
#include <wx/wxprec.h>
#ifdef __BORLANDC__
  #pragma hdrstop
#endif
#ifndef WX_PRECOMP
  #include "wx/wx.h"
#endif

#include <wx/xml/xml.h>
#include <wx/xtixml.h>
#include <wx/xtistrm.h>
#include <wx/mstream.h>

#define FORM_ID        200
#define MAIN_PANEL_ID  201
#define COMBOBOX_ID    202

class Form : public wxFrame
{
public:
    Form();
    ~Form();
    bool Init();
    bool Create( wxWindow * parent, wxWindowID id, const wxString & title,
		 const wxPoint & pos = wxDefaultPosition, const wxSize & size = wxDefaultSize,
		 long style = wxDEFAULT_FRAME_STYLE);

    static const wxString Form::FormName;
    static const wxString Form::ClassName;

    wxPanel* m_MainPanel;
    wxComboBox* m_ComboBox;

};
