
#include "Form.h"

const wxString Form::FormName = wxT("FormName");
const wxString Form::ClassName= wxT("Form");


Form::Form()
{
 
}
 
bool Form::Init()
{
   this->Create(NULL, FORM_ID, "form", wxPoint(160, 160), wxSize(160, 160), \
		 wxCLIP_CHILDREN|wxCAPTION|wxTHICK_FRAME|wxSYSTEM_MENU|wxRESIZE_BOX|wxCLOSE_BOX|wxMINIMIZE_BOX);
   m_MainPanel = new wxPanel(this, MAIN_PANEL_ID, wxPoint(0,0), wxSize(152, 153), wxDEFAULT_FRAME_STYLE, "MainPanel");
   wxString choices[3] = {"one", "two", "three"};
   m_ComboBox = new wxComboBox(m_MainPanel, COMBOBOX_ID, choices[0], wxPoint(0,0), wxSize(100, 50), 3, choices);
   return true;
}

bool Form::Create( wxWindow * parent, wxWindowID id, const wxString & title, const wxPoint & pos, \
                                            const wxSize & size, long style)
{
    return wxFrame::Create( parent, id, title, pos, size, style );
}

Form::~Form()
{

}

