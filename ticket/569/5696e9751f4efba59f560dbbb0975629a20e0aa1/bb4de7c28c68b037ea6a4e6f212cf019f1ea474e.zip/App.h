

class App : public wxApp
{
public:
    virtual bool OnInit();
};

























