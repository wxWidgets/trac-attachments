#include "pch.h"
#include "NullFrame.h"

namespace null_app
{

//! Event table.
wxBEGIN_EVENT_TABLE(NullFrame, wxFrame)
	EVT_CLOSE(NullFrame::OnCloseWindow)
wxEND_EVENT_TABLE()

NullFrame::NullFrame()
	: wxFrame(NULL, wxID_ANY, wxT("NULL FRAME"), wxDefaultPosition, wxDefaultSize, wxDEFAULT_FRAME_STYLE)
{
	////////////////////////////////////////////////////////////////////////// Problematic code //
	wxFTP ftp;
	ftp.SetUser(wxT("username"));
	ftp.SetPassword(wxT("password"));

	if (ftp.Connect(wxT("ip_address")))
	{
		wxString str = ftp.Pwd(); // << ------ - ERROR: string iterator not dereferencable
	}
	////////////////////////////////////////////////////////////////////////// Problematic code //
}

NullFrame::~NullFrame()
{ }

void NullFrame::OnCloseWindow(wxCloseEvent& WXUNUSED(e))
{
	Destroy();
}

} // namespace null_app
