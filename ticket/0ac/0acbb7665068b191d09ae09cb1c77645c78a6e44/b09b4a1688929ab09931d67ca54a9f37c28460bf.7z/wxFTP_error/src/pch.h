#pragma once

//////////////////////////////////////////////////////////////////////////
// wxWidgets includes and definitions.
//
#include <wx/wxprec.h>

#ifndef WX_PRECOMP
	#include <wx/wx.h>
#endif

#include "wx/protocol/ftp.h"