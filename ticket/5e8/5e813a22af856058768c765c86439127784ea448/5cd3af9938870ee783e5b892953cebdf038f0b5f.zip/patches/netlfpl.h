/////////////////////////////////////////////////////////////////////////////
// Name:        netlfpl.h
// Purpose:     cbNETLFPlugin class declaration
// Author:      Alik Kurdjukov
// Modified by:
// Created:     27/04/2003
// RCS-ID:      $Id: $
// Copyright:   (c) Alik Kurdjukov
// Licence:     wxWindows licence
/////////////////////////////////////////////////////////////////////////////

#ifndef __NETLFPL_G__
#define __NETLFPL_G__

#if defined(__GNUG__) && !defined(__APPLE__)
    #pragma interface "netlfpl.h"
#endif

#include "wx/fl/controlbar.h"
#include "wx/fl/toolwnd.h"

#define BTN_NET_BOX_HEIGHT       15
#define BTN_NET_BOX_WIDTH        15
#define BTN_NET_X_WEIGHT         2

/*
This class intercepts bar-decoration and sizing events, and draws 3D hints
around fixed and flexible bars, similar to those in Microsoft.NET products
*/

class WXFL_DECLSPEC cbNETLFPlugin : public cbPluginBase
{
    DECLARE_DYNAMIC_CLASS( cbNETLFPlugin )

protected:
    cbDockPane* mpPane; // is set up temorarely, while handling event

    cbMiniButton* mBoxes[2];

    bool        mBtnPressed;
    bool        mClosePressed;
    cbBarInfo*  mpClickedBar;
    bool        mDepressed;
	wxFont      mTitleFont;

protected:
    // Helper function: draws grooves.
    void DrawGrooves    ( wxDC& dc, const wxPoint& pos, int length );

	// Helper function: draws title
	void DrawTitle(wxDC& dc, const wxPoint& pos, int length, const wxString& text);

    // Helper function: draws a hint.
    void DoDrawHint(wxDC& dc, wxRect& rect, int pos, int boxOfs, 
					int grooveOfs, const cbBarInfo* barInfo);

    // Helper function: gets the layout of a hint.
    void GetHintsLayout( wxRect& rect, cbBarInfo& info,
                         int& boxOfs, int& grooveOfs, int& pos );

    // Helper function: returns information about the hint under the given position.
    int HitTestHints( cbBarInfo& info, const wxPoint& pos );

        // Helper function.
    void ExcludeHints( wxRect& rect, cbBarInfo& info );

        // Helper function: creates close and collapse boxes.
    void CreateBoxes();

public:
    /* public properties */

    bool mCloseBoxOn;    // default: ON
    bool mCollapseBoxOn; // default: ON
    int  mHintGap;       // default: 5 (pixels from above, below, right and left)

public:
        // Default constructor.
    cbNETLFPlugin(void);

        // Constructor, taking parent frame and pane mask flag.
    cbNETLFPlugin( wxFrameLayout* pLayout, int paneMask = wxALL_PANES );

        // Destructor.
    ~cbNETLFPlugin();

        // Called to initialize this plugin.
    void OnInitPlugin();

        // Handles a plugin event.
    void OnSizeBarWindow( cbSizeBarWndEvent& event );

        // Handles a plugin event.
    void OnDrawBarDecorations( cbDrawBarDecorEvent& event );

        // Handles a plugin event.
    void OnLeftDown( cbLeftDownEvent& event );

        // Handles a plugin event.
    void OnLeftUp  ( cbLeftUpEvent&   event );

        // Handles a plugin event.
    void OnMotion  ( cbMotionEvent&   event );

    DECLARE_EVENT_TABLE()
};

/**
 * cbNETMiniButton is a window close button with .NET look
 */
class WXFL_DECLSPEC cbNETMiniButton: public cbMiniButton
{
protected:
	wxPen      mHighBorderPen;
	wxBrush    mHighBackground;
	bool       mIsMouseOver;
	wxBrush    mNormalBackground;
public:
	// Constrictor
	cbNETMiniButton();

    // Draws the close button appearance.
    virtual void Draw( wxDC& dc );

    // Responds to a mouse move event.
    virtual void OnMotion( const wxPoint& pos );
};

/**
 * cbNETCloseBox is a window close button with .NET look
 */
class WXFL_DECLSPEC cbNETCloseBox: public cbNETMiniButton
{
public:
    // Draws the close button appearance.
    virtual void Draw( wxDC& dc );
};

/**
 * cbNETCollapseBox is a window close button with .NET look
 */
class WXFL_DECLSPEC cbNETCollapseBox: public cbNETMiniButton
{
protected:
    bool mIsAtLeft;
public:
    // Draws the collapse button appearance.
    virtual void Draw( wxDC& dc );

	bool IsAtLeft() const {
		return mIsAtLeft;
	}

	void SetIsAtLeft(bool v) {
		mIsAtLeft = v;
	}
};

#endif /* __NETLFPL_G__ */

