/////////////////////////////////////////////////////////////////////////////
// Name:        toolwnd.h
// Purpose:     cbMiniButton class declarations.
// Author:      Aleksandras Gluchovas
// Modified by: Alik Kurdjukov
// Created:     27/04/2003
// RCS-ID:      $Id: $
// Copyright:   (c) Aleksandras Gluchovas
// Licence:     wxWindows licence
/////////////////////////////////////////////////////////////////////////////

#ifndef __MINIBUTTON_G__
#define __MINIBUTTON_G__

#if defined(__GNUG__) && !defined(__APPLE__)
    #pragma interface "minibutton.h"
#endif

#include "wx/fl/controlbar.h"

/*
cbMiniButton is the base class for a small button that can be placed in a wxToolWindow
titlebar.
*/

class WXFL_DECLSPEC cbMiniButton : public wxObject
{
protected:
	wxSize    mSize;
public:
    wxPoint   mPos;
    wxSize    mDim;
    bool      mVisible;
    bool      mEnabled;

    wxFrameLayout* mpLayout;
    cbDockPane*    mpPane;
    cbPluginBase*  mpPlugin;

    wxWindow*      mpWnd;

    bool      mWasClicked;
    bool      mDragStarted;

    bool      mPressed;
public:
        // Default constructor.
    cbMiniButton();

        // Set the position of the button.
    void SetPos( const wxPoint& pos );

        // Returns TRUE if the given position was over the button.
    bool HitTest( const wxPoint& pos );

        // Responds to a left down event.
    void OnLeftDown( const wxPoint& pos );

        // Responds to a left up event.
    void OnLeftUp( const wxPoint& pos );

        // Responds to a mouse move event.
    virtual void OnMotion( const wxPoint& pos );

        // Refreshes the button.
    void Refresh();

        // Draws the button. Override this to implement
        // the desired appearance.
    virtual void Draw( wxDC& dc );

        // Returns TRUE if the button was clicked.
    bool WasClicked();

        // Reset the button.
    void Reset();

        // Enable or disable the button.
    void Enable( bool enable ) { mEnabled = enable; }

        // Returns TRUE if this button is pressed.
    bool IsPressed() { return mPressed; }

	// Return button height
	int GetHeight() const {
		return mSize.GetHeight();
	}

	// Return button width
	int GetWidth() const {
		return mSize.GetWidth();
	}

	const wxSize& GetSize() {
		return mSize;
	}
};

typedef cbMiniButton* cbMinitButtonPtrT;

WXFL_DEFINE_ARRAY( cbMinitButtonPtrT, cbMiniButtonArrayT );

/*
cbCloseBox is a window close button, used in a wxToolWindow titlebar.
*/
class WXFL_DECLSPEC cbCloseBox : public cbMiniButton
{
public:
    // Draws the close button appearance.
    virtual void Draw( wxDC& dc );
};

/*
cbCollapseBox is a window collapse button, used in a wxToolWindow titlebar.
*/
class WXFL_DECLSPEC cbCollapseBox  : public cbMiniButton
{
public:
    bool mIsAtLeft;

    // Draws the collapse button appearance.
    virtual void Draw( wxDC& dc );
};

#endif /* __MINIBUTTON_G__ */
