/////////////////////////////////////////////////////////////////////////////
// Name:        minibutton.cpp
// Purpose:     cbMiniButton implementation.
// Author:      Aleksandras Gluchovas
// Modified by: Alik Kurdjukov
// Created:     24/04/2003
// RCS-ID:      $Id: $
// Copyright:   (c) Aleksandras Gluchovas
// Licence:   	wxWindows licence
/////////////////////////////////////////////////////////////////////////////

#ifdef __GNUG__
    #pragma implementation "minibutton.h"
#endif

// For compilers that support precompilation, includes "wx.h".
#include "wx/wxprec.h"

#ifdef __BORLANDC__
#pragma hdrstop
#endif

#ifndef WX_PRECOMP
#include "wx/wx.h"
#endif

#include "wx/fl/minibutton.h"

// fixed settings
#define BTN_BOX_HEIGHT       12
#define BTN_BOX_WIDTH        12
#define BTN_X_WEIGHT         2

cbMiniButton::cbMiniButton()

	: mVisible( TRUE ),
	  mEnabled( TRUE ),

	  mpLayout( NULL ),
	  mpPane  ( NULL ),
	  mpPlugin( NULL ),
	  mpWnd   ( NULL ),

	  mWasClicked( FALSE ),
	  mDragStarted( FALSE ),
	  mPressed( FALSE ),

	  mSize(BTN_BOX_WIDTH, BTN_BOX_HEIGHT)
{}

void cbMiniButton::SetPos( const wxPoint& pos )
{
	mPos = pos;
}

bool cbMiniButton::HitTest( const wxPoint& pos )
{
	if ( !mVisible ) return FALSE;

	return ( pos.x >= mPos.x && pos.y >= mPos.y &&
		     pos.x < mPos.x + GetWidth()     &&
			 pos.y < mPos.y + GetHeight() );
}

void cbMiniButton::OnLeftDown( const wxPoint& pos )
{
	if ( !mVisible || mDragStarted ) return;

	if ( HitTest( pos ) && mEnabled )
	{
		if ( mpPlugin )
		{
			mpLayout->CaptureEventsForPane( mpPane );
			mpLayout->CaptureEventsForPlugin( mpPlugin );
		}
		else
			mpWnd->CaptureMouse();

		mDragStarted = TRUE;
		mPressed     = TRUE;
		mWasClicked  = FALSE;

		Refresh();
	}
}

void cbMiniButton::OnLeftUp( const wxPoint& pos )
{
	if ( !mVisible || !mDragStarted ) return;

	if ( mpPlugin )
	{
		mpLayout->ReleaseEventsFromPane( mpPane );
		mpLayout->ReleaseEventsFromPlugin( mpPlugin );
	}
	else
		mpWnd->ReleaseMouse();

	mWasClicked  = mPressed;
	mDragStarted = FALSE;

	mPressed = FALSE;
	Refresh();
}

void cbMiniButton::OnMotion( const wxPoint& pos )
{
	if ( !mVisible ) return;

	if ( mDragStarted )
	{
		mPressed = HitTest( pos );

		Refresh();
	}
}

void cbMiniButton::Refresh()
{
	if ( mpLayout )
	{
		wxClientDC dc( &mpLayout->GetParentFrame() );

		Draw( dc );
	}
	else
	{
		wxWindowDC dc( mpWnd );

		Draw( dc );
	}
}

void cbMiniButton::Draw( wxDC& dc )
{
	if ( !mVisible ) return;

	dc.SetPen( *wxTRANSPARENT_PEN );

	dc.SetBrush( *wxLIGHT_GREY_BRUSH );

	dc.DrawRectangle( mPos.x + 1, mPos.y + 1, BTN_BOX_WIDTH - 2, BTN_BOX_HEIGHT - 2 );

	// "hard-code" metafile

	if ( !mPressed )

		dc.SetPen( *wxWHITE_PEN );
	else
		dc.SetPen( *wxBLACK_PEN );

	dc.DrawLine( mPos.x, mPos.y, mPos.x + BTN_BOX_WIDTH, mPos.y );
	dc.DrawLine( mPos.x, mPos.y, mPos.x, mPos.y + BTN_BOX_HEIGHT );

	dc.SetPen( *wxGREY_PEN );

	if ( !mPressed )
	{
		dc.DrawLine( mPos.x + 1, mPos.y + BTN_BOX_HEIGHT - 2, 
					 mPos.x + BTN_BOX_WIDTH - 1, mPos.y + BTN_BOX_HEIGHT - 2 );
		
		dc.DrawLine( mPos.x + BTN_BOX_WIDTH - 2, mPos.y + 1, 
					 mPos.x + BTN_BOX_WIDTH - 2, mPos.y + BTN_BOX_HEIGHT - 1 );
	}
	else
	{
		dc.DrawLine( mPos.x + 1, mPos.y + 1, 
			         mPos.x + BTN_BOX_WIDTH - 2, mPos.y + 1 );
					 
		dc.DrawLine( mPos.x + 1, mPos.y + 1,
			         mPos.x + 1, mPos.y + BTN_BOX_HEIGHT - 2 );
	}

	if ( !mPressed )

		dc.SetPen( *wxBLACK_PEN );
	else
		dc.SetPen( *wxWHITE_PEN );

	dc.DrawLine( mPos.x, mPos.y + BTN_BOX_HEIGHT - 1,  
		         mPos.x + BTN_BOX_WIDTH, mPos.y + BTN_BOX_HEIGHT - 1 );

	dc.DrawLine( mPos.x + BTN_BOX_WIDTH - 1, mPos.y ,
		         mPos.x + BTN_BOX_WIDTH - 1, mPos.y + BTN_BOX_HEIGHT );
}

bool cbMiniButton::WasClicked() 
{ 
	return mWasClicked; 
}

void cbMiniButton::Reset() 
{ 
	mWasClicked = FALSE; 
}

/***** Implementation for class cbCloseBox *****/

void cbCloseBox::Draw( wxDC& dc )
{
#if defined(__WXGTK__) || defined(__WXX11__)

    cbMiniButton::Draw( dc );
    
    wxPen pen( wxColour( 64,64,64 ) ,1, wxSOLID );
    
    dc.SetPen( pen );
    
    int width = BTN_BOX_WIDTH - 7;
    
    int xOfs = (mPressed) ? 4 : 3;
    int yOfs = (mPressed) ? 4 : 3;	

    int one = 1;
    for( int i = 0; i != BTN_X_WEIGHT; ++i )
    {
        dc.DrawLine( mPos.x + xOfs + i - one,
                     mPos.y + yOfs - one,
                     mPos.x + xOfs + i + width,
                     mPos.y + yOfs + width  + one);
    
        dc.DrawLine( mPos.x + xOfs + i + width ,
                     mPos.y + yOfs - one - one,
                     mPos.x + xOfs + i - one,
                     mPos.y + yOfs + width );
    }
    
#else

	cbMiniButton::Draw( dc );

	dc.SetPen( *wxBLACK_PEN );

	int width = BTN_BOX_WIDTH - 7;

	int xOfs = (mPressed) ? 4 : 3;
	int yOfs = (mPressed) ? 4 : 3;

	for( int i = 0; i != BTN_X_WEIGHT; ++i )
	{
		dc.DrawLine( mPos.x + xOfs + i,
			         mPos.y + yOfs,
					 mPos.x + xOfs + i + width,
					 mPos.y + yOfs + width );

		dc.DrawLine( mPos.x + xOfs + i + width - 1,
			         mPos.y + yOfs,
					 mPos.x + xOfs + i - 1,
					 mPos.y + yOfs + width );
	}

#endif

}

/***** Implementation fro class cbCollapseBox *****/

inline static void my_swap( int& a, int& b )
{
	long tmp = a;
	a = b;
	b = tmp;
}

void cbCollapseBox::Draw( wxDC& dc )
{
	cbMiniButton::Draw( dc );

	dc.SetPen( *wxTRANSPARENT_PEN );

	wxPoint arr[3];

	int yOfs  = (mPressed) ? 3 : 2;
	int xOfs  = (mPressed) ? 5 : 4;
	int width = BTN_BOX_WIDTH - 8;

	// rotating/shifting triangle inside collapse box

	arr[0].x = xOfs;
	arr[0].y = yOfs-1;
	arr[2].x = xOfs;
	arr[2].y = BTN_BOX_HEIGHT - yOfs - 1;
	arr[1].x = xOfs + width;
	arr[1].y = (arr[2].y + arr[0].y)/2;

	if ( !mIsAtLeft )
	{
		arr[0].x = BTN_BOX_WIDTH - arr[0].x;
		arr[1].x = BTN_BOX_WIDTH - arr[1].x;
		arr[2].x = BTN_BOX_WIDTH - arr[2].x;
	}

	if ( !mpPane->IsHorizontal() )
	{
		my_swap( arr[0].y, arr[0].x );
		my_swap( arr[1].y, arr[1].x );
		my_swap( arr[2].y, arr[2].x );

		arr[0].x += 1;
		arr[1].x += 1;
		arr[2].x += 1;

		//arr[1].y -= 1;
	}

	arr[0].x += mPos.x;
	arr[0].y += mPos.y;
	arr[1].x += mPos.x;
	arr[1].y += mPos.y;
	arr[2].x += mPos.x;
	arr[2].y += mPos.y;

	if ( !mEnabled ) dc.SetBrush( *wxGREY_BRUSH );
				else dc.SetBrush( *wxBLACK_BRUSH );

	dc.DrawPolygon( 3, arr );
	dc.SetBrush( wxNullBrush );
}
