# Stuff these names to wx namespace so wxPyConstructObject can find them

wx.cbPluginEventPtr = cbPluginEventPtr

wx.cbLeftDownEventPtr = cbLeftDownEventPtr
wx.cbLeftUpEventPtr = cbLeftUpEventPtr
wx.cbRightDownEventPtr = cbRightDownEventPtr
wx.cbRightUpEventPtr = cbRightUpEventPtr
wx.cbMotionEventPtr = cbMotionEventPtr
wx.cbLeftDClickEventPtr = cbLeftDClickEventPtr

wx.cbLayoutRowEventPtr = cbLayoutRowEventPtr
wx.cbResizeRowEventPtr = cbResizeRowEventPtr
wx.cbLayoutRowsEventPtr = cbLayoutRowsEventPtr
wx.cbInsertBarEventPtr = cbInsertBarEventPtr
wx.cbResizeBarEventPtr = cbResizeBarEventPtr
wx.cbRemoveBarEventPtr = cbRemoveBarEventPtr
wx.cbSizeBarWndEventPtr = cbSizeBarWndEventPtr

wx.cbDrawBarDecorEventPtr = cbDrawBarDecorEventPtr
wx.cbDrawRowDecorEventPtr = cbDrawRowDecorEventPtr
wx.cbDrawPaneDecorEventPtr = cbDrawPaneDecorEventPtr
wx.cbDrawBarHandlesEventPtr = cbDrawBarHandlesEventPtr
wx.cbDrawRowHandlesEventPtr = cbDrawRowHandlesEventPtr
wx.cbDrawRowBkGroundEventPtr = cbDrawRowBkGroundEventPtr
wx.cbDrawPaneBkGroundEventPtr = cbDrawPaneBkGroundEventPtr
wx.cbStartBarDraggingEventPtr = cbStartBarDraggingEventPtr
wx.cbDrawHintRectEventPtr = cbDrawHintRectEventPtr
wx.cbStartDrawInAreaEventPtr = cbStartDrawInAreaEventPtr
wx.cbFinishDrawInAreaEventPtr = cbFinishDrawInAreaEventPtr
wx.cbCustomizeBarEventPtr = cbCustomizeBarEventPtr
wx.cbCustomizeLayoutEventPtr = cbCustomizeLayoutEventPtr
