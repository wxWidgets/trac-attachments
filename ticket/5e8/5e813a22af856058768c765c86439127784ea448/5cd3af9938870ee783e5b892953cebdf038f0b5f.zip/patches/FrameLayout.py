
from wxPython.wx import *
from wxPython.fl import *
import images

#----------------------------------------------------------------------

class CustomPlugin(cbPyPluginBase):
	def __init__(self, layout, mask, log):
		cbPyPluginBase.__init__(self, layout, mask)
		self.mask = mask
		self.log = log
		EVT_PL_INSERT_BAR(self, self.OnInsertBar)
		EVT_PL_LEFT_DOWN(self, self.OnLeftDown)
		EVT_PL_LEFT_UP(self, self.OnLeftUp)
		
	def OnInitPlugin(self):
		self.log.write("OnInitPlugin")
		
	def GetPaneMask(self):
		self.log.write("GetPaneMask")
		return mask
		
	def IsReady(self):
		self.log.write("IsReady")
		return 1
		
	def OnLeftDown(self, event):
		self.log.write("Left down")
		event.Skip()
		
	def OnLeftUp(self, event):
		self.log.write("Left up")
		event.Skip()
		
	def OnInsertBar(self, event):
		bi = event.GetBarInfo()
		self.log.write("Insert bar '%s' bounds: %s" % \
							(bi.GetName(), bi.GetBounds()))
		event.Skip()

class TestFrameLayoutWindow(wxFrame):
	def __init__(self, parent, log):
		wxFrame.__init__(self, parent, -1, 'Test DynamicToolBar', size=(700, 600))
		self.log = log
		self.SetBackgroundColour(wxColor(192, 192, 192))
		
		textEdit = self.CreateTextCtrl("Client window")
		
		layout = wxFrameLayout(self, textEdit)
		EVT_PL_INSERT_BAR(layout, self.OnInsertBar)
		
		layout.PushDefaultPlugins()
		#layout.AddPlugin(cbNETLFPlugin().GetClassInfo())
		layout.AddPlugin(cbHintAnimationPlugin().GetClassInfo())
		layout.AddPlugin(cbRowDragPlugin().GetClassInfo())
		layout.PushPlugin(CustomPlugin(layout, wxALL_PANES, self.log))

		## drop in some bars
		sizes0 = cbDimInfoSizesDelta( 200,45, ## when docked horizontally      
							200,85, ## when docked vertically        
							175,35, ## when floated                  
							False,  ## the bar is not fixed-size
							4,      ## vertical gap (bar border)
							4       ## horizontal gap (bar border)
							) 

		sizes1 = cbDimInfoSizesDelta( 150,35, ## when docked horizontally      
							150,85, ## when docked vertically        
							175,35, ## when floated                  
							True,   ## the bar is not fixed-size
							4,      ## vertical gap (bar border)
							4       ## horizontal gap (bar border)
							) 

		sizes2 = cbDimInfoSizesDelta( 250,35, ## when docked horizontally      
							185,37, ## when docked vertically        
							250,35, ## when floated                  
							True,   ## the bar is not fixed-size
							4,      ## vertical gap (bar border)
							4,      ## horizontal gap (bar border)
							cbDynToolBarDimHandler()
							) 

		layout.AddBar(self.CreateTextCtrl("Hello"),  ## bar window
						sizes0, FL_ALIGN_TOP,   ## alignment ( 0-top,1-bottom, etc)
						0,                      ## insert into 0th row (vert. position)
						0,                      ## offset from the start of row (in pixels)
						"InfoViewer1",          ## name to refer in customization pop-ups
						True
					)

		layout.AddBar(self.CreateTextCtrl("Bye"),    ## bar window
						sizes0, FL_ALIGN_TOP,   ## alignment ( 0-top,1-bottom, etc)
						1,                      ## insert into 0th row (vert. position)
						0,                      ## offset from the start of row (in pixels)
						"InfoViewer2",          ## name to refer in customization pop-ups
						True
					)

		layout.AddBar(self.CreateTextCtrl("Fixed0"),  ## bar window
						sizes1, FL_ALIGN_TOP,     ## alignment ( 0-top,1-bottom, etc)
						0,                        ## insert into 0th row (vert. position)
						0,                        ## offset from the start of row (in pixels)
						"ToolBar1",               ## name to refer in customization pop-ups
						True
					)

		toolBar = wxDynamicToolBarXP(self, -1)
		toolBar.AddToolBitmap(1001, images.getNewBitmap())
		EVT_MENU(self, 1001, self.OnNewCommand)
		toolBar.AddSeparator();
		toolBar.AddToolBitmap(1002, images.getOpenBitmap())
		toolBar.AddToolBitmap(1005, images.getCopyBitmap())
		toolBar.AddToolBitmap(1006, images.getPasteBitmap())
		toolBar.AddSeparator();
		toolBar.AddToolWindow(1007, wxComboBox(toolBar, -1, 'test'))

		layout.AddBar(toolBar,                ## bar window (can be NULL)
						sizes2, FL_ALIGN_TOP, ## alignment ( 0-top,1-bottom, etc)
						0,                    ## insert into 0th row (vert. position)
						0,                    ## offset from the start of row (in pixels)
						"ToolBar2",           ## name to refer in customization pop-ups
						False
					)

		layout.EnableFloating(True)

	def CreateTextCtrl(self, text):
		textEdit = wxTextCtrl(self, -1, text, wxDefaultPosition, wxSize(0, 0), wxTE_MULTILINE)
		textEdit.SetBackgroundColour(wxColour(255, 255, 255))
		return textEdit
		
	def OnNewCommand(self, event):
		self.log.write("New command")
		
	def OnInsertBar(self, event):
		self.log.write("InserBar: %s" % str(event))
		

#----------------------------------------------------------------------

def runTest(frame, nb, log):
	win = TestFrameLayoutWindow(nb, log)
	frame.otherWin = win
	win.Show(True)

#----------------------------------------------------------------------



overview = """<html><body>
<h2><center>Simple FL demonstration</center></h2>

</body></html>
"""



if __name__ == '__main__':
    import sys,os
    import run
    run.main(['', os.path.basename(sys.argv[0])])

