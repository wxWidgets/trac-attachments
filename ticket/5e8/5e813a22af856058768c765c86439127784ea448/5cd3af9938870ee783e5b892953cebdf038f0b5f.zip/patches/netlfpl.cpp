/////////////////////////////////////////////////////////////////////////////
// Name:        netlfpl.cpp
// Purpose:     Implementation for cbNETLFPlugin
// Author:      Alik Kurdjukov
// Modified by:
// Created:     27/04/2003
// RCS-ID:      $Id: $
// Copyright:   (c) Alik Kurdjukov
// Licence:     wxWindows licence
/////////////////////////////////////////////////////////////////////////////
 
#ifdef __GNUG__
    #pragma implementation "netlfpl.h"
#endif

// For compilers that support precompilation, includes "wx.h".
#include "wx/wxprec.h"

#ifdef __BORLANDC__
#pragma hdrstop
#endif

#ifndef WX_PRECOMP
#include "wx/wx.h"
#endif

#include "wx/utils.h"
#include "wx/fl/netlfpl.h"

// fixed settings

#define GROOVE_WIDTH         1
#define GROOVE_TO_GROOVE_GAP 1  
#define GROOVE_LENGTH        3
#define BOX_T_BOX_GAP        2
#define BOX_TO_GROOVE_GAP    3

#define BOXES_IN_HINT        2
#define CLOSE_BOX_IDX        0
#define COLLAPSE_BOX_IDX     1

// used interally 

#define CLOSE_BOX_HITTED    1
#define COLLAPSE_BOX_HITTED 2


/***** Implementation fro class cbNETLFPlugin *****/

IMPLEMENT_DYNAMIC_CLASS( cbNETLFPlugin, cbPluginBase )

BEGIN_EVENT_TABLE( cbNETLFPlugin, cbPluginBase )

    EVT_PL_SIZE_BAR_WND  ( cbNETLFPlugin::OnSizeBarWindow )
    EVT_PL_DRAW_BAR_DECOR( cbNETLFPlugin::OnDrawBarDecorations )

    EVT_PL_LEFT_DOWN( cbNETLFPlugin::OnLeftDown )
    EVT_PL_LEFT_UP  ( cbNETLFPlugin::OnLeftUp   )
    EVT_PL_MOTION   ( cbNETLFPlugin::OnMotion   )

END_EVENT_TABLE()

cbNETLFPlugin::cbNETLFPlugin(void)

    : mpPane( 0 ),
      mBtnPressed   ( FALSE ),
      mCloseBoxOn   ( TRUE ),
      mCollapseBoxOn( TRUE ),
      mHintGap      ( 1 ),
	  mTitleFont(8, wxDEFAULT, wxNORMAL, wxBOLD, FALSE, "Verdana")
{
    mBoxes[CLOSE_BOX_IDX]    = NULL;
    mBoxes[COLLAPSE_BOX_IDX] = NULL;
}

cbNETLFPlugin::cbNETLFPlugin( wxFrameLayout* pLayout, int paneMask )

    : cbPluginBase( pLayout, paneMask ),
      mpPane( 0 ),
      mBtnPressed   ( FALSE ),
      mCloseBoxOn   ( TRUE ),
      mCollapseBoxOn( TRUE ),
      mHintGap      ( 1 ),
	  mTitleFont(8, wxDEFAULT, wxNORMAL, wxBOLD, FALSE, "Verdana")
{
    mBoxes[CLOSE_BOX_IDX]    = NULL;
    mBoxes[COLLAPSE_BOX_IDX] = NULL;
}


cbNETLFPlugin::~cbNETLFPlugin()
{
    if (mBoxes[CLOSE_BOX_IDX])
        delete mBoxes[CLOSE_BOX_IDX];

    if (mBoxes[COLLAPSE_BOX_IDX])
        delete mBoxes[COLLAPSE_BOX_IDX];
}  // cbNETLFPlugin destructor


void cbNETLFPlugin::CreateBoxes()
{
    cbNETCloseBox*    box1 = new cbNETCloseBox();
    cbNETCollapseBox* box2 = new cbNETCollapseBox();

    mBoxes[CLOSE_BOX_IDX]    = box1;
    mBoxes[COLLAPSE_BOX_IDX] = box2;

    int i;
    for ( i = 0; i != BOXES_IN_HINT; ++i )
    {
        mBoxes[i]->mpLayout = mpLayout;
        mBoxes[i]->mpPlugin = this;
        mBoxes[i]->mpWnd    = NULL;
    }
}

void cbNETLFPlugin::DrawGrooves(wxDC& dc, const wxPoint& pos, int length)
{
    dc.SetPen( mpLayout->mDarkPen );
    for ( int ofs = 0; ofs < length; ofs += ( GROOVE_WIDTH + GROOVE_TO_GROOVE_GAP ) )
    {
        if ( mpPane->IsHorizontal() )
        {
            dc.DrawLine(pos.x, pos.y + ofs, pos.x + GROOVE_LENGTH, pos.y + ofs );
        }
        else
        {
            dc.DrawLine(pos.x + ofs, pos.y, pos.x + ofs, pos.y + GROOVE_LENGTH );
        }
    }
}

void cbNETLFPlugin::DrawTitle(wxDC& dc, const wxPoint& pos, int length, const wxString& text) {
	dc.SetClippingRegion(pos, wxSize(length, mTitleFont.GetPointSize()*2));
	dc.SetFont(mTitleFont);
	dc.DrawText(text, pos.x, pos.y);
	dc.DestroyClippingRegion();
}

void cbNETLFPlugin::ExcludeHints( wxRect& rect, cbBarInfo& info )
{
    int boxHeight = mBoxes[CLOSE_BOX_IDX]->GetHeight();

    // collapse and close box are not placed on fixed bars

    if ( info.IsFixed() || ( !mCloseBoxOn && !mCollapseBoxOn ) )
        boxHeight = 0;

    int height = wxMax(GROOVE_LENGTH * 3, boxHeight);

    if ( mpPane->IsHorizontal() )
    {
        rect.x     += height + 2;
        rect.width -= height + 2;

        rect.x     -= info.mDimInfo.mHorizGap + 2;
        rect.width += info.mDimInfo.mHorizGap + 2;
    }
    else
    {
        rect.y      += height + 2;
        rect.height -= height + 2;

        rect.y      -= info.mDimInfo.mVertGap + 2;
        rect.height += info.mDimInfo.mVertGap + 2;
    }
}

void cbNETLFPlugin::DoDrawHint( wxDC& dc, wxRect& rect, 
                                   int pos, int boxOfs, int grooveOfs,
                                   const cbBarInfo* barInfo )
{
	bool isFixed = barInfo->IsFixed();

    if ( !isFixed )
    {
        if ( mpPane->IsHorizontal() )
        {
            if ( mCloseBoxOn )

                mBoxes[CLOSE_BOX_IDX]->Draw( dc );

            if ( mCollapseBoxOn )
            
                mBoxes[COLLAPSE_BOX_IDX]->Draw( dc );
        }
        else
        {
            if ( mCloseBoxOn )
            
                mBoxes[CLOSE_BOX_IDX]->Draw( dc );

            if ( mCollapseBoxOn )
            
                mBoxes[COLLAPSE_BOX_IDX]->Draw( dc );
        }
    }

	if (isFixed || (!mCloseBoxOn && !mCollapseBoxOn)) 
	{
	    if ( mpPane->IsHorizontal() )
		    DrawGrooves( dc, wxPoint( rect.x + GROOVE_LENGTH + grooveOfs, pos + GROOVE_LENGTH), 
                     rect.height - (pos - rect.y) - GROOVE_LENGTH*2 );
		else
			DrawGrooves( dc, wxPoint( rect.x + GROOVE_LENGTH, rect.y + GROOVE_LENGTH + grooveOfs), 
                     (pos - rect.x) - GROOVE_LENGTH*2 );
	}
	else
	{
	    if ( mpPane->IsHorizontal() )
			wxLogDebug(wxT("This feature not implemented yet"));
		    //DrawTitle(dc, wxPoint( rect.x + GROOVE_LENGTH + grooveOfs, pos + GROOVE_LENGTH), 
            //         rect.height - (pos - rect.y) - GROOVE_LENGTH*2, barInfo->GetName());
		else
			DrawTitle(dc, wxPoint(rect.x + barInfo->GetDimInfo().GetHorizontalGap(), rect.y + grooveOfs), 
                     (pos - rect.x) - GROOVE_LENGTH*2, barInfo->GetName());
	}
}

void cbNETLFPlugin::GetHintsLayout( wxRect& rect, cbBarInfo& info, 
                                       int& boxOfs, int& grooveOfs, int& pos )
{
    int boxHeight = mBoxes[CLOSE_BOX_IDX]->GetHeight();

    // collapse and close box are not placed on fixed bars
    if ( info.IsFixed() || ( !mCloseBoxOn && !mCollapseBoxOn ) )
    {
        boxHeight = 0;
    }
    int grooveHeight = GROOVE_LENGTH * 3;

    int height = wxMax( grooveHeight, boxHeight );

    // center boxs and groves with respect to each other
    boxOfs    = ( height - boxHeight    ) / 2;
    grooveOfs = ( height - grooveHeight ) / 2;

    pos = ( mpPane->IsHorizontal() ) ? rect.y + mHintGap
                                     : rect.x + rect.width - mHintGap;

    // setup positions for boxes

    if ( !info.IsFixed() )
    {
        // what direction "collapse-triangle" should look at?

        bool isAtLeft = info.mBounds.x <= mpPane->mPaneWidth - ( info.mBounds.x + info.mBounds.width );

        if ( info.IsExpanded() )
        {
            isAtLeft = FALSE;

            cbBarInfo* pCur = info.mpPrev;

            while( pCur )
            {
                if ( !pCur->IsFixed() )
                {
                    isAtLeft = TRUE; 
					break;
                }

                pCur = pCur->mpPrev;
            }
        }
		((cbNETCollapseBox*)(mBoxes[COLLAPSE_BOX_IDX]))->SetIsAtLeft(isAtLeft);

        // collapse/expand works only when more not-fixed bars are present in the same row

        mBoxes[COLLAPSE_BOX_IDX]->Enable( info.mpRow->mNotFixedBarsCnt > 1 );

        int i;
        for ( i = 0; i != BOXES_IN_HINT; ++i )
        {
            mBoxes[i]->mpPane = mpPane;
        }

        if ( mpPane->IsHorizontal() )
        {
            if ( mCloseBoxOn )
            {
                mBoxes[CLOSE_BOX_IDX]->mPos = wxPoint( rect.x + boxOfs + 1, pos );

                pos += mBoxes[CLOSE_BOX_IDX]->GetHeight();
            }

            if ( mCollapseBoxOn )
            {
                if ( mCloseBoxOn ) pos += BOX_T_BOX_GAP;

                mBoxes[COLLAPSE_BOX_IDX]->mPos = wxPoint( rect.x + mHintGap + boxOfs, pos );

                pos += mBoxes[COLLAPSE_BOX_IDX]->GetHeight();

                pos += BOX_TO_GROOVE_GAP;
            }
        }
        else
        {
            if ( mCloseBoxOn )
            {
                pos -= mBoxes[CLOSE_BOX_IDX]->GetWidth();

                mBoxes[CLOSE_BOX_IDX]->mPos = wxPoint( pos , rect.y + boxOfs + mHintGap);
            }

            if ( mCollapseBoxOn )
            {
                if ( mCloseBoxOn ) pos -= BOX_T_BOX_GAP;

                pos -= mBoxes[COLLAPSE_BOX_IDX]->GetWidth();

                mBoxes[COLLAPSE_BOX_IDX]->mPos = wxPoint( pos, rect.y + boxOfs + mHintGap);

                pos -= BOX_TO_GROOVE_GAP;
            }
        }
    }
}

static inline bool is_in_box(const wxPoint& rectPos, 
							const wxSize& rectSize, 
							const wxPoint& mousePos)
{
    return ( mousePos.x >= rectPos.x &&
             mousePos.y >= rectPos.y &&
             mousePos.x < rectPos.x + rectSize.GetWidth() &&
             mousePos.y < rectPos.y + rectSize.GetHeight() );
}

int cbNETLFPlugin::HitTestHints( cbBarInfo& info, const wxPoint& pos )
{
    wxPoint inPane = pos;
    mpPane->PaneToFrame( &inPane.x, &inPane.y );

    wxRect& rect = info.mBoundsInParent;

    if ( info.IsFixed() ) return FALSE;

    int boxOfs, grooveOfs, coord;

    GetHintsLayout( rect, info, boxOfs, grooveOfs, coord );

    if ( mpPane->IsHorizontal() )
    {
        if ( mCloseBoxOn )
        {
            if ( is_in_box( wxPoint( rect.x + mHintGap + boxOfs, coord ), 
							mBoxes[CLOSE_BOX_IDX]->GetSize(), inPane ) )

                return CLOSE_BOX_HITTED;

            coord += mBoxes[CLOSE_BOX_IDX]->GetHeight();
        }

        if ( mCollapseBoxOn )
        {
            if ( mCloseBoxOn ) coord += BOX_T_BOX_GAP;

            if ( is_in_box( wxPoint( rect.x + mHintGap + boxOfs, coord ), 
							mBoxes[COLLAPSE_BOX_IDX]->GetSize(), inPane ) )

                return COLLAPSE_BOX_HITTED;

            coord += mBoxes[COLLAPSE_BOX_IDX]->GetHeight();
        }
    }
    else
    {
        if ( mCloseBoxOn )
        {
            coord -= mBoxes[CLOSE_BOX_IDX]->GetWidth();

            if ( is_in_box( wxPoint( coord , rect.y + mHintGap + boxOfs ), 
							mBoxes[CLOSE_BOX_IDX]->GetSize(), inPane ) )

                return CLOSE_BOX_HITTED;
        }

        if ( mCollapseBoxOn )
        {
            if ( mCloseBoxOn ) coord -= BOX_T_BOX_GAP;
            coord -= mBoxes[COLLAPSE_BOX_IDX]->GetWidth();

            if ( is_in_box( wxPoint( coord, rect.y + mHintGap + boxOfs ), 
							mBoxes[COLLAPSE_BOX_IDX]->GetSize(), inPane ) )

                return COLLAPSE_BOX_HITTED;
        }
    }

    return FALSE;
}

// handlers for plugin-events

void cbNETLFPlugin::OnSizeBarWindow( cbSizeBarWndEvent& event )
{
    wxRect& rect     = event.mBoundsInParent;
    mpPane           = event.mpPane;

    ExcludeHints( rect, *event.mpBar );

    event.Skip(); // pass event to the next plugin in the chain
}

void cbNETLFPlugin::OnDrawBarDecorations( cbDrawBarDecorEvent& event )
{
    wxRect& rect     = event.mBoundsInParent;
    mpPane           = event.mpPane;

    int boxOfs, grooveOfs, pos;

    GetHintsLayout( rect, *event.mpBar, boxOfs, grooveOfs, pos );

    DoDrawHint( *event.mpDc, rect, pos, boxOfs, grooveOfs, event.GetBarInfo() );

    // let other plugins add on their decorations

    event.Skip();
}

void cbNETLFPlugin::OnLeftDown( cbLeftDownEvent& event )
{
    mpPane           = event.mpPane;
    wxPoint inFrame = event.mPos;

    mpPane->PaneToFrame( &inFrame.x, &inFrame.y );

    wxBarIterator iter( mpPane->GetRowList() );

    mpClickedBar = NULL;

    while ( iter.Next() )
    {
        cbBarInfo& bar = iter.BarInfo();

        int boxOfs, grooveOfs, pos;

        GetHintsLayout( bar.mBoundsInParent, bar, boxOfs, grooveOfs, pos );

        if ( !bar.IsFixed() )
        {
            int i;
            for ( i = 0; i != BOXES_IN_HINT; ++i )
            {
                mBoxes[i]->mPressed = FALSE;
                mBoxes[i]->mWasClicked = FALSE;
            }
            for ( i = 0; i != BOXES_IN_HINT; ++i )
            {
                mBoxes[i]->OnLeftDown( inFrame );

                if ( mBoxes[i]->mPressed )
                {
                    mBtnPressed = TRUE;
                    mpClickedBar = &bar;

                    return; // event handled
                }
            }
        }
    }

    event.Skip();
}

void cbNETLFPlugin::OnLeftUp( cbLeftUpEvent&   event )
{
    if ( mBtnPressed )
    {
        wxPoint inFrame = event.mPos;
        mpPane->PaneToFrame( &inFrame.x, &inFrame.y );

        int boxOfs, grooveOfs, pos;

        GetHintsLayout( mpClickedBar->mBoundsInParent, *mpClickedBar, boxOfs, grooveOfs, pos );

        int result = HitTestHints( *mpClickedBar, event.mPos );

        int i;
        for ( i = 0; i != BOXES_IN_HINT; ++i )
        {
            mBoxes[i]->OnLeftUp( inFrame );

            if ( mBoxes[i]->WasClicked() )
            {
                if ( i == 0 )
                {
                    mpLayout->SetBarState( mpClickedBar, wxCBAR_HIDDEN, TRUE );
                }
                else
                {
                    if ( mpClickedBar->IsExpanded() )
                        mpPane->ContractBar( mpClickedBar );
                    else
                        mpPane->ExpandBar( mpClickedBar );
                }
            }
        }

        mBtnPressed = FALSE;
        return;
    }
    else
        event.Skip();
}

void cbNETLFPlugin::OnMotion( cbMotionEvent& event )
{
    if ( mBtnPressed )
    {
        wxPoint inFrame = event.mPos;
        mpPane->PaneToFrame( &inFrame.x, &inFrame.y );

        mpPane = event.mpPane;

        int i;
        for ( i = 0; i != BOXES_IN_HINT; ++i )
        {
            mBoxes[i]->OnMotion( inFrame );
        }
    }
    else
	{
        wxPoint inFrame = event.mPos;
        mpPane->PaneToFrame( &inFrame.x, &inFrame.y );

        mpPane = event.mpPane;

        int i;
        for ( i = 0; i != BOXES_IN_HINT; ++i )
        {
            mBoxes[i]->OnMotion( inFrame );
        }

        event.Skip();
	}
}

void cbNETLFPlugin::OnInitPlugin()
{
    cbPluginBase::OnInitPlugin();

    cbDockPane** panes = mpLayout->GetPanesArray();

    int i;
    for ( i = 0; i != MAX_PANES; ++i )
    {    
        if ( panes[i]->MatchesMask( mPaneMask ) )
        {
            panes[i]->mProps.mMinCBarDim.x = 25;
            panes[i]->mProps.mMinCBarDim.y = 16;
        }
    }
    CreateBoxes();
}

//////////////////////////////////////////////////////////////
// cbNETMiniButton

cbNETMiniButton::cbNETMiniButton() 
	: cbMiniButton(),
		mHighBorderPen(wxColour(10, 36, 106), 1, 0),
		mHighBackground(wxColour(182, 189, 210), wxSOLID),
		mIsMouseOver(false)
{
	mNormalBackground = wxBrush(
			wxSystemSettings::GetColour( wxSYS_COLOUR_3DFACE), wxSOLID);
	mSize.Set(BTN_NET_BOX_WIDTH, BTN_NET_BOX_HEIGHT);
}

void cbNETMiniButton::Draw(wxDC& dc)
{
	if (!mVisible) return;

	if (mIsMouseOver && mEnabled) {
		dc.SetPen(mHighBorderPen);
		dc.SetBrush(mHighBackground);
	} else {
		dc.SetPen( *wxTRANSPARENT_PEN );
		dc.SetBrush(mNormalBackground);
	}
	dc.DrawRectangle(mPos.x, mPos.y, GetWidth(), GetWidth());
}

void cbNETMiniButton::OnMotion(const wxPoint& pos)
{
	bool oldVal = mIsMouseOver;
	mIsMouseOver = HitTest(pos);

	cbMiniButton::OnMotion(pos);

	if (mIsMouseOver != oldVal)
		Refresh();
}

//////////////////////////////////////////////////////////////
// cbNETCloseBox

#define BTN_X_OFFSET 4
#define BTN_Y_OFFSET 4

void cbNETCloseBox::Draw( wxDC& dc )
{
#if defined(__WXGTK__) || defined(__WXX11__)
    #warning This code was not tested

    cbMiniButton::Draw( dc );
    
    wxPen pen( wxColour( 64,64,64 ) ,1, wxSOLID );
    
    dc.SetPen( pen );
    
    int width = GetWidth() - 7;
    
    int one = 1;
    for( int i = 0; i != BTN_X_WEIGHT; ++i )
    {
        dc.DrawLine( mPos.x + BTN_X_OFFSET + i - one,
                     mPos.y + BTN_Y_OFFSET - one,
                     mPos.x + BTN_X_OFFSET + i + width,
                     mPos.y + BTN_Y_OFFSET + width  + one);
    
        dc.DrawLine( mPos.x + BTN_X_OFFSET + i + width ,
                     mPos.y + BTN_Y_OFFSET - one - one,
                     mPos.x + BTN_X_OFFSET + i - one,
                     mPos.y + BTN_Y_OFFSET + width );
    }
    
#else

	cbNETMiniButton::Draw(dc);

	if (mPressed)
		dc.SetPen( *wxWHITE_PEN );
	else
		dc.SetPen( *wxBLACK_PEN );

	int width = GetWidth()  - 8;
	int height = GetHeight() - 8;

	for( int i = 0; i != BTN_NET_X_WEIGHT; ++i )
	{
		dc.DrawLine( mPos.x + BTN_X_OFFSET + i,
			         mPos.y + BTN_Y_OFFSET,
					 mPos.x + BTN_X_OFFSET + i + width,
					 mPos.y + BTN_Y_OFFSET + height );

		dc.DrawLine( mPos.x + BTN_X_OFFSET + i + width - 1,
			         mPos.y + BTN_Y_OFFSET,
					 mPos.x + BTN_X_OFFSET + i - 1,
					 mPos.y + BTN_Y_OFFSET + height );
	}

#endif

}

//////////////////////////////////////////////////////////////
// cbNETCollapseBox

inline static void my_swap( int& a, int& b )
{
	long tmp = a;
	a = b;
	b = tmp;
}

#define BTN_TRN_X_OFFSET 5
#define BTN_TRN_Y_OFFSET 4
#define BTN_TRN_ARROW    4

void cbNETCollapseBox::Draw( wxDC& dc )
{
	cbNETMiniButton::Draw( dc );

	dc.SetPen( *wxTRANSPARENT_PEN );

	wxPoint arr[3];

	int yOfs  = BTN_TRN_Y_OFFSET;
	int xOfs  = BTN_TRN_X_OFFSET;
	int width = GetWidth() - 8;

	// rotating/shifting triangle inside collapse box

	arr[0].x = xOfs;
	arr[0].y = yOfs-1;
	arr[2].x = xOfs;
	arr[2].y = GetHeight() - yOfs;
	arr[1].x = xOfs + BTN_TRN_ARROW;
	arr[1].y = (arr[2].y + arr[0].y)/2;

	if ( !mIsAtLeft )
	{
		arr[0].x = GetWidth() - arr[0].x;
		arr[1].x = GetWidth() - arr[1].x;
		arr[2].x = GetWidth() - arr[2].x;
	}

	if ( !mpPane->IsHorizontal() )
	{
		my_swap( arr[0].y, arr[0].x );
		my_swap( arr[1].y, arr[1].x );
		my_swap( arr[2].y, arr[2].x );

		arr[0].x += 1;
		arr[1].x += 1;
		arr[2].x += 1;

		//arr[1].y -= 1;
	}

	arr[0].x += mPos.x;
	arr[0].y += mPos.y;
	arr[1].x += mPos.x;
	arr[1].y += mPos.y;
	arr[2].x += mPos.x;
	arr[2].y += mPos.y;

	if ( !mEnabled ) 
		dc.SetBrush( *wxGREY_BRUSH );
	else if (!mPressed)
		dc.SetBrush( *wxBLACK_BRUSH );
	else
		dc.SetBrush( *wxWHITE_BRUSH );

	dc.DrawPolygon( 3, arr );
	dc.SetBrush( wxNullBrush );
}
