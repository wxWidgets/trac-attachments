﻿-- Copyright 2015 ChemoMetec A/S
-- Revision   : $Id: EjectInsert.Xcyto10.lua,v 1.1 2017/07/28 12:13:46 cek Exp $
-- Description: Insert/eject of sample tray.

function IsPositionKnown(motorName, unit)
  position, status = GetPosition(motorName, unit)
  if(not string.match(status, "ok" )) then
    Abort(_("Motor status not OK for motor: " .. motorName))
  end
  return position
end

function ReadSettingFileMotorReferencePositions()
  ejectxPosition                 = ReadSettingsFileFloat("/ReferencePoints/EjectxPosition")
  ejectyPositionOpen             = ReadSettingsFileFloat("/ReferencePoints/EjectyPositionOpen")
  ejectyPositionClosed           = ReadSettingsFileFloat("/ReferencePoints/EjectyPositionClosed")
  ejectzPosition                 = ReadSettingsFileFloat("/ReferencePoints/EjectzPosition")
  ejectLightPosition             = ReadSettingsFileFloat("/ReferencePoints/EjectlightPosition")
  insideInstrumentxPosition      = ReadSettingsFileFloat("/ReferencePoints/insideInstrumentxPosition")
  xMaxPositionForObjectiveChange = ReadSettingsFileFloat("/ReferencePoints/xMaxPositionForObjectiveChange")
  local objective4xPositionlist  = ReadSettingsFileList("/ObjectiveList/4x")
  objective4xPosition            = s2n(objective4xPositionlist[1])
  lidClosedPosition              = ReadSettingsFileFloat("/ReferencePoints/lidClosedPosition")
  lidOpenPosition                = ReadSettingsFileFloat("/ReferencePoints/lidOpenPosition")
  visionXPosition                = ReadSettingsFileFloat("/ReferencePoints/visionXPosition")
  xMotorID, xMotorType, xMotorResolution = GetMotorParameters("X")
  yMotorID, yMotorType, yMotorResolution = GetMotorParameters("Y")
  zMotorID, zMotorType, zMotorResolution = GetMotorParameters("Z")
  lidMotorID                             = GetMotorParameters("Lid")
end

function InsertEject()
  ReadSettingFileMotorReferencePositions()
  IsPositionKnown("Filter1",   "step")
  IsPositionKnown("Filter2",   "step")
  IsPositionKnown("Filter3",   "step")
  IsPositionKnown("Camera",    "um")
  IsPositionKnown("Light",     "um")
  initialObjectivePosition = IsPositionKnown("Objective", "step")
  initialXPosition = IsPositionKnown("X", "um")
  initialYPosition = IsPositionKnown("Y", "um")
  initialZPosition = IsPositionKnown("Z", "um")
  -- The tray is the vision position
  if (initialXPosition > visionXPosition-xMotorResolution and initialXPosition < visionXPosition+xMotorResolution) and (initialYPosition > ejectyPositionClosed-yMotorResolution and initialYPosition < ejectyPositionClosed+yMotorResolution) and (initialZPosition > ejectzPosition-zMotorResolution and initialZPosition < ejectzPosition+zMotorResolution) then
    LoadingAreaLight(bottom)
    Goto("X", ejectxPosition,  "um", false)
    Goto("Lid", lidOpenPosition, "step", false)
    Wait("X")
    IsPositionKnown("X", "um")
    Goto("Y", ejectyPositionOpen,  "um", true)
    Wait("Lid")
    local position, status = GetPosition("Lid", "step")
    if(not string.match(status, "ok" )) then MessageBox(_("Lid blocked. Remove obstacle to proceed"), _("Error"), "ICON_ERROR", _("OK")) Home("Lid", true) Goto("Lid", lidOpenPosition, "step", true) end
  -- The tray is inside the instrument
  elseif (initialXPosition <= insideInstrumentxPosition+xMotorResolution) then
    Goto("Light", ejectLightPosition,  "um", true)
    IsPositionKnown("Light", "um")
    Goto("Y", ejectyPositionClosed,  "um", true)
    IsPositionKnown("Y", "um")
    if (initialXPosition >= xMaxPositionForObjectiveChange) and (initialObjectivePosition < objective4xPosition-2 or initialObjectivePosition > objective4xPosition+2) then
      Goto("X", xMaxPositionForObjectiveChange, "um", true)
      IsPositionKnown("X", "um")
    end
    Objective("4x", true)
    IsPositionKnown("Objective", "step")
    Goto("Z", ejectzPosition,  "um", true)
    IsPositionKnown("Z", "um")
    Goto("X", ejectxPosition,  "um", false)
    starttime()
    repeat
      currentPosition, status = GetPosition("X", "um")
      msTime = stoptime(notrace)
    until currentPosition > insideInstrumentxPosition+50000 or string.match(status, "ok" ) or msTime > 10000
    LoadingAreaLight(bottom)
    Goto("Lid", lidOpenPosition, "step", false)
    Wait("X")
    IsPositionKnown("X", "um")
    Goto("Y", ejectyPositionOpen,  "um", true)
  -- The tray is outside the instrument
  elseif (initialXPosition > ejectxPosition-xMotorResolution and initialXPosition < ejectxPosition+xMotorResolution) and (initialYPosition > ejectyPositionOpen-yMotorResolution and initialYPosition < ejectyPositionOpen+yMotorResolution) and (initialZPosition > ejectzPosition-zMotorResolution and initialZPosition < ejectzPosition+zMotorResolution) then
    Goto("Y", ejectyPositionClosed,  "um", true)
    Goto("X", visionXPosition, "um", false)
    Goto("Lid", lidClosedPosition, "step", false)
    Wait("X", "Lid")
    local position, status = GetPosition("Lid", "step")
    if(not string.match(status, "ok" )) then ftdi("/" .. lidMotorID .. "cal 0") Move("Lid", 80, "step", true) MessageBox(_("Lid blocked. Remove obstacle to proceed"), _("Error"), "ICON_ERROR", _("OK")) Home("Lid", true) Goto("Lid", lidClosedPosition, "step", true) end
    LoadingAreaLight(off)
    IsPositionKnown("X", "um")
  -- The tray is in an illigal position for performing eject/insert
  else
    Abort(_("Eject/Insert is not allowed from the current motor positions for X, Y and/or Z"))
  end
end
//[A4D084A5]