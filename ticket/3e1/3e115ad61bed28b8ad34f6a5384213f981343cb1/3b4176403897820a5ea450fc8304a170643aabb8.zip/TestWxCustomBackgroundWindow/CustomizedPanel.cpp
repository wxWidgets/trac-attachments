#ifndef _CUSTOMIZEDPANEL_
#	include "CustomizedPanel.h"
#endif // _CUSTOMIZEDPANEL_

CustomizedPanel::CustomizedPanel() : wxCustomBackgroundWindow<wxPanel>()
{
}

CustomizedPanel::~CustomizedPanel()
{
}
