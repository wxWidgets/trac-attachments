#ifndef _CUSTOMIZEDPANEL_
#define _CUSTOMIZEDPANEL_

#include <wx/wx.h>
#include <wx/panel.h>
#include <wx/custombgwin.h>

#ifndef __DECORATION__
#	ifdef NEED_EXPORT
#		define __DECORATION__ __declspec(dllexport)
#	elif NEED_IMPORT
#		define __DECORATION__ __declspec(dllimport)
#	endif // NEED_IMPORT
#endif // __DECORATION__

class __DECORATION__ CustomizedPanel :	public wxCustomBackgroundWindow<wxPanel>
{
public:
	CustomizedPanel();
	virtual ~CustomizedPanel();
};

#endif // _CUSTOMIZEDPANEL_