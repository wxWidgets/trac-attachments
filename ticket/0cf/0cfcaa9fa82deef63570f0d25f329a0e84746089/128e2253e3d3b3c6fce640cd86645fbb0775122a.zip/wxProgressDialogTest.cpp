/*
** wxProgressDialogTest
**
**  This program demonstrates a minor bug with the wxProgressDialog class.
**
**  . Build a "Debug" build.
**  . Run the program.
**  . Click on "Begin Test". A wxProgressDialog should appear.
**  . When the progress bar reaches the end (after two seconds), an assert
**    should fail. On my system with wxWidgets 2.4.2 I get the following
**    message:
**      .\msw\dialog.cpp(221): assert "wxAssertFailure" failed: DoShowModal()
**      called twice. Do you want to stop the program?
*/

#include "wx/wxprec.h"
#ifndef WX_PRECOMP
    #include "wx/wx.h"
#endif

#include "wx/progdlg.h"



class ProgressWindow : private wxProgressDialog, wxTimer
{
    int maxValue, value;

    // Notify is called on each timer tick.
    void Notify()
    {
        if( value < maxValue ) ++value;

        if( !wxProgressDialog::Update( value, "Processing..." ) )
        {
            Destroy();
        }
    }

  public:
    ProgressWindow( int maxValue_ = 10 )
      : wxProgressDialog( _("Progress Window"), "", maxValue_, NULL,
                          wxPD_APP_MODAL | wxPD_CAN_ABORT ),
        maxValue( maxValue_ ), value( 0 )
    {
        wxTimer::Start( 200 /*ms*/ );
    }

    // XXX function to handle "Close" button press is missing.
};


enum { MY_BUTTON = wxID_HIGHEST+1 };

class MainWindow : public wxFrame
{
 private:
    void myButtonHandler( wxCommandEvent &WXUNUSED(event) )
    {
        new ProgressWindow;
    }

  public:
    MainWindow()
      : wxFrame( NULL, -1, _T(""), wxDefaultPosition, wxSize(140,80) )
    {
        new wxButton( this, MY_BUTTON, "Begin Test" );
    }

    DECLARE_EVENT_TABLE()
};

BEGIN_EVENT_TABLE( MainWindow, wxFrame )
    EVT_BUTTON( MY_BUTTON, MainWindow::myButtonHandler )
END_EVENT_TABLE()


struct MyApp : public wxApp
{
    bool OnInit()
    {
        (new MainWindow)->Show( TRUE );
        return TRUE;
    }
};

IMPLEMENT_APP( MyApp )
