﻿#include "pch.h"
#include <UI/TestPage/TestPage.h>
#include <UI/TestAutoCompleter/TestAutoCompleter.h>
#include "MainFrame.h"

enum
{
    ID_TEXT_CTRL_TEST = wxID_HIGHEST + 1
};

BEGIN_EVENT_TABLE(MainFrame, wxFrame)
EVT_TEXT_ENTER(ID_TEXT_CTRL_TEST, MainFrame::OnTextCtrlTestEnter)
END_EVENT_TABLE()

MainFrame::MainFrame(wxWindow * parent,
                     wxWindowID id,
                     const wxString & title,
                     const wxPoint & pos,
                     const wxSize & size,
                     long style) : wxFrame(parent, id, title, pos, size, style)
{
    wxBoxSizer * pSizer_0 = new wxBoxSizer(wxVERTICAL);

    { // remarks
        const wchar_t * pRemarks =
            L"1. input \"aaa\" in the text ctrl, candidates are \"aaabbb\" and \"aaaaaa\"\r\n"
            L"2. input another \"a\", it becomes \"aaaa\", candidate is \"aaaaaa\"\r\n"
            L"3. delete last \"a\" using backspace, candidate is still \"aaaaaa\"\r\n"
            L"4. bug for \"bool wxTextEntry::AutoComplete(wxTextCompleter * completer)\"\r\n"
            L"5. bug not for \"bool wxTextEntry::AutoComplete(const wxArrayString & choices)\"\r\n";

        wxTextCtrl * pTextCtrl_remarks = new wxTextCtrl(this,
                                                        wxID_ANY,
                                                        pRemarks,
                                                        wxDefaultPosition,
                                                        wxSize(800, 400),
                                                        wxTE_MULTILINE);

        pSizer_0->Add(pTextCtrl_remarks);
    }


    {
        wxTextCtrl * pTextCtrl = new wxTextCtrl(this,
                                                ID_TEXT_CTRL_TEST,
                                                wxEmptyString,
                                                wxDefaultPosition,
                                                wxSize(300, 20),
                                                wxTE_PROCESS_ENTER);
        { // auto completion
            pTextCtrl->AutoComplete(new TestAutoCompleter());
        }
        pSizer_0->Add(pTextCtrl);
    }

    // ignore this
    //{
    //    wxNotebook * pNotebook = new wxNotebook(this, wxID_ANY);
    //    TestPage * pTestPage = new TestPage(pNotebook, wxID_ANY);
    //    pNotebook->AddPage(pTestPage, L"Test");
    //    pSizer_0->Add(pNotebook, 1, wxEXPAND);
    //}

    SetSizer(pSizer_0);
}

MainFrame::~MainFrame()
{
}

void MainFrame::OnTextCtrlTestEnter(wxCommandEvent & event)
{
    wxMessageBox(L"Enter is pressed in the text ctrl in main frame");
}