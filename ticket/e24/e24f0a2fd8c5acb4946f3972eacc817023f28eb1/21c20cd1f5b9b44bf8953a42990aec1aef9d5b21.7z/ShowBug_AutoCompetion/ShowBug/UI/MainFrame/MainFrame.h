#ifndef __MAINFRAME_H__
#define __MAINFRAME_H__

class MainFrame : public wxFrame
{
    DECLARE_EVENT_TABLE()
public:
    MainFrame(wxWindow * parent,
              wxWindowID id = wxID_ANY,
              const wxString & title = wxEmptyString,
              const wxPoint & pos = wxDefaultPosition,
              const wxSize & size = wxSize(800, 600),
              long style = wxDEFAULT_FRAME_STYLE);
    ~MainFrame();
private:
    void OnTextCtrlTestEnter(wxCommandEvent & event);
};

#endif //__MAINFRAME_H__
