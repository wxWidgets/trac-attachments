#pragma once

class TestPage : public wxPanel
{
    DECLARE_EVENT_TABLE()
public:
    TestPage(wxWindow * parent,
             wxWindowID winid = wxID_ANY,
             const wxPoint & pos = wxDefaultPosition,
             const wxSize & size = wxDefaultSize,
             long style = wxTAB_TRAVERSAL | wxNO_BORDER,
             const wxString & name = wxPanelNameStr);
private:
    void OnTextCtrlTestEnter(wxCommandEvent & event);
};

