#include <pch.h>
#include "TestPage.h"

enum
{
    ID_TEXT_CTRL_TEST = wxID_HIGHEST + 2
};

BEGIN_EVENT_TABLE(TestPage, wxPanel)
EVT_TEXT_ENTER(ID_TEXT_CTRL_TEST, TestPage::OnTextCtrlTestEnter)
END_EVENT_TABLE()

TestPage::TestPage(wxWindow * parent,
                   wxWindowID winid,
                   const wxPoint & pos,
                   const wxSize & size,
                   long style,
                   const wxString & name) :
    wxPanel(parent, winid, pos, size, style, name)
{
    wxBoxSizer * pSizer_0 = new wxBoxSizer(wxVERTICAL);
    {
        wxTextCtrl * pTextCtrl = new wxTextCtrl(this,
                                                ID_TEXT_CTRL_TEST,
                                                wxEmptyString,
                                                wxDefaultPosition,
                                                wxSize(300, 20),
                                                wxTE_PROCESS_ENTER);
        { // auto completion
            wxArrayString candidates;
            candidates.push_back(L"aaaaaa");
            candidates.push_back(L"aaabbb");
            candidates.push_back(L"bbbbbb");
            candidates.push_back(L"bbbccc");
            pTextCtrl->AutoComplete(candidates);
        }
        pSizer_0->Add(pTextCtrl);
    }

    SetSizer(pSizer_0);
}

void TestPage::OnTextCtrlTestEnter(wxCommandEvent & event)
{
    wxMessageBox(L"Enter is pressed in the text ctrl in page");
}