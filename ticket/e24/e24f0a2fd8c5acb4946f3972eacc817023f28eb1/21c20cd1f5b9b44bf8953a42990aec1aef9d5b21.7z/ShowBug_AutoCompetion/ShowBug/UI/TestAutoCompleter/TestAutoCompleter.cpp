#include "pch.h"
#include "TestAutoCompleter.h"

TestAutoCompleter::TestAutoCompleter() : wxTextCompleterSimple()
{
    _candidates.push_back(L"aaaaaa");
    _candidates.push_back(L"aaabbb");
    _candidates.push_back(L"bbbbbb");
    _candidates.push_back(L"bbbccc");

    _currentIndex = 0;
}

void TestAutoCompleter::GetCompletions(const wxString & prefix, wxArrayString & res)
{
    size_t count = _candidates.Count();
    for (size_t i = 0; i < count; ++i)
    {
        const wxString & candidate = _candidates[i];
        int n = candidate.Find(prefix);
        if (n == 0)
            res.push_back(candidate);
    }
}

//bool TestAutoCompleter::Start(const wxString & prefix)
//{
//    size_t count = _candidates.Count();
//    for (size_t i = 0; i < count; ++i)
//    {
//
//    }
//
//    return false;
//}
//
//wxString TestAutoCompleter::GetNext()
//{
//    if (_currentIndex < _candidates.GetCount())
//        return _candidates[_currentIndex++];
//    else
//        return wxEmptyString;
//}
