#pragma once

class TestAutoCompleter : public wxTextCompleterSimple
{
public:
    TestAutoCompleter();
public:
    virtual void GetCompletions(const wxString & prefix, wxArrayString & res) override;
private:
    wxArrayString _candidates;
    size_t _currentIndex;
};

