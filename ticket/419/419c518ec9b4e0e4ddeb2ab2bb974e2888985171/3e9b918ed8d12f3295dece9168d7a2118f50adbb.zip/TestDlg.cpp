/////////////////////////////////////////////////////////////////////////////
// Name:        TestDlg.cpp
// Purpose:     
// Author:      AleX
// Modified by: 
// Created:     09/03/2010 13:29:44
// RCS-ID:      
// Copyright:   
// Licence:     
/////////////////////////////////////////////////////////////////////////////

// For compilers that support precompilation, includes "wx/wx.h".
#include "wx/wxprec.h"

#ifdef __BORLANDC__
#pragma hdrstop
#endif

#ifndef WX_PRECOMP
#include "wx/wx.h"
#endif

////@begin includes
////@end includes

#include "TestDlg.h"
#include <wx/filename.h>

////@begin XPM images
////@end XPM images


/*
 * TestDlg type definition
 */

IMPLEMENT_DYNAMIC_CLASS( TestDlg, wxDialog )


/*
 * TestDlg event table definition
 */

BEGIN_EVENT_TABLE( TestDlg, wxDialog )

////@begin TestDlg event table entries
    EVT_BUTTON( ID_BUTTON, TestDlg::OnBUTTONClick )

////@end TestDlg event table entries

END_EVENT_TABLE()


/*
 * TestDlg constructors
 */

TestDlg::TestDlg()
{
    Init();
}

TestDlg::TestDlg( wxWindow* parent, wxWindowID id, const wxString& caption, const wxPoint& pos, const wxSize& size, long style )
{
    Init();
    Create(parent, id, caption, pos, size, style);
}


/*
 * TestDlg creator
 */

bool TestDlg::Create( wxWindow* parent, wxWindowID id, const wxString& caption, const wxPoint& pos, const wxSize& size, long style )
{
////@begin TestDlg creation
    SetExtraStyle(wxWS_EX_BLOCK_EVENTS);
    wxDialog::Create( parent, id, caption, pos, size, style );

    CreateControls();
    if (GetSizer())
    {
        GetSizer()->SetSizeHints(this);
    }
    Centre();
////@end TestDlg creation

    return true;
}


/*
 * TestDlg destructor
 */

TestDlg::~TestDlg()
{
////@begin TestDlg destruction
////@end TestDlg destruction
}


/*
 * Member initialisation
 */

void TestDlg::Init()
{
////@begin TestDlg member initialisation
    m_URL = NULL;
////@end TestDlg member initialisation
}


/*
 * Control creation for TestDlg
 */

void TestDlg::CreateControls()
{    
////@begin TestDlg content construction
    TestDlg* itemDialog1 = this;

    wxBoxSizer* itemBoxSizer2 = new wxBoxSizer(wxHORIZONTAL);
    itemDialog1->SetSizer(itemBoxSizer2);

    m_URL = new wxTextCtrl( itemDialog1, ID_TEXTCTRL, _("http://svn.wxwidgets.org/svn/wx/wxWidgets/trunk/docs/changes.txt"), wxDefaultPosition, wxSize(400, -1), 0 );
    itemBoxSizer2->Add(m_URL, 0, wxALIGN_CENTER_VERTICAL|wxALL, 5);

    wxButton* itemButton4 = new wxButton( itemDialog1, ID_BUTTON, _("Download"), wxDefaultPosition, wxDefaultSize, 0 );
    itemBoxSizer2->Add(itemButton4, 0, wxALIGN_CENTER_VERTICAL|wxALL, 5);

////@end TestDlg content construction
}


/*
 * Should we show tooltips?
 */

bool TestDlg::ShowToolTips()
{
    return true;
}

/*
 * wxEVT_COMMAND_BUTTON_CLICKED event handler for ID_BUTTON
 */

void TestDlg::OnBUTTONClick( wxCommandEvent& event )
{
	wxString fileName = wxFileName::CreateTempFileName(wxT("tst"));
	m_DownloadFile = new wxDownloadFile(this, m_URL->GetValue(), fileName, true);
	wxLogDebug(wxT("%s"), fileName.data());
}

