/////////////////////////////////////////////////////////////////////////////
// Name:        TestDlg.h
// Purpose:     
// Author:      AleX
// Modified by: 
// Created:     09/03/2010 13:29:44
// RCS-ID:      
// Copyright:   
// Licence:     
/////////////////////////////////////////////////////////////////////////////

#ifndef _TESTDLG_H_
#define _TESTDLG_H_


/*!
 * Includes
 */

////@begin includes
////@end includes
#include "DownloadFile.h"

/*!
 * Forward declarations
 */

////@begin forward declarations
////@end forward declarations

/*!
 * Control identifiers
 */

////@begin control identifiers
#define SYMBOL_TESTDLG_STYLE wxCAPTION|wxRESIZE_BORDER|wxSYSTEM_MENU|wxCLOSE_BOX|wxTAB_TRAVERSAL
#define SYMBOL_TESTDLG_TITLE _("TestDlg")
#define SYMBOL_TESTDLG_IDNAME ID_TESTDLG
#define SYMBOL_TESTDLG_SIZE wxSize(400, 300)
#define SYMBOL_TESTDLG_POSITION wxDefaultPosition
////@end control identifiers


/*!
 * TestDlg class declaration
 */

class TestDlg: public wxDialog
{    
    DECLARE_DYNAMIC_CLASS( TestDlg )
    DECLARE_EVENT_TABLE()

public:
    /// Constructors
    TestDlg();
    TestDlg( wxWindow* parent, wxWindowID id = SYMBOL_TESTDLG_IDNAME, const wxString& caption = SYMBOL_TESTDLG_TITLE, const wxPoint& pos = SYMBOL_TESTDLG_POSITION, const wxSize& size = SYMBOL_TESTDLG_SIZE, long style = SYMBOL_TESTDLG_STYLE );

    /// Creation
    bool Create( wxWindow* parent, wxWindowID id = SYMBOL_TESTDLG_IDNAME, const wxString& caption = SYMBOL_TESTDLG_TITLE, const wxPoint& pos = SYMBOL_TESTDLG_POSITION, const wxSize& size = SYMBOL_TESTDLG_SIZE, long style = SYMBOL_TESTDLG_STYLE );

    /// Destructor
    ~TestDlg();

    /// Initialises member variables
    void Init();

    /// Creates the controls and sizers
    void CreateControls();

////@begin TestDlg event handler declarations

    /// wxEVT_COMMAND_BUTTON_CLICKED event handler for ID_BUTTON
    void OnBUTTONClick( wxCommandEvent& event );

////@end TestDlg event handler declarations

////@begin TestDlg member function declarations

////@end TestDlg member function declarations

    /// Should we show tooltips?
    static bool ShowToolTips();

////@begin TestDlg member variables
    wxTextCtrl* m_URL;
    /// Control identifiers
    enum {
        ID_TESTDLG = 10000,
        ID_TEXTCTRL = 10002,
        ID_BUTTON = 10001
    };
////@end TestDlg member variables
	wxDownloadFile*	m_DownloadFile;
};

#endif
    // _TESTDLG_H_
