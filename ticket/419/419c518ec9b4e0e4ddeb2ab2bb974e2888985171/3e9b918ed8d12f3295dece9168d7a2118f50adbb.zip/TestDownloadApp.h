/////////////////////////////////////////////////////////////////////////////
// Name:        TestDownloadApp.h
// Purpose:     
// Author:      AleX
// Modified by: 
// Created:     09/03/2010 13:31:48
// RCS-ID:      
// Copyright:   
// Licence:     
/////////////////////////////////////////////////////////////////////////////

#ifndef _TESTDOWNLOADAPP_H_
#define _TESTDOWNLOADAPP_H_


/*!
 * Includes
 */

////@begin includes
#include "wx/image.h"
#include "TestDlg.h"
////@end includes

/*!
 * Forward declarations
 */

////@begin forward declarations
////@end forward declarations

/*!
 * Control identifiers
 */

////@begin control identifiers
////@end control identifiers

/*!
 * TestDownloadApp class declaration
 */

class TestDownloadApp: public wxApp
{    
    DECLARE_CLASS( TestDownloadApp )
    DECLARE_EVENT_TABLE()

public:
    /// Constructor
    TestDownloadApp();

    void Init();

    /// Initialises the application
    virtual bool OnInit();

    /// Called on exit
    virtual int OnExit();

////@begin TestDownloadApp event handler declarations
////@end TestDownloadApp event handler declarations

////@begin TestDownloadApp member function declarations
////@end TestDownloadApp member function declarations

////@begin TestDownloadApp member variables
////@end TestDownloadApp member variables
};

/*!
 * Application instance declaration 
 */

////@begin declare app
DECLARE_APP(TestDownloadApp)
////@end declare app

#endif
    // _TESTDOWNLOADAPP_H_
