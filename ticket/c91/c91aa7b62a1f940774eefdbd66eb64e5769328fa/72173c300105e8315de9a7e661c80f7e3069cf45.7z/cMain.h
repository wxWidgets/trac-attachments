#pragma once
#include "stdafx.h"

class cMain : public wxFrame
{
public:
	cMain();
	~cMain();

public:
	int C = 0;
	wxBoxSizer *hGridPanel	= nullptr;
	wxBoxSizer *vPanelCommon = nullptr;
	wxBoxSizer *vPanel[2] = { 0 };
	

	void update_panel() {
		auto start = high_resolution_clock::now();
		vPanelCommon->Show(vPanel[C]);
		for (int i = 0; i < 2; i++) {
			if (i == C) continue;
			vPanelCommon->Hide(vPanel[i]);
		}
		vPanelCommon->Layout();
		this->SetTitle((to_string(duration_cast<microseconds>(high_resolution_clock::now() - start).count()/1000)  + "ms"));
	}

	void add_building_table(wxFlexGridSizer* g, int rows, int cols) {
		for (int j = 0; j < rows; j++) {
			for (int i = 0; i < cols; i++) {
				wxToggleButton* b = new wxToggleButton( this, wxID_ANY, to_string(i), wxDefaultPosition, wxSize(45,45), 0 );
				g->Add(b); b->Bind(wxEVT_TOGGLEBUTTON, &cMain::OnToggleTable, this);
			}
		}
	}

	void OnToggleTable(wxCommandEvent &evt) {
		wxToggleButton* b = (wxToggleButton*)wxWindow::FindWindowById(evt.GetId());
			 if (C == 0) C = 1;
		else if (C == 1) C = 0;
		update_panel();
	}

	wxDECLARE_EVENT_TABLE();
};

