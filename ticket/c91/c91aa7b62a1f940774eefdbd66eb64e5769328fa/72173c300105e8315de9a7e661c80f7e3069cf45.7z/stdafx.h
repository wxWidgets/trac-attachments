#pragma once

#define _CRT_SECURE_NO_WARNINGS
///#define _USE_MATH_DEFINES

#include <string>
#include <chrono>
#include "wx/wx.h"
#include "wx/tglbtn.h"

using namespace std;
using namespace std::chrono;
