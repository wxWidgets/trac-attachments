#include "custom.h"
#include <wx/renderer.h>
#include <wx/generic/private/markuptext.h>

#if wxUSE_ACCESSIBILITY
#include <wx/private/markupparser.h>
#endif // wxUSE_ACCESSIBILITY

#include <wx/datectrl.h>

wxCustom::wxCustom()
{
    //ctor
}

wxCustom::~wxCustom()
{
    //dtor
}

namespace
{

wxTextCtrl *CreateEditorTextCtrl(wxWindow *parent, const wxRect& labelRect, const wxString& value)
{
    wxTextCtrl* ctrl = new wxTextCtrl(parent, wxID_ANY, value,
                                      labelRect.GetPosition(),
                                      labelRect.GetSize(),
                                      wxTE_PROCESS_ENTER);

    // Adjust size of wxTextCtrl editor to fit text, even if it means being
    // wider than the corresponding column (this is how Explorer behaves).
    const int fitting = ctrl->GetSizeFromTextSize(ctrl->GetTextExtent(ctrl->GetValue())).x;
    const int current = ctrl->GetSize().x;
    const int maxwidth = ctrl->GetParent()->GetSize().x - ctrl->GetPosition().x;

    // Adjust size so that it fits all content. Don't change anything if the
    // allocated space is already larger than needed and don't extend wxDVC's
    // boundaries.
    int width = wxMin(wxMax(current, fitting), maxwidth);

    if (width != current)
    {
        ctrl->SetSize(wxSize(width, -1));
    }

    // Select the text in the control an place the cursor at the end
    ctrl->SetInsertionPointEnd();
    ctrl->SelectAll();

    return ctrl;
}

} // Anonymous namespace

// ---------------------------------------------------------
// wxDataViewTextRendererEx
// ---------------------------------------------------------

wxIMPLEMENT_CLASS(wxDataViewTextRendererEx, wxDataViewRenderer);

wxDataViewTextRendererEx::wxDataViewTextRendererEx(const wxString &varianttype, wxDataViewCellMode mode, int align)
: wxDataViewRenderer(varianttype, mode, align)
{
#if wxUSE_MARKUP
    m_markupText = NULL;
#endif // wxUSE_MARKUP
}

wxDataViewTextRendererEx::~wxDataViewTextRendererEx()
{
#if wxUSE_MARKUP
    delete m_markupText;
#endif // wxUSE_MARKUP
}

#if wxUSE_MARKUP
void wxDataViewTextRendererEx::EnableMarkup(bool enable)
{
    if (enable)
    {
        if (!m_markupText)
        {
            m_markupText = new wxItemMarkupText(wxString());
        }
    }
    else if (m_markupText)
    {
        delete m_markupText;
        m_markupText = NULL;
    }
}
#endif // wxUSE_MARKUP

bool wxDataViewTextRendererEx::SetValue(const wxVariant &value)
{
    if (value.GetType() == wxT("double"))
    {
        m_text = wxString::Format(wxT("%.2f"), value.GetDouble());
    }
    else
    {
        m_text = value.GetString();
    }

#if wxUSE_MARKUP
    if (m_markupText)
    {
        m_markupText->SetMarkup(m_text);
    }
#endif // wxUSE_MARKUP

    return true;
}

bool wxDataViewTextRendererEx::GetValue(wxVariant& WXUNUSED(value)) const
{
    return false;
}

#if wxUSE_ACCESSIBILITY
wxString wxDataViewTextRendererEx::GetAccessibleDescription() const
{
#if wxUSE_MARKUP
    if (m_markupText)
    {
        return wxMarkupParser::Strip(m_text);
    }
#endif // wxUSE_MARKUP

    return m_text;
}
#endif // wxUSE_ACCESSIBILITY

bool wxDataViewTextRendererEx::HasEditorCtrl() const
{
    return true;
}

wxWindow* wxDataViewTextRendererEx::CreateEditorCtrl(wxWindow *parent, wxRect labelRect, const wxVariant &value)
{
    return CreateEditorTextCtrl(parent, labelRect, value);
}

bool wxDataViewTextRendererEx::GetValueFromEditorCtrl(wxWindow *editor, wxVariant &value)
{
    wxTextCtrl *text = (wxTextCtrl*) editor;
    value = text->GetValue();

    return true;
}

bool wxDataViewTextRendererEx::Render(wxRect rect, wxDC *dc, int state)
{
#if wxUSE_MARKUP
    if (m_markupText)
    {
        int flags = 0;

        if (state & wxDATAVIEW_CELL_SELECTED)
        {
            flags |= wxCONTROL_SELECTED;
        }

        m_markupText->Render(GetView(), *dc, rect, flags, GetEllipsizeMode());
    }
    else
#endif // wxUSE_MARKUP
    {
        RenderText(m_text, 0, rect, dc, state);
    }

    return true;
}

wxSize wxDataViewTextRendererEx::GetSize() const
{
    if (!m_text.empty())
    {
#if wxUSE_MARKUP
        if (m_markupText)
        {
            wxDataViewCtrl* const view = GetView();
            wxClientDC dc(view);

            if (GetAttr().HasFont())
            {
                dc.SetFont(GetAttr().GetEffectiveFont(view->GetFont()));
            }

            return m_markupText->Measure(dc);
        }
#endif // wxUSE_MARKUP

        return GetTextExtent(m_text);
    }
    else
    {
        return wxSize(wxDVC_DEFAULT_RENDERER_SIZE,wxDVC_DEFAULT_RENDERER_SIZE);
    }
}

// ---------------------------------------------------------
// wxDataViewDateTimeRenderer
// ---------------------------------------------------------

#if (defined(wxHAS_GENERIC_DATAVIEWCTRL) || defined(__WXGTK__)) && wxUSE_DATEPICKCTRL

wxDataViewDateTimeRenderer::wxDataViewDateTimeRenderer(const wxString& varianttype, wxDataViewCellMode mode, int align)
: wxDataViewCustomRenderer(varianttype, mode, align)
{
}

wxWindow * wxDataViewDateTimeRenderer::CreateEditorCtrl(wxWindow *parent, wxRect labelRect, const wxVariant& value)
{
    return new wxDatePickerCtrl(parent, wxID_ANY, value.GetDateTime(), labelRect.GetTopLeft(), labelRect.GetSize());
}

bool wxDataViewDateTimeRenderer::GetValueFromEditorCtrl(wxWindow *editor, wxVariant& value)
{
    wxDatePickerCtrl *ctrl = static_cast<wxDatePickerCtrl *>(editor);
    value = ctrl->GetValue();

    return true;
}

bool wxDataViewDateTimeRenderer::SetValue(const wxVariant& value)
{
    m_dateTime = value.GetDateTime();

    return true;
}

bool wxDataViewDateTimeRenderer::GetValue(wxVariant& value) const
{
    value = m_dateTime;

    return true;
}

#if wxUSE_ACCESSIBILITY
wxString wxDataViewDateTimeRenderer::GetAccessibleDescription() const
{
    return m_dateTime.IsValid() ? m_dateTime.FormatISOCombined(wxT(' ')) : wxT("");
}
#endif // wxUSE_ACCESSIBILITY

bool wxDataViewDateTimeRenderer::Render(wxRect cell, wxDC* dc, int state)
{
    wxVariant value;
    GetValue(value);
    wxString strTmp = m_dateTime.IsValid() ? m_dateTime.FormatISOCombined(wxT(' ')) : wxT("");
    RenderText(strTmp, 0, cell, dc, state);

    return true;
}

wxSize wxDataViewDateTimeRenderer::GetSize() const
{
    wxString strTmp = m_dateTime.IsValid() ? m_dateTime.FormatISOCombined(wxT(' ')) : wxT("");

    return GetTextExtent(strTmp);
}

#endif // (defined(wxHAS_GENERIC_DATAVIEWCTRL) || defined(__WXGTK__)) && wxUSE_DATEPICKCTRL
