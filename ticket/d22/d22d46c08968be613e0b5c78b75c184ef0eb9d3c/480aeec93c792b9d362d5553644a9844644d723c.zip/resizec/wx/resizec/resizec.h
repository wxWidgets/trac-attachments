/////////////////////////////////////////////////////////////////////////////
// Name:        wx/resizec.h
// Purpose:     wxResizeableControl base class and derived classes
//              for resizeable pictures
// Author:      Markus Greither
// Modified by:
// Created:     11/10/02
// RCS-ID:      $Id:     1.02 2003/04/30 magr
// Copyright:   (c) Markus Greither
// Licence:     wxWindows licence
/////////////////////////////////////////////////////////////////////////////

#ifndef __RESIZECONTROL__
#define __RESIZECONTROL__

#if defined(__WXMSW__) && wxUSE_METAFILE && wxUSE_ENH_METAFILE
#include "wx/metafile.h"
#endif

// ----------------------------------------------------------------------------
// wxResizeableControl
// ----------------------------------------------------------------------------

//! Class for zoomable windows
/*! Stores the original size of the window, so that
    Zooming is always computed from this data, and thus
    rounding errors are avoided.
*/
class wxZoomData
{
    //! Original window size
    wxSize m_orgSize;
    //! Original window pos
    wxPoint m_orgPos;
    //! Current window size
    wxRect m_currRect;
    //! Current zoom factor
    float m_zoom;
 public:
    //! Ctor
    wxZoomData() : m_zoom(1) {}
    //! Ctor
    wxZoomData(const wxSize &size,const wxPoint &pos)
     : m_orgSize(size),m_orgPos(pos),m_zoom(1) {}
    //! Set new zoom factor (changes size only)
    void SetZoomSize(wxWindow *Window,float zoom)
    {
        m_zoom = zoom;
        m_currRect = wxRect(m_currRect.GetPosition(),
                            wxSize(int(m_orgSize.x*m_zoom),
                                   int(m_orgSize.y*m_zoom)));
        Window->SetSize(m_currRect.GetSize());
    }
    //! Set new zoom factor (position and size)
    /*! curxoffs and curyoffs are the current offset values (e. g.
        scroll position) in absolute size (unzoomed)
        newxoffs and newyoffs are the new offset values
    */
    void SetZoomRect(wxWindow *Window,float zoom,
                     int curxoffs,int curyoffs,
                     int newxoffs,int newyoffs);
    //! Changes zoom factor without resizing the window
    void SetCurrentZoom(float zoom)
    {
        m_zoom = zoom;
        m_orgPos.x = int(m_orgPos.x/zoom);
        m_orgPos.y = int(m_orgPos.y/zoom);
        m_orgSize.x = int(m_orgSize.x/zoom);
        m_orgSize.y = int(m_orgSize.y/zoom);
    }
    //! Returns the current zoom factor
    float GetZoom() {return m_zoom;}
    //! Updates the original window size
    void SetSize(int width,int height);
    //! Updates the original window position
    void Move(int xpos,int ypos);
};

//! Class for moveable and resizable child windows
/*!
    This class draws resize rectangles on each side and corner when focused.
    Dragging these rectangles resizes the window.
    
    

    This class needs to be overloaded and Paint() defined with the graphics
    rendering.

    This would make a perfect abstract class, but the
    definition of wxDynamicCast() doesn't allow this.
*/
class wxResizeableControl : public wxWindow
{
 public:
    //! Flags for resize mode
    enum SizeMoveModes
    {
        Top = 0,
        Bottom,
        Left,
        Right,
        TopLeft,
        BottomLeft,
        TopRight,
        BottomRight,
        MoveWin,
        MaxMode
    };
    //! Size box dimension
    enum SizeRads
    {
        SizeXRad = 5,
        SizeYRad = 5
    };
    //! Ctor
    wxResizeableControl() : wxWindow() {}
    //! Ctor
    wxResizeableControl(wxWindow *AParent, int AnId,const wxPoint &pos,
                        const wxSize &size,long style = 0,
                        const wxString &name = wxPanelNameStr);
    //! Dtor
    virtual ~wxResizeableControl() {}
    //! Paint function for printing and screen output
    virtual void Paint(wxDC &dc,bool Printing,wxSize &size) {}
    //! Returns original size of control
    virtual wxSize GetOriginalSize() {return wxSize(-1,-1);}
    //! Returns with/height ratio
    /*! By overloading this function a fixed with/height
        ratio can be set. The default is to allow any ratio.
    */
    virtual float GetRatio()
    {
        return 0;
    }
    //! Returns the zoom data object
    wxZoomData &GetZoomData() {return m_zoomData;}
    //! Set new zoom factor and resize the window accordingly
    void SetZoom(float Zoom)
    {
        m_zoomData.SetZoomSize(this,Zoom);
    }
    //! Set new zoom factor, but do not resize/move
    void SetCurrentZoom(float Zoom)
    {
        m_zoomData.SetCurrentZoom(Zoom);
    }
    //! Draw a focus rectangle with the given coordinates
    inline void DrawFocusRect(wxDC &dc,wxRect rct)
    {
        FocusRectCoord(dc,rct.x,rct.y,rct.width,rct.height);
    }
    //! Make sure the zoom data gets updated when the window is moved
    void DoSetSize(int x, int y,int width, int height,
                   int sizeFlags = wxSIZE_AUTO)
    {
        if ((x != -1) || (y != -1))
            m_zoomData.Move(x,y);
        if ((width != -1) || (height != -1))
            m_zoomData.SetSize(width,height);
        wxWindow::DoSetSize(x,y,width,height,sizeFlags);
    }

// Event Handlers

    //! Responds to set cursor event
    /*! Sets the cursor accordingly for size rectangles (SIZE cursors)
        or main control area (move cursor)
    */ 
    void OnSetCursor(wxSetCursorEvent &event);
    //! Responds to left button up event
    /*! In case of a drag operation, moves the window to the new position.
        Mouse capture is released here.
    */
    void OnLButtonUp(wxMouseEvent &event);
    //! Responds to left button down event
    /*! Stores the current mouse position and determines the move mode
        If cursor is in size rectangles, according resize mode is selected
        If cursor is in main control arey, move mode is selected.
        The mouse is captured here.
    */
    void OnLButtonDown(wxMouseEvent &event);
    //! Responds to mouse move event
    /*! If mouse is captured and moved wider that the threshold,
        the resize or move rectangle for the new window size/position is drawn.
    */
    void OnMouseMove(wxMouseEvent &event);
    //! Kill focus event hides the size rectangles
    void OnKillFocus(wxFocusEvent &event);
    //! Set focus event draws size rectangles
    void OnSetFocus(wxFocusEvent &event);
    //! Cut event deletes the window
    /*! The parent window receives notification of deletion.
    */
    void OnEditCut(wxCommandEvent &ce);
    //! Key down event of WXK_DELETE deletes the window
    void OnKeyDown(wxKeyEvent &event);
    //! Reponds to size event
    /*! Updates the zoom data and sends parent window notification.
    */
    void OnSize(wxSizeEvent &event);
    //! Reponds to move event
    /*! Updates the zoom data and sends parent window notification.
    */
    void OnMove(wxMoveEvent &event);

 protected:
    //! Zoom data
    wxZoomData m_zoomData;
    //! Flag for mouse capture
    int m_capt;
    //! Cached mouse cursor positions
    wxPoint m_curpos,m_lastcurpos;
    //! Saved move mode from left button down
    int m_movemode;
    //! Flags for focus and move state
    bool m_hasfocus,m_moved;

    //! Draws a focus rectangle
    void FocusRectCoord(wxDC &DC,wxCoord x1,wxCoord y1,wxCoord w,wxCoord h);
    //! Returns window x size
    int GetSizeX(int Mode);
    //! Returns window y size
    int GetSizeY(int Mode);
    //! Draw ored rectangle of current new size (redraw to remove)
    void DrawMoveRect(wxPoint hp,int Mode,float Ratio = 0);
    //! Return new rectangle size, based on mouse position hp
    wxRect NewRect(wxPoint hp,int Mode,float Ratio = 0);
    //! Draw size boxes for resize
    void DrawSizeRect(wxDC &dc);
    //! Determine in which size box the pouse position hp is if any
    int PointInSizeRect(wxPoint hp);

    DECLARE_EVENT_TABLE()
    DECLARE_DYNAMIC_CLASS(wxResizeableControl)
};

// ----------------------------------------------------------------------------
// wxPictureControl
// ----------------------------------------------------------------------------

//! Abstract class for pictures
/*! This would make a perfect abstract class, but the
    definition of wxDynamicCast() doesn't allow this.
*/
class wxPictureControl : public wxResizeableControl
{
 public:
    //! Ctor
    wxPictureControl() : wxResizeableControl() {};
    //! Ctor
    wxPictureControl(wxWindow *AParent, int AnId,const wxPoint &pos,
                      const wxSize &size,long style = 0,
                      const wxString &name = wxPanelNameStr)
      : wxResizeableControl(AParent,AnId,pos,size,style,name) {}
    //! Return picture type string
    virtual const wxChar *GetPictureType() {return wxT("NOTYPE");}
    //! Return picture data size
    virtual long GetPictureSize() {return 0;}
    //! Copy picture data into pt
    virtual long GetPictureData(char *,long) {return 0;}

// Event handlers

    //! Reset original size if available
    void OnRevert(wxCommandEvent &event);
    //! Show context menu
    void OnRightDown(wxMouseEvent &event);
    //! Respond to system color palette change event
    void OnPaletteChanged(wxSysColourChangedEvent &event);
    //! Cut event
    void OnEditCut(wxCommandEvent &ce);
    //! Copy event
    virtual void OnEditCopy(wxCommandEvent &ce) {}
    //! Enable cut event
    void CeEditCut(wxUpdateUIEvent &ce)
    {
        ce.Enable(true);
    }
    //! Enable copy event
    void CeEditCopy(wxUpdateUIEvent &ce)
    {
        ce.Enable(true);
    }
    //! Reponds to size event
    void OnSize(wxSizeEvent &event);
    //! Responds to paint event
    void OnPaint(wxPaintEvent &event);

 protected:
    DECLARE_EVENT_TABLE()
    DECLARE_DYNAMIC_CLASS(wxPictureControl)
};


#if defined(__WXMSW__) && wxUSE_METAFILE && wxUSE_ENH_METAFILE
// ----------------------------------------------------------------------------
// wxMetafileControl
// ----------------------------------------------------------------------------

//! Class for EnhMetaFile pictures
class wxMetafileControl : public wxPictureControl
{
 public:
    //! Ctor
    wxMetafileControl() : wxPictureControl() {};
    //! Ctor
    wxMetafileControl(wxWindow *AParent, int AnId,WXHANDLE Meta,
                      const wxPoint &pos,
                      const wxSize &size,long style = 0,
                      const wxString &name = wxPanelNameStr);
    //! Ctor with raw picture data
    wxMetafileControl(wxWindow *AParent, int AnId,char *Data,int Size,
                      const wxPoint &pos,const wxSize &size,long style = 0,
                      const wxString &name = wxPanelNameStr);
    //! Dtor
    virtual ~wxMetafileControl();
    //! Return picture type name
    const wxChar *GetPictureType()
    {
        return wxT("EnhMetaFile");
    }
    //! Returns picture data size
    long GetPictureSize();
    //! Copy picture data into data
    long GetPictureData(char *data,long n);
    //! Return the picture in bitmap format
    const wxEnhMetaFile &GetMetafile() { return m_metafile; }
    //! Paint function for printing
    void Paint(wxDC &dc,bool Printing,wxSize &size);
    //! Returns with/height ratio
    float GetRatio();
    //! Returns original size of control
    wxSize GetOriginalSize();

// Event handlers

    //! Responds to copy event
    void OnEditCopy(wxCommandEvent &event);

 protected:
    //! Displayed metafile
    wxEnhMetaFile m_metafile;

    DECLARE_EVENT_TABLE()
    DECLARE_DYNAMIC_CLASS(wxMetafileControl)
};

#endif

// ----------------------------------------------------------------------------
// wxBitmapControl
// ----------------------------------------------------------------------------

//! Class for Bitmaps
class wxBitmapControl : public wxPictureControl
{
 public:
    //! Ctor
    wxBitmapControl() : wxPictureControl(),m_bitmap(0) {};
    //! Ctor
    wxBitmapControl(wxWindow *AParent, int AnId,const wxBitmap &Data,
                    const wxPoint &pos,
                    const wxSize &size,long style = 0,
                    const wxString &name = wxPanelNameStr);
#ifdef __WXMSW__
    //! Ctor with raw picture data in DIB format
    wxBitmapControl(wxWindow *AParent, int AnId,char *Data,int Size,
                    const wxPoint &pos,const wxSize &size,long style = 0,
                    const wxString &name = wxPanelNameStr);
#endif
    //! Dtor
    virtual ~wxBitmapControl();
#ifdef __WXMSW__
    //! Return picture type name
    const wxChar *GetPictureType()
    {
        return wxT("Dib");
    }
    //! Returns picture data size
    long GetPictureSize();
    //! Copy picture data into data
    long GetPictureData(char *data,long n);
#endif
    //! Return the picture in bitmap format
    const wxBitmap &GetBitmap() { return *m_bitmap; }
    //! Paint function for printing
    void Paint(wxDC &dc,bool Printing,wxSize &size);
    //! Returns width/height ratio
    float GetRatio();
    //! Returns original size of control
    wxSize GetOriginalSize();

// Event handlers

    //! Responds to copy event
    void OnEditCopy(wxCommandEvent &event);

 protected:
    wxBitmap *m_bitmap;

    DECLARE_EVENT_TABLE()
    DECLARE_DYNAMIC_CLASS(wxBitmapControl)
};

// ----------------------------------------------------------------------------
// wxResizeableControlCanvas
// ----------------------------------------------------------------------------

//! Parent window class for wxResizableControl child windows.
/*! This is a demo implementation that shows the typical operations
    that are necessary to support wxResizableControl child windows.
*/
class wxResizeableControlCanvas : public wxScrolledWindow
{
  public:
    //! Ctor
    wxResizeableControlCanvas() : wxScrolledWindow() {}
    //! Ctor
    wxResizeableControlCanvas(wxWindow *AParent, int AnId,
                              const wxPoint &pos = wxDefaultPosition,
                              const wxSize &size = wxDefaultSize,long style = 0,
                              const wxString &name = wxPanelNameStr)
      : wxScrolledWindow(AParent,AnId,pos,size,style,name) {}
    //! Recalculate the Scrollbars
    void UpdateScrollRange();
    //! Respond to child window notification
    void OnChildWindowChange(wxCommandEvent &) {UpdateScrollRange();}

    DECLARE_EVENT_TABLE()
};

// ----------------------------------------------------------------------------
// Events
// ----------------------------------------------------------------------------

//! Events from child windows
/*! These events notify the parent window of changes, so that it can
    update itself accordingly (recalculate Scrollbars, set document modified
    flag and so on).
*/
BEGIN_DECLARE_EVENT_TYPES()
    DECLARE_EVENT_TYPE(wxEVT_COMMAND_CHILD_MOVED, 520)
    DECLARE_EVENT_TYPE(wxEVT_COMMAND_CHILD_CLOSED, 521)
    DECLARE_EVENT_TYPE(wxEVT_COMMAND_CHILD_RESIZED, 522)
    DECLARE_EVENT_TYPE(wxEVT_COMMAND_CHILD_CREATED, 523)
END_DECLARE_EVENT_TYPES()

#define EVT_CHILD_MOVED(id, fn) \
    DECLARE_EVENT_TABLE_ENTRY( \
        wxEVT_COMMAND_CHILD_MOVED, id, -1, \
        (wxObjectEventFunction)(wxEventFunction)(wxCommandEventFunction) \
        & fn, \
        (wxObject *) NULL \
    ),

#define EVT_CHILD_CLOSED(id, fn) \
    DECLARE_EVENT_TABLE_ENTRY( \
        wxEVT_COMMAND_CHILD_CLOSED, id, -1, \
        (wxObjectEventFunction)(wxEventFunction)(wxCommandEventFunction) \
        & fn, \
        (wxObject *) NULL \
    ),

#define EVT_CHILD_RESIZED(id, fn) \
    DECLARE_EVENT_TABLE_ENTRY( \
        wxEVT_COMMAND_CHILD_RESIZED, id, -1, \
        (wxObjectEventFunction)(wxEventFunction)(wxCommandEventFunction) \
        & fn, \
        (wxObject *) NULL \
    ),

#define EVT_CHILD_CREATED(id, fn) \
    DECLARE_EVENT_TABLE_ENTRY( \
        wxEVT_COMMAND_CHILD_CREATED, id, -1, \
        (wxObjectEventFunction)(wxEventFunction)(wxCommandEventFunction) \
        & fn, \
        (wxObject *) NULL \
    ),

#endif // __RESIZECONTROL__

