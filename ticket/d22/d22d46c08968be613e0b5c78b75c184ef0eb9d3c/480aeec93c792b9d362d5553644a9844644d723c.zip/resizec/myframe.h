//-----------------------------------------------------------------------------
// Name:        myframe.h
// Purpose:     Resizeable controls sample: A derived frame, called MyFrame
// Author:      Markus Greither
// RCS-ID:      
// Copyright:   (c) Markus Greither
// Licence:     wxWindows licence
//-----------------------------------------------------------------------------

//-----------------------------------------------------------------------------
// Begin single inclusion of this .h file condition
//-----------------------------------------------------------------------------

#ifndef _MYFRAME_H_
#define _MYFRAME_H_

//-----------------------------------------------------------------------------
// GCC interface
//-----------------------------------------------------------------------------

#if defined(__GNUG__) && !defined(__APPLE__)
    #pragma interface "myframe.h"
#endif

//-----------------------------------------------------------------------------
// Headers
//-----------------------------------------------------------------------------

#include "wx/frame.h"

//-----------------------------------------------------------------------------
// Class definition: MyFrame
//-----------------------------------------------------------------------------

// Define a new frame type: this is going to be our main frame
class MyFrame : public wxFrame
{
    wxWindow *m_resizecanvas;
public:

    // ctor(s)
    MyFrame(wxWindow *wnd = (wxWindow *)NULL);

private:

    // Event handlers (these functions should _not_ be virtual)
    void OnAbout(wxCommandEvent& event);
    void OnQuit(wxCommandEvent& event);
    void OnPaste(wxCommandEvent& event);
    void OnPasteEnable(wxUpdateUIEvent& event);
    void OnCopy(wxCommandEvent& event);
    void OnCopyEnable(wxUpdateUIEvent& event);
    void OnPrint(wxCommandEvent& event);

    // Any class wishing to process wxWindows events must use this macro
    DECLARE_EVENT_TABLE()

};

//-----------------------------------------------------------------------------
// End single inclusion of this .h file condition
//-----------------------------------------------------------------------------

#endif  // _MYFRAME_H_
