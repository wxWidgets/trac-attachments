/*
 * wxMyApp.h
 *
 *  Created on: Nov 5, 2013
 *      Author: gregor
 */

#ifndef WXMYAPP_H_
#define WXMYAPP_H_

#include "wx/wx.h"
#include "cRenderForm.h"



class wxMyApp : public wxApp
{
public:

	virtual bool OnInit();

	int FilterEvent(wxEvent &event);

};





#endif /* WXMYAPP_H_ */
