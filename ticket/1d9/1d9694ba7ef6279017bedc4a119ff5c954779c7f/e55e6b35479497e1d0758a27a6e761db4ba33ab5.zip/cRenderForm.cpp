/*
 * cRenderForm.cpp
 *
 *  Created on: Nov 4, 2013
 *      Author: gregor
 */

///////////////////////////////////////////////////////////////////////////
// C++ code generated with wxFormBuilder (version Dec 21 2009)
// http://www.wxformbuilder.org/
//
// PLEASE DO "NOT" EDIT THIS FILE!
///////////////////////////////////////////////////////////////////////////

#include "cRenderForm.h"

#include "wx/wx.h"
#include "wx/menu.h"
#include <boost/thread/thread.hpp>
#include <limits>
#include <omp.h>
#include <pthread.h>





///////////////////////////////////////////////////////////////////////////
BEGIN_EVENT_TABLE(cRenderForm, wxFrame)
EVT_MENU(ID_QUIT, cRenderForm::OnQuit)
EVT_MENU(ID_ABOUT, cRenderForm::OnAbout)
EVT_MENU(ID_INIT_ENGINE, cRenderForm::OnInitEngine)


//EVT_PAINT(cRenderForm::paintEvent)
	EVT_MOUSE_EVENTS(cRenderForm::OnMouseEvent)
	EVT_KEY_DOWN(cRenderForm::OnKeyDown)
	EVT_KEY_UP(cRenderForm::OnKeyUp)
	EVT_LEFT_UP(cRenderForm::OnMouseLeftClick)
	EVT_RIGHT_UP(cRenderForm::OnMouseRightClick)
	EVT_MIDDLE_UP(cRenderForm::OnMouseMiddleClick)

END_EVENT_TABLE()



void cRenderForm::InputThreadCall()
{

}

void cRenderForm::ThreadCall()
{

#pragma omp parallel num_threads(3)
{

}

}


void *call_thread(void *form)
{
    cRenderForm *rform = (cRenderForm*)form;

    rform->ThreadCall();
}

void *callInputThread_thread(void *form)
{
    cRenderForm *rform = (cRenderForm*)form;

    rform->InputThreadCall();
}

void cRenderForm::OnInitEngine(wxCommandEvent &event)
{


 int irt1 = 0;
 SetFocus();

}


void cRenderForm::SetupView()
{

 //   wxGetKeyState()

}




void cRenderForm::OnMouseLeftClick(wxMouseEvent &event)
{


}
void cRenderForm::OnMouseRightClick(wxMouseEvent &event)
{

}
void cRenderForm::OnMouseMiddleClick(wxMouseEvent &event)
{

}


void cRenderForm::OnMouseEvent(wxMouseEvent &event)
{

}

void cRenderForm::OnKeyUp(wxKeyEvent &event)
{

}

void cRenderForm::OnKeyDown(wxKeyEvent &event)
{

}


cRenderForm::cRenderForm()
{
    SetFocus();
}

cRenderForm::cRenderForm(const wxString & title, const wxPoint & pos, const wxSize &size) :
		wxFrame(NULL, -1, title, pos , size)
{
	wxMenu *menuFile = new wxMenu;


	menuFile->AppendSeparator();
	menuFile->Append( ID_ABOUT, _("&About..."));
	menuFile->AppendSeparator();
	menuFile->Append( ID_QUIT, _("E&xit") );

    wxMenu *menuTools = new wxMenu;


    menuTools->Append( ID_INIT_ENGINE, _("Init Engine"));


	wxMenuBar *menuBar = new wxMenuBar;
	menuBar->Append(menuFile, _("&File") );
	menuBar->Append(menuTools, _("&Tools"));

	SetMenuBar(menuBar);

	CreateStatusBar();

	SetStatusText( _("Welcome to A") );


}

wxString cRenderForm::getOpenDialogLoadDefaultFileDir()
{
	return wxT("");
}

wxString cRenderForm::getOpenDialogLoadDefaultFile()
{
	return wxT("");
}

wxString cRenderForm::getOpenDialogSaveAsDefaultFileDir()
{
	return wxT("");
}

wxString cRenderForm::getOpenDialogSaveAsDefaultFile()
{
	return wxT("");
}

wxString cRenderForm::getOpenDialogFileFilter()
{
	return wxT("*.*");
}





cRenderForm::~cRenderForm()
{


}

void cRenderForm::OnQuit(wxCommandEvent &event)
{
	Close(true);
}

void cRenderForm::OnAbout(wxCommandEvent &event)
{
wxStopWatch sw1;
	wxStopWatch sw2;


    //// testing for cashline size



}

void cRenderForm::paintEvent()
{

}








