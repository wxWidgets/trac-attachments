/*
 * cRenderForm.h
 *
 *  Created on: Nov 4, 2013
 *      Author: gregor
 */

#ifndef CRENDERFORM_H_
#define CRENDERFORM_H_


#include <boost/shared_ptr.hpp>
#include <wx/dcbuffer.h>
#include <wx/defs.h>
#include <wx/gdicmn.h>
#include <wx/string.h>
#include <wx/wx.h>
#include <wx/wxchar.h>
//#include "../C3DNodes/cSpatialRefNode3D.h"
#include <omp.h>




///////////////////////////////////////////////////////////////////////////

enum {
	ID_QUIT = 1,
	ID_ABOUT,
	ID_MOUSE_MOVE,
	ID_MOUSE_CLICK,
	ID_KEY_DOWN,
	ID_KEY_UP,
	ID_SAVEAS,
	ID_SAVE,
	ID_INIT_ALL,
	ID_INIT_CAM_1,
	ID_INIT_CAM_2,
	ID_INIT_CAM_3,
	ID_INIT_CAM_4,
	ID_INIT_ENGINE,
	ID_CREATE_NEW_DATANODE,
};


///////////////////////////////////////////////////////////////////////////////
/// Class MyFrame1
///////////////////////////////////////////////////////////////////////////////
class cRenderForm : public wxFrame
{
	protected:
		wxButton* m_button1;
	public:


    omp_lock_t m_ompmousekeyboardsync;
    omp_lock_t m_ompdonotwritelocallock;


		//map<int, int> m_pressedkeys;

		// the class is operating on multible processors,
		// in order to get the right handler to the right camera,
		// call this function
		void TriggerUserInputChoice(int id, std::vector<int> *transTable);

        cRenderForm();
		cRenderForm( wxWindow* parent, wxWindowID id = wxID_ANY, const wxString& title = wxEmptyString, const wxPoint& pos = wxDefaultPosition, const wxSize& size = wxSize( 500,300 ) );
		~cRenderForm();

		cRenderForm(const wxString & title, const wxPoint & pos, const wxSize &size);

		void initProcMap();
		void ThreadCall();
		void InputThreadCall();
        void StopThread();

		wxString getDefaultFileDir();

		wxString getOpenDialogLoadDefaultFileDir();
		wxString getOpenDialogLoadDefaultFile();
		wxString getOpenDialogSaveAsDefaultFileDir();
		wxString getOpenDialogSaveAsDefaultFile();
		wxString getOpenDialogFileFilter();

		void OnQuit(wxCommandEvent & event);
		void OnAbout(wxCommandEvent & event);

        void OnInitEngine(wxCommandEvent &event);

		void OnMouseLeftClick(wxMouseEvent &event);
		void OnMouseRightClick(wxMouseEvent &event);
		void OnMouseMiddleClick(wxMouseEvent &event);
		void OnMouseEvent(wxMouseEvent &event);

		void OnKeyDown(wxKeyEvent &event);
		void OnKeyUp(wxKeyEvent &event);

		void OnOpenFile(wxCommandEvent & event);
		void OnSaveFile(wxCommandEvent & event);

		void paintEvent();

		DECLARE_EVENT_TABLE();

		/// this stuff should later move into a macro

	public:


		void SetupView();

};


#endif /* CRENDERFORM_H_ */

