/*
 * wxMyApp.cpp
 *
 *  Created on: Nov 5, 2013
 *      Author: gregor
 */
#include "wxMyApp.h"
#include "cRenderForm.h"




IMPLEMENT_APP(wxMyApp)

bool wxMyApp::OnInit()
{

	cRenderForm *frame = new cRenderForm( _("Welcome to h") , wxPoint(50,50), wxSize(600,600));

	frame->Show(true);
	SetTopWindow(frame);

	return true;

}

int wxMyApp::FilterEvent(wxEvent &event)
{
    if( event.GetEventType() == wxEVT_KEY_DOWN )
    {
        int test = 0;
//        int state = wxGetKeyState(wxKeyCode('h'));
//        //wxObject *code = event.GetEventObject();
//        if(state != 0)
//        {
//            int dfsf = 9;
//        }
//        int test = 0;

    }

    if(event.GetEventType() == wxEVT_LEFT_DOWN)
    {

        int test = 0;
    }
}


