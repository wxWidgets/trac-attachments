/*
 * cRenderForm.cpp
 *
 *  Created on: Nov 4, 2013
 *      Author: gregor
 */

///////////////////////////////////////////////////////////////////////////
// C++ code generated with wxFormBuilder (version Dec 21 2009)
// http://www.wxformbuilder.org/
//
// PLEASE DO "NOT" EDIT THIS FILE!
///////////////////////////////////////////////////////////////////////////

#include "cRenderForm.h"

#include "wx/wx.h"
#include "wx/menu.h"
#include <boost/thread/thread.hpp>
#include <limits>
#include <omp.h>
#include <pthread.h>





///////////////////////////////////////////////////////////////////////////
BEGIN_EVENT_TABLE(cRenderForm, wxFrame)
EVT_MENU(ID_QUIT, cRenderForm::OnQuit)
EVT_MENU(ID_ABOUT, cRenderForm::OnAbout)
EVT_MENU(ID_INIT_ENGINE, cRenderForm::OnInitEngine)


//EVT_PAINT(cRenderForm::paintEvent)
	EVT_MOUSE_EVENTS(cRenderForm::OnMouseEvent)
	EVT_KEY_DOWN(cRenderForm::OnKeyDown)
	EVT_KEY_UP(cRenderForm::OnKeyUp)
	EVT_LEFT_UP(cRenderForm::OnMouseLeftClick)
	EVT_RIGHT_UP(cRenderForm::OnMouseRightClick)
	EVT_MIDDLE_UP(cRenderForm::OnMouseMiddleClick)

END_EVENT_TABLE()



void cRenderForm::InputThreadCall()
{

}

void cRenderForm::RenderingThreadCall()
{

#pragma omp parallel num_threads(3)
{

}

}


void *callRendering_thread(void *form)
{
    cRenderForm *rform = (cRenderForm*)form;

    rform->RenderingThreadCall();
}

void *callInputThread_thread(void *form)
{
    cRenderForm *rform = (cRenderForm*)form;

    rform->InputThreadCall();
}

void cRenderForm::StopRenderingThread()
{
    if(!m_renderthreadruns)
        return;

    omp_set_lock(&m_omprendersync);
        m_stoprenderingthread = true;
    omp_unset_lock(&m_omprendersync);

    omp_set_lock(&m_omprendersync);
        m_renderthreadruns = false;
    omp_unset_lock(&m_omprendersync);

    pthread_join(m_renderthread, NULL);

    omp_destroy_lock(&m_omprendersync);

}

void cRenderForm::OnInitEngine(wxCommandEvent &event)
{


 int irt1 = 0;
 irt1 = pthread_create(&m_renderthread, NULL,  callRendering_thread, (void*)this);

 int irt2 = pthread_create(&m_renderthread, NULL, callInputThread_thread, (void*)this);

 m_renderthreadruns = true;

 SetFocus();

}


void cRenderForm::SetupView()
{

 //   wxGetKeyState()

}




void cRenderForm::OnMouseLeftClick(wxMouseEvent &event)
{
omp_set_lock(&m_ompmousekeyboardsync);
	m_mouse.x_click[wxMOUSE_BTN_LEFT] = event.m_x;
	m_mouse.y_click[wxMOUSE_BTN_LEFT] = event.m_y;
omp_unset_lock(&m_ompmousekeyboardsync);


}
void cRenderForm::OnMouseRightClick(wxMouseEvent &event)
{
omp_set_lock(&m_ompmousekeyboardsync);
	m_mouse.x_click[wxMOUSE_BTN_RIGHT] = event.m_x;
	m_mouse.y_click[wxMOUSE_BTN_RIGHT] = event.m_y;
omp_unset_lock(&m_ompmousekeyboardsync);
}
void cRenderForm::OnMouseMiddleClick(wxMouseEvent &event)
{

}


void cRenderForm::OnMouseEvent(wxMouseEvent &event)
{

}

void cRenderForm::OnKeyUp(wxKeyEvent &event)
{

}

void cRenderForm::OnKeyDown(wxKeyEvent &event)
{

}


cRenderForm::cRenderForm()
{
    m_renderthreadruns = false;
    SetFocus();
}

cRenderForm::cRenderForm(const wxString & title, const wxPoint & pos, const wxSize &size) :
		wxFrame(NULL, -1, title, pos , size)
{
	wxMenu *menuFile = new wxMenu;


	menuFile->AppendSeparator();
	menuFile->Append( ID_ABOUT, _("&About..."));
	menuFile->AppendSeparator();
	menuFile->Append( ID_QUIT, _("E&xit") );

    wxMenu *menuTools = new wxMenu;


    menuTools->Append( ID_INIT_ENGINE, _("Init Engine"));


	wxMenuBar *menuBar = new wxMenuBar;
	menuBar->Append(menuFile, _("&File") );
	menuBar->Append(menuTools, _("&Tools"));

	SetMenuBar(menuBar);

	CreateStatusBar();

	SetStatusText( _("Welcome to A") );


}

wxString cRenderForm::getOpenDialogLoadDefaultFileDir()
{
	return wxT("");
}

wxString cRenderForm::getOpenDialogLoadDefaultFile()
{
	return wxT("");
}

wxString cRenderForm::getOpenDialogSaveAsDefaultFileDir()
{
	return wxT("");
}

wxString cRenderForm::getOpenDialogSaveAsDefaultFile()
{
	return wxT("");
}

wxString cRenderForm::getOpenDialogFileFilter()
{
	return wxT("*.*");
}





cRenderForm::~cRenderForm()
{
    if(m_renderthreadruns)
    {
        StopRenderingThread();
        m_renderthreadruns = false;
    }

}

void cRenderForm::OnQuit(wxCommandEvent &event)
{
	Close(true);
}

void cRenderForm::OnAbout(wxCommandEvent &event)
{
wxStopWatch sw1;
	wxStopWatch sw2;


    //// testing for cashline size



}

void cRenderForm::paintEvent()
{

}








