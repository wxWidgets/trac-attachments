/*
 * cRenderForm.h
 *
 *  Created on: Nov 4, 2013
 *      Author: gregor
 */

#ifndef CRENDERFORM_H_
#define CRENDERFORM_H_


#include <boost/shared_ptr.hpp>
#include <wx/dcbuffer.h>
#include <wx/defs.h>
#include <wx/gdicmn.h>
#include <wx/string.h>
#include <wx/wx.h>
#include <wx/wxchar.h>
//#include "../C3DNodes/cSpatialRefNode3D.h"
#include <omp.h>




///////////////////////////////////////////////////////////////////////////

enum {
	ID_QUIT = 1,
	ID_ABOUT,
	ID_MOUSE_MOVE,
	ID_MOUSE_CLICK,
	ID_KEY_DOWN,
	ID_KEY_UP,
	ID_SAVEAS,
	ID_SAVE,
	ID_INIT_ALL,
	ID_INIT_CAM_1,
	ID_INIT_CAM_2,
	ID_INIT_CAM_3,
	ID_INIT_CAM_4,
	ID_INIT_ENGINE,
	ID_CREATE_NEW_DATANODE,
};

enum USER_CHOICE {
	CHOICE_ABORT = 0,
	CHOICE_REPEAT = 1,
	CHOICE_CONTINUE_TO_CREATE = 2,
	CHOICE_MOVE_BACK = 3,
	CHOICE_MOVE_FORWARD = 4,
	CHOICE_MOVE_LEFT = 5,
	CHOICE_MOVE_RIGHT = 6,
	CHOICE_ROTATE_SIDE_PLUS = 7,
	CHOICE_ROTATE_SIDE_MINUS = 8,
	CHOICE_ROTATE_UP_PLUS = 9,
	CHOICE_ROTATE_UP_MINUS = 10,
	CHOICE_ROTATE_ROOL_PLUS = 11,
	CHOICE_ROTATE_ROOL_MINUS = 12,
};

struct mouse {

	int timestamp;

	int x;
	int y;

	/// coordinates left, right, middle
	int x_click[4];
	int y_click[4];

	// click counter left, right, middle
	int counter[4];
};

struct keyboard {

	/// the key hit counter
	int counter[1024];

};

///////////////////////////////////////////////////////////////////////////////
/// Class MyFrame1
///////////////////////////////////////////////////////////////////////////////
class cRenderForm : public wxFrame
{
	protected:
		wxButton* m_button1;
	public:


    bool      m_renderthreadruns;
    bool      m_stoprenderingthread;
    omp_lock_t m_omprendersync;
    omp_lock_t m_ompmousekeyboardsync;

    omp_lock_t m_ompdonotwritelocallock;

	pthread_t m_renderthread;

	/// create paint thread

		// mapping between keys and mouse input and processes
    /// keyidcode; down, pressed
    std::vector<int> m_key2choices[1024];
    std::vector<int> m_mouse2choices[5];
    int m_choice_map_counter[1024];



		mouse m_mouse;
		keyboard m_keyboard;
		//map<int, int> m_pressedkeys;

		// the class is operating on multible processors,
		// in order to get the right handler to the right camera,
		// call this function
		void TriggerUserInputChoice(int id, std::vector<int> *transTable);

        cRenderForm();
		cRenderForm( wxWindow* parent, wxWindowID id = wxID_ANY, const wxString& title = wxEmptyString, const wxPoint& pos = wxDefaultPosition, const wxSize& size = wxSize( 500,300 ) );
		~cRenderForm();

		cRenderForm(const wxString & title, const wxPoint & pos, const wxSize &size);

		void initProcMap();
		void RenderingThreadCall();
		void InputThreadCall();
        void StopRenderingThread();

		wxString getDefaultFileDir();

		wxString getOpenDialogLoadDefaultFileDir();
		wxString getOpenDialogLoadDefaultFile();
		wxString getOpenDialogSaveAsDefaultFileDir();
		wxString getOpenDialogSaveAsDefaultFile();
		wxString getOpenDialogFileFilter();

		void OnQuit(wxCommandEvent & event);
		void OnAbout(wxCommandEvent & event);

        void OnInitEngine(wxCommandEvent &event);

		void OnMouseLeftClick(wxMouseEvent &event);
		void OnMouseRightClick(wxMouseEvent &event);
		void OnMouseMiddleClick(wxMouseEvent &event);
		void OnMouseEvent(wxMouseEvent &event);

		void OnKeyDown(wxKeyEvent &event);
		void OnKeyUp(wxKeyEvent &event);

		void OnOpenFile(wxCommandEvent & event);
		void OnSaveFile(wxCommandEvent & event);

		void paintEvent();

		DECLARE_EVENT_TABLE();

		/// this stuff should later move into a macro

	public:


		void SetupView();

};


#endif /* CRENDERFORM_H_ */

