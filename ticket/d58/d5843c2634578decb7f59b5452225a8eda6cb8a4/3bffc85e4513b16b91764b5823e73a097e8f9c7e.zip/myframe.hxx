#ifndef __MYRFRAME_HXX__
#define __MYFRAME_HXX__

#include "wx/docmdi.h"

class MyFrame : public wxDocMDIParentFrame {
private:

public:
  MyFrame(void);
  virtual ~MyFrame(void);

private:
  DECLARE_EVENT_TABLE()
};

extern wxDocMDIParentFrame* theApplicationFrame;

#endif
