#include "wx/wx.h"
#include "wx/xrc/xmlres.h"

#include "myframe.hxx"
#include "myview.hxx"
#include "mydocument.hxx"

BEGIN_EVENT_TABLE(MyFrame, wxDocMDIParentFrame)
END_EVENT_TABLE()

wxDocMDIParentFrame* theApplicationFrame = NULL;

MyFrame::MyFrame(void)
 : wxDocMDIParentFrame()
{
  wxXmlResource::Get()->LoadFrame(this, NULL, wxT("myframe"));

  SetIcon(wxICON(appicon));
  SetMenuBar(wxXmlResource::Get()->LoadMenuBar(wxT("main_menu")));

  CreateStatusBar(1);

  m_docManager = new wxDocManager();

  wxString homedir = wxGetHomeDir();

  new wxDocTemplate(m_docManager, "My Files", "*", homedir, "xxx", "My Document", "My View", CLASSINFO(MyDocument), CLASSINFO(MyView));

  theApplicationFrame = this;
}

MyFrame::~MyFrame(void)
{
//  delete m_docManager;
}
