#ifndef __MYVIEW_HXX__
#define __MYVIEW_HXX__

#include "wx/docmdi.h"

class MyView : public wxView {
DECLARE_DYNAMIC_CLASS(MyView)

private:

public:
  MyView(void);
  virtual ~MyView(void);

  void OnDraw(wxDC* dc);

  virtual bool OnCreate(wxDocument* doc, long flags);

private:
  DECLARE_EVENT_TABLE()
};

#endif
