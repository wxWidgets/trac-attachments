#ifndef __MYAPP_HXX__
#define __MYAPP_HXX__

#include "wx/wx.h"

class wxDocManager;

class MyApp : public wxApp {
  DECLARE_DYNAMIC_CLASS(MyApp)

private:

public:
  MyApp(void);
  virtual ~MyApp(void);

  virtual bool OnInit(void);

  DECLARE_EVENT_TABLE()
};

#endif
