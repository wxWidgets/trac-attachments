#ifndef __MYDOCUMENT_HXX__
#define __MYDOCUMENT_HXX__

#include "wx/docmdi.h"

class MyDocument : public wxDocument {
DECLARE_DYNAMIC_CLASS(MyDocument)

private:

public:
  MyDocument(void);
  virtual ~MyDocument(void);

  virtual bool OnCreate(const wxString& path, long flags);

private:
  DECLARE_EVENT_TABLE()
};

#endif
