#if defined(_WIN32) && defined(_DEBUG)
#include <crtdbg.h>
#endif

#include "wx/xrc/xmlres.h"

#include "myapp.hxx"
#include "myframe.hxx"
#include "myview.hxx"
#include "mydocument.hxx"

IMPLEMENT_APP(MyApp)
IMPLEMENT_DYNAMIC_CLASS(MyApp, wxApp)
BEGIN_EVENT_TABLE(MyApp, wxApp)
END_EVENT_TABLE()

MyApp::MyApp(void)
{
#if defined(_WIN32) && defined(_DEBUG)
  int DbgFlag = _CrtSetDbgFlag(_CRTDBG_REPORT_FLAG);
  //DbgFlag |= _CRTDBG_CHECK_ALWAYS_DF;
  DbgFlag |= _CRTDBG_LEAK_CHECK_DF;
  _CrtSetDbgFlag(DbgFlag);
#endif
}

MyApp::~MyApp(void)
{
}

bool
MyApp::OnInit(void)
{
  // initialisiere die XML-Ressourcen
  wxXmlResource::Get()->InitAllHandlers();

  // lade Ressourcen
  if (!wxXmlResource::Get()->Load(wxT("my.xrc"))) {
    wxMessageBox("Ressource File could not be loaded!");
  }

  wxFrame* frame = new MyFrame();
  SetTopWindow(frame);
  frame->Show(true);

  return true;
}
