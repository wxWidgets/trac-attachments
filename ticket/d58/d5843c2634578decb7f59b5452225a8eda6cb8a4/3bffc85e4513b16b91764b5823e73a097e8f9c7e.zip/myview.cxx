#include "wx/wx.h"
#include "wx/docmdi.h"

#include "myframe.hxx"
#include "myview.hxx"

IMPLEMENT_DYNAMIC_CLASS(MyView, wxView)
BEGIN_EVENT_TABLE(MyView, wxView)
END_EVENT_TABLE()

MyView::MyView(void)
{
}

MyView::~MyView(void)
{
}

void
MyView::OnDraw(wxDC* dc)
{
}

bool
MyView::OnCreate(wxDocument* doc, long flags)
{
  wxFrame* frame = new wxDocMDIChildFrame(GetDocument(), this, theApplicationFrame, -1, "Symbol View");

//  wxXmlResource::Get()->LoadFrame(frame, NULL, wxT("symbolframe"));

  SetFrame(frame);
  frame->Show(true);

  return true;
}
