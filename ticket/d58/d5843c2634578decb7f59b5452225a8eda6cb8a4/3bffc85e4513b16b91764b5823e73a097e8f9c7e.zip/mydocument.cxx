#include "wx/wx.h"

#include "mydocument.hxx"

IMPLEMENT_DYNAMIC_CLASS(MyDocument, wxDocument)
BEGIN_EVENT_TABLE(MyDocument, wxDocument)
END_EVENT_TABLE()

MyDocument::MyDocument(void)
{
}

MyDocument::~MyDocument(void)
{
}

bool
MyDocument::OnCreate(const wxString& path, long flags)
{
  return wxDocument::OnCreate(path, flags);
}
