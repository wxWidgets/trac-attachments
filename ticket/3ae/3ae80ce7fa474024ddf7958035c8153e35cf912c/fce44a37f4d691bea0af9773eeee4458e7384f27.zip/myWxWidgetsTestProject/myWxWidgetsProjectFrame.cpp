
#ifdef __GNUG__
#pragma implementation
#pragma interface
#endif

#include "myWxWidgetsProjectFrame.h"

BEGIN_EVENT_TABLE(myWxWidgetsProjectFrame, wxFrame)
  EVT_BUTTON  (MY_BUTTON_ID, myWxWidgetsProjectFrame::OnButton)
END_EVENT_TABLE()


myWxWidgetsProjectFrame::myWxWidgetsProjectFrame(wxFrame *frame, const wxString& title, const wxPoint& pos, const wxSize& size):
  wxFrame(frame, -1, title, pos, size)
{
		

	mp_button = new wxButton(this, MY_BUTTON_ID, "Click me", wxDefaultPosition, wxSize(60, 10));


	CreateStatusBar();
	SetStatusText( "Welcome to wxWindows!" );

}


void myWxWidgetsProjectFrame::OnButton()
//void myWxWidgetsProjectFrame::OnButton(wxCommandEvent & event)
{
	wxMessageBox("click", "test", wxOK | wxICON_INFORMATION);
}