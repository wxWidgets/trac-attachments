
#ifdef __GNUG__
#pragma implementation
#pragma interface
#endif

#include "myWxWidgetsProjectFrame.h"
#include "myWxWidgetsProjectApp.h"
                            
IMPLEMENT_APP(myWxWidgetsProjectApp)
