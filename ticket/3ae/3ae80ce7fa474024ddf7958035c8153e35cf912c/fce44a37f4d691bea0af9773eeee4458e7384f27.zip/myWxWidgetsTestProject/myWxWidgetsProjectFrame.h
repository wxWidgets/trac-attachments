
#ifndef __myWxWidgetsProjectFrame__INCLUDED__
#define __myWxWidgetsProjectFrame__INCLUDED__


#ifdef __GNUG__
#pragma implementation
#pragma interface
#endif

#include "wx/wxprec.h"

#ifndef  WX_PRECOMP
  #include "wx/wx.h"
#endif //precompiled headers

#include <stdlib.h>
#include <math.h>
#include <time.h>
      

enum {
	MY_BUTTON_ID = 89797
};

class myWxWidgetsProjectFrame: public wxFrame
{
public:
	myWxWidgetsProjectFrame(wxFrame *frame, const wxString& title, const wxPoint& pos, const wxSize& size);

protected:
	DECLARE_EVENT_TABLE()
private:
	void OnButton();
	//void OnButton(wxCommandEvent & event);
	wxButton * mp_button;
};


#endif // __myWxWidgetsProjectFrame__INCLUDED__



