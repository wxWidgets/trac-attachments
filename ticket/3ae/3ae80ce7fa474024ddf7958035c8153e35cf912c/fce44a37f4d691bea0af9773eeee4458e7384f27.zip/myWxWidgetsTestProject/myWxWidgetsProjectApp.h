
#ifndef __myWxWidgetsProjectApp__INCLUDED__
#define __myWxWidgetsProjectApp__INCLUDED__


#ifdef __GNUG__
#pragma implementation
#pragma interface
#endif

#include "wx/wxprec.h"

#ifndef  WX_PRECOMP
  #include "wx/wx.h"
#endif //precompiled headers

#include <stdlib.h>
#include <math.h>
#include <time.h>

enum
{
	myWxWidgetsProjectApp_ID_Quit = 1,
	myWxWidgetsProjectApp_ID_About,
};


class myWxWidgetsProjectApp: public wxApp
{ 
public:
	bool OnInit();
	wxMenuBar *mp_menuBar;
};

#endif // __myWxWidgetsProjectApp__INCLUDED__

