
#ifdef __GNUG__
#pragma implementation
#pragma interface
#endif

#include "myWxWidgetsProjectApp.h"
#include "myWxWidgetsProjectFrame.h"


bool myWxWidgetsProjectApp::OnInit()
{
  // Create the main frame window
  myWxWidgetsProjectFrame *frame = new myWxWidgetsProjectFrame(NULL, _T("myWxWidgetsProject"), wxPoint(0, 0), wxSize(640, 480));

  frame->Show(TRUE);

  return TRUE;
}

