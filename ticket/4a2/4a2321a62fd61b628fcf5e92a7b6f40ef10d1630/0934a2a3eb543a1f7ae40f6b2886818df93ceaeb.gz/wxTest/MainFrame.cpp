#include "MainFrame.h"
#include <wx/aboutdlg.h>

#include <fmt/format.h>

MainFrame::MainFrame(wxWindow* parent)
    : MainFrameBaseClass(parent), counter{0}
{
}

MainFrame::~MainFrame()
{
}

void MainFrame::OnExit(wxCommandEvent& event)
{
    wxUnusedVar(event);
    Close();
}

void MainFrame::OnAbout(wxCommandEvent& event)
{
    wxUnusedVar(event);
    wxAboutDialogInfo info;
    info.SetCopyright(_("My MainFrame"));
    info.SetLicence(_("GPL v2 or later"));
    info.SetDescription(_("Short description goes here"));
    ::wxAboutBox(info);
}

void MainFrame::OnBtn_incButtonClicked(wxCommandEvent& event)
{
    wxUnusedVar(event);
    
    counter++;
    txt_Counter->SetLabelText(fmt::format("{}", counter));
}
