/////////////////////////////////////////////////////////////////////////////
// Name:        src/common/zipfname.cpp
// Purpose:     Character encoding for file names in ZIP headers
// Author:      Ralf Sesseler
// Created:     2013-04-28
// RCS-ID:      $Id$
// Copyright:   (c) 2013 Ralf Sesseler
// Licence:     wxWindows licence
/////////////////////////////////////////////////////////////////////////////

#include <wx/wx.h>
#include "zipfname.h"

// table to convert oem 2 unicode
const wchar_t wxMBConvZip::s_oem2uni[129] = {0,0xC7,0xFC,0xE9,0xE2,0xE4,0xE0,0xE5,0xE7,0xEA,0xEB,0xE8,0xEF,0xEE,0xEC,0xC4,0xC5,0xC9,0xE6,0xC6,0xF4,0xF6,0xF2,0xFB,0xF9,0xFF,0xD6,0xDC,0xF8,0xA3,0xD8,0xD7,0x192,0xE1,0xED,0xF3,0xFA,0xF1,0xD1,0xAA,0xBA,0xBF,0xAE,0xAC,0xBD,0xBC,0xA1,0xAB,0xBB,0,0,0,0,0,0xC1,0xC2,0xC0,0xA9,0,0,0,0,0xA2,0xA5,0,0,0,0,0,0,0,0xE3,0xC3,0,0,0,0,0,0,0,0xA4,0xF0,0xD0,0xCA,0xCB,0xC8,0x131,0xCD,0xCE,0xCF,0,0,0,0,0xA6,0xCC,0,0xD3,0xDF,0xD4,0xD2,0xF5,0xD5,0xB5,0xFE,0xDE,0xDA,0xDB,0xD9,0xFD,0xDD,0xAF,0xB4,0xAD,0xB1,0,0xBE,0xB6,0xA7,0xF7,0xB8,0xB0,0xA8,0xB7,0xB9,0xB3,0xB2,0,0};
// table to convert unicode 2 oem
const unsigned char wxMBConvZip::s_uni2oem[95] = {0xAD,0xBD,0x9C,0xCF,0xBE,0xDD,0xF5,0xF9,0xB8,0xA6,0xAE,0xAA,0xF0,0xA9,0xEE,0xF8,0xF1,0xFD,0xFC,0xEF,0xE6,0xF4,0xFA,0xF7,0xFB,0xA7,0xAF,0xAC,0xAB,0xF3,0xA8,0xB7,0xB5,0xB6,0xC7,0x8E,0x8F,0x92,0x80,0xD4,0x90,0xD2,0xD3,0xDE,0xD6,0xD7,0xD8,0xD1,0xA5,0xE3,0xE0,0xE2,0xE5,0x99,0x9E,0x9D,0xEB,0xE9,0xEA,0x9A,0xED,0xE8,0xE1,0x85,0xA0,0x83,0xC6,0x84,0x86,0x91,0x87,0x8A,0x82,0x88,0x89,0x8D,0xA1,0x8C,0x8B,0xD0,0xA4,0x95,0xA2,0x93,0xE4,0x94,0xF6,0x9B,0x97,0xA3,0x96,0x81,0xEC,0xE7,0x98};

wchar_t wxMBConvZip::oem2uni(char c)
{
    unsigned char u = c;
    // control characters
    if (u <= 0x1F) return 0;
    // ASCII characters
    if (u <= 0x7E) return u;
    // use table
    return s_oem2uni[u-0x7F];
}

char wxMBConvZip::uni2oem(wchar_t w)
{
    // control characters
    if (w <= 0x001F) return 0;
    // ASCII characters
    if (w <= 0x007E) return (char)w;
    // not oem characters
    if (w <= 0x00A0) return 0;
    // some special characters
    switch (w)
    {
    case 0x0131: return (char)0xD5;
    case 0x0192: return (char)0x9F;
    }
    // not oem characters or graphics
    if (w >= 0x00FF) return 0;
    // use table
    return (char)s_uni2oem[w-0x00A1];
}

bool wxMBConvZip::testUnicode(wchar_t *src, size_t srcLen)
{
    while (srcLen)
        if (!*src || uni2oem(*src)) {src++; srcLen--;}
        else return true;
    return false;
}

size_t wxMBConvZip::FromWChar(int& zipFlags, char *dst, size_t dstLen, const wchar_t *src, size_t srcLen)
{
    // calculate len if null terminated
    if (srcLen == wxNO_LEN) srcLen = wcslen(src)+1;
    // check if requires unicode
    wchar_t *s = (wchar_t*)src;
    if (testUnicode(s, srcLen))
    {
        zipFlags |= wxZIP_UTF8_FILENAME;
        // utf-8 conversion
        return wxConvUTF8.FromWChar(dst, dstLen, src, srcLen);
    }
    zipFlags &= ~wxZIP_UTF8_FILENAME;

    // return required length
    if (!dst) return srcLen;
    // test for required length
    if (dstLen < srcLen) return wxCONV_FAILED;

    // convert to oem
    size_t len = srcLen;
    while (len--) *(dst++) = uni2oem(*(s++));
    return srcLen;
}

size_t wxMBConvZip::ToWChar(int zipFlags, wchar_t *dst, size_t dstLen, const char *src, size_t srcLen)
{
    // calculate len if null terminated
    if (srcLen == wxNO_LEN) srcLen = strlen(src)+1;
    // utf-8 conversion
    if (zipFlags & wxZIP_UTF8_FILENAME) return wxConvUTF8.ToWChar(dst, dstLen, src, srcLen);

    // return required length
    if (!dst) return srcLen;
    // test for required length
    if (dstLen < srcLen) return wxCONV_FAILED;

    // convert from oem
    char *s = (char*)src;
    size_t len = srcLen;
    while (len--) *(dst++) = oem2uni(*(s++));
    return srcLen;
}

size_t wxMBConvZip::FromOem(char *dst, const char *src, size_t len)
{
    if (len == wxNO_LEN) len = strlen(src)+1;
    char *s = (char*)src;
    size_t l = len;
    while (l--)
    {
        wchar_t w = oem2uni(*s);
        if (w > 255) return wxCONV_FAILED;
        if (!w && *s) return wxCONV_FAILED;
        *(dst++) = w;
        s++;
    }
    return len;
}

size_t wxMBConvZip::ToOem(char *dst, const char *src, size_t len)
{
    if (len == wxNO_LEN) len = strlen(src)+1;
    char *s = (char*)src;
    size_t l = len;
    while (l--)
    {
        *dst = uni2oem((unsigned char)*s);
        if (!*dst && *s) return wxCONV_FAILED;
        dst++;
        s++;
    }
    return len;
}
