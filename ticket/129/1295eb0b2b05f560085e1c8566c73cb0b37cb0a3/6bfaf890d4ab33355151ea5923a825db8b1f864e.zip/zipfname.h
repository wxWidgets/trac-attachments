/////////////////////////////////////////////////////////////////////////////
// Name:        src/common/zipfname.h
// Purpose:     Character encoding for file names in ZIP headers
// Author:      Ralf Sesseler
// Created:     2013-04-28
// RCS-ID:      $Id$
// Copyright:   (c) 2013 Ralf Sesseler
// Licence:     wxWindows licence
/////////////////////////////////////////////////////////////////////////////

// should be included in wxZipFlags
#define wxZIP_UTF8_FILENAME 0x0800

// conversion between wide character and file name for ZIP entries
// uses OEM characters if possible, otherwise UTF-8 and sets the according zip flag
// FromWChar and ToWChar work as in wxMBConv, but take the zip flags as first argument in addition
// also has conversion between ANSI and OEM for non-Unicode builds

class wxMBConvZip
{
public:
    // unicode conversion
    size_t FromWChar(int& zipFlags, char *dst, size_t dstLen, const wchar_t *src, size_t srcLen=wxNO_LEN);
    size_t ToWChar(int zipFlags, wchar_t *dst, size_t dstLen, const char *src, size_t srcLen=wxNO_LEN);

    // latin-1 (ANSI) conversion
    size_t FromOem(char *dst, const char *src, size_t len=wxNO_LEN);
    size_t ToOem(char *dst, const char *src, size_t len=wxNO_LEN);

private:
    static const wchar_t s_oem2uni[129];
    static const unsigned char s_uni2oem[95];

    wchar_t oem2uni(char);
    char uni2oem(wchar_t);
    bool testUnicode(wchar_t*, size_t);
};
