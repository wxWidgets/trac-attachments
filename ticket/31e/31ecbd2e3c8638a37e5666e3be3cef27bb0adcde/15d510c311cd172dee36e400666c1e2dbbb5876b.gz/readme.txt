
All of the patches are for wxWidgets-2.8.4.

wxwidget-2.8.4-02pos6.diff
This patch let the wx project to be compiled smoothly under the PODS 1.2 with sdk-6.1.

wxwidget-2.8.4-03pos5-proj.diff
This patch add the support for SDK-5r4 of the PODS 1.2. Most of the source will be compiled smoothly, but some will compain that the code is out of range because the Palm compiler has the limitation of 64K bytes.

wxwidget-2.8.4-04pos5-split.diff
This patch split some files into more small files and let all of the source code to be *ONLY* compiled but *NOT* to be linked. Because the code have to split to sections which every section is 64K bytes long, we have to add the "__attribute__ ((section ("code1")))" for each function. That is the next job we want to resolve.
