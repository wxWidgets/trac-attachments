#pragma once

#include <wx/wx.h>
#include <wx/msw/ole/activex.h>
#include <mshtml.h>

class CTestClientFrame : public wxFrame
{
public:
	CTestClientFrame(IWebBrowser2* pIWebBrowser2);
	virtual ~CTestClientFrame();

protected:
	DECLARE_EVENT_TABLE()
	void OnActiveXEvent(wxActiveXEvent& evt);

	IWebBrowser2* m_pIWebBrowser2;
};
