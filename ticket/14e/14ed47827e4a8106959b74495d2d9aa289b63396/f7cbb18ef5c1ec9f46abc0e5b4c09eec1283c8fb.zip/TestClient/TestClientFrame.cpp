#include "TestClientFrame.h"
#include <mshtml.h>

#define DISPID_DOCUMENTCOMPLETE     259   // new document goes ReadyState_Complete

BEGIN_EVENT_TABLE(CTestClientFrame, wxFrame)
    EVT_ACTIVEX(wxID_ANY, CTestClientFrame::OnActiveXEvent)
END_EVENT_TABLE()


CTestClientFrame::CTestClientFrame(IWebBrowser2* pIWebBrowser2) : wxFrame(NULL, wxID_ANY, wxT("wxWidgets IE sample"))
{
	m_pIWebBrowser2 = pIWebBrowser2;

	wxPanel* const panel = new wxPanel(this);
    wxSizer* const sizerPanel = new wxBoxSizer(wxVERTICAL);
    wxWindow* const activeXParent = new wxWindow(panel, wxID_ANY, wxDefaultPosition, wxSize(300, 200));

	new wxActiveXContainer(activeXParent, IID_IWebBrowser2, m_pIWebBrowser2);

    sizerPanel->Add(activeXParent, wxSizerFlags(1).Expand().Border());

    Show();

	BSTR bstrURL = wxConvertStringToOle(wxT("http://www.google.com"));

	m_pIWebBrowser2->Navigate(bstrURL, NULL, NULL, NULL, NULL);

}

CTestClientFrame::~CTestClientFrame(void)
{
	if ( m_pIWebBrowser2 )
	{
		m_pIWebBrowser2->Release();
	}
}


void CTestClientFrame::OnActiveXEvent(wxActiveXEvent& evt)
{
	switch ( evt.GetDispatchId() )
	{
	case DISPID_DOCUMENTCOMPLETE:
		break;
	}
	evt.Skip();
}

