#pragma once

#include "TestClientFrame.h"

class CTestClientApp : public wxApp
{
public:
	CTestClientApp(void);
	virtual ~CTestClientApp(void);
	bool OnInit();


protected:
	CTestClientFrame* Frame;

    //wxDECLARE_NO_COPY_CLASS(CTestClientApp);

};
