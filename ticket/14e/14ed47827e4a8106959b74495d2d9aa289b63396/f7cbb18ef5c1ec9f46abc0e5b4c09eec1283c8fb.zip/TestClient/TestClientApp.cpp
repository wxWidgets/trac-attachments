#include "TestClientApp.h"

IMPLEMENT_APP(CTestClientApp)

CTestClientApp::CTestClientApp()
{
	Frame = NULL;
}

CTestClientApp::~CTestClientApp()
{
	
}

bool CTestClientApp::OnInit()
{
	if ( !wxApp::OnInit() )
	{
	    return false;
	}
	IWebBrowser2* pIWebBrowser2 = NULL;
	// create browser interface
	if ( S_OK != ::CoCreateInstance(CLSID_WebBrowser, NULL, CLSCTX_INPROC_SERVER, IID_IWebBrowser2, (void**)&pIWebBrowser2) )
	{
		return false;
	}

	Frame = new CTestClientFrame(pIWebBrowser2);
	return true;
}