import sys,os

from baseframe.app import TheApp


if __name__ == '__main__':

    app = TheApp(redirect = False)
    app.MainLoop()
