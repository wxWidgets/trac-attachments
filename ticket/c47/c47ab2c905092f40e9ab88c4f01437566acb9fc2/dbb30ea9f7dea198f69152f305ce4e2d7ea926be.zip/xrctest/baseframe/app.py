import sys,os
import wx
import wx.xrc

from baseframe.basexmlhandler import BaseXmlHandler
from baseframe.mainframe import MainFrame

class TheApp(wx.App):
    def OnInit(self):
        # prepare xml res
        self.RESFILE = "baseframe/test1.xrc"
        self.res = wx.xrc.XmlResource(self.RESFILE)
        self.res.InsertHandler(BaseXmlHandler(MainFrame))

        # load mainframe
        self.frame = self.res.LoadObject(None, "MAINFRAME", "wxFrame")
        #self.frame.postCreate()

        self.SetTopWindow(self.frame)

        self.frame.Show()
        self.frame.Raise()

        return True
