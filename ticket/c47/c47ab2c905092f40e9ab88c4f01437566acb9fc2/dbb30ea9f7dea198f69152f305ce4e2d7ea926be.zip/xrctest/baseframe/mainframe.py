import os,sys
import wx

class MainFrame(wx.Frame):
    def __init__(self, parent = None):
        wx.Frame.__init__(self,parent)
