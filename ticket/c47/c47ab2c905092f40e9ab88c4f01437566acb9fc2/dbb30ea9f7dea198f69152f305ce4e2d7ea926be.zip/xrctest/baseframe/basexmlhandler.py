import  wx.xrc

class BaseXmlHandler(wx.xrc.XmlResourceHandler):
    def __init__(self, cls):
        wx.xrc.XmlResourceHandler.__init__(self)

        self.cls = cls

        self.AddWindowStyles()

    def CanHandle(self, node):
        result = self.IsOfClass(node, self.cls.__name__)
        return result

    def DoCreateResource(self):
        assert self.GetInstance() is None

        parent = self.GetParentAsWindow()
        ctrl = self.cls(parent)

        self.SetupWindow(ctrl)
        self.CreateChildren(ctrl)

        return ctrl
