#ifndef test_wxwidgets_h
#define test_wxwidgets_h

#include <map>
class MyFrame : public wxFrame
{
	public:
		MyFrame();

		virtual bool Create(wxWindow *parent,wxWindowID id, const wxString& strTitle, const wxPoint& pos = wxDefaultPosition, const wxSize& size = wxDefaultSize, long style = wxDEFAULT_FRAME_STYLE,const wxString& name = wxFrameNameStr);
		virtual ~MyFrame();

	private:
		DECLARE_DYNAMIC_CLASS(MyFrame);

};

class MyApp : public wxApp
{
private:
	public:
		MyApp();
		virtual ~MyApp();

		 bool OnInit();

	private:
		DECLARE_DYNAMIC_CLASS(MyApp);
};
#endif

