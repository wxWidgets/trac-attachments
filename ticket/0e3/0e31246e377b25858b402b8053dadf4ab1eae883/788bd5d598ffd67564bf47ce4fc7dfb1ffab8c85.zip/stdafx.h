// stdafx.h : Includedatei f�r Standardsystem-Includedateien,
// oder projektspezifische Includedateien, die h�ufig benutzt, aber
// in unregelm��igen Abst�nden ge�ndert werden.
//

#pragma once


#define WIN32_LEAN_AND_MEAN		// Selten verwendete Teile der Windows-Header nicht einbinden
// Windows-Headerdateien:

#include <windows.h>
#include <winsock.h>
// C RunTime-Headerdateien
#include <stdlib.h>
#include <malloc.h>
#include <memory.h>
#include <tchar.h>


/*using namespace System;
using namespace System::Windows::Forms;
using namespace CrystalDecisions::Shared;
using namespace CrystalDecisions::CrystalReports::Engine;
using namespace CrystalDecisions::Windows::Forms;*/

#include "wx/wx.h"

#include "wx/xrc/xmlres.h"
#include "wx/xrc/xh_dlg.h"
#include "wx/xml/xml.h"
#include "wx/splitter.h"
#include <wx/gbsizer.h>
#include <wx/display.h>

//#include "cio.hpp"

// TODO: Verweisen Sie hier auf zus�tzliche Header, die Ihr Programm erfordert
