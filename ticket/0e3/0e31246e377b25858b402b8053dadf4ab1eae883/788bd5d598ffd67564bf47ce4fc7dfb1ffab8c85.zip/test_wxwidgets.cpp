// test_wxwidgets.cpp : Definiert den Einstiegspunkt f�r die Anwendung.
//

#include "stdafx.h"
#include <fstream>
#include <iostream>
#include "test_wxwidgets.h"
#ifdef ENABLE_DEBUG_MALLOC
#define new NEW_DEBUG
#endif

//////////////////////////////////////////
/// APPLICATION

IMPLEMENT_APP(MyApp);

IMPLEMENT_DYNAMIC_CLASS(MyApp,wxApp);

MyApp::MyApp()
{
}

MyApp::~MyApp()
{

}

bool
MyApp::OnInit()
{   
	MyFrame *frame = new MyFrame();	
	if (frame->Create(NULL,wxID_ANY,"Test Application"))
	{
		SetTopWindow(frame);
		return true;
	}
	return false;
}




/////////////////////////////////////
/// Frame
/////////////////////////////////////
IMPLEMENT_DYNAMIC_CLASS(MyFrame,wxFrame);

MyFrame::MyFrame()
{
}

MyFrame::~MyFrame()
{
}

bool 
MyFrame::Create(wxWindow *parent,wxWindowID id, const wxString& strTitle, const wxPoint& pos , const wxSize& size, long style ,const wxString& name )
{
	wxString strFileName = "test.xrc";

	if (wxFrame::Create(parent,id,strTitle,pos,size,style,name))
	{
		wxBoxSizer *boxSizer = new wxBoxSizer(wxVERTICAL);

		wxArrayString pList;
		pList.Add(wxString("EUR"));
		pList.Add(wxString("GBp"));
		pList.Add(wxString("ZAR"));
		pList.Add(wxString("GBP"));
		pList.Add(wxString("USD"));

		wxPanel *newPan = new wxPanel(this,wxID_ANY);
		wxBoxSizer* panSizer = new wxBoxSizer(wxVERTICAL);
		wxComboBox *combo = new wxComboBox(newPan,wxID_ANY,wxEmptyString,wxDefaultPosition,wxDefaultSize,pList);
		panSizer->Add(combo,1,wxEXPAND);
		newPan->SetSizer(panSizer);
		boxSizer->Add(newPan,1,wxEXPAND);
		combo->SetMinSize(wxSize(400,-1));
		SetSizerAndFit(boxSizer);
		Show();
		return true;
	}
	return false;
}
