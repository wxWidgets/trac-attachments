#ifndef MAIN_H
#define MAIN_H

#include <wx/wx.h>
#include <wx/grid.h>
#include <wx/notebook.h>

class MyFrame;
class MyApp : public wxApp
{
public:
    virtual bool OnInit(void) wxOVERRIDE;
    void CreateFrame(void);
    MyFrame* m_frame;
};

wxDECLARE_APP(MyApp);

class MyFrame: public wxFrame
{
public:

    MyFrame(wxFrame *frame, const wxString& appTitle);
    void Bar(void);

    void OnButton(wxCommandEvent& );

    wxButton* m_pushToTriggerBugBtn;
    wxNotebook* m_nb;
    wxPanel* m_viewPanel;
    wxTextCtrl* m_text;
    wxPanel* m_editPanel;
    wxGrid* m_grid;

    DECLARE_EVENT_TABLE()
};
#endif // MAIN_H
