#include "Frame.hpp"
#include <cinttypes>
#include <map>
wxIMPLEMENT_APP(MyApp);
bool MyApp::OnInit(void)
{
    if (!wxApp::OnInit())
    {
        return false;
    }
    CreateFrame();
    return true;
}
void MyApp::CreateFrame(void)
{
    m_frame = new MyFrame(0L, wxT("test"));
    m_frame->Show();
}
#define ID_SHOW_BUG wxID_HIGHEST

BEGIN_EVENT_TABLE(MyFrame, wxFrame)
    EVT_BUTTON(ID_SHOW_BUG, MyFrame::OnButton)
END_EVENT_TABLE()

MyFrame::MyFrame(wxFrame *frame, const wxString& appTitle)
    : wxFrame(frame, -1, appTitle)
{
    wxBoxSizer * const topSizerV = new wxBoxSizer(wxVERTICAL);

    m_pushToTriggerBugBtn = new wxButton(this, ID_SHOW_BUG, "Show bug");
    topSizerV->Add(m_pushToTriggerBugBtn);

    m_nb = new wxNotebook(this, wxID_ANY, wxDefaultPosition, wxDefaultSize, 0);

    m_viewPanel = new wxPanel(m_nb);
    wxBoxSizer* const viewPanelSizer = new wxBoxSizer(wxVERTICAL);
    m_text = new wxTextCtrl(m_viewPanel, -1);
    viewPanelSizer->Add(m_text, 1, wxALL | wxEXPAND, 5);
    m_viewPanel->SetSizer(viewPanelSizer);
    m_nb->AddPage(m_viewPanel, wxT("TextCtrl"), false);


    m_editPanel = new wxPanel(m_nb);
    wxBoxSizer* const editPanelSizer = new wxBoxSizer(wxVERTICAL);
    m_grid = new wxGrid(m_editPanel, -1);
    // Grid
    m_grid->CreateGrid(0, 16);
    for (uint8_t i = 0U; i < 16U; ++i)
    {
        m_grid->SetColLabelValue(i, wxString::Format("%02" PRIX8, i));
        m_grid->SetColSize(i, 24);
    }
    editPanelSizer->Add(m_grid, 1, wxALL | wxEXPAND, 5);
    m_editPanel->SetSizer(editPanelSizer);
    m_nb->AddPage(m_editPanel, wxT("Grid"), true);

    topSizerV->Add(m_nb, 1, wxEXPAND, 5);

    m_nb->SetSelection(0);

    this->SetSizer(topSizerV);
}

void MyFrame::OnButton(wxCommandEvent &event)
{
    switch(event.GetId())
    {
    case ID_SHOW_BUG:
    {
        uint8_t gridColIndex = 0U;
        int rowIndex = 0;
        uint32_t startAddress = 0;
        std::map<uint32_t, uint8_t> memory;
        for(int i = 0; i < 42; ++i)
            memory[i]=i%0xFF;
        for (std::map<uint32_t, uint8_t>::const_iterator it = memory.begin(); it != memory.end(); ++it)
        {
            if (gridColIndex == 0)
            {
                if(!m_grid->AppendRows( 1,/*updateLabels =*/ false))
                {
                    return;
                }
                m_grid->SetRowLabelValue(rowIndex, wxString::Format("%08" PRIX32, startAddress));
            }
            m_grid->SetCellValue(rowIndex, gridColIndex, wxString::Format("%02" PRIX8, it->second));
            ++gridColIndex;
            if (gridColIndex >= 16)
            {
                gridColIndex = 0U;
                ++rowIndex;
                startAddress += 16U;
                m_grid->SetRowLabelValue(rowIndex, wxString::Format("%08" PRIX32, startAddress));
            }
        }
        break;
    }
    }
}

