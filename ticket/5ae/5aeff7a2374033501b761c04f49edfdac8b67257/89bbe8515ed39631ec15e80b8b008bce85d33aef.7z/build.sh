#!/bin/bash
set -x
set -e
g++ -c `wx-config --cxxflags --unicode=yes --version=3.1` -I. Frame.cpp 
g++ Frame.o  `wx-config --version=3.1 --libs aui,core,base`-o test
rm -f Frame.o
