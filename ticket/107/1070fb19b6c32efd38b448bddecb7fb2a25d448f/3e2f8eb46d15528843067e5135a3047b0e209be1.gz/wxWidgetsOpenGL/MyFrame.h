/***************************************************************
 * Name:      MyFrame.h
 * Purpose:   Defines Application Frame
 * Author:     ()
 * Created:   2014-06-10
 * Copyright:  ()
 * License:
 **************************************************************/

#ifndef MYFRAME_H
#define MYFRAME_H

#ifndef WX_PRECOMP
    #include <wx/wx.h>
#endif

#include "MyGLCanvas.h"
#include "MyApp.h"
class MyFrame: public wxFrame
{
    public:
        MyFrame(wxFrame *frame, const wxString& title);
        MyGLCanvas *m_canvas;
        ~MyFrame();
        //MyGLCanvas *m_canvas;
    private:
        enum
        {
            idMenuQuit = 1000,
            idMenuAbout
        };
        void OnClose(wxCloseEvent& event);
        void OnQuit(wxCommandEvent& event);
        void OnAbout(wxCommandEvent& event);
        DECLARE_EVENT_TABLE()
};


#endif // MYFRAME_H
