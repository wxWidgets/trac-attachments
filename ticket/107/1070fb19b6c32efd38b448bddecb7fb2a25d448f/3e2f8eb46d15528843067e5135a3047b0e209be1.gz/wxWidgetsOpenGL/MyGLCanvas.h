#ifndef MYGLCANVAS_H
#define MYGLCANVAS_H

#include <wx/glcanvas.h>
#include "MyGLContext.h"
#include "CGeoPack.hpp"

class MyGLCanvas : public wxGLCanvas
{
    public:
        MyGLCanvas(wxWindow *parent, int *lpAttribList);
        void OnPaint(wxPaintEvent &event);
        void OnMouseEvent(wxMouseEvent &event);
        void OnKeyEvent(wxKeyEvent &event);
        MyGLContext *m_context;
        double m_lpWorldTrans[16];
        double m_lpViewTrans[16];
        double m_lpProjectTrans[16];
        ~MyGLCanvas();
    protected:
        int m_xMouse, m_yMouse;
        bool m_bLButtonDown;
        void m_fnRotate();
        void m_fnObserve();
        void m_fnCast();
        double m_zNear;
        double m_zDistance;
        double m_zFar;
        double m_RotateAngle;
        double m_lpRotateAxis[3];
        double m_TanHalfFov;
        bool m_bFirstTime;
        int m_HalfWidth;
        int m_HalfHeight;
    private:
    DECLARE_EVENT_TABLE()
};

#endif // MYGLCANVAS_H
