#ifndef MYGLCONTEXT_H
#define MYGLCONTEXT_H

#include <wx/glcanvas.h>


class MyGLContext : public wxGLContext
{
    public:
        MyGLContext(wxGLCanvas *canvas);
        ~MyGLContext();
    protected:
    private:
};

#endif // MYGLCONTEXT_H
