#include "MyGLCanvas.h"
#include <wx/dcclient.h>
#include <boost/math/constants/constants.hpp>
MyGLCanvas::MyGLCanvas(wxWindow *parent, int *lpAttribList): wxGLCanvas(parent, wxID_ANY, lpAttribList, wxPoint(0, 0), wxSize(800, 570), wxFULL_REPAINT_ON_RESIZE)
{
    m_context = new MyGLContext(this);
    m_zNear = 0.25;
    m_zDistance = 2;
    m_zFar = 4;
    m_TanHalfFov = tan(boost::math::constants::pi<double>() / 8);
    m_RotateAngle = 0;
    m_lpRotateAxis[0] = 0;
    m_lpRotateAxis[1] = 0;
    m_lpRotateAxis[2] = 1;
    m_bFirstTime = true;
//    SetBackgroundStyle(wxBG_STYLE_CUSTOM);
//    m_fnRotate();
//    m_fnObserve();
//    m_fnCast();
    //ctor
}

void MyGLCanvas::m_fnRotate()
{
    CGeoPack::fnFillRotateMatrix(m_lpWorldTrans, m_lpRotateAxis, m_RotateAngle);
}

void MyGLCanvas::m_fnObserve()
{
    int i;
    memset(m_lpViewTrans, 0, 16 * sizeof(double));
    for(i = 0; i < 4; ++i)
    {
        m_lpViewTrans[i * 4 + i] = 1;
    }
    m_lpViewTrans[14] = -m_zDistance;
}

void MyGLCanvas::m_fnCast()
{
    GetSize(&m_HalfWidth, &m_HalfHeight);
    m_HalfWidth /= 2;
    m_HalfHeight /= 2;
    memset(m_lpProjectTrans, 0, 16 * sizeof(double));
    m_lpProjectTrans[0] = double(m_HalfHeight) / double(m_HalfWidth);
    m_lpProjectTrans[5] = 1;
    m_lpProjectTrans[10] = 0.0625 * m_TanHalfFov;//-1 / (m_zFar - m_zNear) * m_TanHalfFov;
    m_lpProjectTrans[11] = -m_TanHalfFov;
    m_lpProjectTrans[14] = -0.5 * m_TanHalfFov;//m_zNear / (m_zFar - m_zNear) * m_TanHalfFov;
    m_lpProjectTrans[15] = 0;
}


void MyGLCanvas::OnMouseEvent(wxMouseEvent &event)
{
    int xMouse, yMouse;
    if(event.LeftDown())
    {
        m_xMouse = event.GetX();
        m_yMouse = event.GetY();
        m_bLButtonDown = true;
    }
    if(event.LeftUp())
    {
        m_xMouse = event.GetX();
        m_yMouse = event.GetY();
        m_bLButtonDown = false;
    }
    if(event.Dragging() && m_bLButtonDown)
    {
        GetSize(&m_HalfWidth, &m_HalfHeight);
        m_HalfWidth /= 2;
        m_HalfHeight /= 2;
        xMouse = event.GetX();
        yMouse = event.GetY();
        int xOffset1 = m_xMouse - m_HalfWidth;
        int yOffset1 = m_HalfHeight - m_yMouse;
        int xOffset2 = xMouse - m_HalfWidth;
        int yOffset2 = m_HalfHeight - yMouse;
        double lpdblVec1[3] = {double(xOffset1), double(yOffset1), sqrt(std::max<double>(0.0, double(m_HalfHeight * m_HalfHeight - xOffset1 * xOffset1 - yOffset1 * yOffset1)))};
        double lpdblVec2[3] = {double(xOffset2), double(yOffset2), sqrt(std::max<double>(0.0, double(m_HalfHeight * m_HalfHeight - xOffset2 * xOffset2 - yOffset2 * yOffset2)))};
        double lpdblCurrentAxis[3] = {0, 0, 1};
        double dblCurrentRotateAngle = 0.0;
        double lpdblNewAxis[3] = {0, 0, 1};
        double dblNewRotateAngle = 0.0;
        CGeoPack::fnMinRotation(lpdblCurrentAxis, dblCurrentRotateAngle, lpdblVec1, lpdblVec2);
        CGeoPack::fnMergeRotation(lpdblNewAxis, dblNewRotateAngle, m_lpRotateAxis, m_RotateAngle, lpdblCurrentAxis, dblCurrentRotateAngle);
        m_RotateAngle = dblNewRotateAngle;
        m_lpRotateAxis[0] = lpdblNewAxis[0];
        m_lpRotateAxis[1] = lpdblNewAxis[1];
        m_lpRotateAxis[2] = lpdblNewAxis[2];
        m_fnRotate();
        m_xMouse = xMouse;
        m_yMouse = yMouse;
        Refresh();
    }
}

void MyGLCanvas::OnKeyEvent(wxKeyEvent &event)
{
    wxKeyCode keyCode;
    keyCode = (wxKeyCode)event.GetKeyCode();
    switch(keyCode)
    {
    case WXK_LEFT:
        break;
    case WXK_RIGHT:
        break;
    case WXK_UP:
        {
            m_zDistance -= 1.0;
            m_zFar -= 2.0;
            m_zNear -= 0.125;
            m_fnObserve();
            m_fnCast();
            Refresh();
        }
        break;
    case WXK_DOWN:
        {
            m_zDistance += 1.0;
            m_zFar += 2.0;
            m_zNear += 0.125;
            m_fnObserve();
            m_fnCast();
            Refresh();
        }
        break;
    default:
        break;
    }
}



void MyGLCanvas::OnPaint(wxPaintEvent &event)
{
    double lpCoordinates[] =\
    {\
        0.5, 0.0, 0.0,\
        -0.5, 0.0, 0.0,\
        0.0, 0.5, 0.0,\
        0.0, -0.5, 0.0,\
        0.0, 0.0, 0.5,\
        0.0, 0.0, -0.5\
    };
    double lpColor[] =\
    {\
        1.0, 0.0, 0.0,\
        0.0, 1.0, 1.0,\
        0.0, 1.0, 0.0,\
        1.0, 0.0, 1.0,\
        0.0, 0.0, 1.0,\
        1.0, 1.0, 0.0\
    };
    int lpInd[] =\
    {\
        0, 2, 4,\
        2, 1, 4,\
        0, 4, 3,\
        2, 0, 5,\
        1, 2, 5,\
        1, 3, 4,\
        0, 3, 5,\
        1, 5, 3\
    };
    int i = 0;
    SetCurrent(*m_context);
    //wxPaintDC dc(this);
    if(m_bFirstTime)
    {
        m_bFirstTime = false;
        m_fnRotate();
        m_fnObserve();
        m_fnCast();
        glEnable(GL_DEPTH_TEST);
    }
    if(glIsEnabled(GL_DEPTH_TEST) == FALSE)
    {
        glEnable(GL_DEPTH_TEST);
    }
    glClearColor(0.0, 0.0, 0.0, 0.0);
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    glLoadIdentity();
    glPushMatrix();
    glMultMatrixd(m_lpProjectTrans);
    glMultMatrixd(m_lpViewTrans);
    glMultMatrixd(m_lpWorldTrans);
    glBegin(GL_TRIANGLES);
    for(i = 0; i< 8; ++i)
    {
        glColor3d(lpColor[lpInd[i * 3] * 3], lpColor[lpInd[i * 3] * 3 + 1], lpColor[lpInd[i * 3] * 3 + 2]);
        glVertex3d(lpCoordinates[lpInd[i * 3] * 3], lpCoordinates[lpInd[i * 3] * 3 + 1], lpCoordinates[lpInd[i * 3] * 3 + 2]);
        glColor3d(lpColor[lpInd[i * 3 + 1] * 3], lpColor[lpInd[i * 3 + 1] * 3 + 1], lpColor[lpInd[i * 3 + 1] * 3 + 2] - 4);
        glVertex3d(lpCoordinates[lpInd[i * 3 + 1] * 3], lpCoordinates[lpInd[i * 3 + 1] * 3 + 1], lpCoordinates[lpInd[i * 3 + 1] * 3 + 2]);
        glColor3d(lpColor[lpInd[i * 3 + 2] * 3], lpColor[lpInd[i * 3 + 2] * 3 + 1], lpColor[lpInd[i * 3 + 2] * 3 + 2]);
        glVertex3d(lpCoordinates[lpInd[i * 3 + 2] * 3], lpCoordinates[lpInd[i * 3 + 2] * 3 + 1], lpCoordinates[lpInd[i * 3 + 2] * 3 + 2]);
    }
    glEnd();
    glPopMatrix();
    glFlush();
    //SwapBuffers();
}

MyGLCanvas::~MyGLCanvas()
{
    delete m_glContext;
    //dtor
}

BEGIN_EVENT_TABLE(MyGLCanvas, wxGLCanvas)
    EVT_PAINT(MyGLCanvas::OnPaint)
    EVT_MOUSE_EVENTS(MyGLCanvas::OnMouseEvent)
    EVT_KEY_DOWN(MyGLCanvas::OnKeyEvent)
END_EVENT_TABLE()
