#include "MyGLContext.h"

MyGLContext::MyGLContext(wxGLCanvas *canvas): wxGLContext(canvas)
{
    //ctor
}


MyGLContext::~MyGLContext()
{
    //dtor
}
