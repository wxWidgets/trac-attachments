/***************************************************************
 * Name:      MyApp.h
 * Purpose:   Defines Application Class
 * Author:     ()
 * Created:   2014-06-10
 * Copyright:  ()
 * License:
 **************************************************************/

#ifndef MYAPP_H
#define MYAPP_H

#include <wx/app.h>

class MyApp : public wxApp
{
    public:
        virtual bool OnInit();
};

#endif // MYAPP_H
