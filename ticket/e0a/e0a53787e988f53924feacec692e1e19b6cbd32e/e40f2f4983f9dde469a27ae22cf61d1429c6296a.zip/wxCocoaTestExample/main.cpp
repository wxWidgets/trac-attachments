#include "wx/wxprec.h"
#ifndef WX_PRECOMP
    #include "wx/wx.h"
#endif

#include "wx/wx.h"
#include "wx/odcombo.h"


class MyApplication: public wxApp
{
protected:
    bool OnInit();
};

MyApplication *pApp;


class MyOwnerDrawnComboBox : public wxOwnerDrawnComboBox
{
protected:
    void OnDrawBackground(wxDC &dc, const wxRect &rect, int item, int flags) const;
    void OnDrawItem(wxDC &dc, const wxRect &rect, int item, int flags) const;
    wxCoord OnMeasureItem(size_t item) const {return(20);}
    wxCoord OnMeasureItemWidth(size_t item) const {return(180);}
    
public:
    MyOwnerDrawnComboBox(wxWindow *pParent, int nID, const wxPoint &position, const wxSize &size);
};


class MyDialog : public wxDialog
{
protected:
    MyOwnerDrawnComboBox *pODComboBox;
    bool mbCreated;
    void OnCreate(wxWindowCreateEvent &event);
   
public:
    MyDialog();
    DECLARE_EVENT_TABLE()
};



class MyMainWindow : public wxFrame
{
protected:
    void OnControlEvent(wxCommandEvent& event);
    void OnClose(wxCloseEvent& event);
    
public:
    MyMainWindow(wxWindow * parent, wxWindowID id, const wxPoint &pos, const wxSize &sizeid);
    DECLARE_EVENT_TABLE()
};



BEGIN_EVENT_TABLE(MyDialog, wxDialog)
    EVT_WINDOW_CREATE(MyDialog::OnCreate)
END_EVENT_TABLE()


MyDialog :: MyDialog()
             : wxDialog(NULL, 101, wxString("The Dialog"), wxDefaultPosition, wxSize(700, 200))
{
    new wxStaticText(this, 99, wxString("This is here to prevent wxWidgets from gratuitously making the combo box fill the entire dialog"), wxPoint(10, 10));
    pODComboBox = new MyOwnerDrawnComboBox((wxWindow *)this, 101, wxPoint(20, 40), wxDefaultSize);
    wxSizer *stupidSizer = new wxBoxSizer(wxVERTICAL);
    stupidSizer->Add(pODComboBox); 
    stupidSizer->SetMinSize(250, 20);
    stupidSizer->Fit(pODComboBox);
    pODComboBox->SetPopupAnchor(wxRIGHT);
    pODComboBox->SetPopupMinWidth(200);
    pODComboBox->SetPopupMaxHeight(-1);
    mbCreated = false;
}

void MyDialog :: OnCreate(wxWindowCreateEvent &event)
{
    if (mbCreated) return;
    mbCreated = true;
    pODComboBox->Append(wxString("one"));
    pODComboBox->Append(wxString("two"));
    pODComboBox->Append(wxString("three"));
    pODComboBox->Append(wxString("four"));
    pODComboBox->SetSelection(2);
}




MyOwnerDrawnComboBox::MyOwnerDrawnComboBox(wxWindow *pParent, int nID, const wxPoint &position, const wxSize &size)
                     : wxOwnerDrawnComboBox(pParent, nID, wxEmptyString, position, size, 0, NULL, wxCB_READONLY|wxODCB_DCLICK_CYCLES)
{
}


void MyOwnerDrawnComboBox::OnDrawBackground(wxDC &dc, const wxRect &rect, int item, int flags) const
{
    OnDrawItem(dc, rect, item, 0);
}


void MyOwnerDrawnComboBox::OnDrawItem(wxDC &dc, const wxRect &rect, int item, int flags) const
{
    if ( item == wxNOT_FOUND )
        return;

    wxColour txtCol;
    int mod = item % 4;

    if (flags & wxODCB_PAINTING_SELECTED)
        txtCol = *wxCYAN;
    else if ( mod == 0 )
        txtCol = *wxBLACK;
    else if ( mod == 1 )
        txtCol = *wxRED;
    else if ( mod == 2 )
        txtCol = *wxGREEN;
    else
        txtCol = *wxBLUE;
    dc.SetTextForeground(txtCol);
    dc.DrawText(GetString(item), rect.x + 3, rect.y + ((rect.height - dc.GetCharHeight())/2));
}








BEGIN_EVENT_TABLE(MyMainWindow, wxWindow)
    EVT_COMMAND(wxID_ANY, wxEVT_COMMAND_BUTTON_CLICKED, MyMainWindow::OnControlEvent)
    EVT_CLOSE(MyMainWindow::OnClose)
END_EVENT_TABLE()

MyMainWindow :: MyMainWindow(wxWindow * parent, wxWindowID id, const wxPoint &pos, const wxSize &size)
                   : wxFrame(parent, id, wxString("Example"), pos, size)
{
    new wxButton(this, 201, wxString("Show Modal Dialog"), wxPoint(14, 14), wxSize(160, 22));
    new wxButton(this, 202, wxString("Show Modeless Dialog"), wxPoint(14, 50), wxSize(160, 22));
}


void MyMainWindow::OnControlEvent(wxCommandEvent &event)
{
    if (event.GetEventType() == wxEVT_COMMAND_BUTTON_CLICKED)
    {
        if (event.GetId() == 201)
        { // Show modal
            MyDialog *pTestDialog = new MyDialog();
            pTestDialog->ShowModal();
            delete pTestDialog;
        }
        if (event.GetId() == 202)
        { // Show modeless
            MyDialog *pTestDialog = new MyDialog();
            pTestDialog->Show();
        }
    }
}


void MyMainWindow::OnClose(wxCloseEvent& event)
{
    pApp->SetExitOnFrameDelete(true);
    Destroy();
}



IMPLEMENT_APP(MyApplication)
 
 
bool MyApplication::OnInit()
{
    MyMainWindow *pMainWindow = new MyMainWindow(NULL, 99, wxPoint(50, 50), wxSize(500, 500));
    pMainWindow->Show();
    pApp = this;
    return true;
}

