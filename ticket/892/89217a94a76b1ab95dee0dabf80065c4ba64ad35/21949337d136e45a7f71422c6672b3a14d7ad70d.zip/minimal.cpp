#include <wx/wx.h>
#include <wx/sizer.h>


#include <wx/font.h>

wxFont Fonts_2(11,wxFONTFAMILY_MODERN,wxFONTSTYLE_ITALIC,wxFONTWEIGHT_BOLD); // big header

/////////////////////////////////////////////////////////////////////////////
// Name:        awx/button.h
// Purpose:
// Author:      Joachim Buermann
// Id:          $Id: button.h,v 1.3 2004/08/30 10:20:19 jb Exp $
// Copyright:   (c) 2003,2004 Joachim Buermann
// Licence:     wxWindows
/////////////////////////////////////////////////////////////////////////////


#include <wx/dcmemory.h>
#include <wx/wx.h>
#include <wx/string.h>
#include <wx/bitmap.h>
#include <wx/colour.h>
#include <wx/tglbtn.h>// for the event

/*!
  \class awxButton
  a graphical button class like wxBitmap but with 4 possible states.
  The states are:
  \li \c up, means button isn't pressed (normal state)
  \li \c over, (mouse over the button, but not pressed)
  \li \c down, button  is pressed (mouse left click)
  \li \c disabled, button is inactive (disabled) and cannot pressed

*/
class AwxButton : public wxWindow
{ 
public:

    ///   The kind of border used by the button
    enum BorderType {
        /// sunken border, seem like a pressed button
        Border_Sunken,
        /// flat (no) border
        Border_Flat,
        /// high border, seems like a active (not pressed) button
        Border_High,
        // set for all Borders
        Border_Not_Specified
    };


public:
    /*!
    The AwxButton constructor
    \param parent A pointer to it's parent class, mostly awxToolbar.
    \param id button identifier. If -1, will automatically create an identifier.
    \param pos button position. wxDefaultPosition is (-1, -1) which indicates that
    wxWidgets should generate a default position for the button. If
    using the AwxButton class directly, supply an actual position.
    \param size the button size. wxDefaultSize is (-1, -1) which
    indicates that AwxButton use a size of 32x32.
    \param upXPM pointer to the xpm data including the up image
    \param overXPM pointer to the xpm data including the over image. If NULL,
    a standard high border is used.
    \param downXPM pointer to the xpm data including the down image. If NULL,
    a standard sunken border is used.
    \param disXPM pointer to the xpm data including the disable image. If NULL,
    the upXPM image is used.
  */
    AwxButton(wxWindow * parent, wxWindowID id, const wxPoint & pos, const wxSize & size,
              const char *const*upXPM, const char *const*overXPM, const char *const*downXPM, const char *const*disXPM);

    AwxButton(wxWindow * parent, wxWindowID id, const wxPoint & pos, const wxSize & size,
              const wxString& upPNG,const wxString& overPNG,
              const wxString& downPNG, const wxString& disPNG);


    AwxButton(wxWindow * parent, wxWindowID id, const wxPoint & pos, const wxSize & size,
              const wxBitmap& upPNG,const wxBitmap& overPNG,
              const wxBitmap& downPNG, const wxBitmap& disPNG);


    /*!
    The default ctor makes nothing.
  */
    AwxButton() {};

    /*!
    The AwxButton destructor. Because AwxButton uses some allocated memory
    from heap, the destructor must free it. It must also be virtual, so
    derivated classes (and their ctors) can call it.
  */
    virtual ~ AwxButton();

    /*!
    Disables the button so it cannot be pressed any longer. The
    button use the internal disable image to drawing this state.
  */
    virtual void Disable();

    /*!
    Enables the button so it can be pressed by the user. The
    button use the internal up image to drawing this state.
  */
    virtual void Enable();

    /*!
    For wxWidget compatiblity. Enable or disable the button.
    \param enable true enables the button, false disables it.
  */
    virtual bool Enable(bool enable) {
        if(enable) Enable();
        else Disable();
        return true;
    };

    /*!
    Returns the internal 'press' state of the button.
    \return true, if teh button is pressed, false otherwise
  */
    virtual bool IsPressed() {return m_state == State_ButtonDown;};

    /*!
    Returns the active state of the button.
    \return true, if teh button is enabled, false otherwise
  */
    bool IsEnabled() {return m_enabled;};
    /*!
    Paint the content of the button. In detail:
    At the first time (m_painted is false), DrawOnBitmap() was
    called (to initiate the internal bitmap), and the m_painted flag
    was set to true.
    Apart from that only a simple draw of the internal bitmap is
    done.
  */
    virtual void OnPaint(wxPaintEvent& WXUNUSED(event));
    /*!
    On MS only call Redraw() and skip the event.
    On linux gtk the background image isn't repaint by the toolbar
    at this time, so defer the redraw for later.
  */
    virtual void OnEraseBackground(wxEraseEvent &event);
    /*!
    All mouse events will be handled by this (if the button is
    enabled).
    If the left mouse button changed to up, a wxEVT_COMMAND_MENU_SELECTED
    event with the button id was fired (in detail, the event was
    forwarded to the parent of the button.
  */
    virtual void OnMouseEvent(wxMouseEvent& WXUNUSED(event));
    /*!
    Only call Redraw() and skip the event.
  */
    virtual void OnSizeEvent(wxSizeEvent& event);
    /*!
    If the button isn't pressed, this call set the button in the
    pressed state (also drawing the associated image and/or border.
  */
    virtual bool Press();
    /*!
    If the button is pressed, this call set the button in the
    unpressed (release) state (also drawing the associated image
    and/or border.
  */
    virtual bool Release();
    /*!
    Set the label for the button. This can be done also dynamically
    within a running application.
    \param text the new label for the button
  */
    virtual void SetText(const wxChar* text);

    virtual void SetTextColour(const wxColour& color);

    virtual void SetTextFont(const wxFont& font);

    /*!
   * Set the Backgroundimage for the button
   */
    virtual void SetBackground(const wxBitmap&  background);

    // set the Border Type
    virtual void SetBorderType(const BorderType&  bordertype);

    virtual void SetBitmaps(const char * const*upXPM, const char *const*overXPM, const char *const*downXPM, const char *const*disXPM);

protected:
    /*!
    The internal button states
  */
    enum ButtonState {
        /// button is active but not pressed (up)
        State_ButtonUp,
        /// mouse pointer is over the button (not pressed)
        State_ButtonOver,
        /// left click on the button
        State_ButtonDown,
        /// button is disabled
        State_ButtonDis,
        /// internal beginning state different from the other ones
        State_ButtonNew
    };


    BorderType mBorderType;
    /// width of the button
    int m_width;
    /// height of the button
    int m_height;
    /*!
    if the buttons width is greater as the image, m_dx covered the
    offset for the image from the origin (left top corner) to draw
    the image in the center (horizontally).
  */
    int m_dx;
    /*!
    if the buttons height is greater as the image, m_dy covered the
    offset for the image from the origin (left top corner) to draw
    the image in the center (vertically).
  */
    int m_dy;

    /// the internal enabled state
    bool m_enabled;

    /// the actual button state (up, over, down and disabled)
    ButtonState m_state;
    /// to check against the last state, this state variable is needed
    ButtonState m_laststate;
    /// the internal bitmap for wxMemoryDC (buffered drawing)
    wxBitmap* m_bitmap;
    /// the button text
    wxString m_text;
    /// the font of thebutton text
    wxFont m_font;
    /// the colourof thebutton text
    wxColour mTextColour;

    /// the four images (for each state)
    wxBitmap *m_icons[4];
    /*!
    Internal flag. Is set to true, if the first OnPaint() was occured.
    As long as the flag is false, a Redraw() call does nothing.
  */
    bool m_painted;
    /// true, if the theme handling was enabled.
    bool m_theme;


    wxBitmap  mBgBitmap;
    /*!
    Internal function to draw the border on the given memory dc.
    \param dc reference to the internal wxMemoryDC context.
    \param border kind of border, sunken, flat or high
  */
    void DrawBorder(wxDC& dc, BorderType border);
    /*!
    Draw the content of the button (dependend of it's state, icons)
    into the memory bitmap (m_bitmap).
    If theme handling is enabled and a connected awxToolbar exists,
    the button queries the background image from the awxToolbar and
    copy it into it's memory bitmap.
    Without theme handling, the background will be filled with the
    system wide background colour for toolbars.
    Following the icon and borders will be drawed, finished by
    drawing the button label (if exists).
    The DrawOnBitmap member function is only be called, if the
    internal state has been changed. Otherwise only the content of
    the bitmap will be paste into the wxPaintDC context (for example,
    if the application was minimized, maximized or covered by another
    program.
  */
    virtual void DrawOnBitmap();
    /*!
    The Redraw function is used outside of a paint event (like
    changing the internal state). It calls the DrawOnBitmap member
    and copy the bitmap content in a wxClientDC context.
  */
    void Redraw();
public:
    /*!
    Set the theme handling on (enabled) or of (disabled)
    param enable true activates the theme drawing, false disabled it
  */
    void EnableTheme(bool enable);
    DECLARE_EVENT_TABLE()

    DECLARE_DYNAMIC_CLASS (AwxButton)

};


/////////////////////////////////////////////////////////////////////////////
// Name:        awx/button.cpp
// Purpose:
// Author:      Joachim Buermann
// Id:          $Id: button.cpp,v 1.2 2004/11/05 10:48:46 jb Exp $
// Copyright:   (c) 2003 Joachim Buermann
// Licence:     wxWindows
/////////////////////////////////////////////////////////////////////////////

#include <wx/dc.h>
#include <wx/dcclient.h>
#include <wx/image.h>
#include <wx/settings.h>


IMPLEMENT_DYNAMIC_CLASS(AwxButton, wxWindow)

BEGIN_EVENT_TABLE(AwxButton, wxWindow)
EVT_MOUSE_EVENTS(AwxButton::OnMouseEvent)
EVT_PAINT(AwxButton::OnPaint)
EVT_SIZE(AwxButton::OnSizeEvent)
EVT_ERASE_BACKGROUND(AwxButton::OnEraseBackground)
END_EVENT_TABLE()

#define wxMB_COLOR_OVER wxColour(0xE8,0xE8,0xE8)
#define wxMB_COLOR_BG wxColour(0xD7,0xD7,0xD7)
#define wxMB_TEXT_MARGIN 8


/// ctor
AwxButton::AwxButton(wxWindow * parent, wxWindowID id, const wxPoint & pos, const wxSize & size,
                     const char *const*upXPM, const char *const*overXPM,const char *const*downXPM,  const char *const*disXPM)
    : wxWindow(parent, id, pos, size)
{
    if(size == wxDefaultSize) {
        m_width = 32;
        m_height = 32;
    } else {
        m_width = size.x;
        m_height = size.y;
    }

    m_state = State_ButtonUp;
    m_enabled = true;
    m_painted = false;
    m_theme = false; // true; //false;
    mBorderType = Border_Not_Specified;

    memset(m_icons,0,sizeof(m_icons));

    if(upXPM) m_icons[0] = new wxBitmap(upXPM);
    // if the over image is a NULL pointer, use a upper frame instead
    if(overXPM) m_icons[1] = new wxBitmap(overXPM);
    // if the down image is a NULL pointer, use a lower frame instead
    if(downXPM) m_icons[2] = new wxBitmap(downXPM);
    // without a disable image, the up image will be used
    if(disXPM) m_icons[3] = new wxBitmap(disXPM);
    else {
        if(upXPM) m_icons[3] = new wxBitmap(upXPM);
    }
    // button font text
#ifdef __WIN32__
    m_font = tcColor::Fonts[1];
#else
    m_font = Fonts_2;
#endif
    m_laststate = State_ButtonNew;

    // use the up icon dimensions for the image
    int x = 0;
    if(m_icons[0]) x = m_icons[0]->GetWidth();
    if(x <= m_width) m_dx = (m_width - x) >> 1;
    else m_dx = 0;
    m_dy = 0;

    mBgBitmap = wxNullBitmap;

    SetSize(m_width,m_height);
    m_bitmap = new wxBitmap(m_width,m_height);
    /*
    awxToolbar* mtb = wxDynamicCast(GetParent(),awxToolbar);
    if(mtb) {
    EnableTheme(mtb->HasTheme());
    }
  */
};

/// ctor // TODO_2019 use bitmap ctor instead of wxStrings
AwxButton::AwxButton(wxWindow * parent, wxWindowID id, const wxPoint & pos, const wxSize & size,
                     const wxString& upPNG,const wxString& overPNG,
                     const wxString& downPNG, const wxString& disPNG)
    : wxWindow(parent, id, pos, size)
{

    if (wxFileExists(upPNG) == false || wxFileExists(overPNG) == false ||
            wxFileExists(downPNG) == false || wxFileExists(disPNG) == false )
    {
        wxLogMessage("ERROR in AwxButton ctor");
    }

    if(size == wxDefaultSize) {
        m_width = 32;
        m_height = 32;
    } else {
        m_width = size.x;
        m_height = size.y;
    }
    
    m_state = State_ButtonUp;
    m_enabled = true;
    m_painted = false;
    m_theme = true; //false;
    mBorderType = Border_Not_Specified;

    memset(m_icons,0,sizeof(m_icons));


    if(upPNG.Length() > 0) m_icons[0] = new wxBitmap(upPNG, wxBITMAP_TYPE_PNG);
    // if the over image is a NULL pointer, use a upper frame instead
    if(overPNG.Length() > 0) m_icons[1] = new wxBitmap(overPNG, wxBITMAP_TYPE_PNG);
    // if the down image is a NULL pointer, use a lower frame instead
    if(downPNG.Length() > 0) m_icons[2] = new wxBitmap(downPNG, wxBITMAP_TYPE_PNG);
    // without a disable image, the up image will be used
    if(disPNG.Length() > 0) m_icons[3] = new wxBitmap(disPNG, wxBITMAP_TYPE_PNG);
    else {
        if(upPNG.Length() > 0) m_icons[3] = new wxBitmap(upPNG, wxBITMAP_TYPE_PNG);
    }
    // button font text
#ifdef __WIN32__
    m_font = tcColor::Fonts[1];
#else
    m_font = Fonts_2;
#endif
    m_laststate = State_ButtonNew;


    // use the up icon dimensions for the image
    int x = 0;
    if(m_icons[0]) x = m_icons[0]->GetWidth();
    if(x <= m_width) m_dx = (m_width - x) >> 1;
    else m_dx = 0;
    m_dy = 0;

    mBgBitmap = wxNullBitmap;

    SetSize(m_width,m_height);
    m_bitmap = new wxBitmap(m_width,m_height);

#ifdef _TODO_2019_
    awxToolbar* mtb = wxDynamicCast(GetParent(),awxToolbar);
    if(mtb) {
        EnableTheme(mtb->HasTheme());
    }
#endif
}


/// can use wxArtProvider Bitmaps for instance
AwxButton::AwxButton(wxWindow * parent, wxWindowID id, const wxPoint & pos, const wxSize & size,
                     const wxBitmap& upPNG,const wxBitmap& overPNG,
                     const wxBitmap& downPNG, const wxBitmap& disPNG)
    : wxWindow(parent, id, pos, size)
{
    if(size == wxDefaultSize) {
        m_width = 32;
        m_height = 32;
    } else {
        m_width = size.x;
        m_height = size.y;
    }

    m_state = State_ButtonUp;
    m_enabled = true;
    m_painted = false;
    m_theme = true; //false;
    mBorderType = Border_Not_Specified;

    memset(m_icons,0,sizeof(m_icons));


    m_icons[0] = new wxBitmap(upPNG);
    // if the over image is a NULL pointer, use a upper frame instead
    m_icons[1] = new wxBitmap(overPNG);
    // if the down image is a NULL pointer, use a lower frame instead
    m_icons[2] = new wxBitmap(downPNG);
    // without a disable image, the up image will be used
    m_icons[3] = new wxBitmap(disPNG);

    // button font text
#ifdef __WIN32__
    m_font = tcColor::Fonts[1];
#else
    m_font = Fonts_2;
#endif
    m_laststate = State_ButtonNew;


    // use the up icon dimensions for the image
    int x = 0;
    if(m_icons[0]) x = m_icons[0]->GetWidth();
    if(x <= m_width) m_dx = (m_width - x) >> 1;
    else m_dx = 0;
    m_dy = 0;

    mBgBitmap = wxNullBitmap;

    SetSize(m_width,m_height);
    m_bitmap = new wxBitmap(m_width,m_height);
#ifdef _TODO_2019_
    awxToolbar* mtb = wxDynamicCast(GetParent(),awxToolbar);
    if(mtb) {
        EnableTheme(mtb->HasTheme());
    }
#endif
}


/// set the Border Type
void AwxButton::SetBorderType(const BorderType&  bordertype)
{
    mBorderType = bordertype;
}

/// set text for button
void AwxButton::SetText(const wxChar* text)
{
    int w,h= 0;
    wxClientDC dc(this);
    dc.SetFont(m_font);
    m_text = text;
    dc.GetTextExtent(text,&w,&h);
#ifdef _TODO_2019_
    if(w > m_width) m_width = w + wxMB_TEXT_MARGIN;
    m_height += m_font.GetPointSize()+2;
    SetSize(m_width,m_height);
    
    if(m_icons[0]) x = m_icons[0]->GetWidth();
    if(x <= m_width) m_dx = (m_width - x) >> 1;
    else m_dx = 0;
#endif
    m_bitmap->Create(m_width,m_height);
    Redraw();
}

/// dtor
AwxButton::~AwxButton()
{
    for(int i=0;i<4;i++) {
        if(m_icons[i]) delete m_icons[i];
    }
    delete m_bitmap;
}


///  set new images for the button
void AwxButton::SetBitmaps(const char * const*upXPM, const char *const*overXPM, 
                           const char *const*downXPM, const char *const*disXPM)
{
    delete m_icons[0];
    delete m_icons[1];
    delete m_icons[2];
    delete m_icons[3];

    m_icons[0] = new wxBitmap(upXPM);
    m_icons[1] = new wxBitmap(overXPM);
    m_icons[2] = new wxBitmap(downXPM);
    m_icons[3] = new wxBitmap(disXPM);
    Refresh(true);
}


/// draw the border
void AwxButton::DrawBorder(wxDC& dc, BorderType border)
{
    // if we want no to show
    if (mBorderType == AwxButton::Border_Flat)
        border = Border_Flat;

    if(!m_theme) {
        wxColour bg = GetParent()->GetBackgroundColour();
        wxBrush brush_over(wxMB_COLOR_OVER);
        dc.SetBrush(brush_over);
        dc.SetPen(*wxTRANSPARENT_PEN);
        dc.DrawRectangle(0,0,m_width,m_height);
    }
    wxPen light(wxColour(0xFF,0xFF,0xFF),1);
    wxPen dark(wxColour(0x80,0x80,0x80),1);
    wxPen corner(wxMB_COLOR_BG,1);

    switch(border) {
    case Border_High:
        dc.SetPen(light);
        dc.DrawLine(1,0,m_width-2,0);
        dc.DrawLine(0,1,0,m_height-2);
        dc.SetPen(dark);
        dc.DrawLine(0,m_height-1,m_width-1,m_height-1);
        dc.DrawLine(m_width-1,0,m_width-1,m_height-1);
        break;
    case Border_Sunken:
        dc.SetPen(dark);
        dc.DrawLine(1,0,m_width-2,0);
        dc.DrawLine(0,1,0,m_height-2);
        dc.SetPen(light);
        dc.DrawLine(1,m_height-1,m_width-2,m_height-1);
        dc.DrawLine(m_width-1,1,m_width-1,m_height-2);
        break;
    default:
        break;
    }
}

void AwxButton::EnableTheme(bool enable)
{
    m_theme = enable;
    Redraw();
}


/// draw on bitmap
void AwxButton::DrawOnBitmap()
{
    // wxCoord dx = 0;
    // wxCoord dy = 0;
    wxCoord w;
    wxCoord h;

    wxMemoryDC dc;
    dc.SelectObject(*m_bitmap);
    // use the system background colour for buttons (wxSYS_COLOUR_BTNFACE)
    // if there is no theme enabled
    if(!m_theme) {

        //wxBrush brush(wxSystemSettings::GetColour(wxSYS_COLOUR_BTNFACE),wxSOLID);
        wxColour bg = m_parent->GetBackgroundColour();
        wxBrush brush(m_parent->GetBackgroundColour());
        dc.SetBackground(brush);
        dc.Clear();
    } else {
        if(/*mBgBitmap != wxNullBitmap &&*/  mBgBitmap.Ok()) {
            dc.DrawBitmap(mBgBitmap,0,0,false);
        } else {
            wxColour bg = m_parent->GetBackgroundColour();
            wxBrush brush(m_parent->GetBackgroundColour());
            dc.SetBackground(brush);
        }

    }
    dc.SetFont(m_font);
    
    switch(m_state) {
    case State_ButtonUp:
        if(m_icons[m_state]) {
            dc.DrawBitmap(*m_icons[m_state],m_dx,m_dy);
        }
        break;
    case State_ButtonOver:
        if(m_icons[m_state]) dc.DrawBitmap(*m_icons[m_state],m_dx,m_dy);
        else {
            DrawBorder(dc,Border_High);
            if(m_icons[State_ButtonUp]) {
                dc.DrawBitmap(*m_icons[State_ButtonUp],m_dx,m_dy);
            }
        }
        break;
    case State_ButtonDown:
        if(m_icons[m_state]) dc.DrawBitmap(*m_icons[m_state],m_dx,m_dy);
        else {
            DrawBorder(dc,Border_Sunken);
            if(m_icons[State_ButtonUp]) {
                dc.DrawBitmap(*m_icons[State_ButtonUp],m_dx+1,m_dy+1);
            }
        }
        //dx = dy = 1;
        break;
    case State_ButtonDis:
        if(m_icons[m_state]) dc.DrawBitmap(*m_icons[m_state],m_dx,m_dy);
        else {
        }
        break;
    default:
        dc.SelectObject(wxNullBitmap);
        return;
    }
    
    dc.GetTextExtent(m_text,&w,&h);
    if(w > m_width) w = m_width;
    if(h > m_height) h = m_height;

    if(!m_text.IsEmpty()) {
        if(m_enabled) {
            dc.SetTextForeground(mTextColour);
            // dc.DrawText(m_text,((m_width-w)>>1)+1+dx,m_height-h+dy);
            dc.DrawText(m_text,m_width/2 -w/2,m_height/2 -h/2);
        } else {
            dc.SetTextForeground(wxColour(255,255,255));
            //dc.DrawText(m_text,((m_width-w)>>1)+1+dx,m_height-h+dy);
            dc.SetTextForeground(wxColour(128,128,128));
            //dc.DrawText(m_text,((m_width-w)>>1)+dy,m_height-h-1+dy);
            dc.DrawText(m_text,m_width/2 -w/2,m_height/2 -h/2);

        }
    }
    
    dc.SelectObject(wxNullBitmap);
}

/// handle paint event
void AwxButton::OnPaint(wxPaintEvent& WXUNUSED(event))
{
    wxPaintDC dc(this);

    if(mBgBitmap.IsOk() == false) {
        mBgBitmap = wxBitmap(m_width,m_height);

        wxMemoryDC memDC;
        memDC.SelectObject(mBgBitmap);
        memDC.SetBrush(wxBrush(GetParent()->GetBackgroundColour()));
        memDC.SetPen(*wxTRANSPARENT_PEN);
        memDC.DrawRectangle(0,0,m_width,  m_height);
        dc.Blit(0,0,m_width,m_height,&memDC, 0, 0, wxCOPY, false);
    }
    if(!m_painted) {
        DrawOnBitmap();
        m_painted = true;
    }
    dc.DrawBitmap(*m_bitmap,0,0,false);
}

/// set the background picture of the button
void AwxButton::SetBackground(const wxBitmap&  background)
{
    mBgBitmap = background;

    Refresh(true);
}

/// set the text colour
void AwxButton::SetTextColour(const wxColour& color)
{
    mTextColour = color;
}

/// set the text font
void AwxButton::SetTextFont(const wxFont& font)
{
    m_font = font;
    Refresh(true);
}

///
void AwxButton::OnEraseBackground(wxEraseEvent& event)
{
#ifdef __WXMSW__
    Redraw();
    event.Skip();
#else
    // at this time, the background image isn't repaint by the toolbar,
    // so defer the redraw for later
    wxSizeEvent ev(GetSize(),GetId());
    AddPendingEvent(ev);
    event.Skip();
#endif
};

/// handle the mouse event
void AwxButton::OnMouseEvent(wxMouseEvent& event)
{
    if(!m_enabled) return;

    wxCommandEvent ev(wxEVT_COMMAND_BUTTON_CLICKED,GetId());
    ev.SetEventObject(GetParent());

    if(event.ButtonDown()) {
        m_state = State_ButtonDown;
        Redraw();
    } else if(event.ButtonUp()) {
        m_state = State_ButtonOver;
        wxPoint pos = event.GetPosition();

        if((pos.x < GetSize().GetWidth()) &&
                (pos.y < GetSize().GetHeight())) {

            GetParent()->GetEventHandler()->ProcessEvent(ev);
        }
        Redraw();
    } else if (event.Entering()) {
        m_state = State_ButtonOver;
        Redraw();
        return;
    } else if(event.Leaving()) {
        if((m_state == State_ButtonOver) || (m_state == State_ButtonDown)) {
            m_state = State_ButtonUp;
            Redraw();
            return;
        }
    }
}

/// handle the size event
void AwxButton::OnSizeEvent(wxSizeEvent &event)
{
    Redraw();
    event.Skip();
};

/// enable the button
void AwxButton::Enable()
{
    if(!m_enabled) {
        m_state = m_laststate;
        m_enabled = true;
        Redraw();
    }
};

/// disable the event
void AwxButton::Disable()
{
    if(m_enabled) {
        m_laststate = m_state;
        m_enabled = false;
        m_state = State_ButtonDis;
        Redraw();
    }
};

/// press the button
bool AwxButton::Press()
{
    if(m_state != State_ButtonDown) {
        m_state = State_ButtonDown;
        Redraw();
        return true;
    }
    return false;
};

/// redraw 
void AwxButton::Redraw()
{
    if(m_painted) {
        DrawOnBitmap();
        wxClientDC dc(this);
        dc.DrawBitmap(*m_bitmap,0,0,false);
    }
};


/// release the button
bool AwxButton::Release()
{
    if(m_state == State_ButtonDown) {
        m_state = State_ButtonUp;
        Redraw();
        return true;
    }
    return false;
};


/// end of AWXButton.cpp



// ----------------------------------------
// how-to-use example



// include XPMs
#include "mobile.xpm"


class MyApp: public wxApp
{
        
    wxFrame *frame;
    AwxButton* m_btn_1;

public:

    bool OnInit()
    {
        // make sure to call this first
        wxInitAllImageHandlers();
            
        frame = new wxFrame(NULL, wxID_ANY, wxT("Hello wxDC"), wxPoint(50,50), wxSize(800,600));
        
        // then simply create like this

	m_btn_1 = new AwxButton(frame, -1, wxPoint(10,25),wxSize(144,108), mobile_xpm, mobile_xpm, mobile_xpm, mobile_xpm);
            
        frame->Show();
        return true;
    } 
        
};

IMPLEMENT_APP(MyApp)
