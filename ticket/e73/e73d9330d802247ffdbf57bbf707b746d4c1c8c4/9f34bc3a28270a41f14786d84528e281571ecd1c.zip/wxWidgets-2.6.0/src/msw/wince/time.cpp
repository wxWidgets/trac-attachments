/////////////////////////////////////////////////////////////////////////////
// Name:        src/msw/wince/time.cpp
// Purpose:     Implements missing time functionality for WinCE
// Author:      Frank Schmidt - f.schmidt@akrobit.de
// Modified by:
// Created:     31-08-2003
// RCS-ID:
// Copyright:   (c) Frank Schmidt
// Licence:     wxWindows licence
/////////////////////////////////////////////////////////////////////////////

// ===========================================================================
// declarations
// ===========================================================================

// ---------------------------------------------------------------------------
// headers
// ---------------------------------------------------------------------------

#if defined(__GNUG__) && !defined(NO_GCC_PRAGMA)
    #pragma implementation "window.h"
#endif

// For compilers that support precompilation, includes "wx.h".
#include "wx/wxprec.h"

#ifdef __BORLANDC__
    #pragma hdrstop
#endif

#ifndef WX_PRECOMP
    #include "wx/msw/wrapwin.h"
#endif

#include "wx/msw/wince/time.h"
#include <winbase.h>


///////////////////////////////////////////////////////////////////////////////
// Some constants for time conversion

static const long SecsPerMin = 60,
                  MinsPerHour = 60,
                  SecsPerHour = MinsPerHour * SecsPerMin,
                  HoursPerDay = 24,
                  SecsPerDay = HoursPerDay * SecsPerHour,
                  DaysPerWeek = 7,
                  MonthsPerYear = 12;
static const long MaxYear = 2038,
                  EpochYear = 1970,
                  EpochWeekday = 4; // 1/1/1970 was a thursday


///////////////////////////////////////////////////////////////////////////////
// timezone - global variable that holds the timezone info

long timezone;


///////////////////////////////////////////////////////////////////////////////
// ftime - return the current time with ms resolution
//         does currently not set timezone and dstflag members

void __cdecl ftime(struct timeb* pTimeb)
{
   // no timezone info yet
   pTimeb->timezone = 0;
   pTimeb->dstflag = -1;

   // get the current time
   SYSTEMTIME systime;
   GetSystemTime(&systime);

   // now convert it into FILETIME
   union {
      FILETIME ft;
      unsigned __int64 i64;      // Number of 100 nanosecond units from 1/1/1601
      } filetime;
   SystemTimeToFileTime(&systime, &filetime.ft);

   // convert epoch to 1.1.1970
   static const __int64 nEpochDiff = 116444736000000000i64;
   filetime.i64 -= nEpochDiff;

   // get the milliseconds
   pTimeb->millitm = (unsigned short)((filetime.i64 / 10000i64) % 1000i64);

   // get the seconds since epoch (1/1/1970)
   pTimeb->time = (time_t)(filetime.i64 / 10000000i64);
}


///////////////////////////////////////////////////////////////////////////////
// time - return current time with second resolution

time_t __cdecl time(time_t* pt)
{
   struct timeb t;
   ftime(&t);
   if (pt)
      *pt = t.time;
   return t.time;
}


///////////////////////////////////////////////////////////////////////////////
// leapyear - determine whether a given year is a leap year

inline bool leapyear(long year)
{
   return (year % 4 == 0) && (year % 100 != 0 || year % 400 == 0);
}


///////////////////////////////////////////////////////////////////////////////
// daysperyear() - return the number of days in a year

inline long daysperyear(bool leapyear)
{
   static const days[] = { 365, 366 };
   return days[leapyear];
}


///////////////////////////////////////////////////////////////////////////////
//  daysinmonth - how many days has this month?

inline long daysinmonth(long lMonth, bool bLeapyear)
{
   static const long mdays[2][MonthsPerYear] = {
      { 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 },
      { 31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 }
      };
   return mdays[bLeapyear][lMonth];
}


///////////////////////////////////////////////////////////////////////////////
// gmtime - split time_t value into logical parts
//          not yet thread safe
//
struct tm * __cdecl gmtime(const time_t* pt)
{
   if (time_t(-1) == *pt )
      return NULL;

   // TO DO: use thread local storage for result
   static struct tm tres;

   // don't know anything about daylight saving time
   tres.tm_isdst = -1;

   // split days and seconds
   long lSecs = *pt % SecsPerDay;
   long lDays = *pt / SecsPerDay;

   // retrieve hour, min, sec
   tres.tm_hour = lSecs / SecsPerHour;
   lSecs %= SecsPerHour;
   tres.tm_min = lSecs / SecsPerMin;
   tres.tm_sec = lSecs % SecsPerMin;

   // now the day of week
   tres.tm_wday = (lDays + EpochWeekday) % DaysPerWeek;

   // calc the year: start with epoch and add years until we have less days than the next year
   long lYear = EpochYear;
   bool bLeap = leapyear(EpochYear);
   long lYearDays = daysperyear(bLeap);
   while (lDays >= lYearDays) {
      ++lYear;
      lDays -= lYearDays;
      bLeap = leapyear(lYear);
      lYearDays = daysperyear(bLeap);
      }
   tres.tm_year = lYear - 1900;
   tres.tm_yday = lDays;

   // calc the month: start with january and add months until we have less days than the next month
   tres.tm_mon = 0;
   long lMonthDays = daysinmonth(tres.tm_mon, bLeap);
   while (lDays >= lMonthDays) {
      ++tres.tm_mon;
      lDays -= lMonthDays;
      lMonthDays = daysinmonth(tres.tm_mon, bLeap);
      }

   // the rest is the day in month - but this starts with 1
   tres.tm_mday = lDays + 1;

   return &tres;
}


///////////////////////////////////////////////////////////////////////////////
// refreshtz - refresh global variable timezone

static void refreshtz()
{
   // refresh the timezone info
   TIME_ZONE_INFORMATION tz;
   DWORD tzid = GetTimeZoneInformation(&tz);
   if (TIME_ZONE_ID_UNKNOWN != tzid) {
      timezone = tz.Bias * SecsPerMin;
      if (TIME_ZONE_ID_DAYLIGHT == tzid)
         timezone += tz.DaylightBias * SecsPerMin;
      }
   else
      timezone = 0;
}


///////////////////////////////////////////////////////////////////////////////
// localtime

struct tm * __cdecl localtime(const time_t * pt)
{
   // refresh timezone
   refreshtz();

   // adjust pt with timezone
   time_t t = *pt - timezone;

#if 1
   return gmtime(&t);
#else
   // simple consistency test
   struct tm* res = gmtime(&t);
   time_t test = mktime(res);
   wxASSERT(*pt == test);
   return res;
#endif
}


///////////////////////////////////////////////////////////////////////////////
// mktime

time_t __cdecl mktime(struct tm *t)
{
   static const time_t InvalidTime = (time_t)-1;

   // valid year?
   long lYear = t->tm_year + 1900;
   if (lYear < EpochYear - 1 || lYear > MaxYear)
      return InvalidTime;

   // make sure month is in [0..11]
   long lMonth = t->tm_mon;
   if (lMonth < 0 || lMonth > 11) {
      lYear += lMonth / MonthsPerYear;
      lMonth %= MonthsPerYear;
      if (lMonth < 0) {
         lMonth += MonthsPerYear;
         --lYear;
         }
      // year still valid?
      if (lYear < EpochYear - 1 || lYear > MaxYear)
         return InvalidTime;
      }

   // days until start of year
   long lDays = (lYear - EpochYear) * 365       // 365 days for each year since epoch
              + (lYear - 1901) / 4 - 17;        // + 1 year for each leap year

   // add the days till 1st of month
   bool bLeap = leapyear(lYear);
   for (long l = 0; l < lMonth; ++l)
      lDays += daysinmonth(l, bLeap);

   // add the days from start of month
   lDays += t->tm_mday - 1;

   // continue calculation in seconds
   time_t tres = (time_t)lDays * (time_t)SecsPerDay;
   tres += (time_t)(t->tm_hour * SecsPerHour);
   tres += (time_t)(t->tm_min * SecsPerMin);
   tres += (time_t)t->tm_sec;

   // adjust the result according to the current timezone
   refreshtz();
   tres += timezone;

   return tres;
}


///////////////////////////////////////////////////////////////////////////////
// wcsftime helpers

static wxString GetLocaleInfoStr(LCTYPE lctype)
{
   int nSize =  ::GetLocaleInfo(LOCALE_USER_DEFAULT, lctype, NULL, 0);
   wxString res;
   ::GetLocaleInfo(LOCALE_USER_DEFAULT, lctype, res.GetWriteBuf(nSize), nSize);
   res.UngetWriteBuf();

   return res;
}
//-----------------------------------------------------------------------------

inline wchar_t* add_string(wchar_t* dest, wchar_t* end, const wchar_t* s)
{
   while (*s && dest != end)
      *dest++ = *s++;
   return dest;
}
//-----------------------------------------------------------------------------

inline wchar_t* add_qm(wchar_t* dest, wchar_t* end)
{
   return add_string(dest, end, L"?");
}
//-----------------------------------------------------------------------------

inline wchar_t* add_num(wchar_t* dest, wchar_t* end, int num, wchar_t* format)
{
   return add_string(dest, end, wxString::Format(format, num).c_str());
}
//-----------------------------------------------------------------------------

inline wchar_t* add_num(wchar_t* dest, wchar_t* end, int num, int lower, int upper, wchar_t* format)
{
   if (num < lower || num > upper)
      return add_qm(dest, end);

   return add_num(dest, end, num, format);
}
//-----------------------------------------------------------------------------

inline wchar_t* add_num2(wchar_t* dest, wchar_t* end, int num)
{
   return add_num(dest, end, num, L"%02d");
}
//-----------------------------------------------------------------------------

inline wchar_t* add_num2(wchar_t* dest, wchar_t* end, int num, int lower, int upper)
{
   return add_num(dest, end, num, lower, upper, L"%02d");
}
//-----------------------------------------------------------------------------

inline wchar_t* add_locinfostr(wchar_t* dest, wchar_t* end, LCTYPE lctype)
{
   return add_string(dest, end, GetLocaleInfoStr(lctype).c_str());
}
//-----------------------------------------------------------------------------

static wchar_t* fmt_a(wchar_t* dest, wchar_t* end, const struct tm * t)
{
   // Abbreviated weekday name
   if (t->tm_wday < 0 || t->tm_wday > 6)
      return add_qm(dest, end);

   static const LCTYPE lct[] = {
      LOCALE_SABBREVDAYNAME7,
      LOCALE_SABBREVDAYNAME1,
      LOCALE_SABBREVDAYNAME2,
      LOCALE_SABBREVDAYNAME3,
      LOCALE_SABBREVDAYNAME4,
      LOCALE_SABBREVDAYNAME5,
      LOCALE_SABBREVDAYNAME6
      };

   return add_locinfostr(dest, end, lct[t->tm_wday]);
}
//-----------------------------------------------------------------------------

static wchar_t* fmt_A(wchar_t* dest, wchar_t* end, const struct tm * t)
{
   // Full weekday name
   if (t->tm_wday < 0 || t->tm_wday > 6)
      return add_qm(dest, end);

   static const LCTYPE lct[] = {
      LOCALE_SDAYNAME7,
      LOCALE_SDAYNAME1,
      LOCALE_SDAYNAME2,
      LOCALE_SDAYNAME3,
      LOCALE_SDAYNAME4,
      LOCALE_SDAYNAME5,
      LOCALE_SDAYNAME6
      };

   return add_locinfostr(dest, end, lct[t->tm_wday]);
}
//-----------------------------------------------------------------------------

static wchar_t* fmt_b(wchar_t* dest, wchar_t* end, const struct tm * t)
{
   // Abbreviated month name
   if (t->tm_mon < 0 || t->tm_mon > 11)
      return add_qm(dest, end);

   static const LCTYPE lct[] = {
      LOCALE_SABBREVMONTHNAME1,
      LOCALE_SABBREVMONTHNAME2,
      LOCALE_SABBREVMONTHNAME3,
      LOCALE_SABBREVMONTHNAME4,
      LOCALE_SABBREVMONTHNAME5,
      LOCALE_SABBREVMONTHNAME6,
      LOCALE_SABBREVMONTHNAME7,
      LOCALE_SABBREVMONTHNAME8,
      LOCALE_SABBREVMONTHNAME9,
      LOCALE_SABBREVMONTHNAME10,
      LOCALE_SABBREVMONTHNAME11,
      LOCALE_SABBREVMONTHNAME12
      };

   return add_locinfostr(dest, end, lct[t->tm_mon]);
}
//-----------------------------------------------------------------------------

static wchar_t* fmt_B(wchar_t* dest, wchar_t* end, const struct tm * t)
{
   // Full month name
   if (t->tm_mon < 0 || t->tm_mon > 11)
      return add_qm(dest, end);

   static const LCTYPE lct[] = {
      LOCALE_SMONTHNAME1,
      LOCALE_SMONTHNAME2,
      LOCALE_SMONTHNAME3,
      LOCALE_SMONTHNAME4,
      LOCALE_SMONTHNAME5,
      LOCALE_SMONTHNAME6,
      LOCALE_SMONTHNAME7,
      LOCALE_SMONTHNAME8,
      LOCALE_SMONTHNAME9,
      LOCALE_SMONTHNAME10,
      LOCALE_SMONTHNAME11,
      LOCALE_SMONTHNAME12
      };

   return add_locinfostr(dest, end, lct[t->tm_mon]);
}
//-----------------------------------------------------------------------------

static wchar_t* fmt_d(wchar_t* dest, wchar_t* end, const struct tm * t)
{
   // Day of month as decimal number (01 .. 31)
   return add_num2(dest, end, t->tm_mday, 1, 31);
}
//-----------------------------------------------------------------------------

static wchar_t* fmt_H(wchar_t* dest, wchar_t* end, const struct tm * t)
{
   // Hour in 24-hour format (00 .. 23)
   return add_num2(dest, end, t->tm_hour, 0, 23);
}
//-----------------------------------------------------------------------------

static wchar_t* fmt_I(wchar_t* dest, wchar_t* end, const struct tm * t)
{
   // Hour in 12-hour format (01 .. 12)
   return add_num2(dest, end, (t->tm_hour % 12) ? (t->tm_hour % 12) : 12, 1, 12);
}
//-----------------------------------------------------------------------------

static wchar_t* fmt_m(wchar_t* dest, wchar_t* end, const struct tm * t)
{
   // Month as decimal number (01 .. 12)
   return add_num2(dest, end, t->tm_mon + 1, 1, 12);
}
//-----------------------------------------------------------------------------

static wchar_t* fmt_M(wchar_t* dest, wchar_t* end, const struct tm * t)
{
   // Minute as decimal number (00 .. 59)
   return add_num2(dest, end, t->tm_min, 0, 59);
}
//-----------------------------------------------------------------------------

static wchar_t* fmt_S(wchar_t* dest, wchar_t* end, const struct tm * t)
{
   // Second as decimal number (00 .. 59)
   return add_num2(dest, end, t->tm_sec, 0, 59);
}
//-----------------------------------------------------------------------------

static wchar_t* fmt_y(wchar_t* dest, wchar_t* end, const struct tm * t)
{
   // Year without century, as decimal number (00 .. 99)
   return add_num2(dest, end, t->tm_year % 100, 0, 99);
}
//-----------------------------------------------------------------------------

static wchar_t* fmt_Y(wchar_t* dest, wchar_t* end, const struct tm * t)
{
   // Year with century, as decimal number
   return add_num2(dest, end, t->tm_year + 1900);
}
//-----------------------------------------------------------------------------

static wchar_t* fmt_j(wchar_t* dest, wchar_t* end, const struct tm * t)
{
   // Day of year as decimal number (001 .. 366)
   return add_num(dest, end, t->tm_yday + 1, 1, 366, L"%03d");
}
//-----------------------------------------------------------------------------

static wchar_t* fmt_U(wchar_t* dest, wchar_t* end, const struct tm * t)
{
   // Week of year as decimal number, with Sunday as first day of week (00 .. 53)
   return add_num2(dest, end, (t->tm_yday + DaysPerWeek - t->tm_wday) / DaysPerWeek, 0, 53);
}
//-----------------------------------------------------------------------------

static wchar_t* fmt_W(wchar_t* dest, wchar_t* end, const struct tm * t)
{
   // Week of year as decimal number, with Monday as first day of week (00 .. 53)
   int nDay = (t->tm_yday + DaysPerWeek -
					(t->tm_wday
					   ? (t->tm_wday - 1)
					   : (DaysPerWeek - 1))) / DaysPerWeek;
   return add_num2(dest, end, nDay, 0, 53);
}
//-----------------------------------------------------------------------------

static wchar_t* fmt_w(wchar_t* dest, wchar_t* end, const struct tm * t)
{
   // Weekday as decimal number (0 .. 6; Sunday is 0)
   return add_num(dest, end, t->tm_wday, 0, 6, L"%d");
}
//-----------------------------------------------------------------------------

static wchar_t* fmt_p(wchar_t* dest, wchar_t* end, const struct tm * t)
{
   // Current locale's A.M./P.M. indicator for 12-hour clock
   bool bPM = t->tm_hour >= (HoursPerDay / 2);
   static const LCTYPE lct[] = {
      LOCALE_S1159, LOCALE_S2359
      };
   return add_locinfostr(dest, end, lct[bPM]);
}
//-----------------------------------------------------------------------------

static wchar_t* fmt_z(wchar_t* dest, wchar_t* end, const struct tm *)
{
   // time-zone name or time zone abbreviation
   TIME_ZONE_INFORMATION tz;
   if (TIME_ZONE_ID_UNKNOWN == GetTimeZoneInformation(&tz))
      return dest;
   return add_string(dest, end, tz.StandardName);
}
//-----------------------------------------------------------------------------

static void convertfromw32fmt(wxString& format)
{
   // translation from win32 format spec to strftime format spec
   static const struct { wchar_t* winfmt; wchar_t* strffmt; }
      conv[] = {
         { L"dddd", L"%A" },  // The full weekday name.
         { L"ddd", L"%a" },   // The three-character weekday abbreviation.
         { L"dd", L"%d" },    // The two-digit day. Single-digit day values are preceded by a zero.
         { L"d", L"%d" },     // The one-digit or the two-digit day.
         { L"gg", L"" },      // The period and era string that is contained in the CAL_SERASTRING value that is associated with the specified locale. Windows CE ignores this element if the date to be formatted does not have an associated era or period string.
         { L"hh", L"%I" },    // The two-digit hour in 12-hour format. Single-digit values are preceded by a zero.
         { L"h", L"%I" },     // The one-digit or the two-digit hour in 12-hour format.
         { L"HH", L"%H" },    // The two-digit hour in 24-hour format. Single-digit values are preceded by a zero.
         { L"H", L"%H" },     // The one-digit or the two-digit hour in 24-hour format.
         { L"mm", L"%M" },    // The two-digit minute. Single-digit values are preceded by a zero.
         { L"m", L"%M" },     // The one-digit or the two-digit minute.
         { L"ss", L"%S" },
         { L"s", L"%S" },
         { L"MMMM", L"%B" },  // The full month name.
         { L"MMM", L"%b" },   // The three-character month abbreviation.
         { L"MM", L"%m" },    // The two-digit month number. Single-digit values are preceded by a zero.
         { L"M", L"%m" },     // The one-digit or the two-digit month number.
         { L"tt", L"%p" },    // The two-letter A.M. and P.M. abbreviation (that is, AM is displayed as AM).
         { L"t", L"%p" },     // The one-letter A.M. and P.M. abbreviation (that is, AM is displayed as A).
         { L"yyy", L"%Y" },   // The full year. For example, 1998 would be displayed as 1998.
         { L"yy", L"%y" },    // The last two digits of the year. For example, 1998 would be displayed as 98.
         { L"y", L"%y" }      // The year is displayed as the last two digits, but with no leading zero for any year that is less than 10.
         };
   wxString newFmt;
   while (!format.IsEmpty()) {
      for (size_t i = 0; i < WXSIZEOF(conv); ++i) {
         if (format.StartsWith(conv[i].winfmt, &format)) {
            newFmt += conv[i].strffmt;
            break;
            }
         }
      if (WXSIZEOF(conv) == i) {
         newFmt += format[0];
         format = format.Mid(1);
         }
      }

   format = newFmt;
}
//-----------------------------------------------------------------------------

static wchar_t* fmt_winfmt(wchar_t* dest, wchar_t* end, const wchar_t* winfmt, const struct tm * t)
{
   wxString fmt(winfmt);
   convertfromw32fmt(fmt);
   return dest + wcsftime(dest, end-dest, fmt.c_str(), t);
}
//-----------------------------------------------------------------------------

static wchar_t* fmt_X(wchar_t* dest, wchar_t* end, const struct tm * t)
{
   // Time representation for current locale
   wxString sFmt = GetLocaleInfoStr(LOCALE_STIMEFORMAT);
   return fmt_winfmt(dest, end, sFmt.c_str(), t);;
}
//-----------------------------------------------------------------------------

static wchar_t* fmt_x(wchar_t* dest, wchar_t* end, const struct tm * t)
{
   // Date representation for current locale
   wxString sFmt = GetLocaleInfoStr(LOCALE_SSHORTDATE);
   return fmt_winfmt(dest, end, sFmt.c_str(), t);;
}
//-----------------------------------------------------------------------------

static wchar_t* fmt_c(wchar_t* dest, wchar_t* end, const struct tm * t)
{
   // Date and time representation appropriate for locale
   wxString sFmt = GetLocaleInfoStr(LOCALE_SSHORTDATE) + L" " + GetLocaleInfoStr(LOCALE_STIMEFORMAT);
   return fmt_winfmt(dest, end, sFmt.c_str(), t);;
}


///////////////////////////////////////////////////////////////////////////////
// wcsftime

size_t __cdecl wcsftime(wchar_t * dest, size_t maxsize, const wchar_t * format, const struct tm * t)
{
   if (0 == maxsize)
      return 0;

   wchar_t* cur = dest;
   wchar_t* end = dest + maxsize;

	for ( ; *format; ++format) {
      if (L'%' == *format) {
			switch (*++format) {
            case 0:
               // append %
               --format;
               break;
            case L'%':
               // append the flag
               break;
            default:
               typedef wchar_t*(*FmtHandler)(wchar_t* dest, wchar_t* end, const struct tm * t);
               #define hdl(c) { L#@c, fmt_##c }
               static const struct { wchar_t fmt; FmtHandler handler; }
                  handlers[] = {
                     hdl(a), hdl(A), hdl(b), hdl(B), hdl(d), hdl(H), hdl(I), hdl(m), hdl(M),
                     hdl(S), hdl(y), hdl(Y), hdl(j), hdl(U), hdl(w), hdl(W), hdl(p), hdl(X),
                     hdl(x), hdl(c),
                     hdl(z), { L'Z', fmt_z }
                     };
               #undef hdl
               size_t i;
               for (i = 0; i < WXSIZEOF(handlers); ++i)
                  if (handlers[i].fmt == *format) {
                     cur = handlers[i].handler(cur, end, t);
                     break;
                     }
               if (i < WXSIZEOF(handlers)) {
                  // handler found. continue with next format char, skip appending the flag
                  continue;
                  }
               // no handler found. append the flag
               break;
            }
         }
      if (cur != end)
         *cur++ = *format;
      }

	if (cur == end) {
      *--cur = 0;
		return 0;
   	}

	*cur = '\0';

	return cur - dest;
}
