/***************************************************************
 * Name:      wxDateTimeTestApp.cpp
 * Purpose:   Code for Application Class
 * Author:    ZamFear
 * Created:   2007-08-16
 * Copyright:
 * License:
 **************************************************************/

#ifdef WX_PRECOMP //
#include "wx_pch.h"
#endif

#ifdef __BORLANDC__
#pragma hdrstop
#endif //__BORLANDC__

#include "wxDateTimeTestApp.h"
#include "wxDateTimeTestMain.h"

IMPLEMENT_APP(wxDateTimeTestApp);

bool wxDateTimeTestApp::OnInit()
{
	wxDateTimeTestFrame* frame = new wxDateTimeTestFrame(0L, _("wxWidgets Application Template"));
	frame->SetIcon(wxICON(aaaa)); // To Set App Icon
	frame->Show();

	return true;
}
