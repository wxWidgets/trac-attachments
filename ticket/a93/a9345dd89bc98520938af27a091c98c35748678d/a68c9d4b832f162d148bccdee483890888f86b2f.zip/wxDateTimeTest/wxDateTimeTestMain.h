/***************************************************************
 * Name:      wxDateTimeTestMain.h
 * Purpose:   Defines Application Frame
 * Author:    ZamFear
 * Created:   2007-08-16
 * Copyright:
 * License:
 **************************************************************/

#ifndef WXDATETIMETESTMAIN_H
#define WXDATETIMETESTMAIN_H

#include "wxDateTimeTestApp.h"

class wxDateTimeTestFrame: public wxFrame
{
	public:
		wxDateTimeTestFrame(wxFrame *frame, const wxString& title);
		~wxDateTimeTestFrame();
	private:
		enum
		{
			idMenuQuit = 1000,
			idMenuAbout
		};
		void OnClose(wxCloseEvent& event);
		void OnQuit(wxCommandEvent& event);
		void OnAbout(wxCommandEvent& event);
		void OnPaint(wxPaintEvent& event);
		DECLARE_EVENT_TABLE()
};


#endif // wxDateTimeTestMAIN_H
