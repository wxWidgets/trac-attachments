/***************************************************************
 * Name:      wxDateTimeTestApp.h
 * Purpose:   Defines Application Class
 * Author:    ZamFear
 * Created:   2007-08-16
 * Copyright:
 * License:
 **************************************************************/

#ifndef WXDATETIMETESTAPP_H
#define WXDATETIMETESTAPP_H

#include <wx/wxprec.h>

#ifdef __BORLANDC__
    #pragma hdrstop
#endif

#ifndef WX_PRECOMP
    #include <wx/wx.h>
#endif

class wxDateTimeTestApp : public wxApp
{
	public:
		virtual bool OnInit();
};

#endif // wxDateTimeTestAPP_H
