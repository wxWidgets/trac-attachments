#ifndef MAINFRAME_H
#define MAINFRAME_H

#include <string>

#include <wx/wx.h>
#include <wx/aui/aui.h>

class MainFrame : public wxFrame
{
	wxAuiManager m_auiManager;
	wxAuiNotebook *m_auiNotebookWorkspace;

public:
	MainFrame(wxWindow *parent = 0, wxWindowID id = -1, std::string const &title = "");
	~MainFrame(void);
};

#endif
