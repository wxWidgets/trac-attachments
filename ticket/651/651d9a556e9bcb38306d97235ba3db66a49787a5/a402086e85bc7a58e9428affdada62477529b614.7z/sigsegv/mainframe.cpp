#include <stdexcept>
#include "mainframe.h"

MainFrame::MainFrame(wxWindow *parent, wxWindowID id, std::string const &title)
: wxFrame(parent, id, title)
{
	m_auiManager.SetManagedWindow(this);
	m_auiNotebookWorkspace = new wxAuiNotebook(this);
	m_auiNotebookWorkspace->AddPage(new wxPanel((wxFrame*)m_auiNotebookWorkspace), "Map 1", true);
	m_auiManager.AddPane(m_auiNotebookWorkspace, wxAuiPaneInfo().Center());

		throw std::logic_error("here is the crash!");
		m_auiManager.Update();
}

MainFrame::~MainFrame(void)
{
	m_auiManager.UnInit();
}

