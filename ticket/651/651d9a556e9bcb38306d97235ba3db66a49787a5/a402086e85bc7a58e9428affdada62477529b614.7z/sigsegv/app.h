#ifndef APP_H
#define APP_H

#include <wx/app.h>

class MainFrame;

class App : public wxApp
{
private:
	MainFrame *m_app;
public:
	virtual bool OnInit();
};
#endif
