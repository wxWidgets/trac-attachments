#include "app.h"

#include <exception>
#include "mainframe.h"

IMPLEMENT_APP(App)

bool App::OnInit()
{
	bool wxsOK = true;
	try
	{
		wxInitAllImageHandlers();

		if(wxsOK)
		{
			m_app = new MainFrame(0);

			m_app->Show();
			SetTopWindow(m_app);
			delete m_app;
		}
	}
	catch(std::exception &e)
	{
		wxsOK = true;
		wxMessageBox(e.what(), "Fatal exception");
	}

	return wxsOK;
}

