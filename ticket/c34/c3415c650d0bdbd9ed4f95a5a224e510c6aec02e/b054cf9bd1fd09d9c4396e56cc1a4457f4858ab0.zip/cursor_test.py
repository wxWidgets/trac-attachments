import wx
import cursor_collection

class Frame(wx.Frame):
    def __init__(self, parent):
        wx.Frame.__init__(self, parent)
        
        self.cursors = [cursor_collection.get_closed_grab(),
                        cursor_collection.get_open_grab()]
        self.i_current_cursor = 0
        self.SetCursor(self.cursors[self.i_current_cursor])
        
        self.Bind(wx.EVT_MOUSE_EVENTS, self.on_mouse)
        
        self.Show()
        
    def toggle_cursor(self):
        self.i_current_cursor = 1 - self.i_current_cursor
        self.SetCursor(self.cursors[self.i_current_cursor])
        
    def on_mouse(self, event):
        event.Skip()
        if event.LeftDown():
            self.toggle_cursor()

app = wx.PySimpleApp()
frame = Frame(None)
app.MainLoop()