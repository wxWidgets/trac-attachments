/////////////////////////////////////////////////////////////////////////////
// Name:        utffile.h
// Purpose:     wxUtfFile - encapsulates low-level "file descriptor" with BOM Unicode interpretation
// Author:      Andreas Pflug
// Modified by:
// Created:     22/09/03
// RCS-ID:      $Id:  $
// Copyright:   (c) 2003 Andreas Pflug <pgadmin@pse-consulting.de>
// Licence:     wxWindows licence
/////////////////////////////////////////////////////////////////////////////

#ifndef _WX_UTFFILEH__
#define _WX_UTFFILEH__

#if defined(__GNUG__) && !defined(__APPLE__)
#pragma interface "utffile.h"
#endif


#if wxUSE_FILE

#include  "wx/file.h"


class WXDLLIMPEXP_BASE wxUtfFile : public wxFile
{
public:
    wxUtfFile();
    wxUtfFile(const wxChar *szFileName, OpenMode mode = read, wxFontEncoding encoding=wxFONTENCODING_DEFAULT);
    wxUtfFile(int fd, wxFontEncoding encoding=wxFONTENCODING_DEFAULT);

    bool Create(const wxChar *szFileName, bool bOverwrite = FALSE, int access = wxS_DEFAULT, wxFontEncoding encoding=wxFONTENCODING_DEFAULT);
    bool Open(const wxChar *szFileName, OpenMode mode = read, int access = wxS_DEFAULT, wxFontEncoding encoding=wxFONTENCODING_DEFAULT);
    void Attach(int fd, wxFontEncoding encoding=wxFONTENCODING_DEFAULT);

    off_t Seek(off_t ofs, wxSeekMode mode = wxFromStart);
    off_t SeekEnd(off_t ofs = 0) { return Seek(ofs, wxFromEnd); }
    off_t Tell() const { return wxFile::Tell() - m_bomOffset; }
    off_t Length() const { return wxFile::Length() - m_bomOffset; }

    off_t Read(wxString& str, off_t nCount=(off_t)-1);
    bool Write(const wxString& str);

protected:

    void WriteBOM();
    void DetermineConversion(wxFontEncoding encoding);
    bool EvalBOM(wxFontEncoding encoding);

    wxMBConv *m_conversion;
    wxFontEncoding m_encoding;
    off_t m_bomOffset;
};


#endif // wxUSE_FILE

#endif // _WX_UTFFILEH__
