/////////////////////////////////////////////////////////////////////////////
// Name:        display.cpp
// Purpose:     MSW Implementation of wxDisplay class
// Author:      Royce Mitchell III
// Modified by:
// Created:     06/21/02
// RCS-ID:      $Id: display.cpp,v 0.0.0.3 2002/06/24 14:35:00 R3 Exp $
// Copyright:   (c) wxWindows team
// Licence:     wxWindows licence
/////////////////////////////////////////////////////////////////////////////

// ===========================================================================
// declarations
// ===========================================================================

// ---------------------------------------------------------------------------
// headers
// ---------------------------------------------------------------------------

#ifdef __GNUG__
    #pragma implementation "display.h"
#endif

// For compilers that support precompilation, includes "wx.h".
#include "wx/wxprec.h"

#ifdef __BORLANDC__
    #pragma hdrstop
#endif

#if wxUSE_DISPLAY

#ifndef WX_PRECOMP
   #include "wx/dynarray.h"
#endif

#include "wx/display.h"

// the following define is necessary to access the multi-monitor function
// declarations in a manner safe to use w/ Windows 95
#define COMPILE_MULTIMON_STUBS
#include "wx/msw/multimon.h"

// ---------------------------------------------------------------------------
// constants
// ---------------------------------------------------------------------------

// ---------------------------------------------------------------------------
// private functions
// ---------------------------------------------------------------------------

void wxmswInitDisplayRectArray();

// ----------------------------------------------------------------------------
// private classes
// ----------------------------------------------------------------------------

class wxmswDisplayInfo;

WX_DECLARE_OBJARRAY(wxmswDisplayInfo, wxmswDisplayInfoArray);

class wxmswDisplayInfo
{
public:
    DISPLAY_DEVICE dd;
    wxRect rect;
    int depth;
};

wxmswDisplayInfoArray g_wxmswDisplayInfoArray;

#include <wx/arrimpl.cpp> // this is a magic incantation which must be done!
WX_DEFINE_OBJARRAY(wxmswDisplayInfoArray);

// ===========================================================================
// implementation
// ===========================================================================

void wxmswInitDisplayInfoArray()
{
    if ( g_wxmswDisplayInfoArray.Count() )
        return;

    DISPLAY_DEVICE dd;

    // MSDN: Before calling EnumDisplayDevices, you must initialize the cb
    // member of DISPLAY_DEVICE to the size, in bytes, of DISPLAY_DEVICE
    dd.cb = sizeof(dd);

    // MSDN: In order to query all display devices in the system, call this
    // function in a loop, starting with iDevNum set to 0, and incrementing
    // iDevNum until the function fails.
    size_t iDevNum = 0;
    while ( EnumDisplayDevices ( NULL, iDevNum, &dd, 0 ) )
    {
        wxmswDisplayInfo* info = new wxmswDisplayInfo();
        memmove ( &(info->dd), &dd, sizeof(dd) );

        // get this display's rect
        HDC hdc = ::CreateDC ( NULL, (LPCSTR)dd.DeviceName, NULL, NULL );
        if ( !hdc )
        {
            wxLogLastError(wxT("CreateDC"));
            info->rect = wxRect ( 0, 0, -1, -1 );
        }
        else
        {
            POINT pt;
            if ( !::GetDCOrgEx ( hdc, &pt ) )
                wxLogLastError(wxT("GetDCOrgEx"));
            int w = ::GetDeviceCaps ( hdc, HORZRES );
            int h = ::GetDeviceCaps ( hdc, VERTRES );
            if ( !::DeleteDC ( hdc ) )
                wxLogLastError(wxT("DeleteDC"));
            info->rect = wxRect ( pt.x, pt.y, w, h );
        }

        // get this display's Depth
        DEVMODE devmode;
        memset ( &devmode, 0, sizeof(devmode) );

        // MSDN: Before calling EnumDisplaySettings, set the dmSize member to
        // sizeof(DEVMODE), and set the dmDriverExtra member to indicate the size,
        // in bytes, of the additional space available to receive private
        // driver-data.
        devmode.dmSize = sizeof(devmode);
        devmode.dmDriverExtra = 0;

        if ( !EnumDisplaySettings ( dd.DeviceName, ENUM_CURRENT_SETTINGS, &devmode ) )
        {
            wxLogLastError(wxT("EnumDisplaySettings"));
            devmode.dmFields = 0;
        }

        if ( !(devmode.dmFields&DM_BITSPERPEL) )
            info->depth = -1;
        else
            info->depth = devmode.dmBitsPerPel;

        // now add this display to the array
        g_wxmswDisplayInfoArray.Add ( info );

        iDevNum++;
    }
}

// ---------------------------------------------------------------------------
// wxDisplay
// ---------------------------------------------------------------------------

size_t wxDisplayBase::GetCount()
{
    return GetSystemMetrics ( SM_CMONITORS );
}

int wxDisplayBase::GetFromPoint ( const wxPoint& pt )
{
    if ( !g_wxmswDisplayInfoArray.Count() )
        wxmswInitDisplayInfoArray();

    size_t count = wxDisplayBase::GetCount(), index;

    for ( index = 0; index < count; index++ )
    {
        wxRect& r = g_wxmswDisplayInfoArray[index].rect;

        if ( (r.GetLeft()<=pt.x) && (r.GetRight()>pt.x)
            && (r.GetTop()<=pt.y) && (r.GetBottom()>pt.y) )
            return index;
    }

    return -1;
}

wxDisplay::wxDisplay ( size_t index ) : wxDisplayBase ( index )
{
    if ( !g_wxmswDisplayInfoArray.Count() )
        wxmswInitDisplayInfoArray();
}

wxRect wxDisplay::GetGeometry() const
{
    return g_wxmswDisplayInfoArray[m_index].rect;
}

int wxDisplay::GetDepth() const
{
    return g_wxmswDisplayInfoArray[m_index].depth;
}

wxString wxDisplay::GetName() const
{
    return wxString ( g_wxmswDisplayInfoArray[m_index].dd.DeviceName );
}

#endif//wxUSE_DISPLAY
