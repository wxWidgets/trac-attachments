/////////////////////////////////////////////////////////////////////////////
// Name:        display.h
// Purpose:     wxDisplay class customization for Mac
// Author:      Brian Victor
// Modified by: Royce Mitchell III
// Created:     06/21/02
// RCS-ID:      $Id: display.h,v 0.0.0.3 2002/06/24 16:16:00 R3 Exp $
// Copyright:   (c) wxWindows team
// Licence:     wxWindows licence
/////////////////////////////////////////////////////////////////////////////

#ifndef _WX_MAC_DISPLAY_H_
#define _WX_MAC_DISPLAY_H_

class wxDisplayMacPriv;

class WXDLLEXPORT wxDisplay : public wxDisplayBase
{
public:
    wxDisplay ( size_t index = 0 );

    virtual wxRect GetGeometry() const;
    virtual int GetDepth() const;
    virtual wxString GetName() const;


    ~wxDisplay();

private:
    wxDisplayMacPriv* m_priv;

    DECLARE_NO_COPY_CLASS(wxDisplay);
};

#endif // _WX_MAC_DISPLAY_H_
