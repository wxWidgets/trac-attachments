///////////////////////////////////////////////////////////////////////////////
// Name:        src/generic/clrpickerg.cpp
// Purpose:     wxGenericColourButton class implementation
// Author:      Francesco Montorsi (readapted code written by Vadim Zeitlin)
// Modified by:
// Created:     15/04/2006
// RCS-ID:      $Id$
// Copyright:   (c) Vadim Zeitlin, Francesco Montorsi
// Licence:     wxWindows licence
///////////////////////////////////////////////////////////////////////////////

// ============================================================================
// declarations
// ============================================================================

// ----------------------------------------------------------------------------
// headers
// ----------------------------------------------------------------------------

// For compilers that support precompilation, includes "wx.h".
#include "wx/wxprec.h"

#ifdef __BORLANDC__
    #pragma hdrstop
#endif

#ifndef WX_PRECOMP
    #include "wx/window.h"
#endif //WX_PRECOMP

#include "wx/clrpicker.h"
#include "wx/colordlg.h"


// ============================================================================
// implementation
// ============================================================================

#if wxUSE_COLOURPICKERCTRL

wxColourData wxGenericColourButton::s_data;
IMPLEMENT_DYNAMIC_CLASS(wxGenericColourButton, wxButton)

// ----------------------------------------------------------------------------
// wxGenericColourButton
// ----------------------------------------------------------------------------

bool wxGenericColourButton::Create( wxWindow *parent, wxWindowID id,
                        const wxColour &col, const wxPoint &pos,
                        const wxSize &size, long style,
                        const wxValidator& validator, const wxString &name)
{
    // create this button
    if (!wxButton::Create( parent, id, wxEmptyString, pos,
                           size, style, validator, name ))
    {
        wxFAIL_MSG( wxT("wxGenericColourButton creation failed") );
        return false;
    }

    // and handle user clicks on it
    Connect(wxEVT_COMMAND_BUTTON_CLICKED,
            wxCommandEventHandler(wxGenericColourButton::OnButtonClick),
            NULL, this);

    m_colour = col;
    UpdateColour();
    InitColourData();

    return true;
}

void wxGenericColourButton::InitColourData()
{
    s_data.SetChooseFull(true);
    for (int i = 0; i < 16; i++)
    {
        // fill with grey tones the custom colors palette
        wxColour colour(i*16, i*16, i*16);
        s_data.SetCustomColour(i, colour);
    }
}

void wxGenericColourButton::OnButtonClick(wxCommandEvent& WXUNUSED(ev))
{
    // update the wxColouData to be shown in the the dialog
    s_data.SetColour(m_colour);

    // create the colour dialog and display it
    wxColourDialog dlg(this, &s_data);
    if (dlg.ShowModal() == wxID_OK)
    {
        s_data = dlg.GetColourData();
        SetColour(s_data.GetColour());

        // fire an event
        wxColourPickerEvent event(this, GetId(), m_colour);
        GetEventHandler()->ProcessEvent(event);
    }
}

void wxGenericColourButton::UpdateColour()
{
    if ( !m_colour.Ok() )
        return;

    // some combinations of the fg/bg colours may be unreadable, so we use the
    // ~ operator to make sure fg colour is different enough from m_colour
    wxColour colFg(~m_colour.Red(), ~m_colour.Green(), ~m_colour.Blue());

    SetForegroundColour(colFg);
    SetBackgroundColour(m_colour);

    // NOTE: we use wxString(wxT("")) to avoid the following from GCC:
    //       error: operands to ?: have different types
    SetLabel((GetWindowStyle() & wxCLRP_SHOW_LABEL) ?
             m_colour.GetAsString(wxC2S_HTML_SYNTAX) : wxString(wxT("")));
}

#endif      // wxUSE_COLOURPICKERCTRL
