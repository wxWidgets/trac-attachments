///////////////////////////////////////////////////////////////////////////////
// Name:        src/generic/fontpickerg.cpp
// Purpose:     wxGenericFontButton class implementation
// Author:      Francesco Montorsi
// Modified by:
// Created:     15/04/2006
// RCS-ID:      $Id$
// Copyright:   (c) Francesco Montorsi
// Licence:     wxWindows licence
///////////////////////////////////////////////////////////////////////////////

// ============================================================================
// declarations
// ============================================================================

// ----------------------------------------------------------------------------
// headers
// ----------------------------------------------------------------------------

// For compilers that support precompilation, includes "wx.h".
#include "wx/wxprec.h"

#ifdef __BORLANDC__
    #pragma hdrstop
#endif

#ifndef WX_PRECOMP
    #include "wx/window.h"
#endif //WX_PRECOMP

#include "wx/fontpicker.h"
#include "wx/fontdlg.h"


// ============================================================================
// implementation
// ============================================================================

#if wxUSE_FONTPICKERCTRL

wxFontData wxGenericFontButton::s_data;
IMPLEMENT_DYNAMIC_CLASS(wxGenericFontButton, wxButton)

// ----------------------------------------------------------------------------
// wxGenericFontButton
// ----------------------------------------------------------------------------

bool wxGenericFontButton::Create( wxWindow *parent, wxWindowID id,
                        const wxFont &initial, const wxPoint &pos,
                        const wxSize &size, long style,
                        const wxValidator& validator, const wxString &name)
{
    wxString label = (style & wxFNTP_FONTDESC_AS_LABEL) ?
                        wxEmptyString : // label will be updated by UpdateFont
                        wxT("Choose font");

    // create this button
    if (!wxButton::Create( parent, id, label, pos,
                           size, style, validator, name ))
    {
        wxFAIL_MSG( wxT("wxGenericFontButton creation failed") );
        return false;
    }

    // and handle user clicks on it
    Connect(wxEVT_COMMAND_BUTTON_CLICKED,
            wxCommandEventHandler(wxGenericFontButton::OnButtonClick),
            NULL, this);

    m_selectedFont = initial;
    UpdateFont();
    InitFontData();

    return true;
}

void wxGenericFontButton::InitFontData()
{
    s_data.SetAllowSymbols(true);
    s_data.SetColour(*wxBLACK);
    s_data.EnableEffects(true);
}

void wxGenericFontButton::OnButtonClick(wxCommandEvent& WXUNUSED(ev))
{
    // update the wxFontData to be shown in the the dialog
    s_data.SetInitialFont(m_selectedFont);

    // create the font dialog and display it
    wxFontDialog dlg(this, s_data);
    if (dlg.ShowModal() == wxID_OK)
    {
        s_data = dlg.GetFontData();
        SetSelectedFont(s_data.GetChosenFont());

        // fire an event
        wxFontPickerEvent event(this, GetId(), m_selectedFont);
        GetEventHandler()->ProcessEvent(event);
    }
}

void wxGenericFontButton::UpdateFont()
{
    if ( !m_selectedFont.Ok() )
        return;

    SetForegroundColour(s_data.GetColour());

    if (HasFlag(wxFNTP_USEFONT_FOR_LABEL))
        wxButton::SetFont(m_selectedFont);        // use currently selected font for the label...

    if (HasFlag(wxFNTP_FONTDESC_AS_LABEL))
        SetLabel(wxString::Format(wxT("%s, %d"),
                 m_selectedFont.GetFaceName().c_str(), m_selectedFont.GetPointSize()));
}

#endif      // wxUSE_FONTPICKERCTRL
