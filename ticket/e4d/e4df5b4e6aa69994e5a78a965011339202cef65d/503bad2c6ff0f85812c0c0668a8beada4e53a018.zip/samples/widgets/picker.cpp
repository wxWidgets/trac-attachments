/////////////////////////////////////////////////////////////////////////////
// Program:     wxWidgets Widgets Sample
// Name:        picker.cpp
// Purpose:     Part of the widgets sample showing wx*PickerCtrl
// Author:      Francesco Montorsi
// Created:     22/4/2006
// Id:          $Id$
// Copyright:   (c) 2006 Francesco Montorsi
// License:     wxWindows license
/////////////////////////////////////////////////////////////////////////////

// ============================================================================
// declarations
// ============================================================================

// ----------------------------------------------------------------------------
// headers
// ----------------------------------------------------------------------------

// for compilers that support precompilation, includes "wx/wx.h".
#include "wx/wxprec.h"

#ifdef __BORLANDC__
    #pragma hdrstop
#endif

#if wxUSE_COLOURPICKERCTRL || wxUSE_FILEPICKERCTRL || wxUSE_DIRPICKERCTRL || wxUSE_FONTPICKERCTRL

// for all others, include the necessary headers
#ifndef WX_PRECOMP
    #include "wx/app.h"
    #include "wx/log.h"
#endif

#include "wx/artprov.h"
#include "wx/sizer.h"
#include "wx/stattext.h"
#include "wx/checkbox.h"

#include "wx/clrpicker.h"
#include "wx/filepicker.h"
#include "wx/fontpicker.h"

#include "widgets.h"

#include "icons/picker.xpm"

// ----------------------------------------------------------------------------
// constants
// ----------------------------------------------------------------------------

// control ids
enum
{
    PickerPage_Reset = wxID_HIGHEST,

#if wxUSE_COLOURPICKERCTRL
    PickerPage_Colour,
#endif
#if wxUSE_FILEPICKERCTRL
    PickerPage_File,
#endif
#if wxUSE_DIRPICKERCTRL
    PickerPage_Dir,
#endif
#if wxUSE_FONTPICKERCTRL
    PickerPage_Font
#endif
};


// ----------------------------------------------------------------------------
// PickerWidgetsPage
// ----------------------------------------------------------------------------

class PickerWidgetsPage : public WidgetsPage
{
public:
    PickerWidgetsPage(WidgetsBookCtrl *book, wxImageList *imaglist);
    virtual ~PickerWidgetsPage(){};

    virtual wxControl *GetWidget() const { /*return m_fontPicker;*/ return NULL; }
    virtual void RecreateWidget() { ReCreatePickers(); }

protected:
    // construction
    void CreatePickers(int picker);         // called only once at first construction
    void ReCreatePickers(int picker = -1);  // -1 = all pickers
    void Reset();
    long GetPickerStyle(int);

    // the pickers and the relative event handlers
#if wxUSE_COLOURPICKERCTRL
    wxColourPickerCtrl *m_clrPicker;
    void OnColourChange(wxColourPickerEvent &ev);
#endif
#if wxUSE_FILEPICKERCTRL
    wxFilePickerCtrl *m_filePicker;
    void OnFileChange(wxFileDirPickerEvent &ev);
#endif
#if wxUSE_DIRPICKERCTRL
    wxDirPickerCtrl *m_dirPicker;
    void OnDirChange(wxFileDirPickerEvent &ev);
#endif
#if wxUSE_FONTPICKERCTRL
    wxFontPickerCtrl *m_fontPicker;
    void OnFontChange(wxFontPickerEvent &ev);
#endif
    void OnCheckBox(wxCommandEvent &ev);
    void OnButtonReset(wxCommandEvent &ev);


    // other controls
    // --------------

    wxCheckBox *m_chkColourTextCtrl, *m_chkColourShowLabel;
    wxCheckBox *m_chkFileTextCtrl, *m_chkFileOverwritePrompt,
               *m_chkFileMustExist, *m_chkFileChangeDir;
    wxCheckBox *m_chkDirTextCtrl, *m_chkDirChangeDir, *m_chkDirMustExist;
    wxCheckBox *m_chkFontTextCtrl, *m_chkFontDescAsLabel, *m_chkFontUseFontForLabel;
    wxFlexGridSizer *m_sizerPicker;

private:
    DECLARE_EVENT_TABLE()
    DECLARE_WIDGETS_PAGE(PickerWidgetsPage)
};

// ----------------------------------------------------------------------------
// event tables
// ----------------------------------------------------------------------------

BEGIN_EVENT_TABLE(PickerWidgetsPage, WidgetsPage)
    EVT_BUTTON(PickerPage_Reset, PickerWidgetsPage::OnButtonReset)

#if wxUSE_COLOURPICKERCTRL
    EVT_COLOURPICKER_CHANGED(PickerPage_Colour, PickerWidgetsPage::OnColourChange)
#endif
#if wxUSE_FILEPICKERCTRL
    EVT_FILEPICKER_CHANGED(PickerPage_File, PickerWidgetsPage::OnFileChange)
#endif
#if wxUSE_DIRPICKERCTRL
    EVT_DIRPICKER_CHANGED(PickerPage_Dir, PickerWidgetsPage::OnDirChange)
#endif
#if wxUSE_FONTPICKERCTRL
    EVT_FONTPICKER_CHANGED(PickerPage_Font, PickerWidgetsPage::OnFontChange)
#endif

    EVT_CHECKBOX(wxID_ANY, PickerWidgetsPage::OnCheckBox)
END_EVENT_TABLE()

// ============================================================================
// implementation
// ============================================================================

IMPLEMENT_WIDGETS_PAGE(PickerWidgetsPage, _T("Pickers"), PICKER_CTRLS);

PickerWidgetsPage::PickerWidgetsPage(WidgetsBookCtrl *book,
                                     wxImageList *imaglist)
                  : WidgetsPage(book, imaglist, picker_xpm)
{
    imaglist->Add(wxBitmap(picker_xpm));

    // left pane
    wxSizer *boxleft = new wxBoxSizer(wxVERTICAL);

#if wxUSE_COLOURPICKERCTRL
    wxStaticBoxSizer *clrbox = new wxStaticBoxSizer(wxVERTICAL, this, _T("&ColourPicker style"));
    //clrbox->Add(5, 5, 0, wxGROW | wxALL, 5); // spacer
    m_chkColourTextCtrl = CreateCheckBoxAndAddToSizer(clrbox, _T("With textctrl"), false);
    m_chkColourShowLabel = CreateCheckBoxAndAddToSizer(clrbox, _T("With label"), false);
    boxleft->Add(clrbox, 0, wxALL|wxGROW, 5);
    boxleft->Add(1, 1, 1, wxGROW | wxALL, 5); // spacer
#endif
#if wxUSE_FILEPICKERCTRL
    wxStaticBoxSizer *filebox = new wxStaticBoxSizer(wxVERTICAL, this, _T("&FilePicker style"));
    //filebox->Add(5, 5, 0, wxGROW | wxALL, 5); // spacer
    m_chkFileTextCtrl = CreateCheckBoxAndAddToSizer(filebox, _T("With textctrl"), false);
    m_chkFileOverwritePrompt = CreateCheckBoxAndAddToSizer(filebox, _T("Overwrite prompt"), false);
    m_chkFileMustExist = CreateCheckBoxAndAddToSizer(filebox, _T("File must exist"), false);
    m_chkFileChangeDir = CreateCheckBoxAndAddToSizer(filebox, _T("Change working dir"), false);
    boxleft->Add(filebox, 0, wxALL|wxGROW, 5);
    boxleft->Add(1, 1, 1, wxGROW | wxALL, 5); // spacer
#endif
#if wxUSE_DIRPICKERCTRL
    wxStaticBoxSizer *dirbox = new wxStaticBoxSizer(wxVERTICAL, this, _T("&DirPicker style"));
    //dirbox->Add(5, 5, 0, wxGROW | wxALL, 5); // spacer
    m_chkDirTextCtrl = CreateCheckBoxAndAddToSizer(dirbox, _T("With textctrl"), false);
    m_chkDirMustExist = CreateCheckBoxAndAddToSizer(dirbox, _T("Dir must exist"), false);
    m_chkDirChangeDir = CreateCheckBoxAndAddToSizer(dirbox, _T("Change working dir"), false);
    boxleft->Add(dirbox, 0, wxALL|wxGROW, 5);
    boxleft->Add(1, 1, 1, wxGROW | wxALL, 5); // spacer
#endif
#if wxUSE_FONTPICKERCTRL
    wxStaticBoxSizer *fontbox = new wxStaticBoxSizer(wxVERTICAL, this, _T("&FontPicker style"));
    //fontbox->Add(5, 5, 0, wxGROW | wxALL, 5); // spacer
    m_chkFontTextCtrl = CreateCheckBoxAndAddToSizer(fontbox, _T("With textctrl"));
    m_chkFontDescAsLabel = CreateCheckBoxAndAddToSizer(fontbox, _T("Font desc as btn label"));
    m_chkFontUseFontForLabel = CreateCheckBoxAndAddToSizer(fontbox, _T("Use font for label"), false);
    //fontbox->Add(5, 5, 0, wxGROW | wxALL, 5); // spacer
    boxleft->Add(fontbox, 0, wxALL|wxGROW, 5);
#endif
    boxleft->Add(new wxButton(this, PickerPage_Reset, _T("&Reset")),
                 0, wxALIGN_CENTRE_HORIZONTAL | wxALL, 15);

    Reset();    // set checkboxes state

    // create pickers
    m_clrPicker = NULL;
    m_filePicker = NULL;
    m_fontPicker = NULL;
    m_dirPicker = NULL;
    CreatePickers(-1);

    // right pane
    wxStaticBoxSizer *boxright = new wxStaticBoxSizer(wxVERTICAL, this, _T("Pickers"));
    int nrows = 0;
#if wxUSE_COLOURPICKERCTRL
    nrows++;
#endif
#if wxUSE_FILEPICKERCTRL
    nrows++;
#endif
#if wxUSE_DIRPICKERCTRL
    nrows++;
#endif
#if wxUSE_FONTPICKERCTRL
    nrows++;
#endif

    m_sizerPicker = new wxFlexGridSizer(nrows, 2, 0, 0);      // 4 rows x 2 columns
#if wxUSE_COLOURPICKERCTRL
    m_sizerPicker->Add(new wxStaticText(this, wxID_ANY, wxT("wxColourPickerCtrl:")),
                       1, wxALIGN_CENTER | wxALL, 5);
    m_sizerPicker->Add(m_clrPicker, 1, wxGROW | wxALL, 5);
#endif
#if wxUSE_FILEPICKERCTRL
    m_sizerPicker->Add(new wxStaticText(this, wxID_ANY, wxT("wxFilePickerCtrl:")),
                       1, wxALIGN_CENTER | wxALL, 5);
    m_sizerPicker->Add(m_filePicker, 1, wxGROW | wxALL, 5);
#endif
#if wxUSE_DIRPICKERCTRL
    m_sizerPicker->Add(new wxStaticText(this, wxID_ANY, wxT("wxDirPickerCtrl:")),
                       1, wxALIGN_CENTER | wxALL, 5);
    m_sizerPicker->Add(m_dirPicker, 1, wxGROW | wxALL, 5);
#endif
#if wxUSE_FONTPICKERCTRL
    m_sizerPicker->Add(new wxStaticText(this, wxID_ANY, wxT("wxFontPickerCtrl:")),
                       1, wxALIGN_CENTER | wxALL, 5);
    m_sizerPicker->Add(m_fontPicker, 1, wxGROW | wxALL, 5);
#endif

    m_sizerPicker->AddGrowableCol(1, 3);
    for (int j=0; j < nrows; j++)
        m_sizerPicker->AddGrowableRow(j, 1);
    boxright->Add(m_sizerPicker, 1, wxGROW|wxALL, 5);

    // global pane
    wxSizer *sz = new wxBoxSizer(wxHORIZONTAL);
    sz->Add(boxleft, 0, wxGROW|wxALL, 5);
    sz->Add(boxright, 1, wxGROW|wxALL, 5);

    SetSizer(sz);
    sz->Fit(this);
}

void PickerWidgetsPage::CreatePickers(int picker)
{
#if wxUSE_COLOURPICKERCTRL
    if (picker == -1 || picker == 0)
    {
        wxDELETE(m_clrPicker);
        m_clrPicker = new wxColourPickerCtrl(this, PickerPage_Colour, *wxRED,
                            wxDefaultPosition, wxDefaultSize, GetPickerStyle(0));
    }
#endif
#if wxUSE_FILEPICKERCTRL
    if (picker == -1 || picker == 1)
    {
        wxDELETE(m_filePicker);

        // pass an empty string as initial file
        m_filePicker = new wxFilePickerCtrl(this, PickerPage_File, wxEmptyString,
                            wxT("Hello!"), wxT("*"), wxDefaultPosition, wxDefaultSize,
                             GetPickerStyle(1));
    }
#endif
#if wxUSE_DIRPICKERCTRL
    if (picker == -1 || picker == 2)
    {
        wxDELETE(m_dirPicker);
        m_dirPicker = new wxDirPickerCtrl(this, PickerPage_Dir, wxGetHomeDir(),
                            wxT("Hello!"), wxDefaultPosition, wxDefaultSize,
                             GetPickerStyle(2));
    }
#endif
#if wxUSE_FONTPICKERCTRL
    if (picker == -1 || picker == 3)
    {
        wxDELETE(m_fontPicker);
        m_fontPicker = new wxFontPickerCtrl(this, PickerPage_Font, *wxSWISS_FONT,
                            wxDefaultPosition, wxDefaultSize, GetPickerStyle(3));
    }
#endif
}

long PickerWidgetsPage::GetPickerStyle(int picker)
{
    long addstyle = 0;

    switch (picker)
    {
#if wxUSE_COLOURPICKERCTRL
    case 0:
        return (m_chkColourTextCtrl->GetValue() ? wxCLRP_USE_TEXTCTRL : 0) |
                 (m_chkColourShowLabel->GetValue() ? wxCLRP_SHOW_LABEL : 0) |
                 addstyle;
#endif
#if wxUSE_FILEPICKERCTRL
    case 1:
        return (m_chkFileTextCtrl->GetValue() ? wxFLP_USE_TEXTCTRL : 0) |
                (m_chkFileOverwritePrompt->GetValue() ? wxFLP_OVERWRITE_PROMPT : 0) |
                (m_chkFileMustExist->GetValue() ? wxFLP_FILE_MUST_EXIST : 0) |
                (m_chkFileChangeDir->GetValue() ? wxFLP_CHANGE_DIR : 0) |
                 addstyle;
#endif
#if wxUSE_DIRPICKERCTRL
    case 2:
        return (m_chkDirTextCtrl->GetValue() ? wxDIRP_USE_TEXTCTRL : 0) |
                (m_chkDirMustExist->GetValue() ? wxDIRP_DIR_MUST_EXIST : 0) |
                (m_chkDirChangeDir->GetValue() ? wxDIRP_CHANGE_DIR : 0) |
                addstyle;
#endif
#if wxUSE_FONTPICKERCTRL
    case 3:
        return (m_chkFontTextCtrl->GetValue() ? wxFNTP_USE_TEXTCTRL : 0) |
                 (m_chkFontUseFontForLabel->GetValue() ? wxFNTP_USEFONT_FOR_LABEL : 0) |
                 (m_chkFontDescAsLabel->GetValue() ? wxFNTP_FONTDESC_AS_LABEL : 0) |
                 addstyle;
#endif

    default:
        wxASSERT(0);
        return -1;
    }
}

void PickerWidgetsPage::ReCreatePickers(int picker)
{
#if wxUSE_COLOURPICKERCTRL
    if (picker == -1 || picker == 0)
    {
        // recreate COLOUR picker
        wxASSERT(m_sizerPicker->Remove(1));
        CreatePickers(0);
        m_sizerPicker->Insert(1, m_clrPicker, 1, wxGROW|wxALL, 5);
    }
#endif
#if wxUSE_FILEPICKERCTRL
    if (picker == -1 || picker == 1)
    {
        // recreate FILE picker
        wxASSERT(m_sizerPicker->Remove(3));
        CreatePickers(1);
        m_sizerPicker->Insert(3, m_filePicker, 1, wxGROW|wxALL, 5);
    }
#endif
#if wxUSE_DIRPICKERCTRL
    if (picker == -1 || picker == 2)
    {
        // recreate DIR picker
        wxASSERT(m_sizerPicker->Remove(5));
        CreatePickers(2);
        m_sizerPicker->Insert(5, m_dirPicker, 1, wxGROW|wxALL, 5);
    }
#endif
#if wxUSE_FONTPICKERCTRL
    if (picker == -1 || picker == 3)
    {
        // recreate FONT picker
        wxASSERT(m_sizerPicker->Remove(7));
        CreatePickers(3);
        m_sizerPicker->Insert(7, m_fontPicker, 1, wxGROW|wxALL, 5);
    }
#endif

    m_sizerPicker->Layout();
}

void PickerWidgetsPage::Reset()
{
#if wxUSE_COLOURPICKERCTRL
    m_chkColourTextCtrl->SetValue((wxCLRP_DEFAULT_STYLE & wxCLRP_USE_TEXTCTRL) != 0);
    m_chkColourShowLabel->SetValue((wxCLRP_DEFAULT_STYLE & wxCLRP_SHOW_LABEL) != 0);
#endif
#if wxUSE_FILEPICKERCTRL
    m_chkFileTextCtrl->SetValue((wxFLP_DEFAULT_STYLE & wxFLP_USE_TEXTCTRL) != 0);
    m_chkFileOverwritePrompt->SetValue((wxFLP_DEFAULT_STYLE & wxFLP_OVERWRITE_PROMPT) != 0);
    m_chkFileMustExist->SetValue((wxFLP_DEFAULT_STYLE & wxFLP_FILE_MUST_EXIST) != 0);
    m_chkFileChangeDir->SetValue((wxFLP_DEFAULT_STYLE & wxFLP_CHANGE_DIR) != 0);
#endif
#if wxUSE_DIRPICKERCTRL
    m_chkDirTextCtrl->SetValue((wxDIRP_DEFAULT_STYLE & wxDIRP_USE_TEXTCTRL) != 0);
    m_chkDirMustExist->SetValue((wxDIRP_DEFAULT_STYLE & wxDIRP_DIR_MUST_EXIST) != 0);
    m_chkDirChangeDir->SetValue((wxDIRP_DEFAULT_STYLE & wxDIRP_CHANGE_DIR) != 0);
#endif
#if wxUSE_FONTPICKERCTRL
    m_chkFontTextCtrl->SetValue((wxFNTP_DEFAULT_STYLE & wxFNTP_USE_TEXTCTRL) != 0);
    m_chkFontUseFontForLabel->SetValue((wxFNTP_DEFAULT_STYLE & wxFNTP_USEFONT_FOR_LABEL) != 0);
    m_chkFontDescAsLabel->SetValue((wxFNTP_DEFAULT_STYLE & wxFNTP_FONTDESC_AS_LABEL) != 0);
#endif
}


// ----------------------------------------------------------------------------
// event handlers
// ----------------------------------------------------------------------------

void PickerWidgetsPage::OnButtonReset(wxCommandEvent& WXUNUSED(event))
{
    Reset();

    ReCreatePickers();
}

#if wxUSE_COLOURPICKERCTRL
void PickerWidgetsPage::OnColourChange(wxColourPickerEvent& event)
{
    wxLogMessage(wxT("The colour changed to '%s' !"),
                 event.GetColour().GetAsString(wxC2S_CSS_SYNTAX).c_str());
}
#endif
#if wxUSE_FILEPICKERCTRL
void PickerWidgetsPage::OnFileChange(wxFileDirPickerEvent& event)
{
    wxLogMessage(wxT("The file changed to '%s' ! The current working directory is '%s'"),
                 event.GetPath().c_str(), wxGetCwd().c_str());
}
#endif
#if wxUSE_DIRPICKERCTRL
void PickerWidgetsPage::OnDirChange(wxFileDirPickerEvent& event)
{
    wxLogMessage(wxT("The directory changed to '%s' ! The current working directory is '%s'"),
                 event.GetPath().c_str(), wxGetCwd().c_str());
}
#endif
#if wxUSE_FONTPICKERCTRL
void PickerWidgetsPage::OnFontChange(wxFontPickerEvent& event)
{
    wxLogMessage(wxT("The font changed to '%s' with size %d !"),
                 event.GetFont().GetFaceName().c_str(), event.GetFont().GetPointSize());
}
#endif

void PickerWidgetsPage::OnCheckBox(wxCommandEvent &event)
{
    if (event.GetEventObject() == m_chkColourTextCtrl ||
        event.GetEventObject() == m_chkColourShowLabel)
        ReCreatePickers(0);

    if (event.GetEventObject() == m_chkFileTextCtrl ||
        event.GetEventObject() == m_chkFileOverwritePrompt ||
        event.GetEventObject() == m_chkFileMustExist ||
        event.GetEventObject() == m_chkFileChangeDir)
        ReCreatePickers(1);

    if (event.GetEventObject() == m_chkDirTextCtrl ||
        event.GetEventObject() == m_chkDirChangeDir ||
        event.GetEventObject() == m_chkDirMustExist)
        ReCreatePickers(2);

    if (event.GetEventObject() == m_chkFontTextCtrl ||
        event.GetEventObject() == m_chkFontDescAsLabel ||
        event.GetEventObject() == m_chkFontUseFontForLabel)
        ReCreatePickers(3);
}

#endif  // wxUSE_COLOURPICKERCTRL || wxUSE_FILEPICKERCTRL || wxUSE_DIRPICKERCTRL || wxUSE_FONTPICKERCTRL
