/***************************************************************
 * Name:      Test302App.h
 * Purpose:   Defines Application Class
 * Author:     ()
 * Created:   2014-10-16
 * Copyright:  ()
 * License:
 **************************************************************/

#ifndef TEST302APP_H
#define TEST302APP_H

#include <wx/app.h>

class Test302App : public wxApp
{
    public:
        virtual bool OnInit();
};

#endif // TEST302APP_H
