/***************************************************************
 * Name:      Test302Main.cpp
 * Purpose:   Code for Application Frame
 * Author:     ()
 * Created:   2014-10-16
 * Copyright:  ()
 * License:
 **************************************************************/

#include "Test302Main.h"
#include <wx/msgdlg.h>

//(*InternalHeaders(Test302Dialog)
#include <wx/intl.h>
#include <wx/string.h>
//*)

//helper functions
enum wxbuildinfoformat {
    short_f, long_f };

wxString wxbuildinfo(wxbuildinfoformat format)
{
    wxString wxbuild(wxVERSION_STRING);

    if (format == long_f )
    {
#if defined(__WXMSW__)
        wxbuild << _T("-Windows");
#elif defined(__UNIX__)
        wxbuild << _T("-Linux");
#endif

#if wxUSE_UNICODE
        wxbuild << _T("-Unicode build");
#else
        wxbuild << _T("-ANSI build");
#endif // wxUSE_UNICODE
    }

    return wxbuild;
}

//(*IdInit(Test302Dialog)
const long Test302Dialog::ID_RADIOBOX1 = wxNewId();
const long Test302Dialog::ID_BUTTON1 = wxNewId();
const long Test302Dialog::ID_BUTTON2 = wxNewId();
//*)

BEGIN_EVENT_TABLE(Test302Dialog,wxDialog)
    //(*EventTable(Test302Dialog)
    //*)
END_EVENT_TABLE()

Test302Dialog::Test302Dialog(wxWindow* parent,wxWindowID id)
{
    //(*Initialize(Test302Dialog)
    Create(parent, id, _("wxWidgets app"), wxDefaultPosition, wxDefaultSize, wxDEFAULT_DIALOG_STYLE, _T("id"));
    SetClientSize(wxSize(428,282));
    RadioBox1 = new wxRadioBox(this, ID_RADIOBOX1, _("Label"), wxPoint(48,56), wxSize(124,148), 0, 0, 1, 0, wxDefaultValidator, _T("ID_RADIOBOX1"));
    Button1 = new wxButton(this, ID_BUTTON1, _("with _T"), wxPoint(284,68), wxDefaultSize, 0, wxDefaultValidator, _T("ID_BUTTON1"));
    Button2 = new wxButton(this, ID_BUTTON2, _("without _T"), wxPoint(288,136), wxDefaultSize, 0, wxDefaultValidator, _T("ID_BUTTON2"));

    Connect(ID_BUTTON1,wxEVT_COMMAND_BUTTON_CLICKED,(wxObjectEventFunction)&Test302Dialog::OnButton1Click);
    Connect(ID_BUTTON2,wxEVT_COMMAND_BUTTON_CLICKED,(wxObjectEventFunction)&Test302Dialog::OnButton2Click);
    //*)
}

Test302Dialog::~Test302Dialog()
{
    //(*Destroy(Test302Dialog)
    //*)
}

void Test302Dialog::OnQuit(wxCommandEvent& event)
{
    Close();
}

void Test302Dialog::OnAbout(wxCommandEvent& event)
{
    wxString msg = wxbuildinfo(long_f);
    wxMessageBox(msg, _("Welcome to..."));
}

void Test302Dialog::OnButton1Click(wxCommandEvent& event)
{
	wxMessageBox(_T("Français 漢字"));
}

void Test302Dialog::OnButton2Click(wxCommandEvent& event)
{
	wxMessageBox("Français 漢字");
}
