/***************************************************************
 * Name:      Test302Main.h
 * Purpose:   Defines Application Frame
 * Author:     ()
 * Created:   2014-10-16
 * Copyright:  ()
 * License:
 **************************************************************/

#ifndef TEST302MAIN_H
#define TEST302MAIN_H

//(*Headers(Test302Dialog)
#include <wx/radiobox.h>
#include <wx/button.h>
#include <wx/dialog.h>
//*)

class Test302Dialog: public wxDialog
{
    public:

        Test302Dialog(wxWindow* parent,wxWindowID id = -1);
        virtual ~Test302Dialog();

    private:

        //(*Handlers(Test302Dialog)
        void OnQuit(wxCommandEvent& event);
        void OnAbout(wxCommandEvent& event);
        void OnButton1Click(wxCommandEvent& event);
        void OnButton2Click(wxCommandEvent& event);
        //*)

        //(*Identifiers(Test302Dialog)
        static const long ID_RADIOBOX1;
        static const long ID_BUTTON1;
        static const long ID_BUTTON2;
        //*)

        //(*Declarations(Test302Dialog)
        wxButton* Button1;
        wxButton* Button2;
        wxRadioBox* RadioBox1;
        //*)

        DECLARE_EVENT_TABLE()
};

#endif // TEST302MAIN_H
