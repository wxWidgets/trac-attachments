/***************************************************************
 * Name:      Test302App.cpp
 * Purpose:   Code for Application Class
 * Author:     ()
 * Created:   2014-10-16
 * Copyright:  ()
 * License:
 **************************************************************/

#include "Test302App.h"

//(*AppHeaders
#include "Test302Main.h"
#include <wx/image.h>
//*)

IMPLEMENT_APP(Test302App);

bool Test302App::OnInit()
{
    //(*AppInitialize
    bool wxsOK = true;
    wxInitAllImageHandlers();
    if ( wxsOK )
    {
    Test302Dialog Dlg(0);
    SetTopWindow(&Dlg);
    Dlg.ShowModal();
    wxsOK = false;
    }
    //*)
    return wxsOK;

}
