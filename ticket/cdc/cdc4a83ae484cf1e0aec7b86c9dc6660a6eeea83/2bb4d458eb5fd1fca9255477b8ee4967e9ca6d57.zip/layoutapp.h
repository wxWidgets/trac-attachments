/////////////////////////////////////////////////////////////////////////////
// Name:        layoutapp.h
// Purpose:     
// Author:      Greg Hazel
// Modified by: 
// Created:     06/01/05 22:12:41
// RCS-ID:      
// Copyright:   
// Licence:     
/////////////////////////////////////////////////////////////////////////////

#ifndef _LAYOUTAPP_H_
#define _LAYOUTAPP_H_

#if defined(__GNUG__) && !defined(__APPLE__)
#pragma interface "layoutapp.cpp"
#endif

/*!
 * Includes
 */

////@begin includes
#include "wx/image.h"
#include "layoutbug.h"
////@end includes

/*!
 * Forward declarations
 */

////@begin forward declarations
////@end forward declarations

/*!
 * Control identifiers
 */

////@begin control identifiers
////@end control identifiers

/*!
 * LayoutApp class declaration
 */

class LayoutApp: public wxApp
{    
    DECLARE_CLASS( LayoutApp )
    DECLARE_EVENT_TABLE()

public:
    /// Constructor
    LayoutApp();

    /// Initialises the application
    virtual bool OnInit();

    /// Called on exit
    virtual int OnExit();

////@begin LayoutApp event handler declarations

////@end LayoutApp event handler declarations

////@begin LayoutApp member function declarations

////@end LayoutApp member function declarations

////@begin LayoutApp member variables
////@end LayoutApp member variables
};

/*!
 * Application instance declaration 
 */

////@begin declare app
DECLARE_APP(LayoutApp)
////@end declare app

#endif
    // _LAYOUTAPP_H_
