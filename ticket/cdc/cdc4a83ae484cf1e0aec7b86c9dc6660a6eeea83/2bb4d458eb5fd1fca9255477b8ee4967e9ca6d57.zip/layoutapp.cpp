/////////////////////////////////////////////////////////////////////////////
// Name:        layoutapp.cpp
// Purpose:     
// Author:      Greg Hazel
// Modified by: 
// Created:     06/01/05 22:12:41
// RCS-ID:      
// Copyright:   
// Licence:     
/////////////////////////////////////////////////////////////////////////////

#if defined(__GNUG__) && !defined(__APPLE__)
#pragma implementation "layoutapp.h"
#endif

// For compilers that support precompilation, includes "wx/wx.h".
#include "wx/wxprec.h"

#ifdef __BORLANDC__
#pragma hdrstop
#endif

#ifndef WX_PRECOMP
#include "wx/wx.h"
#endif

////@begin includes
////@end includes

#include "layoutapp.h"

////@begin XPM images
////@end XPM images

/*!
 * Application instance implementation
 */

////@begin implement app
IMPLEMENT_APP( LayoutApp )
////@end implement app

/*!
 * LayoutApp type definition
 */

IMPLEMENT_CLASS( LayoutApp, wxApp )

/*!
 * LayoutApp event table definition
 */

BEGIN_EVENT_TABLE( LayoutApp, wxApp )

////@begin LayoutApp event table entries
////@end LayoutApp event table entries

END_EVENT_TABLE()

/*!
 * Constructor for LayoutApp
 */

LayoutApp::LayoutApp()
{
////@begin LayoutApp member initialisation
////@end LayoutApp member initialisation
}

/*!
 * Initialisation for LayoutApp
 */

bool LayoutApp::OnInit()
{    
////@begin LayoutApp initialisation
    // Remove the comment markers above and below this block
    // to make permanent changes to the code.

#if wxUSE_XPM
    wxImage::AddHandler( new wxXPMHandler );
#endif
#if wxUSE_LIBPNG
    wxImage::AddHandler( new wxPNGHandler );
#endif
#if wxUSE_LIBJPEG
    wxImage::AddHandler( new wxJPEGHandler );
#endif
#if wxUSE_GIF
    wxImage::AddHandler( new wxGIFHandler );
#endif
    LBFrame* mainWindow = new LBFrame( NULL, ID_FRAME );
    mainWindow->Show(true);
////@end LayoutApp initialisation

    return true;
}

/*!
 * Cleanup for LayoutApp
 */
int LayoutApp::OnExit()
{    
////@begin LayoutApp cleanup
    return wxApp::OnExit();
////@end LayoutApp cleanup
}

