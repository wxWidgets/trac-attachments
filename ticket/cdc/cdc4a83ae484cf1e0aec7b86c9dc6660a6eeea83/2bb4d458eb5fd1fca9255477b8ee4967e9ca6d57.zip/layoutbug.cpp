/////////////////////////////////////////////////////////////////////////////
// Name:        layoutbug.cpp
// Purpose:     
// Author:      Greg Hazel
// Modified by: 
// Created:     06/01/05 22:15:42
// RCS-ID:      
// Copyright:   
// Licence:     
/////////////////////////////////////////////////////////////////////////////

#if defined(__GNUG__) && !defined(__APPLE__)
#pragma implementation "layoutbugg.h"
#endif

// For compilers that support precompilation, includes "wx/wx.h".
#include "wx/wxprec.h"

#ifdef __BORLANDC__
#pragma hdrstop
#endif

#ifndef WX_PRECOMP
#include "wx/wx.h"
#endif

////@begin includes
////@end includes

#include "layoutbug.h"

////@begin XPM images
////@end XPM images

/*!
 * LBFrame type definition
 */

IMPLEMENT_CLASS( LBFrame, wxFrame )

/*!
 * LBFrame event table definition
 */

BEGIN_EVENT_TABLE( LBFrame, wxFrame )

////@begin LBFrame event table entries
    EVT_MENU( ID_M_SLIDER, LBFrame::OnMSliderClick )

    EVT_MENU( ID_M_BORDER, LBFrame::OnMBorderClick )

    EVT_MENU( ID_M_LAYOUT, LBFrame::OnMLayoutClick )

    EVT_MENU( ID_EXIT, LBFrame::OnExitClick )

////@end LBFrame event table entries

END_EVENT_TABLE()

/*!
 * LBFrame constructors
 */

LBFrame::LBFrame( )
{
}

LBFrame::LBFrame( wxWindow* parent, wxWindowID id, const wxString& caption, const wxPoint& pos, const wxSize& size, long style )
{
    Create( parent, id, caption, pos, size, style );
}

/*!
 * LBFrame creator
 */

bool LBFrame::Create( wxWindow* parent, wxWindowID id, const wxString& caption, const wxPoint& pos, const wxSize& size, long style )
{
////@begin LBFrame member initialisation
    m_panel = NULL;
////@end LBFrame member initialisation

////@begin LBFrame creation
    wxFrame::Create( parent, id, caption, pos, size, style );

    CreateControls();
    Centre();
////@end LBFrame creation
    return TRUE;
}

/*!
 * Control creation for LBFrame
 */

void LBFrame::CreateControls()
{    
////@begin LBFrame content construction
    LBFrame* itemFrame1 = this;

    wxMenuBar* menuBar = new wxMenuBar;
    wxMenu* itemMenu3 = new wxMenu;
    itemMenu3->Append(ID_M_SLIDER, _("Toggle Slider"), _T(""), wxITEM_CHECK);
    itemMenu3->Check(ID_M_SLIDER, TRUE);
    itemMenu3->Append(ID_M_BORDER, _("Toggle Border"), _T(""), wxITEM_CHECK);
    itemMenu3->Check(ID_M_BORDER, TRUE);
    itemMenu3->Append(ID_M_LAYOUT, _("Call Layout"), _T(""), wxITEM_NORMAL);
    itemMenu3->AppendSeparator();
    itemMenu3->Append(ID_EXIT, _("E&xit"), _T(""), wxITEM_NORMAL);
    menuBar->Append(itemMenu3, _("Click Me"));
    itemFrame1->SetMenuBar(menuBar);

    wxFlexGridSizer* itemFlexGridSizer9 = new wxFlexGridSizer(2, 1, 0, 0);
    itemFlexGridSizer9->AddGrowableRow(0);
    itemFlexGridSizer9->AddGrowableCol(0);
    itemFrame1->SetSizer(itemFlexGridSizer9);

    wxListCtrl* itemListCtrl10 = new wxListCtrl( itemFrame1, ID_LISTCTRL, wxDefaultPosition, wxDefaultSize, wxLC_REPORT );
    itemFlexGridSizer9->Add(itemListCtrl10, 0, wxGROW|wxGROW, 5);

    m_panel = new wxPanel( itemFrame1, ID_PANEL, wxDefaultPosition, wxDefaultSize, wxSUNKEN_BORDER|wxTAB_TRAVERSAL );
    itemFlexGridSizer9->Add(m_panel, 0, wxGROW|wxGROW, 5);

    wxFlexGridSizer* itemFlexGridSizer12 = new wxFlexGridSizer(1, 1, 0, 0);
    itemFlexGridSizer12->AddGrowableRow(0);
    itemFlexGridSizer12->AddGrowableCol(0);
    m_panel->SetSizer(itemFlexGridSizer12);

    wxSlider* itemSlider13 = new wxSlider( m_panel, ID_SLIDER, 0, 0, 100, wxDefaultPosition, wxDefaultSize, wxSL_HORIZONTAL );
    itemFlexGridSizer12->Add(itemSlider13, 0, wxGROW|wxGROW, 5);

////@end LBFrame content construction
}

/*!
 * Should we show tooltips?
 */

bool LBFrame::ShowToolTips()
{
    return TRUE;
}

/*!
 * Get bitmap resources
 */

wxBitmap LBFrame::GetBitmapResource( const wxString& name )
{
    // Bitmap retrieval
////@begin LBFrame bitmap retrieval
    return wxNullBitmap;
////@end LBFrame bitmap retrieval
}

/*!
 * Get icon resources
 */

wxIcon LBFrame::GetIconResource( const wxString& name )
{
    // Icon retrieval
////@begin LBFrame icon retrieval
    return wxNullIcon;
////@end LBFrame icon retrieval
}
/*!
 * wxEVT_COMMAND_MENU_SELECTED event handler for ID_MENU
 */

void LBFrame::OnMSliderClick( wxCommandEvent& event )
{
    m_panel->Show(event.GetInt());
    GetSizer()->Layout();
    event.Skip();
}


/*!
 * wxEVT_COMMAND_MENU_SELECTED event handler for ID_MENUITEM
 */

void LBFrame::OnMLayoutClick( wxCommandEvent& event )
{
    GetSizer()->Layout();
    event.Skip();
}


/*!
 * wxEVT_COMMAND_MENU_SELECTED event handler for ID_EXIT
 */

void LBFrame::OnExitClick( wxCommandEvent& event )
{
    Destroy();
    event.Skip();
}


/*!
 * wxEVT_COMMAND_MENU_SELECTED event handler for ID_M_BORDER
 */

void LBFrame::OnMBorderClick( wxCommandEvent& event )
{
    m_panel->Show(false);
    GetSizer()->Layout();

    if (event.GetInt())
    {
      m_panel->SetWindowStyleFlag(wxSUNKEN_BORDER);
    }
    else
    {
      m_panel->SetWindowStyleFlag(wxNO_BORDER);
    }

    m_panel->Show(true);
    GetSizer()->Layout();

    event.Skip();
}


