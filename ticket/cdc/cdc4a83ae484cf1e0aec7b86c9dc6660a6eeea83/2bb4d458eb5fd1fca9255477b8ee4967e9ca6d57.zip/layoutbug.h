/////////////////////////////////////////////////////////////////////////////
// Name:        layoutbug.h
// Purpose:     
// Author:      Greg Hazel
// Modified by: 
// Created:     06/01/05 22:19:56
// RCS-ID:      
// Copyright:   
// Licence:     
/////////////////////////////////////////////////////////////////////////////

#ifndef _LAYOUTBUG_H_
#define _LAYOUTBUG_H_

#if defined(__GNUG__) && !defined(__APPLE__)
#pragma interface "layoutbug.cpp"
#endif

/*!
 * Includes
 */

////@begin includes
#include "wx/frame.h"
#include "wx/listctrl.h"
////@end includes

/*!
 * Forward declarations
 */

////@begin forward declarations
////@end forward declarations

/*!
 * Control identifiers
 */

////@begin control identifiers
#define ID_FRAME 10004
#define SYMBOL_LBFRAME_STYLE wxCAPTION|wxRESIZE_BORDER|wxSYSTEM_MENU|wxCLOSE_BOX|wxCLIP_CHILDREN 
#define SYMBOL_LBFRAME_TITLE _("Layout Bug")
#define SYMBOL_LBFRAME_IDNAME ID_FRAME
#define SYMBOL_LBFRAME_SIZE wxSize(400, 300)
#define SYMBOL_LBFRAME_POSITION wxDefaultPosition
#define ID_M_SLIDER 10005
#define ID_M_BORDER 10008
#define ID_M_LAYOUT 10006
#define ID_EXIT 10007
#define ID_LISTCTRL 10000
#define ID_PANEL 10003
#define ID_SLIDER 10002
////@end control identifiers

/*!
 * Compatibility
 */

#ifndef wxCLOSE_BOX
#define wxCLOSE_BOX 0x1000
#endif
#ifndef wxFIXED_MINSIZE
#define wxFIXED_MINSIZE 0
#endif

/*!
 * LBFrame class declaration
 */

class LBFrame: public wxFrame
{    
    DECLARE_CLASS( LBFrame )
    DECLARE_EVENT_TABLE()

public:
    /// Constructors
    LBFrame( );
    LBFrame( wxWindow* parent, wxWindowID id = SYMBOL_LBFRAME_IDNAME, const wxString& caption = SYMBOL_LBFRAME_TITLE, const wxPoint& pos = SYMBOL_LBFRAME_POSITION, const wxSize& size = SYMBOL_LBFRAME_SIZE, long style = SYMBOL_LBFRAME_STYLE );

    bool Create( wxWindow* parent, wxWindowID id = SYMBOL_LBFRAME_IDNAME, const wxString& caption = SYMBOL_LBFRAME_TITLE, const wxPoint& pos = SYMBOL_LBFRAME_POSITION, const wxSize& size = SYMBOL_LBFRAME_SIZE, long style = SYMBOL_LBFRAME_STYLE );

    /// Creates the controls and sizers
    void CreateControls();

////@begin LBFrame event handler declarations

    /// wxEVT_COMMAND_MENU_SELECTED event handler for ID_M_SLIDER
    void OnMSliderClick( wxCommandEvent& event );

    /// wxEVT_COMMAND_MENU_SELECTED event handler for ID_M_BORDER
    void OnMBorderClick( wxCommandEvent& event );

    /// wxEVT_COMMAND_MENU_SELECTED event handler for ID_M_LAYOUT
    void OnMLayoutClick( wxCommandEvent& event );

    /// wxEVT_COMMAND_MENU_SELECTED event handler for ID_EXIT
    void OnExitClick( wxCommandEvent& event );

////@end LBFrame event handler declarations

////@begin LBFrame member function declarations

    /// Retrieves bitmap resources
    wxBitmap GetBitmapResource( const wxString& name );

    /// Retrieves icon resources
    wxIcon GetIconResource( const wxString& name );
////@end LBFrame member function declarations

    /// Should we show tooltips?
    static bool ShowToolTips();

////@begin LBFrame member variables
    wxPanel* m_panel;
////@end LBFrame member variables
};

#endif
    // _LAYOUTBUG_H_
