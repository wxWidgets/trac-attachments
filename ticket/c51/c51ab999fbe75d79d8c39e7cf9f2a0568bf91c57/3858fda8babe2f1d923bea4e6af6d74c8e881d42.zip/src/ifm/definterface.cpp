/*!
    Implementation for default interface stuff

    \file   definterface.cpp
    \author Robin McNeill
    \date   Created: 11/06/04

    Copyright (c) Robin McNeill
    Licensed under the terms of the wxWindows license
*/

#include "wx/wxprec.h"

#ifdef __BORLANDC__
    #pragma hdrstop
#endif

#include "wx/ifm/definterface.h"
#include "wx/ifm/resize.h"
#include "wx/ifm/dragndrop.h"
#include "wx/panel.h"

#include "btn_hide.xpm"
#include "btn_min.xpm"
#include "btn_max.xpm"
#include "btn_hide_h.xpm"
#include "btn_min_h.xpm"
#include "btn_max_h.xpm"
#include "btn_hide_hp.xpm"
#include "btn_min_hp.xpm"
#include "btn_max_hp.xpm"

#include "wx/settings.h"

#include "wx/listimpl.cpp"
WX_DEFINE_LIST(wxIFMComponentList);

DEFINE_IFM_DATA_KEY(IFM_CONTAINER_DATA_KEY)
DEFINE_IFM_DATA_KEY(IFM_PANEL_DATA_KEY)
DEFINE_IFM_DATA_KEY(IFM_TABBED_PANEL_DATA_KEY)

DEFINE_IFM_COMPONENT_TYPE(IFM_COMPONENT_CONTAINER)
DEFINE_IFM_COMPONENT_TYPE(IFM_COMPONENT_PANEL_TAB)
DEFINE_IFM_COMPONENT_TYPE(IFM_COMPONENT_PANEL)

DEFINE_EVENT_TYPE(wxEVT_IFM_ADDTOPCONTAINER);
DEFINE_EVENT_TYPE(wxEVT_IFM_REMOVETOPCONTAINER);
DEFINE_EVENT_TYPE(wxEVT_IFM_SELECTTAB);
DEFINE_EVENT_TYPE(wxEVT_IFM_COMPONENTBUTTONCLICK);

IMPLEMENT_DYNAMIC_CLASS(wxIFMDefaultInterfacePlugin, wxIFMInterfacePluginBase);
IMPLEMENT_DYNAMIC_CLASS(wxIFMDefaultContainerPlugin, wxIFMExtensionPluginBase);
IMPLEMENT_DYNAMIC_CLASS(wxIFMDefaultPanelPlugin, wxIFMExtensionPluginBase);
IMPLEMENT_DYNAMIC_CLASS(wxIFMDefaultChildData, wxIFMChildDataBase);
IMPLEMENT_DYNAMIC_CLASS(wxIFMContainerData, wxIFMExtensionDataBase);
IMPLEMENT_DYNAMIC_CLASS(wxIFMPanelTabData, wxIFMExtensionDataBase);
IMPLEMENT_DYNAMIC_CLASS(wxIFMPanelData, wxIFMExtensionDataBase);

// bitmaps for component buttons
wxBitmap m_bmpClose, m_bmpMin, m_bmpMax,
    m_bmpCloseH, m_bmpMinH, m_bmpMaxH,
    m_bmpCloseP, m_bmpMinP, m_bmpMaxP;

#if IFM_CANFLOAT

/*
wxIFMFloatingFrame implementation
*/
BEGIN_EVENT_TABLE(wxIFMFloatingFrame, wxIFMFloatingWindowBase)
    EVT_CLOSE   (wxIFMFloatingFrame::OnClose)
END_EVENT_TABLE()

wxIFMFloatingFrame::wxIFMFloatingFrame(wxIFMInterfacePluginBase *ip, wxWindow *parent, wxWindowID id,
        const wxString& title, const wxPoint& pos, const wxSize& size, long style, const wxString& name)
        : wxIFMFloatingWindowBase(ip)
{
    m_window = new wxFrame(parent, id, title, pos, size, style, name);
    ConnectEvents();
}

void wxIFMFloatingFrame::OnClose(wxCloseEvent &event)
{
    // don't know if this works, but at least try to close properly
    // if we can't veto the event
    if( event.CanVeto() )
    {
        // only hide the window
        event.Veto();
        m_window->Hide();

        // hide our root component too
        m_component->Show(false, false);
    }
    else
    {
        DisconnectEvents();
    }
}

#endif

/*
wxIFMDefaultInterfacePlugin implementation
*/
BEGIN_EVENT_TABLE(wxIFMDefaultInterfacePlugin, wxIFMInterfacePluginBase)
    EVT_IFM_DELETECOMPONENT (wxIFMDefaultInterfacePlugin::OnDeleteComponent)
    EVT_IFM_ADDCHILD    (wxIFMDefaultInterfacePlugin::OnAddChild)
    EVT_IFM_UPDATE      (wxIFMDefaultInterfacePlugin::OnUpdate)
    EVT_IFM_PAINTINTERFACE (wxIFMDefaultInterfacePlugin::OnPaint)
    EVT_IFM_GETCONTENTRECT(wxIFMDefaultInterfacePlugin::OnGetContentRect)

    EVT_IFM_ADDTOPCONTAINER (wxIFMDefaultInterfacePlugin::OnAddTopContainer)
    EVT_IFM_REMOVETOPCONTAINER (wxIFMDefaultInterfacePlugin::OnRemoveTopContainer)

#if IFM_CANFLOAT
    EVT_IFM_CREATEFLOATINGWINDOW    (wxIFMDefaultInterfacePlugin::OnCreateFloatingWindow)
    EVT_IFM_DESTROYFLOATINGWINDOW   (wxIFMDefaultInterfacePlugin::OnDestroyFloatingWindow)
    //EVT_IFM_FLOAT                   (wxIFMDefaultInterfacePlugin::OnFloat)
#endif
END_EVENT_TABLE()

wxIFMDefaultInterfacePlugin::wxIFMDefaultInterfacePlugin()
    : wxIFMInterfacePluginBase()
{ }

wxIFMDefaultInterfacePlugin::~wxIFMDefaultInterfacePlugin()
{
#if IFM_CANFLOAT
    // delete floating window objects
    for( int i = 0, count = m_floatingWindows.GetCount(); i < count; ++i )
    //for( wxIFMFloatingWindowArray::const_iterator i = m_floatingWindows.begin(), end = m_floatingWindows.end(); i != end; ++i )
        delete m_floatingWindows[i];
        //delete (*i);
#endif
}

const wxIFMComponentList &wxIFMDefaultInterfacePlugin::GetTopContainerList() const
{
    return m_containers;
}

bool wxIFMDefaultInterfacePlugin::ProcessPluginEvent(wxIFMPluginEvent &event)
{
    bool ret = wxIFMInterfacePluginBase::ProcessPluginEvent(event);

#if IFM_CANFLOAT
    if( event.GetEventType() == wxEVT_IFM_CREATEFLOATINGWINDOW )
    {
        wxIFMCreateFloatingWindowEvent *evt = wxDynamicCast(&event, wxIFMCreateFloatingWindowEvent);
        if( evt )
            m_floatingWindows.push_back(evt->GetWindow());
    }
#endif

    return ret;
}

void wxIFMDefaultInterfacePlugin::OnAddTopContainer(wxIFMAddTopContainerEvent &event)
{
    wxIFMComponent *component = event.GetComponent();

    wxASSERT_MSG(component, wxT("NULL component?"));
    if( !component )
        return;

    if( event.GetIndexMode() )
    {
        int index = event.GetIndex();

        if( index == -1 )
        {
            m_containers.push_back(component);
        }
        else
        {
            // get an interator to the index position
            if( index == 0 )
                m_containers.push_front(component);
            else
            {
                wxIFMComponentList::iterator i; int n;
                for( i = m_containers.begin(), n = 0; n < index; ++i, n++ );
                m_containers.insert(i, component);
            }
        }
    }
    else
    {
        // find the index of the index container
        wxIFMComponent *index = event.GetIndexContainer();
        wxIFMComponentList::iterator i, end;
        for( i = m_containers.begin(), end = m_containers.end(); i != end; ++i)
        {
            if( *i == index )
                break;
        }

        // dock before or after this index
        if( !event.GetIndex() ) // GetIndex() == 0 means dock after
            i++;
        // dont advance to the end of the list
        if( i == end )
            m_containers.push_back(component);
        else
            m_containers.insert(i, component);
    }

#if IFM_CANFLOAT
    // if a container is moved from a floating window into a top level position, it needs
    // to recieve float notify events, or child windows fall off the face of the earth
    wxIFMFloatNotifyEvent evt(component, false);
    ProcessPluginEvent(evt);
#endif
}

void wxIFMDefaultInterfacePlugin::OnRemoveTopContainer(wxIFMRemoveTopContainerEvent &event)
{
    wxIFMComponent *container = event.GetComponent();

    wxASSERT_MSG(container, wxT("NULL component?"));
    if( !container )
        return;

    for( wxIFMComponentList::iterator i = m_containers.begin(), end = m_containers.end(); i != end; ++i )
    {
        if( *i == container )
        {
            m_containers.erase(i);

            // give the container no orientation value
            wxIFMContainerData *data = IFM_GET_EXTENSION_DATA(container, wxIFMContainerData);
            wxASSERT_MSG(data, wxT("Container with no container data?"));
            if( data )
                data->m_orientation = IFM_ORIENTATION_NONE;

            return;
        }
    }

    wxFAIL_MSG(wxT("Trying to remove a container not in top level list!"));
}

bool wxIFMDefaultInterfacePlugin::Initialize(wxInterfaceManager *m_manager)
{
    // base initialization
    wxIFMInterfacePluginBase::Initialize(m_manager);

    // push required plugins
    wxIFMExtensionPluginBase *plugin;

    plugin = new wxIFMDefaultContainerPlugin();
    if( !PushExtensionPlugin(plugin) )
        return false;

    plugin = new wxIFMDefaultPanelPlugin();
    if( !PushExtensionPlugin(plugin) )
        return false;

    plugin = new wxIFMDefaultResizePlugin();
    if( !PushExtensionPlugin(plugin) )
        return false;

    plugin = new wxIFMDefaultDockingPlugin();
    if( !PushExtensionPlugin(plugin) )
        return false;

    return true;
}

wxIFMComponent *wxIFMDefaultInterfacePlugin::GetContainer(int orientation)
{
    // look for the last container with the specified orientation
    // FIXME: This actually finds the first container?
    //for( wxIFMComponentList::compatibility_iterator node = m_containers.GetFirst(); node; node = node->GetNext() )
    for( wxIFMComponentList::const_iterator i = m_containers.begin(), end = m_containers.end(); i != end; ++i )
    {
        //wxIFMComponent *container = node->GetData();
        wxIFMComponent *container = (*i);
        wxIFMContainerData *data = IFM_GET_EXTENSION_DATA(container, wxIFMContainerData);
        if( data->m_orientation == orientation )
            return container;
    }

    // no container found
    return NULL;
}

void wxIFMDefaultInterfacePlugin::OnDeleteComponent(wxIFMDeleteComponentEvent &event)
{
    if( event.GetComponentType() == IFM_COMPONENT_CONTAINER )
    {
        wxIFMComponent *container = event.GetComponent();

        // remove the container from the top level container list
        for( wxIFMComponentList::iterator i = m_containers.begin(), end = m_containers.end(); i != end; ++i )
        {
            if( *i == container )
            {
                m_containers.erase(i);
                break;
            }
        }
    }

    event.Skip();
}

void wxIFMDefaultInterfacePlugin::OnAddChild(wxIFMAddChildEvent &event)
{
    static int s_nextOrientation = IFM_ORIENTATION_TOP; // for default orientation selection
    static wxIFMComponent *last_panel;
    bool delete_data = false;

    wxIFMChildDataBase *base = event.GetChildData();

    // verify that the data is of the right type
    wxIFMDefaultChildData *data = wxDynamicCast(base, wxIFMDefaultChildData);

    // construct a defaultchilddata object from the regular object if we must
    if( !data )
    {
        delete_data = true;
        data = new wxIFMDefaultChildData(*base);
    }

    //! \todo Handle tabify. We don't make panels for children being tabbed
    bool tabify = data->m_tabify;

    // create a tab for the child
    wxIFMNewComponentEvent newevt(IFM_COMPONENT_PANEL_TAB);
    ProcessPluginEvent(newevt);

    wxIFMComponent *tab = newevt.GetComponent();

    tab->m_canHide = data->m_hideable;
    tab->m_fixed = data->m_fixed;

    if( !tab->m_fixed )
    {
        tab->m_minSize = data->m_minSize;
        tab->m_maxSize = data->m_maxSize;
        tab->m_desiredSize = data->m_desiredSize;
    }
    else
        tab->m_minSize = (tab->m_maxSize = (tab->m_desiredSize = data->m_desiredSize));

#if IFM_CANFLOAT
    // set floating data for the tab and the tabbed panel
    wxIFMFloatingData *floating_data = IFM_GET_EXTENSION_DATA(tab, wxIFMFloatingData);
    floating_data->m_rect.SetSize(tab->m_desiredSize);
    floating_data->m_rect.SetPosition(data->m_pos);
#endif

    tab->m_name = data->m_name;

    wxIFMPanelTabData *tab_data = IFM_GET_EXTENSION_DATA(tab, wxIFMPanelTabData);
    if(data->m_bitmap.Ok())
        tab_data->m_bitmap = data->m_bitmap.GetSubBitmap(wxRect(0, 0, data->m_bitmap.GetWidth(), data->m_bitmap.GetHeight()));

    // set the child of the tab
    wxIFMSetChildEvent setevt(tab, data->m_type, data->m_child);
    ProcessPluginEvent(setevt);

    // store the child window / component pair
    AddChildWindow(data->m_child, tab);

    int orientation = data->m_orientation;

    // are we floating?
#if IFM_CANFLOAT
    if( orientation == IFM_ORIENTATION_FLOAT )
    {
        // send the tab a float event
        wxIFMFloatEvent floatevt(tab, floating_data->m_rect);
        ProcessPluginEvent(floatevt);
    }
    else
#endif
    // handle tabify
    if( tabify && last_panel )
    {
        // dock the child as a tab of the last panel
        wxIFMDockEvent evt(tab, last_panel, IFM_DEFAULT_INDEX);
        ProcessPluginEvent(evt);
    }
    else
    {
        // see if we need to chose an orientation
        if( orientation == IFM_ORIENTATION_DEFAULT )
        {
            orientation = s_nextOrientation;

            // calculate next orientation
            switch(s_nextOrientation)
            {
                case IFM_ORIENTATION_TOP:
                    s_nextOrientation = IFM_ORIENTATION_LEFT;
                    break;
                case IFM_ORIENTATION_LEFT:
                    s_nextOrientation = IFM_ORIENTATION_BOTTOM;
                    break;
                case IFM_ORIENTATION_BOTTOM:
                    s_nextOrientation = IFM_ORIENTATION_RIGHT;
                    break;
                case IFM_ORIENTATION_RIGHT:
                    s_nextOrientation = IFM_ORIENTATION_TOP;
                    break;
            }
        }

        // retrieve destinition container
        wxIFMComponent *container = GetContainer(orientation);

        // make a container if need be
        if( !container || data->m_newRow )
        {
            wxIFMNewComponentEvent newevt(IFM_COMPONENT_CONTAINER);
            ProcessPluginEvent(newevt);

            container = newevt.GetComponent();

            wxASSERT_MSG(container, wxT("NULL component returned by new component event?"));
            if( !container )
                return;

            wxIFMContainerData *data = IFM_GET_EXTENSION_DATA(container, wxIFMContainerData);
            wxASSERT_MSG(data, wxT("Container without container data?"));
            if( !data )
                return;

            data->m_orientation = orientation;
            switch(orientation)
            {
                case IFM_ORIENTATION_TOP:
                case IFM_ORIENTATION_BOTTOM:
                    container->m_alignment = IFM_ALIGN_HORIZONTAL;
                    break;
                case IFM_ORIENTATION_LEFT:
                case IFM_ORIENTATION_RIGHT:
                    container->m_alignment = IFM_ALIGN_VERTICAL;
                    break;
            }

            // add container as a top level one using the event
            wxIFMAddTopContainerEvent addevt(container, -1);
            ProcessPluginEvent(addevt);
        }

        // dock this tabbed panel into the specified container
        wxIFMDockEvent dockevt(tab, container, data->m_index);
        ProcessPluginEvent(dockevt);

        // the tabs parent will be a panel automagically, so we store that
        // as the previously used panel for tabify
        last_panel = tab->m_parent;
    }

    // show or hide the new component
    tab->Show(!data->m_hidden, false);

    // complete successfully
    event.SetSuccess();

    if( delete_data )
        delete data;
}

void wxIFMDefaultInterfacePlugin::OnUpdate(wxIFMUpdateEvent &event)
{
    wxSize size = event.GetSize();
    wxPoint pos = event.GetPosition();
    wxRect m_contentRect = event.GetRect();

    wxIFMComponent *container;
    wxIFMContainerData *data;
    wxWindow *content = event.GetContent();
    wxRect rect;

    int min_w = 0, min_h = 0;

    // update containers beginning from the start of the list
    // also calculate the minimum allowable size for the interface
    for( wxIFMComponentList::iterator i = m_containers.begin(), end = m_containers.end(); i != end; ++i )
    {
        container = *i;

        if( !container->IsVisible() )
            continue;

        data = IFM_GET_EXTENSION_DATA(container, wxIFMContainerData);

        // calculate size
        wxSize size = container->GetDesiredSize();
        wxSize min_size = container->GetMinSize();

        wxIFMComponentList::iterator temp = i;
        ++temp;
        if( temp == end && !content )
        {
            // make this container as big as the remaining area to deal with having no content window
            rect = m_contentRect;
        }
        else
        {
            switch(data->m_orientation)
            {
                case IFM_ORIENTATION_LEFT:
                    rect.x = m_contentRect.x;
                    rect.y = m_contentRect.y;
                    rect.width = size.GetWidth();
                    rect.height = m_contentRect.height;

                    m_contentRect.width -= rect.width;
                    m_contentRect.x += rect.width;

                    //if( min_h < min_size.y )
                        min_h += min_size.y;
                        min_w += min_size.x;

                    break;

                case IFM_ORIENTATION_RIGHT:
                    rect.width = size.GetWidth();
                    rect.x = m_contentRect.x + m_contentRect.width - rect.width;
                    rect.y = m_contentRect.y;
                    rect.height = m_contentRect.height;

                    m_contentRect.width -= rect.width;

                    //if( min_h < min_size.y )
                        min_h += min_size.y;
                        min_w += min_size.x;

                    break;

                case IFM_ORIENTATION_TOP:
                    rect.x = m_contentRect.x;
                    rect.y = m_contentRect.y;
                    rect.width = m_contentRect.width;
                    rect.height = size.GetHeight();

                    m_contentRect.y += rect.height;
                    m_contentRect.height -= rect.height;

                    //if( min_w < min_size.x )
                        min_h += min_size.y;
                        min_w += min_size.x;

                    break;

                case IFM_ORIENTATION_BOTTOM:
                    rect.width = m_contentRect.width;
                    rect.height = size.GetHeight();
                    rect.x = m_contentRect.x;
                    rect.y = m_contentRect.y + m_contentRect.height - rect.height;

                    m_contentRect.height -= rect.height;

                    //if( min_w < min_size.x )
                        min_h += min_size.y;
                        min_w += min_size.x;

                    break;

                default:
                    wxFAIL_MSG(wxT("Invalid orientation value"));
            }
        }

        // this code is commented out because its logic is flawed
        // I need to not update a container so long as none of its children
        // require an update
        //! \todo Add a flag to default data that specifies if a change has been made since the last update
        /*
        // only update the container if its new rect is different from its old rect
        wxIFMRectEvent rectevt(wxEVT_IFM_GETRECT, IFM_COMPONENT_CONTAINER, container);
        ProcessPluginEvent(rectevt);

        if( rect != rectevt.GetRect() )
        */
        {
            // update the container
            wxIFMUpdateComponentEvent updevt(container, rect);
            ProcessPluginEvent(updevt);
        }
    }

    // position content window
    if( content )
        content->SetSize(m_contentRect);

    // set size hints
    //GetManager()->GetParent()->ClientToScreen(&min_w, &min_h);
    GetManager()->GetParent()->SetSizeHints(min_w, min_h);

    // update floating windows if needed
#if IFM_CANFLOAT
    if( event.GetFoating() )
    {
        wxIFMFloatingWindowBase *base;

        for( size_t i = 0; i < m_floatingWindows.GetCount(); i++ )
        //for( wxIFMFloatingWindowArray::const_iterator i = m_floatingWindows.begin(), end = m_floatingWindows.end(); i != end; ++i )
        {
            base = m_floatingWindows[i];
            // base = *i;

            base->Update(true);
        }
    }
#endif
}

void wxIFMDefaultInterfacePlugin::OnPaint(wxIFMPaintInterfaceEvent &event)
{
    wxDC &dc = event.GetDC();

    wxIFMComponent *component;
    wxRegionContain result;

    // don't paint a component if we don't have to
    const wxRegion &region = event.GetUpdateRegion();
    for( wxIFMComponentList::const_iterator i = m_containers.begin(), end = m_containers.end(); i != end; ++i )
    {
        component = *i;

        if( !component->IsVisible() )
            continue;
        else
        {
            result = region.Contains(component->m_rect);
            if( result == wxInRegion || result == wxPartRegion )
            {
                // make a copy of the region and find the parts of the component
                // that need updating
                //wxRegion new_region = region;
                //new_region.Intersect(component->m_rect);
                component->Paint(dc, region);
            }
        }
    }
}

wxIFMComponent *wxIFMDefaultInterfacePlugin::GetComponentByPos(const wxPoint &pos, wxIFMComponent *component, bool floating)
{
#if IFM_CANFLOAT
    if( floating )
    {
        wxIFMComponent *component = GetFloatingComponentByPos(GetManager()->GetParent()->ClientToScreen(pos));
        if( component )
            return component;
    }
#endif

    if( component == NULL )
    {
        wxIFMComponent *ret;
        for( wxIFMComponentList::const_iterator i = m_containers.begin(), end = m_containers.end(); i != end; ++i )
        {
            ret = GetComponentByPos(pos, *i);
            if( ret )
                return ret;
        }
        return NULL;
    }

    //wxIFMHitTestEvent evt(component, IFM_COORDS_ABSOLUTE, pos);
    //ProcessPluginEvent(evt);
    if( !component->m_hidden && component->m_rect.Inside(pos) )

    //if( evt.GetPassed() )
    {
        // check children
        wxIFMComponent *ret;
        const wxIFMComponentArray &children = component->m_children;
        for( size_t i = 0; i < children.GetCount(); i++ )
        //for( wxIFMComponentArray::const_iterator i = children.begin(), end = children.end(); i != end; ++i )
        {
            ret = GetComponentByPos(pos, children[i]);
            if( ret )
                return ret;
        }
        return component;
    }

    return NULL;
}

void wxIFMDefaultInterfacePlugin::OnGetContentRect(wxIFMRectEvent &event)
{
    wxRect m_contentRect = GetManager()->GetInterfaceRect();
    wxIFMComponent *container;
    wxIFMContainerData *data;

    // update containers beginning from the start of the list
    for( wxIFMComponentList::const_iterator i = m_containers.begin(), end = m_containers.end(); i != end; ++i )
    {
        container = *i;
        data = IFM_GET_EXTENSION_DATA(container, wxIFMContainerData);

        wxIFMRectEvent rectevt(wxEVT_IFM_GETRECT, container);
        ProcessPluginEvent(rectevt);
        const wxRect &rect = rectevt.GetRect();

        switch(data->m_orientation)
        {
            // skip docked containers
            case IFM_ORIENTATION_DOCKED:
                continue;

            case IFM_ORIENTATION_LEFT:
                m_contentRect.width -= rect.width;
                m_contentRect.x += rect.width;
                break;

            case IFM_ORIENTATION_RIGHT:
                m_contentRect.width -= rect.width;
                break;

            case IFM_ORIENTATION_TOP:
                m_contentRect.y += rect.height;
                m_contentRect.height -= rect.height;
                break;

            case IFM_ORIENTATION_BOTTOM:
                m_contentRect.height -= rect.height;
                break;

            default:
                wxFAIL_MSG(wxT("Invalid orientation value"));
        }
    }

    // return content rect
    event.SetRect(m_contentRect);
}

#if IFM_CANFLOAT
void wxIFMDefaultInterfacePlugin::OnCreateFloatingWindow(wxIFMCreateFloatingWindowEvent &event)
{
    // component being floated
    wxIFMComponent *component = event.GetComponent();

    wxASSERT_MSG(component, wxT("Creating a floating window for a NULL component?"));
    if( !component )
        return;

    // create a frame to float with
    long style = IFM_FLOATING_FRAME_STYLE;

    wxIFMFloatingWindowBase *window = new wxIFMFloatingFrame(this, event.GetParent(), wxID_ANY, wxT(""),
        wxPoint(0,0), wxSize(0,0), style);
    event.SetWindow(window);

    // create the root component as well
    if( event.GetComponent()->GetType() == IFM_COMPONENT_CONTAINER )
        window->m_component = event.GetComponent();
    else
    {
        wxIFMNewComponentEvent evt(IFM_COMPONENT_FLOATING_ROOT);
        ProcessPluginEvent(evt);
        window->m_component = evt.GetComponent();

        wxASSERT_MSG(window->m_component, wxT("NULL floating root returned?"));
        if( !window->m_component )
            return;
    }

    // tell the root component its floating
    wxIFMFloatNotifyEvent fltevt(window->GetComponent(), true, window);
    ProcessPluginEvent(fltevt);

    // horizontal child alignment by default
    if( window->GetComponent()->m_alignment == IFM_ALIGN_NONE )
        window->GetComponent()->m_alignment = IFM_ALIGN_HORIZONTAL;

    wxIFMContainerData *contdata = IFM_GET_EXTENSION_DATA(window->m_component, wxIFMContainerData);
    if( contdata )
        contdata->m_orientation = IFM_ORIENTATION_FLOAT;

    // dock the component into the root component if needed
    if( component->GetType() != IFM_COMPONENT_CONTAINER )
    {
        wxIFMDockEvent dockevt(component, window->GetComponent(), 0);
        ProcessPluginEvent(dockevt);
    }
}

void wxIFMDefaultInterfacePlugin::OnDestroyFloatingWindow(wxIFMDestroyFloatingWindowEvent &event)
{
    wxIFMFloatingWindowBase *base = event.GetWindow();

    wxASSERT_MSG(base, wxT("Destroying a NULL floating window?"));
    if( !base )
        return;

    // remove the floating window from the floating window array
    //for( int i = 0, count = m_floatingWindows.GetCount(); i < count; ++i )
    for( wxIFMFloatingWindowArray::iterator i = m_floatingWindows.begin(), end = m_floatingWindows.end(); i != end; ++i )
    {
        //if( m_floatingWindows[i] == base )
        if( *i == base )
        {
            //m_floatingWindows.RemoveAt(i);
            m_floatingWindows.erase(i);
            break;
        }
    }

    base->m_destroyRoot = event.ShouldDestroyRoot();

    delete base;
}

#endif

/*
wxIFMDefaultContainerPlugin implementation
*/
BEGIN_EVENT_TABLE(wxIFMDefaultContainerPlugin, wxIFMExtensionPluginBase)
    EVT_IFM_NEWCOMPONENT    (wxIFMDefaultContainerPlugin::OnCreateComponent)
    EVT_IFM_DOCK            (wxIFMDefaultContainerPlugin::OnDock) // docks panel rows into the container
    EVT_IFM_UNDOCK          (wxIFMDefaultContainerPlugin::OnUndock)
    EVT_IFM_UPDATECOMPONENT (wxIFMDefaultContainerPlugin::OnUpdate)
    EVT_IFM_VISIBILITYCHANGED (wxIFMDefaultContainerPlugin::OnVisibilityChange)
    EVT_IFM_GETDESIREDSIZE  (wxIFMDefaultContainerPlugin::OnGetDesiredSize)
    EVT_IFM_SETDESIREDSIZE  (wxIFMDefaultContainerPlugin::OnSetDesiredSize)
    EVT_IFM_LEFTDOWN        (wxIFMDefaultContainerPlugin::OnLeftDown)
    EVT_IFM_PAINTDECOR      (wxIFMDefaultContainerPlugin::OnPaintDecor)

    EVT_IFM_COMPONENTBUTTONCLICK (wxIFMDefaultContainerPlugin::OnComponentButtonClick)

#if IFM_CANFLOAT
    EVT_IFM_FLOATING_NOTIFY    (wxIFMDefaultContainerPlugin::OnFloatNotify)
#endif
END_EVENT_TABLE()

wxIFMDefaultContainerPlugin::wxIFMDefaultContainerPlugin()
    : wxIFMExtensionPluginBase()
{ }

bool wxIFMDefaultContainerPlugin::HasVisibleChildren(wxIFMComponent *component)
{
    wxIFMComponentArray &children = component->m_children;
    wxIFMComponent *child;

    for( int i = 0, size = children.GetCount(); i < size; ++i )
    //for( wxIFMComponentArray::const_iterator i = children.begin(), end = children.end(); i != end; ++i )
    {
        child = children[i];
        //child = *i;

        // child containers alone don't count, but their children do
        if( child->GetType() == IFM_COMPONENT_CONTAINER )
        {
            if( HasVisibleChildren(child) )
                return true;
        }
        else
        {
            if( child->IsVisible() )
                return true;
        }
    }

    return false;
}

int wxIFMDefaultContainerPlugin::GetVisibleChildrenCount(wxIFMComponent *component)
{
    wxIFMComponentArray &children = component->m_children;
    wxIFMComponent *child;
    int child_count = 0;

    for( int i = 0, size = children.GetCount(); i < size; ++i )
    //for( wxIFMComponentArray::const_iterator i = children.begin(), end = children.end(); i != end; ++i )
    {
        child = children[i];
        //child = *i;

        // child containers alone don't count, but their children do
        if( child->GetType() == IFM_COMPONENT_CONTAINER )
        {
            child_count += GetVisibleChildrenCount(child);
        }
        else
        {
            if( child->IsVisible() )
                child_count++;
        }
    }

    return child_count;
}

bool wxIFMDefaultContainerPlugin::HasNonCloseableChildren(wxIFMComponent *component)
{
    wxIFMComponentArray &children = component->m_children;
    wxIFMComponent *child;

    for( size_t i = 0; i < children.GetCount(); i++ )
    //for( wxIFMComponentArray::const_iterator i = children.begin(), end = children.end(); i != end; ++i )
    {
        child = children[i];
        //child = *i;
        if( !child->m_canHide )
            return true;
        else
            if( HasNonCloseableChildren(child) )
                return true;
    }

    return false;
}

void wxIFMDefaultContainerPlugin::OnCreateComponent(wxIFMNewComponentEvent &event)
{
    // only create containers or root floating components
    if( event.GetComponentType() == IFM_COMPONENT_CONTAINER ||
        event.GetComponentType() == IFM_COMPONENT_FLOATING_ROOT )
    {
        wxIFMComponent *container = new wxIFMComponent(GetIP(), IFM_COMPONENT_CONTAINER);

        // container specific storage
        wxIFMContainerData *data = new wxIFMContainerData(GetIP(), container);

        // add the drag gripper to the left side of all containers, and a close button
        data->m_tray_rect.width = IFM_CONTAINER_GRIPPER_WIDTH;
        container->m_margins.Set(0);
        container->m_margins.left = data->m_tray_rect.width;
        container->m_borders.Set(0);

#if 0 // no button yet
        wxIFMComponentButton *btn;
        btn = data->m_buttonManager.AddButton(IFM_COMPONENT_ID_CLOSE);
        btn->m_bmp = &m_bmpClose;
        btn->m_bmpH = &m_bmpCloseH;
        btn->m_bmpP = &m_bmpCloseP;
#endif

        container->AddExtensionData(data);

        // return the new component
        event.SetComponent(container);
    }
    else
        event.Skip();
}

// paint the drag gripper on the side of all containers
void wxIFMDefaultContainerPlugin::OnPaintDecor(wxIFMPaintEvent &event)
{
#if IFM_CONTAINER_GRIPPER_WIDTH
    if( event.GetComponentType() == IFM_COMPONENT_CONTAINER )
    {
        wxIFMComponent *component = event.GetComponent();

        wxASSERT_MSG(component, wxT("NULL component?"));
        if( !component )
            return;

        wxIFMContainerData *data = IFM_GET_EXTENSION_DATA(component, wxIFMContainerData);

        wxASSERT_MSG(data, wxT("Container with no container data?"));
        if( !data )
            return;

        wxDC &dc = event.GetDC();

        //! \todo Make this not hard coded color and style
        wxBrush brush(wxSystemSettings::GetColour(wxSYS_COLOUR_BTNSHADOW));

        dc.SetBrush(brush);
        dc.SetPen(*wxBLACK_PEN);

        dc.DrawRectangle(data->m_tray_rect);
    }
    else
#endif
        event.Skip();
}

void wxIFMDefaultContainerPlugin::OnSetDesiredSize(wxIFMRectEvent &event)
{
    if( event.GetComponentType() != IFM_COMPONENT_CONTAINER )
    {
        event.Skip();
        return;
    }

    GetNextHandler()->ProcessEvent(event);

    // set the desired size of our children
    wxIFMComponent *component = event.GetComponent();

    wxASSERT_MSG(component, wxT("NULL component?"));
    if( !component )
        return;

    const wxIFMComponentArray &children = component->m_children;
    wxRect rect, combined_rect;
    int numchildren = children.GetCount(), i;
    wxRect *child_rects = new wxRect[numchildren];

    // the desired size is specified in absolute cords, only use client coords for children
    wxIFMConvertRectEvent cvtevt(component, IFM_COORDS_ABSOLUTE, IFM_COORDS_CLIENT, event.GetRect());
    GetIP()->ProcessPluginEvent(cvtevt);
    rect = cvtevt.GetRect();

    // sum the total desired widths
    for( i = 0; i < numchildren; ++i )
    {
        wxIFMRectEvent evt(wxEVT_IFM_GETDESIREDSIZE, children[i]);
        GetIP()->ProcessPluginEvent(evt);

        child_rects[i] = evt.GetRect();
        combined_rect.height += child_rects[i].height;
        combined_rect.width += child_rects[i].width;
    }

    if( component->m_alignment == IFM_ALIGN_HORIZONTAL )
        combined_rect.height = rect.height;
    else if( component->m_alignment == IFM_ALIGN_VERTICAL )
        combined_rect.width = rect.width;

    for( i = 0; i < numchildren; ++i )
    {
        // scale desired size
        if( component->m_alignment == IFM_ALIGN_HORIZONTAL )
        {
            child_rects[i].height = combined_rect.height;
            child_rects[i].width = (int)(rect.width * ((double)child_rects[i].width / combined_rect.width));
        }
        else if( component->m_alignment == IFM_ALIGN_VERTICAL )
        {
            child_rects[i].width = combined_rect.width;
            child_rects[i].height = (int)(rect.height * ((double)child_rects[i].height / combined_rect.height));
        }

        wxIFMRectEvent evt(wxEVT_IFM_SETDESIREDSIZE, children[i], child_rects[i]);
        GetIP()->ProcessPluginEvent(evt);
    }

    delete[] child_rects;
}

void wxIFMDefaultContainerPlugin::OnGetDesiredSize(wxIFMRectEvent &event)
{
    //! \todo I can cache this result and only recalculate it if any part of the component was updated

    // only process containers
    if( event.GetComponentType() != IFM_COMPONENT_CONTAINER )
    {
        event.Skip();
        return;
    }

    // return the combined calculated size of all child components
    wxSize size;
    int width = 0, height = 0;
    wxIFMComponent *container = event.GetComponent();

    wxASSERT_MSG(container, wxT("NULL component?"));
    if( !container )
        return;

    // return 0 if hidden
    if( container->m_hidden  || !HasVisibleChildren(container) )
    {
        event.SetSize(wxSize(0,0));
        return;
    }

    for( int i = 0, count = container->m_children.GetCount(); i < count; ++i )
    //for( wxIFMComponentArray::const_iterator i = container->m_children.begin(), end = container->m_children.end(); i != end; ++i )
    {
        size = container->m_children[i]->GetDesiredSize();
        //size = (*i)->GetDesiredSize();

        if( container->m_alignment == IFM_ALIGN_HORIZONTAL )
        {
            if( size.GetHeight() > height )
                height = size.GetHeight();
            width += size.GetWidth();
        }
        else if( container->m_alignment == IFM_ALIGN_VERTICAL )
        {
            if( size.GetWidth() > width )
                width = size.GetWidth();
            height += size.GetHeight();
        }
    }

    size.Set(width, height);

    // never size less than our minimum
    wxSize min_size = container->GetMinSize();
    // convert the min size back into client coords
    min_size = container->GetConvertedRect(wxRect(wxPoint(), min_size), IFM_COORDS_ABSOLUTE, IFM_COORDS_CLIENT).GetSize();

    if( min_size.y > size.GetHeight() && min_size.y != IFM_NO_MINIMUM )
        size.SetHeight(min_size.y);
    if( min_size.x > size.GetWidth() && min_size.x != IFM_NO_MINIMUM  )
        size.SetWidth(min_size.x);

    // convert from client to absolute coords to allow containers to have border and margin widths
    event.SetSize(container->GetConvertedRect(wxRect(wxPoint(), size), IFM_COORDS_CLIENT, IFM_COORDS_ABSOLUTE).GetSize());
}

/*
NOTE

  The event table entry for this function is commented out, because I no longer return (0,0,0,0)
  if it has no visible children
*/
void wxIFMDefaultContainerPlugin::OnGetRect(wxIFMRectEvent &event)
{
    if( event.GetComponentType() != IFM_COMPONENT_CONTAINER )
    {
        // return (0,0,0,0) if there are no visible children
        if( !HasVisibleChildren(event.GetComponent()) )
            event.SetRect(wxRect(0,0,0,0));
        else
            event.Skip();
    }
    else
        event.Skip();
}

void wxIFMDefaultContainerPlugin::OnDock(wxIFMDockEvent &event)
{
    // handle docking of components into containers
    if( event.GetDestinationType() == IFM_COMPONENT_CONTAINER )
    {
        GetNextHandler()->ProcessEvent(event);

        wxIFMComponent *component = event.GetComponent();

        // if we are docking a container into a container, give the child container
        // the IFM_ORIENTATION_DOCKED orientation value
        // FIXME: should I do this?
        if( component->GetType() == IFM_COMPONENT_CONTAINER )
        {
            wxIFMContainerData *contdata = IFM_GET_EXTENSION_DATA(component, wxIFMContainerData);

            wxASSERT_MSG(contdata, wxT("Container with no container data?"));
            if( !contdata )
                return;

            contdata->m_orientation = IFM_ORIENTATION_DOCKED;
        }
    }
    else
        event.Skip();
}

void wxIFMDefaultContainerPlugin::OnUndock(wxIFMUndockEvent &event)
{
    if( event.GetParentType() == IFM_COMPONENT_CONTAINER && event.GetComponentType() == IFM_COMPONENT_PANEL )
    {
        /*
        If the container is a docked container and will only have one child docked into it
        after this event is processed:

        -undock the container
        -undock the child from the container
        -dock the child into the containers old parent,
        -and destroy the container
        */
        wxIFMComponent *container = event.GetParent();
        wxIFMComponent *parent = container->m_parent;

        if( container->m_docked && container->m_children.GetCount() == 2 )
        {
            // save the container's index for later
            int index = 0;
            {
                wxIFMComponentArray &components = parent->m_children;
                //for( int count = components.GetCount(); index < count; index++ )
                for( wxIFMComponentArray::const_iterator i = components.begin(), end = components.end(); i != end; ++i, index++ )
                    if( *i /*components[index]*/ == container )
                        break;
            }

            GetNextHandler()->ProcessEvent(event);
            wxIFMComponent *child = container->m_children[0];

            // undock the child, but don't destroy the container
            wxIFMUndockEvent undockevt1(child, false);
            GetIP()->ProcessPluginEvent(undockevt1);

            // undock the container
            wxIFMUndockEvent undockevt2(container, false);
            GetIP()->ProcessPluginEvent(undockevt2);

            // dock the child where the container was
            wxIFMDockEvent dockevt(child, parent, index);
            GetIP()->ProcessPluginEvent(dockevt);

            // delete the container
            wxIFMDeleteComponentEvent delevt(container);
            GetIP()->ProcessPluginEvent(delevt);

            // reset the events parent because this function deletes it
            event.SetParent(parent);
            return;
        }
    }

    event.Skip();
}

#if IFM_CANFLOAT
void wxIFMDefaultContainerPlugin::UpdateFloatingCaption(wxIFMComponent *container)
{
    // if we are the root container of floating window and we have more than one child
    // display a native caption. If we have only one child, remove the native caption
    wxIFMFloatingData *floating_data = IFM_GET_EXTENSION_DATA(container, wxIFMFloatingData);
    if( !container->m_docked && floating_data->m_floating )
    {
        bool lower = false;

        wxWindow *wnd = floating_data->m_window->GetWindow();
        int style = wnd->GetWindowStyle();

        // hack around some wxWidgets "features"
        if( style & wxCAPTION )
            lower = true;

        if( GetVisibleChildrenCount(container) >= 2 )
        {
            if( style & wxCAPTION )
                return;
            style |= (wxCAPTION | wxFRAME_TOOL_WINDOW);
        }
        else
        {
            if( !(style & wxCAPTION) )
                return;
            style &= ~(wxCAPTION | wxFRAME_TOOL_WINDOW);
        }

        wnd->SetWindowStyle(style);

        // its not worth it, wxWidgets can fix their own bugs
        //if( lower )
            //wnd->Lower();
    }
}
#endif

void wxIFMDefaultContainerPlugin::OnVisibilityChange(wxIFMComponentVisibilityChangedEvent &event)
{
    if( event.GetComponentType() == IFM_COMPONENT_CONTAINER && !event.GetShow() )
    {
        wxIFMComponent *component = event.GetComponent();
        wxASSERT_MSG(component, wxT("NULL component?"));
        if( !component )
            return;

        // make sure our component buttons are hidden
        wxIFMContainerData *data = IFM_GET_EXTENSION_DATA(component, wxIFMContainerData);
        wxASSERT_MSG(data, wxT("Container with no container data?"));
        if( !data )
            return;

        //data->m_buttonManager.Show(false);
    }

    event.Skip();
}

void wxIFMDefaultContainerPlugin::OnShowComponent(wxIFMShowComponentEvent &event)
{
    /*
    wxIFMComponent *component = event.GetComponent();

    wxASSERT_MSG(component, wxT("NULL component?"));
    if( !component )
        return;

    wxIFMComponent *parent = component->m_parent;

    // hide the container if it has no more visible children
    if( parent && parent->GetType() == IFM_COMPONENT_CONTAINER )
    {

    }
    */

    event.Skip();
}

void wxIFMDefaultContainerPlugin::OnUpdate(wxIFMUpdateComponentEvent &event)
{
    // only process containers
    if( event.GetComponentType() != IFM_COMPONENT_CONTAINER )
    {
        event.Skip();
        return;
    }

    wxIFMComponent *container = event.GetComponent();

    wxASSERT_MSG(container, wxT("NULL component?"));
    if( !container )
        return;

    // size and position ourself first by passing the event down the chain
    // and to the default plugin
    GetNextHandler()->ProcessEvent(event);

    wxIFMContainerData *data = IFM_GET_EXTENSION_DATA(container, wxIFMContainerData);

    wxASSERT_MSG(data, wxT("Container with no container data?"));
    if( !data )
        return;

#if IFM_CONTAINER_GRIPPER_WIDTH
    // update the size and position of the tray_rect
    wxRect bg_rect = container->GetBackgroundRect();
    data->m_tray_rect.height = bg_rect.height;
    data->m_tray_rect.x = bg_rect.x;
    data->m_tray_rect.y = bg_rect.y;
#endif

#if IFM_CANFLOAT
    // if we are hidden, make sure our floating frame is hidden (if applicable) and do nothing
    if( container->m_hidden )
    {
        wxIFMFloatingData *floating_data = IFM_GET_EXTENSION_DATA(container, wxIFMFloatingData);
        if( floating_data->m_floating && !container->m_docked )
        {
            if( floating_data->m_window->GetWindow()->IsShown() )
                floating_data->m_window->GetWindow()->Hide();
        }
        return;
    }
#endif

    // current will be -1 if no components are visible
    int current = wxIFMComponent::GetNextVisibleComponent(container->m_children, 0);

    if( !HasVisibleChildren(container) )
        current = -1;

#if IFM_CANFLOAT
    wxIFMFloatingData *floating_data = IFM_GET_EXTENSION_DATA(container, wxIFMFloatingData);
    // if there are no visible children and we are a top level floating container, hide the floating window
    if( current == -1 && floating_data->m_floating && !container->m_docked )
    {
        floating_data->m_window->GetWindow()->Hide();
        return;
    }

    // if there are visible children and we are a top level floating container, make sure our floating window is shown
    if( current >= 0 && floating_data->m_floating && !container->m_docked )
    {
        if( !floating_data->m_window->GetWindow()->IsShown() )
            floating_data->m_window->GetWindow()->Show();
    }
#endif

    // don't use this for now, its not done yet
#if 0
    {
        wxIFMContainerData *data = IFM_GET_EXTENSION_DATA(container, wxIFMContainerData);

        wxASSERT_MSG(data, wxT("Container with no container data?"));
        if( !data )
            return;

        if( current == -1 )
        {
            // no visible children, make sure our component buttons are hidden too
            if( data )
                data->m_buttonManager.Show(false);

            return;
        }
        else if( HasNonCloseableChildren(container) )
        {
            if( data )
            {
                data->m_buttonManager.Show(true);
                data->m_buttonManager.Show(false, IFM_COMPONENT_ID_CLOSE);
            }
        }
        else
            if( data )
                data->m_buttonManager.Show(true);
    }
#endif

    // calculate rects of our children using the calc rects event
    wxIFMCalcRectsEvent calcevt(container);

    wxIFMComponentArray &children = container->m_children;
    //wxIFMComponentArray::iterator i, end;
    //for( i = children.begin(), end = children.end(); i != end; ++i )
    for( size_t i1 = 0; i1 < children.GetCount(); i1++ )
        calcevt.AddComponent(children[i1]);

    GetIP()->ProcessPluginEvent(calcevt);

    // position children
    const wxRectArray &rects = calcevt.GetComponentRects();
    //wxRectArray::const_iterator ri;
    for( size_t i = 0, ri = 0; i < children.GetCount(); i++, ri++ )
    //for( i = children.begin(), end = children.end(), ri = rects.begin(); i != end; ++i, ri++ )
    {
        if( children[i]->m_hidden )
            continue;
        else
        {
            wxIFMUpdateComponentEvent updevt(children[i], rects[ri]);
            GetIP()->ProcessPluginEvent(updevt);
        }
    }

    // position our buttons
#if 0
    wxIFMContainerData *data = IFM_GET_EXTENSION_DATA(container, wxIFMContainerData);
    wxASSERT_MSG(data, wxT("Container with no container data?"));
    if( data )
    {
        wxSize size = data->m_buttonManager.GetRect().GetSize();
        wxRect rect = container->GetBackgroundRect();
        data->m_buttonManager.SetPosition(wxPoint(rect.x + 1, rect.y));
        data->m_buttonManager.Layout();
    }
#endif

#if IFM_CANFLOAT
    // make sure our caption is hidden or shown as needed
    UpdateFloatingCaption(container);
#endif
}

#if IFM_CANFLOAT
void wxIFMDefaultContainerPlugin::OnFloatNotify(wxIFMFloatNotifyEvent &event)
{
    if( event.GetComponentType() == IFM_COMPONENT_CONTAINER )
    {
        GetNextHandler()->ProcessEvent(event);

        wxIFMComponent *component = event.GetComponent();

        wxASSERT_MSG(component, wxT("NULL component?"));
        if( !component )
            return;

        wxIFMContainerData *data = IFM_GET_EXTENSION_DATA(component, wxIFMContainerData);
        wxASSERT_MSG(data, wxT("Container with no container data?"));
        if( !data )
            return;

        // if we are floating a top level floating container
        // remove ourselves from the top level container list first
        if( event.GetFloating() )
        {
            if( data && (data->m_orientation == IFM_ORIENTATION_LEFT || data->m_orientation == IFM_ORIENTATION_RIGHT || data->m_orientation == IFM_ORIENTATION_TOP || data->m_orientation == IFM_ORIENTATION_BOTTOM) )
            {
                wxIFMRemoveTopContainerEvent evt(component);
                GetIP()->ProcessPluginEvent(evt);
            }
        }

        //data->m_buttonManager.SetParent(component->GetParentWindow());
    }
    else
        event.Skip();
}
#endif

void wxIFMDefaultContainerPlugin::OnComponentButtonClick(wxIFMComponentButtonEvent &event)
{
    wxIFMComponent *component = event.GetComponent();
    if( component->GetType() == IFM_COMPONENT_CONTAINER )
    {
        wxIFMComponentButton *button = event.GetButton();
        if( button->GetID() == IFM_COMPONENT_ID_CLOSE )
        {
            // hide ourself
            component->Show(false, true);
            return;
        }
    }

    event.Skip();
}

void wxIFMDefaultContainerPlugin::OnLeftDown(wxIFMMouseEvent &event)
{
    if( event.GetComponentType() == IFM_COMPONENT_CONTAINER )
    {
        wxPoint pos = event.GetMouseEvent().GetPosition();

        wxIFMComponent *component = event.GetComponent();

        wxASSERT_MSG(component, wxT("NULL component?"));
        if( !component )
            return;

        wxIFMContainerData *data = IFM_GET_EXTENSION_DATA(component, wxIFMContainerData);

        wxASSERT_MSG(data, wxT("Container with no container data?"));
        if( !data )
            return;

        if( data->m_tray_rect.Inside(pos) )
        {
            wxIFMInitDragEvent evt(component, component, pos);
            GetIP()->ProcessPluginEvent(evt);
        }
    }
    else
        event.Skip();
}

/*
wxIFMDefaultPanelPlugin implementation
*/
BEGIN_EVENT_TABLE(wxIFMDefaultPanelPlugin, wxIFMExtensionPluginBase)
    EVT_IFM_NEWCOMPONENT    (wxIFMDefaultPanelPlugin::OnCreateComponent)
    EVT_IFM_DELETECOMPONENT (wxIFMDefaultPanelPlugin::OnDestroyComponent)
    EVT_IFM_UPDATECOMPONENT (wxIFMDefaultPanelPlugin::OnUpdate)
    EVT_IFM_VISIBILITYCHANGED (wxIFMDefaultPanelPlugin::OnVisibilityChanged)
    EVT_IFM_SETCHILD        (wxIFMDefaultPanelPlugin::OnSetChild)
    EVT_IFM_SHOWCOMPONENT   (wxIFMDefaultPanelPlugin::OnShowComponent)
    EVT_IFM_PAINTDECOR      (wxIFMDefaultPanelPlugin::OnPaintDecor)
    EVT_IFM_PAINTBG         (wxIFMDefaultPanelPlugin::OnPaintBg)
    EVT_IFM_DOCK            (wxIFMDefaultPanelPlugin::OnDock)
    EVT_IFM_UNDOCK          (wxIFMDefaultPanelPlugin::OnUndock)
    EVT_IFM_COMPONENTBUTTONCLICK (wxIFMDefaultPanelPlugin::OnComponentButtonClick)
    EVT_IFM_LEFTDOWN       (wxIFMDefaultPanelPlugin::OnLeftDown)
    EVT_IFM_SELECTTAB       (wxIFMDefaultPanelPlugin::OnSelectTab)
    EVT_IFM_GETDESIREDSIZE  (wxIFMDefaultPanelPlugin::OnGetDesiredSize)
    EVT_IFM_SETDESIREDSIZE  (wxIFMDefaultPanelPlugin::OnSetDesiredSize)
    EVT_IFM_GETMINSIZE      (wxIFMDefaultPanelPlugin::OnGetMinSize)
    EVT_IFM_GETMAXSIZE      (wxIFMDefaultPanelPlugin::OnGetMaxSize)
    EVT_IFM_QUERYCHILD      (wxIFMDefaultPanelPlugin::OnQueryChild)

#if IFM_CANFLOAT
    EVT_IFM_FLOATING_NOTIFY (wxIFMDefaultPanelPlugin::OnFloatNotify)
#endif
END_EVENT_TABLE()

bool wxIFMDefaultPanelPlugin::Initialize(wxIFMInterfacePluginBase *plugin)
{
    wxIFMExtensionPluginBase::Initialize(plugin);

    // load component button bitmaps
    m_bmpClose = wxBitmap(btn_hide_xpm);
    m_bmpMin = wxBitmap(btn_min_xpm);
    m_bmpMax = wxBitmap(btn_max_xpm);
    m_bmpCloseH = wxBitmap(btn_hide_h_xpm);
    m_bmpMinH = wxBitmap(btn_min_h_xpm);
    m_bmpMaxH = wxBitmap(btn_max_h_xpm);
    m_bmpCloseP = wxBitmap(btn_hide_hp_xpm);
    m_bmpMinP = wxBitmap(btn_min_hp_xpm);
    m_bmpMaxP = wxBitmap(btn_max_hp_xpm);

    // determine the height of the caption and tabs based on the height of its font
    m_caption_config.font = wxSystemSettings::GetFont(wxSYS_DEFAULT_GUI_FONT);
    m_caption_config.color = /*wxColour(0, 51, 153)*/ wxSystemSettings::GetColour(wxSYS_COLOUR_ACTIVECAPTION);

    int w, h;
    GetManager()->GetParent()->GetTextExtent(wxT(" "), &w, &h, 0, 0, &m_caption_config.font);

    m_caption_config.font_height = h;
    m_caption_config.padding = m_caption_config.font_height / 4;
    m_caption_config.height = m_caption_config.font_height + m_caption_config.padding;

    // configure tab data
    m_tab_config.font = m_caption_config.font;
    m_tab_config.font_color = wxSystemSettings::GetColour(wxSYS_COLOUR_BTNTEXT);
    m_tab_config.font_height = h;
    m_tab_config.tab_padding = m_tab_config.font_height / 4;
    m_tab_config.tab_height = m_tab_config.font_height + m_tab_config.tab_padding * 2;
    m_tab_config.row_height = m_tab_config.tab_height + 2;
    m_tab_config.row_indent = 2;
    m_tab_config.rounding_factor = 3;
    m_tab_config.tab_spacing = -1;

    m_tab_config.tab_border_p = wxPen(wxSystemSettings::GetColour(wxSYS_COLOUR_BTNSHADOW));
    m_tab_config.tab_active_bg_b = wxBrush(wxSystemSettings::GetColour(wxSYS_COLOUR_BTNHIGHLIGHT));
    m_tab_config.tab_active_bg_p = wxPen(wxSystemSettings::GetColour(wxSYS_COLOUR_BTNHIGHLIGHT));
    m_tab_config.tab_inactive_bg_b = wxBrush(wxSystemSettings::GetColour(wxSYS_COLOUR_BTNFACE));
    m_tab_config.tab_inactive_bg_p = wxPen(wxSystemSettings::GetColour(wxSYS_COLOUR_BTNFACE));
    m_tab_config.bg_brush = wxBrush(wxSystemSettings::GetColour(wxSYS_COLOUR_3DLIGHT));
    m_tab_config.bg_pen = wxPen(wxSystemSettings::GetColour(wxSYS_COLOUR_3DLIGHT));
    m_tab_config.line_pen = m_tab_config.tab_border_p;

    return true;
}

void wxIFMDefaultPanelPlugin::OnCreateComponent(wxIFMNewComponentEvent &event)
{
    // create tabs
    if( event.GetComponentType() == IFM_COMPONENT_PANEL_TAB )
    {
        // create a new component
        wxIFMComponent *tab = new wxIFMComponent(GetIP(), IFM_COMPONENT_PANEL_TAB);

        // add panel specific data storage
        wxIFMPanelTabData *tabdata = new wxIFMPanelTabData();

        tab->AddExtensionData(tabdata);

        tab->m_borders.Set(0);
        tab->m_margins.Set(0);

        // return the new component
        event.SetComponent(tab);
    }
    // create panels too
    else if( event.GetComponentType() == IFM_COMPONENT_PANEL )
    {
        wxIFMComponent *panel = new wxIFMComponent(GetIP(), IFM_COMPONENT_PANEL);
        wxIFMPanelData *data = new wxIFMPanelData(GetIP(), panel);
        panel->AddExtensionData(data);

        panel->m_margins.Set(1);
        panel->m_margins.top += m_caption_config.height + IFM_CAPTION_PAD*2;
        panel->m_margins.bottom += m_tab_config.row_height;
        panel->m_borders.Set(1);

        // add close, maximize, minimize buttons
        wxIFMComponentButton *btn;

        /*
            We dont use these buttons yet, comment them out until they are implemented

        btn = data->m_buttonManager.AddButton(IFM_COMPONENT_ID_MINIMIZE);
        btn->m_bmp = &m_bmpMin;
        btn->m_bmpH = &m_bmpMinH;
        btn->m_bmpP = &m_bmpMinP;

        btn = data->m_buttonManager.AddButton(IFM_COMPONENT_ID_MAXIMIZE);
        btn->m_bmp = &m_bmpMax;
        btn->m_bmpH = &m_bmpMaxH;
        btn->m_bmpP = &m_bmpMaxP;
        */

        data->m_button_manager.SetPosition(wxPoint(1, (m_caption_config.height - IFM_COMPONENT_BUTTON_Y) / 2));
        btn = data->m_button_manager.AddButton(IFM_COMPONENT_ID_CLOSE);
        btn->m_bmp = &m_bmpClose;
        btn->m_bmpH = &m_bmpCloseH;
        btn->m_bmpP = &m_bmpCloseP;
        btn->SetBackgroundColour(m_caption_config.color);

        event.SetComponent(panel);
    }
    else
        event.Skip();
}

void wxIFMDefaultPanelPlugin::OnDestroyComponent(wxIFMDeleteComponentEvent &event)
{
    if( event.GetComponentType() == IFM_COMPONENT_PANEL )
    {
        wxIFMComponent *panel = event.GetComponent();

        wxASSERT_MSG(panel, wxT("NULL component?"));
        if( !panel )
            return;

        wxIFMPanelData *data = IFM_GET_EXTENSION_DATA(panel, wxIFMPanelData);

        wxASSERT_MSG(data, wxT("Panel with no panel data?"));
        if( !data )
            return;

        data->m_button_manager.Hide();
    }
    event.Skip();
}

//! \todo Move this into defaultplugin
void wxIFMDefaultPanelPlugin::OnSetChild(wxIFMSetChildEvent &event)
{
    wxIFMComponent *panel = event.GetComponent();

    // set the child
    panel->m_child = event.GetChild();
    panel->m_childType = event.GetChildType();

    // hide the child if the panel is hidden
    if( panel->m_hidden )
        panel->m_child->Hide();

    /*
    wxIFMPanelTabData *data = IFM_GET_EXTENSION_DATA(panel, wxIFMPanelTabData);

    // give us a caption if needed
    if( panel->m_childType == IFM_CHILD_TOOLBAR )
    {
        data->m_hasCaption = false;
        data->m_buttonManager.Hide();

        // set max and min heights to match toolbar height
        panel->m_minSize = panel->m_child->GetBestSize();
        panel->m_maxSize = panel->m_child->GetBestSize();
        panel->m_desiredSize = panel->m_child->GetBestSize();
    }
    else
    {
        data->m_buttonManager.Show();
        data->m_hasCaption = true;
        panel->m_margins.top += m_caption_config.height + 1;
    }

    data->m_buttonManager.Show(panel->m_canHide, IFM_COMPONENT_ID_CLOSE);
    */
}

void wxIFMDefaultPanelPlugin::OnQueryChild(wxIFMQueryChildEvent &event)
{
    wxIFMComponent *tab = event.GetComponent();
    if( tab->GetType() == IFM_COMPONENT_PANEL_TAB )
    {
        event.SetVisible(false);
        wxIFMComponent *parent = tab->m_parent;

        if( !parent->IsVisible() )
            return;

        wxIFMPanelData *data = IFM_GET_EXTENSION_DATA(parent, wxIFMPanelData);
        for(unsigned int i = 0; i < data->m_tabs.GetCount(); i++)
        {
            wxIFMTab *tab = data->m_tabs[i];
            if(tab->m_tab->m_child == event.GetChild())
            {
                event.SetVisible(tab->m_visible);
                break;
            }
        }
    }
    else
        event.Skip();
}

void wxIFMDefaultPanelPlugin::OnDock(wxIFMDockEvent &event)
{
    // if we are docking a panel with one tab, dock the tab, instead of the panel
    if( event.GetDestinationType() == IFM_COMPONENT_PANEL && event.GetComponentType() == IFM_COMPONENT_PANEL )
    {
        wxIFMComponent *panel = event.GetComponent();

        wxASSERT_MSG(panel, wxT("NULL component?"));
        if( !panel )
            return;

        wxIFMPanelData *data = IFM_GET_EXTENSION_DATA(panel, wxIFMPanelData);

        wxASSERT_MSG(data, wxT("Panel with no panel data?"));
        if( !data )
            return;

        if( data->m_tabs.size() == 1 )
        {
            wxIFMComponent *tab = data->m_tabs[0]->m_tab;
            // dock the tab of that panel into the destination panel
            wxIFMUndockEvent undock(tab, false);
            GetIP()->ProcessPluginEvent(undock);

            wxIFMDockEvent dock(tab, event.GetDestination(), event.GetIndex());
            GetIP()->ProcessPluginEvent(dock);
            return;
        }
    }

    // dock stuff into panels
    if( event.GetDestinationType() == IFM_COMPONENT_PANEL )
    {
        // default processing
        GetNextHandler()->ProcessEvent(event);

        wxIFMComponent *tabbed_panel = event.GetDestination();
        wxIFMComponent *panel_tab = event.GetComponent();

        wxASSERT_MSG(tabbed_panel && panel_tab, wxT("NULL tab or panel?"));
        if( !tabbed_panel || !panel_tab )
            return;

        wxIFMPanelData *data = IFM_GET_EXTENSION_DATA(tabbed_panel, wxIFMPanelData);

        wxASSERT_MSG(data, wxT("Panel with no panel data?"));
        if( !data )
            return;

        // if this is the first tab of this panel, make the panels desired size large enough
        // to accomodate the panel
        if( tabbed_panel->m_children.size() == 1 )
        {
            tabbed_panel->SetDesiredSize(tabbed_panel->GetConvertedRect( // convert from client to absolute
                wxRect(wxPoint(), panel_tab->GetDesiredSize()), // make a rect
                IFM_COORDS_CLIENT, IFM_COORDS_ABSOLUTE).GetSize()); // get its size
        }

        int index = event.GetIndex(), count = panel_tab->m_children.size() - 1;

        // create and initialize the tab
        wxIFMTab *tab = new wxIFMTab;
        tab->m_tab = panel_tab;

        // calculate the width of the tabs name string
        int h;
        GetManager()->GetParent()->GetTextExtent(tab->m_tab->m_name, &tab->m_name_width, &h, 0, 0, &m_tab_config.font);
        if( tab->m_name_width == 0 )
            tab->m_name_width = 20;

        if( index == IFM_DEFAULT_INDEX || index > count )
        {
            // add it as the last tab
            data->m_tabs.push_back(tab);
        }
        else
        {
            // add it where it wants to be
            data->m_tabs.insert(data->m_tabs.begin() + index, tab);
        }

        panel_tab->m_parent = tabbed_panel;

        wxIFMSelectTabEvent evt(tabbed_panel, tab, false);
        GetIP()->ProcessPluginEvent(evt);
    }
    // also, if a tab is docked directly into a container
    // dock a panel there instead, and then dock the tab into the panel
    else if( event.GetDestinationType() == IFM_COMPONENT_CONTAINER && event.GetComponentType() == IFM_COMPONENT_PANEL_TAB )
    {
        wxIFMComponent *tab = event.GetComponent();

        // create the tab
        wxIFMNewComponentEvent newevt(IFM_COMPONENT_PANEL);
        GetIP()->ProcessPluginEvent(newevt);

        wxIFMComponent *panel = newevt.GetComponent();

        // dock the panel where the tab was going
        wxIFMDockEvent dockevt1(panel, event.GetDestination(), event.GetIndex());
        GetIP()->ProcessPluginEvent(dockevt1);

        // dock the tab into the panel
        wxIFMDockEvent dockevt2(tab, panel, 0);
        GetIP()->ProcessPluginEvent(dockevt2);
    }
    else
        event.Skip();
}

void wxIFMDefaultPanelPlugin::OnUndock(wxIFMUndockEvent &event)
{
    // undock stuff from panels
    if( event.GetParentType() == IFM_COMPONENT_PANEL )
    {
        // find the tab which represented this component and remove it

        wxIFMComponent *panel = event.GetParent();
        wxIFMComponent *panel_tab = event.GetComponent();

        wxASSERT_MSG(panel, wxT("NULL component?"));
        if( !panel )
            return;

        wxIFMPanelData *data = IFM_GET_EXTENSION_DATA(panel, wxIFMPanelData);

        wxASSERT_MSG(data, wxT("Tabbed panel with no tabbed panel data?"));
        if( !data )
            return;

        wxIFMTab *tab = NULL;
        for( size_t i = 0; i < data->m_tabs.GetCount(); i++ )
        //for( wxIFMTabArray::iterator i = data->m_tabs.begin(), end = data->m_tabs.end(); i != end; ++i )
        {
            tab = data->m_tabs[i];
            if( tab->m_tab == panel_tab )
            {
                data->m_tabs.RemoveAt(i);
                break;
            }
            tab = NULL;
        }

        // select a new tab
        if( data->m_tabs.size() > 0 )
        {
            if( tab == data->m_active_tab )
            {
                wxIFMSelectTabEvent evt(panel, data->m_tabs[0], true);
                GetIP()->ProcessPluginEvent(evt);
            }
        }
        else
            data->m_active_tab = NULL;

        delete tab;

        // default processing
        GetNextHandler()->ProcessEvent(event);
    }
    else
        event.Skip();
}

void wxIFMDefaultPanelPlugin::OnUpdate(wxIFMUpdateComponentEvent &event)
{
    // process tabs
    if( event.GetComponentType() == IFM_COMPONENT_PANEL_TAB )
    {
        wxIFMComponent *tab = event.GetComponent();

        wxASSERT_MSG(tab, wxT("NULL component?"));
        if( !tab )
            return;

        wxASSERT_MSG(tab->m_child, wxT("Panel with null child!"));
        if( !tab->m_child )
            return;

        if( !tab->IsVisible() )
        {
            // make sure our child is hidden
            if( tab->m_child->IsShown() )
                tab->m_child->Show(false);
            return;
        }
        else
        {
            // make sure our child is visible since the tab is visible
            if( !tab->m_child->IsShown() )
                tab->m_child->Show();
        }

        // size and position ourself by passing the event down the chain
        // and to the default component handler
        // WARNING: If plugins are added in the wrong order GetNextHandler may return null!
        GetNextHandler()->ProcessEvent(event);

        // request client size and position
        wxIFMRectEvent rectevt2(wxEVT_IFM_GETCLIENTRECT, tab);
        GetIP()->ProcessPluginEvent(rectevt2);

        // size our child window
        tab->m_child->SetSize(rectevt2.GetRect());
    }
    // and panels
    else if( event.GetComponentType() == IFM_COMPONENT_PANEL )
    {
        wxIFMComponent *panel = event.GetComponent();

        wxASSERT_MSG(panel, wxT("NULL component?"));
        if( !panel )
            return;

        wxIFMPanelData *data = IFM_GET_EXTENSION_DATA(panel, wxIFMPanelData);

        wxASSERT_MSG(data, wxT("Tabbed panel with no tabbed panel data?"));
        if( !data )
            return;

        if( !data->m_active_tab )
            return;

        // forward the update event to the active panel but size ourself first
        GetNextHandler()->ProcessEvent(event);

        // set the caption rect
        wxRect rect = panel->GetBackgroundRect();
        data->m_caption.x = rect.x + IFM_CAPTION_PAD;
        data->m_caption.y = rect.y + IFM_CAPTION_PAD;
        data->m_caption.height = m_caption_config.height;
        data->m_caption.width = rect.width - IFM_CAPTION_PAD*2;

        // set the caption title position too
        data->m_titlePos.x = data->m_caption.x + m_caption_config.padding;
        data->m_titlePos.y = data->m_caption.y + (m_caption_config.height - m_caption_config.font_height)/2;

        // update the active panel tab
        wxRect client_rect = panel->GetClientRect();
        wxIFMUpdateComponentEvent evt(data->m_active_tab->m_tab, client_rect);
        GetIP()->ProcessPluginEvent(evt);

        wxRect tab_rect;
        tab_rect.x = rect.x + m_tab_config.row_indent;
        tab_rect.y = rect.y + rect.height - m_tab_config.row_height;
        tab_rect.height = m_tab_config.tab_height;

        // update the tab positions
        for( size_t i = 0; i < data->m_tabs.GetCount(); i++ )
        //for( wxIFMTabArray::iterator i = data->m_tabs.begin(), end = data->m_tabs.end(); i != end; ++i )
        {
            wxIFMTab *tab = data->m_tabs[i];

            if( !tab->m_visible )
                continue;

            wxIFMPanelTabData *tab_data = IFM_GET_EXTENSION_DATA(tab->m_tab, wxIFMPanelTabData);

            tab_rect.width = tab->m_name_width + m_tab_config.tab_padding + m_tab_config.tab_padding;

            if(tab_data && tab_data->m_bitmap.Ok())
                tab_rect.width += tab_data->m_bitmap.GetWidth() + m_tab_config.tab_padding;

            tab->m_rect = tab_rect;
            tab_rect.x += tab_rect.width + m_tab_config.tab_spacing;
        }

        // position compontent buttons
        wxSize size = data->m_button_manager.GetRect().GetSize();
        data->m_button_manager.SetPosition(wxPoint(data->m_caption.x + data->m_caption.width - size.x, data->m_caption.y));
        data->m_button_manager.Layout();
    }
    else
        event.Skip();
}

void wxIFMDefaultPanelPlugin::OnShowComponent(wxIFMShowComponentEvent &event)
{
    GetNextHandler()->ProcessEvent(event);

    bool show = event.GetShow();

    wxIFMComponent *component = event.GetComponent();

    wxASSERT_MSG(component, wxT("NULL component?"));
    if( !component )
        return;

    wxIFMComponent *panel = component->m_parent;

    if( !panel )
        return;

    if( panel->GetType() == IFM_COMPONENT_PANEL )
    {
        // show or hide the tab for this child
        wxIFMPanelData *data = IFM_GET_EXTENSION_DATA(panel, wxIFMPanelData);

        // don't do anything if we hide this component ourselves
        if( data->m_dont_hide_tab )
        {
            data->m_dont_hide_tab = false;
            return;
        }

        // find the tab
        wxIFMTab *tab = NULL;
        for( size_t i = 0; i < data->m_tabs.GetCount(); i++ )
        //for( wxIFMTabArray::iterator i = data->m_tabs.begin(), end = data->m_tabs.end(); i != end; ++i )
        {
            tab = data->m_tabs[i];
            if( tab->m_tab == component )
                break;
        }

        tab->m_visible = show;

        if( !show )
        {
            bool vis = false;

            // if there are no visible tabs left, hide the panel too
            for( size_t i = 0; i < data->m_tabs.GetCount(); i++ )
            //for( wxIFMTabArray::iterator i = data->m_tabs.begin(), end = data->m_tabs.end(); i != end; ++i )
            {
                wxIFMTab *tab = data->m_tabs[i];
                if( tab->m_visible )
                {
                    vis = true;
                    break;
                }
            }

            if( !vis )
                panel->Hide();

            // if we hide the active tab, select another
            else if( tab->m_active )
            {
                // find the next visible tab to select
                wxIFMTab *new_tab;
                for( size_t i = 0; i < data->m_tabs.GetCount(); i++ )
                //for( wxIFMTabArray::iterator i = data->m_tabs.begin(), end = data->m_tabs.end(); i != end; ++i )
                {
                    new_tab = data->m_tabs[i];
                    if( new_tab->m_visible && new_tab != tab )
                    {
                        wxIFMSelectTabEvent evt(panel, new_tab, false);
                        GetIP()->ProcessPluginEvent(evt);
                        break;
                    }
                }
            }
        }
        // select the tab if its being shown
        else
        {
            wxIFMSelectTabEvent evt(panel, tab, false);
            GetIP()->ProcessPluginEvent(evt);
        }
    }
}

void wxIFMDefaultPanelPlugin::OnVisibilityChanged(wxIFMComponentVisibilityChangedEvent &event)
{
    wxIFMComponent *component = event.GetComponent();

    wxASSERT_MSG(component, wxT("NULL component?"));
    if( !component )
        return;

    bool shown = event.GetShow();

    if( event.GetComponentType() == IFM_COMPONENT_PANEL_TAB )
    {
        // we would normally show the child here as well, but we
        // will wait for the next update component event and let it
        // take care of that for us

        // we will however hide the child immediately if needed
        if( !shown )
            component->m_child->Show(false);
    }
    else if( event.GetComponentType() == IFM_COMPONENT_PANEL )
    {
        wxIFMPanelData *data = IFM_GET_EXTENSION_DATA(component, wxIFMPanelData);

        wxASSERT_MSG(data, wxT("Tabbed panel with no tabbed panel data?"));
        if( !data )
            return;

        data->m_button_manager.Show(shown);
    }

    // if the component's parent is a panel, then the component is a tab of that panel.
    // show or hide that tab if the component was hidden

    // skip to let the default implementation send the notification to our children, in case we have any
    event.Skip();
}

#if IFM_CANFLOAT

void wxIFMDefaultPanelPlugin::OnFloatNotify(wxIFMFloatNotifyEvent &event)
{
    wxIFMComponent *component = event.GetComponent();

    wxASSERT_MSG(component, wxT("NULL component?"));
    if( !component )
        return;

    // process for panel tabs
    if( event.GetComponentType() == IFM_COMPONENT_PANEL_TAB )
    {
        // let the default plugin go first
        GetNextHandler()->ProcessEvent(event);

        if( component->m_child )
            component->m_child->Reparent(component->GetParentWindow());
    }
    // and panels
    else if( event.GetComponentType() == IFM_COMPONENT_PANEL )
    {
        // let the default plugin go first
        GetNextHandler()->ProcessEvent(event);

        wxIFMPanelData *data = IFM_GET_EXTENSION_DATA(component, wxIFMPanelData);

        wxASSERT_MSG(data, wxT("Panel with no panel data?"));
        if( !data )
            return;

        data->m_button_manager.SetParent(component->GetParentWindow());
    }
    else
        event.Skip();
}

#endif // IFM_CANFLOAT

void wxIFMDefaultPanelPlugin::OnPaintDecor(wxIFMPaintEvent &event)
{
    if( event.GetComponentType() == IFM_COMPONENT_PANEL )
    {
        wxRegion region = event.GetRegion();
        wxIFMComponent *component = event.GetComponent();

        wxASSERT_MSG(component, wxT("NULL component?"));
        if( !component )
            return;

        if( component->m_hidden )
            return;

        wxIFMPanelData *data = IFM_GET_EXTENSION_DATA(component, wxIFMPanelData);

        wxASSERT_MSG(data, wxT("Panel with no panel data?"));
        if( !data )
            return;

        wxDC &dc = event.GetDC();
        wxRegionContain result = region.Contains(data->m_caption);
        if( result == wxPartRegion || result == wxInRegion )
        {
            dc.SetBrush(wxBrush(m_caption_config.color));
            dc.SetPen(wxPen(m_caption_config.color));

            // draw caption background
            dc.DrawRectangle(data->m_caption);

            // draw caption text
            dc.SetFont(m_caption_config.font);
            dc.SetTextForeground(wxSystemSettings::GetColour(wxSYS_COLOUR_CAPTIONTEXT));
            if( data->m_active_tab )
                dc.DrawText(data->m_active_tab->m_tab->m_name, data->m_titlePos.x, data->m_titlePos.y);
        }

        // draw the tabs
        DrawTabs(dc, component, region, data->m_tabs);
    }
    else
        event.Skip();
}

void wxIFMDefaultPanelPlugin::OnPaintBg(wxIFMPaintEvent &event)
{
    if( event.GetComponentType() == IFM_COMPONENT_PANEL || event.GetComponentType() == IFM_COMPONENT_PANEL_TAB )
    {
        wxIFMComponent *component = event.GetComponent();

        wxASSERT_MSG(component, wxT("NULL component?"));
        if( !component )
            return;

        if( component->m_hidden )
            return;

        wxRect rect = component->GetBackgroundRect();
        wxDC &dc = event.GetDC();

        // draw the background with the same color as the active tab background
        dc.SetBrush(m_tab_config.tab_active_bg_b);
        dc.SetPen(wxPen(m_tab_config.tab_active_bg_b.GetColour()));

        dc.DrawRectangle(rect);
    }
    else
        event.Skip();
}

void wxIFMDefaultPanelPlugin::DrawTabs(wxDC &dc, wxIFMComponent *component, const wxRegion &region, const wxIFMTabArray &tabs)
{
    wxIFMTab *tab;

    wxRect bg = component->GetClientRect();
    wxRect tabs_area;
    tabs_area.x = bg.x;
    tabs_area.y = bg.y + bg.height + 1;// - 1;//tab->m_tab->m_parent->m_margins.bottom;
    tabs_area.width = bg.width;
    tabs_area.height = m_tab_config.row_height;

    // paint tabs only if we need to
    wxRegionContain result = region.Contains(tabs_area);
    if( !(result == wxInRegion || result == wxPartRegion) )
        return;

    // background for tabs area
    dc.SetPen(m_tab_config.bg_pen);
    dc.SetBrush(m_tab_config.bg_brush);
    dc.DrawRectangle(tabs_area);

    // top line
    dc.SetPen(m_tab_config.line_pen);
    dc.DrawLine(tabs_area.x-1, tabs_area.y, tabs_area.x + tabs_area.width+1, tabs_area.y);

    wxIFMPanelTabData *tab_data;
    wxRect rect;

    //for( wxIFMTabArray::const_iterator i = tabs.begin(), end = tabs.end(); i != end; ++i )
    for( size_t i = 0; i < tabs.GetCount(); i++ )
    {
        //tab = *i;
        tab = tabs[i];

        if( !tab->m_visible )
            continue;

        // don't paint the tab if its not in the update region
        result = region.Contains(tab->m_rect);
        if( !(result == wxInRegion || result == wxPartRegion) )
            continue;

        rect = tab->m_rect;

        // draw the tab background
        // if the tab is not selected draw a black line above
        if( tab->m_active )
        {
            dc.SetBrush(m_tab_config.tab_active_bg_b);
            dc.SetPen(m_tab_config.tab_border_p);
            dc.DrawRoundedRectangle(rect.x, rect.y, rect.width, rect.height, m_tab_config.rounding_factor);

            dc.SetPen(m_tab_config.tab_active_bg_p);
            dc.DrawRectangle(rect.x, rect.y, rect.width, m_tab_config.rounding_factor);

            dc.SetPen(m_tab_config.tab_border_p);
            dc.DrawLine(rect.x, rect.y, rect.x, rect.y + m_tab_config.rounding_factor);
            dc.DrawLine(rect.x + rect.width - 1, rect.y, rect.x + rect.width - 1, rect.y + m_tab_config.rounding_factor);
        }
        else
        {
            dc.SetBrush(m_tab_config.tab_inactive_bg_b);
            dc.SetPen(m_tab_config.tab_border_p);
            dc.DrawRoundedRectangle(rect.x, rect.y, rect.width, rect.height, m_tab_config.rounding_factor);

            dc.SetPen(m_tab_config.tab_inactive_bg_p);
            dc.DrawRectangle(rect.x, rect.y, rect.width, m_tab_config.rounding_factor);

            dc.SetPen(m_tab_config.tab_border_p);
            dc.DrawLine(rect.x, rect.y, rect.x, rect.y + m_tab_config.rounding_factor);
            dc.DrawLine(rect.GetRight(), rect.y, rect.GetRight(), rect.y + m_tab_config.rounding_factor);

            dc.SetPen(m_tab_config.line_pen);
            dc.DrawLine(rect.x, rect.y, rect.x+rect.width, rect.y);
        }

        tab_data = IFM_GET_EXTENSION_DATA(tab->m_tab, wxIFMPanelTabData);

        // draw bitmap
        if(tab_data && tab_data->m_bitmap.Ok())
        {
            wxBitmap &bmp = tab_data->m_bitmap;
            dc.DrawBitmap(bmp, rect.x + m_tab_config.tab_padding, rect.y + (rect.height - bmp.GetHeight())/2, true);
            rect.x += m_tab_config.tab_padding + bmp.GetWidth();
        }

        // draw the label
        dc.SetFont(m_tab_config.font);
        dc.SetTextForeground(m_tab_config.font_color);

        dc.DrawText(tab->m_tab->m_name, rect.x + m_tab_config.tab_padding, rect.y + (rect.height - m_tab_config.font_height) / 2);
    }
}

void wxIFMDefaultPanelPlugin::OnComponentButtonClick(wxIFMComponentButtonEvent &event)
{
    wxIFMComponent *component = event.GetComponent();

    wxASSERT_MSG(component, wxT("NULL component?"));
    if( !component )
        return;

    if( component->GetType() == IFM_COMPONENT_PANEL )
    {
        wxIFMComponentButton *button = event.GetButton();
        if( button->GetID() == IFM_COMPONENT_ID_CLOSE )
        {
            component->Show(false, true);
            return;
        }
        else if( button->GetID() == IFM_COMPONENT_ID_MINIMIZE )
        {

            //! \todo implement minimizing of components
            return;
        }
        else if( button->GetID() == IFM_COMPONENT_ID_MAXIMIZE )
        {

            //! \todo implement maximizing of components
            return;
        }
    }

    event.Skip();
}

void wxIFMDefaultPanelPlugin::OnLeftDown(wxIFMMouseEvent &event)
{
    wxMouseEvent &evt = event.GetMouseEvent();
    wxPoint pos = evt.GetPosition();
    if( event.GetComponentType() == IFM_COMPONENT_PANEL )
    {
        wxIFMComponent *component = event.GetComponent();

        wxASSERT_MSG(component, wxT("NULL component?"));
        if( !component )
            return;

        wxIFMPanelData *data = IFM_GET_EXTENSION_DATA(component, wxIFMPanelData);

        wxASSERT_MSG(data, wxT("Panel with no panel data?"));
        if( !data )
            return;

        // see if the user clicked on a tab and select it
        for( size_t i = 0; i < data->m_tabs.GetCount(); i++ )
        //for( wxIFMTabArray::const_iterator i = data->m_tabs.begin(), end = data->m_tabs.end(); i != end; ++i )
        {
            wxIFMTab *tab = data->m_tabs[i];
            if( tab->m_visible && tab->m_rect.Inside(event.GetMouseEvent().GetPosition()) )
            {
                wxIFMSelectTabEvent evt(component, tab, true);
                GetIP()->ProcessPluginEvent(evt);
                break;
            }
        }

        // now check for drag initialization hot spots which are the caption and any tab
        if( data->m_caption.Inside(pos) )
        {
            wxIFMInitDragEvent evt(component, component, pos);
            GetIP()->ProcessPluginEvent(evt);
        }
        else
        {
            // check for individual tab hits
            for( size_t i = 0; i < data->m_tabs.GetCount(); i++ )
            //for(wxIFMTabArray::iterator i = data->m_tabs.begin(), end = data->m_tabs.end(); i != end; ++i )
            {
                wxIFMTab *tab = data->m_tabs[i];
                if( tab->m_visible && tab->m_rect.Inside(pos) )
                {
                    // if we only have one tab drag the panel instead of the tab
                    wxIFMComponent *drag;
                    if( data->m_tabs.size() == 1 )
                        drag = component;
                    else
                        drag = tab->m_tab;

                    wxIFMInitDragEvent evt(component, drag, pos);
                    GetIP()->ProcessPluginEvent(evt);
                    break;
                }
            }
        }
    }
    else
        event.Skip();
}

void wxIFMDefaultPanelPlugin::OnSelectTab(wxIFMSelectTabEvent &event)
{
    if( event.GetComponentType() == IFM_COMPONENT_PANEL )
    {
        wxIFMComponent *panel = event.GetComponent();

        wxASSERT_MSG(panel, wxT("NULL component?"));
        if( !panel )
            return;

        wxIFMPanelData *data = IFM_GET_EXTENSION_DATA(panel, wxIFMPanelData);

        wxASSERT_MSG(data, wxT("Tabbed panel with no tabbed panel data?"));
        if( !data )
            return;

        wxIFMTab *tab = event.GetTab();

        // don't active the current tab over again
        if( tab == data->m_active_tab )
            return;

        // record the new active tab
        data->m_active_tab = tab;

        // update the new tab
        if( event.GetUpdate() )
        {
            wxIFMUpdateComponentEvent evt(tab->m_tab, panel->GetClientRect());
            GetIP()->ProcessPluginEvent(evt);
        }

        // show and activate the new tab while hiding the others
        for( size_t i = 0; i < data->m_tabs.GetCount(); i++ )
        //for( wxIFMTabArray::iterator i = data->m_tabs.begin(), end = data->m_tabs.end(); i != end; ++i )
        {
            data->m_dont_hide_tab = true;
            data->m_tabs[i]->m_tab->Show(data->m_tabs[i] == tab, false);
            data->m_tabs[i]->m_active = data->m_tabs[i] == tab;
        }

        if(event.GetUpdate()) {
            wxIFMUpdateComponentEvent evt(panel, panel->GetRect());
            GetIP()->ProcessPluginEvent(evt);
        }
    }
    else
        event.Skip();
}

void wxIFMDefaultPanelPlugin::OnGetDesiredSize(wxIFMRectEvent &event)
{
    /*
    if( event.GetComponentType() == IFM_COMPONENT_PANEL )
    {
        wxIFMComponent *panel = event.GetComponent();

        wxASSERT_MSG(panel, wxT("NULL component?"));
        if( !panel )
            return;

        wxIFMPanelData *data = IFM_GET_EXTENSION_DATA(panel, wxIFMPanelData);

        wxASSERT_MSG(data, wxT("Tabbed panel with no tabbed panel data?"));
        if( !data )
            return;

        // use the active tabs desired size
        event.SetRect(panel->GetConvertedRect(wxRect(wxPoint(), data->m_active_tab->GetDesiredSize()), IFM_COORDS_CLIENT, IFM_COORDS_ABSOLUTE));
    }
    else
    */
        event.Skip();
}

void wxIFMDefaultPanelPlugin::OnSetDesiredSize(wxIFMRectEvent &event)
{
    if( event.GetComponentType() == IFM_COMPONENT_PANEL )
    {
        wxIFMComponent *panel = event.GetComponent();

        wxASSERT_MSG(panel, wxT("NULL component?"));
        if( !panel )
            return;

        wxIFMPanelData *data = IFM_GET_EXTENSION_DATA(panel, wxIFMPanelData);

        wxASSERT_MSG(data, wxT("Tabbed panel with no tabbed panel data?"));
        if( !data )
            return;

        // set the size for all tabs
        wxSize size = panel->GetConvertedRect(event.GetRect(), IFM_COORDS_ABSOLUTE, IFM_COORDS_CLIENT).GetSize();

        for( size_t i = 0; i < data->m_tabs.GetCount(); i++ )
        //for( wxIFMTabArray::iterator i = data->m_tabs.begin(), end = data->m_tabs.end(); i != end; ++i )
            data->m_tabs[i]->m_tab->SetDesiredSize(size);

        // skip to set our own desired size too
    }

    event.Skip();
}

void wxIFMDefaultPanelPlugin::OnGetMinSize(wxIFMRectEvent &event)
{
    if( event.GetComponentType() == IFM_COMPONENT_PANEL )
    {
        wxIFMComponent *panel = event.GetComponent();

        wxASSERT_MSG(panel, wxT("NULL component?"));
        if( !panel )
            return;

        wxIFMPanelData *data = IFM_GET_EXTENSION_DATA(panel, wxIFMPanelData);

        wxASSERT_MSG(data, wxT("Tabbed panel with no tabbed panel data?"));
        if( !data )
            return;

        // find the largest min size of our tabs and use that
        wxSize final_min = panel->m_minSize;

        for( size_t i = 0; i < panel->m_children.GetCount(); i++ )
        //for( wxIFMComponentArray::iterator i = panel->m_children.begin(), end = panel->m_children.end(); i != end; ++i )
        {
            wxSize min = panel->m_children[i]->GetMinSize();
            if( min.x > final_min.x )
                final_min.x = min.x;
            if( min.y > final_min.y )
                final_min.y = min.y;
        }

        wxSize converted_min = panel->GetConvertedRect(wxRect(wxPoint(),final_min), IFM_COORDS_CLIENT, IFM_COORDS_ABSOLUTE).GetSize();
        if( final_min.x != IFM_NO_MINIMUM )
            final_min.x = converted_min.x;
        if( final_min.y != IFM_NO_MINIMUM )
            final_min.y = converted_min.y;

        event.SetSize(final_min);
    }
    else
        event.Skip();
}

void wxIFMDefaultPanelPlugin::OnGetMaxSize(wxIFMRectEvent &event)
{
    if( event.GetComponentType() == IFM_COMPONENT_PANEL )
    {
        wxIFMComponent *panel = event.GetComponent();

        wxASSERT_MSG(panel, wxT("NULL component?"));
        if( !panel )
            return;

        wxIFMPanelData *data = IFM_GET_EXTENSION_DATA(panel, wxIFMPanelData);

        wxASSERT_MSG(data, wxT("Tabbed panel with no tabbed panel data?"));
        if( !data )
            return;

        event.Skip();
    }
    else
        event.Skip();
}

/*
wxIFMComponentButtonManager implementation
*/
wxIFMComponentButtonManager::wxIFMComponentButtonManager(wxIFMInterfacePluginBase *ip, wxIFMComponent *component)
    : m_height(0),
    m_ip(ip),
    m_component(component),
    m_hidden(false)
{ }

wxIFMComponentButtonManager::~wxIFMComponentButtonManager()
{

}

wxIFMInterfacePluginBase *wxIFMComponentButtonManager::GetIP()
{
    return m_ip;
}

wxIFMComponent *wxIFMComponentButtonManager::GetComponent()
{
    return m_component;
}

const wxPoint &wxIFMComponentButtonManager::GetPosition() const
{
    return m_pos;
}

void wxIFMComponentButtonManager::Hide()
{
    Show(false);
}

wxIFMComponentButton *wxIFMComponentButtonManager::AddButton(int id)
{
    wxIFMComponentButton *btn = new wxIFMComponentButton(this, id, m_component->GetParentWindow());

    // size the button
    btn->SetSize(IFM_COMPONENT_BUTTON_X, IFM_COMPONENT_BUTTON_Y);

    // store the button
    m_buttons.push_back(btn);

    return btn;
}

void wxIFMComponentButtonManager::RemoveButton(int id)
{
    for( int i = 0, count = m_buttons.GetCount(); i < count; ++i )
    //for( wxIFMComponentButtonArray::iterator i = m_buttons.begin(), end = m_buttons.end(); i != end; ++i )
    {
        if( m_buttons[i]->GetID() == id )
        //if( (*i)->GetID() == id )
        {
            wxIFMComponentButton *btn = m_buttons[i];
            m_buttons.RemoveAt(i);
            //delete *i;
            //m_buttons.erase(i);
            delete btn;
            return;
        }
    }

    wxFAIL_MSG(wxT("Removing a button not managed by this button manager"));
}

wxIFMComponentButton *wxIFMComponentButtonManager::GetButton(int id)
{
    for( int i = 0, count = m_buttons.GetCount(); i < count; ++i )
    //for( wxIFMComponentButtonArray::const_iterator i = m_buttons.begin(), end = m_buttons.end(); i != end; ++i )
    {
        if( m_buttons[i]->GetID() == id )
        //if( (*i)->GetID() == id )
            return m_buttons[i];
            //return (*i);
    }

    return NULL;
}

const wxRect wxIFMComponentButtonManager::GetRect() const
{
    wxRect rect;
    rect.x = m_pos.x;
    rect.y = m_pos.y;
    rect.height = m_height;

    for( int i = 0, count = m_buttons.GetCount(); i < count; ++i )
    //for( wxIFMComponentButtonArray::const_iterator i = m_buttons.begin(), end = m_buttons.end(); i != end; ++i )
    {
        rect.width += m_buttons[i]->GetRect().width;
        //rect.width += (*i)->GetRect().width;
        rect.width += IFM_COMPONENT_BUTTON_PAD;
    }

    return rect;
}

void wxIFMComponentButtonManager::SetPosition(const wxPoint& pos)
{
    m_pos = pos;
}

void wxIFMComponentButtonManager::SetHeight(int height)
{
    m_height = height;
    for( int i = 0, count = m_buttons.GetCount(); i < count; ++i )
    //for( wxIFMComponentButtonArray::iterator i = m_buttons.begin(), end = m_buttons.end(); i != end; ++i )
        m_buttons[i]->SetSize(IFM_COMPONENT_BUTTON_X, IFM_COMPONENT_BUTTON_Y);
        //(*i)->SetSize(IFM_COMPONENT_BUTTON_X, IFM_COMPONENT_BUTTON_X);
}

void wxIFMComponentButtonManager::SetParent(wxWindow *parent)
{
    for( int i = 0, count = m_buttons.GetCount(); i < count; ++i )
    //for( wxIFMComponentButtonArray::iterator i = m_buttons.begin(), end = m_buttons.end(); i != end; ++i )
        m_buttons[i]->Reparent(parent);
        //(*i)->Reparent(parent);
}

void wxIFMComponentButtonManager::Layout()
{
    if( m_hidden )
        return;

    wxPoint pos = m_pos;
    pos.y += 2;

    for( int i = 0, count = m_buttons.GetCount(); i < count; ++i )
    //for( wxIFMComponentButtonArray::iterator i = m_buttons.begin(), end = m_buttons.end(); i != end; ++i )
    {
        m_buttons[i]->SetPosition(pos);
        //(*i)->SetPosition(pos);
        pos.x += (IFM_COMPONENT_BUTTON_X + IFM_COMPONENT_BUTTON_PAD);
    }
}

void wxIFMComponentButtonManager::Show(bool show)
{
    m_hidden = !show;

    for( int i = 0, count = m_buttons.GetCount(); i < count; ++i )
    //for( wxIFMComponentButtonArray::iterator i = m_buttons.begin(), end = m_buttons.end(); i != end; ++i )
        m_buttons[i]->Show(show);
        //(*i)->Show(show);
}

void wxIFMComponentButtonManager::Show(bool show, int id)
{
    wxIFMComponentButton *btn = GetButton(id);

    wxASSERT_MSG(btn, wxT("invalid button id"));
    if( btn )
        btn->Show(show);
}

BEGIN_EVENT_TABLE(wxIFMComponentButton, wxWindow)
    EVT_ERASE_BACKGROUND (wxIFMComponentButton::OnEraseBg)
    EVT_PAINT           (wxIFMComponentButton::OnPaint)
    EVT_ENTER_WINDOW    (wxIFMComponentButton::OnEnterWindow)
    EVT_LEAVE_WINDOW    (wxIFMComponentButton::OnLeaveWindow)
    EVT_LEFT_DOWN       (wxIFMComponentButton::OnLeftDown)
    EVT_LEFT_UP         (wxIFMComponentButton::OnLeftUp)
    EVT_MOTION          (wxIFMComponentButton::OnMouseMove)
END_EVENT_TABLE()

wxIFMComponentButton::wxIFMComponentButton(wxIFMComponentButtonManager *manager, int id, wxWindow *parent)
    : wxWindow(parent, wxID_ANY, wxPoint(0,0), wxSize(0,0), wxNO_BORDER),
    m_id(id),
    m_manager(manager),
    m_hover(false),
    m_pressed(false),
    m_leftDown(false),
    m_bmp(NULL),
    m_bmpH(NULL),
    m_bmpP(NULL)
{ }

wxIFMInterfacePluginBase *wxIFMComponentButton::GetIP()
{
    return m_manager->GetIP();
}

int wxIFMComponentButton::GetID() const
{
    return m_id;
}

bool wxIFMComponentButton::GetHover() const
{
    return m_hover;
}

bool wxIFMComponentButton::GetPressed() const
{
    return m_pressed;
}

void wxIFMComponentButton::SetHover(bool h)
{
    if( h != m_hover )
    {
        m_hover = h;
        Refresh();
    }
}

void wxIFMComponentButton::SetPressed(bool p)
{
    if( p != m_pressed )
    {
        m_pressed = p;
        Refresh();
    }
}

void wxIFMComponentButton::OnEnterWindow(wxMouseEvent &WXUNUSED(event))
{
    SetHover(true);
}

void wxIFMComponentButton::OnLeaveWindow(wxMouseEvent &WXUNUSED(event))
{
    SetHover(false);
}

void wxIFMComponentButton::OnPaint(wxPaintEvent &WXUNUSED(event))
{
    wxPaintDC dc(this);
    int w, h;

    GetClientSize(&w, &h);
    dc.SetBrush(GetBackgroundColour());
    dc.SetPen(GetBackgroundColour());
    dc.DrawRectangle(0, 0, w, h);

    if( m_hover )
    {
        if( m_pressed )
            dc.DrawBitmap(*m_bmpP, 0, 0, true);
        else
            dc.DrawBitmap(*m_bmpH, 0, 0, true);
    }
    else
        dc.DrawBitmap(*m_bmp, 0, 0, true);
}

void wxIFMComponentButton::OnEraseBg(wxEraseEvent &WXUNUSED(event))
{

}

void wxIFMComponentButton::OnLeftDown(wxMouseEvent &WXUNUSED(event))
{
    m_leftDown = true;
    CaptureMouse();

    SetPressed(true);
}

void wxIFMComponentButton::OnLeftUp(wxMouseEvent &event)
{
    if( m_leftDown )
    {
        m_leftDown = false;
        ReleaseMouse();

        SetPressed(false);

        wxRect rect = GetRect();
        rect.y = rect.x = 0;
        if( rect.Inside(event.GetPosition()) )
        {
            // send button press event
            wxIFMComponentButtonEvent evt(wxEVT_IFM_COMPONENTBUTTONCLICK, m_manager->GetComponent(), this);
            GetIP()->ProcessPluginEvent(evt);
        }
    }
}

void wxIFMComponentButton::OnMouseMove(wxMouseEvent &event)
{
    if( m_leftDown )
    {
        wxRect rect = GetRect();
        rect.y = rect.x = 0;
        SetPressed(rect.Inside(event.GetPosition()));
    }
}

/*
    wxIFMDefaultChildData implementation
*/
wxIFMDefaultChildData::wxIFMDefaultChildData()
    : wxIFMChildDataBase(),
    m_orientation(IFM_ORIENTATION_DEFAULT),
    m_index(IFM_DEFAULT_INDEX),
    m_newRow(false),
    m_tabify(false),
    m_bitmap(wxNullBitmap),
    m_pos(IFM_DEFAULT_POS)
{ }

// docked ctor
wxIFMDefaultChildData::wxIFMDefaultChildData(wxWindow *child, int type, const wxString &name,
        wxSize size, bool hidden, int orientation, int index, bool newRow, bool tabify, const wxBitmap &bmp)
    : wxIFMChildDataBase(child, type, name, size, hidden),
    m_orientation(orientation),
    m_index(index),
    m_newRow(newRow),
    m_tabify(tabify),
    m_bitmap(bmp),
    m_pos(IFM_DEFAULT_POS)
{ }

// floating ctor
wxIFMDefaultChildData::wxIFMDefaultChildData(wxWindow *child, int type, wxPoint pos, wxSize size,
        bool hidden, const wxString &name)
    : wxIFMChildDataBase(child, type, name, size, hidden),
    m_orientation(IFM_ORIENTATION_FLOAT),
    m_index(0),
    m_newRow(false),
    m_tabify(false),
    m_bitmap(wxNullBitmap),
    m_pos(pos)
{ }

wxIFMDefaultChildData::wxIFMDefaultChildData(const wxIFMDefaultChildData &data)
    : wxIFMChildDataBase(data),
    m_orientation(data.m_orientation),
    m_index(data.m_index),
    m_newRow(data.m_newRow),
    m_tabify(data.m_tabify),
    m_bitmap(data.m_bitmap),
    m_pos(data.m_pos)
{ }

wxIFMDefaultChildData::wxIFMDefaultChildData(const wxIFMChildDataBase &data)
    : wxIFMChildDataBase(data),
    m_orientation(IFM_ORIENTATION_DEFAULT),
    m_index(IFM_DEFAULT_INDEX),
    m_newRow(false),
    m_tabify(false),
    m_bitmap(wxNullBitmap),
    m_pos(IFM_DEFAULT_POS)
{ }

/*
    wxIFMContainerData implementation
*/
wxIFMContainerData::wxIFMContainerData()
    : wxIFMExtensionDataBase()/*,
    m_buttonManager(0,0)*/
{ }

wxIFMContainerData::wxIFMContainerData(wxIFMInterfacePluginBase *ip, wxIFMComponent *c)
    : wxIFMExtensionDataBase(),
    //m_buttonManager(ip, c),
    m_orientation(IFM_ORIENTATION_NONE)
{ }

wxIFMComponentDataKeyType wxIFMContainerData::GetDataKey() const
{
    return IFM_CONTAINER_DATA_KEY;
}

wxIFMComponentDataKeyType wxIFMContainerData::DataKey()
{
    return IFM_CONTAINER_DATA_KEY;
}

/*
    wxIFMPanelTabData implementation
*/
wxIFMPanelTabData::wxIFMPanelTabData()
    : wxIFMExtensionDataBase(),
    m_bitmap(wxNullBitmap)
{ }

wxIFMComponentDataKeyType wxIFMPanelTabData::GetDataKey() const
{
    return IFM_PANEL_DATA_KEY;
}


wxIFMComponentDataKeyType wxIFMPanelTabData::DataKey()
{
    return IFM_PANEL_DATA_KEY;
}

/*
    wxIFMPanelData implementation
*/
wxIFMPanelData::wxIFMPanelData(wxIFMInterfacePluginBase *ip, wxIFMComponent *c)
    : m_button_manager(ip, c),
    m_active_tab_index(-1),
    m_active_tab(NULL),
    m_dont_hide_tab(false)
{ }

wxIFMPanelData::~wxIFMPanelData()
{
    // clean up tabs
    for( size_t i = 0; i < m_tabs.GetCount(); i++ )
    //for( wxIFMTabArray::iterator i = m_tabs.begin(), end = m_tabs.end(); i != end; ++i )
        delete m_tabs[i];
}

wxIFMComponentDataKeyType wxIFMPanelData::GetDataKey() const
{
    return IFM_TABBED_PANEL_DATA_KEY;
}

wxIFMComponentDataKeyType wxIFMPanelData::DataKey()
{
    return IFM_TABBED_PANEL_DATA_KEY;
}
