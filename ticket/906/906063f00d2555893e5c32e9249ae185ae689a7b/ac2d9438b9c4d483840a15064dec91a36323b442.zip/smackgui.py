import sys, os
cfg = os.path.split(sys.argv[0])[0]+"/stc-styles.rc.cfg"
del sys
del os

from wxPython.wx import *
from wxPython.stc import *
import time
import threading
from STCStyleEditor import initSTC
import compiler
import exceptions
import traceback


I1 = wxNewId()
I2 = wxNewId()
I4 = wxNewId()

def idle(win):
    print "starting idle thread"
    time.sleep(5)
    print "ending idle thread"

def gfree(win):
    print "starting busy thread"
    c = 0
    start = time.time()
    while time.time()-start<5:
        c += 1
        print c,
        wxPostEvent(win, wxIdleEvent())
    print "ending busy thread", c

class MainWindow(wxFrame):
    def __init__(self,parent,id,title):
        wxFrame.__init__(self,parent,-4, title, size = ( 200,100),
                                     style=wxDEFAULT_FRAME_STYLE|wxNO_FULL_REPAINT_ON_RESIZE)
        self.CreateStatusBar()
        self.Show(true)
 
        self.stc = wxStyledTextCtrl(self, -1, style = wxNO_FULL_REPAINT_ON_RESIZE)
        
        menubar = wxMenuBar()
        menu = wxMenu()
        menu.Append(I4, "Update gui (no crash)", "constantly update the GUI for 5 seconds, no extra threads")
        menu.Append(I1, "Idle thread (no crash)", "start an idling thread that lasts for 5 seconds, but does nothing else")
        menu.Append(I2, "Event Poster (crash)", "start a thread that uses (minimal) processor and posts idle events, lasts 5 seconds")
        EVT_MENU(self, I1, self.IdleThread)
        EVT_MENU(self, I2, self.GarbageFree)
        EVT_MENU(self, I4, self.JustGUI)


        menubar.Append(menu, "Tests")
        self.SetMenuBar(menubar)

    def JustGUI(self, e):
        start = time.time()
        cnt = 0
        i = "def main(): print 'hello world'\n"
        li = len(i)
        self.stc.SetText(i)
        while time.time()-start < 5:
            cnt += 1
            self.stc.SetText(self.stc.GetText()*2)
            self.stc.SetText(i)
            self.SetStatusText("%i seconds remaining...%i"%(int(5-(time.time()-start)), cnt))

            try:
                initSTC(self.stc, cfg, 'python')
            except exceptions.Exception, e:
                traceback.print_last()

        self.SetStatusText("Done.")

    def IdleThread(self, e):
        self.SetStatusText("starting idle thread")
        threading.Thread(None, idle, None, (self,)).start()
        self.JustGUI(e)
        self.SetStatusText("idle loop should be ending")
    
    def GarbageFree(self, e):
        self.SetStatusText("starting busy thread")
        threading.Thread(None, gfree, None, (self,)).start()
        self.JustGUI(e)
        self.SetStatusText("busy loop should be ending")
    

app = wxPySimpleApp()
frame = MainWindow(None, -1, "Kill the garbage collector")
app.MainLoop()