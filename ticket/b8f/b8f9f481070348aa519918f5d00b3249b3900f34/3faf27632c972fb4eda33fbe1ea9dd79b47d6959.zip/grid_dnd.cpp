///////////////////////////////////////////////////////////////////////////
// C++ code generated with wxFormBuilder (version Sep  8 2010)
// http://www.wxformbuilder.org/
//
// PLEASE DO "NOT" EDIT THIS FILE!
///////////////////////////////////////////////////////////////////////////

#include "grid_dnd.h"
#include <wx/dnd.h>

///////////////////////////////////////////////////////////////////////////

MyPanel::MyPanel(wxWindow* parent):
    wxPanel( parent, wxID_ANY, wxDefaultPosition, wxDefaultSize, wxRAISED_BORDER|wxTAB_TRAVERSAL )
{
  m_BlockDrop = new BlockDrop();
  SetDropTarget(m_BlockDrop);

}

MyFrame::MyFrame( wxWindow* parent, wxWindowID id, const wxString& title, const wxPoint& pos, const wxSize& size, long style ) :
    wxFrame( parent, id, title, pos, size, style )
{
	this->SetSizeHints( wxDefaultSize, wxDefaultSize );
	
	wxBoxSizer* bSizer1;
	bSizer1 = new wxBoxSizer( wxHORIZONTAL );
	
	m_Panel = new MyPanel(this);
	m_Panel->SetMinSize( wxSize( 100,-1 ) );
	
	bSizer1->Add( m_Panel, 0, wxALL|wxEXPAND, 5 );
	
	m_Grid = new wxGrid( this, wxID_ANY, wxDefaultPosition, wxDefaultSize, 0 );
	
	// Grid
	m_Grid->CreateGrid( 3, 3 );
	m_Grid->EnableEditing( true );
	m_Grid->EnableGridLines( true );
	m_Grid->EnableDragGridSize( false );
	m_Grid->SetMargins( 0, 0 );
	
	// Columns
	m_Grid->EnableDragColMove( false );
	m_Grid->EnableDragColSize( true );
	m_Grid->SetColLabelSize( 30 );
	m_Grid->SetColLabelAlignment( wxALIGN_CENTRE, wxALIGN_CENTRE );
	
	// Rows
	m_Grid->EnableDragRowSize( true );
	m_Grid->SetRowLabelSize( 80 );
	m_Grid->SetRowLabelAlignment( wxALIGN_CENTRE, wxALIGN_CENTRE );
	
	// Label Appearance
	
	// Cell Defaults
	m_Grid->SetDefaultCellAlignment( wxALIGN_LEFT, wxALIGN_TOP );
	bSizer1->Add( m_Grid, 0, wxALL, 5 );
	
	this->SetSizer( bSizer1 );
	this->Layout();
	
	this->Centre( wxBOTH );
	
	// Connect Events
	m_Grid->Connect( wxEVT_GRID_CELL_LEFT_CLICK, wxGridEventHandler( MyFrame::onGridCellLeftClick ), NULL, this );
}

MyFrame::~MyFrame()
{
	// Disconnect Events
	m_Grid->Disconnect( wxEVT_GRID_CELL_LEFT_CLICK, wxGridEventHandler( MyFrame::onGridCellLeftClick ), NULL, this );

	
}

void MyFrame::onGridCellLeftClick( wxGridEvent& event ) {
  wxTextDataObject my_data(wxString::Format(wxT("moveto:row%d:col%d:"), event.GetRow(), event.GetCol()));
  wxDropSource dragSource( this );
  dragSource.SetData( my_data );
  wxDragResult result = dragSource.DoDragDrop(wxDrag_CopyOnly);
  event.Skip(true);
}


bool BlockDrop::OnDropText(wxCoord x, wxCoord y, const wxString& data) {
  printf( "D&D data [%s][%ld]\n", (const char*)data.mb_str(wxConvUTF8), data.Len() );
  return true;
}


