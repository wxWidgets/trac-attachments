#include "scrollwin.h"

ScrollWin::ScrollWin(wxWindow* parent, wxPoint pos,wxSize size)
	:wxScrolledWindow(parent,-1,pos,size,wxSUNKEN_BORDER |
		wxWANTS_CHARS)
{
	SetBackgroundColour(wxColour(255,255,255));

	win1=new wxWindow(this,-1,wxDefaultPosition,wxSize(1,20));
	win1->SetBackgroundColour(wxColour(255,0,0));
	win2=new wxWindow(this,-1,wxDefaultPosition,wxSize(1,20));
	win2->SetBackgroundColour(wxColour(0,255,0));

	mainSizer=new wxBoxSizer(wxVERTICAL);
	mainSizer->Add(win1,false,wxEXPAND | wxBOTTOM,10);
	mainSizer->Add(win2,false,wxEXPAND);
	mainSizer->Add(0,true,wxEXPAND);

	SetSizer(mainSizer);
	SetAutoLayout(true);
	Layout();

	SetScrollbars(0, 5, 0, 0);
}