#ifndef SCROLL_FRAME_H
#define SCROLL_FRAME_H

#include "scrollwin.h"

class ScrollFrame: public wxFrame
{
	protected:
	ScrollWin* scrollWin;
	wxBoxSizer* mainSizer;

	public:
	ScrollFrame(wxWindow* parent, const wxPoint &pos=wxDefaultPosition);
};

#endif
