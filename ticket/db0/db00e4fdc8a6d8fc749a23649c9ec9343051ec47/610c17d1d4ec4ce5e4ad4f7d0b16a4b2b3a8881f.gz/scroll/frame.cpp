#include <wx/image.h>
#include <wx/wfstream.h>
#include "frame.h"

ScrollFrame::ScrollFrame(wxWindow* parent, const wxPoint &pos)
	:wxFrame(parent,-1,"Scrolling test",pos,wxSize(130,300),
		wxDEFAULT_FRAME_STYLE | wxWANTS_CHARS)
{
	scrollWin=new ScrollWin(this);
	mainSizer=new wxBoxSizer(wxVERTICAL);
	mainSizer->Add(scrollWin,true,wxALL | wxEXPAND,5);

	SetSizer(mainSizer);
	SetAutoLayout(true);
	Layout();
}
