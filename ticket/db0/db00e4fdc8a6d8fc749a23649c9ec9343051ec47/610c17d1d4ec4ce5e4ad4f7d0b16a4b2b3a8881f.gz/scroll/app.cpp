#include <wx/image.h>

#include "app.h"
#include "frame.h"

IMPLEMENT_APP(ScrollApp)

bool ScrollApp::OnInit()
{
	SetAppName("Scrolling test");
	ScrollFrame* frame=new ScrollFrame(NULL);
	frame->Show(true);
	SetTopWindow(frame);
	return true;
}