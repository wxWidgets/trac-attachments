#ifndef SCROLL_APP_H
#define SCROLL_APP_H

#include <wx/wx.h>

class ScrollApp: public wxApp
{
	public:
	virtual bool OnInit();
};

DECLARE_APP(ScrollApp)

#endif SCROLL_APP_H
