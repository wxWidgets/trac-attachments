#ifndef SCROLL_WIN_H
#define SCROLL_WIN_H

#include <wx/wx.h>

class ScrollWin: public wxScrolledWindow
{
	private:
	wxBoxSizer* mainSizer;
	wxWindow* win1, *win2;

	public:
	ScrollWin(wxWindow* parent,
		wxPoint position=wxDefaultPosition,
		wxSize size=wxDefaultSize);
};

#endif
