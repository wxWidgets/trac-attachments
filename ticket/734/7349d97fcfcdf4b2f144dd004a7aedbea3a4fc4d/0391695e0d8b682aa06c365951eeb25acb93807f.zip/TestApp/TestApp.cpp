#include "wx/wxprec.h"
#ifdef __BORLANDC__
	#pragma hdrstop
#endif
#ifndef WX_PRECOMP
	#include "wx/wx.h"
#endif

#include <wx/textfile.h>


class DefaultApp : public wxApp
{

public:
	DefaultApp();
	virtual bool OnInit();

	DECLARE_NO_COPY_CLASS(DefaultApp)
		
};

IMPLEMENT_APP(DefaultApp)

DefaultApp::DefaultApp()
{
}

bool DefaultApp::OnInit()
{

	wxString filename = wxT("Winamp.m3u");
	
	wxTextFile file;
	
	if (file.Open(filename, wxConvLocal) && !file.Eof())
	{

		for (wxString line = file.GetFirstLine(); !file.Eof(); line = file.GetNextLine())
		{

			if (line.Length() && line.Last() == 0)
			{

				wxMessageBox(wxT("The following line has a NUL char at the end:\n\n") + line);
			
			}

		}

	}

	wxMessageBox(wxT("End of file."));

	return false;

}
