#include <windows.h>
#include <process.h>

/*  Window procedure  */

#define  MSG_WAITING_FOR_TIMER  "waiting for timer"
#define  MSG_TIMER_HAS_ARRIVED  "timer has arrived"
HWND  hwnd;
int   timer_has_arrived = 0;

LRESULT CALLBACK WndProc(HWND hwnd, UINT iMsg, WPARAM wParam, LPARAM lParam)
{
    PAINTSTRUCT ps;
    HDC         hdc;
    switch ( iMsg ) {
    case WM_PAINT:
	hdc = BeginPaint(hwnd, &ps);
        if (timer_has_arrived)
          TextOut(hdc, 100, 100, MSG_TIMER_HAS_ARRIVED, strlen(MSG_TIMER_HAS_ARRIVED));
        else
          TextOut(hdc, 100, 100, MSG_WAITING_FOR_TIMER, strlen(MSG_WAITING_FOR_TIMER));
	EndPaint(hwnd, &ps);
	return 0;
    case WM_TIMER:
        timer_has_arrived = 1;              // timer has arrived !
        InvalidateRect(hwnd, NULL, TRUE);
        break;

    case WM_DESTROY:
	PostQuitMessage(0);
	return 0;
    }
    return DefWindowProc(hwnd, iMsg, wParam, lParam);
}


/* the thread function */ 

void threadfunc( void *dummy )
{
  UINT retval = SetTimer(hwnd,123,1000 * 5,NULL);   // wait 5 seconds
}


/*  WinMain entry point  */

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance,
		   LPSTR szCmdLine, int iCmdShow)
{
    static char szAppName[] = "wintimer";
    MSG         msg;
    WNDCLASSEX  wndclass;
    wndclass.cbSize         = sizeof(wndclass);
    wndclass.style          = CS_HREDRAW | CS_VREDRAW;
    wndclass.lpfnWndProc    = WndProc;
    wndclass.cbClsExtra     = 0;
    wndclass.cbWndExtra     = 0;
    wndclass.hInstance      = hInstance;
    wndclass.hIcon          = LoadIcon(NULL, IDI_APPLICATION);
    wndclass.hIconSm        = LoadIcon(NULL, IDI_APPLICATION);
    wndclass.hCursor        = LoadCursor(NULL, IDC_ARROW);
    wndclass.hbrBackground  = (HBRUSH) GetStockObject(WHITE_BRUSH);
    wndclass.lpszClassName  = szAppName;
    wndclass.lpszMenuName   = NULL;
    RegisterClassEx(&wndclass);
    hwnd = CreateWindow(szAppName, "Timer demo",
			WS_OVERLAPPEDWINDOW,
			CW_USEDEFAULT, CW_USEDEFAULT,
			CW_USEDEFAULT, CW_USEDEFAULT,
			NULL, NULL, hInstance, NULL);
    ShowWindow(hwnd, iCmdShow);
    UpdateWindow(hwnd);
    _beginthread(threadfunc,0,0);
    while ( GetMessage(&msg, NULL, 0, 0) ) {
	TranslateMessage(&msg);    /*  for certain keyboard messages  */
	DispatchMessage(&msg);     /*  send message to WndProc        */
    } 
    return msg.wParam;
}
