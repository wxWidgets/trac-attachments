///-----------------------------------------------------------------
///
/// @file      serverDlg.cpp
/// @author    Administrator
/// Created:   13-12-2010 23:08:41
/// @section   DESCRIPTION
///            serverDlg class implementation
///
///------------------------------------------------------------------

#include "serverDlg.h"

//Do not add custom headers
//wxDev-C++ designer will remove them
////Header Include Start
////Header Include End

//----------------------------------------------------------------------------
// serverDlg
//----------------------------------------------------------------------------
//Add Custom Events only in the appropriate block.
//Code added in other places will be removed by wxDev-C++
////Event Table Start
BEGIN_EVENT_TABLE(serverDlg,wxDialog)
	////Manual Code Start
	EVT_SOCKET(SERVER_ID,  serverDlg::OnServerEvent)
	////Manual Code End
	
	EVT_CLOSE(serverDlg::OnClose)
	EVT_BUTTON(ID_WXBUTTON1,serverDlg::WxButton1Click)
END_EVENT_TABLE()
////Event Table End

serverDlg::serverDlg(wxWindow *parent, wxWindowID id, const wxString &title, const wxPoint &position, const wxSize& size, long style)
: wxDialog(parent, id, title, position, size, style)
{
	CreateGUIControls();
	address.Service(443);
    server = new wxSocketServer(address);
    server->SetEventHandler(*this, SERVER_ID);
    server->SetNotify(wxSOCKET_CONNECTION_FLAG);
    server->Notify(true);
    events=0;
}

serverDlg::~serverDlg()
{
} 

void serverDlg::CreateGUIControls()
{
	//Do not add custom code between
	//GUI Items Creation Start and GUI Items Creation End.
	//wxDev-C++ designer will remove them.
	//Add the custom code before or after the blocks
	////GUI Items Creation Start

	WxPanel1 = new wxPanel(this, ID_WXPANEL1, wxPoint(18, 4), wxSize(392, 232));

	WxEdit1 = new wxTextCtrl(WxPanel1, ID_WXEDIT1, wxT(""), wxPoint(189, 87), wxSize(114, 22), 0, wxDefaultValidator, wxT("WxEdit1"));

	WxStaticText1 = new wxStaticText(WxPanel1, ID_WXSTATICTEXT1, wxT("events generated:"), wxPoint(87, 89), wxDefaultSize, 0, wxT("WxStaticText1"));

	WxButton1 = new wxButton(WxPanel1, ID_WXBUTTON1, wxT("reset"), wxPoint(147, 132), wxSize(109, 22), 0, wxDefaultValidator, wxT("WxButton1"));

	SetTitle(wxT("server"));
	SetIcon(wxNullIcon);
	SetSize(260,202,445,264);
	Center();
	
	////GUI Items Creation End
}

void serverDlg::OnClose(wxCloseEvent& /*event*/)
{
	Destroy();
}

void serverDlg::OnServerEvent(wxSocketEvent& event)
{
events++;
WxEdit1->SetValue(wxString::Format("%d",events));
wxSocketBase *socket;
socket=server->Accept(false);
}

/*
 * WxButton1Click
 */
void serverDlg::WxButton1Click(wxCommandEvent& event)
{
events=0;
WxEdit1->SetValue("0");
}
