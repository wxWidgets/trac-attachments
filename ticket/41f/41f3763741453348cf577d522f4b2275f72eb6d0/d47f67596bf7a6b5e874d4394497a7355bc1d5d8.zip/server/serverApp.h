//---------------------------------------------------------------------------
//
// Name:        serverApp.h
// Author:      Administrator
// Created:     13-12-2010 23:08:41
// Description: 
//
//---------------------------------------------------------------------------

#ifndef __SERVERDLGApp_h__
#define __SERVERDLGApp_h__

#ifdef __BORLANDC__
	#pragma hdrstop
#endif

#ifndef WX_PRECOMP
	#include <wx/wx.h>
#else
	#include <wx/wxprec.h>
#endif

class serverDlgApp : public wxApp
{
	public:
		bool OnInit();
		int OnExit();
};

#endif
