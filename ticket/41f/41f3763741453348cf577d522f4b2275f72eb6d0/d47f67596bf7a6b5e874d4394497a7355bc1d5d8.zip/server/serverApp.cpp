//---------------------------------------------------------------------------
//
// Name:        serverApp.cpp
// Author:      Administrator
// Created:     13-12-2010 23:08:41
// Description: 
//
//---------------------------------------------------------------------------

#include "serverApp.h"
#include "serverDlg.h"

IMPLEMENT_APP(serverDlgApp)

bool serverDlgApp::OnInit()
{
	serverDlg* dialog = new serverDlg(NULL);
	SetTopWindow(dialog);
	dialog->Show(true);		
	return true;
}
 
int serverDlgApp::OnExit()
{
	return 0;
}
