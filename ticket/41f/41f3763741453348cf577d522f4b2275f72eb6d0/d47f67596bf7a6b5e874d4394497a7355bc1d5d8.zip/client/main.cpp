#include <winsock2.h>
#include <stdio.h>
int main()
{
SOCKADDR_IN SockAddr;
SOCKET Socket;
WSADATA wsaData;
WSAStartup(MAKEWORD(2,0),&wsaData);
memset(&SockAddr,0,sizeof(SockAddr));
SockAddr.sin_family=AF_INET;
SockAddr.sin_port=htons(443);
SockAddr.sin_addr.s_addr=inet_addr("127.0.0.1");
int c=0;
for(int i=0;i<200;i++) //this makes 200 connections to the wxSocketServer
{
c++;
Socket=socket(AF_INET,SOCK_STREAM,IPPROTO_TCP);
connect(Socket,(SOCKADDR*)&SockAddr,sizeof(SOCKADDR_IN));
}
printf("%d connections",c);
return 0;
}
