//---------------------------------------------------------------------------
// Created:     4.12.2006 23:20:46
// Adapted: 	19.1.2008 20:45:00 for Eclipse
//---------------------------------------------------------------------------

#include "MyApp.h"
#include "Forms/cMainFrame.h"
#include "Logging/cLogTextCtrl.h"
#include "Server/cServerManagement.h"
#include "Client/cClientSocket.h"

#include <wx/msgdlg.h>
#include <wx/settings.h>
#include <wx/apptrait.h>	// For config filenames
#include <wx/stdpaths.h>	// For config filenames
#include <wx/fileconf.h>
#include <wx/app.h>			// for wxTheApp
#include <wx/intl.h>

IMPLEMENT_APP(MyApp)

// Here are instantiated logging controls
cLogTextCtrl *clientLog;
cLogTextCtrl *serverLog;

bool MyApp::OnInit()
{
	cMainFrame *frame = new cMainFrame(NULL);
	
	// Continue with standard GUI initializaction
   SetTopWindow(frame);
   frame->Show();
   
   clientLog = new cLogTextCtrl(frame->clientLogText); 
   serverLog = new cLogTextCtrl(frame->serverLogText);
   
   clientSocket = new cClientSocket;
   
   return true;
}

/*
int SNMP_UDP_receiverApp::OnRun()
{
	*logTextCtrl << ((wxTopLevelWindow *)wxTheApp->GetTopWindow())->GetTitle() << _(" <- OnRun() title\n");

	//   socket6355->Transmit((unsigned char *)"pmcs_KILL", sizeof("pmcs_KILL"), wxT("localhost"), 162);
	
	return wxApp::OnRun();
}
*/

int MyApp::OnExit()
{
	delete clientLog;
	delete serverLog;
	clientLog = NULL;
	serverLog = NULL;
	
	delete clientSocket;
//	delete serverManagement;

	return 0;
}
