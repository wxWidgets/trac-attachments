///////////////////////////////////////////////////////////////////////////
// C++ code generated with wxFormBuilder (version Apr 16 2008)
// http://www.wxformbuilder.org/
//
// PLEASE DO "NOT" EDIT THIS FILE!
///////////////////////////////////////////////////////////////////////////

#include <wx/statbox.h>
#include <wx/settings.h>

#include "wxFormBuilder_source.h"

///////////////////////////////////////////////////////////////////////////

BEGIN_EVENT_TABLE( fbMainFrame, wxFrame )
	EVT_BUTTON( SERVER_SEND_BUTTON, fbMainFrame::_wxFB_ServerSendButton )
	EVT_CHECKBOX( wxID_ANY, fbMainFrame::_wxFB_UseServerCheckbox )
	EVT_BUTTON( CLIENT_CONNECT_BUTTON, fbMainFrame::_wxFB_ClientConnectButton )
	EVT_BUTTON( CLIENT_SEND_BUTTON, fbMainFrame::_wxFB_ClientSendButton )
	EVT_BUTTON( CLIENT_DISCONNECT_BUTTON, fbMainFrame::_wxFB_ClientDisconnectButton )
END_EVENT_TABLE()

fbMainFrame::fbMainFrame( wxWindow* parent, wxWindowID id, const wxString& title, const wxPoint& pos, const wxSize& size, long style ) : wxFrame( parent, id, title, pos, size, style )
{
	this->SetSizeHints( wxSize( 640,480 ), wxDefaultSize );
	
	mainSizer = new wxBoxSizer( wxHORIZONTAL );
	
	wxBoxSizer* bSizer33;
	bSizer33 = new wxBoxSizer( wxVERTICAL );
	
	m_staticText22 = new wxStaticText( this, wxID_ANY, _("Server"), wxDefaultPosition, wxDefaultSize, 0 );
	m_staticText22->Wrap( -1 );
	m_staticText22->SetFont( wxFont( wxNORMAL_FONT->GetPointSize(), 70, 90, 92, false, wxEmptyString ) );
	
	bSizer33->Add( m_staticText22, 0, wxALL|wxALIGN_CENTER_HORIZONTAL, 5 );
	
	wxBoxSizer* bSizer351;
	bSizer351 = new wxBoxSizer( wxHORIZONTAL );
	
	serverMessageText = new wxTextCtrl( this, wxID_ANY, _("Server message včetně nádherné češtiny"), wxDefaultPosition, wxDefaultSize, 0 );
	bSizer351->Add( serverMessageText, 1, wxALL, 5 );
	
	bSizer33->Add( bSizer351, 0, wxEXPAND, 5 );
	
	serverSendButton = new wxButton( this, SERVER_SEND_BUTTON, _("Send"), wxDefaultPosition, wxDefaultSize, 0 );
	bSizer33->Add( serverSendButton, 0, wxALL|wxALIGN_CENTER_HORIZONTAL, 5 );
	
	serverLogText = new wxTextCtrl( this, wxID_ANY, wxEmptyString, wxDefaultPosition, wxDefaultSize, wxTE_MULTILINE|wxTE_READONLY );
	bSizer33->Add( serverLogText, 1, wxALL|wxEXPAND, 5 );
	
	mainSizer->Add( bSizer33, 1, wxEXPAND, 5 );
	
	m_staticline4 = new wxStaticLine( this, wxID_ANY, wxDefaultPosition, wxDefaultSize, wxLI_VERTICAL );
	mainSizer->Add( m_staticline4, 0, wxEXPAND | wxALL, 5 );
	
	wxBoxSizer* bSizer331;
	bSizer331 = new wxBoxSizer( wxVERTICAL );
	
	wxGridSizer* gSizer1;
	gSizer1 = new wxGridSizer( 1, 3, 0, 0 );
	
	m_checkBox2 = new wxCheckBox( this, wxID_ANY, _("Use own server"), wxDefaultPosition, wxDefaultSize, 0 );
	
	gSizer1->Add( m_checkBox2, 0, wxALL, 5 );
	
	m_staticText221 = new wxStaticText( this, wxID_ANY, _("Client"), wxDefaultPosition, wxDefaultSize, 0 );
	m_staticText221->Wrap( -1 );
	m_staticText221->SetFont( wxFont( wxNORMAL_FONT->GetPointSize(), 70, 90, 92, false, wxEmptyString ) );
	
	gSizer1->Add( m_staticText221, 0, wxALL|wxALIGN_CENTER_HORIZONTAL, 5 );
	
	bSizer331->Add( gSizer1, 0, wxEXPAND, 5 );
	
	wxBoxSizer* bSizer3511;
	bSizer3511 = new wxBoxSizer( wxHORIZONTAL );
	
	clientMessageText = new wxTextCtrl( this, wxID_ANY, _("Client message včetně nádherné češtiny"), wxDefaultPosition, wxDefaultSize, 0 );
	bSizer3511->Add( clientMessageText, 1, wxALL, 5 );
	
	bSizer331->Add( bSizer3511, 0, wxEXPAND, 5 );
	
	wxBoxSizer* bSizer41;
	bSizer41 = new wxBoxSizer( wxHORIZONTAL );
	
	clientConnectButton = new wxButton( this, CLIENT_CONNECT_BUTTON, _("Connect"), wxDefaultPosition, wxDefaultSize, 0 );
	bSizer41->Add( clientConnectButton, 0, wxALL, 5 );
	
	
	bSizer41->Add( 20, 0, 1, wxEXPAND, 5 );
	
	clientSendButton = new wxButton( this, CLIENT_SEND_BUTTON, _("Send"), wxDefaultPosition, wxDefaultSize, 0 );
	bSizer41->Add( clientSendButton, 0, wxALL, 5 );
	
	
	bSizer41->Add( 0, 0, 1, wxEXPAND, 5 );
	
	clientDisconnectButton = new wxButton( this, CLIENT_DISCONNECT_BUTTON, _("Disconnect"), wxDefaultPosition, wxDefaultSize, 0 );
	bSizer41->Add( clientDisconnectButton, 0, wxALL, 5 );
	
	bSizer331->Add( bSizer41, 0, wxALIGN_CENTER_HORIZONTAL, 5 );
	
	clientLogText = new wxTextCtrl( this, wxID_ANY, wxEmptyString, wxDefaultPosition, wxDefaultSize, wxTE_MULTILINE|wxTE_READONLY );
	bSizer331->Add( clientLogText, 1, wxALL|wxEXPAND, 5 );
	
	mainSizer->Add( bSizer331, 1, wxEXPAND, 5 );
	
	this->SetSizer( mainSizer );
	this->Layout();
}

fbMainFrame::~fbMainFrame()
{
}
