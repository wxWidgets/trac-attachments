#ifndef CMAINFRAME_H_
#define CMAINFRAME_H_

#include "wxFormBuilder_source.h"

class cMainFrame : public fbMainFrame
{
public:
	cMainFrame(wxWindow* parent);
	virtual ~cMainFrame();

protected:
	// Virtual event handler, overriden in this derived class
	virtual void ClientConnectButton( wxCommandEvent& event );
	virtual void ClientSendButton( wxCommandEvent& event );
	virtual void ClientDisconnectButton( wxCommandEvent& event );
	virtual void UseServerCheckbox( wxCommandEvent& event );
	virtual void ServerSendButton( wxCommandEvent& event );

};

#endif /*CMAINFRAME_H_*/
