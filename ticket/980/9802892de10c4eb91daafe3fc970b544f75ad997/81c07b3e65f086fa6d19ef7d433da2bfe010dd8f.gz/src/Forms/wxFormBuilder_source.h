///////////////////////////////////////////////////////////////////////////
// C++ code generated with wxFormBuilder (version Apr 16 2008)
// http://www.wxformbuilder.org/
//
// PLEASE DO "NOT" EDIT THIS FILE!
///////////////////////////////////////////////////////////////////////////

#ifndef __wxFormBuilder_source__
#define __wxFormBuilder_source__

#include <wx/intl.h>

#include <wx/string.h>
#include <wx/stattext.h>
#include <wx/gdicmn.h>
#include <wx/font.h>
#include <wx/colour.h>
#include <wx/settings.h>
#include <wx/textctrl.h>
#include <wx/sizer.h>
#include <wx/button.h>
#include <wx/statline.h>
#include <wx/checkbox.h>
#include <wx/frame.h>

///////////////////////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////////////////////
/// Class fbMainFrame
///////////////////////////////////////////////////////////////////////////////
class fbMainFrame : public wxFrame 
{
	DECLARE_EVENT_TABLE()
	private:
		
		// Private event handlers
		void _wxFB_ServerSendButton( wxCommandEvent& event ){ ServerSendButton( event ); }
		void _wxFB_UseServerCheckbox( wxCommandEvent& event ){ UseServerCheckbox( event ); }
		void _wxFB_ClientConnectButton( wxCommandEvent& event ){ ClientConnectButton( event ); }
		void _wxFB_ClientSendButton( wxCommandEvent& event ){ ClientSendButton( event ); }
		void _wxFB_ClientDisconnectButton( wxCommandEvent& event ){ ClientDisconnectButton( event ); }
		
	
	protected:
		enum
		{
			SERVER_SEND_BUTTON = 1000,
			CLIENT_CONNECT_BUTTON,
			CLIENT_SEND_BUTTON,
			CLIENT_DISCONNECT_BUTTON,
		};
		
		wxBoxSizer* mainSizer;
		wxStaticText* m_staticText22;
		wxTextCtrl* serverMessageText;
		wxButton* serverSendButton;
		wxStaticLine* m_staticline4;
		wxCheckBox* m_checkBox2;
		wxStaticText* m_staticText221;
		wxTextCtrl* clientMessageText;
		wxButton* clientConnectButton;
		
		wxButton* clientSendButton;
		
		wxButton* clientDisconnectButton;
		
		// Virtual event handlers, overide them in your derived class
		virtual void ServerSendButton( wxCommandEvent& event ){ event.Skip(); }
		virtual void UseServerCheckbox( wxCommandEvent& event ){ event.Skip(); }
		virtual void ClientConnectButton( wxCommandEvent& event ){ event.Skip(); }
		virtual void ClientSendButton( wxCommandEvent& event ){ event.Skip(); }
		virtual void ClientDisconnectButton( wxCommandEvent& event ){ event.Skip(); }
		
	
	public:
		wxTextCtrl* serverLogText;
		wxTextCtrl* clientLogText;
		fbMainFrame( wxWindow* parent, wxWindowID id = wxID_ANY, const wxString& title = _("Socket tester"), const wxPoint& pos = wxDefaultPosition, const wxSize& size = wxSize( 691,480 ), long style = wxDEFAULT_FRAME_STYLE|wxTAB_TRAVERSAL );
		~fbMainFrame();
	
};

#endif //__wxFormBuilder_source__
