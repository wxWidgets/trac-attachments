#include "cMainFrame.h"
#include "../Logging/cLogTextCtrl.h"
#include "../Client/cClientSocket.h"
#include "../Server/cServerManagement.h"

#include <wx/settings.h>	// for GetMetric()
#include <wx/window.h>		// for Set/GetSize()

void cMainFrame::UseServerCheckbox( wxCommandEvent& event )
{
	mainSizer->Show((size_t)0, event.IsChecked());
	mainSizer->Show((size_t)1, event.IsChecked());
	Layout();

	if(event.IsChecked()) {
		serverManagement = new cServerManagement;
		serverManagement->Listen(true);
	}
	else
		delete serverManagement;
		
}

void cMainFrame::ServerSendButton( wxCommandEvent& event ) 
{
//	serverSockets.GetSocket()->Send(wxString(_("Také ze serveru včetně nádherné češtiny.")));
	serverManagement->Send(serverMessageText->GetValue());
}

void cMainFrame::ClientConnectButton( wxCommandEvent& event ) 
{ 
	clientSocket->Connect();
}

void cMainFrame::ClientSendButton( wxCommandEvent& event ) 
{
//	clientSocket->Send(wxString(_("Test message včetně nádherné češtiny.")));
	clientSocket->Send(clientMessageText->GetValue());
}


void cMainFrame::ClientDisconnectButton( wxCommandEvent& event ) 
{ 
	clientSocket->Disconnect();
}


cMainFrame::cMainFrame(wxWindow* parent)
: fbMainFrame(parent)
{
	// Adjust window size on larger displays:
	wxSize size;
	int new_x, res_x,
	new_y, res_y;
	
	// Get X screen resolution and recompute proper window width
	new_x = (res_x = wxSystemSettings::GetMetric(wxSYS_SCREEN_X, this)) - 200;
	if(new_x<res_x)
		new_x = res_x;
	if(new_x > 1024)
		new_x = 1024+(res_x-1024)/3;

	// Get Y screen resolution and recompute proper window height
	new_y = (res_y = wxSystemSettings::GetMetric(wxSYS_SCREEN_Y, this)) - 200;

	//Change window dimensions properly
/*
	size=GetSize();
	size.SetWidth(new_x);
*/	
	SetSize(new_x, new_y);
	mainSizer->Hide((size_t) 0);
	mainSizer->Hide((size_t) 1);
	Layout();
}

cMainFrame::~cMainFrame()
{
}
