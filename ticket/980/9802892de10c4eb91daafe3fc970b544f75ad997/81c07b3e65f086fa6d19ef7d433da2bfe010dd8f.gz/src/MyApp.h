//---------------------------------------------------------------------------
// Created:     4.12.2006 23:20:46
// Adapted: 	19.1.2008 20:45:00 for Eclipse
//---------------------------------------------------------------------------

#ifndef __UDPRECEIVE1FRMApp_h__
#define __UDPRECEIVE1FRMApp_h__

#include <wx/app.h>


class MyApp : public wxApp
{
	public:
		bool OnInit();
//		int OnRun();
		int OnExit();
};

#endif
