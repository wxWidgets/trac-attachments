#ifndef CSEVERMANAGEMENT_H_
#define CSEVERMANAGEMENT_H_

#include "cServerSocket.h"

#include <wx/event.h>
#include <vector>

class cServerManagement : public wxEvtHandler
{
	public:
		cServerManagement();
		~cServerManagement();
		// Activates or deactivates all structures needed to listen on 6355 port for client connection.
		// On deactivation closes all opened server sockets as well.
		void Listen(bool listen);
		// Writes message with text given by UNICODE wxString as UTF-8 string to all connected clients
		// (so far ignores sending errors !!!)
		bool Send(wxString text);

		enum {
					ID_SERVER = 1000,
					ID_CLIENT
		};
		
	private:
		void OnServerEvent(wxSocketEvent &event);
		void AddSocket(cServerSocket *socket);
		void RemoveSocket(cServerSocket *socket);

	private:
		std::vector<cServerSocket> sockets;
		wxSocketServer *listening_socket;
		bool listening;
		
		DECLARE_EVENT_TABLE();
};

extern cServerManagement *serverManagement;

#endif /*CSEVERMANAGEMENT_H_*/
