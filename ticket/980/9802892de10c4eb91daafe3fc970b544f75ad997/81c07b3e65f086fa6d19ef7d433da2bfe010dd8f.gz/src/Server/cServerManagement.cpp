#include "cServerManagement.h"
#include "../Logging/cLogTextCtrl.h"

BEGIN_EVENT_TABLE(cServerManagement, wxEvtHandler)
	EVT_SOCKET(cServerManagement::ID_SERVER, cServerManagement::OnServerEvent)
END_EVENT_TABLE()

cServerManagement::cServerManagement()
{
	listening = false;
}

cServerManagement::~cServerManagement()
{
	Listen(false);
}

// Activates or deactivates all structures needed to listen on 6355 port for client connection.
// On deactivation closes all opened server sockets as well.
void cServerManagement::Listen(bool listen)
{
	if (listen == listening) { // No change required
		*serverLog << wxString::Format(_("@ LISTENING CHANGE to %s REQUESTED while already %s.\n"), listen ? _("listening") : _("not listening"), listen ? _("listening") : _("not listening"));
		 return;	
	};

	if(listen) {
		wxIPV4address localAddr;

		localAddr.AnyAddress();
		localAddr.Service(6355);

		listening_socket = new wxSocketServer(localAddr, wxSOCKET_NONE | wxSOCKET_REUSEADDR);
		listening_socket->SetEventHandler(*this, ID_SERVER);
		listening_socket->SetNotify(wxSOCKET_CONNECTION_FLAG);
		listening_socket->Notify(true);

		if(!listening_socket->Ok()) {
			wxBell();
			*serverLog << _("@ SERVER LISTENING FAILED\n");
			listening = false;
		} else {
			*serverLog << _("@ SERVER LISTENING INITED\n");
			listening = true;
		};
	} else {
		listening_socket->Destroy();
		*serverLog << _("@ SERVER LISTENING DESTROYED\n");
		listening = false;
		while(sockets.size()) {
			sockets.back().Destroy();
			sockets.pop_back();
			*serverLog << wxString::Format(_("Socket from back destroyed. Current count of server sockets = %u.\n"), sockets.size());
		}
		*serverLog << _("@ ALL SERVER SOCKETS DESTROYED\n");
	};
}

// Writes message with text given by UNICODE wxString as UTF-8 string to all connected clients
// Returns true if no error occured, false othervise. 
bool cServerManagement::Send(wxString text)
{
	std::vector<cServerSocket>::iterator it;
	bool result=true;	// Assume no error
	
	for(it = sockets.begin(); it != sockets.end(); ++it )
	{
		result &= (*it).Send(text);
	}
	*serverLog << wxString::Format(_("Text \"%s\" sent to %u sockets.\n"), (const char *) text.c_str(), sockets.size());
	
	return result;
}

void cServerManagement::OnServerEvent(wxSocketEvent &event)
{
	*serverLog << _("@ SERVER SOCKET EVENT:\n");

	switch(event.GetSocketEvent())
	{
		case wxSOCKET_CONNECTION:
		{
			register cServerSocket *serverSocket;
			wxSocketBase *tmp;
			wxIPV4address locl, peer;
			

			*serverLog << _("@ INCOMMING CONNECTION DETECTED\n");
			if((tmp=listening_socket->Accept())) {
				if(tmp->Ok()) {
					*serverLog << _("@ INCOMMING CONNECTION ACCEPTED\n");
					if(!tmp->GetLocal(locl))
						*serverLog << _("ERROR: can not get local address of socket !\n");
					else if(!tmp->GetPeer(peer))
						*serverLog << _("ERROR: can not get peer address of socket !\n");
					else {
						*serverLog << wxString::Format(_("%s[%s]:%u -> %s[%s]:%u\n"),
						                               peer.Hostname().c_str(),
						                               peer.IPAddress().c_str(),
						                               peer.Service(),
						                               locl.Hostname().c_str(),
						                               locl.IPAddress().c_str(),
						                               locl.Service()
						);
					};


					AddSocket(serverSocket = new cServerSocket(tmp));
					tmp->SetClientData(serverSocket);

					wxString message = _("INITIAL MESSAGE FROM SERVER");
					//serverSocket->Send(message);
				} else
					*serverLog << _("@ INCOMMING SERVER SOCKET NOT OK !!!\n");
			} else
				*serverLog << _("@ INCOMMING CONNECTION ACCEPTION ERROR\n");

		};
		break;
		
		case wxSOCKET_INPUT:
		{
			char buff[1024];
			wxString s;
			wxSocketBase *socket = event.GetSocket();

			if(socket->ReadMsg(&buff, 1024).Error()) {
				*serverLog << _("@ READMSG ERROR !\n");
			} else {
				*serverLog << wxString::Format(_("@ READMSG READ %u byte(s)\n"), socket->LastCount());
				s = wxString::FromUTF8(buff, socket->LastCount());
				*serverLog << _("@ INCOMMING DATA READ: ") << s << wxT("\n");
			};
		};
		break;

		case wxSOCKET_LOST:
		{
			*serverLog << _("@ CLIENT SOCKET CLOSED\n");
			RemoveSocket((cServerSocket *) event.GetClientData());
		};
		break;
		
		default:
			// Should never occure, as other events are not allowed via SetNotify()
			// the following code is just to remove excessive compiler warnings about not handled enum values
			*serverLog << _("@ SERVER SOCKET INVALID EVENT\n");
			break;
	};
}

void cServerManagement::AddSocket(cServerSocket *socket)
{
	sockets.push_back(*socket);
	*serverLog << wxString::Format(_("Added new server socket, current count of server sockets = %u.\n"), sockets.size());
}

void cServerManagement::RemoveSocket(cServerSocket *socket)
{
	std::vector<cServerSocket>::iterator it;
	for(it = sockets.begin(); (it != sockets.end()) && ((*it) != *socket) ; ++it );
	if(it != sockets.end())
	{
		*serverLog << wxString::Format(_("Erased server socket. "));
		sockets.erase(it);
	}
	*serverLog << wxString::Format(_("Current count of server sockets = %u.\n"), sockets.size());
}

cServerManagement *serverManagement;
