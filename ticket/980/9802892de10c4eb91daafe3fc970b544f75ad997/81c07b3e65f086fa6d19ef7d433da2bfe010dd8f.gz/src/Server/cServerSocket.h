#ifndef CSERVERSOCKET_H_
#define CSERVERSOCKET_H_

//#include <wx/event.h>
#include <wx/socket.h>

//#include <vector>

class cServerSocket
{
public:
	cServerSocket(wxSocketBase *socket);
//	virtual ~cServerSocket();
	// Writes message with text given by UNICODE wxString as UTF-8 string
	// Returns false if error occured (use wxSocketBase::LastError() to detect error kind)
	bool Send(wxString &text);
	// Sends whole the localities and alarms tree from the server to the client
	// typically used on socket connection establishment, 
	// but usable e.g. for hot plug of new localities tree or client requested refresh after error
//	void ReloadTree(void);
	// Calls Destroy() method on included socket
	void Destroy(void);
	// Comparison is based on equality of the socket pointer
	bool operator==(cServerSocket &other);
	bool operator!=(cServerSocket &other);

private:
	wxSocketBase *socket;
};

#endif /*CSERVERSOCKET_H_*/
