#include "cServerSocket.h"
#include "cServerManagement.h"
#include "../Logging/cLogTextCtrl.h"

#include <wx/string.h>

cServerSocket::cServerSocket(wxSocketBase *par_socket)
{
	socket = par_socket;
	socket->SetEventHandler(*serverManagement, cServerManagement::ID_SERVER);
	socket->SetNotify(wxSOCKET_INPUT_FLAG | wxSOCKET_LOST_FLAG);
	socket->Notify(true);

//	socket->SetTimeout(1);
//	socket->SetFlags(wxSOCKET_NONE);

	*serverLog << _("@ SERVER SOCKET CONSTRUCTED\n");
}

void cServerSocket::Destroy(void)
{
	socket->Destroy();
	*serverLog << _("@ SERVER SOCKET DESTROYED\n");
}

// Comparison is based on equality of the socket pointer
bool cServerSocket::operator==(cServerSocket &other)
{
	return socket == other.socket;
};

bool cServerSocket::operator!=(cServerSocket &other)
{
	return !(*this == other);
}

bool cServerSocket::Send(wxString &s)
{
	const char *buff;
	wxCharBuffer cbuff;

	cbuff = s.utf8_str();
	buff = cbuff.data();
	register int len = strlen(buff);
	*serverLog << wxString::Format(wxT("SENDING %i char(s): "), len);
	*serverLog << s << wxT("\n");
	if(socket->WriteMsg(buff, len).Error())	
		*serverLog << wxT("SENDING ERROR\n");
	else
		*serverLog << wxT("MESSAGE SENT\n");
	return !socket->Error();
}

/*
void cServerSocket::Send(wxString s)
{
	const char *buff;
	wxCharBuffer cbuff;

	cbuff = s.utf8_str();
	buff = cbuff.data();
//	buff = "test";
//	buff = s.mb_str(wxConvUTF8);
	int len = strlen(buff);
	*serverLog << wxString::Format(wxT("SENDING %i char(s):"), len);
	*serverLog << s << wxT("\n");
	socket->WriteMsg(buff, len);	
	*serverLog << wxT("MESSAGE SENT\n");
}
*/

