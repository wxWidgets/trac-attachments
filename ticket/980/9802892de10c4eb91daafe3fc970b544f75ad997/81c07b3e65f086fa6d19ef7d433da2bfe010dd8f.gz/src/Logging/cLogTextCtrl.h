#ifndef CLOGTEXTCTRL_H_
#define CLOGTEXTCTRL_H_

#include <wx/textctrl.h>
#include <wx/string.h>

class cLogTextCtrl
{
public:
	cLogTextCtrl(wxTextCtrl *par_ctrl) : ctrl(par_ctrl){};
	cLogTextCtrl & operator<<(wxString s);
	
private:
	wxTextCtrl *ctrl;
};

extern cLogTextCtrl *clientLog, *serverLog;	// Instantiated in MyApp.cpp

#endif /*CLOGTEXTCTRL_H_*/
