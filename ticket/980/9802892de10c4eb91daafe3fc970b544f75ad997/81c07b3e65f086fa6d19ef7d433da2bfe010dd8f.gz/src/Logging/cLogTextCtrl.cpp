#include "cLogTextCtrl.h"

#define MIN_LOG_SIZE	75000
#define MAX_LOG_SIZE	100000

cLogTextCtrl & cLogTextCtrl::operator<<(const wxString s)
{
	long size;

	*ctrl << s;
	if((s.Find('\n') != wxNOT_FOUND) && ((size = ctrl->GetLastPosition()) > MAX_LOG_SIZE)) {
		ctrl->Remove(1,size - MIN_LOG_SIZE);
	};
	return *this;
}
