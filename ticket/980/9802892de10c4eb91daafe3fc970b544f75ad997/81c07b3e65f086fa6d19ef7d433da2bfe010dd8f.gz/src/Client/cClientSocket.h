#ifndef CCLIENTSOCKET_H_
#define CCLIENTSOCKET_H_

#include <wx/event.h>
#include <wx/socket.h>

class cClientSocket : wxEvtHandler
{
public:
	cClientSocket();
	virtual ~cClientSocket();
	
	void Connect(void);
	void Disconnect(void);
	bool Send(wxString s);
	
	
private:
	enum
	{
		ID_DATAREADY=1100,
		ID_DUMMY_VALUE_ //don't remove this value unless you have other enum values
	};

	// Incomming connection event
	void OnClientSocketEvent(wxSocketEvent &event);

	
	wxSocketClient socket;

	DECLARE_EVENT_TABLE()
};

#endif /*CCLIENTSOCKET_H_*/

extern cClientSocket *clientSocket;
