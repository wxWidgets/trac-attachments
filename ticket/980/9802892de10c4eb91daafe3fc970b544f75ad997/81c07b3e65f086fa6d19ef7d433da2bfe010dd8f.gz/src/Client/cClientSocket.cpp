#include "cClientSocket.h"
#include "../Logging/cLogTextCtrl.h"

BEGIN_EVENT_TABLE(cClientSocket, wxEvtHandler)
	EVT_SOCKET(ID_DATAREADY, cClientSocket::OnClientSocketEvent)
END_EVENT_TABLE()

cClientSocket::cClientSocket()
{

	*clientLog << _("@ CLIENT SOCKET CONSTRUCTED\n");
}

cClientSocket::~cClientSocket()
{
	Disconnect();
}

void cClientSocket::OnClientSocketEvent(wxSocketEvent &event)
{
	wxString s;

	*clientLog << _("@ CLIENT SOCKET EVENT:\n");

	switch(event.GetSocketEvent())
	{
		case wxSOCKET_INPUT:
		{

			char buff[1024];

			wxBell();
			if(socket.ReadMsg(&buff, 1024).Error()) {
				*clientLog << _("@ READMSG ERROR !\n");
			} else {
				*clientLog << wxString::Format(_("@ READMSG READ %u byte(s)\n"), socket.LastCount());
				s = wxString::FromUTF8(buff, socket.LastCount());
				*clientLog << _("@ INCOMMING DATA READ: ") << s << wxT("\n");
			};
		};
		
//		WriteMessage(s);
		break;

		case wxSOCKET_LOST:
		{
			*clientLog << _("@ CLIENT SOCKET CLOSED\n");
//			socket->Destroy();
			if(socket.IsConnected())
				*clientLog << _("CLIENT SOCKET reports IsConnected().\n");
			else
				*clientLog << _("CLIENT SOCKET reports IsConnected()==false.\n");
		};
		break;
		
		default:
			// Should never occure, as other events are not allowed via SetNotify()
			// the following code is just to remove excessive compiler warnings about not handled enum values
			*clientLog << _("@ CLIENT SOCKET INVALID EVENT\n");
			break;
	};
}

void cClientSocket::Connect(void)
{
	if(socket.IsConnected())
		*clientLog << _("CONNECT CLIENT SOCKET requested while IsConnected() reported - request IGNORED.\n");
	else {


		wxIPV4address addr;
		addr.Hostname(wxT("localhost"));
		addr.Service(6355);

		if(socket.Connect(addr)) {
			*clientLog << wxT("CONNECTED to server\n");
			socket.SetEventHandler(*this, ID_DATAREADY);
			socket.SetNotify(wxSOCKET_INPUT_FLAG | wxSOCKET_LOST_FLAG);
			socket.Notify(true);
			*clientLog << wxT("NOTIFICATION setup done\n");
			
			//Send(_("INITIAL MESSAGE FROM CLIENT"));
		}
		else
			*clientLog << wxT("CONNECTION to server FAILED\n");
	};

}

void cClientSocket::Disconnect(void)
{
	if(socket.IsConnected()) {
		socket.Close();
		if (clientLog) *clientLog << wxT("CONNECTION to server DISCONNECTED.\n");
	} else
		if (clientLog) *clientLog << wxT("DISCONNECT CLIENT SOCKET requested while IsConnected()==false reported - IGNORED.\n");
}

bool cClientSocket::Send(wxString s)
{
	const char *buff;
	wxCharBuffer cbuff;

	cbuff = s.utf8_str();
	buff = cbuff.data();
	register int len = strlen(buff);
	*clientLog << wxString::Format(wxT("SENDING %i char(s):"), len);
	*clientLog << s << wxT("\n");
	if(socket.WriteMsg(buff, len).Error())	
		*clientLog << wxT("SENDING ERROR\n");
	else
		*clientLog << wxT("MESSAGE SENT\n");
	return !socket.Error();
}

cClientSocket *clientSocket;
