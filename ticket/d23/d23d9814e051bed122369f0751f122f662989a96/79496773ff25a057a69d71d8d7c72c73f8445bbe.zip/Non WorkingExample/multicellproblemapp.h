/////////////////////////////////////////////////////////////////////////////
// Name:        multicellproblemapp.h
// Purpose:     
// Author:      Helge Baurmann
// Modified by: 
// Created:     19/06/2013 17:37:39
// RCS-ID:      
// Copyright:   (c) by Euro Systems Group
// Licence:     
/////////////////////////////////////////////////////////////////////////////

#ifndef _MULTICELLPROBLEMAPP_H_
#define _MULTICELLPROBLEMAPP_H_


/*!
 * Includes
 */

////@begin includes
#include "wx/image.h"
#include "mainframe.h"
////@end includes

/*!
 * Forward declarations
 */

////@begin forward declarations
////@end forward declarations

/*!
 * Control identifiers
 */

////@begin control identifiers
////@end control identifiers

/*!
 * MulticellProblemApp class declaration
 */

class MulticellProblemApp: public wxApp
{    
    DECLARE_CLASS( MulticellProblemApp )
    DECLARE_EVENT_TABLE()

public:
    /// Constructor
    MulticellProblemApp();

    void Init();

    /// Initialises the application
    virtual bool OnInit();

    /// Called on exit
    virtual int OnExit();

////@begin MulticellProblemApp event handler declarations

////@end MulticellProblemApp event handler declarations

////@begin MulticellProblemApp member function declarations

////@end MulticellProblemApp member function declarations

////@begin MulticellProblemApp member variables
////@end MulticellProblemApp member variables
};

/*!
 * Application instance declaration 
 */

////@begin declare app
DECLARE_APP(MulticellProblemApp)
////@end declare app

#endif
    // _MULTICELLPROBLEMAPP_H_
