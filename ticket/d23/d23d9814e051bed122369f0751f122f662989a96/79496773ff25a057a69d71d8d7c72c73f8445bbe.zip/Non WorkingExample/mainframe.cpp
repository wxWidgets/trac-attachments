/////////////////////////////////////////////////////////////////////////////
// Name:        mainframe.cpp
// Purpose:     
// Author:      Helge Baurmann
// Modified by: 
// Created:     19/06/2013 17:38:03
// RCS-ID:      
// Copyright:   (c) by Euro Systems Group
// Licence:     
/////////////////////////////////////////////////////////////////////////////

// For compilers that support precompilation, includes "wx/wx.h".
#include "wx/wxprec.h"

#ifdef __BORLANDC__
#pragma hdrstop
#endif

#ifndef WX_PRECOMP
#include "wx/wx.h"
#endif

////@begin includes
////@end includes

#include "mainframe.h"
#include <wx/grid.h>

////@begin XPM images
////@end XPM images


/*
 * MainFrame type definition
 */

IMPLEMENT_CLASS( MainFrame, wxFrame )


/*
 * MainFrame event table definition
 */

BEGIN_EVENT_TABLE( MainFrame, wxFrame )

////@begin MainFrame event table entries
////@end MainFrame event table entries

END_EVENT_TABLE()


/*
 * MainFrame constructors
 */

MainFrame::MainFrame()
{
    Init();
}

MainFrame::MainFrame( wxWindow* parent, wxWindowID id, const wxString& caption, const wxPoint& pos, const wxSize& size, long style )
{
    Init();
    Create( parent, id, caption, pos, size, style );
}


/*
 * MainFrame creator
 */

bool MainFrame::Create( wxWindow* parent, wxWindowID id, const wxString& caption, const wxPoint& pos, const wxSize& size, long style )
{
////@begin MainFrame creation
    wxFrame::Create( parent, id, caption, pos, size, style );

    CreateControls();
    Centre();
////@end MainFrame creation
    return true;
}


/*
 * MainFrame destructor
 */

MainFrame::~MainFrame()
{
////@begin MainFrame destruction
////@end MainFrame destruction
}


/*
 * Member initialisation
 */

void MainFrame::Init()
{
////@begin MainFrame member initialisation
    m_TxtCtrl = NULL;
    m_Grid = NULL;
////@end MainFrame member initialisation
}


/*
 * Control creation for MainFrame
 */

void MainFrame::CreateControls()
{    
////@begin MainFrame content construction
    MainFrame* itemFrame1 = this;

    wxPanel* itemPanel2 = new wxPanel( itemFrame1, ID_PANEL, wxDefaultPosition, wxDefaultSize, wxSUNKEN_BORDER|wxTAB_TRAVERSAL );

    wxBoxSizer* itemBoxSizer3 = new wxBoxSizer(wxVERTICAL);
    itemPanel2->SetSizer(itemBoxSizer3);

    wxBoxSizer* itemBoxSizer4 = new wxBoxSizer(wxHORIZONTAL);
    itemBoxSizer3->Add(itemBoxSizer4, 0, wxGROW|wxALL, 5);

    wxStaticText* itemStaticText5 = new wxStaticText( itemPanel2, wxID_STATIC, _("Multicell Text control"), wxDefaultPosition, wxDefaultSize, 0 );
    itemBoxSizer4->Add(itemStaticText5, 0, wxALIGN_TOP|wxALL, 5);

    m_TxtCtrl = new wxTextCtrl( itemPanel2, ID_TEXTCTRL, wxEmptyString, wxDefaultPosition, wxSize(300, 80), wxTE_MULTILINE );
    itemBoxSizer4->Add(m_TxtCtrl, 0, wxALIGN_CENTER_VERTICAL|wxALL, 5);

    wxBoxSizer* itemBoxSizer7 = new wxBoxSizer(wxHORIZONTAL);
    itemBoxSizer3->Add(itemBoxSizer7, 0, wxGROW|wxALL, 5);

    wxStaticText* itemStaticText8 = new wxStaticText( itemPanel2, wxID_STATIC, _("Multicell in \ncolumn B"), wxDefaultPosition, wxDefaultSize, 0 );
    itemBoxSizer7->Add(itemStaticText8, 0, wxALIGN_TOP|wxALL, 5);

    m_Grid = new wxGrid( itemPanel2, ID_GRID, wxDefaultPosition, wxSize(600, 250), wxSUNKEN_BORDER|wxHSCROLL|wxVSCROLL );
    m_Grid->SetDefaultColSize(50);
    m_Grid->SetDefaultRowSize(25);
    m_Grid->SetColLabelSize(25);
    m_Grid->SetRowLabelSize(50);
    m_Grid->CreateGrid(3, 5, wxGrid::wxGridSelectCells);
    itemBoxSizer7->Add(m_Grid, 0, wxGROW|wxALL, 5);

////@end MainFrame content construction
    
    // code to display the problem
    m_TxtCtrl->SetLabel(_T("Text Ctrl is working with enter to get multilines") );
    m_Grid->SetCellEditor(1, 1, new wxGridCellAutoWrapStringEditor());
    m_Grid->SetCellEditor(2, 1, new wxGridCellAutoWrapStringEditor());
    m_Grid->SetCellEditor(3, 1, new wxGridCellAutoWrapStringEditor());
    m_Grid->SetColSize(1,200);
    
    m_Grid->SetRowSize(0,80);
    m_Grid->SetRowSize(1,80);
    m_Grid->SetRowSize(2,80);
    m_Grid->SetCellValue(0,1, _T("The following rows in the column should be wrapped and multiline with Ctrl-Enter when field is selected and text is put in"));
}


/*
 * Should we show tooltips?
 */

bool MainFrame::ShowToolTips()
{
    return true;
}

/*
 * Get bitmap resources
 */

wxBitmap MainFrame::GetBitmapResource( const wxString& name )
{
    // Bitmap retrieval
////@begin MainFrame bitmap retrieval
    wxUnusedVar(name);
    return wxNullBitmap;
////@end MainFrame bitmap retrieval
}

/*
 * Get icon resources
 */

wxIcon MainFrame::GetIconResource( const wxString& name )
{
    // Icon retrieval
////@begin MainFrame icon retrieval
    wxUnusedVar(name);
    return wxNullIcon;
////@end MainFrame icon retrieval
}
