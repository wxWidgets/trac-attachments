#!/usr/bin/env python
print "Checking dependencies..."
import sys

try:
    import wx
    from wx import webkit
    print "wxPython - OK"
except:
    print "you need to have wxPython installed !"
    print "download it at: http://www.wxpython.org/download.php"
    print "this app does not run without it !"
    print "leaving...."    
    sys.exit()
        
import gui_xrc


class webKitDebug(wx.App):

    def printSelection(self, event):
       
        print self.kit.GetSelection().encode('latin-1')


    

        
    def OnInit(self):
                        
        wx.InitAllImageHandlers()
        self.main = gui_xrc.xrcFRAME1(None)
        self.main.getSelection.Bind(wx.EVT_BUTTON, self.printSelection)
        
        self.main.SetSize((860, 768))
        
        
        
        
        
        self.kit = webkit.WebKitCtrl(self.main, -1, size = (800,600), style=0)
        #self.kit = wx.TextCtrl(self.main, -1, size = (800,600))
        self.kit.SetPosition((15, 65))
        #self.kit.SetPageSource("<h1>Hello World</h1>")
        self.kit.LoadURL("http://www.wxpython.org")
        #self.kit.SetValue("some text")
        #self.kit.MakeEditable()
        
        # display GUI
        self.main.Show(True)
        
        
        
        wx.Yield()
        return True


   


def main():
    application = webKitDebug(0)
    application.MainLoop()
    
   
if __name__ == '__main__':
    main()
