#include <wx/frame.h>
#include <wx/app.h>

#pragma comment( lib, "wxbase29ud.lib" )
#pragma comment( lib, "wxmsw29ud_core.lib" )
#pragma comment( lib, "wxpngd.lib" )
#pragma comment( lib, "wxzlibd.lib" )
#pragma comment( lib, "advapi32.lib" )
#pragma comment( lib, "comctl32.lib" )
#pragma comment( lib, "comdlg32.lib" )
#pragma comment( lib, "user32.lib" )
#pragma comment( lib, "gdi32.lib" )
#pragma comment( lib, "oleaut32.lib" )
#pragma comment( lib, "shell32.lib" )
#pragma comment( lib, "ole32.lib" )
#pragma comment( lib, "rpcrt4.lib" )
#pragma comment( lib, "winspool.lib" )

class WxAppDll : public wxApp
{
};

DECLARE_APP(WxAppDll);
IMPLEMENT_APP_NO_MAIN(WxAppDll);

extern "C" __declspec(dllexport) void runWX()
{
	int    argc( 1 );
	char * argv[] = { "Test", 0 };
    wxInitializer initializer(argc, argv);

	new wxFrame( NULL, wxID_ANY, "Frame" );
};
