Edit run.bat - specify wxwidgets location, as well as location of the lib dir relative to
the wxwidgets location. You need to have debug static unicode version of wxWidgets with
static runtime.

Run run.bat - this should produce app.exe and test.dll.

Finally run app.exe - an assertion failure should occur (screenshot attached).
