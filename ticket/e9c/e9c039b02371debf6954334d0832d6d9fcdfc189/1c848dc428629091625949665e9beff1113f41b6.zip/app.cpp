#include <wx/frame.h>
#include <wx/app.h>

#pragma comment( lib, "wxbase29ud.lib" )
#pragma comment( lib, "wxmsw29ud_core.lib" )
#pragma comment( lib, "wxpngd.lib" )
#pragma comment( lib, "wxzlibd.lib" )
#pragma comment( lib, "advapi32.lib" )
#pragma comment( lib, "comctl32.lib" )
#pragma comment( lib, "comdlg32.lib" )
#pragma comment( lib, "user32.lib" )
#pragma comment( lib, "gdi32.lib" )
#pragma comment( lib, "oleaut32.lib" )
#pragma comment( lib, "shell32.lib" )
#pragma comment( lib, "ole32.lib" )
#pragma comment( lib, "rpcrt4.lib" )
#pragma comment( lib, "winspool.lib" )

class WxAppExe : public wxApp
{
public:
	typedef void (*RunWx)();

	virtual bool OnInit()
	{
		// Boom.
		wxFrame * frame = new wxFrame( NULL, wxID_ANY, "Frame", wxDefaultPosition, wxSize( 500, 500 ) );
		frame->Show();

		HMODULE test( ::LoadLibrary( L"test.dll" ) );
		RunWx runWx = (RunWx)GetProcAddress( test, "runWX" );
		runWx();
		FreeLibrary( test );
		return true;
	}
};

DECLARE_APP(WxAppExe);
IMPLEMENT_APP(WxAppExe);


