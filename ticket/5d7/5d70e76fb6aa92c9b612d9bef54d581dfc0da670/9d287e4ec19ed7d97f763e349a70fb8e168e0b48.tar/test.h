#ifndef _TEST_H_
#define _TEST_H_


/*!
 * Includes
 */

////@begin includes
#include "wx/frame.h"
#include "wx/notebook.h"
////@end includes

/*!
 * Control identifiers
 */

////@begin control identifiers
#define ID_TESTF 13200
#define ID_TESTF_PANEL 13201
#define ID_TESTF_BOOK 13209
#define ID_TESTF_PANEL_TAB1 13210
#define ID_TEST_TL 13212
#define ID_TEST_TR 13213
#define ID_TEST_BL 13214
#define ID_TEST_BR 13215
#define ID_TEST_B1 13216
#define ID_TEST_B2 13217
#define SYMBOL_TESTF_STYLE wxCAPTION|wxSYSTEM_MENU|wxCLOSE_BOX|wxFRAME_FLOAT_ON_PARENT|wxFRAME_NO_TASKBAR|wxTAB_TRAVERSAL
#define SYMBOL_TESTF_TITLE _("Test")
#define SYMBOL_TESTF_IDNAME ID_TESTF
#define SYMBOL_TESTF_SIZE wxDefaultSize
#define SYMBOL_TESTF_POSITION wxDefaultPosition
////@end control identifiers


/*!
 * TestFrame class declaration
 */

class TestFrame: public wxFrame
{    
    DECLARE_CLASS( TestFrame )
    DECLARE_EVENT_TABLE()

public:
    TestFrame();
    TestFrame( wxWindow* parent, wxWindowID id = SYMBOL_TESTF_IDNAME, const wxString& caption = SYMBOL_TESTF_TITLE, const wxPoint& pos = SYMBOL_TESTF_POSITION, const wxSize& size = SYMBOL_TESTF_SIZE, long style = SYMBOL_TESTF_STYLE );

    bool Create( wxWindow* parent, wxWindowID id = SYMBOL_TESTF_IDNAME, const wxString& caption = SYMBOL_TESTF_TITLE, const wxPoint& pos = SYMBOL_TESTF_POSITION, const wxSize& size = SYMBOL_TESTF_SIZE, long style = SYMBOL_TESTF_STYLE );

    ~TestFrame();

    void Init();
    void CreateControls();


    void OnCloseWindow( wxCloseEvent& event );
    void OnCancel( wxCommandEvent& event );

};

#endif
    // _TESTF_H_
