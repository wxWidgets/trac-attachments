// stdafx.cpp : source file that includes just the standard includes
//	wxActiveX.pch will be the pre-compiled header
//	stdafx.obj will contain the pre-compiled type information

#include "stdafx.h"

// TODO: reference any additional headers you need in STDAFX.H
// and not in this file

//---------------------------------------------------------------------------
#ifdef _MSC_VER // Microsoft C++ Compiler

#ifdef _DEBUG
	#pragma comment (lib, "wxbase29ud.lib")
	#pragma comment (lib, "wxmsw29ud_core.lib")
#else
	#pragma comment (lib, "wxbase29u.lib")
	#pragma comment (lib, "wxmsw29u_core.lib")
#endif

#endif // _MSC_VER // Microsoft C++ Compiler
//---------------------------------------------------------------------------

