/////////////////////////////////////////////////////////////////////////////

// Name:        wxbugapp.cpp

// Purpose:     

// Author:      Greg Hazel

// Modified by: 

// Created:     Sun Aug 14 03:14:08 2005

// RCS-ID:      

// Copyright:   

// Licence:     

/////////////////////////////////////////////////////////////////////////////



#if defined(__GNUG__) && !defined(__APPLE__)
#pragma implementation "wxbugapp.h"
#endif

// For compilers that support precompilation, includes "wx/wx.h".
#include "wx/wxprec.h"

#ifdef __BORLANDC__
#pragma hdrstop
#endif

#ifndef WX_PRECOMP
#include "wx/wx.h"
#endif

////@begin includes
////@end includes

#include "wxbugapp.h"
#include "wxbugpanel.h"

////@begin XPM images
////@end XPM images

/*!
 * Application instance implementation
 */

////@begin implement app
IMPLEMENT_APP( wxBug_App )
////@end implement app

/*!
 * wxBug_App type definition
 */

IMPLEMENT_CLASS( wxBug_App, wxApp )

/*!
 * wxBug_App event table definition
 */

BEGIN_EVENT_TABLE( wxBug_App, wxApp )

////@begin wxBug_App event table entries
////@end wxBug_App event table entries

END_EVENT_TABLE()

/*!
 * Constructor for wxBug_App
 */

wxBug_App::wxBug_App()
{
////@begin wxBug_App member initialisation
////@end wxBug_App member initialisation
}

/*!
 * Initialisation for wxBug_App
 */

bool wxBug_App::OnInit()
{    
////@begin wxBug_App initialisation
    // Remove the comment markers above and below this block
    // to make permanent changes to the code.

#if wxUSE_XPM
    wxImage::AddHandler( new wxXPMHandler );
#endif
#if wxUSE_LIBPNG
    wxImage::AddHandler( new wxPNGHandler );
#endif
#if wxUSE_LIBJPEG
    wxImage::AddHandler( new wxJPEGHandler );
#endif
#if wxUSE_GIF
    wxImage::AddHandler( new wxGIFHandler );
#endif
    wxBugLauncher* mainWindow = new wxBugLauncher(NULL, ID_BUG_LAUNCHER, _("wxBug Launcher"));
    mainWindow->Show(true);
////@end wxBug_App initialisation

    return true;
}

/*!
 * Cleanup for wxBug_App
 */
int wxBug_App::OnExit()
{    
////@begin wxBug_App cleanup
    return wxApp::OnExit();
////@end wxBug_App cleanup
}

