/////////////////////////////////////////////////////////////////////////////

// Name:        wxbugapp.h

// Purpose:     

// Author:      Greg Hazel

// Modified by: 

// Created:     Sun Aug 14 03:14:08 2005

// RCS-ID:      

// Copyright:   

// Licence:     

/////////////////////////////////////////////////////////////////////////////



#ifndef _WXBUGAPP_H_
#define _WXBUGAPP_H_

#if defined(__GNUG__) && !defined(__APPLE__)
#pragma interface "wxbugapp.cpp"
#endif

/*!
 * Includes
 */

////@begin includes
#include "wx/image.h"
#include "wxbuglauncher.h"
////@end includes

/*!
 * Forward declarations
 */

////@begin forward declarations
////@end forward declarations

/*!
 * Control identifiers
 */

////@begin control identifiers
////@end control identifiers

/*!
 * wxBug_App class declaration
 */

class wxBug_App: public wxApp
{    
    DECLARE_CLASS( wxBug_App )
    DECLARE_EVENT_TABLE()

public:
    /// Constructor
    wxBug_App();

    /// Initialises the application
    virtual bool OnInit();

    /// Called on exit
    virtual int OnExit();

////@begin wxBug_App event handler declarations

////@end wxBug_App event handler declarations

////@begin wxBug_App member function declarations

////@end wxBug_App member function declarations

////@begin wxBug_App member variables
////@end wxBug_App member variables
};

/*!
 * Application instance declaration 
 */

////@begin declare app
DECLARE_APP(wxBug_App)
////@end declare app

#endif
    // _WXBUGAPP_H_
