/////////////////////////////////////////////////////////////////////////////

// Name:        wxbuglauncher.h

// Purpose:     

// Author:      Greg Hazel

// Modified by: 

// Created:     08/14/05 23:51:14

// RCS-ID:      

// Copyright:   

// Licence:     

/////////////////////////////////////////////////////////////////////////////



#ifndef _WXBUGLAUNCHER_H_
#define _WXBUGLAUNCHER_H_

#if defined(__GNUG__) && !defined(__APPLE__)
#pragma interface "wxbuglauncher.cpp"
#endif

/*!
 * Includes
 */

////@begin includes
#include "wx/spinctrl.h"
////@end includes

/*!
 * Forward declarations
 */

////@begin forward declarations
class wxSpinCtrl;
////@end forward declarations

/*!
 * Control identifiers
 */

////@begin control identifiers
#define ID_BUG_LAUNCHER 10002
#define SYMBOL_WXBUGLAUNCHER_STYLE wxCAPTION|wxRESIZE_BORDER|wxSYSTEM_MENU|wxCLOSE_BOX
#define SYMBOL_WXBUGLAUNCHER_TITLE _("wxBug Launcher")
#define SYMBOL_WXBUGLAUNCHER_IDNAME ID_BUG_LAUNCHER
#define SYMBOL_WXBUGLAUNCHER_SIZE wxSize(400, 300)
#define SYMBOL_WXBUGLAUNCHER_POSITION wxDefaultPosition
#define ID_CB_BREAK_GTK 10003
#define ID_CB_GROWABLE 10004
#define ID_CB_USEMINSIZE 10000
#define ID_SC_WIDTH 10001
#define ID_SC_HEIGHT 10002
#define ID_CB_MINSIZE_RELATIONSHIP 10016
#define ID_BUTTON 10017
////@end control identifiers

/*!
 * Compatibility
 */

#ifndef wxCLOSE_BOX
#define wxCLOSE_BOX 0x1000
#endif
#ifndef wxFIXED_MINSIZE
#define wxFIXED_MINSIZE 0
#endif

/*!
 * wxBugLauncher class declaration
 */

class wxBugLauncher: public wxFrame
{    
    DECLARE_DYNAMIC_CLASS( wxBugLauncher )
    DECLARE_EVENT_TABLE()

public:
    /// Constructors
    wxBugLauncher( );
    wxBugLauncher( wxWindow* parent, wxWindowID id = SYMBOL_WXBUGLAUNCHER_IDNAME, const wxString& caption = SYMBOL_WXBUGLAUNCHER_TITLE, const wxPoint& pos = SYMBOL_WXBUGLAUNCHER_POSITION, const wxSize& size = SYMBOL_WXBUGLAUNCHER_SIZE, long style = SYMBOL_WXBUGLAUNCHER_STYLE );

    /// Creation
    bool Create( wxWindow* parent, wxWindowID id = SYMBOL_WXBUGLAUNCHER_IDNAME, const wxString& caption = SYMBOL_WXBUGLAUNCHER_TITLE, const wxPoint& pos = SYMBOL_WXBUGLAUNCHER_POSITION, const wxSize& size = SYMBOL_WXBUGLAUNCHER_SIZE, long style = SYMBOL_WXBUGLAUNCHER_STYLE );

    /// Creates the controls and sizers
    void CreateControls();

////@begin wxBugLauncher event handler declarations

    /// wxEVT_COMMAND_CHECKBOX_CLICKED event handler for ID_CB_BREAK_GTK
    void OnCbBreakGtkClick( wxCommandEvent& event );

    /// wxEVT_COMMAND_CHECKBOX_CLICKED event handler for ID_CB_GROWABLE
    void OnCbGrowableClick( wxCommandEvent& event );

    /// wxEVT_COMMAND_CHECKBOX_CLICKED event handler for ID_CB_USEMINSIZE
    void OnCbUseminsizeClick( wxCommandEvent& event );

    /// wxEVT_COMMAND_SPINCTRL_UPDATED event handler for ID_SC_WIDTH
    void OnScWidthUpdated( wxSpinEvent& event );

    /// wxEVT_COMMAND_SPINCTRL_UPDATED event handler for ID_SC_HEIGHT
    void OnScHeightUpdated( wxSpinEvent& event );

    /// wxEVT_COMMAND_CHOICE_SELECTED event handler for ID_CB_MINSIZE_RELATIONSHIP
    void OnCbMinsizeRelationshipSelected( wxCommandEvent& event );

    /// wxEVT_COMMAND_BUTTON_CLICKED event handler for ID_BUTTON
    void OnButtonClick( wxCommandEvent& event );

////@end wxBugLauncher event handler declarations

////@begin wxBugLauncher member function declarations

    /// Retrieves bitmap resources
    wxBitmap GetBitmapResource( const wxString& name );

    /// Retrieves icon resources
    wxIcon GetIconResource( const wxString& name );
////@end wxBugLauncher member function declarations

    void LaunchDemo(bool use_minsize,
                    wxSize minsize,
                    int relationship,
                    bool growable,
                    bool append_before_show,
                    const wxString title = _("wxBug Demonstration"));

    /// Should we show tooltips?
    static bool ShowToolTips();

////@begin wxBugLauncher member variables
    wxSpinCtrl* m_sc_width;
    wxSpinCtrl* m_sc_height;
////@end wxBugLauncher member variables
    bool m_demo_use_minsize;
    wxSize m_demo_minsize;

    int m_demo_minsize_relationship;

    bool m_demo_growable_col;

    bool m_demo_append_before_show;
};

#endif
    // _WXBUGLAUNCHER_H_
