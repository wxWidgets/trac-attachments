/////////////////////////////////////////////////////////////////////////////

// Name:        wxbuglauncher.cpp

// Purpose:     

// Author:      Greg Hazel

// Modified by: 

// Created:     08/14/05 23:51:14

// RCS-ID:      

// Copyright:   

// Licence:     

/////////////////////////////////////////////////////////////////////////////



#if defined(__GNUG__) && !defined(__APPLE__)
#pragma implementation "wxbuglauncher.h"
#endif

// For compilers that support precompilation, includes "wx/wx.h".
#include "wx/wxprec.h"

#ifdef __BORLANDC__
#pragma hdrstop
#endif

#ifndef WX_PRECOMP
#include "wx/wx.h"
#endif

////@begin includes
////@end includes

#include "wxbuglauncher.h"
#include "wxbugpanel.h"

////@begin XPM images
////@end XPM images

/*!
 * wxBugLauncher type definition
 */

IMPLEMENT_DYNAMIC_CLASS( wxBugLauncher, wxFrame )

/*!
 * wxBugLauncher event table definition
 */

BEGIN_EVENT_TABLE( wxBugLauncher, wxFrame )

////@begin wxBugLauncher event table entries
    EVT_CHECKBOX( ID_CB_BREAK_GTK, wxBugLauncher::OnCbBreakGtkClick )

    EVT_CHECKBOX( ID_CB_GROWABLE, wxBugLauncher::OnCbGrowableClick )

    EVT_CHECKBOX( ID_CB_USEMINSIZE, wxBugLauncher::OnCbUseminsizeClick )

    EVT_SPINCTRL( ID_SC_WIDTH, wxBugLauncher::OnScWidthUpdated )

    EVT_SPINCTRL( ID_SC_HEIGHT, wxBugLauncher::OnScHeightUpdated )

    EVT_CHOICE( ID_CB_MINSIZE_RELATIONSHIP, wxBugLauncher::OnCbMinsizeRelationshipSelected )

    EVT_BUTTON( ID_BUTTON, wxBugLauncher::OnButtonClick )

////@end wxBugLauncher event table entries

END_EVENT_TABLE()

/*!
 * wxBugLauncher constructors
 */

wxBugLauncher::wxBugLauncher( )
{
}

wxBugLauncher::wxBugLauncher( wxWindow* parent, wxWindowID id, const wxString& caption, const wxPoint& pos, const wxSize& size, long style )
{
    Create(parent, id, caption, pos, size, style);
}

/*!
 * wxBugLauncher creator
 */

bool wxBugLauncher::Create( wxWindow* parent, wxWindowID id, const wxString& caption, const wxPoint& pos, const wxSize& size, long style )
{
////@begin wxBugLauncher member initialisation
    m_sc_width = NULL;
    m_sc_height = NULL;
////@end wxBugLauncher member initialisation

////@begin wxBugLauncher creation
    SetExtraStyle(GetExtraStyle()|wxWS_EX_BLOCK_EVENTS);
    wxFrame::Create( parent, id, caption, pos, size, style );

    CreateControls();
    GetSizer()->Fit(this);
    GetSizer()->SetSizeHints(this);
    Centre();
////@end wxBugLauncher creation
    return TRUE;
}

/*!
 * Control creation for wxBugLauncher
 */

void wxBugLauncher::CreateControls()
{    
////@begin wxBugLauncher content construction
    //wxBugLauncher* mpanel = this;

    wxFlexGridSizer* msizer = new wxFlexGridSizer(1, 1, 0, 0);
    SetSizer(msizer);
    
    wxPanel* mpanel = new wxPanel(this, wxID_ANY);
    msizer->Add(mpanel, 0, wxGROW, 0);

    wxFlexGridSizer* itemFlexGridSizer2 = new wxFlexGridSizer(4, 1, 0, 0);
    mpanel->SetSizer(itemFlexGridSizer2);

    wxFlexGridSizer* itemFlexGridSizer3 = new wxFlexGridSizer(1, 2, 0, 0);
    itemFlexGridSizer3->AddGrowableCol(0);
    itemFlexGridSizer2->Add(itemFlexGridSizer3, 0, wxALIGN_CENTER_HORIZONTAL|wxGROW|wxALL, 5);

    wxCheckBox* itemCheckBox4 = new wxCheckBox( mpanel, ID_CB_BREAK_GTK, _("Append Before Show (GTK bug)"), wxDefaultPosition, wxDefaultSize, wxCHK_2STATE );
    itemCheckBox4->SetValue(TRUE);
    itemFlexGridSizer3->Add(itemCheckBox4, 0, wxALIGN_LEFT|wxALIGN_CENTER_VERTICAL|wxALL, 5);

    wxFlexGridSizer* itemFlexGridSizer5 = new wxFlexGridSizer(1, 2, 0, 0);
    itemFlexGridSizer5->AddGrowableCol(0);
    itemFlexGridSizer2->Add(itemFlexGridSizer5, 0, wxALIGN_CENTER_HORIZONTAL|wxGROW|wxALL, 5);

    wxCheckBox* itemCheckBox6 = new wxCheckBox( mpanel, ID_CB_GROWABLE, _("Use Growable Column"), wxDefaultPosition, wxDefaultSize, wxCHK_2STATE );
    itemCheckBox6->SetValue(TRUE);
    itemFlexGridSizer5->Add(itemCheckBox6, 0, wxALIGN_LEFT|wxALIGN_CENTER_VERTICAL|wxALL, 5);

    wxFlexGridSizer* itemFlexGridSizer7 = new wxFlexGridSizer(1, 2, 0, 0);
    itemFlexGridSizer7->AddGrowableCol(0);
    itemFlexGridSizer2->Add(itemFlexGridSizer7, 0, wxALIGN_CENTER_HORIZONTAL|wxGROW|wxALL, 5);

    wxCheckBox* itemCheckBox8 = new wxCheckBox( mpanel, ID_CB_USEMINSIZE, _("Use MinSize:"), wxDefaultPosition, wxDefaultSize, wxCHK_2STATE );
    itemCheckBox8->SetValue(FALSE);
    itemFlexGridSizer7->Add(itemCheckBox8, 0, wxALIGN_LEFT|wxALIGN_CENTER_VERTICAL|wxALL, 5);

    wxFlexGridSizer* itemFlexGridSizer9 = new wxFlexGridSizer(2, 4, 0, 0);
    itemFlexGridSizer7->Add(itemFlexGridSizer9, 0, wxALIGN_RIGHT|wxALIGN_CENTER_VERTICAL|wxALL, 5);

    wxStaticText* itemStaticText10 = new wxStaticText( mpanel, wxID_STATIC, _("Width:"), wxDefaultPosition, wxDefaultSize, 0 );
    itemFlexGridSizer9->Add(itemStaticText10, 0, wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL|wxALL|wxADJUST_MINSIZE, 5);

    m_sc_width = new wxSpinCtrl( mpanel, ID_SC_WIDTH, _("0"), wxDefaultPosition, wxSize(60, -1), wxSP_ARROW_KEYS, -1, 1280, 0 );
    itemFlexGridSizer9->Add(m_sc_width, 0, wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL|wxALL, 5);

    wxStaticText* itemStaticText12 = new wxStaticText( mpanel, wxID_STATIC, _("Height:"), wxDefaultPosition, wxDefaultSize, 0 );
    itemFlexGridSizer9->Add(itemStaticText12, 0, wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL|wxALL|wxADJUST_MINSIZE, 5);

    m_sc_height = new wxSpinCtrl( mpanel, ID_SC_HEIGHT, _("0"), wxDefaultPosition, wxSize(60, -1), wxSP_ARROW_KEYS, -1, 1280, 0 );
    itemFlexGridSizer9->Add(m_sc_height, 0, wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL|wxALL, 5);

    wxFlexGridSizer* itemFlexGridSizer14 = new wxFlexGridSizer(2, 2, 0, 0);
    itemFlexGridSizer14->AddGrowableCol(0);
    itemFlexGridSizer2->Add(itemFlexGridSizer14, 0, wxALIGN_CENTER_HORIZONTAL|wxGROW|wxALL, 5);

    wxStaticText* itemStaticText15 = new wxStaticText( mpanel, wxID_STATIC, _("MinSize Relationship:"), wxDefaultPosition, wxDefaultSize, 0 );
    itemFlexGridSizer14->Add(itemStaticText15, 0, wxALIGN_LEFT|wxALIGN_CENTER_VERTICAL|wxALL|wxADJUST_MINSIZE, 5);

    wxString itemChoice16Strings[] = {
        _("wxADJUST_MINSIZE"),
        _("wxFIXED_MINSIZE")
    };
    wxChoice* itemChoice16 = new wxChoice( mpanel, ID_CB_MINSIZE_RELATIONSHIP, wxDefaultPosition, wxDefaultSize, 2, itemChoice16Strings, 0 );
    itemChoice16->SetStringSelection(_("wxADJUST_MINSIZE"));
    itemFlexGridSizer14->Add(itemChoice16, 0, wxALIGN_RIGHT|wxALIGN_CENTER_VERTICAL|wxALL, 5);

    wxButton* itemButton17 = new wxButton( mpanel, ID_BUTTON, _("Launch Window"), wxDefaultPosition, wxDefaultSize, 0 );
    itemFlexGridSizer2->Add(itemButton17, 0, wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL|wxALL, 5);

////@end wxBugLauncher content construction

    m_demo_use_minsize = false;
    m_demo_minsize = wxSize(0,0);

    m_demo_minsize_relationship = wxADJUST_MINSIZE;

    m_demo_growable_col = true;

    m_sc_width->Enable(m_demo_use_minsize);
    m_sc_height->Enable(m_demo_use_minsize);

    //
    LaunchDemo(false, wxSize(0,0), wxADJUST_MINSIZE, true, true, _("Broken on GTK"));
}

/*!
 * Should we show tooltips?
 */

bool wxBugLauncher::ShowToolTips()
{
    return TRUE;
}

/*!
 * Get bitmap resources
 */

wxBitmap wxBugLauncher::GetBitmapResource( const wxString& name )
{
    // Bitmap retrieval
////@begin wxBugLauncher bitmap retrieval
    return wxNullBitmap;
////@end wxBugLauncher bitmap retrieval
}

/*!
 * Get icon resources
 */

wxIcon wxBugLauncher::GetIconResource( const wxString& name )
{
    // Icon retrieval
////@begin wxBugLauncher icon retrieval
    return wxNullIcon;
////@end wxBugLauncher icon retrieval
}


/*!
* wxEVT_COMMAND_SPINCTRL_UPDATED event handler for ID_SC_WIDTH
*/

void wxBugLauncher::OnScWidthUpdated( wxSpinEvent& event )
{
  m_demo_minsize.SetWidth(event.GetInt());
  event.Skip();
}

/*!
 * wxEVT_COMMAND_SPINCTRL_UPDATED event handler for ID_SC_HEIGHT
 */

void wxBugLauncher::OnScHeightUpdated( wxSpinEvent& event )
{
  m_demo_minsize.SetHeight(event.GetInt());
  event.Skip();
}


/*!
 * wxEVT_COMMAND_CHECKBOX_CLICKED event handler for ID_CHECKBOX
 */

void wxBugLauncher::OnCbUseminsizeClick( wxCommandEvent& event )
{
  m_demo_use_minsize = event.GetInt();
  m_sc_width->Enable(m_demo_use_minsize);
  m_sc_height->Enable(m_demo_use_minsize);
  event.Skip();
}

/*!
 * wxEVT_COMMAND_CHECKBOX_CLICKED event handler for ID_CHECKBOX1
 */

void wxBugLauncher::OnCbGrowableClick( wxCommandEvent& event )
{
  m_demo_growable_col = event.GetInt();
  event.Skip();
}

/*!
 * wxEVT_COMMAND_CHOICE_SELECTED event handler for ID_MINSIZE_RELATIONSHIP_CHOICE
 */

void wxBugLauncher::OnCbMinsizeRelationshipSelected( wxCommandEvent& event )
{
  switch(event.GetInt()) {
    case 0:
      m_demo_minsize_relationship = wxADJUST_MINSIZE;
      break;
    case 1:
      m_demo_minsize_relationship = wxFIXED_MINSIZE;
      break;
  }
  
  event.Skip();
}

/*!
* wxEVT_COMMAND_CHECKBOX_CLICKED event handler for ID_CB_BREAK_GTK
*/

void wxBugLauncher::OnCbBreakGtkClick( wxCommandEvent& event )
{
  m_demo_append_before_show = event.GetInt();
  event.Skip();
}

/*!
 * wxEVT_COMMAND_BUTTON_CLICKED event handler for ID_BUTTON
 */

void wxBugLauncher::OnButtonClick( wxCommandEvent& event )
{
  LaunchDemo(m_demo_use_minsize,
             m_demo_minsize,
             m_demo_minsize_relationship,
             m_demo_growable_col,
             m_demo_append_before_show);

  event.Skip();
}

void wxBugLauncher::LaunchDemo(bool use_minsize,
                               wxSize minsize,
                               int relationship,
                               bool growable,
                               bool append_before_show,
                               const wxString title)
{
  static wxString text = wxString(_("A very long string with lots and lots of words and things that exceed the length of the window"));

  // the first frame. broken.
  wxFrame *frame1 = new wxFrame(this, wxID_ANY, title);

  wxFlexGridSizer *s1 = new wxFlexGridSizer(1, 1, 0, 0);
  s1->AddGrowableRow(0);
  s1->AddGrowableCol(0);

  wxBugsPanel *panel1 = new wxBugsPanel(frame1, wxID_ANY,
                                        use_minsize,
                                        minsize,
                                        relationship,
                                        growable);
  s1->Add(panel1, 0, wxGROW, 0);

  if (append_before_show)
  {
    panel1->m_choice->Append(text);
    panel1->m_choice->SetSelection(0);

    frame1->SetSizerAndFit(s1);
    frame1->Show();
  }
  else
  {
    frame1->SetSizerAndFit(s1);
    frame1->Show();

    panel1->m_choice->Append(text);
    panel1->m_choice->SetSelection(0);
  }
}
