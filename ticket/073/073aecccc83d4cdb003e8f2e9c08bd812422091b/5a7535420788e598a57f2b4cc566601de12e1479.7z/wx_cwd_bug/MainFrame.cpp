
#include "MainFrame.h"

#include <wx/dirctrl.h>

#include "App.h"

BEGIN_EVENT_TABLE(MFrame, wxFrame)
    EVT_BUTTON  (BF_ID_MAINFRAME_TEST, MFrame::OnTest)
END_EVENT_TABLE()


MFrame::MFrame ()
            : wxFrame (NULL,
                       BF_ID_MAINFRAME,
                       wxEmptyString),
                       menuProject_(NULL)
{
    // set as top window
    wxGetApp().SetTopWindow(this);

    //
    wxButton* pButton = new wxButton(this, BF_ID_MAINFRAME_TEST, "wxGetCwd()");

    //
    wxGenericDirCtrl* pDirCtrl = new wxGenericDirCtrl(this);

    // ** sizer **
    wxSizer* pSizer = new wxBoxSizer (wxVERTICAL);
    pSizer->Add( pButton, wxSizerFlags(0).Center() );
    pSizer->Add( pDirCtrl, wxSizerFlags(3).Expand() );
    SetSizer(pSizer);

    //
    Show(TRUE);
}

/*virtual*/ MFrame::~MFrame ()
{
}

void MFrame::OnTest (wxCommandEvent& WXUNUSED(event))
{
    wxMessageBox(wxGetCwd());
}
