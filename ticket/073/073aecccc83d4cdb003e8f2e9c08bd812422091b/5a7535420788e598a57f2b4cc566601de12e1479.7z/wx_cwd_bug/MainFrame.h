#ifndef MAINFRAME_H
#define MAINFRAME_H

#include <wx/wx.h>

#define BF_ID_MAINFRAME             1 + 10000
#define BF_ID_MAINFRAME_TEST        18 + 10000

/// main window of the application
class MFrame : public wxFrame
{
    private:
        ///
        wxMenu*             menuProject_;

    public:
        /// constructor
        MFrame ();
        /// virtual destructor
        virtual ~MFrame ();

        ///
        void OnTest (wxCommandEvent& event);

    DECLARE_EVENT_TABLE();
};

#endif
