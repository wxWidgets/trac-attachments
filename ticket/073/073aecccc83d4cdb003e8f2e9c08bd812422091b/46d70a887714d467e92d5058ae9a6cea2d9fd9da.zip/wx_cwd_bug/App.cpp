#include "App.h"

#include <wx/wx.h>

#include "MainFrame.h"

IMPLEMENT_APP(App);


App::App ()
{
}

/*virtual*/ App::~App ()
{
}

bool App::OnInit()
{
    new MFrame();

    return TRUE;
}

/*virtual*/ int App::OnExit()
{
}
