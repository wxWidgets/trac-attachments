#ifndef BFAPP_H
#define BFAPP_H

// forwarde declarations
class MFrame;

// includes
#include <wx/wx.h>
#include <wx/intl.h>


///
class App : public wxApp
{
    public:
        /// constructor
        App ();
        /// virtual destructor
        virtual ~App ();

        /// start point like main()
        virtual bool OnInit();
        ///
        virtual int OnExit();

};

///
DECLARE_APP(App);

#endif
