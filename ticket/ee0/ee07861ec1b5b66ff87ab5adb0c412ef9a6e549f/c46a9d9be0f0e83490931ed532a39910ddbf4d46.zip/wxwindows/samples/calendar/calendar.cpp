/////////////////////////////////////////////////////////////////////////////
// Name:        calendar.cpp
// Purpose:     wxCalendarCtrl sample
// Author:      Vadim Zeitlin
// Modified by: Antti Merenluoto
// Created:     02.01.00
// RCS-ID:      $Id: calendar.cpp,v 1.18 2002/12/13 21:32:57 MBN Exp $
// Copyright:   (c) Vadim Zeitlin
// Licence:     wxWindows licence
/////////////////////////////////////////////////////////////////////////////

/* Modification notes: 
  As I increased the number of configured colours I realized that I needed an application to
  test the different combinations. Instead of making separate application, I added the code in
  here. I hope it does not prevent anyone from seeing wood from trees. With new code
  this sample additionally demonstrates:
  - Deriving and using wxDateTimeHolidayAuthority
  - Declaring and sending custom events. 
  - Catching mouse clicks responding to them. 
  - Using ready wx controls and owner draw items in the same window. 
   (AM)
*/

// ============================================================================
// declarations
// ============================================================================

// ----------------------------------------------------------------------------
// headers
// ----------------------------------------------------------------------------

#if defined(__GNUG__) && !defined(__APPLE__)
    #pragma implementation "calendar.cpp"
    #pragma interface "calendar.cpp"
#endif

// For compilers that support precompilation, includes "wx/wx.h".
#include "wx/wxprec.h"

#ifdef __BORLANDC__
    #pragma hdrstop
#endif

// for all others, include the necessary headers
#ifndef WX_PRECOMP
    #include "wx/app.h"
    #include "wx/log.h"
    #include "wx/frame.h"
    #include "wx/panel.h"
    #include "wx/stattext.h"
    #include "wx/menu.h"
    #include "wx/layout.h"
    #include "wx/msgdlg.h"
#endif

#include "wx/calctrl.h"
#include "wx/colordlg.h"
#include "wx/filedlg.h"
#include "wx/ffile.h"

// ----------------------------------------------------------------------------
// private constants
// ----------------------------------------------------------------------------
const int MAX_COLOURTYPES = 5;

// ----------------------------------------------------------------------------
// private classes
// ----------------------------------------------------------------------------

// Define a new application type, each program should derive a class from wxApp
class MyApp : public wxApp
{
public:
    // override base class virtuals
    // ----------------------------

    // this one is called on application startup and is a good place for the app
    // initialization (doing it here and not in the ctor allows to have an error
    // return: if OnInit() returns false, the application terminates)
    virtual bool OnInit();
};

// ............................................................................
class MyPanel : public wxPanel
{
public:
    MyPanel(wxFrame *frame);

    void OnCalendar(wxCalendarEvent& event);
    void OnCalendarWeekDayClick(wxCalendarEvent& event);
    void OnCalendarChange(wxCalendarEvent& event);
    void OnCalMonthChange(wxCalendarEvent& event);
    void OnCalYearChange(wxCalendarEvent& event);

    wxCalendarCtrl *GetCal() const { return m_calendar; }

    // turn on/off the specified style bit on the calendar control
    void ToggleCalStyle(bool on, int style);

    void HighlightSpecial(bool on);

private:
    void OnPaint(wxPaintEvent& event);
    void OnClick(wxMouseEvent& event);

    void OnChangeFgColor(wxCommandEvent &event);
    void OnChangeBgColor(wxCommandEvent &event);

    wxCalendarCtrl *m_calendar;
    wxFrame *frame;
    wxPoint colourPosition[MAX_COLOURTYPES];

    DECLARE_EVENT_TABLE()
};

// ............................................................................
BEGIN_DECLARE_EVENT_TYPES()
    DECLARE_EVENT_TYPE(EVT_FGCOLOR_CHANGED, 0)
    DECLARE_EVENT_TYPE(EVT_BGCOLOR_CHANGED, 0)
END_DECLARE_EVENT_TYPES()

// Define a new frame type: this is going to be our main frame
class MyFrame : public wxFrame
{
public:
    // ctor(s)
    MyFrame(const wxString& title, const wxPoint& pos, const wxSize& size);

    // event handlers (these functions should _not_ be virtual)
    void ExportColours(wxCommandEvent& event);
    void OnQuit(wxCommandEvent& event);
    void OnAbout(wxCommandEvent& event);

    void OnCalMonday(wxCommandEvent& event);
    void OnCalHolidays(wxCommandEvent& event);
    void OnCalSpecial(wxCommandEvent& event);

    void OnCalAllowMonth(wxCommandEvent& event);
    void OnCalAllowYear(wxCommandEvent& event);

    void OnCalShowSurroundingWeeks(wxCommandEvent& event);
    void OnAllowYearUpdate(wxUpdateUIEvent& event);

    void OnCalWeekNumbers(wxCommandEvent &event);
    void OnSatAsHoliday(wxCommandEvent &event);
    void OnNarrow(wxCommandEvent &event);

    void OnCalShortDayNames(wxCommandEvent &event);
    void OnSizeSmall(wxCommandEvent &event);
    void OnSizeDefault(wxCommandEvent &event);
    void OnSizeLarge(wxCommandEvent &event);

private:
    MyPanel *m_panel;

    // any class wishing to process wxWindows events must use this macro
    DECLARE_EVENT_TABLE()
};

// ............................................................................
class MyHolidays : public wxDateTimeHolidayAuthority
{
protected:
    virtual bool DoIsHoliday(const wxDateTime& dt) const;
    virtual size_t DoGetHolidaysInRange(const wxDateTime& dtStart,
                                        const wxDateTime& dtEnd,
                                        wxDateTimeArray& holidays) const;
};

// ----------------------------------------------------------------------------
// constants
// ----------------------------------------------------------------------------

const int CAL_X_COORD = 160;
const int CAL_Y_COORD = 30;

// IDs for the controls and the menu commands
enum
{
    // menu items
    Calendar_File_About = 100,
    Calendar_File_ExportColours,
    Calendar_File_Quit,
    Calendar_Cal_Monday = 200,
    Calendar_Cal_Holidays,
    Calendar_Cal_Special,
    Calendar_Cal_Month,
    Calendar_Cal_Year,
    Calendar_Cal_SurroundWeeks,
    Calendar_Cal_WeekNumbers,
    Calendar_Cal_SatAsHoliday,
    Calendar_Cal_Narrow,
    Calendar_Size_ShortDayNames,
    Calendar_Size_Small,
    Calendar_Size_Default,
    Calendar_Size_Large,
    Calendar_CalCtrl = 1000
};

// Custom events for MyPanel
DEFINE_EVENT_TYPE(EVT_FGCOLOR_CHANGED)
DEFINE_EVENT_TYPE(EVT_BGCOLOR_CHANGED)

// ----------------------------------------------------------------------------
// event tables and other macros for wxWindows
// ----------------------------------------------------------------------------

// the event tables connect the wxWindows events with the functions (event
// handlers) which process them. It can be also done at run-time, but for the
// simple menu events like this the static method is much simpler.
BEGIN_EVENT_TABLE(MyFrame, wxFrame)
    EVT_MENU(Calendar_File_Quit,  MyFrame::OnQuit)
    EVT_MENU(Calendar_File_ExportColours, MyFrame::ExportColours)
    EVT_MENU(Calendar_File_About, MyFrame::OnAbout)

    EVT_MENU(Calendar_Cal_Monday, MyFrame::OnCalMonday)
    EVT_MENU(Calendar_Cal_Holidays, MyFrame::OnCalHolidays)
    EVT_MENU(Calendar_Cal_Special, MyFrame::OnCalSpecial)

    EVT_MENU(Calendar_Cal_Month, MyFrame::OnCalAllowMonth)
    EVT_MENU(Calendar_Cal_Year, MyFrame::OnCalAllowYear)
    EVT_UPDATE_UI(Calendar_Cal_Year, MyFrame::OnAllowYearUpdate)

    EVT_MENU(Calendar_Cal_SurroundWeeks, MyFrame::OnCalShowSurroundingWeeks)

    EVT_MENU(Calendar_Cal_WeekNumbers, MyFrame::OnCalWeekNumbers)
    EVT_MENU(Calendar_Cal_SatAsHoliday, MyFrame::OnSatAsHoliday)
    EVT_MENU(Calendar_Cal_Narrow, MyFrame::OnNarrow)
    EVT_MENU(Calendar_Size_ShortDayNames, MyFrame::OnCalShortDayNames)
    EVT_MENU(Calendar_Size_Small, MyFrame::OnSizeSmall)
    EVT_MENU(Calendar_Size_Default, MyFrame::OnSizeDefault)
    EVT_MENU(Calendar_Size_Large, MyFrame::OnSizeLarge)

END_EVENT_TABLE()

BEGIN_EVENT_TABLE(MyPanel, wxPanel)
    EVT_PAINT(MyPanel::OnPaint)
    EVT_LEFT_DOWN(MyPanel::OnClick)
    EVT_CALENDAR            (Calendar_CalCtrl,   MyPanel::OnCalendar)
    EVT_CALENDAR_MONTH      (Calendar_CalCtrl,   MyPanel::OnCalMonthChange)
    EVT_CALENDAR_YEAR       (Calendar_CalCtrl,   MyPanel::OnCalYearChange)
    EVT_CALENDAR_SEL_CHANGED(Calendar_CalCtrl,   MyPanel::OnCalendarChange)
    EVT_CALENDAR_WEEKDAY_CLICKED(Calendar_CalCtrl, MyPanel::OnCalendarWeekDayClick)
    EVT_COMMAND(0,EVT_FGCOLOR_CHANGED,MyPanel::OnChangeFgColor)
    EVT_COMMAND(0,EVT_BGCOLOR_CHANGED,MyPanel::OnChangeBgColor)
END_EVENT_TABLE()

// Create a new application object: this macro will allow wxWindows to create
// the application object during program execution (it's better than using a
// static object for many reasons) and also declares the accessor function
// wxGetApp() which will return the reference of the right type (i.e. MyApp and
// not wxApp)
IMPLEMENT_APP(MyApp)

// ============================================================================
// implementation
// ============================================================================

// ----------------------------------------------------------------------------
// the application class
// ----------------------------------------------------------------------------

// `Main program' equivalent: the program execution "starts" here
bool MyApp::OnInit()
{
    // Create the main application window
    MyFrame *frame = new MyFrame(_T("Calendar wxWindows sample"),
                                 wxPoint(50, 50), wxSize(450, 340));

    frame->Show(TRUE);

    // success: wxApp::OnRun() will be called which will enter the main message
    // loop and the application will run. If we returned FALSE here, the
    // application would exit immediately.
    return TRUE;
}

// ----------------------------------------------------------------------------
// main frame
// ----------------------------------------------------------------------------

// frame constructor
MyFrame::MyFrame(const wxString& title, const wxPoint& pos, const wxSize& size)
       : wxFrame((wxFrame *)NULL, -1, title, pos, size)
{
    // create a menu bar
    wxMenu *menuFile = new wxMenu;

    menuFile->Append(Calendar_File_About, _T("&About...\tCtrl-A"), _T("Show about dialog"));
    menuFile->Append(Calendar_File_ExportColours, _T("&Export colours..."), _T("Exports current colours into a disk file."));
    menuFile->AppendSeparator();
    menuFile->Append(Calendar_File_Quit, _T("E&xit\tAlt-X"), _T("Quit this program"));

    wxMenu *menuCal = new wxMenu;
    menuCal->Append(Calendar_Cal_Monday,
                    _T("Monday &first weekday\tCtrl-F"),
                    _T("Toggle between Mon and Sun as the first week day"),
                    TRUE);
    menuCal->Append(Calendar_Cal_Holidays, _T("Show &holidays\tCtrl-H"),
                    _T("Toggle highlighting the holidays"),
                    TRUE);
    menuCal->Append(Calendar_Cal_Special, _T("Highlight &special dates\tCtrl-S"),
                    _T("Test custom highlighting"),
                    TRUE);
    menuCal->Append(Calendar_Cal_SurroundWeeks,
                    _T("Show s&urrounding weeks\tCtrl-W"),
                    _T("Show the neighbouring weeks in the prev/next month"),
                    TRUE);
    menuCal->AppendSeparator();
    menuCal->Append(Calendar_Cal_Month, _T("Hide &Month change arrow\tCtrl-M"),
                    _T("Hides the month change arrow."),
                    TRUE);
    menuCal->Append(Calendar_Cal_Year, _T("Hide &Year change arrow\tCtrl-Y"),
                    _T("Hides the year change arrow."),
                    TRUE);
    menuCal->AppendSeparator();
    menuCal->Append(Calendar_Cal_WeekNumbers, _T("&Week number display"),
                    _T("Shows/hides week numbers on the left of day numbers"),
                    TRUE);
    menuCal->Append(Calendar_Cal_SatAsHoliday, _T("S&aturday is holiday"),
                    _T("Shows Saturdays as a normal day or a holiday."),
                    TRUE);
    menuCal->Append(Calendar_Cal_Narrow, _T("&Narrow to current year"),
                    _T("Allows user to choose only days within the current year."),
                    TRUE);

    wxMenu *menuSize = new wxMenu;
    menuSize->Append(Calendar_Size_ShortDayNames, _T("Sh&ort day names"),
                    _T("Toggles between two and three letter week day names."),
                    TRUE);
    menuSize->Append(Calendar_Size_Small , _T("&Small"), _T("Make calendar small"));
    menuSize->Append(Calendar_Size_Default , _T("&Default"), _T("Make calendar resize to default size"));
    menuSize->Append(Calendar_Size_Large , _T("&Large"), _T("Make calendar large"));

    // now append the freshly created menu to the menu bar...
    wxMenuBar *menuBar = new wxMenuBar;
    menuBar->Append(menuFile, _T("&File"));
    menuBar->Append(menuCal, _T("&Calendar"));
    menuBar->Append(menuSize, _T("&Size"));

    menuBar->Check(Calendar_Cal_Monday, TRUE);
    menuBar->Check(Calendar_Cal_Holidays, TRUE);
    menuBar->Check(Calendar_Cal_SatAsHoliday,TRUE);

    // ... and attach this menu bar to the frame
    SetMenuBar(menuBar);

    m_panel = new MyPanel(this);

#if wxUSE_STATUSBAR
    // create a status bar just for fun (by default with 1 pane only)
    CreateStatusBar(2);
    SetStatusText(_T("Welcome to wxWindows!"));
#endif // wxUSE_STATUSBAR
}

void MyFrame::OnQuit(wxCommandEvent& WXUNUSED(event))
{
    // TRUE is to force the frame to close
    Close(TRUE);
}

void MyFrame::OnAbout(wxCommandEvent& WXUNUSED(event))
{
    wxMessageBox(_T("wxCalendarCtrl sample\n� 2000 Vadim Zeitlin"),
                 _T("About Calendar"), wxOK | wxICON_INFORMATION, this);
}

void MyFrame::OnCalMonday(wxCommandEvent& event)
{
    bool enable = GetMenuBar()->IsChecked(event.GetId());

    m_panel->ToggleCalStyle(enable, wxCAL_MONDAY_FIRST);
}

void MyFrame::OnCalHolidays(wxCommandEvent& event)
{
    bool enable = GetMenuBar()->IsChecked(event.GetId());

    m_panel->GetCal()->EnableHolidayDisplay(enable);
}

void MyFrame::OnCalSpecial(wxCommandEvent& event)
{
    m_panel->HighlightSpecial(GetMenuBar()->IsChecked(event.GetId()));
}

void MyFrame::OnCalAllowMonth(wxCommandEvent& event)
{
    bool allow = GetMenuBar()->IsChecked(event.GetId());
    m_panel->ToggleCalStyle(allow, wxCAL_NO_MONTH_CHANGE);
}

void MyFrame::OnCalAllowYear(wxCommandEvent& event)
{
    bool allow = GetMenuBar()->IsChecked(event.GetId());
    m_panel->ToggleCalStyle(allow, wxCAL_NO_YEAR_CHANGE);
}

void MyFrame::OnCalShowSurroundingWeeks(wxCommandEvent& event)
{
    bool allow = GetMenuBar()->IsChecked(event.GetId());

    m_panel->ToggleCalStyle(allow, wxCAL_SHOW_SURROUNDING_WEEKS);
}

void MyFrame::OnAllowYearUpdate(wxUpdateUIEvent& event)
{
    event.Enable( !GetMenuBar()->IsChecked(Calendar_Cal_Month));
}

void MyFrame::OnCalWeekNumbers(wxCommandEvent &event)
{
    bool enable = GetMenuBar()->IsChecked(event.GetId());
    m_panel->GetCal()->EnableWeekNumberDisplay(enable);
}

void MyFrame::OnCalShortDayNames(wxCommandEvent &event)
{
    bool enable = GetMenuBar()->IsChecked(event.GetId());
    m_panel->GetCal()->EnableShortDayName(enable);

    wxSize best = m_panel->GetCal()->GetBestSize();
    m_panel->GetCal()->SetSize(CAL_X_COORD,CAL_Y_COORD,best.GetWidth(),best.GetHeight());
}

void MyFrame::OnSatAsHoliday(wxCommandEvent &event)
{
    /* In this case it is more feasible to work with the wxDateTimeHolidayAuthority instead of
       individually turning off and on the Saturdays. The wxDateTimeWorkDays authority is
       supplied by wx libary. It includes Saturdays as holidays by default. Our own class has
       only Sundays as holidays.
     */
    bool enable = GetMenuBar()->IsChecked(event.GetId());
    wxDateTimeHolidayAuthority::ClearAllAuthorities();
    if(enable)
        wxDateTimeHolidayAuthority::AddAuthority(new wxDateTimeWorkDays);
    else
        wxDateTimeHolidayAuthority::AddAuthority(new MyHolidays);
    m_panel->GetCal()->NoteHolidayChange();
}

void MyFrame::OnNarrow(wxCommandEvent &event)
{
    bool enable = GetMenuBar()->IsChecked(event.GetId());
    if(enable)
    {
        // Calculate the limits, in this case the first and last day of current year.
        wxDateTime start = wxDateTime::Now();
        wxDateTime end = start;
        start.SetToYearDay(1);
        end.SetMonth(wxDateTime::Dec);
        end.SetToLastMonthDay();
        m_panel->GetCal()->SetDateRange(start,end);
    }
    else
        m_panel->GetCal()->SetDateRange();
}

// ----------------------------------------------------------------------------
// Various calendar sizes
// ----------------------------------------------------------------------------

void MyFrame::OnSizeSmall(wxCommandEvent &event)
{
    /* I wanted to try how the control looks with a font designed for small print.  This is not
       going to look much different from the default size unless you get and install Silkscreen
       font: http://www.kottke.org/plus/type/silkscreen/ or use any other font with same
       characteristics. The Silkscreen is free for personal and commercial use. -AM
    */
    wxFont normal(7,wxDEFAULT,wxNORMAL,wxNORMAL,FALSE,"Silkscreen");
    wxFont title(7,wxDEFAULT,wxNORMAL,wxNORMAL,FALSE,"Silkscreen");

    m_panel->GetCal()->SetFont(normal);
    m_panel->GetCal()->SetTitleFont(title);

    wxSize best = m_panel->GetCal()->GetBestSize();
    m_panel->GetCal()->SetSize(CAL_X_COORD,CAL_Y_COORD,best.GetWidth(),best.GetHeight());
}

void MyFrame::OnSizeDefault(wxCommandEvent &event)
{
    // Set fonts as the control sets them by default.
    wxFont normal = *wxSWISS_FONT;
    wxFont title = *wxSWISS_FONT;
    title.SetWeight(wxBOLD);

    m_panel->GetCal()->SetFont(normal);
    m_panel->GetCal()->SetTitleFont(title);

    wxSize best = m_panel->GetCal()->GetBestSize();
    m_panel->GetCal()->SetSize(CAL_X_COORD,CAL_Y_COORD,best.GetWidth(),best.GetHeight());
}

void MyFrame::OnSizeLarge(wxCommandEvent &event)
{
    wxFont normal(12,wxSWISS,wxNORMAL,wxBOLD,FALSE);
    wxFont title(13,wxSWISS,wxNORMAL,wxBOLD,FALSE);

    m_panel->GetCal()->SetFont(normal);
    m_panel->GetCal()->SetTitleFont(title);

    wxSize best = m_panel->GetCal()->GetBestSize();
    m_panel->GetCal()->SetSize(CAL_X_COORD,CAL_Y_COORD,best.GetWidth(),best.GetHeight());
}

// ----------------------------------------------------------------------------
// MyFrame extra goodies
// ----------------------------------------------------------------------------
/* This function exports current color selections into a disk file as ready to use wxWindows
   code so you do not have to manually copy them from color chooser dialog :-).
*/
void MyFrame::ExportColours(wxCommandEvent& event)
{
    wxString line;
    wxColour fg,bg;
    wxFFile file;

    wxString path = ::wxFileSelector(_T("Export file name"));
    if(path.IsEmpty())
        return;

    if(file.Open(path.GetData(),_T("w")))
    {
        fg = m_panel->GetCal()->GetTitleColourFg();
        bg = m_panel->GetCal()->GetTitleColourBg();
        line.Printf(_T("m_calendar->SetTitleColours(wxColour(%d,%d,%d),wxColour(%d,%d,%d));\n"),
            fg.Red(),fg.Green(),fg.Blue(),bg.Red(),bg.Green(),bg.Blue());
        file.Write(line);

        fg = m_panel->GetCal()->GetHeaderColourFg();
        bg = m_panel->GetCal()->GetHeaderColourBg();
        line.Printf(_T("m_calendar->SetHeaderColours(wxColour(%d,%d,%d),wxColour(%d,%d,%d));\n"),
            fg.Red(),fg.Green(),fg.Blue(),bg.Red(),bg.Green(),bg.Blue());
        file.Write(line);

        fg = m_panel->GetCal()->GetWeekNumberColourFg();
        bg = m_panel->GetCal()->GetWeekNumberColourBg();
        line.Printf(_T("m_calendar->SetWeekNumberColours(wxColour(%d,%d,%d),wxColour(%d,%d,%d));\n"),
            fg.Red(),fg.Green(),fg.Blue(),bg.Red(),bg.Green(),bg.Blue());
        file.Write(line);

        fg = m_panel->GetCal()->GetHighlightColourFg();
        bg = m_panel->GetCal()->GetHighlightColourBg();
        line.Printf(_T("m_calendar->SetHighlightColours(wxColour(%d,%d,%d),wxColour(%d,%d,%d));\n"),
            fg.Red(),fg.Green(),fg.Blue(),bg.Red(),bg.Green(),bg.Blue());
        file.Write(line);

        fg = m_panel->GetCal()->GetHolidayColourFg();
        bg = m_panel->GetCal()->GetHolidayColourBg();
        line.Printf(_T("m_calendar->SetHolidayColours(wxColour(%d,%d,%d),wxColour(%d,%d,%d));\n"),
            fg.Red(),fg.Green(),fg.Blue(),bg.Red(),bg.Green(),bg.Blue());
        file.Write(line);
        file.Close();
    }
    else
        wxMessageBox(_T("Unable to create export file."),"wxCalendar Sample",wxOK | wxICON_EXCLAMATION,this);
}


// ----------------------------------------------------------------------------
// MyPanel
// ----------------------------------------------------------------------------

// Couple of constants needed in positioning the color sample squares. 
const int COL_SAMPLE_SIZE = 20;
const int COL_SAMPLE_MARGIN = 5;

MyPanel::MyPanel(wxFrame *mainFrame)
       : wxPanel(mainFrame, -1)
{
    SetAutoLayout(TRUE);
    frame = mainFrame;

    // Initial positioning of the color sample titles.
    colourPosition[0].x = 5;
    colourPosition[0].y = 30;
    colourPosition[1].x = 5;
    colourPosition[1].y = 55;
    colourPosition[2].x = 5;
    colourPosition[2].y = 80;
    colourPosition[3].x = 5;
    colourPosition[3].y = 105;
    colourPosition[4].x = 5;
    colourPosition[4].y = 130;

    new wxStaticText(this, -1, _T("Title")    ,colourPosition[0]);
    new wxStaticText(this, -1, _T("Header")   ,colourPosition[1]);
    new wxStaticText(this, -1, _T("Week Nr.") ,colourPosition[2]);
    new wxStaticText(this, -1, _T("Highlight"),colourPosition[3]);
    new wxStaticText(this, -1, _T("Holiday")  ,colourPosition[4]);

    for(int i=0; i<MAX_COLOURTYPES; i++)
        colourPosition[i].x += 75;
    
    new wxStaticText(this, -1, _T("Bg"), wxPoint(80,10));
    new wxStaticText(this, -1, _T("Fg"), wxPoint(80+COL_SAMPLE_SIZE+COL_SAMPLE_MARGIN,10));

    m_calendar = new wxCalendarCtrl(this, Calendar_CalCtrl,
                                    wxDefaultDateTime,
                                    wxPoint(CAL_X_COORD,CAL_Y_COORD),
                                    wxDefaultSize,
                                    wxCAL_MONDAY_FIRST |
                                    wxCAL_SHOW_HOLIDAYS |
                                    wxRAISED_BORDER);
}

void MyPanel::OnCalendar(wxCalendarEvent& event)
{
    wxLogMessage(wxT("Selected %s from calendar"),
                 event.GetDate().FormatISODate().c_str());
}

void MyPanel::OnCalendarChange(wxCalendarEvent& event)
{
    wxString s;
    s.Printf(wxT("Selected date: %s"), event.GetDate().FormatISODate().c_str());

    frame->SetStatusText(s,1);
}

void MyPanel::OnCalMonthChange(wxCalendarEvent& WXUNUSED(event))
{
    wxLogStatus(wxT("Calendar month changed"));
}

void MyPanel::OnCalYearChange(wxCalendarEvent& WXUNUSED(event))
{
    wxLogStatus(wxT("Calendar year changed"));
}

void MyPanel::OnCalendarWeekDayClick(wxCalendarEvent& event)
{
    wxLogMessage(wxT("Clicked on %s"),
                 wxDateTime::GetWeekDayName(event.GetWeekDay()).c_str());
}

void MyPanel::ToggleCalStyle(bool on, int flag)
{
    long style = m_calendar->GetWindowStyle();
    if ( on )
        style |= flag;
    else
        style &= ~flag;

    m_calendar->SetWindowStyle(style);
    m_calendar->Refresh();
}

void MyPanel::HighlightSpecial(bool on)
{
    if ( on )
    {
        wxCalendarDateAttr
            *attrRedCircle = new wxCalendarDateAttr(wxCAL_BORDER_ROUND, *wxRED),
            *attrGreenSquare = new wxCalendarDateAttr(wxCAL_BORDER_SQUARE, *wxGREEN),
            *attrHeaderLike = new wxCalendarDateAttr(*wxBLUE, *wxLIGHT_GREY);

        m_calendar->SetAttr(17, attrRedCircle);
        m_calendar->SetAttr(29, attrGreenSquare);
        m_calendar->SetAttr(13, attrHeaderLike);
    }
    else // off
    {
        m_calendar->ResetAttr(17);
        m_calendar->ResetAttr(29);
        m_calendar->ResetAttr(13);
    }

    m_calendar->Refresh();
}

void MyPanel::OnPaint(wxPaintEvent& WXUNUSED(event))
{
    wxSize rectSize(COL_SAMPLE_SIZE,COL_SAMPLE_SIZE);

    wxPaintDC dc(this);

    // Colours for the background
    wxBrush rectBrush(m_calendar->GetTitleColourBg(),wxSOLID);dc.SetBrush(rectBrush);
    dc.DrawRectangle(colourPosition[0],rectSize);
    rectBrush.SetColour(m_calendar->GetHeaderColourBg());dc.SetBrush(rectBrush);
    dc.DrawRectangle(colourPosition[1],rectSize);
    rectBrush.SetColour(m_calendar->GetWeekNumberColourBg());dc.SetBrush(rectBrush);
    dc.DrawRectangle(colourPosition[2],rectSize);
    rectBrush.SetColour(m_calendar->GetHighlightColourBg());dc.SetBrush(rectBrush);
    dc.DrawRectangle(colourPosition[3],rectSize);
    rectBrush.SetColour(m_calendar->GetHolidayColourBg());dc.SetBrush(rectBrush);
    dc.DrawRectangle(colourPosition[4],rectSize);

    // Colours for the foreground
    for(int i=0; i<MAX_COLOURTYPES; i++)
        colourPosition[i].x += COL_SAMPLE_SIZE + COL_SAMPLE_MARGIN;

    rectBrush.SetColour(m_calendar->GetTitleColourFg());dc.SetBrush(rectBrush);
    dc.DrawRectangle(colourPosition[0],rectSize);
    rectBrush.SetColour(m_calendar->GetHeaderColourFg());dc.SetBrush(rectBrush);
    dc.DrawRectangle(colourPosition[1],rectSize);
    rectBrush.SetColour(m_calendar->GetWeekNumberColourFg());dc.SetBrush(rectBrush);
    dc.DrawRectangle(colourPosition[2],rectSize);
    rectBrush.SetColour(m_calendar->GetHighlightColourFg());dc.SetBrush(rectBrush);
    dc.DrawRectangle(colourPosition[3],rectSize);
    rectBrush.SetColour(m_calendar->GetHolidayColourFg());dc.SetBrush(rectBrush);
    dc.DrawRectangle(colourPosition[4],rectSize);

    for(int i=0; i<MAX_COLOURTYPES; i++)
        colourPosition[i].x -= COL_SAMPLE_SIZE + COL_SAMPLE_MARGIN;
}

void MyPanel::OnClick(wxMouseEvent& event)
{
    int i;
    wxColour newColour;
    wxRect sampleRect;
    sampleRect.SetWidth(COL_SAMPLE_SIZE);
    sampleRect.SetHeight(COL_SAMPLE_SIZE);

    wxPoint p = event.GetPosition();
    
    // If background column.
    if(p.x >= colourPosition[0].x && p.x <= colourPosition[0].x + COL_SAMPLE_SIZE)
    {
        sampleRect.SetX(colourPosition[0].x);
        for(i=0; i<MAX_COLOURTYPES; i++)
        {
            sampleRect.SetY(colourPosition[i].y);
            if(sampleRect.Inside(p))
                break;
        }
        if( i == MAX_COLOURTYPES)
            return;
        wxCommandEvent cmdEvent(EVT_BGCOLOR_CHANGED,0);
        cmdEvent.SetExtraLong(i);
        AddPendingEvent(cmdEvent);
        return;
    }

    // If foreground column.
    wxCoord x = colourPosition[0].x + COL_SAMPLE_SIZE + COL_SAMPLE_MARGIN;
    if(p.x >= x && p.x <= x + COL_SAMPLE_SIZE)
    {
        sampleRect.SetX(x);
        for(i=0; i<MAX_COLOURTYPES; i++)
        {
            sampleRect.SetY(colourPosition[i].y);
            if(sampleRect.Inside(p))
                break;
        }
        if( i == MAX_COLOURTYPES)
            return;
        wxCommandEvent cmdEvent(EVT_FGCOLOR_CHANGED,0);
        cmdEvent.SetExtraLong(i);
        AddPendingEvent(cmdEvent);
    }
}

void MyPanel::OnChangeFgColor(wxCommandEvent &event)
{
    wxColour newColour;

    switch(event.GetExtraLong())
    {
    case 0: // Title
        newColour = ::wxGetColourFromUser(this,m_calendar->GetTitleColourFg());
        if( newColour.Ok() )
            m_calendar->SetTitleColours(newColour,wxNullColour);
        break;
    case 1: // Header
        newColour = ::wxGetColourFromUser(this,m_calendar->GetHeaderColourFg());
        if( newColour.Ok() )
            m_calendar->SetHeaderColours(newColour,wxNullColour);
        break;
    case 2: // Week Nr
        newColour = ::wxGetColourFromUser(this,m_calendar->GetWeekNumberColourFg());
        if( newColour.Ok() )
            m_calendar->SetWeekNumberColours(newColour,wxNullColour);
        break;
    case 3: // Highlight
        newColour = ::wxGetColourFromUser(this,m_calendar->GetHighlightColourFg());
        if( newColour.Ok() )
            m_calendar->SetHighlightColours(newColour,wxNullColour);
        break;
    case 4: // Holiday
        newColour = ::wxGetColourFromUser(this,m_calendar->GetHolidayColourFg());
        if( newColour.Ok() )
            m_calendar->SetHolidayColours(newColour,wxNullColour);
        break;
    default:
        return;
    }
    m_calendar->Refresh();
    Refresh();
}

void MyPanel::OnChangeBgColor(wxCommandEvent &event)
{
    wxColour newColour;

    switch(event.GetExtraLong())
    {
    case 0: // Title
        newColour = ::wxGetColourFromUser(this,m_calendar->GetTitleColourBg());
        if( newColour.Ok() )
            m_calendar->SetTitleColours(wxNullColour,newColour);
        break;
    case 1: // Header
        newColour = ::wxGetColourFromUser(this,m_calendar->GetHeaderColourBg());
        if( newColour.Ok() )
            m_calendar->SetHeaderColours(wxNullColour,newColour);
        break;
    case 2: // Week Nr
        newColour = ::wxGetColourFromUser(this,m_calendar->GetWeekNumberColourBg());
        if( newColour.Ok() )
            m_calendar->SetWeekNumberColours(wxNullColour,newColour);
        break;
    case 3: // Highlight
        newColour = ::wxGetColourFromUser(this,m_calendar->GetHighlightColourBg());
        if( newColour.Ok() )
            m_calendar->SetHighlightColours(wxNullColour,newColour);
        break;
    case 4: // Holiday
        newColour = ::wxGetColourFromUser(this,m_calendar->GetHolidayColourBg());
        if( newColour.Ok() )
            m_calendar->SetHolidayColours(wxNullColour,newColour);
        break;
    default:
        return;
    }
    m_calendar->Refresh();
    Refresh();
}

// ----------------------------------------------------------------------------
// MyHolidays
// ----------------------------------------------------------------------------

bool MyHolidays::DoIsHoliday(const wxDateTime& dt) const
{
    wxDateTime::WeekDay wd = dt.GetWeekDay();
    return (wd == wxDateTime::Sun);
}

size_t MyHolidays::DoGetHolidaysInRange(const wxDateTime& dtStart,
                                                const wxDateTime& dtEnd,
                                                wxDateTimeArray& holidays) const
{
    if ( dtStart > dtEnd )
    {
        wxFAIL_MSG( _T("invalid date range in GetHolidaysInRange") );

        return 0u;
    }

    holidays.Empty();

    // instead of checking all days, start with the first Sat after dtStart and
    // end with the last Sun before dtEnd
    wxDateTime dtSunFirst = dtStart.GetNextWeekDay(wxDateTime::Sun),
               dtSunLast = dtEnd.GetPrevWeekDay(wxDateTime::Sun),
               dt;

    for ( dt = dtSunFirst; dt <= dtSunLast; dt += wxDateSpan::Week() )
    {
        holidays.Add(dt);
    }

    return holidays.GetCount();
}
