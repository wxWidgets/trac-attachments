///////////////////////////////////////////////////////////////////////////////
// Name:        generic/calctrl.cpp
// Purpose:     implementation fo the generic wxCalendarCtrl
// Author:      Vadim Zeitlin
// Modified by: Antti Merenluoto
// Created:     29.12.99
// RCS-ID:      $Id: calctrl.cpp,v 1.51 2003/10/16 10:27:55 VZ Exp $
// Copyright:   (c) 1999 Vadim Zeitlin <zeitlin@dptmaths.ens-cachan.fr>
// Licence:     wxWindows licence
///////////////////////////////////////////////////////////////////////////////

// ----------------------------------------------------------------------------
// headers
// ----------------------------------------------------------------------------

#if defined(__GNUG__) && !defined(NO_GCC_PRAGMA)
    #pragma implementation "calctrl.h"
#endif

// For compilers that support precompilation, includes "wx.h".
#include "wx/wxprec.h"

#ifdef __BORLANDC__
    #pragma hdrstop
#endif

#ifndef WX_PRECOMP
    #include "wx/dcclient.h"
    #include "wx/settings.h"
    #include "wx/brush.h"
    #include "wx/combobox.h"
    #include "wx/stattext.h"
    #include "wx/textctrl.h"
#endif //WX_PRECOMP

#if wxUSE_CALENDARCTRL

#include "wx/calctrl.h"

// ============================================================================
// declarations
// ============================================================================

#define DEBUG_PAINT 0

// Constants needed in sizing and drawing.
wxCoord const BORDER_WMARGIN = 4;
wxCoord const BORDER_HMARGIN = 6;
int const ARROW_OFFSET = 5;
int const ARROW_MARGIN = 3;

// Month ids for popup menu
int const MONTH_JANUARY = 100;
int const MONTH_DECEMBER = MONTH_JANUARY+wxDateTime::Dec;

// ----------------------------------------------------------------------------
// wxWin macros
// ----------------------------------------------------------------------------

BEGIN_EVENT_TABLE(wxCalendarCtrl, wxControl)
    EVT_PAINT(wxCalendarCtrl::OnPaint)

    EVT_CHAR(wxCalendarCtrl::OnChar)

    EVT_LEFT_DOWN(wxCalendarCtrl::OnClick)
    EVT_LEFT_DCLICK(wxCalendarCtrl::OnDClick)
    EVT_RIGHT_DOWN(wxCalendarCtrl::OnRightClick)

    EVT_MENU_RANGE(MONTH_JANUARY, MONTH_DECEMBER, wxCalendarCtrl::OnMonthSelect)
END_EVENT_TABLE()

#if wxUSE_EXTENDED_RTTI
WX_DEFINE_FLAGS( wxCalendarCtrlStyle )

wxBEGIN_FLAGS( wxCalendarCtrlStyle )
    // new style border flags, we put them first to
    // use them for streaming out
    wxFLAGS_MEMBER(wxBORDER_SIMPLE)
    wxFLAGS_MEMBER(wxBORDER_SUNKEN)
    wxFLAGS_MEMBER(wxBORDER_DOUBLE)
    wxFLAGS_MEMBER(wxBORDER_RAISED)
    wxFLAGS_MEMBER(wxBORDER_STATIC)
    wxFLAGS_MEMBER(wxBORDER_NONE)

    // old style border flags
    wxFLAGS_MEMBER(wxSIMPLE_BORDER)
    wxFLAGS_MEMBER(wxSUNKEN_BORDER)
    wxFLAGS_MEMBER(wxDOUBLE_BORDER)
    wxFLAGS_MEMBER(wxRAISED_BORDER)
    wxFLAGS_MEMBER(wxSTATIC_BORDER)
    wxFLAGS_MEMBER(wxBORDER)

    // standard window styles
    wxFLAGS_MEMBER(wxTAB_TRAVERSAL)
    wxFLAGS_MEMBER(wxCLIP_CHILDREN)
    wxFLAGS_MEMBER(wxTRANSPARENT_WINDOW)
    wxFLAGS_MEMBER(wxWANTS_CHARS)
    wxFLAGS_MEMBER(wxFULL_REPAINT_ON_RESIZE)
    wxFLAGS_MEMBER(wxALWAYS_SHOW_SB )
    wxFLAGS_MEMBER(wxVSCROLL)
    wxFLAGS_MEMBER(wxHSCROLL)

    wxFLAGS_MEMBER(wxCAL_SUNDAY_FIRST)
    wxFLAGS_MEMBER(wxCAL_MONDAY_FIRST)
    wxFLAGS_MEMBER(wxCAL_SHOW_HOLIDAYS)
    wxFLAGS_MEMBER(wxCAL_NO_YEAR_CHANGE)
    wxFLAGS_MEMBER(wxCAL_NO_MONTH_CHANGE)
    wxFLAGS_MEMBER(wxCAL_SEQUENTIAL_MONTH_SELECTION)
    wxFLAGS_MEMBER(wxCAL_SHOW_SURROUNDING_WEEKS)

wxEND_FLAGS( wxCalendarCtrlStyle )

IMPLEMENT_DYNAMIC_CLASS_XTI(wxCalendarCtrl, wxControl,"wx/calctrl.h")

wxBEGIN_PROPERTIES_TABLE(wxCalendarCtrl)
    wxEVENT_RANGE_PROPERTY( Updated , wxEVT_CALENDAR_SEL_CHANGED , wxEVT_CALENDAR_WEEKDAY_CLICKED , wxCalendarEvent )
    wxHIDE_PROPERTY( Children )
	wxPROPERTY( Date,wxDateTime, SetDate , GetDate, , 0 /*flags*/ , wxT("Helpstring") , wxT("group"))
    wxPROPERTY_FLAGS( WindowStyle , wxCalendarCtrlStyle , long , SetWindowStyleFlag , GetWindowStyleFlag , , 0 /*flags*/ , wxT("Helpstring") , wxT("group")) // style
wxEND_PROPERTIES_TABLE()

wxBEGIN_HANDLERS_TABLE(wxCalendarCtrl)
wxEND_HANDLERS_TABLE()

wxCONSTRUCTOR_6( wxCalendarCtrl , wxWindow* , Parent , wxWindowID , Id , wxDateTime , Date , wxPoint , Position , wxSize , Size , long , WindowStyle )
#else
IMPLEMENT_DYNAMIC_CLASS(wxCalendarCtrl, wxControl)
#endif
IMPLEMENT_DYNAMIC_CLASS(wxCalendarEvent, wxCommandEvent)

// ----------------------------------------------------------------------------
// events
// ----------------------------------------------------------------------------

DEFINE_EVENT_TYPE(wxEVT_CALENDAR_SEL_CHANGED)
DEFINE_EVENT_TYPE(wxEVT_CALENDAR_DAY_CHANGED)
DEFINE_EVENT_TYPE(wxEVT_CALENDAR_MONTH_CHANGED)
DEFINE_EVENT_TYPE(wxEVT_CALENDAR_YEAR_CHANGED)
DEFINE_EVENT_TYPE(wxEVT_CALENDAR_DOUBLECLICKED)
DEFINE_EVENT_TYPE(wxEVT_CALENDAR_WEEKDAY_CLICKED)

// ============================================================================
// implementation
// ============================================================================

wxCalendarCtrl::wxCalendarCtrl(wxWindow *parent,
                   wxWindowID id,
                   const wxDateTime& date,
                   const wxPoint& pos,
                   const wxSize& size,
                   long style,
                   const wxString& name)
{
    Init();
    (void)Create(parent, id, date, pos, size, style, name);
}

void wxCalendarCtrl::Init()
{
    m_userChangedYear = FALSE;

    m_widthCol =
    m_heightRow = 0;

    for ( size_t n = 0; n < WXSIZEOF(m_attrs); n++ )
    {
        m_attrs[n] = NULL;
    }

    m_colHighlightFg = wxSystemSettings::GetColour(wxSYS_COLOUR_HIGHLIGHTTEXT);
    m_colHighlightBg = wxSystemSettings::GetColour(wxSYS_COLOUR_HIGHLIGHT);

    m_colHolidayFg = *wxRED;
    m_colHolidayBg = *wxWHITE;

    m_colTitleFg = *wxWHITE;
    m_colTitleBg = *wxBLUE;

    m_colHeaderFg = *wxBLUE;
    m_colHeaderBg = *wxLIGHT_GREY;

    m_colWeekFg = m_colHeaderFg;
    m_colWeekBg = m_colHeaderBg;
}

bool wxCalendarCtrl::Create(wxWindow *parent,
                            wxWindowID id,
                            const wxDateTime& date,
                            const wxPoint& pos,
                            const wxSize& size,
                            long style,
                            const wxString& name)
{
    if ( !wxControl::Create(parent, id, pos, size,
                            style | wxCLIP_CHILDREN | wxWANTS_CHARS,
                            wxDefaultValidator, name) )
    {
        return FALSE;
    }

    // needed to get the arrow keys normally used for the dialog navigation
    SetWindowStyle(style | wxWANTS_CHARS);

    m_date = date.IsValid() ? date : wxDateTime::Today();

    // Set the day names now that the style is set and they are going to be needed soon for
    // size calculations.
    SetDayNames();
    SetHolidayAttrs();

    m_lowdate = wxDefaultDateTime;
    m_highdate = wxDefaultDateTime;

    if ( size.x == -1 || size.y == -1 )
    {
        wxSize sizeReal = DoGetBestSize();
        SetSize(pos.x, pos.y, sizeReal.x, sizeReal.y);
    }
    else
        RecalcGeometry( size.x, size.y );

    // we need to set the position as well because the main control position
    // is not the same as the one specified in pos if we have the controls
    // above it

    SetBackgroundColour(*wxWHITE);
    SetFont(*wxSWISS_FONT);
    m_titleFont = *wxSWISS_FONT;
    m_titleFont.SetWeight(wxBOLD);

    return TRUE;
}

wxCalendarCtrl::~wxCalendarCtrl()
{
    for ( size_t n = 0; n < WXSIZEOF(m_attrs); n++ )
    {
        delete m_attrs[n];
    }
}

void wxCalendarCtrl::SetDayNames()
{
    wxDateTime::WeekDay wd;
    for ( wd = wxDateTime::Sun; wd < wxDateTime::Inv_WeekDay; wxNextWDay(wd) )
    {
        m_weekdays[wd] = wxDateTime::GetWeekDayName(wd, wxDateTime::Name_Abbr);
        if(HasFlag(wxCAL_TWO_LETTER_WEEKDAY))
            m_weekdays[wd].Truncate(2);
    }
}

// ----------------------------------------------------------------------------
// forward wxWin functions to subcontrols
// ----------------------------------------------------------------------------

bool wxCalendarCtrl::Destroy()
{
    return wxControl::Destroy();
}

bool wxCalendarCtrl::Show(bool show)
{
    if ( !wxControl::Show(show) )
    {
        return FALSE;
    }
    return TRUE;
}

bool wxCalendarCtrl::Enable(bool enable)
{
    if ( !wxControl::Enable(enable) )
    {
        return FALSE;
    }
    return TRUE;
}

// ----------------------------------------------------------------------------
// Enable styles that need a bit setting up.
// ----------------------------------------------------------------------------

#ifdef WXWIN_COMPATIBILITY_2_4
// This is obsolete: Use SetWindowStyle-Refresh instead.
void wxCalendarCtrl::EnableYearChange(bool enable)
{
    long style = GetWindowStyle();
    if ( enable )
        style &= ~wxCAL_NO_YEAR_CHANGE;
    else
        style |= wxCAL_NO_YEAR_CHANGE;
    SetWindowStyle(style);
    Refresh();
}
// This is obsolete: Use SetWindowStyle-Refresh instead.
void wxCalendarCtrl::EnableMonthChange(bool enable)
{
    long style = GetWindowStyle();
    if ( enable )
        style &= ~wxCAL_NO_MONTH_CHANGE;
    else
        style |= wxCAL_NO_MONTH_CHANGE;
    SetWindowStyle(style);
    Refresh();
}
#endif

void wxCalendarCtrl::EnableWeekNumberDisplay(bool display)
{
    long style = GetWindowStyle();
    if ( display )
        style |= wxCAL_SHOW_WEEK_NUMBERS;
    else
        style &= ~wxCAL_SHOW_WEEK_NUMBERS;
    SetWindowStyle(style);

    int width,height;
    DoGetSize(&width,&height);
    RecalcGeometry(width,height);
    Refresh();
}

void wxCalendarCtrl::EnableShortDayName(bool enable)
{
    long style = GetWindowStyle();
    if ( enable )
        style |= wxCAL_TWO_LETTER_WEEKDAY;
    else
        style &= ~wxCAL_TWO_LETTER_WEEKDAY;
    SetWindowStyle(style);
    SetDayNames();
    Refresh();
}

void wxCalendarCtrl::NoteHolidayChange()
{
    SetHolidayAttrs();
    Refresh();
}

// ----------------------------------------------------------------------------
// changing date
// ----------------------------------------------------------------------------

bool wxCalendarCtrl::SetDate(const wxDateTime& date)
{

    bool sameMonth = m_date.GetMonth() == date.GetMonth(),
         sameYear = m_date.GetYear() == date.GetYear();

    if ( IsDateInRange(date) )
    {
        if ( sameMonth && sameYear )
        {
            // just change the day
            ChangeDay(date);
        }
        else
        {
            // change everything
            m_date = date;
            // as the month changed, holidays did too
            SetHolidayAttrs();
            // update the calendar
            Refresh();
        }
        return TRUE;
    }
    return FALSE;
}

void wxCalendarCtrl::ChangeDay(const wxDateTime& date)
{
    if ( m_date != date )
    {
        // we need to refresh the row containing the old date and the one
        // containing the new one
        wxDateTime dateOld = m_date;
        m_date = date;

        RefreshDate(dateOld);

        // if the date is in the same row, it was already drawn correctly
        if ( GetWeek(m_date) != GetWeek(dateOld) )
        {
            RefreshDate(m_date);
        }
    }
}

void wxCalendarCtrl::SetDateAndNotify(const wxDateTime& date)
{
    wxDateTime::Tm tm1 = m_date.GetTm(),
                   tm2 = date.GetTm();

    wxEventType type;
    if ( tm1.year != tm2.year )
        type = wxEVT_CALENDAR_YEAR_CHANGED;
    else if ( tm1.mon != tm2.mon )
        type = wxEVT_CALENDAR_MONTH_CHANGED;
    else if ( tm1.mday != tm2.mday )
        type = wxEVT_CALENDAR_DAY_CHANGED;
    else
        return;

    if ( SetDate(date) )
    {
        GenerateEvents(type, wxEVT_CALENDAR_SEL_CHANGED);
    }
}

// ----------------------------------------------------------------------------
// date range
// ----------------------------------------------------------------------------

bool wxCalendarCtrl::SetLowerDateLimit(const wxDateTime& date /* = wxDefaultDateTime */)
{
    bool retval = TRUE;

    if ( !(date.IsValid()) || ( ( m_highdate.IsValid() ) ? ( date <= m_highdate ) : TRUE ) )
    {
        m_lowdate = date;
    }
    else
    {
        retval = FALSE;
    }

    return retval;
}

bool wxCalendarCtrl::SetUpperDateLimit(const wxDateTime& date /* = wxDefaultDateTime */)
{
    bool retval = TRUE;

    if ( !(date.IsValid()) || ( ( m_lowdate.IsValid() ) ? ( date >= m_lowdate ) : TRUE ) )
    {
        m_highdate = date;
    }
    else
    {
        retval = FALSE;
    }

    return retval;
}

bool wxCalendarCtrl::SetDateRange(const wxDateTime& lowerdate /* = wxDefaultDateTime */, const wxDateTime& upperdate /* = wxDefaultDateTime */)
{
    bool retval = TRUE;

    if (
        ( !( lowerdate.IsValid() ) || ( ( upperdate.IsValid() ) ? ( lowerdate <= upperdate ) : TRUE ) ) &&
        ( !( upperdate.IsValid() ) || ( ( lowerdate.IsValid() ) ? ( upperdate >= lowerdate ) : TRUE ) ) )
    {
        m_lowdate = lowerdate;
        m_highdate = upperdate;
    }
    else
    {
        retval = FALSE;
    }

    return retval;
}

// ----------------------------------------------------------------------------
// date helpers
// ----------------------------------------------------------------------------

wxDateTime wxCalendarCtrl::GetStartDate() const
{
    wxDateTime::Tm tm = m_date.GetTm();

    wxDateTime date = wxDateTime(1, tm.mon, tm.year);

    // rewind back
    date.SetToPrevWeekDay(GetWindowStyle() & wxCAL_MONDAY_FIRST
                          ? wxDateTime::Mon : wxDateTime::Sun);

    if ( GetWindowStyle() & wxCAL_SHOW_SURROUNDING_WEEKS )
    {
        // We want to offset the calendar if we start on the first..
        if ( date.GetDay() == 1 )
        {
            date -= wxDateSpan::Week();
        }
    }

    return date;
}

bool wxCalendarCtrl::IsDateShown(const wxDateTime& date) const
{
    if ( !(GetWindowStyle() & wxCAL_SHOW_SURROUNDING_WEEKS) )
    {
        return date.GetMonth() == m_date.GetMonth();
    }
    else
    {
        return TRUE;
    }
}

bool wxCalendarCtrl::IsDateInRange(const wxDateTime& date) const
{
    // Check if the given date is in the range specified
    return ( ( ( m_lowdate.IsValid() ) ? ( date >= m_lowdate ) : TRUE )
        && ( ( m_highdate.IsValid() ) ? ( date <= m_highdate ) : TRUE ) );
}

bool wxCalendarCtrl::ChangeYear(wxDateTime* target) const
{
    bool retval = FALSE;

    if ( !(IsDateInRange(*target)) )
    {
        if ( target->GetYear() < m_date.GetYear() )
        {
            if ( target->GetYear() >= GetLowerDateLimit().GetYear() )
            {
                *target = GetLowerDateLimit();
                retval = TRUE;
            }
            else
            {
                *target = m_date;
            }
        }
        else
        {
            if ( target->GetYear() <= GetUpperDateLimit().GetYear() )
            {
                *target = GetUpperDateLimit();
                retval = TRUE;
            }
            else
            {
                *target = m_date;
            }
        }
    }
    else
    {
        retval = TRUE;
    }

    return retval;
}

bool wxCalendarCtrl::ChangeMonth(wxDateTime* target) const
{
    bool retval = TRUE;

    if ( !(IsDateInRange(*target)) )
    {
        retval = FALSE;

        if ( target->GetMonth() < m_date.GetMonth() )
        {
            *target = GetLowerDateLimit();
        }
        else
        {
            *target = GetUpperDateLimit();
        }
    }

    return retval;
}

size_t wxCalendarCtrl::GetWeek(const wxDateTime& date) const
{
    size_t retval = date.GetWeekOfMonth(GetWindowStyle() & wxCAL_MONDAY_FIRST
                                   ? wxDateTime::Monday_First
                                   : wxDateTime::Sunday_First);

    if ( (GetWindowStyle() & wxCAL_SHOW_SURROUNDING_WEEKS) )
    {
        // we need to offset an extra week if we "start" on the 1st of the month
        wxDateTime::Tm tm = date.GetTm();

        wxDateTime datetest = wxDateTime(1, tm.mon, tm.year);

        // rewind back
        datetest.SetToPrevWeekDay(GetWindowStyle() & wxCAL_MONDAY_FIRST
                              ? wxDateTime::Mon : wxDateTime::Sun);

        if ( datetest.GetDay() == 1 )
        {
            retval += 1;
        }
    }

    return retval;
}

// ----------------------------------------------------------------------------
// size management
// ----------------------------------------------------------------------------
wxSize wxCalendarCtrl::DoGetBestSize() const
{
    wxCoord width=0,height=0;

    wxClientDC dc((wxWindow*)this);
    dc.SetFont(m_font);

    // determine the column width (we assume that the weekday names are always
    // wider (in any language) than the numbers)
    wxDateTime::WeekDay wd;
    for ( wd = wxDateTime::Sun; wd < wxDateTime::Inv_WeekDay; wxNextWDay(wd) )
    {
        wxCoord wd_width;
        dc.GetTextExtent(m_weekdays[wd], &wd_width, &height);
        if ( wd_width > width )
        {
            width = wd_width;
        }
    }

    // leave some margins
    width += HasFlag(wxCAL_TWO_LETTER_WEEKDAY)?3:2;
    height += 2;

    if(HasFlag(wxCAL_SHOW_WEEK_NUMBERS))
        width *= 8;
    else
        width *= 7;
    height *= 8;

    if ( !HasFlag(wxBORDER_NONE) )
    {
        // the border would clip the last line otherwise
        height += BORDER_HMARGIN;
        width += BORDER_WMARGIN;
    }

    return wxSize(width, height);
}

void wxCalendarCtrl::DoSetSize(int x, int y,
                               int width, int height,
                               int sizeFlags)
{
    wxControl::DoSetSize(x, y, width, height, sizeFlags);
    if( width>0 && height > 0 )
        RecalcGeometry(width,height);
}

void wxCalendarCtrl::DoMoveWindow(int x, int y, int width, int height)
{
    wxControl::DoMoveWindow(x, y, width, height);
    if( width>0 && height > 0 )
        RecalcGeometry(width,height);
}

void wxCalendarCtrl::DoGetPosition(int *x, int *y) const
{
    wxControl::DoGetPosition(x, y);
}

void wxCalendarCtrl::DoGetSize(int *width, int *height) const
{
    wxControl::DoGetSize(width, height);
}

void wxCalendarCtrl::RecalcGeometry(int width, int height)
{
    int colCount = HasFlag(wxCAL_SHOW_WEEK_NUMBERS) ? 8 : 7;
    int borderWidth  = HasFlag(wxBORDER_NONE) ? 0 : BORDER_WMARGIN;
    int borderHeight = HasFlag(wxBORDER_NONE) ? 0 : BORDER_HMARGIN;
    m_widthCol = (width-borderWidth)/colCount;
    m_heightRow = (height-borderHeight)/8;
}

// ----------------------------------------------------------------------------
// drawing
// ----------------------------------------------------------------------------
void wxCalendarCtrl::OnPaint(wxPaintEvent& WXUNUSED(event))
{
    wxColour colFg, colBg;
    wxColour DARK_GREY(96,96,96);
    wxCoord weekOffset,y = 0;
    wxCoord monthw, monthh;
    int colCount;

    if( HasFlag(wxCAL_SHOW_WEEK_NUMBERS) )
    {
        colCount = 8;
        weekOffset = m_widthCol;
    }
    else
    {
        colCount = 7;
        weekOffset = 0;
    }
    wxPaintDC dc(this);

#if DEBUG_PAINT
    wxLogDebug("--- starting to paint, selection: %s, week %u\n",
           m_date.Format("%a %d-%m-%Y %H:%M:%S").c_str(),
           GetWeek(m_date));
#endif

    // ...............................................................
    // Set colors and rect for month name and year
    dc.SetFont(m_titleFont);

    dc.SetBackgroundMode(wxTRANSPARENT);
    dc.SetTextForeground(m_colTitleFg);
    dc.SetBrush(wxBrush(m_colTitleBg, wxSOLID));
    dc.SetPen(wxPen(m_colTitleBg, 1, wxSOLID));
    dc.DrawRectangle(0, y, GetClientSize().x, m_heightRow);

    // Get extent of month-name + year
    wxString headertext = m_date.Format(wxT("%b %Y"));
    dc.GetTextExtent(headertext, &monthw, &monthh);

    // draw month-name centered above weekdays
    wxCoord monthx = ((m_widthCol * colCount) - monthw) / 2;
    wxCoord monthy = ((m_heightRow - monthh) / 2) + y;
    dc.DrawText(headertext, monthx,  monthy);

    // ...............................................................
    // Calculate arrow coordinates
    if( AllowMonthChange() )
    {
        wxPoint leftarrow[3];
        wxPoint rightarrow[3];

        wxCoord leftOffset[3] = { ARROW_MARGIN,ARROW_MARGIN+ARROW_OFFSET, m_widthCol+ARROW_MARGIN };
        wxCoord rightOffset[3];
        rightOffset[0] = (colCount-1)*m_widthCol+ARROW_MARGIN;
        rightOffset[1] = rightOffset[0]+ARROW_OFFSET;
        rightOffset[2] = rightOffset[0]-m_widthCol+ARROW_MARGIN;

        int arrowheight = m_heightRow-4;

        leftarrow[0] = wxPoint(0, arrowheight / 2);
        leftarrow[1] = wxPoint(arrowheight / 2, 0);
        leftarrow[2] = wxPoint(arrowheight / 2, arrowheight - 1);

        rightarrow[0] = wxPoint(0, 0);
        rightarrow[1] = wxPoint(arrowheight / 2, arrowheight / 2);
        rightarrow[2] = wxPoint(0, arrowheight - 1);

        dc.SetBrush(wxBrush(m_colTitleFg, wxSOLID));
        dc.SetPen(wxPen(m_colTitleFg, 1, wxSOLID));

        // draw the arrows
        if( AllowYearChange() )
        {
            dc.DrawPolygon(3, leftarrow, leftOffset[0] , 2, wxWINDING_RULE);
            dc.DrawPolygon(3, leftarrow, leftOffset[1] , 2, wxWINDING_RULE);
            dc.DrawPolygon(3, rightarrow, rightOffset[0] , 2, wxWINDING_RULE);
            dc.DrawPolygon(3, rightarrow, rightOffset[1] , 2, wxWINDING_RULE);
            dc.DrawPolygon(3, leftarrow, leftOffset[2] , 2, wxWINDING_RULE);
            dc.DrawPolygon(3, rightarrow, rightOffset[2] , 2, wxWINDING_RULE);
        }
        else
        {
            dc.DrawPolygon(3, leftarrow, leftOffset[1] , 2, wxWINDING_RULE);
            dc.DrawPolygon(3, rightarrow, rightOffset[1] , 2, wxWINDING_RULE);
        }
    }
    // ...............................................................
    // Draw the week days

    dc.SetFont(m_font);
    dc.SetTextForeground(*wxBLACK);

    y += m_heightRow;

    if ( IsExposed(0, y, colCount*m_widthCol, m_heightRow) )
    {
#if DEBUG_PAINT
        wxLogDebug("painting the header");
#endif

        dc.SetBackgroundMode(wxTRANSPARENT);
        dc.SetTextForeground(m_colHeaderFg);
        dc.SetBrush(wxBrush(m_colHeaderBg, wxSOLID));
        dc.SetPen(wxPen(m_colHeaderBg, 1, wxSOLID));
        dc.DrawRectangle(0, y, GetClientSize().x, m_heightRow);

        wxCoord dayw, dayh;
        if ( HasFlag(wxCAL_SHOW_WEEK_NUMBERS) )
        {
            dc.GetTextExtent(wxT("#"), &dayw, &dayh);
            dc.DrawText(wxT("#"), ((m_widthCol- dayw) / 2), y);
        }

        bool startOnMonday = (GetWindowStyle() & wxCAL_MONDAY_FIRST) != 0;
        for ( size_t wd = 0; wd < 7; wd++ )
        {
            size_t n;
            if ( startOnMonday )
                n = wd == 6 ? 0 : wd + 1;
            else
                n = wd;
            dc.GetTextExtent(m_weekdays[n], &dayw, &dayh);
            dc.DrawText(m_weekdays[n], (wd*m_widthCol) + ((m_widthCol- dayw) / 2) + weekOffset, y); // center the day-name
        }
    }

    // ...............................................................
    // Draw the week number background if any
    y += m_heightRow;
    if ( HasFlag(wxCAL_SHOW_WEEK_NUMBERS) && IsExposed(0, y, m_widthCol, m_heightRow*6) )
    {
        dc.SetBrush(wxBrush(m_colWeekBg, wxSOLID));
        dc.SetPen(wxPen(m_colWeekBg, 1, wxSOLID));
        dc.DrawRectangle(0, y, m_widthCol, GetClientSize().y);
    }

    // ...............................................................
    // then the calendar itself

    wxDateTime date = GetStartDate();

#if DEBUG_PAINT
    wxLogDebug("starting calendar from %s\n",
            date.Format("%a %d-%m-%Y %H:%M:%S").c_str());
#endif

    // Create highlight and default pen and brush
    wxPen hlPen(m_backgroundColour,1,wxSOLID);
    wxBrush hlBrush(m_backgroundColour,wxSOLID);
    wxPen defPen(m_backgroundColour,1,wxSOLID);
    wxBrush defBrush(m_backgroundColour,wxSOLID);

    dc.SetTextForeground(m_foregroundColour);
    dc.SetPen(defPen);
    dc.SetBrush(defBrush);

    for ( size_t nWeek = 1; nWeek <= 6; nWeek++, y += m_heightRow )
    {
        // if the update region doesn't intersect this row, don't paint it
        if ( !IsExposed(0, y, colCount*m_widthCol, m_heightRow - 1) )
        {
            date += wxDateSpan::Week();
            continue;
        }

#if DEBUG_PAINT
        wxLogDebug("painting week %d at y = %d\n", nWeek, y);
#endif
        if( HasFlag(wxCAL_SHOW_WEEK_NUMBERS) )
        {
            wxCoord width;
            wxString weekStr;
            weekStr.Printf("%d", date.GetWeekOfYear());
            dc.GetTextExtent(weekStr, &width, (wxCoord *)NULL);
            dc.SetTextForeground(m_colWeekFg);
            dc.DrawText(weekStr, (m_widthCol - width) / 2, y + 1);
            dc.SetTextForeground(m_foregroundColour);
        }

        for ( size_t wd = 0; wd < 7; wd++ )
        {
            if ( IsDateShown(date) )
            {
                // don't use wxDate::Format() which prepends 0s
                unsigned int day = date.GetDay();
                wxString dayStr = wxString::Format(_T("%u"), day);
                wxCoord width;
                dc.GetTextExtent(dayStr, &width, (wxCoord *)NULL);

                bool changedColours = FALSE,
                     changedFont = FALSE;

                bool isSel = FALSE;
                wxCalendarDateAttr *attr = NULL;

                if ( date.GetMonth() != m_date.GetMonth() || !IsDateInRange(date) )
                {
                    // surrounding week or out-of-range
                    // draw "disabled"
                    colFg = *wxLIGHT_GREY;
                    colBg = m_backgroundColour;
                    changedColours = TRUE;
                }
                else
                {
                    isSel = date.IsSameDate(m_date);
                    attr = m_attrs[day - 1];

                    if ( isSel )
                    {
                        colFg = m_colHighlightFg;
                        colBg = m_colHighlightBg;
                        changedColours = TRUE;
                    }
                    else if ( attr )
                    {
                        if ( attr->IsHoliday() )
                        {
                            colFg = m_colHolidayFg;
                            colBg = m_colHolidayBg;
                        }
                        else
                        {
                            colFg = attr->GetTextColour();
                            colBg = attr->GetBackgroundColour();
                        }

                        if ( colFg.Ok() )
                        {
                            dc.SetTextForeground(colFg);
                            changedColours = TRUE;
                        }

                        if ( colBg.Ok() )
                        {
                            //dc.SetTextBackground(colBg);
                            changedColours = TRUE;
                        }

                        if ( attr->HasFont() )
                        {
                            dc.SetFont(attr->GetFont());
                            changedFont = TRUE;
                        }
                    }
                }
                // Draw the background as rect.
                if(changedColours)
                {
                    hlPen.SetColour(colBg);
                    hlBrush.SetColour(colBg);
                    dc.SetPen(hlPen);
                    dc.SetBrush(hlBrush);
                    dc.SetTextForeground(colFg);
                }
                wxCoord x = weekOffset + wd*m_widthCol;
                dc.DrawRectangle(x+1,y+1,m_widthCol-2,m_heightRow-2);

                // Draw the text on top (transparent background)
                x += (m_widthCol - width) / 2;
                dc.DrawText(dayStr, x, y + 1);

                if ( !isSel && attr && attr->HasBorder() )
                {
                    wxColour colBorder;
                    if ( attr->HasBorderColour() )
                    {
                        colBorder = attr->GetBorderColour();
                    }
                    else
                    {
                        colBorder = m_foregroundColour;
                    }

                    wxPen pen(colBorder, 1, wxSOLID);
                    dc.SetPen(pen);
                    dc.SetBrush(*wxTRANSPARENT_BRUSH);
                    changedColours = TRUE;

                    switch ( attr->GetBorder() )
                    {
                        case wxCAL_BORDER_SQUARE:
                            dc.DrawRectangle(x - 2, y,
                                             width + 4, m_heightRow);
                            break;

                        case wxCAL_BORDER_ROUND:
                            dc.DrawEllipse(x - 2, y,
                                           width + 4, m_heightRow);
                            break;

                        default:
                            wxFAIL_MSG(_T("unknown border type"));
                    }
                }

                if ( changedColours )
                {
                    dc.SetTextForeground(m_foregroundColour);
                    dc.SetPen(defPen);
                    dc.SetBrush(defBrush);
                }

                if ( changedFont )
                {
                    dc.SetFont(m_font);
                }
            }
            //else: just don't draw it

            date += wxDateSpan::Day();
        }
    }

    // Greying out out-of-range background
    bool showSurrounding = (GetWindowStyle() & wxCAL_SHOW_SURROUNDING_WEEKS) != 0;

    date = ( showSurrounding ) ? GetStartDate() : wxDateTime(1, m_date.GetMonth(), m_date.GetYear());
    if ( !IsDateInRange(date) )
    {
        wxDateTime firstOOR = GetLowerDateLimit() - wxDateSpan::Day(); // first out-of-range

        wxBrush oorbrush = *wxLIGHT_GREY_BRUSH;
        oorbrush.SetStyle(wxFDIAGONAL_HATCH);

        HighlightRange(&dc, date, firstOOR, wxTRANSPARENT_PEN, &oorbrush);
    }

    date = ( showSurrounding ) ? GetStartDate() + wxDateSpan::Weeks(6) - wxDateSpan::Day() : wxDateTime().SetToLastMonthDay(m_date.GetMonth(), m_date.GetYear());
    if ( !IsDateInRange(date) )
    {
        wxDateTime firstOOR = GetUpperDateLimit() + wxDateSpan::Day(); // first out-of-range

        wxBrush oorbrush = *wxLIGHT_GREY_BRUSH;
        oorbrush.SetStyle(wxFDIAGONAL_HATCH);

        HighlightRange(&dc, firstOOR, date, wxTRANSPARENT_PEN, &oorbrush);
    }

#if DEBUG_PAINT
    wxLogDebug("+++ finished painting");
#endif
}

void wxCalendarCtrl::RefreshDate(const wxDateTime& date)
{
    wxRect rect;
    int colCount = HasFlag(wxCAL_SHOW_WEEK_NUMBERS)?8:7;

    // always refresh the whole row at once because our OnPaint() will draw
    // the whole row anyhow - and this allows the small optimisation in
    // OnClick() below to work
    rect.x = 0;

    rect.y = (m_heightRow * (GetWeek(date)+1));

    rect.width = colCount*m_widthCol;
    rect.height = m_heightRow;

#ifdef __WXMSW__
    // VZ: for some reason, the selected date seems to occupy more space under
    //     MSW - this is probably some bug in the font size calculations, but I
    //     don't know where exactly. This fix is ugly and leads to more
    //     refreshes than really needed, but without it the selected days
    //     leaves even more ugly underscores on screen.
    rect.Inflate(0, 1);
#endif // MSW

#if DEBUG_PAINT
    wxLogDebug("*** refreshing week %d at (%d, %d)-(%d, %d)\n",
           GetWeek(date),
           rect.x, rect.y,
           rect.x + rect.width, rect.y + rect.height);
#endif

    Refresh(TRUE, &rect);
}

void wxCalendarCtrl::HighlightRange(wxPaintDC* pDC, const wxDateTime& fromdate, const wxDateTime& todate, wxPen* pPen, wxBrush* pBrush)
{
    // Highlights the given range using pen and brush
    // Does nothing if todate < fromdate


#if DEBUG_PAINT
    wxLogDebug("+++ HighlightRange: (%s) - (%s) +++", fromdate.Format("%d %m %Y"), todate.Format("%d %m %Y"));
#endif

    if ( todate >= fromdate )
    {
        // do stuff
        // date-coordinates
        int fd, fw;
        int td, tw;

        // implicit: both dates must be currently shown - checked by GetDateCoord
        if ( GetDateCoord(fromdate, &fd, &fw) && GetDateCoord(todate, &td, &tw) )
        {
#if DEBUG_PAINT
            wxLogDebug("Highlight range: (%i, %i) - (%i, %i)", fd, fw, td, tw);
#endif
            if ( ( (tw - fw) == 1 ) && ( td < fd ) )
            {
                // special case: interval 7 days or less not in same week
                // split in two seperate intervals
                wxDateTime tfd = fromdate + wxDateSpan::Days(7-fd);
                wxDateTime ftd = tfd + wxDateSpan::Day();
#if DEBUG_PAINT
                wxLogDebug("Highlight: Seperate segments");
#endif
                // draw seperately
                HighlightRange(pDC, fromdate, tfd, pPen, pBrush);
                HighlightRange(pDC, ftd, todate, pPen, pBrush);
            }
            else
            {
                int numpoints;
                wxPoint corners[8]; // potentially 8 corners in polygon

                if ( fw == tw )
                {
                    // simple case: same week
                    numpoints = 4;
                    corners[0] = wxPoint((fd - 1) * m_widthCol, (fw * m_heightRow));
                    corners[1] = wxPoint((fd - 1) * m_widthCol, ((fw + 1 ) * m_heightRow));
                    corners[2] = wxPoint(td * m_widthCol, ((tw + 1) * m_heightRow));
                    corners[3] = wxPoint(td * m_widthCol, (tw * m_heightRow));
                }
                else
                {
                    int cidx = 0;
                    // "complex" polygon
                    corners[cidx] = wxPoint((fd - 1) * m_widthCol, (fw * m_heightRow)); cidx++;

                    if ( fd > 1 )
                    {
                        corners[cidx] = wxPoint((fd - 1) * m_widthCol, ((fw + 1) * m_heightRow)); cidx++;
                        corners[cidx] = wxPoint(0, ((fw + 1) * m_heightRow)); cidx++;
                    }

                    corners[cidx] = wxPoint(0, ((tw + 1) * m_heightRow)); cidx++;
                    corners[cidx] = wxPoint(td * m_widthCol, ((tw + 1) * m_heightRow)); cidx++;

                    if ( td < 7 )
                    {
                        corners[cidx] = wxPoint(td * m_widthCol, (tw * m_heightRow)); cidx++;
                        corners[cidx] = wxPoint(7 * m_widthCol, (tw * m_heightRow)); cidx++;
                    }

                    corners[cidx] = wxPoint(7 * m_widthCol, (fw * m_heightRow)); cidx++;

                    numpoints = cidx;
                }

                // draw the polygon
                pDC->SetBrush(*pBrush);
                pDC->SetPen(*pPen);
                pDC->DrawPolygon(numpoints, corners);
            }
        }
    }
    // else do nothing
#if DEBUG_PAINT
    wxLogDebug("--- HighlightRange ---");
#endif
}

bool wxCalendarCtrl::GetDateCoord(const wxDateTime& date, int *day, int *week) const
{
    bool retval = TRUE;

#if DEBUG_PAINT
    wxLogDebug("+++ GetDateCoord: (%s) +++", date.Format("%d %m %Y"));
#endif

    if ( IsDateShown(date) )
    {
        bool startOnMonday = ( GetWindowStyle() & wxCAL_MONDAY_FIRST ) != 0;

        // Find day
        *day = date.GetWeekDay();

        if ( *day == 0 ) // sunday
        {
            *day = ( startOnMonday ) ? 7 : 1;
        }
        else
        {
            day += ( startOnMonday ) ? 0 : 1;
        }

        int targetmonth = date.GetMonth() + (12 * date.GetYear());
        int thismonth = m_date.GetMonth() + (12 * m_date.GetYear());

        // Find week
        if ( targetmonth == thismonth )
        {
            *week = GetWeek(date);
        }
        else
        {
            if ( targetmonth < thismonth )
            {
                *week = 1; // trivial
            }
            else // targetmonth > thismonth
            {
                wxDateTime ldcm;
                int lastweek;
                int lastday;

                // get the datecoord of the last day in the month currently shown
#if DEBUG_PAINT
                wxLogDebug("     +++ LDOM +++");
#endif
                GetDateCoord(ldcm.SetToLastMonthDay(m_date.GetMonth(), m_date.GetYear()), &lastday, &lastweek);
#if DEBUG_PAINT
                wxLogDebug("     --- LDOM ---");
#endif

                wxTimeSpan span = date - ldcm;

                int daysfromlast = span.GetDays();
#if DEBUG_PAINT
                wxLogDebug("daysfromlast: %i", daysfromlast);
#endif
                if ( daysfromlast + lastday > 7 ) // past week boundary
                {
                    int wholeweeks = (daysfromlast / 7);
                    *week = wholeweeks + lastweek;
                    if ( (daysfromlast - (7 * wholeweeks) + lastday) > 7 )
                    {
                        *week += 1;
                    }
                }
                else
                {
                    *week = lastweek;
                }
            }
        }
    }
    else
    {
        *day = -1;
        *week = -1;
        retval = FALSE;
    }

#if DEBUG_PAINT
    wxLogDebug("--- GetDateCoord: (%s) = (%i, %i) ---", date.Format("%d %m %Y"), *day, *week);
#endif

    return retval;
}

// ----------------------------------------------------------------------------
// mouse handling
// ----------------------------------------------------------------------------

void wxCalendarCtrl::OnDClick(wxMouseEvent& event)
{
    if ( HitTest(event.GetPosition()) != wxCAL_HITTEST_DAY )
    {
        event.Skip();
    }
    else
    {
        GenerateEvent(wxEVT_CALENDAR_DOUBLECLICKED);
    }
}

void wxCalendarCtrl::OnClick(wxMouseEvent& event)
{
    wxDateTime date;
    wxDateTime::WeekDay wday;
    switch ( HitTest(event.GetPosition(), &date, &wday) )
    {
        case wxCAL_HITTEST_DAY:
            if ( IsDateInRange(date) )
            {
                ChangeDay(date);

                GenerateEvents(wxEVT_CALENDAR_DAY_CHANGED,
                               wxEVT_CALENDAR_SEL_CHANGED);
            }
            break;

        case wxCAL_HITTEST_HEADER:
            {
                wxCalendarEvent event(this, wxEVT_CALENDAR_WEEKDAY_CLICKED);
                event.m_wday = wday;
                (void)GetEventHandler()->ProcessEvent(event);
            }
            break;

        case wxCAL_HITTEST_DECMONTH:
        case wxCAL_HITTEST_INCMONTH:
        case wxCAL_HITTEST_INCYEAR:
        case wxCAL_HITTEST_DECYEAR:
        case wxCAL_HITTEST_SURROUNDING_WEEK:
            SetDateAndNotify(date); // we probably only want to refresh the control. No notification.. (maybe as an option?)
            break;

        default:
            wxFAIL_MSG(_T("unknown hittest code"));
            // fall through

        case wxCAL_HITTEST_NOWHERE:
            event.Skip();
            break;
    }
}

void wxCalendarCtrl::OnRightClick(wxMouseEvent& event)
{
    // We are only interested if the click hit the title bar.
    if ( AllowMonthChange() && event.GetPosition().y < m_heightRow)
    {
        // Show the month pop-up menu.
        wxMenu popup(_T(""));
        for(wxDateTime::Month m = wxDateTime::Jan; m<=wxDateTime::Dec; wxNextMonth(m))
        {
            popup.Append(MONTH_JANUARY+m, wxDateTime::GetMonthName(m));
        }
        PopupMenu(&popup,event.GetPosition().x+5,event.GetPosition().y);
    }
}

// This function is called if user selects any of the pop up months.
void wxCalendarCtrl::OnMonthSelect(wxCommandEvent& event)
{
    wxDateTime date = m_date;
    date.SetMonth(static_cast<wxDateTime::Month>(event.GetId()-MONTH_JANUARY));
    SetDateAndNotify(date);
}

void wxCalendarCtrl::DecrimentDate(wxDateTime *date, const wxDateSpan span)
{
    if ( IsDateInRange(m_date - span) )
    {
        *date = m_date - span;
    }
    else
    {
        *date = GetLowerDateLimit();
    }
}

void wxCalendarCtrl::IncrementDate(wxDateTime *date, const wxDateSpan span)
{
    if ( IsDateInRange(m_date + span ) )
    {
        *date = m_date + span;
    }
    else
    {
        *date = GetUpperDateLimit();
    }
}

wxCalendarHitTestResult wxCalendarCtrl::HitTest(const wxPoint& pos,
                                                wxDateTime *date,
                                                wxDateTime::WeekDay *wd)
{
    int colCount = HasFlag(wxCAL_SHOW_WEEK_NUMBERS)?8:7;
    wxCoord y = pos.y;

    // ...............................................................
    // Month - Year row
    if ( y < m_heightRow)
    {
        bool allowYear = AllowYearChange();
        bool allowMonth = AllowMonthChange();
        if( !allowMonth )
            return wxCAL_HITTEST_NOWHERE;

        if( pos.x < m_widthCol )
        {
            if(allowYear)
            {
                if(date)
                    DecrimentDate(date,wxDateSpan::Year());
                return wxCAL_HITTEST_DECYEAR;
            }
            if(date)
                DecrimentDate(date,wxDateSpan::Month());
            return wxCAL_HITTEST_DECMONTH;
        }
        if( pos.x > m_widthCol*(colCount-1) )
        {
            if(allowYear)
            {
                if(date)
                    IncrementDate(date,wxDateSpan::Year());
                return wxCAL_HITTEST_INCYEAR;
            }
            if(date)
                IncrementDate(date,wxDateSpan::Month());
            return wxCAL_HITTEST_INCMONTH;
        }

        // Header: month
        if( allowMonth )
        {
            if( pos.x >= m_widthCol && pos.x < m_widthCol*2 )
            {
                if(date)
                    DecrimentDate(date,wxDateSpan::Month());
                return wxCAL_HITTEST_DECMONTH;
            }
            if( pos.x > m_widthCol*(colCount-2) && pos.x < m_widthCol*(colCount-1) )
            {
                if(date)
                    IncrementDate(date,wxDateSpan::Month());
                return wxCAL_HITTEST_INCMONTH;
            }
        }
        return wxCAL_HITTEST_NOWHERE;
    }

    // ...............................................................
    // Row of week day names

    if ( HasFlag(wxCAL_SHOW_WEEK_NUMBERS) && pos.x < m_widthCol )
        return wxCAL_HITTEST_NOWHERE;

    int wday = HasFlag(wxCAL_SHOW_WEEK_NUMBERS) ? ((pos.x - m_widthCol) / m_widthCol) : pos.x / m_widthCol;

    if ( y < m_heightRow * 2 )
    {
        if ( wd )
        {
            if ( GetWindowStyle() & wxCAL_MONDAY_FIRST )
            {
                wday = wday == 6 ? 0 : wday + 1;
            }

            *wd = (wxDateTime::WeekDay)wday;
        }
        return wxCAL_HITTEST_HEADER;
    }

    // ...............................................................
    // Day numbers
    int week = (y - (m_heightRow * 2)) / m_heightRow;
    if ( week >= 6 || wday >= 7 )
    {
        return wxCAL_HITTEST_NOWHERE;
    }

    wxDateTime dt = GetStartDate() + wxDateSpan::Days(7*week + wday);

    if ( IsDateShown(dt) )
    {
        if ( date )
            *date = dt;

        if ( dt.GetMonth() == m_date.GetMonth() )
        {

            return wxCAL_HITTEST_DAY;
        }
        else
        {
            return wxCAL_HITTEST_SURROUNDING_WEEK;
        }
    }
    else
    {
        return wxCAL_HITTEST_NOWHERE;
    }
}

// ----------------------------------------------------------------------------
// keyboard interface
// ----------------------------------------------------------------------------

void wxCalendarCtrl::OnChar(wxKeyEvent& event)
{
    wxDateTime target;
    switch ( event.GetKeyCode() )
    {
        case _T('+'):
        case WXK_ADD:
            target = m_date + wxDateSpan::Year();
            if ( ChangeYear(&target) )
            {
                SetDateAndNotify(target);
            }
            break;

        case _T('-'):
        case WXK_SUBTRACT:
            target = m_date - wxDateSpan::Year();
            if ( ChangeYear(&target) )
            {
                SetDateAndNotify(target);
            }
            break;

        case WXK_PRIOR:
            target = m_date - wxDateSpan::Month();
            ChangeMonth(&target);
            SetDateAndNotify(target); // always
            break;

        case WXK_NEXT:
            target = m_date + wxDateSpan::Month();
            ChangeMonth(&target);
            SetDateAndNotify(target); // always
            break;

        case WXK_RIGHT:
            if ( event.ControlDown() )
            {
                target = wxDateTime(m_date).SetToNextWeekDay(
                                 GetWindowStyle() & wxCAL_MONDAY_FIRST
                                 ? wxDateTime::Sun : wxDateTime::Sat);
                if ( !IsDateInRange(target) )
                {
                    target = GetUpperDateLimit();
                }
                SetDateAndNotify(target);
            }
            else
                SetDateAndNotify(m_date + wxDateSpan::Day());
            break;

        case WXK_LEFT:
            if ( event.ControlDown() )
            {
                target = wxDateTime(m_date).SetToPrevWeekDay(
                                 GetWindowStyle() & wxCAL_MONDAY_FIRST
                                 ? wxDateTime::Mon : wxDateTime::Sun);
                if ( !IsDateInRange(target) )
                {
                    target = GetLowerDateLimit();
                }
                SetDateAndNotify(target);
            }
            else
                SetDateAndNotify(m_date - wxDateSpan::Day());
            break;

        case WXK_UP:
            SetDateAndNotify(m_date - wxDateSpan::Week());
            break;

        case WXK_DOWN:
            SetDateAndNotify(m_date + wxDateSpan::Week());
            break;

        case WXK_HOME:
            if ( event.ControlDown() )
                SetDateAndNotify(wxDateTime::Today());
            else
                SetDateAndNotify(wxDateTime(1, m_date.GetMonth(), m_date.GetYear()));
            break;

        case WXK_END:
            SetDateAndNotify(wxDateTime(m_date).SetToLastMonthDay());
            break;

        case WXK_RETURN:
            GenerateEvent(wxEVT_CALENDAR_DOUBLECLICKED);
            break;

        default:
            event.Skip();
    }
}

// ----------------------------------------------------------------------------
// holidays handling
// ----------------------------------------------------------------------------

void wxCalendarCtrl::EnableHolidayDisplay(bool display)
{
    long style = GetWindowStyle();
    if ( display )
        style |= wxCAL_SHOW_HOLIDAYS;
    else
        style &= ~wxCAL_SHOW_HOLIDAYS;

    SetWindowStyle(style);

    if ( display )
        SetHolidayAttrs();
    else
        ResetHolidayAttrs();

    Refresh();
}

void wxCalendarCtrl::SetHolidayAttrs()
{
    if ( GetWindowStyle() & wxCAL_SHOW_HOLIDAYS )
    {
        ResetHolidayAttrs();

        wxDateTime::Tm tm = m_date.GetTm();
        wxDateTime dtStart(1, tm.mon, tm.year),
                   dtEnd = dtStart.GetLastMonthDay();

        wxDateTimeArray hol;
        wxDateTimeHolidayAuthority::GetHolidaysInRange(dtStart, dtEnd, hol);

        size_t count = hol.GetCount();
        for ( size_t n = 0; n < count; n++ )
        {
            SetHoliday(hol[n].GetDay());
        }
    }
}

void wxCalendarCtrl::SetHoliday(size_t day)
{
    wxCHECK_RET( day > 0 && day < 32, _T("invalid day in SetHoliday") );

    wxCalendarDateAttr *attr = GetAttr(day);
    if ( !attr )
    {
        attr = new wxCalendarDateAttr;
    }

    attr->SetHoliday(TRUE);

    // can't use SetAttr() because it would delete this pointer
    m_attrs[day - 1] = attr;
}

void wxCalendarCtrl::ResetHolidayAttrs()
{
    for ( size_t day = 0; day < 31; day++ )
    {
        if ( m_attrs[day] )
        {
            m_attrs[day]->SetHoliday(FALSE);
        }
    }
}

// ----------------------------------------------------------------------------
// wxCalendarEvent
// ----------------------------------------------------------------------------

void wxCalendarEvent::Init()
{
    m_wday = wxDateTime::Inv_WeekDay;
}

wxCalendarEvent::wxCalendarEvent(wxCalendarCtrl *cal, wxEventType type)
               : wxCommandEvent(type, cal->GetId())
{
    m_date = cal->GetDate();
    SetEventObject(cal);
}

#endif // wxUSE_CALENDARCTRL

