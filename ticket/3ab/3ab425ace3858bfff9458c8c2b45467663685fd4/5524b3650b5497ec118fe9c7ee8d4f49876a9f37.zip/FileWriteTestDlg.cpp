//---------------------------------------------------------------------------
//
// Name:        FileWriteTestDlg.cpp
// Author:      jeff
// Created:     5/26/2009 10:06:03 AM
// Description: FileWriteTestDlg class implementation
//
//---------------------------------------------------------------------------

#include "FileWriteTestDlg.h"

//Do not add custom headers
//wxDev-C++ designer will remove them
////Header Include Start
////Header Include End

//----------------------------------------------------------------------------
// FileWriteTestDlg
//----------------------------------------------------------------------------
//Add Custom Events only in the appropriate block.
//Code added in other places will be removed by wxDev-C++
////Event Table Start
BEGIN_EVENT_TABLE(FileWriteTestDlg,wxDialog)
	////Manual Code Start
	////Manual Code End
	
	EVT_CLOSE(FileWriteTestDlg::OnClose)
	EVT_BUTTON(ID_WXBUTTON1,FileWriteTestDlg::WxButton1Click)
END_EVENT_TABLE()
////Event Table End

FileWriteTestDlg::FileWriteTestDlg(wxWindow *parent, wxWindowID id, const wxString &title, const wxPoint &position, const wxSize& size, long style)
: wxDialog(parent, id, title, position, size, style)
{
	CreateGUIControls();
}

FileWriteTestDlg::~FileWriteTestDlg()
{
} 

void FileWriteTestDlg::CreateGUIControls()
{
	//Do not add custom code between
	//GUI Items Creation Start and GUI Items Creation End.
	//wxDev-C++ designer will remove them.
	//Add the custom code before or after the blocks
	////GUI Items Creation Start

	WxMemo1 = new wxTextCtrl(this, ID_WXMEMO1, wxT("WxMemo1"), wxPoint(42, 95), wxSize(242, 89), wxTE_MULTILINE, wxDefaultValidator, wxT("WxMemo1"));
	WxMemo1->SetMaxLength(0);
	WxMemo1->AppendText(wxT("WxMemo1"));
	WxMemo1->SetFocus();
	WxMemo1->SetInsertionPointEnd();

	WxEdit1 = new wxTextCtrl(this, ID_WXEDIT1, wxT("OutputFile.bin"), wxPoint(97, 33), wxSize(121, 19), 0, wxDefaultValidator, wxT("WxEdit1"));

	WxTimer1 = new wxTimer();
	WxTimer1->SetOwner(this, ID_WXTIMER1);

	WxButton1 = new wxButton(this, ID_WXBUTTON1, wxT("Write File"), wxPoint(42, 60), wxSize(75, 25), 0, wxDefaultValidator, wxT("WxButton1"));

	WxStaticText1 = new wxStaticText(this, ID_WXSTATICTEXT1, wxT("File Name"), wxPoint(43, 30), wxDefaultSize, 0, wxT("WxStaticText1"));

	SetTitle(wxT("FileWriteTest"));
	SetIcon(wxNullIcon);
	SetSize(8,8,352,262);
	Center();
	
	////GUI Items Creation End
}

void FileWriteTestDlg::OnClose(wxCloseEvent& /*event*/)
{
	Destroy();
}

/*
 * WxButton1Click
 */
void FileWriteTestDlg::WxButton1Click(wxCommandEvent& event)
{
	// insert your code here
	
	
	
}
