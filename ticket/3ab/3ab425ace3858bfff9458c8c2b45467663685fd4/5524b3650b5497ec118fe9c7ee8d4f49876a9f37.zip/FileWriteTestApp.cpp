//---------------------------------------------------------------------------
//
// Name:        FileWriteTestApp.cpp
// Author:      jeff
// Created:     5/26/2009 10:06:03 AM
// Description: 
//
//---------------------------------------------------------------------------

#include "FileWriteTestApp.h"
#include "FileWriteTestDlg.h"

IMPLEMENT_APP(FileWriteTestDlgApp)

bool FileWriteTestDlgApp::OnInit()
{
	FileWriteTestDlg* dialog = new FileWriteTestDlg(NULL);
	SetTopWindow(dialog);
	dialog->Show(true);		
	return true;
}
 
int FileWriteTestDlgApp::OnExit()
{
	return 0;
}
