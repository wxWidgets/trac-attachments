#include "Frame.h"

#include <wx/textdlg.h>

//helper functions
enum wxbuildinfoformat {short_f, long_f };
wxString wxbuildinfo(wxbuildinfoformat format)
{
    wxString wxbuild(wxVERSION_STRING);

    if (format == long_f )
    {
#if defined(__WXMSW__)
        wxbuild << _T("-Windows");
#elif defined(__UNIX__)
        wxbuild << _T("-Linux");
#endif

#if wxUSE_UNICODE
        wxbuild << _T("-unicode build");
#else
        wxbuild << _T("-ANSI build");
#endif // wxUSE_UNICODE
    }

    return wxbuild;
}

// wxEvent Table 
BEGIN_EVENT_TABLE(MyFrame, wxFrame)
    EVT_MENU(ID_QUIT			, MyFrame::OnQuit)
    EVT_MENU(ID_ABOUT			, MyFrame::OnAbout)
END_EVENT_TABLE()


MyFrame::MyFrame(wxFrame *frame, const wxString& title)
    	:wxFrame(frame, -1, title)
{

	// set up the menu bar
	vSetUpMenuBar();

	// set up the status bar
	vSetUpStatusBar();
	
	// create a panel to place all the controls
	m_pPanel  	= new wxPanel(this, wxID_ANY, wxPoint(0,0), wxSize(600,600)); 


	m_pCalendarCtrl = new wxCalendarCtrl(m_pPanel, wxID_ANY, wxDefaultDateTime, wxPoint(10,10));
				m_pCalendarCtrl->SetFont(wxFont(8, wxSWISS, wxNORMAL,wxNORMAL, false, wxT("Tahoma")));



	// set the window size
	this->SetSize(300,250);
							
}

MyFrame::~MyFrame(){}





void MyFrame::OnQuit(wxCommandEvent& WXUNUSED(event))
{
    Close();
}

void MyFrame::OnAbout(wxCommandEvent& WXUNUSED(event))
{

 
 	wxAboutDialogInfo AboutDialogInfo;
	AboutDialogInfo.AddDeveloper(wxT("Ettl Martin Dipl. Inf (FH)\nTechnical University of Munich\nResearch Department Satellite Geodesy\n-Fundamentalstation Wettzell -\nSackenrieder Str.25\nD-93444 Bad Koetzting\nEmail:ettl@fs.wettzell.de\n "));
	AboutDialogInfo.SetDescription(wxT("wxTemplate Demo\nby\nEttl Martin"));
	AboutDialogInfo.SetName(wxT("wxTemplateDemo"));
	AboutDialogInfo.SetVersion(wxT("v17.03.2009"));
 
 	wxAboutBox(AboutDialogInfo);

}

void MyFrame::vSetUpMenuBar(void)
{
#if wxUSE_MENUS
	
    m_pMenubar = new wxMenuBar();

	// set up the file menu
    m_pFileMenu = new wxMenu(_T(""));
    m_pFileMenu->Append(ID_QUIT, "&Quit\tAlt-F4" , _("Quit the application"));
    m_pMenubar->Append(m_pFileMenu, _("&File"));

	// set up the help menu
    m_pHelpMenu = new wxMenu(_T(""));
    m_pHelpMenu->Append(ID_ABOUT, _("&About\tF1"), _("Show info about this application"));
    m_pMenubar->Append(m_pHelpMenu, _("&Help"));

	// realize the menu( send it to the window)
    SetMenuBar(m_pMenubar);
	
#endif // wxUSE_MENUS


}

void MyFrame::vSetUpStatusBar(void)
{

	#if wxUSE_STATUSBAR
    // create a status bar with some information about the used wxWidgets version
    CreateStatusBar(2);
    SetStatusText(_("Hello user !"),0);
    SetStatusText(wxbuildinfo(short_f),1);
	#endif // wxUSE_STATUSBAR	

	return;		
}





// *************************************************************************
// * END OF FILE (CVS Concurrent Version Control)
// * -----------------------------------------------------------------------
// * $RCSfile: $
// * $Revision: $
// *************************************************************************


