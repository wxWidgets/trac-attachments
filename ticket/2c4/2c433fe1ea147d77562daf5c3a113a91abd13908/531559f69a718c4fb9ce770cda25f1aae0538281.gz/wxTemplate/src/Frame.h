
/*  
*******************************************************************
* CVS Concurrent Versions Control
* ----------------------------------------------------------------
* $RCSfile: Frame.h $
* $Revision:$  
* ----------------------------------------------------------------
* $Author: Ettl Martin$
* $Date: $
* $Locker: $
* ----------------------------------------------------------------
* $Log:$
******************************************************************
*/
/*! \file
*   \brief This is the defintion of Class Frame. This class
*			is the 'main' frame of the wxLED demo application.\n
*
*
******************************************************************
*	Used precompiler definitions: 	<br>
*	Used namespaces: standard		<br>
*	Used exeption-handles:			<br>
*
*
*
******************************************************************/

#ifndef MAIN_H
#define MAIN_H

#include <wx/wx.h>
// wx Includes
#include <wx/button.h>
#include <wx/textctrl.h>
#include <wx/notebook.h>
#include <wx/aboutdlg.h>
#include <wx/calctrl.h>

class MyFrame: public wxFrame
{
	enum wxIDs
	{
		 ID_ABOUT = wxID_HIGHEST
		,ID_QUIT
	};	
	public:

		MyFrame(wxFrame *frame, const wxString& title);
		~MyFrame();
	
	private:
	
		// Event Handler
		void OnQuit(wxCommandEvent& event);
		void OnAbout(wxCommandEvent& event);

		void vSetUpMenuBar(void);
		void vSetUpStatusBar(void);

		wxPanel 	*m_pPanel;

		// menu bar stuff
		wxMenuBar	*m_pMenubar ;
		wxMenu	 	*m_pFileMenu;
		wxMenu		*m_pHelpMenu;
		wxCalendarCtrl *m_pCalendarCtrl;		

		DECLARE_EVENT_TABLE()
};




#endif // MAIN_H

// *************************************************************************
// * END OF FILE (CVS Concurrent Version Control)
// * -----------------------------------------------------------------------
// * $RCSfile: $
// * $Revision: $
// *************************************************************************


