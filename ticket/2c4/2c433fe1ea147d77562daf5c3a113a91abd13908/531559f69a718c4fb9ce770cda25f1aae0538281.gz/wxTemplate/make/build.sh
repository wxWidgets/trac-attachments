make -j3 -f Makefile
