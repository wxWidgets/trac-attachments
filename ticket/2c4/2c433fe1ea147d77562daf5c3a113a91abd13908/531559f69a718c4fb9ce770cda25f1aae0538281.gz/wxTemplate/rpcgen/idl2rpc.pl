#!/usr/bin/perl -w
#====================================================================================
# idl2rpc.pl
# ------------
#***********************************************************************
#* CVS Concurrent Versions Control
#* ---------------------------------------------------------------------
#* $RCSfile: idl2rpc.pl,v $ 
#* $Revision: 1.34 $
#* ---------------------------------------------------------------------
#* $Author: neidh $
#* $Date: 2009/01/30 18:09:26 $            
#* $Locker:  $
#* ---------------------------------------------------------------------
#* $Log: idl2rpc.pl,v $
#* Revision 1.34  2009/01/30 18:09:26  neidh
#* BugFix: Down compatibility with version 2008-09-03 and
#* lower where the functions are without "_" so that the
#* method bodies are not destroyed
#*
#*
#*
#***********************************************************************/
#*! \file
#*  \brief Interface generator which converts an interface dfined with
#*         a special interface definition language into C/C++ Code
#*         which includes the build interface <br>
#*
#* Usage (idl2rpc):
#* ======
#* 
#* idl2rpc.pl ([-SLT <sec>/<usec>] |  --> Server loop timeout for periodic activities
#*             [-TLT <sec>/<usec>])   --> Server loop timeout for periodic activities using threads
#*            [-CT <sec>/<usec>]      --> Client request timeout for each request
#*            [-CRT <sec>/<usec>]     --> Client retry timeout after a request retry is started
#*            [-TCP|-UDP]             --> Mainly used transportprotocol
#*            [-PCL <number>]         --> Program classification code >= 600 and <= 1070, standard is 700
#*            [-CL]                   --> Create only client
#*            <IDL-filepath>.idl      --> IDL-filepath
#***********************************************************************
#*         Used precompiler definitions: - <br>
#*         Used namespaces:              - <br>
#*         Used exeption-handles:        - <br>
#***********************************************************************
#* Licence and warranty:
#* =====================
#* Copyright (C) 2008 A. Neidhardt
#*                    Forschungseinrichtung Satellitengeodaesie, TU Muenchen &
#*                    Bundesamt fuer Kartographie und Geodaesie
#*                    Geodetic Observatory Wettzell
#*                    Sackenrieder Str. 25
#*                    D-93444 Bad Koetzting
#* 
#* This program is free software: you can redistribute it and/or modify
#* it as long as you inform the original author/ publishing company. All
#* modifications should be registrated there, to offer them also to the other
#* users. The usage of this software and all generated code lines are only permitted
#* for non-commercial needs. In each publication and usage the copyright holder has 
#* to be mentioned. For further information contact the copyright holder.
#* 
#* This program is distributed in the hope that it will be useful,
#* but WITHOUT ANY WARRANTY; without even the implied warranty of
#* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
#* 
#***********************************************************************

use Cwd;
use strict;

my $g_VersionDate = "2009-03-05-001";
# BugFix: Free structuring of IDL-file token
# AddOn: Allow negative constants
# AddOn: Automatic safety device (-ASD)
# AddOn: Print version information -V
# BugFix: Calling parameter without IDL-File throw error now
# AddOn: double �Interface�_client::_dGetRoundTripDataRateNormalized (unsigned int uiPackageSizeInByte)
# BugFix: wrong if-statement in _proc.cpp when filling IN-structure of dyn. arrays
# AddOn: Reduce unused variable warnings

my $g_CVSHead = "/***********************************************************************\
 * CVS Concurrent Versions Control\
 * ---------------------------------------------------------------------\
 * \$"."RCSfile:  \$ \
 * \$"."Revision:  \$\
 * ---------------------------------------------------------------------\
 * \$"."Author:  \$\
 * \$"."Date:  \$\
 * \$"."Locker:  \$\
 * ---------------------------------------------------------------------\
 * \$"."Log:  \$\
 *\
 *\
";
my $g_LicenseHead = " ***********************************************************************\
 * Licence and warranty:\
 * =====================\
 * Version ".$g_VersionDate."\
 * Copyright (C) 2008 A. Neidhardt\
 *                    Forschungseinrichtung Satellitengeodaesie, TU Muenchen &\
 *                    Bundesamt fuer Kartographie und Geodaesie\
 *                    Geodetic Observatory Wettzell\
 *                    Sackenrieder Str. 25\
 *                    D-93444 Bad Koetzting\
 * \
 * This program is free software: you can redistribute it and/or modify\
 * it as long as you inform the original author/ publishing company. All\
 * modifications should be registrated there, to offer them also to the other\
 * users. The usage of this software and all generated code lines are only permitted\
 * for non-commercial needs. In each publication and usage the copyright holder has \
 * to be mentioned. For further information contact the copyright holder.\
 * \
 * This program is distributed in the hope that it will be useful,\
 * but WITHOUT ANY WARRANTY; without even the implied warranty of\
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.\
 ***********************************************************************/
\
";

my $g_FileHead = $g_CVSHead.$g_LicenseHead;

my $g_InterfaceClassDeclarationTemplate = "/***********************************************************************/\
/*! \\file �ModulFilename�\
 *  \\brief Interface code file defined at �InterfaceFilenameWithoutExt�.idl and generated by idl2rpc.pl<br>\
 ***********************************************************************/
 \
 ".
$g_FileHead.
"#ifndef __�InterfaceFilenameWithoutExt�_INTERFACE__\
#define __�InterfaceFilenameWithoutExt�_INTERFACE__\
#include <string>\
#include \"�InterfaceFilenameWithoutExt�.h\"\
\
#ifndef __interface_throw__\
#define __interface_throw__\
class _interface_throw\
{\
  private:\
    unsigned int _operation_state;\
    std::string strErrorMsg;\
\
  public:\
    friend class �Interface�_client;\
    friend class �Interface�_server;\
\
  public:\
    _interface_throw () \
    {\
        _operation_state = 1;\
        strErrorMsg = \"\";\
    }\
    _interface_throw (const _interface_throw & CIn)\
    {\
        _operation_state = CIn._operation_state;\
        strErrorMsg = CIn.strErrorMsg;\
    }\
    ~_interface_throw ()\
    {\
        _operation_state = 1;\
        strErrorMsg = \"\";\
    }\
    _interface_throw & operator= (const _interface_throw & CIn)\
    {\
        _operation_state = CIn._operation_state;\
        strErrorMsg = CIn.strErrorMsg;\
        return *this;\
    }\
    unsigned short _usGetOperationState ()\
    {\
        return _operation_state;\
    }\
    std::string _strGetErrorMsg ()\
    {\
        return strErrorMsg;\
    }\
};\
typedef _interface_throw �Interface�_interface_throw;
#endif //__interface_throw__\
\
#define _MAXROUNDTRIPBYTESUM 4096 // Half of an UDP-package \
\
class �Interface�\
{\
  public:\
    virtual ~�Interface� () {};\
�AbstractInterfaceFunctionDeclarations�\
};\
\
#endif // __�InterfaceFilenameWithoutExt�_INTERFACE__\
";

my $g_ClientClassDeclarationTemplate = 
"/***********************************************************************/\
/*! \\file �ModulFilename�\
 *  \\brief Interface code file defined at �InterfaceFilenameWithoutExt�.idl and generated by idl2rpc.pl<br>\
 ***********************************************************************/
 \
 ".
$g_FileHead.
"#ifndef __�InterfaceFilenameWithoutExt�_client__\
#define __�InterfaceFilenameWithoutExt�_client__\
\
#include <rpc/rpc.h>\
#include \"�InterfaceFilenameWithoutExt�_interface.hpp\" \
#include \"�InterfaceFilenameWithoutExt�_simple_semvar.hpp\" \
\
#ifndef __ClientBase__\
#define __ClientBase__\
class ClientBase\
{\
  public:\
    ClientBase () {} \
    virtual ~ClientBase () {} \
    virtual unsigned short _usOpenInterface (std::string strNewServerIP) = 0;\
    virtual void _vCloseInterface () = 0;\
    virtual unsigned short _usIsClientConnected () = 0;\
    virtual std::string _strGetErrorMsg () = 0;\
    virtual unsigned long _ulPing () = 0;\
    virtual void _vResetServer () = 0;\
    virtual unsigned short _usCheckIDLVersion () = 0;\
    virtual unsigned short _usCheckIDLVersion (std::string & strIDL2RPCVersion, \
                                               int & iIDL2RPCVersionOK,\
                                               std::string & strInterfaceVersion, \
                                               int & iInterfaceVersionOK) = 0;\
    virtual unsigned long _ulGetRoundTripDelay () = 0;\
    virtual unsigned long _ulGetRoundTripDelay (unsigned long & ulSec, unsigned long & ulUSec) = 0;\
    virtual double _dGetRoundTripDataRate () = 0;\
    virtual double _dGetRoundTripDataRateNormalized (unsigned int uiPackageSizeInByte) = 0;\
    virtual unsigned short _usGetRequestTimeout (unsigned long & ulSec, unsigned long & ulUSec) = 0;\
    virtual unsigned short _usSetRequestTimeout (unsigned long ulSec, unsigned long ulUSec) = 0;\
    virtual unsigned short _usGetRetryTimeout (unsigned long & ulSec, unsigned long & ulUSec) = 0;\
    virtual unsigned short _usSetRetryTimeout (unsigned long ulSec, unsigned long ulUSec) = 0;\
    virtual unsigned short _usGetTransportProtocol (unsigned short & usProtocolID) = 0;\
    virtual unsigned short _usSetTransportProtocol (unsigned short usProtocolID) = 0;\
    virtual unsigned short _usGetTCPPort (unsigned int & uiTCPPort) = 0;\
    virtual unsigned short _usSetTCPPort (unsigned int uiTCPPort) = 0;\
    virtual unsigned short _usGetUDPPort (unsigned int & uiUDPPort) = 0;\
    virtual unsigned short _usSetUDPPort (unsigned int uiUDPPort) = 0;\
};\
#endif // __ClientBase__\
\
class �Interface�_client : public ClientBase, public �Interface� \
{\
  private:\
    unsigned long priv_ulRoundTripDelayMSecRounded; // Roundtrip delay in millisecond (rounded)\
    unsigned long priv_ulRoundTripDelaySec;         // Roundtrip delay second part\
    unsigned long priv_ulRoundTripDelayUSec;        // Roundtrip delay microsecond part\
    unsigned long priv_ulRoundTripByteSum;          // Sum of effective user bytes transfered during roundtrip time
    unsigned long priv_ulStartTimeMSecRounded;      // Starttime of roundtrip millisecond part (rounded)\
    unsigned long priv_ulStartTimeSec;              // Starttime of roundtrip second part\
    unsigned long priv_ulStartTimeUSec;             // Starttime of roundtrip microsecond part\
    struct timeval priv_RequestTimeout;             // The request timeout defines the timeout for one rpc call untill it has to be finish\
    struct timeval priv_RetryTimeout;               // The retry timeout is the time that RPC waits for the server to reply before retransmitting the request\
    unsigned short priv_usTransportProtocol;        // 0 = UDP, 1 = TCP\
    unsigned int priv_uiFixedTCPPort;               // Used TCP port\
    unsigned int priv_uiFixedUDPPort;               // Used UDP port\
    CLIENT * priv_pSClient;                         // ONC RPC client\
    int priv_iTCPSocket;                            // Specific socket for TCP\
    int priv_iUDPSocket;                            // Specific socket for UDP\
    std::string priv_strServerIP;                   // IP of server\
    std::string priv_strError;                      // Last error message\
    �Interface�_semvar<char> cThreadSaveClientSemaphore; // Semaphore to make client socket access point thread save\
  private:\
    unsigned long ul�Interface�GetMilliSecTick ();\
    void v�Interface�GetMicroSecTick (unsigned long & ulSec, unsigned long & ulUSec);\
    void v�Interface�StartTimer ();\
    void v�Interface�StopTimer ();\
    unsigned short us�Interface�OpenInterfaceIntern (std::string strNewServerIP) throw (_interface_throw);\
    void v�Interface�CloseInterfaceIntern () throw (_interface_throw);\
  public:\
    �Interface�_client () throw (_interface_throw);\
    �Interface�_client (const std::string strNewServerIP) throw (_interface_throw);\
    �Interface�_client (const �Interface�_client & CIn) throw (_interface_throw);\
    virtual ~�Interface�_client () throw (_interface_throw);\
    �Interface�_client & operator= (const �Interface�_client & CIn) throw (_interface_throw);\
    unsigned short us�Interface�OpenInterface (std::string strNewServerIP) throw (_interface_throw);\
    void v�Interface�CloseInterface () throw (_interface_throw);\
    unsigned short us�Interface�IsClientConnected ();\
    std::string str�Interface�GetErrorMsg () throw (_interface_throw);\
    unsigned long ul�Interface�Ping () throw (_interface_throw);\
    void v�Interface�ResetServer () throw (_interface_throw);\
    unsigned short us�Interface�CheckIDLVersion () throw (_interface_throw);\
    unsigned short us�Interface�CheckIDLVersion (std::string & strIDL2RPCVersion, \
                                                 int & iIDL2RPCVersionOK,\
                                                 std::string & strInterfaceVersion, \
                                                 int & iInterfaceVersionOK) throw (_interface_throw);\
    unsigned long ul�Interface�GetRoundTripDelay ();\
    unsigned long ul�Interface�GetRoundTripDelay (unsigned long & ulSec, unsigned long & ulUSec);\
    double d�Interface�GetRoundTripDataRate ();\
    unsigned short us�Interface�GetRequestTimeout (unsigned long & ulSec, unsigned long & ulUSec);\
    unsigned short us�Interface�SetRequestTimeout (unsigned long ulSec, unsigned long ulUSec);\
    unsigned short us�Interface�GetRetryTimeout (unsigned long & ulSec, unsigned long & ulUSec);\
    unsigned short us�Interface�SetRetryTimeout (unsigned long ulSec, unsigned long ulUSec);\
    unsigned short us�Interface�GetTransportProtocol (unsigned short & usProtocolID);\
    unsigned short us�Interface�SetTransportProtocol (unsigned short usProtocolID);\
    unsigned short us�Interface�GetTCPPort (unsigned int & uiTCPPort);\
    unsigned short us�Interface�SetTCPPort (unsigned int uiTCPPort);\
    unsigned short us�Interface�GetUDPPort (unsigned int & uiUDPPort);\
    unsigned short us�Interface�SetUDPPort (unsigned int uiUDPPort);\
    virtual unsigned short _usOpenInterface (std::string strNewServerIP) throw (_interface_throw);\
    virtual void _vCloseInterface () throw (_interface_throw);\
    virtual unsigned short _usIsClientConnected ();\
    virtual std::string _strGetErrorMsg () throw (_interface_throw);\
    virtual unsigned long _ulPing () throw (_interface_throw);\
    virtual void _vResetServer () throw (_interface_throw);\
    virtual unsigned short _usCheckIDLVersion () throw (_interface_throw);\
    virtual unsigned short _usCheckIDLVersion (std::string & strIDL2RPCVersion, \
                                               int & iIDL2RPCVersionOK,\
                                               std::string & strInterfaceVersion, \
                                               int & iInterfaceVersionOK) throw (_interface_throw);\
    virtual unsigned long _ulGetRoundTripDelay ();\
    virtual unsigned long _ulGetRoundTripDelay (unsigned long & ulSec, unsigned long & ulUSec);\
    virtual double _dGetRoundTripDataRate ();\
    virtual double _dGetRoundTripDataRateNormalized (unsigned int uiPackageSizeInByte);\
    virtual unsigned short _usGetRequestTimeout (unsigned long & ulSec, unsigned long & ulUSec);\
    virtual unsigned short _usSetRequestTimeout (unsigned long ulSec, unsigned long ulUSec);\
    virtual unsigned short _usGetRetryTimeout (unsigned long & ulSec, unsigned long & ulUSec);\
    virtual unsigned short _usSetRetryTimeout (unsigned long ulSec, unsigned long ulUSec);\
    virtual unsigned short _usGetTransportProtocol (unsigned short & usProtocolID);\
    virtual unsigned short _usSetTransportProtocol (unsigned short usProtocolID);\
    virtual unsigned short _usGetTCPPort (unsigned int & uiTCPPort);\
    virtual unsigned short _usSetTCPPort (unsigned int uiTCPPort);\
    virtual unsigned short _usGetUDPPort (unsigned int & uiUDPPort);\
    virtual unsigned short _usSetUDPPort (unsigned int uiUDPPort);\
�InterfaceFunctionDeclarations�\
};\
#endif // __�InterfaceFilenameWithoutExt�_client__\
";

my $g_ClientClassDefinitionTemplate = 
"/***********************************************************************/\
/*! \\file �ModulFilename�\
 *  \\brief Interface code file defined at �InterfaceFilenameWithoutExt�.idl and generated by idl2rpc.pl<br>\
 ***********************************************************************/
 \
 ".
$g_FileHead.
"#include <stdio.h>\
#include <rpc/rpc.h>\
#include <sys/time.h>\
#include <time.h>\
#include <sys/timeb.h>\
#include <string>\
#include <sys/socket.h>\
#include <netinet/in.h>\
#include <arpa/inet.h>\
#include <netdb.h>\
#include <unistd.h>\
#include \"�InterfaceFilenameWithoutExt�_interface.hpp\"\
#include \"�InterfaceFilenameWithoutExt�_client.hpp\"\
#include \"�InterfaceFilenameWithoutExt�_os.h\"\
\
/***********************************************************************\
 *  class     �Interface�_client\
 *  function  ul�Interface�GetMilliSecTick\
 ***********************************************************************/\
/*!           Return millisecond ticks to measure time periodes\
 *  \\param   -\
 *  \\return  unsigned long <- Time ticks\
 ***********************************************************************/\
/*  author    Alexander Neidhardt\
 *  date      14.05.2007\
 *  revision  -\
 *  info      Part of the idl2rpc.pl - generator!\
 ***********************************************************************/\
unsigned long �Interface�_client::ul�Interface�GetMilliSecTick()\
{\
    timeb STime;\
\
    ftime (&STime);\
    return (unsigned long) (STime.time*1000 + STime.millitm);\
}\
\
/***********************************************************************\
 *  class     �Interface�_client\
 *  function  v�Interface�GetMicroSecTick\
 ***********************************************************************/\
/*!           Return microsecond ticks to measure time periodes\
 *  \\param   unsigned long & ulSec <- Second part\
 *  \\param   unsigned long & ulUSec <- Microsecond part\
 *  \\return  -\
 ***********************************************************************/\
/*  author    Alexander Neidhardt\
 *  date      14.05.2007\
 *  revision  -\
 *  info      Part of the idl2rpc.pl - generator!\
 ***********************************************************************/\
void �Interface�_client::v�Interface�GetMicroSecTick (unsigned long & ulSec, unsigned long & ulUSec)\
{\
    struct timeval STime;
    struct timezone SZone;
    \
    ulSec = 0;\
    ulUSec = 0;\
    \
    if (gettimeofday (&STime, &SZone) != 0) return;\
    \
    // Seconds since 01.01.1970 00:00\
    ulSec = STime.tv_sec;\
    // Microseconds since last second\
    ulUSec = STime.tv_usec;\
}\
\
/***********************************************************************\
 *  class     �Interface�_client\
 *  function  v�Interface�StartTimer\
 ***********************************************************************/\
/*!           Starts the timer to measure a special time periode \
 *  \\param   -\
 *  \\return  -\
 ***********************************************************************/\
/*  author    Alexander Neidhardt\
 *  date      14.05.2007\
 *  revision  -\
 *  info      Part of the idl2rpc.pl - generator!\
 ***********************************************************************/\
void �Interface�_client::v�Interface�StartTimer ()\
{\
    priv_ulStartTimeMSecRounded = ul�Interface�GetMilliSecTick();\
    v�Interface�GetMicroSecTick (priv_ulStartTimeSec, priv_ulStartTimeUSec);\
}\
\
/***********************************************************************\
 *  class     �Interface�_client\
 *  function  v�Interface�StopTimer\
 ***********************************************************************/\
/*!           Stops the timer to measure a special time periode \
 *  \\param   -\
 *  \\return  -\
 ***********************************************************************/\
/*  author    Alexander Neidhardt\
 *  date      14.05.2007\
 *  revision  -\
 *  info      Part of the idl2rpc.pl - generator!\
 ***********************************************************************/\
void �Interface�_client::v�Interface�StopTimer ()\
{\
    unsigned long ulEndTimeSecRounded;\
    unsigned long ulEndTimeSec;\
    unsigned long ulEndTimeUSec;\
    \
    ulEndTimeSecRounded = ul�Interface�GetMilliSecTick();\
    v�Interface�GetMicroSecTick (ulEndTimeSec, ulEndTimeUSec);\
    \
    priv_ulRoundTripDelayMSecRounded = ulEndTimeSecRounded - priv_ulStartTimeMSecRounded;\
    priv_ulRoundTripDelaySec = (((1000000-priv_ulStartTimeUSec)+ulEndTimeUSec)/1000000)+(ulEndTimeSec-priv_ulStartTimeSec-1);\
    priv_ulRoundTripDelayUSec = (((1000000-priv_ulStartTimeUSec)+ulEndTimeUSec)%1000000);\
}\
\
/***********************************************************************\
 *  class     �Interface�_client\
 *  function  us�Interface�OpenInterfaceIntern\
 ***********************************************************************/\
/*!           Open interface \
 *  \\param   std::string strNewServerIP -> Server IP to connect with\
 *  \\return  unsigned short <- Errorcode (0=ok, 1=error)\
 ***********************************************************************/\
/*  author    Alexander Neidhardt\
 *  date      14.05.2007\
 *  revision  -\
 *  info      Part of the idl2rpc.pl - generator!\
 ***********************************************************************/\
unsigned short �Interface�_client::us�Interface�OpenInterfaceIntern (std::string strNewServerIP) throw (_interface_throw)\
{\
    // RPC-in/out-structures\
    void * vInput = NULL;\
    unsigned long * SOutput;\
    struct timeval RequestTimeout;\
    struct timeval RetryTimeout;\
    struct sockaddr_in STServerAddress;\
    struct hostent * hostent_ptr;\
\
    // Prepare client timeouts\
    RequestTimeout.tv_sec = �RequestTimeoutSec�;\
    RequestTimeout.tv_usec = �RequestTimeoutUSec�;\
    RetryTimeout.tv_sec = �RetryTimeoutSec�;\
    RetryTimeout.tv_usec = �RetryTimeoutUSec�;\
\
    try\
    {\
        priv_ulRoundTripDelayMSecRounded = 0;\
        priv_ulRoundTripDelaySec = 0;\
        priv_ulRoundTripDelayUSec = 0;\
        priv_ulStartTimeMSecRounded = 0;\
        priv_ulStartTimeSec = 0;\
        priv_ulStartTimeUSec = 0;\
        priv_strError = \"OK\";\
    }\
    catch (...)\
    {\
        _interface_throw CInterfaceExcept;\
        priv_strError = \"Can't open interface\";\
        CInterfaceExcept.strErrorMsg = priv_strError;\
        CInterfaceExcept._operation_state = 1;\
        throw (CInterfaceExcept);\
        return 1;\
    }\
    if (priv_pSClient != NULL)\
    {\
        try\
        {\
            v�Interface�CloseInterfaceIntern ();\
        }\
        catch (_interface_throw CInterfaceExcept)\
        {\
            throw (CInterfaceExcept);\
            return 1;\
        }\
    }\
    \
    \
    if (priv_usTransportProtocol == 0)\
    {\
        // UDP \
        if (priv_uiFixedUDPPort == 0)\
        {\
            // Open portmapper based connection (UDP)\
            if ((priv_pSClient = clnt_create (strNewServerIP.c_str(), �RPCPROGRAM�, �RPCPVERSION�, \"udp\")) == NULL)\
            {\
                _interface_throw CInterfaceExcept;\
                priv_strError = clnt_spcreateerror (strNewServerIP.c_str());\
                CInterfaceExcept.strErrorMsg = priv_strError;\
                CInterfaceExcept._operation_state = 1;\
                throw (CInterfaceExcept);\
                return 1;\
            }\
        }\
        else\
        {\
            // Open specific socket (UDP = SOCK_DGRAM) \
            priv_iUDPSocket = socket(PF_INET, SOCK_DGRAM, 0); // standard is priv_iUDPSocket = RPC_ANYSOCK;\
            STServerAddress.sin_family = AF_INET;\
            STServerAddress.sin_port = htons(priv_uiFixedUDPPort);\
            if ((hostent_ptr = gethostbyname(strNewServerIP.c_str())) == NULL)\
            {\
                _interface_throw CInterfaceExcept;\
                priv_strError = \"Can't get host by name\";\
                CInterfaceExcept.strErrorMsg = priv_strError;\
                CInterfaceExcept._operation_state = 1;\
                throw (CInterfaceExcept);\
                return 1;\
            }\
            bcopy ( hostent_ptr->h_addr, &(STServerAddress.sin_addr.s_addr), hostent_ptr->h_length);\
            if ((connect (priv_iUDPSocket, (struct sockaddr *) & STServerAddress, sizeof (STServerAddress))) == -1)\
            {\
                _interface_throw CInterfaceExcept;\
                priv_strError = \"Can't connect to host\";\
                CInterfaceExcept.strErrorMsg = priv_strError;\
                CInterfaceExcept._operation_state = 1;\
                throw (CInterfaceExcept);\
                return 1;\
            }\
            \
            if ((priv_pSClient = clntudp_create (&STServerAddress, �RPCPROGRAM�, �RPCPVERSION�, RetryTimeout, &priv_iUDPSocket)) == NULL)\
            {\
                _interface_throw CInterfaceExcept;\
                priv_strError = clnt_spcreateerror (strNewServerIP.c_str());\
                CInterfaceExcept.strErrorMsg = priv_strError;\
                CInterfaceExcept._operation_state = 1;\
                throw (CInterfaceExcept);\
                return 1;\
            }\
        }
    }\
    else \
    {\
        // TCP \
        if (priv_uiFixedTCPPort == 0)\
        {\
            // Open portmapper based connection (TCP)\
            if ((priv_pSClient = clnt_create (strNewServerIP.c_str(), �RPCPROGRAM�, �RPCPVERSION�, \"tcp\")) == NULL)\
            {\
                _interface_throw CInterfaceExcept;\
                priv_strError = clnt_spcreateerror (strNewServerIP.c_str());\
                CInterfaceExcept.strErrorMsg = priv_strError;\
                CInterfaceExcept._operation_state = 1;\
                throw (CInterfaceExcept);\
                return 1;\
            }\
        }\
        else\
        {\
            // Open specific socket (TCP = SOCK_STREAM)\
            priv_iTCPSocket = socket(PF_INET, SOCK_STREAM, 0); // standard is priv_iTCPSocket = RPC_ANYSOCK;\
            STServerAddress.sin_family = AF_INET;\
            STServerAddress.sin_port = htons(priv_uiFixedTCPPort);\
            if ((hostent_ptr = gethostbyname(strNewServerIP.c_str())) == NULL)\
            {\
                _interface_throw CInterfaceExcept;\
                priv_strError = \"Can't get host by name\";\
                CInterfaceExcept.strErrorMsg = priv_strError;\
                CInterfaceExcept._operation_state = 1;\
                throw (CInterfaceExcept);\
                return 1;\
            }\
            bcopy ( hostent_ptr->h_addr, &(STServerAddress.sin_addr.s_addr), hostent_ptr->h_length);\
            if ((connect (priv_iTCPSocket, (struct sockaddr *) & STServerAddress, sizeof (STServerAddress))) == -1)\
            {\
                _interface_throw CInterfaceExcept;\
                priv_strError = \"Can't connect to host\";\
                CInterfaceExcept.strErrorMsg = priv_strError;\
                CInterfaceExcept._operation_state = 1;\
                throw (CInterfaceExcept);\
                return 1;\
            }\
            \
            if ((priv_pSClient = clnttcp_create (&STServerAddress, �RPCPROGRAM�, �RPCPVERSION�, &priv_iTCPSocket, 0, 0)) == NULL)\
            {\
                _interface_throw CInterfaceExcept;\
                priv_strError = clnt_spcreateerror (strNewServerIP.c_str());\
                CInterfaceExcept.strErrorMsg = priv_strError;\
                CInterfaceExcept._operation_state = 1;\
                throw (CInterfaceExcept);\
                return 1;\
            }\
        }\
    }\
    \
    try\
    {\
        priv_strServerIP = strNewServerIP;\
    \
    }\
    catch (...)\
    {\
        _interface_throw CInterfaceExcept;\
        priv_strError = \"Can't open interface\";\
        CInterfaceExcept.strErrorMsg = priv_strError;\
        CInterfaceExcept._operation_state = 1;\
        v�Interface�CloseInterfaceIntern ();\
        throw (CInterfaceExcept);\
        return 1;\
    }\
    \
    // Test interface\
    if ((SOutput = sap_�InterfaceLC�_basicping_1 (vInput, priv_pSClient)) == NULL)\
    {\
        _interface_throw CInterfaceExcept;\
        priv_strError = clnt_spcreateerror (priv_strServerIP.c_str());\
        CInterfaceExcept.strErrorMsg = priv_strError;\
        CInterfaceExcept._operation_state = 2;\
        v�Interface�CloseInterfaceIntern ();\
        throw (CInterfaceExcept);\
        return 1;\
    }\
    \
    // Get timeouts\
    if (!clnt_control (priv_pSClient, CLGET_TIMEOUT, (char *)&priv_RequestTimeout))\
    {\
        _interface_throw CInterfaceExcept;\
        priv_strError = \"Can't get request timeout information\";\
        CInterfaceExcept.strErrorMsg = priv_strError;\
        CInterfaceExcept._operation_state = 1;\
        v�Interface�CloseInterfaceIntern ();\
        throw (CInterfaceExcept);\
        return 1;\
    }\
    if (priv_usTransportProtocol == 0)\
    {\
        if (!clnt_control (priv_pSClient, CLGET_RETRY_TIMEOUT, (char *)&priv_RetryTimeout))\
        {\
            _interface_throw CInterfaceExcept;\
            priv_strError = \"Can't get retry timeout information\";\
            CInterfaceExcept.strErrorMsg = priv_strError;\
            CInterfaceExcept._operation_state = 1;\
            v�Interface�CloseInterfaceIntern ();\
            throw (CInterfaceExcept);\
            return 1;\
        }\
    }\
    \
    if (RequestTimeout.tv_sec > 0 || \
        RequestTimeout.tv_usec > 0) \
    {\
        priv_RequestTimeout.tv_sec = RequestTimeout.tv_sec;\
        priv_RequestTimeout.tv_usec = RequestTimeout.tv_usec;\
    }\
    if (priv_usTransportProtocol == 0)\
    {\
        if (RetryTimeout.tv_sec > 0 ||\
            RetryTimeout.tv_usec > 0)\
        {\
            priv_RetryTimeout.tv_sec = RetryTimeout.tv_sec;\
            priv_RetryTimeout.tv_usec = RetryTimeout.tv_usec;\
        }\
    }\
    \
    // Set timeouts\
    if (!clnt_control (priv_pSClient, CLSET_TIMEOUT, (char *)&priv_RequestTimeout))\
    {\
        _interface_throw CInterfaceExcept;\
        priv_strError = \"Can't set request timeout information\";\
        CInterfaceExcept.strErrorMsg = priv_strError;\
        CInterfaceExcept._operation_state = 1;\
        v�Interface�CloseInterfaceIntern ();\
        throw (CInterfaceExcept);\
        return 1;\
    }\
    if (priv_usTransportProtocol == 0)\
    {\
        if (!clnt_control (priv_pSClient, CLSET_RETRY_TIMEOUT, (char *)&priv_RetryTimeout))\
        {\
            _interface_throw CInterfaceExcept;\
            priv_strError = \"Can't get retry timeout information\";\
            CInterfaceExcept.strErrorMsg = priv_strError;\
            CInterfaceExcept._operation_state = 1;\
            v�Interface�CloseInterfaceIntern ();\
            throw (CInterfaceExcept);\
            return 1;\
        }\
    }\
    \
    return 0;\
}\
\
/***********************************************************************\
 *  class     �Interface�_client\
 *  function  v�Interface�CloseInterfaceIntern\
 ***********************************************************************/\
/*!           Close interface \
 *  \\param   -\
 *  \\return  -\
 ***********************************************************************/\
/*  author    Alexander Neidhardt\
 *  date      14.05.2007\
 *  revision  -\
 *  info      Part of the idl2rpc.pl - generator!\
 ***********************************************************************/\
void �Interface�_client::v�Interface�CloseInterfaceIntern () throw (_interface_throw)\
{\
    try\
    {\
        if (priv_pSClient != NULL)\
        {\
            clnt_destroy (priv_pSClient);\
            priv_pSClient = NULL;\
        }\
        if (priv_iTCPSocket != -1)\
        {\
            close (priv_iTCPSocket);\
        }\
        if (priv_iUDPSocket != -1)\
        {\
            close (priv_iUDPSocket);\
        }\
    }\
    catch (...)\
    {\
        _interface_throw CInterfaceExcept;\
        priv_strError = \"Can't close interface\";\
        CInterfaceExcept.strErrorMsg = priv_strError;\
        CInterfaceExcept._operation_state = 1;\
        throw (CInterfaceExcept);\
        return;\
    }\
    try\
    {\
        // priv_strServerIP = \"\";\
        priv_strError = \"OK\";\
    }\
    catch (...)\
    {\
        _interface_throw CInterfaceExcept;\
        priv_strError = \"Can't close interface\";\
        CInterfaceExcept.strErrorMsg = priv_strError;\
        CInterfaceExcept._operation_state = 1;\
        throw (CInterfaceExcept);\
        return;\
    }\
}\
\
/***********************************************************************\
 *  class     �Interface�_client\
 *  function  �Interface�_client\
 ***********************************************************************/\
/*!           Constructor \
 *  \\param   -\
 *  \\return  -\
 ***********************************************************************/\
/*  author    Alexander Neidhardt\
 *  date      14.05.2007\
 *  revision  -\
 *  info      Part of the idl2rpc.pl - generator!\
 ***********************************************************************/\
�Interface�_client::�Interface�_client () throw (_interface_throw) : �Interface�()\
{\
    try\
    {\
        priv_ulRoundTripDelayMSecRounded = 0;\
        priv_ulRoundTripDelaySec = 0;\
        priv_ulRoundTripDelayUSec = 0;\
        priv_ulStartTimeMSecRounded = 0;\
        priv_ulStartTimeSec = 0;\
        priv_ulStartTimeUSec = 0;\
        priv_RequestTimeout.tv_sec = �RequestTimeoutSec�;\
        priv_RequestTimeout.tv_usec = �RequestTimeoutUSec�;\
        priv_RetryTimeout.tv_sec = �RetryTimeoutSec�;\
        priv_RetryTimeout.tv_usec = �RetryTimeoutUSec�;\
        priv_pSClient = NULL;\
        priv_strServerIP = \"\";\
        priv_strError = \"OK\";\
        priv_usTransportProtocol = �TransportProtocol�;\
        priv_iTCPSocket = -1;\
        priv_iUDPSocket = -1;\
        cThreadSaveClientSemaphore = '\\0';\
        priv_uiFixedTCPPort = �TCPPort�;\
        priv_uiFixedUDPPort = �UDPPort�;\
        priv_ulRoundTripByteSum = 0;\
    }\
    catch (...)\
    {\
        _interface_throw CInterfaceExcept;\
        priv_strError = \"Can't init interface\";\
        CInterfaceExcept.strErrorMsg = priv_strError;\
        CInterfaceExcept._operation_state = 1;\
        throw (CInterfaceExcept);\
        return;\
    }\
}\
\
/***********************************************************************\
 *  class     �Interface�_client\
 *  function  �Interface�_client\
 ***********************************************************************/\
/*!           Constructor with included open\
 *  \\param   const std::string strNewServerIP -> Server IP to connect with\
 *  \\return  -\
 ***********************************************************************/\
/*  author    Alexander Neidhardt\
 *  date      14.05.2007\
 *  revision  -\
 *  info      Part of the idl2rpc.pl - generator!\
 ***********************************************************************/\
�Interface�_client::�Interface�_client (const std::string strNewServerIP) throw (_interface_throw) : �Interface�()\
{\
    try\
    {\
        priv_ulRoundTripDelayMSecRounded = 0;\
        priv_ulRoundTripDelaySec = 0;\
        priv_ulRoundTripDelayUSec = 0;\
        priv_ulStartTimeMSecRounded = 0;\
        priv_ulStartTimeSec = 0;\
        priv_ulStartTimeUSec = 0;\
        priv_RequestTimeout.tv_sec = �RequestTimeoutSec�;\
        priv_RequestTimeout.tv_usec = �RequestTimeoutUSec�;\
        priv_RetryTimeout.tv_sec = �RetryTimeoutSec�;\
        priv_RetryTimeout.tv_usec = �RetryTimeoutUSec�;\
        priv_pSClient = NULL;\
        priv_strServerIP = strNewServerIP;\
        priv_strError = \"OK\";\
        priv_usTransportProtocol = �TransportProtocol�;\
        priv_iTCPSocket = -1;\
        priv_iUDPSocket = -1;\
        cThreadSaveClientSemaphore = '\\0';\
        priv_uiFixedTCPPort = �TCPPort�;\
        priv_uiFixedUDPPort = �UDPPort�;\
        priv_ulRoundTripByteSum = 0;\
    }\
    catch (...)\
    {\
        _interface_throw CInterfaceExcept;\
        priv_strError = \"Can't init interface\";\
        CInterfaceExcept.strErrorMsg = priv_strError;\
        CInterfaceExcept._operation_state = 1;\
        throw (CInterfaceExcept);\
        return;\
    }\
    try\
    {\
        if (strNewServerIP.length() > 0)\
        {\
            if (us�Interface�OpenInterfaceIntern (priv_strServerIP))\
            {\
                _interface_throw CInterfaceExcept;\
                priv_strError = \"Can't open interface\";\
                CInterfaceExcept.strErrorMsg = priv_strError;\
                CInterfaceExcept._operation_state = 1;\
                throw (CInterfaceExcept);\
                return;\
            }\
        }\
    }\
    catch (_interface_throw CInterfaceExcept)\
    {\
        throw (CInterfaceExcept);\
        return;\
    }\
}\
\
/***********************************************************************\
 *  class     �Interface�_client\
 *  function  �Interface�_client\
 ***********************************************************************/\
/*!           Copy-Constructor \
 *  \\param   const �Interface�_client & CIn -> Interface to copy\
 *  \\return  -\
 ***********************************************************************/\
/*  author    Alexander Neidhardt\
 *  date      14.05.2007\
 *  revision  -\
 *  info      Part of the idl2rpc.pl - generator!\
 ***********************************************************************/\
�Interface�_client::�Interface�_client (const �Interface�_client & CIn) throw (_interface_throw) : ClientBase(), �Interface�(CIn)\
{\
    try\
    {\
        priv_ulRoundTripDelayMSecRounded = 0;\
        priv_ulRoundTripDelaySec = 0;\
        priv_ulRoundTripDelayUSec = 0;\
        priv_ulStartTimeMSecRounded = 0;\
        priv_ulStartTimeSec = 0;\
        priv_ulStartTimeUSec = 0;\
        priv_RequestTimeout.tv_sec = CIn.priv_RequestTimeout.tv_sec;\
        priv_RequestTimeout.tv_usec = CIn.priv_RequestTimeout.tv_usec;\
        priv_RetryTimeout.tv_sec = CIn.priv_RetryTimeout.tv_sec;\
        priv_RetryTimeout.tv_usec = CIn.priv_RetryTimeout.tv_usec;\
        priv_pSClient = NULL;\
        priv_strServerIP = CIn.priv_strServerIP;\
        priv_strError = \"OK\";\
        priv_usTransportProtocol = CIn.priv_usTransportProtocol;\
        priv_iTCPSocket = CIn.priv_iTCPSocket;\
        priv_iUDPSocket = CIn.priv_iUDPSocket;\
        cThreadSaveClientSemaphore = ((�Interface�_client*)&CIn)->cThreadSaveClientSemaphore.CGetSemVal();
        priv_uiFixedTCPPort = CIn.priv_uiFixedTCPPort;\
        priv_uiFixedUDPPort = CIn.priv_uiFixedUDPPort;\
        priv_ulRoundTripByteSum = 0;\
    }\
    catch (...)\
    {\
        _interface_throw CInterfaceExcept;\
        priv_strError = \"Can't init interface\";\
        CInterfaceExcept.strErrorMsg = priv_strError;\
        CInterfaceExcept._operation_state = 1;\
        throw (CInterfaceExcept);\
        return;\
    }\
    try\
    {\
        if (((�Interface�_client*)&CIn)->us�Interface�IsClientConnected ())\
        {\
            if (us�Interface�OpenInterfaceIntern (CIn.priv_strServerIP))\
            {\
                _interface_throw CInterfaceExcept;\
                priv_strError = \"Can't open interface\";\
                CInterfaceExcept.strErrorMsg = priv_strError;\
                CInterfaceExcept._operation_state = 1;\
                throw (CInterfaceExcept);\
                return;\
            }\
        }\
    }\
    catch (_interface_throw CInterfaceExcept)\
    {\
        throw (CInterfaceExcept);\
        return;\
    }\
}\
\
/***********************************************************************\
 *  class     �Interface�_client\
 *  function  ~�Interface�_client\
 ***********************************************************************/\
/*!           Destructor \
 *  \\param   -\
 *  \\return  -\
 ***********************************************************************/\
/*  author    Alexander Neidhardt\
 *  date      14.05.2007\
 *  revision  -\
 *  info      Part of the idl2rpc.pl - generator!\
 ***********************************************************************/\
�Interface�_client::~�Interface�_client () throw (_interface_throw)\
{\
    try\
    {\
        v�Interface�CloseInterfaceIntern ();\
    }\
    catch (_interface_throw CInterfaceExcept)\
    {\
        throw (CInterfaceExcept);\
        return;\
    }\
    \
    try\
    {\
        priv_ulRoundTripDelayMSecRounded = 0;\
        priv_ulRoundTripDelaySec = 0;\
        priv_ulRoundTripDelayUSec = 0;\
        priv_ulStartTimeMSecRounded = 0;\
        priv_ulStartTimeSec = 0;\
        priv_ulStartTimeUSec = 0;\
        priv_RequestTimeout.tv_sec = �RequestTimeoutSec�;\
        priv_RequestTimeout.tv_usec = �RequestTimeoutUSec�;\
        priv_RetryTimeout.tv_sec = �RetryTimeoutSec�;\
        priv_RetryTimeout.tv_usec = �RetryTimeoutUSec�;\
        priv_pSClient = NULL;\
        priv_strError = \"OK\";\
        priv_usTransportProtocol = �TransportProtocol�;\
        priv_iTCPSocket = -1;\
        priv_iUDPSocket = -1;\
        cThreadSaveClientSemaphore = '\\0';\
        priv_uiFixedTCPPort = �TCPPort�;\
        priv_uiFixedUDPPort = �UDPPort�;\
        priv_ulRoundTripByteSum = 0;\
    }\
    catch (...)\
    {\
        _interface_throw CInterfaceExcept;\
        priv_strError = \"Can't destroy interface\";\
        CInterfaceExcept.strErrorMsg = priv_strError;\
        CInterfaceExcept._operation_state = 1;\
        throw (CInterfaceExcept);\
        return;\
    }\
}\
\
/***********************************************************************\
 *  class     �Interface�_client\
 *  function  operator=\
 ***********************************************************************/\
/*!           Asign operator \
 *  \\param   �Interface�_client CIn -> Asign from\
 *  \\return  �Interface�_client <- The copy\
 ***********************************************************************/\
/*  author    Alexander Neidhardt\
 *  date      14.05.2007\
 *  revision  -\
 *  info      Part of the idl2rpc.pl - generator!\
 ***********************************************************************/\
�Interface�_client & �Interface�_client::operator= (const �Interface�_client & CIn) throw (_interface_throw)\
{\
    try\
    {\
        priv_ulRoundTripDelayMSecRounded = 0;\
        priv_ulRoundTripDelaySec = 0;\
        priv_ulRoundTripDelayUSec = 0;\
        priv_ulStartTimeMSecRounded = 0;\
        priv_ulStartTimeSec = 0;\
        priv_ulStartTimeUSec = 0;\
        priv_RequestTimeout.tv_sec = CIn.priv_RequestTimeout.tv_sec;\
        priv_RequestTimeout.tv_usec = CIn.priv_RequestTimeout.tv_usec;\
        priv_RetryTimeout.tv_sec = CIn.priv_RetryTimeout.tv_sec;\
        priv_RetryTimeout.tv_usec = CIn.priv_RetryTimeout.tv_usec;\
        priv_pSClient = NULL;\
        priv_strServerIP = CIn.priv_strServerIP;\
        priv_strError = \"OK\";\
        priv_usTransportProtocol = CIn.priv_usTransportProtocol;\
        priv_iTCPSocket = CIn.priv_iTCPSocket;\
        priv_iUDPSocket = CIn.priv_iUDPSocket;\
        cThreadSaveClientSemaphore = ((�Interface�_client*)&CIn)->cThreadSaveClientSemaphore.CGetSemVal();
        priv_uiFixedTCPPort = CIn.priv_uiFixedTCPPort;\
        priv_uiFixedUDPPort = CIn.priv_uiFixedUDPPort;\
        priv_ulRoundTripByteSum = 0;\
    }\
    catch (...)\
    {\
        _interface_throw CInterfaceExcept;\
        priv_strError = \"Can't init interface\";\
        CInterfaceExcept.strErrorMsg = priv_strError;\
        CInterfaceExcept._operation_state = 1;\
        throw (CInterfaceExcept);\
        return *this;\
    }\
    try\
    {\
        if (((�Interface�_client*)&CIn)->us�Interface�IsClientConnected ())\
        {\
            if (us�Interface�OpenInterfaceIntern (CIn.priv_strServerIP))\
            {\
                _interface_throw CInterfaceExcept;\
                priv_strError = \"Can't open interface\";\
                CInterfaceExcept.strErrorMsg = priv_strError;\
                CInterfaceExcept._operation_state = 1;\
                throw (CInterfaceExcept);\
                return *this;\
            }\
        }\
    }\
    catch (_interface_throw CInterfaceExcept)\
    {\
        throw (CInterfaceExcept);\
        return *this;\
    }\
    return *this;\
}\
\
/***********************************************************************\
 *  class     �Interface�_client\
 *  function  us�Interface�OpenInterface\
 ***********************************************************************/\
/*!           Open interface (with thread save semaphore)\
 *  \\param   std::string strNewServerIP -> Server IP to connect with\
 *  \\return  unsigned short <- Errorcode (0=ok, 1=error)\
 ***********************************************************************/\
/*  author    Alexander Neidhardt\
 *  date      14.05.2007\
 *  revision  -\
 *  info      Part of the idl2rpc.pl - generator!\
 ***********************************************************************/\
unsigned short �Interface�_client::us�Interface�OpenInterface (std::string strNewServerIP) throw (_interface_throw)\
{\
    unsigned short usError = 0;\
    unsigned long ulBlockHandle = 0;\
    \
    // Enter critical section\
    try\
    {\
        cThreadSaveClientSemaphore.vBlock(ulBlockHandle);\
    }\
    catch (...)\
    {\
        _interface_throw CInterfaceExcept;\
        priv_strError = \"Semaphore failed BLOCK\";\
        CInterfaceExcept.strErrorMsg = priv_strError;\
        CInterfaceExcept._operation_state = 2;\
        throw CInterfaceExcept;\
    }\
    \
    try\
    {\
        usError = us�Interface�OpenInterfaceIntern (strNewServerIP);\
        if (usError)\
        {\
            priv_strError += \" Can't open interface\";\
        }\
    }\
    catch (_interface_throw CInterfaceExcept)\
    {\
        priv_strError = CInterfaceExcept.strErrorMsg;\
        usError = 1;\
    }\
    catch (...)\
    {\
        priv_strError = \"Undefined error while opening interface\";\
        usError = 1;\
    }\
    \
    // Leave critical section\
    try\
    {\
        cThreadSaveClientSemaphore.vUnblock(ulBlockHandle);\
    }\
    catch (...)\
    {\
        _interface_throw CInterfaceExcept;\
        priv_strError = \"Semaphore failed UNBLOCK\";\
        CInterfaceExcept.strErrorMsg = priv_strError;\
        CInterfaceExcept._operation_state = 2;\
        throw CInterfaceExcept;\
    }\
    \
    return usError;\
}\
\
/***********************************************************************\
 *  class     �Interface�_client\
 *  function  v�Interface�CloseInterface\
 ***********************************************************************/\
/*!           Close interface (with thread save semaphore)\
 *  \\param   -\
 *  \\return  -\
 ***********************************************************************/\
/*  author    Alexander Neidhardt\
 *  date      14.05.2007\
 *  revision  -\
 *  info      Part of the idl2rpc.pl - generator!\
 ***********************************************************************/\
void �Interface�_client::v�Interface�CloseInterface () throw (_interface_throw)\
{\
    unsigned long ulBlockHandle = 0;\
    \
    // Enter critical section\
    try\
    {\
        cThreadSaveClientSemaphore.vBlock(ulBlockHandle);\
    }\
    catch (...)\
    {\
        _interface_throw CInterfaceExcept;\
        priv_strError = \"Semaphore failed BLOCK\";\
        CInterfaceExcept.strErrorMsg = priv_strError;\
        CInterfaceExcept._operation_state = 2;\
        throw CInterfaceExcept;\
    }\
    \
    try\
    {\
       v�Interface�CloseInterfaceIntern ();\
    }\
    catch (_interface_throw CInterfaceExcept)\
    {\
    }\
    catch (...)\
    {\
        _interface_throw CInterfaceExcept;\
        priv_strError = \"Undefined error while closing interface\";\
        CInterfaceExcept.strErrorMsg = priv_strError;\
        CInterfaceExcept._operation_state = 2;\
    }\
    \
    // Leave critical section\
    try\
    {\
        cThreadSaveClientSemaphore.vUnblock(ulBlockHandle);\
    }\
    catch (...)\
    {\
        _interface_throw CInterfaceExcept;\
        priv_strError = \"Semaphore failed UNBLOCK\";\
        CInterfaceExcept.strErrorMsg = priv_strError;\
        CInterfaceExcept._operation_state = 2;\
        throw CInterfaceExcept;\
    }\
}\
\
/***********************************************************************\
 *  class     �Interface�_client\
 *  function  us�Interface�IsClientConnected\
 ***********************************************************************/\
/*!           Check if interface is opened \
 *  \\param   -\
 *  \\return  unsigned short <- Answer (0=no, 1=yes)\
 ***********************************************************************/\
/*  author    Alexander Neidhardt\
 *  date      14.05.2007\
 *  revision  -\
 *  info      Part of the idl2rpc.pl - generator!\
 ***********************************************************************/\
unsigned short �Interface�_client::us�Interface�IsClientConnected ()\
{\
    if (priv_pSClient != NULL)\
        return 1;\
    else\
        return 0;\
}\
\
/***********************************************************************\
 *  class     �Interface�_client\
 *  function  str�Interface�GetErrorMsg\
 ***********************************************************************/\
/*!           Return error last message\
 *  \\param   -\
 *  \\return  std::string <- Errormessage\
 ***********************************************************************/\
/*  author    Alexander Neidhardt\
 *  date      14.05.2007\
 *  revision  -\
 *  info      Part of the idl2rpc.pl - generator!\
 ***********************************************************************/\
std::string �Interface�_client::str�Interface�GetErrorMsg () throw (_interface_throw)\
{\
    std::string strError;
\
    try\
    {\
        strError = priv_strError;\
        priv_strError = \"OK\";\
    }\
    catch (...)\
    {\
        _interface_throw CInterfaceExcept;\
        priv_strError = \"Can't read error message\";\
        CInterfaceExcept.strErrorMsg = priv_strError;\
        CInterfaceExcept._operation_state = 1;\
        throw (CInterfaceExcept);\
        return strError;\
    }\
    return strError;\
}\
\
/***********************************************************************\
 *  class     �Interface�_client\
 *  function  ul�Interface�Ping\
 ***********************************************************************/\
/*!           Method to ping the server\
 *  \\param   -\
 *  \\return  unsigned long <- Round trip delay of ping\
 ***********************************************************************/\
/*  author    Alexander Neidhardt\
 *  date      14.05.2007\
 *  revision  -\
 *  info      Part of the idl2rpc.pl - generator!\
 ***********************************************************************/\
unsigned long �Interface�_client::ul�Interface�Ping () throw (_interface_throw)\
{\
    // RPC-in/out-structures\
    void * vInput = NULL;\
    unsigned long * SOutput;\
    unsigned long ulBlockHandle = 0;\
    unsigned short __usInternalError = 0;\
    _interface_throw CInterfaceExcept;\
    // =============================================================\
    // Start round trip delay measuring
    v�Interface�StartTimer ();
    // =============================================================\
    // Enter critical section\
    try\
    {\
        cThreadSaveClientSemaphore.vBlock(ulBlockHandle);\
    }\
    catch (...)\
    {\
        priv_strError = \"Semaphore failed BLOCK\";\
        CInterfaceExcept.strErrorMsg = priv_strError;\
        CInterfaceExcept._operation_state = 2;\
        __usInternalError = 1;\
        goto ul�Interface�Ping_Return;\
    }\
    // =============================================================\
    // Check if interface is usable\
    if (!us�Interface�IsClientConnected ())\
    {\
        if (priv_strServerIP.length() > 0)\
        {\
            // Try to open interface\
            try\
            {\
               us�Interface�OpenInterfaceIntern (priv_strServerIP);\
            }\
            catch (_interface_throw CInterfaceException)\
            {\
                CInterfaceExcept = CInterfaceException;\
                priv_strError = CInterfaceExcept.strErrorMsg;\
                __usInternalError = 1;\
                goto ul�Interface�Ping_Return;\
            }\
        }\
        else\
        {\
            priv_strError = \"No IP saved for reopen\";\
            CInterfaceExcept.strErrorMsg = priv_strError;\
            CInterfaceExcept._operation_state = 2;\
            __usInternalError = 1;\
            goto ul�Interface�Ping_Return;\
        }\
    }\
    priv_ulRoundTripByteSum = 0;\
    // =============================================================\
    // Call RPC-functionality\
    if ((SOutput = sap_�InterfaceLC�_basicping_1 (vInput, priv_pSClient)) == NULL)\
    {\
        priv_strError = clnt_spcreateerror (priv_strServerIP.c_str());\
        CInterfaceExcept.strErrorMsg = priv_strError;\
        CInterfaceExcept._operation_state = 2;\
        v�Interface�CloseInterfaceIntern (); // Close interface for a later reopen\
        __usInternalError = 2;\
        goto ul�Interface�Ping_Return;\
    }\
    // =============================================================\
    // Return jump point\
    ul�Interface�Ping_Return:
    // =============================================================\
    // Stop round trip delay measuring
    v�Interface�StopTimer ();
    // Check timeout situations\
    if (__usInternalError == 2)\
    {\
        if (((unsigned long)priv_RequestTimeout.tv_sec < priv_ulRoundTripDelaySec) ||\
            ((unsigned long)priv_RequestTimeout.tv_sec == priv_ulRoundTripDelaySec &&\
             (unsigned long)priv_RequestTimeout.tv_usec <= priv_ulRoundTripDelayUSec))\
        {\
             CInterfaceExcept.strErrorMsg[CInterfaceExcept.strErrorMsg.length()-1] = '\\0';\
             CInterfaceExcept.strErrorMsg += \", Request timeout fired\";\
        }\
        else\
        {\
             CInterfaceExcept.strErrorMsg[CInterfaceExcept.strErrorMsg.length()-1] = '\\0';\
             CInterfaceExcept.strErrorMsg += \", Communication broken\";\
        }\
    }\
    // =============================================================\
    // Leave critical section\
    try\
    {\
        cThreadSaveClientSemaphore.vUnblock(ulBlockHandle);\
    }\
    catch (...)\
    {\
        priv_strError = \"Semaphore failed UNBLOCK\";\
        CInterfaceExcept.strErrorMsg = priv_strError;\
        CInterfaceExcept._operation_state = 2;\
        __usInternalError = 1;\
    }\
    // =============================================================\
    // Return return value\
    return priv_ulRoundTripDelayMSecRounded;\
}\
\
/***********************************************************************\
 *  class     �Interface�_client\
 *  function  v�Interface�ResetServer\
 ***********************************************************************/\
/*!           Method to reset the server\
 *  \\param   -\
 *  \\return  -\
 ***********************************************************************/\
/*  author    Alexander Neidhardt\
 *  date      14.05.2007\
 *  revision  -\
 *  info      Part of the idl2rpc.pl - generator!\
 ***********************************************************************/\
void �Interface�_client::v�Interface�ResetServer () throw (_interface_throw)\
{\
    // RPC-in/out-structures\
    void * vInput = NULL;\
    void * SOutput;\
    unsigned long ulBlockHandle = 0;\
    unsigned short __usInternalError = 0;\
    _interface_throw CInterfaceExcept;\
    // =============================================================\
    // Start round trip delay measuring
    v�Interface�StartTimer ();
    // =============================================================\
    // Change transport protocol because reset only works with TCP
    if (_usSetTransportProtocol (1))
    {
        priv_strError = \"Transport protocol change failed\";\
        CInterfaceExcept.strErrorMsg = priv_strError;\
        CInterfaceExcept._operation_state = 2;\
        __usInternalError = 1;\
        goto v�Interface�ResetServer_Return;\
    }
    // =============================================================\
    // Enter critical section\
    try\
    {\
        cThreadSaveClientSemaphore.vBlock(ulBlockHandle);\
    }\
    catch (...)\
    {\
        priv_strError = \"Semaphore failed BLOCK\";\
        CInterfaceExcept.strErrorMsg = priv_strError;\
        CInterfaceExcept._operation_state = 2;\
        __usInternalError = 1;\
        goto v�Interface�ResetServer_Return;\
    }\
    // =============================================================\
    // Check if interface is usable\
    if (!us�Interface�IsClientConnected ())\
    {\
        if (priv_strServerIP.length() > 0)\
        {\
            // Try to open interface\
            try\
            {\
               us�Interface�OpenInterfaceIntern (priv_strServerIP);\
            }\
            catch (_interface_throw CInterfaceException)\
            {\
                CInterfaceExcept = CInterfaceException;\
                priv_strError = CInterfaceExcept.strErrorMsg;\
                __usInternalError = 1;\
                goto v�Interface�ResetServer_Return;\
            }\
        }\
        else\
        {\
            priv_strError = \"No IP saved for reopen\";\
            CInterfaceExcept.strErrorMsg = priv_strError;\
            CInterfaceExcept._operation_state = 2;\
            __usInternalError = 1;\
            goto v�Interface�ResetServer_Return;\
        }\
    }\
    priv_ulRoundTripByteSum = 0;\
    // =============================================================\
    // Call RPC-functionality\
    if ((SOutput = sap_�InterfaceLC�_basicresetserver_1 (vInput, priv_pSClient)) == NULL)\
    {\
        priv_strError = clnt_spcreateerror (priv_strServerIP.c_str());\
        CInterfaceExcept.strErrorMsg = priv_strError;\
        CInterfaceExcept._operation_state = 2;\
        v�Interface�CloseInterfaceIntern (); // Close interface for a later reopen\
        __usInternalError = 2;\
        goto v�Interface�ResetServer_Return;\
    }\
    // =============================================================\
    // Return jump point\
    v�Interface�ResetServer_Return:
    // =============================================================\
    // Stop round trip delay measuring
    v�Interface�StopTimer ();
    // Check timeout situations\
    if (__usInternalError == 2)\
    {\
        if (((unsigned long)priv_RequestTimeout.tv_sec < priv_ulRoundTripDelaySec) ||\
            ((unsigned long)priv_RequestTimeout.tv_sec == priv_ulRoundTripDelaySec &&\
             (unsigned long)priv_RequestTimeout.tv_usec <= priv_ulRoundTripDelayUSec))\
        {\
             CInterfaceExcept.strErrorMsg[CInterfaceExcept.strErrorMsg.length()-1] = '\\0';\
             CInterfaceExcept.strErrorMsg += \", Request timeout fired\";\
        }\
        else\
        {\
             CInterfaceExcept.strErrorMsg[CInterfaceExcept.strErrorMsg.length()-1] = '\\0';\
             CInterfaceExcept.strErrorMsg += \", Communication broken\";\
        }\
    }\
    // =============================================================\
    // Leave critical section\
    try\
    {\
        cThreadSaveClientSemaphore.vUnblock(ulBlockHandle);\
    }\
    catch (...)\
    {\
        priv_strError = \"Semaphore failed UNBLOCK\";\
        CInterfaceExcept.strErrorMsg = priv_strError;\
        CInterfaceExcept._operation_state = 2;\
        __usInternalError = 1;\
    }\
    // =============================================================\
    // Return return value\
    return;\
}\
\
/***********************************************************************\
 *  class     �Interface�_client\
 *  function  us�Interface�CheckIDLVersion\
 ***********************************************************************/\
/*!           Method to check IDL and interface version at server\
 *  \\param   -\
 *  \\return  unsigned short <- Answer (0=versions not equal, 1=versions equal)\
 ***********************************************************************/\
/*  author    Alexander Neidhardt\
 *  date      30.10.2008\
 *  revision  -\
 *  info      Part of the idl2rpc.pl - generator!\
 ***********************************************************************/\
unsigned short �Interface�_client::us�Interface�CheckIDLVersion () throw (_interface_throw)\
{\
    // RPC-in/out-structures
    unsigned long ulBlockHandle = 0;
    unsigned short __usInternalError = 0;
    _interface_throw CInterfaceExcept;
    INSAP_�Interface�CheckIDLVersionType SInput;
    OUTSAP_�Interface�CheckIDLVersionStruct * SOutput = NULL;
    std::string strIDL2RPCVersion = \"".$g_VersionDate."\";
    std::string strInterfaceVersion = \"�InterfaceVersion�\";
    // =============================================================
    // Variable init
    priv_strError = \"Everything ok\";
    CInterfaceExcept.strErrorMsg = priv_strError;
    CInterfaceExcept._operation_state = 0;
    // =============================================================
    // Start round trip delay measuring
    v�Interface�StartTimer ();
    // =============================================================
    // Enter critical section
    try
    {
        cThreadSaveClientSemaphore.vBlock(ulBlockHandle);
    }
    catch (...)
    {
        priv_strError = \"Semaphore failed BLOCK\";
        CInterfaceExcept.strErrorMsg = priv_strError;
        CInterfaceExcept._operation_state = 2;
        __usInternalError = 1;
        goto sap_�Interface�_uscheckidlversion_1_Return;
    }
    // =============================================================
    // Check if interface is usable
    if (!us�Interface�IsClientConnected ())
    {
        if (priv_strServerIP.length() > 0)
        {
            // Try to open interface
            try
            {
               us�Interface�OpenInterfaceIntern (priv_strServerIP);
            }
            catch (_interface_throw CInterfaceException)
            {
                CInterfaceExcept = CInterfaceException;
                priv_strError = CInterfaceExcept.strErrorMsg;
                __usInternalError = 1;
                goto sap_�Interface�_uscheckidlversion_1_Return;
            }
        }
        else
        {
            priv_strError = \"No IP saved for reopen\";
            CInterfaceExcept.strErrorMsg = priv_strError;
            CInterfaceExcept._operation_state = 2;
            __usInternalError = 1;
            goto sap_�Interface�_uscheckidlversion_1_Return;
        }
    }
    priv_ulRoundTripByteSum = 0;\
    // =============================================================
    // Fill in-structure
    SInput.strIDL2RPCVersion.strIDL2RPCVersion_val = (char *) strIDL2RPCVersion.c_str();
    SInput.strIDL2RPCVersion.strIDL2RPCVersion_len = strIDL2RPCVersion.length()+1;
    priv_ulRoundTripByteSum += ((strIDL2RPCVersion.length()+1)*sizeof(char));
    SInput.strInterfaceVersion.strInterfaceVersion_val = (char *) strInterfaceVersion.c_str();
    SInput.strInterfaceVersion.strInterfaceVersion_len = strInterfaceVersion.length()+1;
    priv_ulRoundTripByteSum += ((strInterfaceVersion.length()+1)*sizeof(char));
    // =============================================================
    // Check if transfer size fits to used transport protocol
    if (priv_usTransportProtocol != 1 && priv_ulRoundTripByteSum > _MAXROUNDTRIPBYTESUM)
    {
        priv_strError = \"Wrong transport protocol for transfer data volume\";
        CInterfaceExcept.strErrorMsg = priv_strError;
        CInterfaceExcept._operation_state = 1;
        __usInternalError = 1;
        goto sap_�Interface�_uscheckidlversion_1_Return;
    }
    // Call RPC-functionality
    if ((SOutput = sap_�InterfaceLC�_basiccheckidlversion_1 (&SInput, priv_pSClient)) == NULL)
    {
        priv_strError = clnt_spcreateerror (priv_strServerIP.c_str());
        CInterfaceExcept.strErrorMsg = priv_strError;
        CInterfaceExcept._operation_state = 2;
        v�Interface�CloseInterfaceIntern (); // Close interface for a later reopen
        __usInternalError = 2;
        goto sap_�Interface�_uscheckidlversion_1_Return;
    }
    if (SOutput->_operation_state != 0)
    {
        priv_strError = \"Operation state error detected\";
        CInterfaceExcept.strErrorMsg = priv_strError;
        CInterfaceExcept._operation_state = SOutput->_operation_state;
        __usInternalError = 1;
        goto sap_�Interface�_uscheckidlversion_1_Return;
    }
    // =============================================================
    // Set parameter return
    if (SOutput != NULL &&
        SOutput->strIDL2RPCVersion.strIDL2RPCVersion_val != NULL)
    {
        priv_ulRoundTripByteSum += SOutput->strIDL2RPCVersion.strIDL2RPCVersion_len;
    }
    priv_ulRoundTripByteSum += sizeof(int);
    if (SOutput != NULL &&
        SOutput->strInterfaceVersion.strInterfaceVersion_val != NULL)
    {
        priv_ulRoundTripByteSum += SOutput->strInterfaceVersion.strInterfaceVersion_len;
    }
    priv_ulRoundTripByteSum += sizeof(int);
    priv_ulRoundTripByteSum += sizeof(int);
    // =============================================================
    // Return jump point
    sap_�Interface�_uscheckidlversion_1_Return:
    // =============================================================
    // Stop round trip delay measuring
    v�Interface�StopTimer ();
    // Check timeout situations
    if (__usInternalError == 2)
    {
        if (((unsigned long)priv_RequestTimeout.tv_sec < priv_ulRoundTripDelaySec) ||
            ((unsigned long)priv_RequestTimeout.tv_sec == priv_ulRoundTripDelaySec &&
             (unsigned long)priv_RequestTimeout.tv_usec <= priv_ulRoundTripDelayUSec))
        {
             CInterfaceExcept.strErrorMsg[CInterfaceExcept.strErrorMsg.length()-1] = '\\0';
             CInterfaceExcept.strErrorMsg += \", Request timeout fired\";
        }
        else
        {
             CInterfaceExcept.strErrorMsg[CInterfaceExcept.strErrorMsg.length()-1] = '\\0';
             CInterfaceExcept.strErrorMsg += \", Communication broken\";
        }
    }
    // =============================================================
    // Leave critical section
    try
    {
        cThreadSaveClientSemaphore.vUnblock(ulBlockHandle);
    }
    catch (...)
    {
        priv_strError = \"Semaphore failed UNBLOCK\";
        CInterfaceExcept.strErrorMsg = priv_strError;
        CInterfaceExcept._operation_state = 2;
        __usInternalError = 1;
    }
    // =============================================================
    // Clean up 
    if (SOutput != NULL &&
        SOutput->strIDL2RPCVersion.strIDL2RPCVersion_val != NULL)
    {
        free (SOutput->strIDL2RPCVersion.strIDL2RPCVersion_val);
        SOutput->strIDL2RPCVersion.strIDL2RPCVersion_val = NULL;
        SOutput->strIDL2RPCVersion.strIDL2RPCVersion_len = 0;
    }
    if (SOutput != NULL &&
        SOutput->strInterfaceVersion.strInterfaceVersion_val != NULL)
    {
        free (SOutput->strInterfaceVersion.strInterfaceVersion_val);
        SOutput->strInterfaceVersion.strInterfaceVersion_val = NULL;
        SOutput->strInterfaceVersion.strInterfaceVersion_len = 0;
    }
    if (__usInternalError)
    {
    }
    // =============================================================
    // Throw exception if necessary 
    if (__usInternalError)
    {
        throw CInterfaceExcept;
    }
    // =============================================================
    // Return return value
    return SOutput->_Ret;
}\
\
/***********************************************************************\
 *  class     �Interface�_client\
 *  function  us�Interface�CheckIDLVersion\
 ***********************************************************************/\
/*!           Method to check IDL and interface version at server\
 *  \\param   std::string & strIDL2RPCVersion <- IDL2RPC version of server\
 *  \\param   int & iIDL2RPCVersionOK <- IDL2RPC version fits to client version\
 *  \\param   std::string & strInterfaceVersion <- interface version of server\
 *  \\param   int & iInterfaceVersionOK <- interface version fits to client version\
 *  \\return  unsigned short <- Answer (0=versions not equal, 1=versions equal)\
 ***********************************************************************/\
/*  author    Alexander Neidhardt\
 *  date      30.10.2008\
 *  revision  -\
 *  info      Part of the idl2rpc.pl - generator!\
 ***********************************************************************/\
unsigned short �Interface�_client::us�Interface�CheckIDLVersion (std::string & strIDL2RPCVersion, \
                                                                 int & iIDL2RPCVersionOK,\
                                                                 std::string & strInterfaceVersion, \
                                                                 int & iInterfaceVersionOK) throw (_interface_throw)\
{\
    // RPC-in/out-structures
    unsigned long ulBlockHandle = 0;
    unsigned short __usInternalError = 0;
    _interface_throw CInterfaceExcept;
    INSAP_�Interface�CheckIDLVersionType SInput;
    OUTSAP_�Interface�CheckIDLVersionStruct * SOutput = NULL;
    std::string strClientIDL2RPCVersion = \"".$g_VersionDate."\";
    std::string strClientInterfaceVersion = \"�InterfaceVersion�\";
    // =============================================================
    // Variable init
    priv_strError = \"Everything ok\";
    CInterfaceExcept.strErrorMsg = priv_strError;
    CInterfaceExcept._operation_state = 0;
    strIDL2RPCVersion = \"\";
    strInterfaceVersion = \"\";
    // =============================================================
    // Start round trip delay measuring
    v�Interface�StartTimer ();
    // =============================================================
    // Enter critical section
    try
    {
        cThreadSaveClientSemaphore.vBlock(ulBlockHandle);
    }
    catch (...)
    {
        priv_strError = \"Semaphore failed BLOCK\";
        CInterfaceExcept.strErrorMsg = priv_strError;
        CInterfaceExcept._operation_state = 2;
        __usInternalError = 1;
        goto sap_�Interface�_uscheckidlversion_1_Return;
    }
    // =============================================================
    // Check if interface is usable
    if (!us�Interface�IsClientConnected ())
    {
        if (priv_strServerIP.length() > 0)
        {
            // Try to open interface
            try
            {
               us�Interface�OpenInterfaceIntern (priv_strServerIP);
            }
            catch (_interface_throw CInterfaceException)
            {
                CInterfaceExcept = CInterfaceException;
                priv_strError = CInterfaceExcept.strErrorMsg;
                __usInternalError = 1;
                goto sap_�Interface�_uscheckidlversion_1_Return;
            }
        }
        else
        {
            priv_strError = \"No IP saved for reopen\";
            CInterfaceExcept.strErrorMsg = priv_strError;
            CInterfaceExcept._operation_state = 2;
            __usInternalError = 1;
            goto sap_�Interface�_uscheckidlversion_1_Return;
        }
    }
    priv_ulRoundTripByteSum = 0;\
    // =============================================================
    // Fill in-structure
    SInput.strIDL2RPCVersion.strIDL2RPCVersion_val = (char *) strClientIDL2RPCVersion.c_str();
    SInput.strIDL2RPCVersion.strIDL2RPCVersion_len = strClientIDL2RPCVersion.length()+1;
    priv_ulRoundTripByteSum += ((strClientIDL2RPCVersion.length()+1)*sizeof(char));
    SInput.strInterfaceVersion.strInterfaceVersion_val = (char *) strClientInterfaceVersion.c_str();
    SInput.strInterfaceVersion.strInterfaceVersion_len = strClientInterfaceVersion.length()+1;
    priv_ulRoundTripByteSum += ((strClientInterfaceVersion.length()+1)*sizeof(char));
    // =============================================================
    // Check if transfer size fits to used transport protocol
    if (priv_usTransportProtocol != 1 && priv_ulRoundTripByteSum > _MAXROUNDTRIPBYTESUM)
    {
        priv_strError = \"Wrong transport protocol for transfer data volume\";
        CInterfaceExcept.strErrorMsg = priv_strError;
        CInterfaceExcept._operation_state = 1;
        __usInternalError = 1;
        goto sap_�Interface�_uscheckidlversion_1_Return;
    }
    // Call RPC-functionality
    if ((SOutput = sap_�InterfaceLC�_basiccheckidlversion_1 (&SInput, priv_pSClient)) == NULL)
    {
        priv_strError = clnt_spcreateerror (priv_strServerIP.c_str());
        CInterfaceExcept.strErrorMsg = priv_strError;
        CInterfaceExcept._operation_state = 2;
        v�Interface�CloseInterfaceIntern (); // Close interface for a later reopen
        __usInternalError = 2;
        goto sap_�Interface�_uscheckidlversion_1_Return;
    }
    if (SOutput->_operation_state != 0)
    {
        priv_strError = \"Operation state error detected\";
        CInterfaceExcept.strErrorMsg = priv_strError;
        CInterfaceExcept._operation_state = SOutput->_operation_state;
        __usInternalError = 1;
        goto sap_�Interface�_uscheckidlversion_1_Return;
    }
    // =============================================================
    // Set parameter return
    try
    {
        if (SOutput != NULL &&
            SOutput->strIDL2RPCVersion.strIDL2RPCVersion_val != NULL)
        {
            strIDL2RPCVersion = SOutput->strIDL2RPCVersion.strIDL2RPCVersion_val;
            priv_ulRoundTripByteSum += SOutput->strIDL2RPCVersion.strIDL2RPCVersion_len;
        }
        iIDL2RPCVersionOK = SOutput->iIDL2RPCVersionOK;
        priv_ulRoundTripByteSum += sizeof(int);
        if (SOutput != NULL &&
            SOutput->strInterfaceVersion.strInterfaceVersion_val != NULL)
        {
            strInterfaceVersion = SOutput->strInterfaceVersion.strInterfaceVersion_val;
            priv_ulRoundTripByteSum += SOutput->strInterfaceVersion.strInterfaceVersion_len;
        }
        iInterfaceVersionOK = SOutput->iInterfaceVersionOK;
        priv_ulRoundTripByteSum += sizeof(int);
        priv_ulRoundTripByteSum += sizeof(int);
    }
    catch (...)
    {
        priv_strError = \"String copy error\";
        CInterfaceExcept.strErrorMsg = priv_strError;
        CInterfaceExcept._operation_state = 3;
        __usInternalError = 1;
        goto sap_�Interface�_uscheckidlversion_1_Return;
    }
    // =============================================================
    // Return jump point
    sap_�Interface�_uscheckidlversion_1_Return:
    // =============================================================
    // Stop round trip delay measuring
    v�Interface�StopTimer ();
    // Check timeout situations
    if (__usInternalError == 2)
    {
        if (((unsigned long)priv_RequestTimeout.tv_sec < priv_ulRoundTripDelaySec) ||
            ((unsigned long)priv_RequestTimeout.tv_sec == priv_ulRoundTripDelaySec &&
             (unsigned long)priv_RequestTimeout.tv_usec <= priv_ulRoundTripDelayUSec))
        {
             CInterfaceExcept.strErrorMsg[CInterfaceExcept.strErrorMsg.length()-1] = '\\0';
             CInterfaceExcept.strErrorMsg += \", Request timeout fired\";
        }
        else
        {
             CInterfaceExcept.strErrorMsg[CInterfaceExcept.strErrorMsg.length()-1] = '\\0';
             CInterfaceExcept.strErrorMsg += \", Communication broken\";
        }
    }
    // =============================================================
    // Leave critical section
    try
    {
        cThreadSaveClientSemaphore.vUnblock(ulBlockHandle);
    }
    catch (...)
    {
        priv_strError = \"Semaphore failed UNBLOCK\";
        CInterfaceExcept.strErrorMsg = priv_strError;
        CInterfaceExcept._operation_state = 2;
        __usInternalError = 1;
    }
    // =============================================================
    // Clean up 
    if (SOutput != NULL &&
        SOutput->strIDL2RPCVersion.strIDL2RPCVersion_val != NULL)
    {
        free (SOutput->strIDL2RPCVersion.strIDL2RPCVersion_val);
        SOutput->strIDL2RPCVersion.strIDL2RPCVersion_val = NULL;
        SOutput->strIDL2RPCVersion.strIDL2RPCVersion_len = 0;
    }
    if (SOutput != NULL &&
        SOutput->strInterfaceVersion.strInterfaceVersion_val != NULL)
    {
        free (SOutput->strInterfaceVersion.strInterfaceVersion_val);
        SOutput->strInterfaceVersion.strInterfaceVersion_val = NULL;
        SOutput->strInterfaceVersion.strInterfaceVersion_len = 0;
    }
    if (__usInternalError)
    {
    }
    // =============================================================
    // Throw exception if necessary 
    if (__usInternalError)
    {
        throw CInterfaceExcept;
    }
    // =============================================================
    // Return return value
    return SOutput->_Ret;
}\
\
/***********************************************************************\
 *  class     �Interface�_client\
 *  function  ul�Interface�GetRoundTripDelay\
 ***********************************************************************/\
/*!           Return round trip delay in milliseconds\
 *  \\param   -\
 *  \\return  unsigned long <- Round trip delay millisec\
 ***********************************************************************/\
/*  author    Alexander Neidhardt\
 *  date      14.05.2007\
 *  revision  -\
 *  info      Part of the idl2rpc.pl - generator!\
 ***********************************************************************/\
unsigned long �Interface�_client::ul�Interface�GetRoundTripDelay ()\
{\
    return priv_ulRoundTripDelayMSecRounded;\
}\
\
/***********************************************************************\
 *  class     �Interface�_client\
 *  function  ul�Interface�GetRoundTripDelay\
 ***********************************************************************/\
/*!           Return round trip delay in microseconds\
 *  \\param   unsigned long & ulSec <- Round trip delay sec\
 *  \\param   unsigned long & ulUSec <- Round trip delay microsec\
 *  \\return  unsigned long <- Round trip delay millisec\
 ***********************************************************************/\
/*  author    Alexander Neidhardt\
 *  date      14.05.2007\
 *  revision  -\
 *  info      Part of the idl2rpc.pl - generator!\
 ***********************************************************************/\
unsigned long �Interface�_client::ul�Interface�GetRoundTripDelay (unsigned long & ulSec, unsigned long & ulUSec)\
{\
    ulSec = priv_ulRoundTripDelaySec;\
    ulUSec = priv_ulRoundTripDelayUSec;\
    return priv_ulRoundTripDelayMSecRounded;\
}\
\
/***********************************************************************\
 *  class     �Interface�_client\
 *  function  d�Interface�GetRoundTripDataRate\
 ***********************************************************************/\
/*!           Return round trip data rate in bytes per second\
 *  \\param   -\
 *  \\return  double <- Round trip data rate in bytes per second\
 ***********************************************************************/\
/*  author    Alexander Neidhardt\
 *  date      15.12.2008\
 *  revision  -\
 *  info      Part of the idl2rpc.pl - generator!\
 ***********************************************************************/\
double �Interface�_client::d�Interface�GetRoundTripDataRate ()\
{\
    double dDataRate = 0.0;\
    if (priv_ulRoundTripByteSum != 0)\
    {\
        dDataRate = ((double)priv_ulRoundTripByteSum)/(((double)priv_ulRoundTripDelaySec)+((double)priv_ulRoundTripDelayUSec/1000000.0));\
    }\
    return dDataRate;
}\
\
/***********************************************************************\
 *  class     �Interface�_client\
 *  function  us�Interface�GetRequestTimeout\
 ***********************************************************************/\
/*!           Return settings for request timeout\
 *  \\param   unsigned long & ulSec <- Sec\
 *  \\param   unsigned long & ulUSec <- Microsec\
 *  \\return  unsigned short <- Errorcode (0=ok, 1=error)\
 ***********************************************************************/\
/*  author    Alexander Neidhardt\
 *  date      14.05.2007\
 *  revision  -\
 *  info      Part of the idl2rpc.pl - generator!\
 ***********************************************************************/\
unsigned short �Interface�_client::us�Interface�GetRequestTimeout (unsigned long & ulSec, unsigned long & ulUSec)\
{\
    ulSec = priv_RequestTimeout.tv_sec;\
    ulUSec = priv_RequestTimeout.tv_usec;\
    \
    return 0;\
}\
\
/***********************************************************************\
 *  class     �Interface�_client\
 *  function  us�Interface�SetRequestTimeout\
 ***********************************************************************/\
/*!           Set settings for request timeout\
 *  \\param   unsigned long ulSec -> Sec\
 *  \\param   unsigned long ulUSec -> Microsec\
 *  \\return  unsigned short <- Errorcode (0=ok, 1=error)\
 ***********************************************************************/\
/*  author    Alexander Neidhardt\
 *  date      14.05.2007\
 *  revision  -\
 *  info      Part of the idl2rpc.pl - generator!\
 ***********************************************************************/\
unsigned short �Interface�_client::us�Interface�SetRequestTimeout (unsigned long ulSec, unsigned long ulUSec)\
{\
    priv_RequestTimeout.tv_sec = ulSec;\
    priv_RequestTimeout.tv_usec = ulUSec;\
    \
    if (us�Interface�IsClientConnected ())\
    {\
        if (!clnt_control (priv_pSClient, CLSET_TIMEOUT, (char *)&priv_RequestTimeout))\
        {\
            priv_strError = \"Can't set request timeout information\";\
            return 1;\
        }\
    }\
    return 0;\
}\
\
/***********************************************************************\
 *  class     �Interface�_client\
 *  function  us�Interface�GetRetryTimeout\
 ***********************************************************************/\
/*!           Return settings for retry timeout (UDP)\
 *  \\param   unsigned long & ulSec <- Sec\
 *  \\param   unsigned long & ulUSec <- Microsec\
 *  \\return  unsigned short <- Errorcode (0=ok, 1=error)\
 ***********************************************************************/\
/*  author    Alexander Neidhardt\
 *  date      14.05.2007\
 *  revision  -\
 *  info      Part of the idl2rpc.pl - generator!\
 ***********************************************************************/\
unsigned short �Interface�_client::us�Interface�GetRetryTimeout (unsigned long & ulSec, unsigned long & ulUSec)\
{\
    ulSec = priv_RetryTimeout.tv_sec;\
    ulUSec = priv_RetryTimeout.tv_usec;\
    \
    return 0;\
}\
\
/***********************************************************************\
 *  class     �Interface�_client\
 *  function  us�Interface�SetRetryTimeout\
 ***********************************************************************/\
/*!           Set settings for retry timeout (UDP)\
 *  \\param   unsigned long ulSec -> Sec\
 *  \\param   unsigned long ulUSec -> Microsec\
 *  \\return  unsigned short <- Errorcode (0=ok, 1=error)\
 ***********************************************************************/\
/*  author    Alexander Neidhardt\
 *  date      14.05.2007\
 *  revision  -\
 *  info      Part of the idl2rpc.pl - generator!\
 ***********************************************************************/\
unsigned short �Interface�_client::us�Interface�SetRetryTimeout (unsigned long ulSec, unsigned long ulUSec)\
{\
    priv_RetryTimeout.tv_sec = ulSec;\
    priv_RetryTimeout.tv_usec = ulUSec;\
    \
    if (us�Interface�IsClientConnected ())\
    {\
        if (!clnt_control (priv_pSClient, CLSET_RETRY_TIMEOUT, (char *)&priv_RetryTimeout))\
        {\
            priv_strError = \"Can't set retry timeout information\";\
            return 1;\
        }\
    }\
    \
    return 0;\
}\
\
/***********************************************************************\
 *  class     �Interface�_client\
 *  function  us�Interface�GetTransportProtocol\
 ***********************************************************************/\
/*!           Return settings for transport protocol\
 *  \\param   unsigned short & usProtocolID <- Protocol ID (0=UDP, 1=TCP)\
 *  \\return  unsigned short <- Errorcode (0=ok, 1=error)\
 ***********************************************************************/\
/*  author    Alexander Neidhardt\
 *  date      14.05.2007\
 *  revision  -\
 *  info      Part of the idl2rpc.pl - generator!\
 ***********************************************************************/\
unsigned short �Interface�_client::us�Interface�GetTransportProtocol (unsigned short & usProtocolID)\
{\
    usProtocolID = priv_usTransportProtocol;\
    return 0;\
}\
\
/***********************************************************************\
 *  class     �Interface�_client\
 *  function  us�Interface�SetTransportProtocol\
 ***********************************************************************/\
/*!           Set settings for transport protocol\
 *  \\param   unsigned short & usProtocolID -> Protocol ID (0=UDP, 1=TCP)\
 *  \\return  unsigned short <- Errorcode (0=ok, 1=error)\
 ***********************************************************************/\
/*  author    Alexander Neidhardt\
 *  date      12.12.2008\
 *  revision  -\
 *  info      Part of the idl2rpc.pl - generator!\
 ***********************************************************************/\
unsigned short �Interface�_client::us�Interface�SetTransportProtocol (unsigned short usProtocolID)\
{\
    unsigned short usReopen = 0;\
    \
    if (us�Interface�IsClientConnected ())\
    {\
        try\
        {\
            v�Interface�CloseInterfaceIntern ();
        }\
        catch (_interface_throw CInterfaceExcept)\
        {\
            return 1;\
        }\
        usReopen = 1;\
    }\
    \
    priv_usTransportProtocol = usProtocolID;\
    \
    if (usReopen == 1)\
    {\
        try\
        {\
            us�Interface�OpenInterfaceIntern (priv_strServerIP);\
        }\
        catch (_interface_throw CInterfaceExcept)\
        {\
            return 1;\
        }\
    }\
    \
    return 0;\
}\
\
/***********************************************************************\
 *  class     �Interface�_client\
 *  function  us�Interface�GetTCPPort\
 ***********************************************************************/\
/*!           Get settings for TCP port\
 *  \\param   unsigned int & uiTCPPort <- Port\
 *  \\return  unsigned short <- Errorcode (0=ok, 1=error)\
 ***********************************************************************/\
/*  author    Alexander Neidhardt\
 *  date      12.12.2008\
 *  revision  -\
 *  info      Part of the idl2rpc.pl - generator!\
 ***********************************************************************/\
unsigned short �Interface�_client::us�Interface�GetTCPPort (unsigned int & uiTCPPort)\
{\
    uiTCPPort = priv_uiFixedTCPPort;
    return 0;
}\
\
/***********************************************************************\
 *  class     �Interface�_client\
 *  function  us�Interface�SetTCPPort\
 ***********************************************************************/\
/*!           Set settings for TCP port and reconnect if connection is open\
 *  \\param   unsigned int uiTCPPort -> Port\
 *  \\return  unsigned short <- Errorcode (0=ok, 1=error)\
 ***********************************************************************/\
/*  author    Alexander Neidhardt\
 *  date      12.12.2008\
 *  revision  -\
 *  info      Part of the idl2rpc.pl - generator!\
 ***********************************************************************/\
unsigned short �Interface�_client::us�Interface�SetTCPPort (unsigned int uiTCPPort)\
{\
    unsigned short usIsConnectedMarker = _usIsClientConnected ();\
    \
    if (usIsConnectedMarker)\
    {\
        try\
        {\
            v�Interface�CloseInterface ();\
        }\
        catch (_interface_throw CInterfaceException)\
        {\
            priv_strError = CInterfaceException.strErrorMsg;\
            return 1;\
        }\
    }\
    \
    priv_uiFixedTCPPort = uiTCPPort;\
    \
    if (usIsConnectedMarker)\
    {\
        try\
        {\
           us�Interface�OpenInterfaceIntern (priv_strServerIP);\
        }\
        catch (_interface_throw CInterfaceException)\
        {\
            priv_strError = CInterfaceException.strErrorMsg;\
            return 1;\
        }\
    }\
    \
    return 0;\
}\
\
/***********************************************************************\
 *  class     �Interface�_client\
 *  function  us�Interface�GetUDPPort\
 ***********************************************************************/\
/*!           Get settings for UDP port\
 *  \\param   unsigned int & uiUDPPort <- Port\
 *  \\return  unsigned short <- Errorcode (0=ok, 1=error)\
 ***********************************************************************/\
/*  author    Alexander Neidhardt\
 *  date      12.12.2008\
 *  revision  -\
 *  info      Part of the idl2rpc.pl - generator!\
 ***********************************************************************/\
unsigned short �Interface�_client::us�Interface�GetUDPPort (unsigned int & uiUDPPort)\
{\
    uiUDPPort = priv_uiFixedUDPPort;
    return 0;
}\
\
/***********************************************************************\
 *  class     �Interface�_client\
 *  function  us�Interface�SetUDPPort\
 ***********************************************************************/\
/*!           Set settings for UDP port and reconnect if connection is open\
 *  \\param   unsigned int uiUDPPort -> Port\
 *  \\return  unsigned short <- Errorcode (0=ok, 1=error)\
 ***********************************************************************/\
/*  author    Alexander Neidhardt\
 *  date      12.12.2008\
 *  revision  -\
 *  info      Part of the idl2rpc.pl - generator!\
 ***********************************************************************/\
unsigned short �Interface�_client::us�Interface�SetUDPPort (unsigned int uiUDPPort)\
{\
    unsigned short usIsConnectedMarker = _usIsClientConnected ();\
    \
    if (usIsConnectedMarker)\
    {\
        try\
        {\
            v�Interface�CloseInterface ();\
        }\
        catch (_interface_throw CInterfaceException)\
        {\
            priv_strError = CInterfaceException.strErrorMsg;\
            return 1;\
        }\
    }\
    \
    priv_uiFixedUDPPort = uiUDPPort;\
    \
    if (usIsConnectedMarker)\
    {\
        try\
        {\
           us�Interface�OpenInterfaceIntern (priv_strServerIP);\
        }\
        catch (_interface_throw CInterfaceException)\
        {\
            priv_strError = CInterfaceException.strErrorMsg;\
            return 1;\
        }\
    }\
    \
    return 0;\
}\
\
/***********************************************************************\
 *  class     �Interface�_client\
 *  function  _usOpenInterface\
 ***********************************************************************/\
/*!           Open interface (with thread save semaphore)\
 *  \\param   std::string strNewServerIP -> Server IP to connect with\
 *  \\return  unsigned short <- Errorcode (0=ok, 1=error)\
 ***********************************************************************/\
/*  author    Alexander Neidhardt\
 *  date      14.05.2007\
 *  revision  -\
 *  info      Part of the idl2rpc.pl - generator!\
 ***********************************************************************/\
unsigned short �Interface�_client::_usOpenInterface (std::string strNewServerIP) throw (_interface_throw)\
{\
    unsigned short usRetVal = 0;\
    \
    try\
    {\
        if ((usRetVal = us�Interface�OpenInterface (strNewServerIP)) != 0)\
            return usRetVal;\
    }\
    catch (_interface_throw CInterfaceExcept)\
    {\
        throw CInterfaceExcept;\
    }\
    catch (...)\
    {\
        _interface_throw CInterfaceExcept;\
        priv_strError = \"Unknown error\";\
        CInterfaceExcept.strErrorMsg = priv_strError;\
        CInterfaceExcept._operation_state = 2;\
        throw CInterfaceExcept;\
    }\
    \
    return 0;\
}\
\
/***********************************************************************\
 *  class     �Interface�_client\
 *  function  _vCloseInterface\
 ***********************************************************************/\
/*!           Close interface (with thread save semaphore)\
 *  \\param   -\
 *  \\return  -\
 ***********************************************************************/\
/*  author    Alexander Neidhardt\
 *  date      14.05.2007\
 *  revision  -\
 *  info      Part of the idl2rpc.pl - generator!\
 ***********************************************************************/\
void �Interface�_client::_vCloseInterface () throw (_interface_throw)\
{\
    try\
    {\
        v�Interface�CloseInterface ();\
    }\
    catch (_interface_throw CInterfaceExcept)\
    {\
        throw CInterfaceExcept;\
    }\
    catch (...)\
    {\
        _interface_throw CInterfaceExcept;\
        priv_strError = \"Unknown error\";\
        CInterfaceExcept.strErrorMsg = priv_strError;\
        CInterfaceExcept._operation_state = 2;\
        throw CInterfaceExcept;\
    }\
    \
}\
\
/***********************************************************************\
 *  class     �Interface�_client\
 *  function  _usIsClientConnected\
 ***********************************************************************/\
/*!           Check if interface is opened \
 *  \\param   -\
 *  \\return  unsigned short <- Answer (0=no, 1=yes)\
 ***********************************************************************/\
/*  author    Alexander Neidhardt\
 *  date      14.05.2007\
 *  revision  -\
 *  info      Part of the idl2rpc.pl - generator!\
 ***********************************************************************/\
unsigned short �Interface�_client::_usIsClientConnected ()\
{\
    unsigned short usRetVal = 0;\
    \
    try\
    {\
        usRetVal = us�Interface�IsClientConnected ();\
    }\
    catch (_interface_throw CInterfaceExcept)\
    {\
        throw CInterfaceExcept;\
    }\
    catch (...)\
    {\
        _interface_throw CInterfaceExcept;\
        priv_strError = \"Unknown error\";\
        CInterfaceExcept.strErrorMsg = priv_strError;\
        CInterfaceExcept._operation_state = 2;\
        throw CInterfaceExcept;\
    }\
    \
    return usRetVal;\
}\
\
/***********************************************************************\
 *  class     �Interface�_client\
 *  function  _strGetErrorMsg\
 ***********************************************************************/\
/*!           Return error last message\
 *  \\param   -\
 *  \\return  std::string <- Errormessage\
 ***********************************************************************/\
/*  author    Alexander Neidhardt\
 *  date      14.05.2007\
 *  revision  -\
 *  info      Part of the idl2rpc.pl - generator!\
 ***********************************************************************/\
std::string �Interface�_client::_strGetErrorMsg () throw (_interface_throw)\
{\
    try\
    {\
        return str�Interface�GetErrorMsg ();\
    }\
    catch (_interface_throw CInterfaceExcept)\
    {\
        throw CInterfaceExcept;\
    }\
    catch (...)\
    {\
        _interface_throw CInterfaceExcept;\
        priv_strError = \"Unknown error\";\
        CInterfaceExcept.strErrorMsg = priv_strError;\
        CInterfaceExcept._operation_state = 2;\
        throw CInterfaceExcept;\
    }\
    return priv_strError;\
}\
\
/***********************************************************************\
 *  class     �Interface�_client\
 *  function  _ulPing\
 ***********************************************************************/\
/*!           Method to ping the server\
 *  \\param   -\
 *  \\return  unsigned long <- Round trip delay of ping\
 ***********************************************************************/\
/*  author    Alexander Neidhardt\
 *  date      14.05.2007\
 *  revision  -\
 *  info      Part of the idl2rpc.pl - generator!\
 ***********************************************************************/\
unsigned long �Interface�_client::_ulPing () throw (_interface_throw)\
{\
    unsigned long ulRetVal = 0;\
    \
    try\
    {\
        ulRetVal = ul�Interface�Ping ();\
    }\
    catch (_interface_throw CInterfaceExcept)\
    {\
        throw CInterfaceExcept;\
    }\
    catch (...)\
    {\
        _interface_throw CInterfaceExcept;\
        priv_strError = \"Unknown error\";\
        CInterfaceExcept.strErrorMsg = priv_strError;\
        CInterfaceExcept._operation_state = 2;\
        throw CInterfaceExcept;\
    }\
    \
    return ulRetVal;\
}\
\
/***********************************************************************\
 *  class     �Interface�_client\
 *  function  _vResetServer\
 ***********************************************************************/\
/*!           Method to reset the server\
 *  \\param   -\
 *  \\return  -\
 ***********************************************************************/\
/*  author    Alexander Neidhardt\
 *  date      14.05.2007\
 *  revision  -\
 *  info      Part of the idl2rpc.pl - generator!\
 ***********************************************************************/\
void �Interface�_client::_vResetServer () throw (_interface_throw)\
{\
    try\
    {\
        v�Interface�ResetServer ();\
    }\
    catch (_interface_throw CInterfaceExcept)\
    {\
        throw CInterfaceExcept;\
    }\
    catch (...)\
    {\
        _interface_throw CInterfaceExcept;\
        priv_strError = \"Unknown error\";\
        CInterfaceExcept.strErrorMsg = priv_strError;\
        CInterfaceExcept._operation_state = 2;\
        throw CInterfaceExcept;\
    }\
}\
\
/***********************************************************************\
 *  class     �Interface�_client\
 *  function  _usCheckIDLVersion\
 ***********************************************************************/\
/*!           Method to check IDL and interface version at server\
 *  \\param   std::string & strIDL2RPCVersion <- IDL2RPC version of server\
 *  \\param   int & iIDL2RPCVersionOK <- IDL2RPC version fits to client version\
 *  \\param   std::string & strInterfaceVersion <- interface version of server\
 *  \\param   int & iInterfaceVersionOK <- interface version fits to client version\
 *  \\return  unsigned short <- Answer (0=Versions not equal, 1=Versions equal)\
 ***********************************************************************/\
/*  author    Alexander Neidhardt\
 *  date      30.10.2008\
 *  revision  -\
 *  info      Part of the idl2rpc.pl - generator!\
 ***********************************************************************/\
unsigned short �Interface�_client::_usCheckIDLVersion () throw (_interface_throw)\
{\
    unsigned short usRetVal = 0;\
    \
    try\
    {\
        usRetVal = us�Interface�CheckIDLVersion ();\
    }\
    catch (_interface_throw CInterfaceExcept)\
    {\
        throw CInterfaceExcept;\
    }\
    catch (...)\
    {\
        _interface_throw CInterfaceExcept;\
        priv_strError = \"Unknown error\";\
        CInterfaceExcept.strErrorMsg = priv_strError;\
        CInterfaceExcept._operation_state = 2;\
        throw CInterfaceExcept;\
    }\
    \
    return usRetVal;\
}\
\
/***********************************************************************\
 *  class     �Interface�_client\
 *  function  _usCheckIDLVersion\
 ***********************************************************************/\
/*!           Method to check IDL and interface version at server\
 *  \\param   -\
 *  \\return  unsigned short <- Answer (0=Versions not equal, 1=Versions equal)\
 ***********************************************************************/\
/*  author    Alexander Neidhardt\
 *  date      30.10.2008\
 *  revision  -\
 *  info      Part of the idl2rpc.pl - generator!\
 ***********************************************************************/\
unsigned short �Interface�_client::_usCheckIDLVersion (std::string & strIDL2RPCVersion, \
                                                       int & iIDL2RPCVersionOK,\
                                                       std::string & strInterfaceVersion, \
                                                       int & iInterfaceVersionOK) throw (_interface_throw)\
{\
    unsigned short usRetVal = 0;\
    \
    try\
    {\
        usRetVal = us�Interface�CheckIDLVersion (strIDL2RPCVersion, iIDL2RPCVersionOK, 
                                                 strInterfaceVersion, iInterfaceVersionOK);\
    }\
    catch (_interface_throw CInterfaceExcept)\
    {\
        throw CInterfaceExcept;\
    }\
    catch (...)\
    {\
        _interface_throw CInterfaceExcept;\
        priv_strError = \"Unknown error\";\
        CInterfaceExcept.strErrorMsg = priv_strError;\
        CInterfaceExcept._operation_state = 2;\
        throw CInterfaceExcept;\
    }\
    \
    return usRetVal;\
}\
\
/***********************************************************************\
 *  class     �Interface�_client\
 *  function  _ulGetRoundTripDelay\
 ***********************************************************************/\
/*!           Return round trip delay in milliseconds\
 *  \\param   -\
 *  \\return  unsigned long <- Round trip delay millisec\
 ***********************************************************************/\
/*  author    Alexander Neidhardt\
 *  date      14.05.2007\
 *  revision  -\
 *  info      Part of the idl2rpc.pl - generator!\
 ***********************************************************************/\
unsigned long �Interface�_client::_ulGetRoundTripDelay ()\
{\
    return ul�Interface�GetRoundTripDelay ();\
}\
\
/***********************************************************************\
 *  class     �Interface�_client\
 *  function  _ulGetRoundTripDelay\
 ***********************************************************************/\
/*!           Return round trip delay in microseconds\
 *  \\param   unsigned long & ulSec <- Round trip delay sec\
 *  \\param   unsigned long & ulUSec <- Round trip delay microsec\
 *  \\return  unsigned long <- Round trip delay millisec\
 ***********************************************************************/\
/*  author    Alexander Neidhardt\
 *  date      14.05.2007\
 *  revision  -\
 *  info      Part of the idl2rpc.pl - generator!\
 ***********************************************************************/\
unsigned long �Interface�_client::_ulGetRoundTripDelay (unsigned long & ulSec, unsigned long & ulUSec)\
{\
    return ul�Interface�GetRoundTripDelay (ulSec, ulUSec);\
}\
\
/***********************************************************************\
 *  class     �Interface�_client\
 *  function  _dGetRoundTripDataRate\
 ***********************************************************************/\
/*!           Return round trip data rate in bytes per second\
 *  \\param   -\
 *  \\return  double <- Round trip data rate in bytes per second\
 ***********************************************************************/\
/*  author    Alexander Neidhardt\
 *  date      15.12.2008\
 *  revision  -\
 *  info      Part of the idl2rpc.pl - generator!\
 ***********************************************************************/\
double �Interface�_client::_dGetRoundTripDataRate ()\
{\
    return d�Interface�GetRoundTripDataRate ();\
}\
\
/***********************************************************************\
 *  class     �Interface�_client\
 *  function  _dGetRoundTripDataRateNormalized\
 ***********************************************************************/\
/*!           Return round trip data rate in bytes per second\
 *  \\param   -\
 *  \\return  double <- Round trip data rate in bytes per second\
 ***********************************************************************/\
/*  author    Alexander Neidhardt\
 *  date      15.12.2008\
 *  revision  -\
 *  info      Part of the idl2rpc.pl - generator!\
 ***********************************************************************/\
double �Interface�_client::_dGetRoundTripDataRateNormalized (unsigned int uiPackageSizeInByte)\
{\
    unsigned long ulSec;\
    unsigned long ulUSec;\
    unsigned long ulNumberOfByte;\
    unsigned long ulNumberOfFrames;\
    unsigned long ulRest;\
    \
    (void) ul�Interface�GetRoundTripDelay (ulSec, ulUSec);\
    ulNumberOfByte = ((unsigned long)(d�Interface�GetRoundTripDataRate ()*\
                     (((double)ulSec)+((double)ulUSec/1000000.0))));\
    ulNumberOfFrames = ulNumberOfByte/uiPackageSizeInByte;\
    ulRest = ulNumberOfByte\%uiPackageSizeInByte;\
    if (ulRest)\
        ulNumberOfFrames++;\
    return ((double)(ulNumberOfFrames*uiPackageSizeInByte))/\
           (((double)ulSec)+((double)ulUSec/1000000.0));\
}\
\
/***********************************************************************\
 *  class     �Interface�_client\
 *  function  _usGetRequestTimeout\
 ***********************************************************************/\
/*!           Return settings for request timeout\
 *  \\param   unsigned long & ulSec <- Sec\
 *  \\param   unsigned long & ulUSec <- Microsec\
 *  \\return  unsigned short <- Errorcode (0=ok, 1=error)\
 ***********************************************************************/\
/*  author    Alexander Neidhardt\
 *  date      14.05.2007\
 *  revision  -\
 *  info      Part of the idl2rpc.pl - generator!\
 ***********************************************************************/\
unsigned short �Interface�_client::_usGetRequestTimeout (unsigned long & ulSec, unsigned long & ulUSec)\
{\
    return us�Interface�GetRequestTimeout (ulSec, ulUSec);\
}\
\
/***********************************************************************\
 *  class     �Interface�_client\
 *  function  _usSetRequestTimeout\
 ***********************************************************************/\
/*!           Set settings for request timeout\
 *  \\param   unsigned long ulSec -> Sec\
 *  \\param   unsigned long ulUSec -> Microsec\
 *  \\return  unsigned short <- Errorcode (0=ok, 1=error)\
 ***********************************************************************/\
/*  author    Alexander Neidhardt\
 *  date      14.05.2007\
 *  revision  -\
 *  info      Part of the idl2rpc.pl - generator!\
 ***********************************************************************/\
unsigned short �Interface�_client::_usSetRequestTimeout (unsigned long ulSec, unsigned long ulUSec)\
{\
    return us�Interface�SetRequestTimeout (ulSec, ulUSec);\
}\
\
/***********************************************************************\
 *  class     �Interface�_client\
 *  function  _usGetRetryTimeout\
 ***********************************************************************/\
/*!           Return settings for retry timeout (UDP)\
 *  \\param   unsigned long & ulSec <- Sec\
 *  \\param   unsigned long & ulUSec <- Microsec\
 *  \\return  unsigned short <- Errorcode (0=ok, 1=error)\
 ***********************************************************************/\
/*  author    Alexander Neidhardt\
 *  date      14.05.2007\
 *  revision  -\
 *  info      Part of the idl2rpc.pl - generator!\
 ***********************************************************************/\
unsigned short �Interface�_client::_usGetRetryTimeout (unsigned long & ulSec, unsigned long & ulUSec)\
{\
    return us�Interface�GetRetryTimeout (ulSec, ulUSec);\
}\
\
/***********************************************************************\
 *  class     �Interface�_client\
 *  function  _usSetRetryTimeout\
 ***********************************************************************/\
/*!           Set settings for retry timeout (UDP)\
 *  \\param   unsigned long ulSec -> Sec\
 *  \\param   unsigned long ulUSec -> Microsec\
 *  \\return  unsigned short <- Errorcode (0=ok, 1=error)\
 ***********************************************************************/\
/*  author    Alexander Neidhardt\
 *  date      14.05.2007\
 *  revision  -\
 *  info      Part of the idl2rpc.pl - generator!\
 ***********************************************************************/\
unsigned short �Interface�_client::_usSetRetryTimeout (unsigned long ulSec, unsigned long ulUSec)\
{\
    return us�Interface�SetRetryTimeout (ulSec, ulUSec);\
}\
\
/***********************************************************************\
 *  class     �Interface�_client\
 *  function  _usGetTransportProtocol\
 ***********************************************************************/\
/*!           Return settings for transport protocol\
 *  \\param   unsigned short & usProtocolID <- Protocol ID (0=UDP, 1=TCP)\
 *  \\return  unsigned short <- Errorcode (0=ok, 1=error)\
 ***********************************************************************/\
/*  author    Alexander Neidhardt\
 *  date      14.05.2007\
 *  revision  -\
 *  info      Part of the idl2rpc.pl - generator!\
 ***********************************************************************/\
unsigned short �Interface�_client::_usGetTransportProtocol (unsigned short & usProtocolID)\
{\
    return us�Interface�GetTransportProtocol (usProtocolID);\
}\
\
/***********************************************************************\
 *  class     �Interface�_client\
 *  function  _usSetTransportProtocol\
 ***********************************************************************/\
/*!           Set settings for transport protocol\
 *  \\param   unsigned short & usProtocolID -> Protocol ID (0=UDP, 1=TCP)\
 *  \\return  unsigned short <- Errorcode (0=ok, 1=error)\
 ***********************************************************************/\
/*  author    Alexander Neidhardt\
 *  date      14.05.2007\
 *  revision  -\
 *  info      Part of the idl2rpc.pl - generator!\
 ***********************************************************************/\
unsigned short �Interface�_client::_usSetTransportProtocol (unsigned short usProtocolID)\
{\
    return us�Interface�SetTransportProtocol (usProtocolID);\
}\
\
/***********************************************************************\
 *  class     �Interface�_client\
 *  function  _usGetTCPPort\
 ***********************************************************************/\
/*!           Get settings for TCP port\
 *  \\param   unsigned int & uiTCPPort <- Port\
 *  \\return  unsigned short <- Errorcode (0=ok, 1=error)\
 ***********************************************************************/\
/*  author    Alexander Neidhardt\
 *  date      12.12.2008\
 *  revision  -\
 *  info      Part of the idl2rpc.pl - generator!\
 ***********************************************************************/\
unsigned short �Interface�_client::_usGetTCPPort (unsigned int & uiTCPPort)\
{\
    return us�Interface�GetTCPPort (uiTCPPort);\
}\
\
/***********************************************************************\
 *  class     �Interface�_client\
 *  function  _usSetTCPPort\
 ***********************************************************************/\
/*!           Set settings for TCP port and reconnect if connection is open\
 *  \\param   unsigned int uiTCPPort -> Port\
 *  \\return  unsigned short <- Errorcode (0=ok, 1=error)\
 ***********************************************************************/\
/*  author    Alexander Neidhardt\
 *  date      12.12.2008\
 *  revision  -\
 *  info      Part of the idl2rpc.pl - generator!\
 ***********************************************************************/\
unsigned short �Interface�_client::_usSetTCPPort (unsigned int uiTCPPort)\
{\
    return us�Interface�SetTCPPort (uiTCPPort);\
}\
\
/***********************************************************************\
 *  class     �Interface�_client\
 *  function  _usGetUDPPort\
 ***********************************************************************/\
/*!           Get settings for UDP port\
 *  \\param   unsigned int & uiUDPPort <- Port\
 *  \\return  unsigned short <- Errorcode (0=ok, 1=error)\
 ***********************************************************************/\
/*  author    Alexander Neidhardt\
 *  date      12.12.2008\
 *  revision  -\
 *  info      Part of the idl2rpc.pl - generator!\
 ***********************************************************************/\
unsigned short �Interface�_client::_usGetUDPPort (unsigned int & uiUDPPort)\
{\
    return us�Interface�GetUDPPort (uiUDPPort);\
}\
\
/***********************************************************************\
 *  class     �Interface�_client\
 *  function  _usSetUDPPort\
 ***********************************************************************/\
/*!           Set settings for UDP port and reconnect if connection is open\
 *  \\param   unsigned int uiUDPPort -> Port\
 *  \\return  unsigned short <- Errorcode (0=ok, 1=error)\
 ***********************************************************************/\
/*  author    Alexander Neidhardt\
 *  date      12.12.2008\
 *  revision  -\
 *  info      Part of the idl2rpc.pl - generator!\
 ***********************************************************************/\
unsigned short �Interface�_client::_usSetUDPPort (unsigned int uiUDPPort)\
{\
    return us�Interface�SetUDPPort (uiUDPPort);\
}\
\
�InterfaceFunctionDefinitions�\
\
";

my $g_ClientClassRPCMethodDefinitionTemplate = 
"/***********************************************************************\
 *  class     �Interface�_client\
 *  function  �Method�\
 ***********************************************************************/\
/*!           Generated interface method. See interface definition file! (defined by user)\
 ***********************************************************************/\
/*  author    Alexander Neidhardt\
 *  date      14.05.2007\
 *  revision  -\
 *  info      Part of the idl2rpc.pl - generator!\
 ***********************************************************************/\
�ReturnValue� �Interface�_client::�Method� (�Parameters�) throw (_interface_throw)\
{\
    // RPC-in/out-structures\
    unsigned long ulBlockHandle = 0;\
    unsigned short __usInternalError = 0;\
    _interface_throw CInterfaceExcept;\
    �INVariableDefinition�\
    �OUTVariableDefinition�\
    �VariableDefinitions�\
    // =============================================================\
    // Variable init\
    priv_strError = \"Everything ok\";\
    CInterfaceExcept.strErrorMsg = priv_strError;\
    CInterfaceExcept._operation_state = 0;\
    �VariableInit�\
    // =============================================================\
    // Start round trip delay measuring
    v�Interface�StartTimer ();
    // =============================================================\
    // Enter critical section\
    try\
    {\
        cThreadSaveClientSemaphore.vBlock(ulBlockHandle);\
    }\
    catch (...)\
    {\
        priv_strError = \"Semaphore failed BLOCK\";\
        CInterfaceExcept.strErrorMsg = priv_strError;\
        CInterfaceExcept._operation_state = 2;\
        __usInternalError = 1;\
        goto �RPCFunction�_Return;\
    }\
    // =============================================================\
    // Check if interface is usable\
    if (!us�Interface�IsClientConnected ())\
    {\
        if (priv_strServerIP.length() > 0)\
        {\
            // Try to open interface\
            try\
            {\
               us�Interface�OpenInterfaceIntern (priv_strServerIP);\
            }\
            catch (_interface_throw CInterfaceException)\
            {\
                CInterfaceExcept = CInterfaceException;\
                priv_strError = CInterfaceExcept.strErrorMsg;\
                __usInternalError = 1;\
                goto �RPCFunction�_Return;\
            }\
        }\
        else\
        {\
            priv_strError = \"No IP saved for reopen\";\
            CInterfaceExcept.strErrorMsg = priv_strError;\
            CInterfaceExcept._operation_state = 2;\
            __usInternalError = 1;\
            goto �RPCFunction�_Return;\
        }\
    }\
    // =============================================================\
    // Fill in-structure\
    priv_ulRoundTripByteSum = 0;
    �FillINVariables�\
    // =============================================================\
    // Check if transfer size fits to used transport protocol\
    if (priv_usTransportProtocol != 1 && priv_ulRoundTripByteSum > _MAXROUNDTRIPBYTESUM)\
    {\
        priv_strError = \"Wrong transport protocol for transfer data volume\";\
        CInterfaceExcept.strErrorMsg = priv_strError;\
        CInterfaceExcept._operation_state = 1;\
        __usInternalError = 1;
        goto �RPCFunction�_Return;\
    }\
    // Call RPC-functionality\
    if ((�OUTVariable� �RPCFunction� (�INVariable�, priv_pSClient)) == NULL)\
    {\
        priv_strError = clnt_spcreateerror (priv_strServerIP.c_str());\
        CInterfaceExcept.strErrorMsg = priv_strError;\
        CInterfaceExcept._operation_state = 2;\
        v�Interface�CloseInterfaceIntern (); // Close interface for a later reopen\
        __usInternalError = 2;\
        goto �RPCFunction�_Return;\
    }\
    if (SOutput->_operation_state != 0)\
    {\
        priv_strError = \"Operation state error detected\";\
        CInterfaceExcept.strErrorMsg = priv_strError;\
        CInterfaceExcept._operation_state = SOutput->_operation_state;\
        __usInternalError = 1;\
        goto �RPCFunction�_Return;\
    }
    // =============================================================\
    // Set parameter return\
    �FillParameterReturn�\
    // =============================================================\
    // Return jump point\
    �RPCFunction�_Return:\
    // =============================================================\
    // Stop round trip delay measuring
    v�Interface�StopTimer ();
    // Check timeout situations\
    if (__usInternalError == 2)\
    {\
        if (((unsigned long)priv_RequestTimeout.tv_sec < priv_ulRoundTripDelaySec) ||\
            ((unsigned long)priv_RequestTimeout.tv_sec == priv_ulRoundTripDelaySec &&\
             (unsigned long)priv_RequestTimeout.tv_usec <= priv_ulRoundTripDelayUSec))\
        {\
             CInterfaceExcept.strErrorMsg[CInterfaceExcept.strErrorMsg.length()-1] = '\\0';\
             CInterfaceExcept.strErrorMsg += \", Request timeout fired\";\
        }\
        else\
        {\
             CInterfaceExcept.strErrorMsg[CInterfaceExcept.strErrorMsg.length()-1] = '\\0';\
             CInterfaceExcept.strErrorMsg += \", Communication broken\";\
        }\
    }\
    // =============================================================\
    // Leave critical section\
    try\
    {\
        cThreadSaveClientSemaphore.vUnblock(ulBlockHandle);\
    }\
    catch (...)\
    {\
        priv_strError = \"Semaphore failed UNBLOCK\";\
        CInterfaceExcept.strErrorMsg = priv_strError;\
        CInterfaceExcept._operation_state = 2;\
        __usInternalError = 1;\
    }\
    // =============================================================\
    // Clean up \
    �FinalCleanUp�\
    if (__usInternalError)\
    {\
        �SetDefaultParameterReturn�\
    }\
    // =============================================================\
    // Throw exception if necessary \
    if (__usInternalError)\
    {\
        throw CInterfaceExcept;\
    }\
    // =============================================================\
    // Return return value\
    �SetReturnValue�\
}\
";

my $g_ServerClassDeclarationTemplate = 
"/***********************************************************************/\
/*! \\file �ModulFilename�\
 *  \\brief Interface code file defined at �InterfaceFilenameWithoutExt�.idl and generated by idl2rpc.pl<br>\
 ***********************************************************************/
 \
 ".
$g_FileHead.
"#ifndef __�InterfaceFilenameWithoutExt�_server__\
#define __�InterfaceFilenameWithoutExt�_server__\
\
#include <rpc/rpc.h>\
#include \"�InterfaceFilenameWithoutExt�_interface.hpp\" \
#include \"�InterfaceFilenameWithoutExt�_simple_semvar.hpp\"\
// USERDEFINCLUDEBEG: Userdefined includes\
�UserDefinedIncludes�\
// USERDEFINCLUDEEND\
\
class �Interface�_server : �Interface�\
{\
    std::string priv_strError;        // Attribute for error messages\
    unsigned short usStopServerLoop;  // If this attribute is 1 the server will terminate regularly\
    unsigned short usServerInitAlert; // This attribute is set when the internal class construction failed\
    // USERDEFATTRIBBEG: Userdefined attributes\
    �UserDefinedAttributes�\
    // USERDEFATTRIBEND\
    // USERDEFATTMETHODBEG: Userdefined attribute methods\
    �UserDefinedAttMethods�\
    // USERDEFATTMETHODEND\
  private:\
    void v�Interface�StopServerLoop ();\
  public:\
    �Interface�_server() throw (_interface_throw);\
    �Interface�_server (const �Interface�_server & CIn) throw (_interface_throw);\
    virtual ~�Interface�_server () throw (_interface_throw);\
    �Interface�_server & operator= (const �Interface�_server & CIn) throw (_interface_throw);\
    std::string str�Interface�GetErrorMsg () throw (_interface_throw);\
    unsigned short us�Interface�ServerLoopStopOrderIsActive ();\
    unsigned short us�Interface�ServerInitAlertIsActive ();\
  public:\
    // Methods which have to be filled by developer \
    virtual void _vInitServerActivity (int argc, char *argv[]);\
    virtual void _vPeriodicServerActivity ();\
    virtual void _vOnExitServerActivity ();\
    virtual void _vAutomaticSafetyDeviceAlert ();\
    virtual void _vAutomaticSafetyDeviceAlertRepeated ();\
�InterfaceFunctionDeclarations�\
};\
#endif // __�InterfaceFilenameWithoutExt�_server__\
";

my $g_ServerClassDefinitionTemplate = 
"/***********************************************************************/\
/*! \\file �ModulFilename�\
 *  \\brief Interface code file defined at �InterfaceFilenameWithoutExt�.idl and generated by idl2rpc.pl<br>\
 ***********************************************************************/
 \
 ".
$g_FileHead.
"#include <stdio.h>\
#include <rpc/rpc.h>\
#include <string>\
#include \"�InterfaceFilenameWithoutExt�_interface.hpp\"\
#include \"�InterfaceFilenameWithoutExt�_server.hpp\"\
#include \"�InterfaceFilenameWithoutExt�_os.h\"\
// USERDEFINCLUDEBEG: Userdefined includes\
�UserDefinedIncludes�\
// USERDEFINCLUDEEND\
// USERDEFATTMETHODBEG: Userdefined attribute methods\
�UserDefinedAttMethods�\
// USERDEFATTMETHODEND\
\
/***********************************************************************\
 *  class     �Interface�_server\
 *  function  v�Interface�StopServerLoop\
 ***********************************************************************/\
/*!           Set stop flag to finish server loop\
 *  \\param   -\
 *  \\return  -\
 ***********************************************************************/\
/*  author    Alexander Neidhardt\
 *  date      14.05.2007\
 *  revision  -\
 *  info      Part of the idl2rpc.pl - generator!\
 ***********************************************************************/\
void �Interface�_server::v�Interface�StopServerLoop ()\
{\
    usStopServerLoop = 1;\
}\
\
/***********************************************************************\
 *  class     �Interface�_server\
 *  function  �Interface�_server\
 ***********************************************************************/\
/*!           Constructor\
 *  \\param   -\
 *  \\return  -\
 ***********************************************************************/\
/*  author    Alexander Neidhardt\
 *  date      14.05.2007\
 *  revision  -\
 *  info      Part of the idl2rpc.pl - generator!\
 ***********************************************************************/\
�Interface�_server::�Interface�_server () throw (_interface_throw) : �Interface�()\
{\
    try\
    {\
        priv_strError = \"OK\";\
        usStopServerLoop = 0;\
        usServerInitAlert = 0;\
    }\
    catch (...)\
    {\
        _interface_throw CInterfaceExcept;\
        usServerInitAlert = 1;\
        priv_strError = \"Can't init interface\";\
        CInterfaceExcept.strErrorMsg = priv_strError;\
        CInterfaceExcept._operation_state = 1;\
        throw (CInterfaceExcept);\
        return;\
    }\
    try\
    {\
    // USERDEFATTRIBBEG: Userdefined attributes
    // USERDEFATTRIBEND
    }\
    catch (...)\
    {\
        _interface_throw CInterfaceExcept;\
        usServerInitAlert = 1;\
        priv_strError = \"Can't init interface\";\
        CInterfaceExcept.strErrorMsg = priv_strError;\
        CInterfaceExcept._operation_state = 1;\
        throw (CInterfaceExcept);\
        return;\
    }\
}\
\
/***********************************************************************\
 *  class     �Interface�_server\
 *  function  �Interface�_server\
 ***********************************************************************/\
/*!           Copy-Constructor\
 *  \\param   const �Interface�_server & CIn -> Copy from\
 *  \\return  -\
 ***********************************************************************/\
/*  author    Alexander Neidhardt\
 *  date      14.05.2007\
 *  revision  -\
 *  info      Part of the idl2rpc.pl - generator!\
 ***********************************************************************/\
�Interface�_server::�Interface�_server (const �Interface�_server & CIn) throw (_interface_throw) : �Interface�(CIn)\
{\
    try\
    {\
        priv_strError = \"OK\";\
        usStopServerLoop = CIn.usStopServerLoop;\
        usServerInitAlert = CIn.usServerInitAlert;\
    }\
    catch (...)\
    {\
        _interface_throw CInterfaceExcept;\
        usServerInitAlert = 1;\
        priv_strError = \"Can't init interface\";\
        CInterfaceExcept.strErrorMsg = priv_strError;\
        CInterfaceExcept._operation_state = 1;\
        throw (CInterfaceExcept);\
        return;\
    }\
    try\
    {\
    // USERDEFATTRIBBEG: Userdefined attributes
    // USERDEFATTRIBEND
    }\
    catch (...)\
    {\
        _interface_throw CInterfaceExcept;\
        usServerInitAlert = 1;\
        priv_strError = \"Can't init interface\";\
        CInterfaceExcept.strErrorMsg = priv_strError;\
        CInterfaceExcept._operation_state = 1;\
        throw (CInterfaceExcept);\
        return;\
    }\
}\
\
/***********************************************************************\
 *  class     �Interface�_server\
 *  function  ~�Interface�_server\
 ***********************************************************************/\
/*!           Destructor\
 *  \\param   -\
 *  \\return  -\
 ***********************************************************************/\
/*  author    Alexander Neidhardt\
 *  date      14.05.2007\
 *  revision  -\
 *  info      Part of the idl2rpc.pl - generator!\
 ***********************************************************************/\
�Interface�_server::~�Interface�_server () throw (_interface_throw)\
{\
    try\
    {\
        priv_strError = \"OK\";\
        usStopServerLoop = 0;
        usServerInitAlert = 0;\
    }\
    catch (...)\
    {\
        _interface_throw CInterfaceExcept;\
        usServerInitAlert = 1;\
        priv_strError = \"Can't destroy interface\";\
        CInterfaceExcept.strErrorMsg = priv_strError;\
        CInterfaceExcept._operation_state = 1;\
        throw (CInterfaceExcept);\
        return;\
    }\
    try\
    {\
    // USERDEFATTRIBBEG: Userdefined attributes
    // USERDEFATTRIBEND
    }\
    catch (...)\
    {\
        _interface_throw CInterfaceExcept;\
        usServerInitAlert = 1;\
        priv_strError = \"Can't init interface\";\
        CInterfaceExcept.strErrorMsg = priv_strError;\
        CInterfaceExcept._operation_state = 1;\
        throw (CInterfaceExcept);\
        return;\
    }\
}\
\
/***********************************************************************\
 *  class     �Interface�_server\
 *  function  operator=\
 ***********************************************************************/\
/*!           Asign operator\
 *  \\param   �Interface�_server CIn -> Asign from\
 *  \\return  �Interface�_server <- Asign to\
 ***********************************************************************/\
/*  author    Alexander Neidhardt\
 *  date      14.05.2007\
 *  revision  -\
 *  info      Part of the idl2rpc.pl - generator!\
 ***********************************************************************/\
�Interface�_server & �Interface�_server::operator= (const �Interface�_server & CIn) throw (_interface_throw)\
{\
    try\
    {\
        priv_strError = \"OK\";\
        usStopServerLoop = CIn.usStopServerLoop;\
        usServerInitAlert = CIn.usServerInitAlert;\
    }\
    catch (...)\
    {\
        _interface_throw CInterfaceExcept;\
        usServerInitAlert = 1;\
        priv_strError = \"Can't init interface\";\
        CInterfaceExcept.strErrorMsg = priv_strError;\
        CInterfaceExcept._operation_state = 1;\
        throw (CInterfaceExcept);\
        return *this;\
    }\
    try\
    {\
    // USERDEFATTRIBBEG: Userdefined attributes
    // USERDEFATTRIBEND
    }\
    catch (...)\
    {\
        _interface_throw CInterfaceExcept;\
        usServerInitAlert = 1;\
        priv_strError = \"Can't init interface\";\
        CInterfaceExcept.strErrorMsg = priv_strError;\
        CInterfaceExcept._operation_state = 1;\
        throw (CInterfaceExcept);\
        return *this;\
    }\
    return *this;\
}\
\
/***********************************************************************\
 *  class     �Interface�_server\
 *  function  str�Interface�GetErrorMsg\
 ***********************************************************************/\
/*!           Return error message\
 *  \\param   -\
 *  \\return  std::string <- Error message\
 ***********************************************************************/\
/*  author    Alexander Neidhardt\
 *  date      14.05.2007\
 *  revision  -\
 *  info      Part of the idl2rpc.pl - generator!\
 ***********************************************************************/\
std::string �Interface�_server::str�Interface�GetErrorMsg () throw (_interface_throw)\
{\
    std::string strError;
\
    try\
    {\
        strError = priv_strError;\
        priv_strError = \"OK\";\
    }\
    catch (...)\
    {\
        _interface_throw CInterfaceExcept;\
        priv_strError = \"Can't read error message\";\
        CInterfaceExcept.strErrorMsg = priv_strError;\
        CInterfaceExcept._operation_state = 1;\
        throw (CInterfaceExcept);\
        return strError;\
    }\
    return strError;\
}\
\
/***********************************************************************\
 *  class     �Interface�_server\
 *  function  us�Interface�ServerLoopStopOrderIsActive\
 ***********************************************************************/\
/*!           Check if the stop flag is set\
 *  \\param   -\
 *  \\return  unsigned short <- Answer (0=no, 1=yes)\
 ***********************************************************************/\
/*  author    Alexander Neidhardt\
 *  date      14.05.2007\
 *  revision  -\
 *  info      Part of the idl2rpc.pl - generator!\
 ***********************************************************************/\
unsigned short �Interface�_server::us�Interface�ServerLoopStopOrderIsActive ()\
{\
    return usStopServerLoop;
}\
\
/***********************************************************************\
 *  class     �Interface�_server\
 *  function  us�Interface�ServerInitAlertIsActive\
 ***********************************************************************/\
/*!           The init failed => check if alert is active\
 *  \\param   -\
 *  \\return  unsigned short <- Answer (0=no, 1=yes)\
 ***********************************************************************/\
/*  author    Alexander Neidhardt\
 *  date      14.05.2007\
 *  revision  -\
 *  info      Part of the idl2rpc.pl - generator!\
 ***********************************************************************/\
unsigned short �Interface�_server::us�Interface�ServerInitAlertIsActive ()\
{\
    return usServerInitAlert;
}\
\
/***********************************************************************\
 *  class     �Interface�_server\
 *  function  _vInitServerActivity\
 ***********************************************************************/\
/*!           Initial tasks done at the start time (defined by user)\
 *  \\param   -\
 *  \\return  -\
 ***********************************************************************/\
/*  author    Alexander Neidhardt\
 *  date      14.05.2007\
 *  revision  -\
 *  info      Part of the idl2rpc.pl - generator!\
 ***********************************************************************/\
void �Interface�_server::_vInitServerActivity (int argc, char *argv[])\
{\
// USERDEFMETHODBEG: Userdefined method body
// USERDEFMETHODEND
}\
\
/***********************************************************************\
 *  class     �Interface�_server\
 *  function  _vPeriodicServerActivity\
 ***********************************************************************/\
/*!           Periodic tasks done at the loop time (defined by user)\
 *  \\param   -\
 *  \\return  -\
 ***********************************************************************/\
/*  author    Alexander Neidhardt\
 *  date      14.05.2007\
 *  revision  -\
 *  info      Part of the idl2rpc.pl - generator!\
 ***********************************************************************/\
void �Interface�_server::_vPeriodicServerActivity ()\
{\
// USERDEFMETHODBEG: Userdefined method body
// USERDEFMETHODEND
}\
\
/***********************************************************************\
 *  class     �Interface�_server\
 *  function  _vOnExitServerActivity\
 ***********************************************************************/\
/*!           Final tasks done at the finish time (defined by user)\
 *  \\param   -\
 *  \\return  -\
 ***********************************************************************/\
/*  author    Alexander Neidhardt\
 *  date      14.05.2007\
 *  revision  -\
 *  info      Part of the idl2rpc.pl - generator!\
 ***********************************************************************/\
void �Interface�_server::_vOnExitServerActivity ()\
{\
// USERDEFMETHODBEG: Userdefined method body
// USERDEFMETHODEND
}\
\
/***********************************************************************\
 *  class     �Interface�_server\
 *  function  _vAutomaticSafetyDeviceAlert\
 ***********************************************************************/\
/*!           Method called when the automatic safety device produces an\
 *            alert (happens when the connection to the client is lost and\
 *            the automatic safety device (ASD) is activated)
 *            Method is called only once!
 *  \\param   -\
 *  \\return  -\
 ***********************************************************************/\
/*  author    Alexander Neidhardt\
 *  date      25.02.2009\
 *  revision  -\
 *  info      Part of the idl2rpc.pl - generator!\
 ***********************************************************************/\
void �Interface�_server::_vAutomaticSafetyDeviceAlert ()\
{\
// USERDEFMETHODBEG: Userdefined method body
// USERDEFMETHODEND
}\
\
/***********************************************************************\
 *  class     �Interface�_server\
 *  function  _vAutomaticSafetyDeviceAlertRepeated\
 ***********************************************************************/\
/*!           Method called when the automatic safety device produces an\
 *            alert (happens when the connection to the client is lost and\
 *            the automatic safety device (ASD) is activated)
 *            Method is called as long as the alert is on!
 *  \\param   -\
 *  \\return  -\
 ***********************************************************************/\
/*  author    Alexander Neidhardt\
 *  date      25.02.2009\
 *  revision  -\
 *  info      Part of the idl2rpc.pl - generator!\
 ***********************************************************************/\
void �Interface�_server::_vAutomaticSafetyDeviceAlertRepeated ()\
{\
// USERDEFMETHODBEG: Userdefined method body
// USERDEFMETHODEND
}\
\
�InterfaceFunctionDefinitions�\
\
";

my $g_ServerClassRPCMethodDefinitionTemplate = 
"/***********************************************************************\
 *  class     �Interface�_server\
 *  function  �Method�\
 ***********************************************************************/\
/*!           Generated interface method. See interface definition file! (defined by user)\
 ***********************************************************************/\
/*  author    Alexander Neidhardt\
 *  date      14.05.2007\
 *  revision  -\
 *  info      Part of the idl2rpc.pl - generator!\
 ***********************************************************************/\
�ReturnValue� �Interface�_server::�Method� (�Parameters�) throw (_interface_throw)\
{\
// USERDEFMETHODBEG: Userdefined method body
�UserDefinedMethod�
// USERDEFMETHODEND
}\
";

my $g_ServerProcDeclarationTemplate = 
"/***********************************************************************/\
/*! \\file �ModulFilename�\
 *  \\brief Interface code file defined at �InterfaceFilenameWithoutExt�.idl and generated by idl2rpc.pl<br>\
 ***********************************************************************/
 \
 ".
$g_FileHead.
"#ifndef __�InterfaceFilenameWithoutExt�_proc__\
#define __�InterfaceFilenameWithoutExt�_proc__\
\
#include \"�InterfaceFilenameWithoutExt�.h\"\
\
#ifdef __cplusplus\
extern \"C\"
{
#endif //__cplusplus\
void vSetUDPPort (unsigned long ulPort);\
void vSetTCPPort (unsigned long ulPort);\
void vInitDynVarMemory ();\
void _vInitServerActivity (int argc, char *argv[]);\
void _vPeriodicServerActivity ();\
void _vOnExitServerActivity ();\
unsigned short usServerLoopStopOrderIsActive ();\
unsigned short usCheckServerIsRunning ();\
void vPrivate_svc_run ();\
#ifdef __cplusplus\
} // extern \"C\"
#endif //__cplusplus\
\
#endif /* __�InterfaceFilenameWithoutExt�_proc__ */\
";

my $g_ServerProcDefinitionTemplate = 
"/***********************************************************************/\
/*! \\file �ModulFilename�\
 *  \\brief Interface code file defined at �InterfaceFilenameWithoutExt�.idl and generated by idl2rpc.pl<br>\
 ***********************************************************************/
 \
 ".
$g_FileHead.
"#include <string>\
#include <unistd.h>\
#include <time.h>\
#include \"�InterfaceFilenameWithoutExt�_proc.hpp\"\
#include \"�InterfaceFilenameWithoutExt�_interface.hpp\"\
#include \"�InterfaceFilenameWithoutExt�_server.hpp\"\
#include \"�InterfaceFilenameWithoutExt�_client.hpp\"\
#include \"�InterfaceFilenameWithoutExt�_os.h\"\
\
static unsigned long g_ulUDPPort;\
static unsigned long g_ulTCPPort;\
\
// Function declarations needed in thread etc.
#ifdef __cplusplus\
extern \"C\"
{
#endif //__cplusplus\
unsigned short usServerLoopStopOrderIsActive ();\
unsigned short usServerInitAlertIsActive ();\
#ifdef __cplusplus\
} // extern \"C\"
#endif //__cplusplus\
\
�SimpleThreadInclude�\
�ASDThreadInclude�\
#define MAXDYNVARIABLES  256\
\
// GLOBAL VARIABLES\
// Handle memory management between several RPC-calls\
static void * g_pvDynVarMemory[MAXDYNVARIABLES]; // Each remote procedure can handle MAXDYNVARIABLES dynamic variables\
static �Interface�_server g_SServerMethods; // The user defined server methods\
\
\
�SimpleThreadDefinition�\
\
�ASDThreadDefinition�\
\
#ifdef __cplusplus\
extern \"C\"
{
#endif //__cplusplus\
\
#include <stdio.h>\
#include <stdlib.h>
#include <rpc/rpc.h>\
#include <sys/errno.h>\
#include <sys/time.h>\
#include <time.h>\
\
/***********************************************************************\
 *  function  vSetUDPPort\
 ***********************************************************************/\
/*!           Saves the assigned port as UDP-port\
 *  \\param   unsigned long ulPort -> The new port\
 *  \\return  -\
 ***********************************************************************/\
/*  author    Alexander Neidhardt\
 *  date      20.01.2009\
 *  revision  -\
 *  info      Part of the idl2rpc.pl - generator!\
 ***********************************************************************/\
void vSetUDPPort (unsigned long ulPort)\
{\
    g_ulUDPPort = ulPort;\
}\
\
/***********************************************************************\
 *  function  vSetTCPPort\
 ***********************************************************************/\
/*!           Saves the assigned port as TCP-port\
 *  \\param   unsigned long ulPort -> The new port\
 *  \\return  -\
 ***********************************************************************/\
/*  author    Alexander Neidhardt\
 *  date      20.01.2009\
 *  revision  -\
 *  info      Part of the idl2rpc.pl - generator!\
 ***********************************************************************/\
void vSetTCPPort (unsigned long ulPort)\
{\
    g_ulTCPPort = ulPort;\
}\
\
/***********************************************************************\
 *  function  vInitDynVarMemory\
 ***********************************************************************/\
/*!           Init dynamic memory to handle dynamic arguments\
 *  \\param   -\
 *  \\return  -\
 ***********************************************************************/\
/*  author    Alexander Neidhardt\
 *  date      14.05.2007\
 *  revision  -\
 *  info      Part of the idl2rpc.pl - generator!\
 ***********************************************************************/\
void vInitDynVarMemory ()\
{\
    unsigned long ulIndex;\
    for (ulIndex = 0; ulIndex < MAXDYNVARIABLES; ulIndex++)\
    {\
        g_pvDynVarMemory[ulIndex] = NULL;\
    }\
}\
\
/***********************************************************************\
 *  function  vResetDynVarMemory\
 ***********************************************************************/\
/*!           Delete dynamic memory to handle dynamic arguments\
 *  \\param   -\
 *  \\return  -\
 ***********************************************************************/\
/*  author    Alexander Neidhardt\
 *  date      14.05.2007\
 *  revision  -\
 *  info      Part of the idl2rpc.pl - generator!\
 ***********************************************************************/\
void vResetDynVarMemory ()\
{\
    unsigned long ulIndex;\
    for (ulIndex = 0; ulIndex < MAXDYNVARIABLES; ulIndex++)\
    {\
        if (g_pvDynVarMemory[ulIndex] == NULL)\
            break;\
        free (g_pvDynVarMemory[ulIndex]);\
        g_pvDynVarMemory[ulIndex] = NULL;\
    }\
}\
\
/***********************************************************************\
 *  function  ulGetNextDynVarIndex\
 ***********************************************************************/\
/*!           Return index of next free array field\
 *  \\param   -\
 *  \\return  unsigned long <- Next index of free dynamic area\
 ***********************************************************************/\
/*  author    Alexander Neidhardt\
 *  date      14.05.2007\
 *  revision  -\
 *  info      Part of the idl2rpc.pl - generator!\
 ***********************************************************************/\
unsigned long ulGetNextDynVarIndex ()\
{\
    unsigned long ulIndex;\
    for (ulIndex = 0; ulIndex < MAXDYNVARIABLES; ulIndex++)\
    {\
        if (g_pvDynVarMemory[ulIndex] == NULL)\
            break;\
    }\
    return ulIndex;\
}\
\
/***********************************************************************\
 *  function  _vInitServerActivity\
 ***********************************************************************/\
/*!           Call the user defined initial tasks\
 *  \\param   int argc -> Number of calling parameter arguments\
 *  \\param   char *argv[] -> Calling parameter arguments\
 *  \\return  -\
 ***********************************************************************/\
/*  author    Alexander Neidhardt\
 *  date      14.05.2007\
 *  revision  -\
 *  info      Part of the idl2rpc.pl - generator!\
 ***********************************************************************/\
void _vInitServerActivity (int argc, char *argv[])\
{\
    if (usServerInitAlertIsActive ())\
        return;\
    // Call user-defined init activity\
    g_SServerMethods._vInitServerActivity (argc, argv);\
    �SimpleThreadActivation�
    �ASDThreadActivation�
}\
\
/***********************************************************************\
 *  function  _vPeriodicServerActivity\
 ***********************************************************************/\
/*!           Call the user defined periodic tasks\
 *  \\param   -\
 *  \\return  -\
 ***********************************************************************/\
/*  author    Alexander Neidhardt\
 *  date      14.05.2007\
 *  revision  -\
 *  info      Part of the idl2rpc.pl - generator!\
 ***********************************************************************/\
void _vPeriodicServerActivity ()\
{\
    if (usServerInitAlertIsActive ())\
        return;\
    // Call user-defined init activity\
    g_SServerMethods._vPeriodicServerActivity ();\
}\
\
/***********************************************************************\
 *  function  _vOnExitServerActivity\
 ***********************************************************************/\
/*!           Call the user defined exit tasks\
 *  \\param   -\
 *  \\return  -\
 ***********************************************************************/\
/*  author    Alexander Neidhardt\
 *  date      14.05.2007\
 *  revision  -\
 *  info      Part of the idl2rpc.pl - generator!\
 ***********************************************************************/\
void _vOnExitServerActivity ()\
{\
    if (usServerInitAlertIsActive ())\
        return;\
    // Call user-defined init activity\
    g_SServerMethods._vOnExitServerActivity ();\
    �SimpleThreadDeactivation�
    �ASDThreadDeactivation�
}\
\
/***********************************************************************\
 *  function  usServerLoopStopOrderIsActive\
 ***********************************************************************/\
/*!           Answer if periodic tasks should be stoped\
 *  \\param   -\
 *  \\return  unsigned short <- Answer (0=no, 1=yes)\
 ***********************************************************************/\
/*  author    Alexander Neidhardt\
 *  date      14.05.2007\
 *  revision  -\
 *  info      Part of the idl2rpc.pl - generator!\
 ***********************************************************************/\
unsigned short usServerLoopStopOrderIsActive ()\
{\
    return g_SServerMethods.us�Interface�ServerLoopStopOrderIsActive ();\
}\
\
/***********************************************************************\
 *  function  usServerInitAlertIsActive\
 ***********************************************************************/\
/*!           Init failed => Answer if alert is set\
 *  \\param   -\
 *  \\return  unsigned short <- Answer (0=no, 1=yes)\
 ***********************************************************************/\
/*  author    Alexander Neidhardt\
 *  date      14.05.2007\
 *  revision  -\
 *  info      Part of the idl2rpc.pl - generator!\
 ***********************************************************************/\
unsigned short usServerInitAlertIsActive ()\
{\
    return g_SServerMethods.us�Interface�ServerInitAlertIsActive ();\
}\
\
/***********************************************************************\
 *  function  usCheckServerIsRunning\
 ***********************************************************************/\
/*!           Check if server is already activated by starting client communication test\
 *  \\param   -\
 *  \return  unsigned short <- Answer (0=no, 1=yes)\
 ***********************************************************************/\
/*  author    Alexander Neidhardt\
 *  date      14.05.2007\
 *  revision  -\
 *  info      Part of the idl2rpc.pl - generator!\
 ***********************************************************************/\
unsigned short usCheckServerIsRunning ()\
{\
    �Interface�_client CClient;\
\
    try\
    {\
        if (CClient._usOpenInterface (\"127.0.0.1\"))\
        {\
            return 0;\
        }\
    }\
    catch (�Interface�_interface_throw CErr)\
    {\
        return 0;\
    }\
    catch (...)\
    {\
        return 2;\
    }\
\
    try\
    {\
        CClient._vCloseInterface ();\
    }\
    catch (...)\
    {\
        return 2;\
    }\
\
    return 1;\
}\
\
/***********************************************************************\
 *  function  vPrivate_svc_run\
 ***********************************************************************/\
/*!           Replacement of original, RPC-generated main loop with own tasks\
 *  \\param   -\
 *  \\return  -\
 ***********************************************************************/\
/*  author    Alexander Neidhardt\
 *  date      14.05.2007\
 *  revision  -\
 *  info      Part of the idl2rpc.pl - generator!\
 ***********************************************************************/\
void vPrivate_svc_run ()\
{\
    unsigned short usBreak = 0;\
    fd_set readfdset;\
    extern int errno;\
    static int tsize = 0;\
    struct timeval STTimeout;\
    struct timeval StartTime;\
    struct timeval EndTime;\
    struct timeval EndMinusStartTime;\
    struct timeval TimeToNextFire;\
    struct timezone Zone;\
    unsigned short usTimeCheckIsNotUsed = 0;\
    unsigned short usUsePeriodic = 0;\
    \
    if (usServerInitAlertIsActive ())\
        return;\
    \
    if (!tsize)\
        tsize = getdtablesize();\
        \
    TimeToNextFire.tv_sec = �TimeoutSec�; \
    TimeToNextFire.tv_usec = �TimeoutUSec�;\
    if (TimeToNextFire.tv_sec > 0 ||\
        TimeToNextFire.tv_usec > 0)\
        usUsePeriodic = 1;\
    else\
        usUsePeriodic = 0;\
    if (usUsePeriodic)\
    {\
        _vPeriodicServerActivity ();\
        usTimeCheckIsNotUsed = 0;\
        if (gettimeofday (&StartTime, &Zone) != 0) \
            usTimeCheckIsNotUsed = 1;\
    }\
    \
    while (1)\
    {\
        if (usBreak ||\
            usServerLoopStopOrderIsActive () ||\
            usServerInitAlertIsActive ())\
            break;\
        \
        STTimeout.tv_sec = TimeToNextFire.tv_sec; \
        STTimeout.tv_usec = TimeToNextFire.tv_usec;\
\
        readfdset = svc_fdset;\
        switch (select (tsize, &readfdset, (fd_set*) NULL, (fd_set*) NULL, �Timeout�))\
        {\
            case -1:\
                if (errno == EBADF)\
                    continue;\
                perror (\"select failed\");\
                usBreak = 1;\
                break;\
            case 0:\
                _vPeriodicServerActivity ();\
                if (usUsePeriodic)\
                {\
                    usTimeCheckIsNotUsed = 0;\
                    if (gettimeofday (&StartTime, &Zone) != 0) \
                        usTimeCheckIsNotUsed = 1;\
                    TimeToNextFire.tv_sec = �TimeoutSec�;
                    TimeToNextFire.tv_usec = �TimeoutUSec�;
                }\
                break;\
            default:\
                if (usUsePeriodic)\
                {\
                    if (!usTimeCheckIsNotUsed &&\
                        gettimeofday (&EndTime, &Zone) != 0) \
                        usTimeCheckIsNotUsed = 1;\
                    if (!usTimeCheckIsNotUsed)\
                    {\
                        EndMinusStartTime.tv_sec = (((1000000-StartTime.tv_usec)+EndTime.tv_usec)/1000000)+(EndTime.tv_sec-StartTime.tv_sec-1);
                        EndMinusStartTime.tv_usec = ((1000000-StartTime.tv_usec)+EndTime.tv_usec)%1000000;
                        if (EndMinusStartTime.tv_sec >= �TimeoutSec� && EndMinusStartTime.tv_usec >= �TimeoutUSec�)\
                        {\
                            _vPeriodicServerActivity ();\
                            usTimeCheckIsNotUsed = 0;\
                            if (gettimeofday (&StartTime, &Zone) != 0) \
                                usTimeCheckIsNotUsed = 1;\
                        }\
                    }\
                }\
                svc_getreqset (&readfdset);\
                if (usUsePeriodic)\
                {\
                    if (!usTimeCheckIsNotUsed &&\
                        gettimeofday (&EndTime, &Zone) != 0) \
                        usTimeCheckIsNotUsed = 1;\
                    if (!usTimeCheckIsNotUsed)\
                    {\
                        EndMinusStartTime.tv_sec = (((1000000-StartTime.tv_usec)+EndTime.tv_usec)/1000000)+(EndTime.tv_sec-StartTime.tv_sec-1);
                        EndMinusStartTime.tv_usec = ((1000000-StartTime.tv_usec)+EndTime.tv_usec)%1000000;
                        if (EndMinusStartTime.tv_sec >= �TimeoutSec� && EndMinusStartTime.tv_usec >= �TimeoutUSec�)\
                        {\
                            _vPeriodicServerActivity ();\
                            usTimeCheckIsNotUsed = 0;\
                            if (gettimeofday (&StartTime, &Zone) != 0) \
                                usTimeCheckIsNotUsed = 1;\
                            while (EndMinusStartTime.tv_sec >= �TimeoutSec� && EndMinusStartTime.tv_usec >= �TimeoutUSec�)\
                            {\
                                EndMinusStartTime.tv_sec = (((1000000-�TimeoutUSec�)+EndMinusStartTime.tv_usec)/1000000)+(EndMinusStartTime.tv_sec-�TimeoutSec�-1);
                                EndMinusStartTime.tv_usec = ((1000000-�TimeoutUSec�)+EndMinusStartTime.tv_usec)%1000000;
                            }\
                        }\
                        TimeToNextFire.tv_sec = (((1000000-EndMinusStartTime.tv_usec)+�TimeoutUSec�)/1000000)+(�TimeoutSec�-EndMinusStartTime.tv_sec-1);
                        TimeToNextFire.tv_usec = ((1000000-EndMinusStartTime.tv_usec)+�TimeoutUSec�)%1000000;
                    }\
                }\
                break;\
        }\
    }\
}\
\
/***********************************************************************\
 *  function  sap_�InterfaceLC�_basicping_1_svc\
 ***********************************************************************/\
/*!           Always usable, given RPC-method to ping the server\
 *  \\param   void * pSInput -> Input structure with function parameter\
 *  \\param   struct svc_req * pSSvc -> Input structure with server/client info\
 *  \\return  unsigned long * <- Current time tag\
 ***********************************************************************/\
/*  author    Alexander Neidhardt\
 *  date      14.05.2007\
 *  revision  -\
 *  info      Part of the idl2rpc.pl - generator!\
 ***********************************************************************/\
unsigned long * sap_�InterfaceLC�_basicping_1_svc (void * pSInput, struct svc_req * pSSvc)\
{\
    static unsigned long ulTime;\
    (void)pSInput; // Reduce compiler warnings unused variables
    (void)pSSvc;   // Reduce compiler warnings unused variables
    ulTime = time(NULL);\
    return &ulTime;\
}\
\
\
/***********************************************************************\
 *  function  sap_�InterfaceLC�_basiccheckidlversion_1_svc\
 ***********************************************************************/\
/*!           Always usable, given RPC-method to check idl and interface version the server\
 *  \\param   INSAP_�Interface�CheckIDLVersionType * pSInput -> Input structure with function parameter\
 *  \\param   struct svc_req * pSSvc -> Input structure with server/client info\
 *  \\return  OUTSAP_�Interface�CheckIDLVersionStruct * <- Answer \
 ***********************************************************************/\
/*  author    Alexander Neidhardt\
 *  date      30.10.2008\
 *  revision  -\
 *  info      Part of the idl2rpc.pl - generator!\
 ***********************************************************************/\
OUTSAP_�Interface�CheckIDLVersionStruct * sap_�InterfaceLC�_basiccheckidlversion_1_svc (INSAP_�Interface�CheckIDLVersionType * pSInput, struct svc_req * pSSvc)\
{\
    // RPC-in/out-structures\
    unsigned short __usInternalError = 0;\
    std::string strIDL2RPCVersion;\
    (void)pSInput; // Reduce compiler warnings unused variables
    (void)pSSvc;   // Reduce compiler warnings unused variables
    strIDL2RPCVersion = pSInput->strIDL2RPCVersion.strIDL2RPCVersion_val;\
    std::string strInterfaceVersion;\
    strInterfaceVersion = pSInput->strInterfaceVersion.strInterfaceVersion_val;\
    static OUTSAP_�Interface�CheckIDLVersionStruct SOutput;
    // =============================================================\
    // Variable init\
    SOutput.strIDL2RPCVersion.strIDL2RPCVersion_val = NULL;
    SOutput.strIDL2RPCVersion.strIDL2RPCVersion_len = 0;
    SOutput.strInterfaceVersion.strInterfaceVersion_val = NULL;
    SOutput.strInterfaceVersion.strInterfaceVersion_len = 0;
    SOutput._Ret = 0; // NOK
    SOutput.iInterfaceVersionOK = 0; // NOK\
    SOutput.iIDL2RPCVersionOK = 0; // NOK\
    SOutput._operation_state = 0; // Operation processed
    // =============================================================\
    // Fill in-structure\
    vResetDynVarMemory();\
    // =============================================================\
    // Set parameter return\
    if ((SOutput.strIDL2RPCVersion.strIDL2RPCVersion_val = (char *) malloc (sizeof(char)*(strlen(\"".$g_VersionDate."\")+1))) == NULL)
    {
        __usInternalError = 1;
        SOutput._operation_state = 3; // Memory error
        goto sap_�InterfaceLC�_basiccheckidlversion_1_svc_Return;
    }
    strcpy (SOutput.strIDL2RPCVersion.strIDL2RPCVersion_val, \"".$g_VersionDate."\");\
    SOutput.strIDL2RPCVersion.strIDL2RPCVersion_len = sizeof(char)*(strlen(\"".$g_VersionDate."\")+1);
    if ((SOutput.strInterfaceVersion.strInterfaceVersion_val = (char *) malloc (sizeof(char)*(strlen(\"�InterfaceVersion�\")+1))) == NULL)
    {
        __usInternalError = 1;
        SOutput._operation_state = 3; // Memory error
        goto sap_�InterfaceLC�_basiccheckidlversion_1_svc_Return;
    }
    strcpy (SOutput.strInterfaceVersion.strInterfaceVersion_val, \"�InterfaceVersion�\");\
    SOutput.strInterfaceVersion.strInterfaceVersion_len = sizeof(char)*(strlen(\"�InterfaceVersion�\")+1);
    // Check version\
    if (strIDL2RPCVersion == \"".$g_VersionDate."\")\
    {\
        SOutput.iIDL2RPCVersionOK = 1; // OK\
    }\
    if (strInterfaceVersion == \"�InterfaceVersion�\")\
    {\
        SOutput.iInterfaceVersionOK = 1; // OK\
    }\
    if (SOutput.iInterfaceVersionOK && SOutput.iIDL2RPCVersionOK) \
    {\
        SOutput._Ret = 1; // OK \
    }\
    free (pSInput->strIDL2RPCVersion.strIDL2RPCVersion_val);\
    pSInput->strIDL2RPCVersion.strIDL2RPCVersion_val = NULL;\
    pSInput->strIDL2RPCVersion.strIDL2RPCVersion_len = 0;\
    free (pSInput->strInterfaceVersion.strInterfaceVersion_val);\
    pSInput->strInterfaceVersion.strInterfaceVersion_val = NULL;\
    pSInput->strInterfaceVersion.strInterfaceVersion_len = 0;\
    // =============================================================
    // Return jump point
    sap_�InterfaceLC�_basiccheckidlversion_1_svc_Return:
    // =============================================================\
    // Clean up \
    if (__usInternalError)\
    {\
        if (pSInput->strIDL2RPCVersion.strIDL2RPCVersion_val != NULL)\
        {\
            free (pSInput->strIDL2RPCVersion.strIDL2RPCVersion_val);\
            pSInput->strIDL2RPCVersion.strIDL2RPCVersion_val = NULL;\
            pSInput->strIDL2RPCVersion.strIDL2RPCVersion_len = 0;\
        }\
        if (pSInput->strInterfaceVersion.strInterfaceVersion_val != NULL)\
        {\
            free (pSInput->strInterfaceVersion.strInterfaceVersion_val);\
            pSInput->strInterfaceVersion.strInterfaceVersion_val = NULL;\
            pSInput->strInterfaceVersion.strInterfaceVersion_len = 0;\
        }\
        if (SOutput.strIDL2RPCVersion.strIDL2RPCVersion_val != NULL)
        {
            free (SOutput.strIDL2RPCVersion.strIDL2RPCVersion_val);
            SOutput.strIDL2RPCVersion.strIDL2RPCVersion_val = NULL;
            SOutput.strIDL2RPCVersion.strIDL2RPCVersion_len = 0;
        }
        if (SOutput.strInterfaceVersion.strInterfaceVersion_val != NULL)
        {
            free (SOutput.strInterfaceVersion.strInterfaceVersion_val);
            SOutput.strInterfaceVersion.strInterfaceVersion_val = NULL;
            SOutput.strInterfaceVersion.strInterfaceVersion_len = 0;
        }
    }\
    // =============================================================\
    // Return return value\
    return &SOutput;\
}\
\
/***********************************************************************\
 *  function  sap_�InterfaceLC�_basicresetserver_1_svc\
 ***********************************************************************/\
/*!           Always usable, given RPC-method to reset the server\
 *  \\param   void * pSInput -> Input structure with function parameter\
 *  \\param   struct svc_req * pSSvc -> Input structure with server/client info\
 *  \\return  void * <- NULL\
 ***********************************************************************/\
/*  author    Alexander Neidhardt\
 *  date      14.05.2007\
 *  revision  -\
 *  info      Part of the idl2rpc.pl - generator!\
 ***********************************************************************/\
void * sap_�InterfaceLC�_basicresetserver_1_svc (void * pSInput, struct svc_req * pSSvc)\
{\
    // Exit server => watchdog restarts it again
    (void)pSInput; // Reduce compiler warnings unused variables
    (void)pSSvc;   // Reduce compiler warnings unused variables
    exit(0);\
    \
    return NULL;\
}\
\
�InterfaceFunctionDefinitions�\
#ifdef __cplusplus\
} // extern \"C\"
#endif //__cplusplus\
";

my $g_ServerProcRPCMethodDefinitionTemplate = 
"/***********************************************************************\
 *  function  �RPCMethod�\
 ***********************************************************************/\
/*!           Generated interface method. See interface definition file! (defined by user)\
 ***********************************************************************/\
/*  author    Alexander Neidhardt\
 *  date      14.05.2007\
 *  revision  -\
 *  info      Part of the idl2rpc.pl - generator!\
 ***********************************************************************/\
�OUTStruct� �RPCMethod� (�INStruct�, struct svc_req * pSSvc)\
{\
    // RPC-in/out-structures\
    unsigned short __usInternalError = 0;\
    unsigned long ulReturnByteSum = 0;\
    �INVariableDefinition�\
    �OUTVariableDefinition�\
    �VariableDefinitions�\
    (void)pSInput; // Reduce compiler warnings unused variables
    (void)pSSvc;   // Reduce compiler warnings unused variables
    // =============================================================\
    // Initial check \
    if (g_ulUDPPort == 0 || g_ulTCPPort == 0)\
    {\
        __usInternalError = 1;\
        SOutput._operation_state = 5; // Wrong transport protocol\
        goto �RPCMethod�_Return;\
    }\
    �UDPPackagePossibility�\
    // =============================================================\
    // Variable init\
    �VariableInit�\
    // =============================================================\
    // Fill in-structure\
    �FillINVariables�\
    // =============================================================\
    // Call RPC-functionality at cpp-server\
    try \
    {\
        �ReturnValue� g_SServerMethods.�Method� (�Parameters�);\
        �ASDTouch�\
    }\
    catch (...)\
    {\
        __usInternalError = 1;\
        SOutput._operation_state = 4; // Operation with errors\
        goto �RPCMethod�_Return;\
    }\
    // =============================================================\
    // Set parameter return\
    �FillParameterReturn�\
    if (g_ulUDPPort == pSSvc->rq_xprt->xp_port &&\
        ulReturnByteSum > _MAXROUNDTRIPBYTESUM)\
    {\
        __usInternalError = 1;\
        SOutput._operation_state = 5; // Wrong transport protocol\
        goto �RPCMethod�_Return;\
    }\
    // =============================================================\
    // Return jump point\
    �RPCMethod�_Return:\
    // =============================================================\
    // Clean up \
    �FinalCleanUp�\
    if (__usInternalError)\
    {\
        �ErrorDelete�\
        �SetDefaultParameterReturn�\
    }\
    // =============================================================\
    // Return return value\
    �SetReturnValue�\
}\
";

my $g_ServerMainIncludeRPCReplacementsTemplate = 
"#include <sys/types.h>\
#include <sys/wait.h>\
#include <unistd.h>\
#include <signal.h>\
\
static unsigned int g_uiPIDSon;\
static unsigned int g_uiPIDDad;\
static int g_iUDPSocket;\
static int g_iTCPSocket;\
\
void vTermHandlerDad(int signal)\
{\
    (void)signal; // Reduce compiler warnings unused variable
    if (g_uiPIDSon != 0)\
    {\
        kill (g_uiPIDSon, SIGTERM);\
    }\
    exit (0);\
}\
\
void vTermHandlerSon(int signal)\
{\
    (void)signal; // Reduce compiler warnings unused variable
    pmap_unset (SAP_�Interface�, SAP_VERS_�Interface�);\
    if (g_iUDPSocket != -1 && g_iUDPSocket != 0)\
    {\
        close (g_iUDPSocket);
    }\
    if (g_iTCPSocket != -1 && g_iTCPSocket != 0)\
    {\
        close (g_iTCPSocket);
    }\
    if (g_uiPIDDad != 0)\
    {\
        kill (g_uiPIDDad, SIGTERM);\
    }\
    _vOnExitServerActivity ();\
    exit (0);\
}\
\
unsigned int uiInitInetServer (unsigned int uiPort,\
                               int * iSocket,\
                               unsigned int uiSocketProtocol)\
{\
    struct sockaddr_in STServerAddress;\
\
    /* Create socket */ \
    if (uiSocketProtocol == 0)\
    {\
        /* UDP = SOCK_DGRAM */
        if ((*iSocket = socket (AF_INET, SOCK_DGRAM, 0)) == -1)\
        {\
            return 1;\
        }\
    }\
    else\
    {\
        /* TCP = SOCK_STREAM */
        if ((*iSocket = socket (AF_INET, SOCK_STREAM, 0)) == -1)\
        {\
            return 1;\
        }\
    }\
    \
    /* Bind socket to address */\
    STServerAddress.sin_family = AF_INET;\
    STServerAddress.sin_addr.s_addr = htonl (INADDR_ANY);\
    STServerAddress.sin_port = htons (uiPort);\
    if (bind (*iSocket, (struct sockaddr *) & STServerAddress, sizeof (STServerAddress)) == -1)\
    {\
        close (*iSocket);\
        *iSocket = -1;\
        return 1;\
    }\
    \
    /* Activate the listen on socket */\
    /*\
    if (listen (*iSocket, 5) == -1)\
    {\
        close (*iSocket);\
        *iSocket = -1;\
        return 1;\
    }\
    */  \
    return 0;\
}\
";

my $g_ServerMainRPCStartupReplacementsTemplate = 
"    {\
        /* Check if server is already activated */
        unsigned short usServerIsRunning;\
        if ((usServerIsRunning = usCheckServerIsRunning ()))\
        {\
            if (usServerIsRunning == 2)\
                fprintf (stderr, \"Connection check with existing server has general errors, interrupt startup\\n\");\
            else\
                fprintf (stderr, \"Server is already running, interrupt startup\\n\");\
            return 1;\
        }\
    }\
";
my $g_ServerMainRPCReplacementsTemplate = 
"    {\
        /* Replacement for original svc_run (); */
        int iStateVal;\
        \
        while (1)\
        {\
            g_uiPIDDad = getpid();\
            g_uiPIDSon = fork ();\
            switch (g_uiPIDSon)\
            {\
                case -1:\
                    fprintf (stderr, \"\%s\", \"unable to fork process.\");\
                    exit (1);\
                case 0: /* Child */\
                    signal (SIGKILL, vTermHandlerSon);\
                    signal (SIGQUIT, vTermHandlerSon);\
                    signal (SIGTERM, vTermHandlerSon);\
                    signal (SIGINT, vTermHandlerSon);\
                    _vInitServerActivity (argc, argv);\
                    vPrivate_svc_run ();\
                    _vOnExitServerActivity ();\
                    kill (g_uiPIDDad, SIGTERM);\
                    pmap_unset (SAP_�Interface�, SAP_VERS_�Interface�);\
                    fprintf (stderr, \"\%s\", \"svc_run returned\\n\");\
                    exit (0);\
                    break;\
                default:\
                    signal (SIGKILL, vTermHandlerDad);\
                    signal (SIGQUIT, vTermHandlerDad);\
                    signal (SIGTERM, vTermHandlerDad);\
                    signal (SIGINT, vTermHandlerDad);\
                    wait (& iStateVal);\
                    fprintf (stderr, \"\%s\", \"svc_run terminated undefined and restarts\\n\");\
                    break;\
            }\
        }\
    }\
";

# Thread-class written by Andreas Leidig
# Changes to that code for usage in Perl-generator
# 1) Include guardian: SOSW_SIMPLE_THREAD_H_ ---> __�InterfaceFilenameWithoutExt�_SIMPLE_THREAD_H__
# 2) Class-name with prefix �Interface�_
# 3) \ ---> \\
# 4) ' ---> \'
# 5) " ---> \"
# 6) @ ---> \@
# 7) $ ---> \$
# 8) % ---> \%
# 9) Each line end needs a \
my $g_SimpleThreadClassDeclarationTemplate = 
"/***********************************************************************/\
/*! \\file �ModulFilename�\
 *  \\brief Interface code file defined at �InterfaceFilenameWithoutExt�.idl and generated by idl2rpc.pl<br>\
 ***********************************************************************/
 \
 ".
$g_FileHead.
"/*! \\brief definition of thread class \\n\
 *            Definition of\
 *             �Interface�_CSimpleThread            - an abstract minimal wrapper around posix pthread\
 *  \\author Andreas Leidig <leidig\@fs.wettzell.de>\
 *  \\date   11.08.2007\
 *  \\note  - Link pthread lib  :  LIBS = -lpthread \\n\
 *            - Use -D_THREAD_SAFE compilation flag    \\n\
 *            - The thread functionality of this class can only be used by subclassing - look at documentation and demo programs\
 *            - Method 'static void vWaitMillis(..)' may be used as general purpose wait function - without creating any thread instance\
 *           - Use class CSemaphore to synchronize thread operations\
 *          - This application was built using Eclipse CDT - text format on simple text editor may lack\
 * \\todo classify pthread return error codes\
 */\
\
#ifndef __�InterfaceFilenameWithoutExt�_SIMPLE_THREAD_H__\
#define __�InterfaceFilenameWithoutExt�_SIMPLE_THREAD_H__\
\
// Define needed in older compilers to set GNU mode
#ifndef _GNU_SOURCE\
#define _GNU_SOURCE\
#endif // _GNU_SOURCE\
\
#include <string>\
#include <pthread.h>\
#include <errno.h>\
\
\
// install thread execution method\
#ifdef __cplusplus\
extern \"C\" {\
#endif\
     void *pv�Interface�_CSimpleThreadCallback(void *pvInstance);\
#ifdef __cplusplus\
}//extern \"C\"\
#endif\
\
 \
/*!
 * \\class �Interface�_CSimpleThread\
 * \\brief �Interface�_CSimpleThread minimal abstract wrapper class around pthread\\n\
 * \\note\
 *  <ul style=\"list-style-type:square\">\
 *  <li> Link pthread lib  :  LIBS = -lpthread  </li>\
 *     <li> Use -D_THREAD_SAFE compilation flag    </li>\
*     <li> Method vWaitMillis() may be used as general purpose wait function </li>\
 *    <li> Use class CSemaphore to synchronize thread operations </li>\
 *     <h3>Example: </h3>\
 *      <pre>\
 *         <code>\
 *    // subclass �Interface�_CSimpleThread (f.e. named 'CAnyThreadClass') like this :\
 *    CAnyThreadClass: public �Interface�_CSimpleThread{\
 * \
 *        // define pvEntry() and..\
 *        void * pvEntry();\
 * \
 *    };\
 * \
 *     //  ..implement pvEntry() with exactly same signature    \
 *    void * CAnyThreadClass::pvEntry(){        \
 *         // ..perhaps do any initalization..    \
 *         while(m_bRunning){ \
 *            // ..        \
 *             // ..do someting useful..\
 *             // ..\
 *             vWaitMillis(1000);// wait (for example) one second    \
 *         }            \
 *         return NULL;\
 *    }                \
 * \
 *    // example constructor implementation    \
 *    CAnyThreadClass::CAnyThreadClass{\
 *        // ... do any initializations.. \\n\
 *        // start thread as detached thread f.e with initial delay 1 second. \
 *        // call 'iRun(..)' either inside your class or from outside (untested). \
 *        iRun(    true ,     // detached mode\
 *            1000 );  // starts in one second\
 *    }\
 *    </code>\
 * </pre>\
 * \\author Andreas Leidig <leidig\@fs.wettzell.de>\
 * \\date 24.04.2007\
 */ \
class �Interface�_CSimpleThread{\
    \
public:        \
    �Interface�_CSimpleThread(void);\
    virtual ~�Interface�_CSimpleThread(void);\
    \
    // call to run the thread    \
    int iRun(bool bDetached=true, const int iDelayMillis=0);\
    \
    // join (if thread was started in joinable mode)\
    int iWaitFor(void);\
        \
    // release scheduling (untested!)\
    void vYield(void);\
    \
    // stop thread by brute force\
    int iKill();\
\
    // identifier\
    unsigned int uiGetID();\
    \
    // thread-save static sleep method\
    static void vWaitMillis(const int iMilliSeconds);    \
    \
    \
    /// success code\
    static const int THREAD_SUCCESS = 0;\
    \
    /// error code - thread could not have been created\
    static const int THREAD_CREATION_ERROR = 10000;\
    \
protected:    \
    \
    /*!\
     * pvEntry - pure virtual method that will be executed by your custom thread implementation.\\n\
     * implement  in your own �Interface�_CSimpleThread - derived class with exactly the same signature.\
     * \\returns void * ptr - is usually NULL.\
     */    \
    virtual void * pvEntry(void)=0;\
    \
    /// hold activity information\
    bool               m_bRunning;\
            \
    \
private:    \
    // perform initial delay\
    void vInitialWait();\
    \
    // grant access to our private 'spvThreadCode()' method to thread installation callback routine\
    friend  void * pv�Interface�_CSimpleThreadCallback(void *pvInstance);    \
    \
    // static helper, not part of api\
    static void * spvThreadCode(void * pvInstance);\
            \
    /// start delay\
    int               m_iStartDelay;\
            \
    /// pthread identifier \
    pthread_t          m_tThreadId;\
\
    /// pthread attributes\
    pthread_attr_t        m_tAttr;\
};\
\
#endif\
";

# Thread-class written by Andreas Leidig
# Changes to that code for usage in Perl-generator
# 1) #include "simple_thread.h" ---> #include \"�InterfaceFilenameWithoutExt�_simple_thread.hpp\"
# 2) Class-name with prefix �Interface�_
# 3) \ ---> \\
# 4) ' ---> \'
# 5) " ---> \"
# 6) @ ---> \@
# 7) $ ---> \$
# 8) % ---> \%
# 9) Each line end needs a \
my $g_SimpleThreadClassDefinitionTemplate = 
"/***********************************************************************/\
/*! \\file �ModulFilename�\
 *  \\brief Interface code file defined at �InterfaceFilenameWithoutExt�.idl and generated by idl2rpc.pl<br>\
 ***********************************************************************/
 \
 ".
$g_FileHead.
"/*! \
 *  \\brief implementation of abstract thread base class \\n\
 *  \\see     �InterfaceFilenameWithoutExt�simple_thread.h\
 *  \\author Andreas Leidig <leidig\@fs.wettzell.de>\
 *  \\date   11.08.2007\
 */\
\
// Define needed in older compilers to set GNU mode
#ifndef _GNU_SOURCE\
#define _GNU_SOURCE\
#endif // _GNU_SOURCE\
\
#include <signal.h>\
#include <pthread.h>\
#include <sys/time.h>\
#include <sys/types.h>\
#include <unistd.h>\
\
#include \"�InterfaceFilenameWithoutExt�_simple_thread.hpp\"\
#include \"�InterfaceFilenameWithoutExt�_os.h\"\
\
/// thread save sleep emulation by using \'select(..)\' \
#define _WAIT_USE_SELECT_\
\
\
/*!\
 * pv�Interface�_CSimpleThreadCallback - global c - function returns static spvThreadCode �Interface�_CSimpleThread method\
 * \\param   pvInstance <-> pointer to �Interface�_CSimpleThread derived instance \
 * \\returns �Interface�_CSimpleThreads static  spvThreadCode method.\
 * \\author  Andreas Leidig <leidig\@fs.wettzell.de> \\n\
 * \\date    23.04.2007\
 */\
void *pv�Interface�_CSimpleThreadCallback(void *pvInstance){\
    return �Interface�_CSimpleThread::spvThreadCode(pvInstance);\
}\
\
\
/*!\
 * spvThreadCode - static method gets ptr to instance via pv_arg\
 * \\param   pvInstance <-> pointer to �Interface�_CSimpleThread derived instance\
 * \\returns call to spvThreadCode() - implementation of pure virtual �Interface�_CSimpleThread thread execution method\
 * \\author  Andreas Leidig <leidig\@fs.wettzell.de> \\n\
 * \\date    23.04.2007\
 */\
void * �Interface�_CSimpleThread::spvThreadCode(void * pvInstance){\
    �Interface�_CSimpleThread * pthread =  (�Interface�_CSimpleThread *) pvInstance;\
    //printf(\"init wait called\\n\");  \
    pthread->vInitialWait();            // perform initial delay\
    //printf(\"init wait returned\\n\");\
    return pthread->pvEntry();\
}\
\
\
/*!\
 * constructor \
 * \\author  Andreas Leidig <leidig\@fs.wettzell.de> \\n\
 * \\date    23.04.2007\
 */\
�Interface�_CSimpleThread::�Interface�_CSimpleThread():\
    m_bRunning(false) ,\
    m_iStartDelay(0)  { \
    pthread_attr_init     (&m_tAttr);\
}\
\
\
/*!\
 * destructor -\
 * stops thread - frees pthread attributes \
 * \\author  Andreas Leidig <leidig\@fs.wettzell.de> \\n\
 * \\date    23.04.2007\
 */\
�Interface�_CSimpleThread::~�Interface�_CSimpleThread(){ \
                // free attributes\
    pthread_attr_destroy(&m_tAttr);\
}\
\
\
/*!\
 * iRun - starts thread\
 * \\param bDetach        -> true  : 'detached' (fire-and-forget) pthread, recommended, default; \n \
 *                        false : 'joinable' pthread (you can wait on termination calling iWaitFor())\
 * \\param iDelayMillis -> delay thread start by iDelayMillis milliseconds, default is 0\
 * \\return 0 on success\
 * \\author  Andreas Leidig <leidig\@fs.wettzell.de> \\n\
 * \\date    23.04.2007\
 */\
int �Interface�_CSimpleThread::iRun(bool bDetach,const int iDelayMillis){\
    if(bDetach && m_bRunning)               // prevent nesting when 'detached'\
        return 0;\
    m_iStartDelay = iDelayMillis;           // save start delay (implement 'vWaitMillis(m_iStartDelay);' at startup of your service routine before entry of main loop)\
                                            // start thread\
    int ret = pthread_create(&m_tThreadId,    // thread id\
                              &m_tAttr,         // scheduling attributes\
                              pv�Interface�_CSimpleThreadCallback,// service function ptr\
                              (void *)this); // provide instance as service function argument\
    if(ret){        \
        m_bRunning = false;\
        return THREAD_CREATION_ERROR;\
    }\
    if(bDetach)\
        ret = pthread_detach(m_tThreadId);  // detach the thread \
    if(ret==0)\
        m_bRunning = true;\
    return ret;\
}\
\
\
/*!
 * iWaitFor - blocks until thread ends;\
 * \\returns 0 on success;\
 * \\note makes sense if thread was started in joinable mode : 'iRun(bool bDetached=false,..);'\
 * \\warning untested!\
 * \\author  Andreas Leidig <leidig\@fs.wettzell.de> \\n\
 * \\date    29.05.2007\
 */\
int �Interface�_CSimpleThread::iWaitFor(){\
    int iDetachstate;\
    pthread_attr_getdetachstate (&m_tAttr, &iDetachstate);\
    if(iDetachstate)\
        return 0;\
    return pthread_join(m_tThreadId, NULL);\
}\
\
\
/*!\
 * uiGetID - get thread identifier\
 * \\returns thread specific id\
 * \\author  Andreas Leidig <leidig\@fs.wettzell.de> \\n\
 * \\date    11.08.2007\
 */\
unsigned int �Interface�_CSimpleThread::uiGetID(){\
    pthread_t tid;\
    tid = pthread_self();\
    return (int)tid;\
}\
\
/*!\
 * iKill - sends signal SIGKILL to pthread\
 * \\returns 0 on success;\
 * \\note stops thread using brute force\
 * \\author  Andreas Leidig <leidig\@fs.wettzell.de> \\n\
 * \\date    31.05.2007\
 */\
int �Interface�_CSimpleThread::iKill(){\
    m_bRunning = false;\
    return pthread_kill ( m_tThreadId, SIGKILL );\
}\
\
\
/*!
 * vYield - forces the calling thread to relinquish use of its \\n\
 * processor and to wait in the run queue before it is scheduled again.\
 * \\warning not complete tested\
 * \\author  Andreas Leidig <leidig\@fs.wettzell.de> \\n\
 * \\date    23.04.2007\
 * \\todo     test pthread_yield() / sched_yield()\
 */\
void �Interface�_CSimpleThread::vYield(){\
    pthread_yield ();// release scheduling\
    //sched_yield(); // \
}\
\
\
/*!\
 * vInitialWait performes initial delay after calling iRun()\
 * \\author  Andreas Leidig <leidig\@fs.wettzell.de> \\n\
 * \\date    24.05.2007\
 */\
void �Interface�_CSimpleThread::vInitialWait(){\
    vWaitMillis(m_iStartDelay);\
}\
\
\
/*!
 * vWaitMillis - static thread-save wait implementation ( unlike usleep() is )\
 * \\param iMilliseconds -> timeout in milliseconds \
 * \\returns 0 on No Error; eSoswTrgErr on error \\see eSoswTrgErr\
 * \\note -can also be used as thread save general purpose wait function without using any seperate thread\
         -set USE_SELECT to choose the 'select(..)' based sleep emulation - nanosleep is used otherwise (don't know whats better)\
 * \\author  Andreas Leidig <leidig\@fs.wettzell.de> \\n\
 * \\date    23.04.2007\
 */ \
void �Interface�_CSimpleThread::vWaitMillis(const int iMilliseconds){\
    if(iMilliseconds <= 0)// nothin to wait\
        return;\
#ifndef _WAIT_USE_SELECT_                                // use nanosleep emulation\
    timespec tmReq;                                        \
    tmReq.tv_sec  = (time_t)(iMilliseconds / 1000);        // seconds fraction\
    tmReq.tv_nsec = (iMilliseconds \% 1000) * 1000000;    // nanoseconds fraction\
    (void)nanosleep(&tmReq, (timespec *)NULL);            // we're not interested in remaining time nor return value    \
#else                                                    // use select emulation\
    struct timeval timeout={(iMilliseconds / 1000),(iMilliseconds \% 1000) * 1000}; // sec, �sec   \
    select(0, 0, 0, 0, &timeout);                        // select() called with NULL filedescriptors blocks until timeout occurs\
#endif\
}\
\
";

# Semaphore-class written by Andreas Leidig and added with 
# Changes to that code for usage in Perl-generator
# 1) Include guardian: SOSW_SIMPLE_SEMAPHORE_H_ ---> __�InterfaceFilenameWithoutExt�_SIMPLE_SEMAPHORE_H__
# 2) Class-name with prefix �Interface�_
# 3) \ ---> \\
# 4) ' ---> \'
# 5) " ---> \"
# 6) @ ---> \@
# 7) $ ---> \$
# 8) % ---> \%
# 9) Each line end needs a \
my $g_SimpleSemaphoreClassDeclarationTemplate = 
"/***********************************************************************/\
/*! \\file �ModulFilename�\
 *  \\brief Interface code file defined at �InterfaceFilenameWithoutExt�.idl and generated by idl2rpc.pl<br>\
 ***********************************************************************/
 \
 ".
$g_FileHead.
"/*!
 *  \\brief definition of semaphore class \\n\
 *             Definition of\
 *             �Interface�_CSemaphore            - minimal wrapper around unnamed posix semaphore with \'timeout\' capability\
 *  \\author Andreas Leidig <leidig\@fs.wettzell.de>\
 *  \\date   11.08.2007\
 *  \\note  - Use this classes to synchronize thread operations (class CPThread)\
           - Always try to use this class with �Interface�_CSemaphoreLocker - usage will be safer\
 *          - This application was built using Eclipse CDT - text format on simple text editor may lack\
 */\
#ifndef __�InterfaceFilenameWithoutExt�_SIMPLE_SEMAPHORE_H__\
#define __�InterfaceFilenameWithoutExt�_SIMPLE_SEMAPHORE_H__\
\
// Define needed in older compilers to set GNU mode
#ifndef _GNU_SOURCE\
#define _GNU_SOURCE\
#endif // _GNU_SOURCE\
\
#include <string>\
\
#include <semaphore.h>\
#include <errno.h>\
\
/*!\
 * \\class �Interface�_CSemaphore\
 * \\brief �Interface�_CSemaphore minimal wrapper class around unnamed posix semaphore\
 * \\note \
 *  <ul style=\"list-style-type:square\">\
 *  <li> purpose: synchronization object for multithreaded process </li>\
 *     <li> provides additionally iGetValue() debug method </li>\
 *  <li> Always try to use this class with �Interface�_CSemaphoreLocker - usage will be safer </li>\
 * <p>\
 * <h3>Example: </h3>\
 *     <pre>\
 *      <code>\
 *         <p>\
 *  CAnyThreadClass:..{\
 *      ...\
 *         int iMySharedResourceAccessMethod();\
 *         // create as binary semaphore f.e. initially locked\
 *         �Interface�_CSemaphore m_sem(0);\
 *  };        \
 *         </p>\
 *      <p>\
 *    int CAnyThreadClass::iMySharedResourceAccessMethod(){\
 *         \
 *         // wait max 1 second until binary semaphore is free\
 *         m_sem.iWaitTimeout(1000);\
 *         \
 *         // check if sem could be locked (or timeout occurred)\
 *         if(m_sem.iError() == �Interface�_CSemaphore::SEM_SUCCESS)\
        {\
 *             // perform access to protected resource..\
 *             ...\
 *             return �Interface�_CSemaphore::SEM_SUCCESS;\
 *         }\
 *         else\
        {\
 *             // timeout occurred    \
 *             return �Interface�_CSemaphore::SEM_TIMEOUT;\
 *        } \
 *    }\
 *         </p>\
 *       </code>\
 *     </pre>\
 * </p>\
 * \\see �Interface�_CSemaphoreLocker support class\
 * \\author Andreas Leidig <leidig\@fs.wettzell.de>\
 * \\date 24.04.2007\
 */ \
class �Interface�_CSemaphore\
{\
  private: \
    /// max value for this sem ( \'1\' for binary \'mutex\' mode )\
    int m_iMaxCount;\
    /// holds error code for last operation made (or \'0\' if no error occurred)\
    int m_iError;\
    /// the semaphore\
    sem_t * m_Sem;\
  public:\
     enum {    \
        /// call was unsuccessful, the state of the semaphore shall be unchanged\
        SEM_UNCHANGED  = -1,\
        /// successfully decremented\
        SEM_SUCCESS    = 0,\
        /// sem was already locked, so it cannot be immediately locked by the sem_trywait() operation ( sem_trywait() only).\
        SEM_LOCKED       = EAGAIN,\
        /// sem could not be locked before the specified timeout expired.\
        SEM_TIMEOUT       = ETIMEDOUT,\
        /// a deadlock condition was detected.\
        SEM_DEAD       = EDEADLK,\
        /// a signal interrupted this function.\
        SEM_INTERRUPTED= EINTR,\
        /// the sem argument does not refer to a valid semaphore.\
        SEM_INVALID       = EINVAL\
    };\
  public:\
    // create semaphore in unlocked/binary mode\
    �Interface�_CSemaphore();\
    // copy constructor\
    �Interface�_CSemaphore(const �Interface�_CSemaphore & CIn);\
    // defaults to binary mode\
     �Interface�_CSemaphore(int iInitialCount, unsigned int iMaxCount=1);\
    // Destructor\
     virtual ~�Interface�_CSemaphore();\
    // assign operator\
    �Interface�_CSemaphore & operator= (const �Interface�_CSemaphore & CIn);\
    // explicite init\
    int iInit(int iInitialCount, unsigned int iMaxCountIn);\
     // increment\
     int iPost();\
     // decrement (non blocking)\
     int iTrySem();\
     // decrement (max blocking time in ms ->  timeout_millis)\
     int iWaitTimeout(unsigned long ulTimeoutMillis);\
     // decrement (maybe blocking forever) \
     int iWait();     \
     // diagnose methods, access is never blocking\
     int iGetValue(int & value);\
     int iError();\
     const char * pcErrDescr();\
     static const char * spcErrDescr(int iErr);\
};\
\
#endif // __�InterfaceFilenameWithoutExt�_SIMPLE_SEMAPHORE_H__\
\
";

# Semaphore-class written by Andreas Leidig and added with 
# Changes to that code for usage in Perl-generator
# 1) #include "simple_semaphore.h" ---> #include \"�InterfaceFilenameWithoutExt�_simple_semvar.hpp\"
# 2) Class-name with prefix �Interface�_
# 3) \ ---> \\
# 4) ' ---> \'
# 5) " ---> \"
# 6) @ ---> \@
# 7) $ ---> \$
# 8) % ---> \%
# 9) Each line end needs a \
my $g_SimpleSemaphoreClassDefinitionTemplate = 
"/***********************************************************************/\
/*! \\file �ModulFilename�\
 *  \\brief Interface code file defined at �InterfaceFilenameWithoutExt�.idl and generated by idl2rpc.pl<br>\
 ***********************************************************************/
 \
 ".
$g_FileHead.
"/*! \
 *  \\brief implementation of semaphore class \\n\
 *  \\see     simple_semaphore.h\
 *  \\author Andreas Leidig <leidig\@fs.wettzell.de>\
 *  \\date   11.08.2007\
 */\
\
// Define needed in older compilers to set GNU mode
#ifndef _GNU_SOURCE\
#define _GNU_SOURCE\
#endif // _GNU_SOURCE\
\
#include <signal.h>\
#include <sys/time.h>\
#include <time.h>\
#include <stdlib.h>\
#include \"�InterfaceFilenameWithoutExt�_simple_semvar.hpp\"\
#include \"�InterfaceFilenameWithoutExt�_os.h\"\
\
/*!\
 * constructor \\n\
 * inits the unnamed posix semaphore\
 * \\param iInitialCount -> initial value (0 means \'locked\'; > 0 \'unlocked\') must be <= iMaxCount\
 * \\param iMaxCountIn -> maximal value sem will be incrementable, default is 1 \'binary semaphore\'\
 * \\author  Andreas Leidig <leidig\@fs.wettzell.de>, A. Neidhardt \\n\
 * \\date    23.04.2007\
 */\
�Interface�_CSemaphore::�Interface�_CSemaphore(int iInitialCount, unsigned int iMaxCountIn)\
{\
    m_iMaxCount = 0;\
    m_iError = SEM_INVALID;\
    m_Sem = NULL;\
    \
    if ((m_Sem = (sem_t *) malloc (sizeof(sem_t))) == NULL)\
    {\
        m_iError = SEM_INVALID;\
        return;\
    }\
    if ((m_iError = sem_init(m_Sem /*the semaphore*/, 0 /*not shared to other process*/, \
                           iInitialCount /*initial value*/)))\
    {\
        free (m_Sem);\
        m_Sem = NULL;\
        return;\
    }\
    m_iMaxCount = iMaxCountIn;\
}\
\
/*!\
 * default constructor \\n\
 * inits the unnamed posix semaphore as unlocked and in binary mode\
 * \\author  Andreas Leidig <leidig\@fs.wettzell.de>, A. Neidhardt \\n\
 * \\date    11.08.2007\
 */\
�Interface�_CSemaphore::�Interface�_CSemaphore()\
{\
    m_iMaxCount = 0;\
    m_iError = SEM_INVALID;\
    m_Sem = NULL;\
    \
    if ((m_Sem = (sem_t *) malloc (sizeof(sem_t))) == NULL)\
    {\
        m_iError = SEM_INVALID;\
        return;\
    }\
    if ((m_iError = sem_init(m_Sem /*the semaphore*/, 0 /*not shared to other process*/, \
                           1 /*initial value*/)))\
    {\
        free (m_Sem);\
        m_Sem = NULL;\
        return;\
    }\
    m_iMaxCount = 1;\
}\
\
/*!\
 * copy constructor \\n\
 * inits the unnamed posix semaphore with given one\
 * \\author  A. Neidhardt \\n\
 * \\date    21.02.2008\
 */\
�Interface�_CSemaphore::�Interface�_CSemaphore(const �Interface�_CSemaphore & CIn)\
{\
    m_iMaxCount = CIn.m_iMaxCount;\
    m_iError = CIn.m_iError;\
    m_Sem = CIn.m_Sem;\
}\
\
/*!\
 * destructor \
 * destroys the unnamed posix semaphore\
 * \\todo : invent Destroy() method \
 * \\author  Andreas Leidig <leidig\@fs.wettzell.de>, A. Neidhardt \\n\
 * \\date    23.04.2007\
 */\
�Interface�_CSemaphore::~�Interface�_CSemaphore()\
{\
    int iSemValue = 0;\
    if (m_Sem != NULL)\
    {\
        if ((m_iError = iGetValue(iSemValue)) == SEM_SUCCESS)\
        {\
            if (iSemValue == 0)\
            {\
                // Semaphore is locked => free it\
                (void) iPost();\
            }\
        }\
         sem_destroy(m_Sem);\
         free (m_Sem);\
         m_Sem = NULL;\
    }\
}\
\
/*!\
 * operator = \\n\
 * assigns the unnamed posix semaphore with given one\
 * \\author  A. Neidhardt \\n\
 * \\date    21.02.2008\
 */\
�Interface�_CSemaphore & �Interface�_CSemaphore::operator= (const �Interface�_CSemaphore & CIn)\
{\
    int iSemValue = 0;\
    m_iMaxCount = CIn.m_iMaxCount;\
    m_iError = CIn.m_iError;\
    if (m_Sem != NULL)\
    {\
        if ((m_iError = iGetValue(iSemValue)) == SEM_SUCCESS)\
        {\
            if (iSemValue == 0)\
            {\
                // Semaphore is locked => free it\
                (void) iPost();\
            }\
        }\
         sem_destroy(m_Sem);\
        free (m_Sem);\
        m_Sem = NULL;    \
    }\
    m_Sem = CIn.m_Sem;\
    return *this;\
}\
\
/*!\
 * iInit \\n\
 * init a already set semaphore again\
 * \\author  A. Neidhardt \\n\
 * \\date    21.02.2008\
 */\
int �Interface�_CSemaphore::iInit(int iInitialCount = 0, unsigned int iMaxCountIn = 1)\
{\
    int iSemValue = 0;\
    // free existing semaphore\
    if (m_Sem != NULL)\
    {\
        if ((m_iError = iGetValue(iSemValue)) != SEM_SUCCESS)\
        {\
            return m_iError;\
        }\
        if (iSemValue == 0)\
        {\
            // Semaphore is locked => free it\
            if ((m_iError = iPost()) != SEM_SUCCESS)\
            {\
                return m_iError;\
            }\
        }\
         sem_destroy(m_Sem);\
        free (m_Sem);\
        m_Sem = NULL;    \
    }\
    // create new semaphore\
    if ((m_Sem = (sem_t *) malloc (sizeof(sem_t))) == NULL)\
    {\
        m_iError = SEM_INVALID;\
        return m_iError;\
    }\
    // init new semaphore\
    if ((m_iError = sem_init(m_Sem /*the semaphore*/, 0 /*not shared to other process*/, \
                           iInitialCount /*initial value*/)))\
    {\
        free (m_Sem);\
        m_Sem = NULL;\
        return m_iError;\
    }\
    m_iMaxCount = iMaxCountIn;\
    m_iError = SEM_SUCCESS;\
    return m_iError;\
}\
\
/*!\
 * iPost - increments (frees) the semaphore\
 * \\return 0 on success, m_iError on failiure\
 * \\author  Andreas Leidig <leidig\@fs.wettzell.de>, A. Neidhardt \\n\
 * \\date    23.04.2007\
 * \\note method is not blocking\
 */\
int �Interface�_CSemaphore::iPost()\
{\
    int iSemValue = 0;\
    if (m_Sem == NULL)\
    {\
        m_iError = SEM_INVALID;\
        return SEM_INVALID;\
    }\
    if ((m_iError = iGetValue(iSemValue)) != SEM_SUCCESS)\
        return m_iError;\
    if(iSemValue < m_iMaxCount)// if actual value is below max\
        m_iError = sem_post(m_Sem);\
    else                       // value is equal max, nothing will be done\
        m_iError = SEM_UNCHANGED;\
    return m_iError;\
}\
\
/*!\
 * iWait - blocks (maybe forever) until semaphore is > 0. Then decrements back ( = \'locks\' if 0).\
 * \\return 0 on success, m_iError on failiure\
 * \\note still untested, testers welcome!\
 * \\author  Andreas Leidig <leidig\@fs.wettzell.de>, A. Neidhardt \\n\
 * \\date    23.04.2007\
 * \\warning may block forever if semaphore will not be unlocked\
 */\
int �Interface�_CSemaphore::iWait()\
{\
    if (m_Sem == NULL)\
    {\
        m_iError = SEM_INVALID;\
        return SEM_INVALID;\
    }\
    return (m_iError=sem_wait(m_Sem));\
}\
\
/*!\
 * iTrySem - returns always immediatly . It decrements the semaphore value if it was > 0; \\n\
 *    else nothing will be changed. \
 * \\return 0 on success, m_iError on failiure\
 * \\author  Andreas Leidig <leidig\@fs.wettzell.de>, A. Neidhardt \\n\
 * \\date    23.04.2007\
 * \\note initial name \'iTryWait()\' was changed because this method never waits.\
 */\
int �Interface�_CSemaphore::iTrySem()\
{\
    if (m_Sem == NULL)\
    {\
        m_iError = SEM_INVALID;\
        return SEM_INVALID;\
    }\
    return (m_iError=sem_trywait(m_Sem));\
}\
\
/*!\
 * iWaitTimeout - blocks until semaphore is > 0 , then decrements (locks) \\n \
 * - or timeout occurs.(then nothing will be changed).\
 * \\param ulTimeoutMillis -> max timeout in milliseconds\
 * \\return 0 on success, m_iError on failiure\
 * \\author  Andreas Leidig <leidig\@fs.wettzell.de>, A. Neidhardt \\n\
 * \\date    23.04.2007\
 * \\note recommended semaphore access method\
 */\
int �Interface�_CSemaphore::iWaitTimeout(unsigned long ulTimeoutMillis)\
{\
    struct timespec  abs_timeout; // calc target absolute timeout\
    const int C_iBillion = 1000000000; // 1e9\
    struct timeval cur_epoch; // first\
\
    if (m_Sem == NULL)\
    {\
       m_iError = SEM_INVALID;\
       return SEM_INVALID;\
    }\
\
    gettimeofday( &cur_epoch, 0 ); // get current absolute epoch\
    abs_timeout.tv_nsec = (cur_epoch.tv_usec/*current microsecond*/ + (ulTimeoutMillis \% 1000) * 1000 )/*microseconds to wait*/ * 1000 /*nanoseconds*/;\
    abs_timeout.tv_sec = abs_timeout.tv_nsec / C_iBillion /*handle nanoseconds overflow*/ + cur_epoch.tv_sec/*current second*/ + ulTimeoutMillis / 1000/*seconds to wait*/;\
    abs_timeout.tv_nsec \%=C_iBillion; // strip billions -\
\
    // sem returns immidiate on ns overflow\
    m_iError = sem_timedwait(m_Sem, &abs_timeout);\
    return m_iError;\
}\
\
/*!\
 * iGetValue -  provides state of sem without changing anything, returns immediatly\
 * \\return actual value of semaphore\
 * \\author  Andreas Leidig <leidig\@fs.wettzell.de>, A. Neidhardt \\n\
 * \\date    23.04.2007\
 */\
int �Interface�_CSemaphore::iGetValue(int & value)\
{\
    if (m_Sem == NULL)\
    {\
        m_iError = SEM_INVALID;\
        return SEM_INVALID;\
    }\
    sem_getvalue(m_Sem, &value);\
    m_iError = SEM_SUCCESS;\
    return SEM_SUCCESS;\
}\
\
/*!\
 * iError - provides error code of last semaphore operation, returns immediatly\
 * \\return last error code of semaphore\
 * \\author  Andreas Leidig <leidig\@fs.wettzell.de>, A. Neidhardt \\n\
 * \\date    23.04.2007\
 * \\note call this method after iWaitTimeout() or iTrySem() to check if semaphore could be locked.\
 */\
int �Interface�_CSemaphore::iError()\
{\
    if (m_Sem == NULL)\
        return SEM_INVALID;\
    return m_iError;\
}\
\
/*!\
 * spcErrDescr - static method translates error code to string representation\
 * \\param iErr -> the error code\
 * \\return string representation of iErr error code\
 * \\note used by pcErrDescr\
 * \\author  Andreas Leidig <leidig\@fs.wettzell.de>, A. Neidhardt \\n\
 * \\date    23.04.2007\
 */\
const char * �Interface�_CSemaphore::spcErrDescr(int iErr)\
{\
    switch(iErr)\
    {\
        case SEM_UNCHANGED  : return \"Unchanged\";\
        case SEM_SUCCESS    : return \"Success\";\
        case SEM_LOCKED        : return \"Already locked\";\
        case SEM_TIMEOUT    : return \"Wait Timeout\";\
        case SEM_DEAD        : return \"Deadlock\";        \
        case SEM_INTERRUPTED: return \"Interrupted by signal\";\
        case SEM_INVALID    : return \"Invalid\";\
    }\
    return \"Unknown\";\
}\
\
/*!\
 * pcErrDescr - method translates error code of last sem operation to string representation\
 * \\return string representation of m_iError\
 * \\author  Andreas Leidig <leidig\@fs.wettzell.de>, A. Neidhardt \\n\
 * \\date    23.04.2007\
 */\
const char * �Interface�_CSemaphore::pcErrDescr()\
{\
    return spcErrDescr(m_iError);    \
}\
\
";

my $g_SimpleSemaphoreVariableClassDeclarationTemplate = 
"#ifndef __�InterfaceFilenameWithoutExt�_SIMPLE_SEMVAR_H__\
#define __�InterfaceFilenameWithoutExt�_SIMPLE_SEMVAR_H__\
\
// Define needed in older compilers to set GNU mode
#ifndef _GNU_SOURCE\
#define _GNU_SOURCE\
#endif // _GNU_SOURCE\
\
#include <string>\
#include <time.h>\
\
class �Interface�_semvar_throw\
{\
  private:\
    unsigned int _operation_state;\
    std::string strErrorMsg;\
\
  public:\
    �Interface�_semvar_throw () \
    {\
        _operation_state = 1;\
        strErrorMsg = \"\";\
    }\
            �Interface�_semvar_throw (const �Interface�_semvar_throw & CIn)\
    {\
        _operation_state = CIn._operation_state;\
        strErrorMsg = CIn.strErrorMsg;\
    }\
    ~�Interface�_semvar_throw ()\
    {\
        _operation_state = 1;\
        strErrorMsg = \"\";\
    }\
    �Interface�_semvar_throw & operator= (const �Interface�_semvar_throw & CIn)\
    {\
        _operation_state = CIn._operation_state;\
        strErrorMsg = CIn.strErrorMsg;\
        return *this;\
    }\
    unsigned short _usGetOperationState ()\
    {\
        return _operation_state;\
    }\
    std::string _strGetErrorMsg ()\
    {\
        return strErrorMsg;\
    }\
    void vSetThrowState (std::string strErrorMsgIn, unsigned short usOperationStateIn)\
    {\
        strErrorMsg = strErrorMsgIn;\
        _operation_state = usOperationStateIn;\
    }\
};\
template <class VarType> class �Interface�_semvar\
{\
    private:    \
        /// internal variable memory\
        VarType m_CVar;\
        /// the pointer to �Interface�_CSemaphore class\
        �Interface�_CSemaphore m_CSem;\
        /// timeout settings\
        int m_iSemTimeoutMSec;\
        /// Handle set when blocking is active
        unsigned long m_ulBlockHandle;
    private:\
        // Try to get semaphore\
        unsigned short usEnterSemaphore ();\
        // Give semaphore back\
        unsigned short usExitSemaphore ();\
    public:\
        // Standard constructor
        �Interface�_semvar () throw (�Interface�_semvar_throw);\
        // Standard constructor with parameter for timeout\
        �Interface�_semvar (int iSemTimeoutMSec) throw (�Interface�_semvar_throw);\
        // Copy-constructor\
        �Interface�_semvar (�Interface�_semvar<VarType> & CSemVar) throw (�Interface�_semvar_throw);\
        // Destructor\
        ~�Interface�_semvar () throw (�Interface�_semvar_throw);\
        // Asignment of VarType to semvar\
        �Interface�_semvar & operator= (const VarType & TVar) throw (�Interface�_semvar_throw);\
        // Asignment of semvar to semvar\
        �Interface�_semvar & operator= (const �Interface�_semvar<VarType> & CSemVar) throw (�Interface�_semvar_throw);\
        // Insert value into semaphore variable\
        void vInsertSemVal (VarType TVar) throw (�Interface�_semvar_throw);\
        void vSetSemVal (VarType TVar) throw (�Interface�_semvar_throw);\
        // Get value from semaphore variable\
        VarType CGetSemVal () throw (�Interface�_semvar_throw);    \
        // Explicit blocking methods and the additional access methods
        void vBlock (unsigned long & ulBlockHandle) throw (�Interface�_semvar_throw);\
        void vUnblock (unsigned long & ulBlockHandle) throw (�Interface�_semvar_throw);\
        void vSetSemVal (unsigned long & ulBlockHandle, VarType TVar) throw (�Interface�_semvar_throw);\
        VarType CGetSemVal (unsigned long & ulBlockHandle) throw (�Interface�_semvar_throw);\
};\
\
// ==================================================================================\
// semvar-definitions\
// ==================================================================================\
\
template <class VarType> unsigned short �Interface�_semvar<VarType>::usEnterSemaphore ()\
{\
    if (m_CSem.iError() > 0)\
    {\
        return 1;\
    }\
    if (m_iSemTimeoutMSec > 0)\
    {\
        // Wait with timeout\
        if (m_CSem.iWaitTimeout(m_iSemTimeoutMSec) > 0)\
        {\
           return 1;\
        }\
    }\
    else\
    {\
        // Wait infinitum\
        if (m_CSem.iWait() > 0)\
        {\
           return 1;\
        }\
    }\
    return 0;\
}\
\
template <class VarType> unsigned short �Interface�_semvar<VarType>::usExitSemaphore ()\
{\
    int iValue = 0;
    if (m_CSem.iError() > 0)\
    {\
        return 1;\
    }\
    if (m_CSem.iGetValue(iValue) > 0)\
    {\
        return 1;\
    }\
    if (iValue == 0)\
    {\
        // Semaphore is locked => free it\
        if (m_CSem.iPost() > 0)\
        {\
            return 1;\
        }\
    }\
    return 0;\
}\
\
template <class VarType> �Interface�_semvar<VarType>::�Interface�_semvar () throw (�Interface�_semvar_throw)\
{\
    m_iSemTimeoutMSec = 0;  // No timeout => wait infinitum\
    m_ulBlockHandle = 0;
    if (m_CSem.iError() > 0)\
    { \
        �Interface�_semvar_throw SemVarThrow;\
        SemVarThrow.vSetThrowState (\"Semaphore is not created\", 1);\
        throw (SemVarThrow);\
    }\
}\
\
template <class VarType> �Interface�_semvar<VarType>::�Interface�_semvar (int iSemTimeoutMSec) throw (�Interface�_semvar_throw)\
{\
    m_iSemTimeoutMSec = iSemTimeoutMSec;  // Set timeout\
    m_ulBlockHandle = 0;
    if (m_CSem.iError() > 0)\
    {\
        �Interface�_semvar_throw SemVarThrow;\
        SemVarThrow.vSetThrowState (\"Semaphore is not created\", 1);\
        throw (SemVarThrow);\
    }\
}\
\
template <class VarType> �Interface�_semvar<VarType>::�Interface�_semvar (�Interface�_semvar<VarType> & CSemVar) throw (�Interface�_semvar_throw)\
{\
    m_CSem = CSemVar.m_CSem;\
    if (m_CSem.iError() > 0)\
    {\
        �Interface�_semvar_throw SemVarThrow;\
        SemVarThrow.vSetThrowState (\"Semaphore is not created\", 1);\
        throw (SemVarThrow);\
    }\
    if (usEnterSemaphore())\
    {\
        �Interface�_semvar_throw SemVarThrow;\
        SemVarThrow.vSetThrowState (\"Critical section could not be entered\", 1);\
        throw (SemVarThrow);\
    }\
    m_iSemTimeoutMSec = CSemVar.m_iSemTimeoutMSec;\
    m_ulBlockHandle = CSemVar.m_ulBlockHandle;\
    m_CVar = CSemVar.m_CVar;\
    if (usExitSemaphore())\
    {\
        �Interface�_semvar_throw SemVarThrow;\
        SemVarThrow.vSetThrowState (\"Critical section could not be leaved\", 1);\
        throw (SemVarThrow);\
    }\
}\
\
template <class VarType> �Interface�_semvar<VarType>::~�Interface�_semvar () throw (�Interface�_semvar_throw)\
{\
    int iValue;
    if (m_CSem.iError() > 0)\
    {\
        �Interface�_semvar_throw SemVarThrow;\
        SemVarThrow.vSetThrowState (\"Semaphore is not created\", 1);\
        throw (SemVarThrow);\
    }\
    if (m_CSem.iGetValue(iValue) > 0)\
    {\
        �Interface�_semvar_throw SemVarThrow;\
        SemVarThrow.vSetThrowState (\"Semaphore is not created\", 1);\
        throw (SemVarThrow);\
    }\
    if (iValue == 0)\
    {\
        // Semaphore is locked => free it\
        if (m_CSem.iPost() > 0)\
        {\
            �Interface�_semvar_throw SemVarThrow;\
            SemVarThrow.vSetThrowState (\"Semaphore could not be deleted\", 1);\
            throw (SemVarThrow);\
        }\
    }\
}\
\
template <class VarType> �Interface�_semvar<VarType> & �Interface�_semvar<VarType>::operator= (const VarType & TVar) throw (�Interface�_semvar_throw)\
{\
    if (usEnterSemaphore())\
    {\
        �Interface�_semvar_throw SemVarThrow;\
        SemVarThrow.vSetThrowState (\"Critical section could not be entered\", 1);\
        throw (SemVarThrow);\
    }\
    m_ulBlockHandle = time(NULL);
    m_CVar = TVar;\
    m_ulBlockHandle = 0;\
    if (usExitSemaphore())\
    {\
        �Interface�_semvar_throw SemVarThrow;\
        SemVarThrow.vSetThrowState (\"Critical section could not be leaved\", 1);\
        throw (SemVarThrow);\
    }\
    return *this;\
}\
\
template <class VarType> �Interface�_semvar<VarType> & �Interface�_semvar<VarType>::operator= (const �Interface�_semvar<VarType> & CSemVar) throw (�Interface�_semvar_throw)\
{\
    m_CSem = CSemVar.m_CSem;\
    if (m_CSem.iError() > 0)\
    {\
        �Interface�_semvar_throw SemVarThrow;\
        SemVarThrow.vSetThrowState (\"Semaphore is not created\", 1);\
        throw (SemVarThrow);\
    }\
    if (usEnterSemaphore())\
    {\
        �Interface�_semvar_throw SemVarThrow;\
        SemVarThrow.vSetThrowState (\"Critical section could not be entered\", 1);\
        throw (SemVarThrow);\
    }\
    m_iSemTimeoutMSec = CSemVar.m_iSemTimeoutMSec;\
    m_ulBlockHandle = CSemVar.m_ulBlockHandle;\
    m_CVar = CSemVar.m_CVar;\
    if (usExitSemaphore())\
    {\
        �Interface�_semvar_throw SemVarThrow;\
        SemVarThrow.vSetThrowState (\"Critical section could not be leaved\", 1);\
        throw (SemVarThrow);\
    }\
    return *this;\
}\
\
template <class VarType> void �Interface�_semvar<VarType>::vInsertSemVal (VarType TVar) throw (�Interface�_semvar_throw)\
{\
    try
    {
        vSetSemVal (TVar);
    }
    catch (�Interface�_semvar_throw SemVarThrow)
    {
        throw (SemVarThrow);\
    }
}\
\
template <class VarType> void �Interface�_semvar<VarType>::vSetSemVal (VarType TVar) throw (�Interface�_semvar_throw)\
{\
    if (usEnterSemaphore())\
    {\
        �Interface�_semvar_throw SemVarThrow;\
        SemVarThrow.vSetThrowState (\"Critical section could not be entered\", 1);\
        throw (SemVarThrow);\
    }\
    m_ulBlockHandle = time(NULL);
    m_CVar = TVar;\
    m_ulBlockHandle = 0;
    if (usExitSemaphore())\
    {\
        �Interface�_semvar_throw SemVarThrow;\
        SemVarThrow.vSetThrowState (\"Critical section could not be leaved\", 1);\
        throw (SemVarThrow);\
    }\
}\
\
template <class VarType> VarType �Interface�_semvar<VarType>::CGetSemVal () throw (�Interface�_semvar_throw)\
{\
    VarType CContent;\
    if (usEnterSemaphore())\
    {\
        �Interface�_semvar_throw SemVarThrow;\
        SemVarThrow.vSetThrowState (\"Critical section could not be entered\", 1);\
        throw (SemVarThrow);\
    }\
    m_ulBlockHandle = time(NULL);
    CContent = m_CVar;\
    m_ulBlockHandle = 0;
    if (usExitSemaphore())\
    {\
        �Interface�_semvar_throw SemVarThrow;\
        SemVarThrow.vSetThrowState (\"Critical section could not be leaved\", 1);\
        throw (SemVarThrow);\
    }\
    return CContent;\
}\
\
template <class VarType> void �Interface�_semvar<VarType>::vBlock (unsigned long & ulBlockHandle) throw (�Interface�_semvar_throw)\
{\
    if (ulBlockHandle != 0)\
    {\
        �Interface�_semvar_throw SemVarThrow;\
        SemVarThrow.vSetThrowState (\"Critical section could not be entered\", 1);\
        throw (SemVarThrow);\
    }\
    if (usEnterSemaphore())\
    {\
        �Interface�_semvar_throw SemVarThrow;\
        SemVarThrow.vSetThrowState (\"Critical section could not be entered\", 1);\
        throw (SemVarThrow);\
    }\
    m_ulBlockHandle = time(NULL);\
    ulBlockHandle = m_ulBlockHandle;\
}\
\
template <class VarType> void �Interface�_semvar<VarType>::vUnblock (unsigned long & ulBlockHandle) throw (�Interface�_semvar_throw)\
{\
    if (m_ulBlockHandle == 0 || \
        m_ulBlockHandle != ulBlockHandle)\
    {\
        �Interface�_semvar_throw SemVarThrow;\
        SemVarThrow.vSetThrowState (\"Critical section could not be entered\", 1);\
        throw (SemVarThrow);\
    }\
    m_ulBlockHandle = 0;\
    ulBlockHandle = m_ulBlockHandle;\
    if (usExitSemaphore())\
    {\
        �Interface�_semvar_throw SemVarThrow;\
        SemVarThrow.vSetThrowState (\"Critical section could not be leaved\", 1);\
        throw (SemVarThrow);\
    }\
}\
\
template <class VarType> void �Interface�_semvar<VarType>::vSetSemVal (unsigned long & ulBlockHandle, VarType TVar) throw (�Interface�_semvar_throw)\
{\
    if (m_ulBlockHandle == 0 || \
        m_ulBlockHandle != ulBlockHandle)\
    {\
        �Interface�_semvar_throw SemVarThrow;\
        SemVarThrow.vSetThrowState (\"Critical section could not be entered\", 1);\
        throw (SemVarThrow);\
    }\
    m_CVar = TVar;\
}\
\
template <class VarType> VarType �Interface�_semvar<VarType>::CGetSemVal (unsigned long & ulBlockHandle) throw (�Interface�_semvar_throw)\
{\
    VarType CContent;\
    if (m_ulBlockHandle == 0 || 
        m_ulBlockHandle != ulBlockHandle)
    {\
        �Interface�_semvar_throw SemVarThrow;\
        SemVarThrow.vSetThrowState (\"Critical section could not be entered\", 1);\
        throw (SemVarThrow);\
    }\
    CContent = m_CVar;\
    return CContent;\
}\
#endif\
";

my $g_SimpleSemaphoreVariableClassDefinitionTemplate = 
"/***********************************************************************/\
/*! \\file �ModulFilename�\
 *  \\brief Interface code file defined at �InterfaceFilenameWithoutExt�.idl and generated by idl2rpc.pl<br>\
 ***********************************************************************/
 \
 ".
$g_FileHead.
"\
#include \"�InterfaceFilenameWithoutExt�_os.h\"\
";

my $g_SimpleSemaphoreVariableDummyClassDeclarationTemplate = 
"/***********************************************************************/\
/*! \\file �ModulFilename�\
 *  \\brief Interface code file defined at �InterfaceFilenameWithoutExt�.idl and generated by idl2rpc.pl<br>\
 ***********************************************************************/
 \
 ".
$g_FileHead.
"#ifndef __�InterfaceFilenameWithoutExt�_SIMPLE_SEMVAR_H__\
#define __�InterfaceFilenameWithoutExt�_SIMPLE_SEMVAR_H__\
\
// Define needed in older compilers to set GNU mode
#ifndef _GNU_SOURCE\
#define _GNU_SOURCE\
#endif // _GNU_SOURCE\
\
#include <string>\
class �Interface�_semvar_throw\
{\
  private:\
    unsigned int _operation_state;\
    std::string strErrorMsg;\
\
  public:\
    �Interface�_semvar_throw () \
    {\
        _operation_state = 1;\
        strErrorMsg = \"\";\
    }\
            �Interface�_semvar_throw (const �Interface�_semvar_throw & CIn)\
    {\
        _operation_state = CIn._operation_state;\
        strErrorMsg = CIn.strErrorMsg;\
    }\
    ~�Interface�_semvar_throw ()\
    {\
        _operation_state = 1;\
        strErrorMsg = \"\";\
    }\
    �Interface�_semvar_throw & operator= (const �Interface�_semvar_throw & CIn)\
    {\
        _operation_state = CIn._operation_state;\
        strErrorMsg = CIn.strErrorMsg;\
        return *this;\
    }\
    unsigned short _usGetOperationState ()\
    {\
        return _operation_state;\
    }\
    std::string _strGetErrorMsg ()\
    {\
        return strErrorMsg;\
    }\
    void vSetThrowState (std::string strErrorMsgIn, unsigned short usOperationStateIn)\
    {\
        strErrorMsg = strErrorMsgIn;\
        _operation_state = usOperationStateIn;\
    }\
};\
template <class VarType> class �Interface�_semvar\
{\
    private:    \
        /// internal variable memory\
        VarType m_CVar;\
        /// timeout settings\
        int m_iSemTimeoutMSec;\
    private:\
        // Try to get semaphore\
        unsigned short usEnterSemaphore ();\
        // Give semaphore back\
        unsigned short usExitSemaphore ();\
    public:\
        // Standard constructor
        �Interface�_semvar () throw (�Interface�_semvar_throw);\
        // Standard constructor with parameter for timeout\
        �Interface�_semvar (int iSemTimeoutMSec) throw (�Interface�_semvar_throw);\
        // Copy-constructor\
        �Interface�_semvar (�Interface�_semvar<VarType> & CSemVar) throw (�Interface�_semvar_throw);\
        // Destructor\
        ~�Interface�_semvar () throw (�Interface�_semvar_throw);\
        // Asignment of VarType to semvar\
        �Interface�_semvar & operator= (const VarType & TVar) throw (�Interface�_semvar_throw);\
        // Asignment of semvar to semvar\
        �Interface�_semvar & operator= (const �Interface�_semvar<VarType> & CSemVar) throw (�Interface�_semvar_throw);\
        // Insert value into semaphore variable\
        void vInsertSemVal (VarType TVar) throw (�Interface�_semvar_throw);\
        void vSetSemVal (VarType TVar) throw (�Interface�_semvar_throw);\
        // Get value of semaphore variable\
        VarType CGetSemVal () throw (�Interface�_semvar_throw);    \
        // Explicit blocking methods and the additional access methods
        void vBlock (unsigned long & ulBlockHandle) throw (�Interface�_semvar_throw);\
        void vUnblock (unsigned long & ulBlockHandle) throw (�Interface�_semvar_throw);\
        void vSetSemVal (unsigned long & ulBlockHandle, VarType TVar) throw (�Interface�_semvar_throw);\
        VarType CGetSemVal (unsigned long & ulBlockHandle) throw (�Interface�_semvar_throw);\
};\
\
// ==================================================================================\
// semvar-definitions\
// ==================================================================================\
\
template <class VarType> unsigned short �Interface�_semvar<VarType>::usEnterSemaphore ()\
{\
    return 0;\
}\
\
template <class VarType> unsigned short �Interface�_semvar<VarType>::usExitSemaphore ()\
{\
    return 0;\
}\
\
template <class VarType> �Interface�_semvar<VarType>::�Interface�_semvar () throw (�Interface�_semvar_throw)\
{\
    m_iSemTimeoutMSec = 0;  // No timeout => wait infinitum\
}\
\
template <class VarType> �Interface�_semvar<VarType>::�Interface�_semvar (int iSemTimeoutMSec) throw (�Interface�_semvar_throw)\
{\
    m_iSemTimeoutMSec = iSemTimeoutMSec;  // Set timeout\
}\
\
template <class VarType> �Interface�_semvar<VarType>::�Interface�_semvar (�Interface�_semvar<VarType> & CSemVar) throw (�Interface�_semvar_throw)\
{\
    m_iSemTimeoutMSec = CSemVar.m_iSemTimeoutMSec;\
    m_CVar = CSemVar.m_CVar;\
}\
\
template <class VarType> �Interface�_semvar<VarType>::~�Interface�_semvar () throw (�Interface�_semvar_throw)\
{\
}\
\
template <class VarType> �Interface�_semvar<VarType> & �Interface�_semvar<VarType>::operator= (const VarType & TVar) throw (�Interface�_semvar_throw)\
{\
    m_CVar = TVar;\
    return *this;\
}\
\
template <class VarType> �Interface�_semvar<VarType> & �Interface�_semvar<VarType>::operator= (const �Interface�_semvar<VarType> & CSemVar) throw (�Interface�_semvar_throw)\
{\
    m_iSemTimeoutMSec = CSemVar.m_iSemTimeoutMSec;\
    m_CVar = CSemVar.m_CVar;\
    return *this;\
}\
\
template <class VarType> void �Interface�_semvar<VarType>::vInsertSemVal (VarType TVar) throw (�Interface�_semvar_throw)\
{\
    try
    {
        vSetSemVal (TVar);
    }
    catch (�Interface�_semvar_throw SemVarThrow)
    {
        throw (SemVarThrow);\
        return;\
    }
}\
\
template <class VarType> void �Interface�_semvar<VarType>::vSetSemVal (VarType TVar) throw (�Interface�_semvar_throw)\
{\
    if (usEnterSemaphore())\
    {\
        �Interface�_semvar_throw SemVarThrow;\
        SemVarThrow.vSetThrowState (\"Critical section could not be entered\", 1);\
        throw (SemVarThrow);\
        return;\
    }\
    m_CVar = TVar;\
    if (usExitSemaphore())\
    {\
        �Interface�_semvar_throw SemVarThrow;\
        SemVarThrow.vSetThrowState (\"Critical section could not be leaved\", 1);\
        throw (SemVarThrow);\
        return;\
    }\
}\
\
template <class VarType> VarType �Interface�_semvar<VarType>::CGetSemVal () throw (�Interface�_semvar_throw)\
{\
    VarType CContent;\
    if (usEnterSemaphore())\
    {\
        �Interface�_semvar_throw SemVarThrow;\
        SemVarThrow.vSetThrowState (\"Critical section could not be entered\", 1);\
        throw (SemVarThrow);\
        return CContent;\
    }\
    CContent = m_CVar;\
    if (usExitSemaphore())\
    {\
        �Interface�_semvar_throw SemVarThrow;\
        SemVarThrow.vSetThrowState (\"Critical section could not be leaved\", 1);\
        throw (SemVarThrow);\
        return CContent;\
    }\
    return CContent;\
}\
\
template <class VarType> void �Interface�_semvar<VarType>::vBlock (unsigned long & ulBlockHandle) throw (�Interface�_semvar_throw)\
{\
    ulBlockHandle = 0;\
    return;\
}\
\
template <class VarType> void �Interface�_semvar<VarType>::vUnblock (unsigned long & ulBlockHandle) throw (�Interface�_semvar_throw)\
{\
    ulBlockHandle = 0;\
    return;\
}\
\
template <class VarType> void �Interface�_semvar<VarType>::vSetSemVal (unsigned long & ulBlockHandle, VarType TVar) throw (�Interface�_semvar_throw)\
{\
    try\
    {\
        vSetSemVal (TVar);\
    }\
    catch (�Interface�_semvar_throw SemVarThrow)\
    {\
        throw (SemVarThrow);\
        return;\
    }\
}\
\
template <class VarType> VarType �Interface�_semvar<VarType>::CGetSemVal (unsigned long & ulBlockHandle) throw (�Interface�_semvar_throw)\
{\
    VarType CContent;\
    try\
    {\
        CContent = CGetSemVal ();\
    }\
    catch (�Interface�_semvar_throw SemVarThrow)\
    {\
        throw (SemVarThrow);\
        return CContent;\
    }\
    return CContent;\
}\
#endif\
";

my $g_SimpleSemaphoreVariableDummyClassDefinitionTemplate = 
"/***********************************************************************/\
/*! \\file �ModulFilename�\
 *  \\brief Interface code file defined at �InterfaceFilenameWithoutExt�.idl and generated by idl2rpc.pl<br>\
 ***********************************************************************/
 \
 ".
$g_FileHead.
"\
";

# ===================================================================================
# RPC-X-file part
# ---------------
# The following elements and functions are used to create the parts of the RPC-X-file
# which is used by rpcgen to create the server and client modules
# ===================================================================================
# Global variables: blocks of the resulting files
# The following variables are only handled by the RPCX-functions and not directly while running other functions
my $g_RPCX_DEFINITION_BLOCK = "";        # Here are the definitions of RPC-X-file, constructed while parsing
my $g_RPCX_PROGRAM_BLOCK = "";           # Here are the program parts of RPC-X-file and the final completed file parts, constructed while parsing
my $g_RPCX_FUNCTION_INPUTSTRUCT = "";    # Here are the input structure elements iteratively of each function for RPC-X-file, constructed while parsing and added to definition block
my $g_RPCX_FUNCTION_OUTPUTSTRUCT = "";   # Here are the output structure elements iteratively of each function for RPC-X-file, constructed while parsing and added to definition block
my $g_RPCX_CLASS_IDENTIFIER = "";        # This is a marker for current class name
my $g_RPCX_PROGRAM_NUMBER = "";          # This is a marker for program number registrated at portmaper (interface part)
my $g_RPCX_FUNCTION_IDENTIFIER = "";     # This is a marker for current function name
my $g_RPCX_FUNCTION_RETURN = "";         # This is a marker for current function return type
my $g_RPCX_PARAMETER_IO = "";            # This is a marker for current parameter input/output- direction
my $g_RPCX_PARAMETER_TYPE = "";          # This is a marker for current parameter type
my $g_RPCX_PARAMETER_IDENTIFIER = "";    # This is a marker for current parameter name
my $g_RPCX_LENVARIABLE_NAME = "";        # This is a marker for length variables of multiple arrays
my $g_RPCX_NEWTYPE_TYPE = "";            # This is a marker for current type in a new type definition
my $g_RPCX_NEWTYPE_IDENTIFIER = "";      # This is a marker for current type name in a new type definition
my $g_RPCX_INTERFACE_VERSION = "";       # This is a marker for version of interface

# >--------------------------------------------------------------------------<
# > Subroutine: AddToRPCX_DEFINITION_BLOCK                                   <
# >             Add an expression to definition block of RPC-X-file          <
# > Parameter:  $Expression -> Expression which should be added              <
# > Return:     -                                                            <
# > Author:     A. Neidhardt                                                 <
# > Date:       07.02.2007                                                   <
# > Revision:   -                                                            <
# > Info:       -                                                            <
# >--------------------------------------------------------------------------<
sub AddToRPCX_DEFINITION_BLOCK {
    my ($Expression)=@_;
    
    $g_RPCX_DEFINITION_BLOCK = $g_RPCX_DEFINITION_BLOCK.$Expression;
}

# >--------------------------------------------------------------------------<
# > Subroutine: ReplaceAtRPCX_DEFINITION_BLOCK                               <
# >             Replace speficied wildcards with another expression at       <
# >             definition block of RPC-X-file                               <
# > Parameter:  $ReplaceExpression -> Expression which should be replaced    <
# >             $NewExpression -> Expression which is new                    <
# > Return:     -                                                            <
# > Author:     A. Neidhardt                                                 <
# > Date:       07.02.2007                                                   <
# > Revision:   -                                                            <
# > Info:       -                                                            <
# >--------------------------------------------------------------------------<
sub ReplaceAtRPCX_DEFINITION_BLOCK {
    my ($ReplaceExpression,$NewExpression)=@_;
    
    $g_RPCX_DEFINITION_BLOCK =~ s/$ReplaceExpression/$NewExpression/g;;
}

# >--------------------------------------------------------------------------<
# > Subroutine: AddToRPCX_PROGRAM_BLOCK                                      <
# >             Add an expression to program block of RPC-X-file             <
# > Parameter:  $Expression -> Expression which should be added              <
# > Return:     -                                                            <
# > Author:     A. Neidhardt                                                 <
# > Date:       07.02.2007                                                   <
# > Revision:   -                                                            <
# > Info:       -                                                            <
# >--------------------------------------------------------------------------<
sub AddToRPCX_PROGRAM_BLOCK {
    my ($Expression)=@_;
    
    $g_RPCX_PROGRAM_BLOCK = $g_RPCX_PROGRAM_BLOCK.$Expression;
}

# >--------------------------------------------------------------------------<
# > Subroutine: AddFunctionStructuresToRPCX_DEFINITION_BLOCK                 <
# >             Add a created in- and ouptut structures of current function  <
# >             to definition block of RPC-X-file                            <
# > Parameter:  -                                                            <
# > Return:     -                                                            <
# > Author:     A. Neidhardt                                                 <
# > Date:       07.02.2007                                                   <
# > Revision:   -                                                            <
# > Info:       -                                                            <
# >--------------------------------------------------------------------------<
sub AddFunctionStructuresToRPCX_DEFINITION_BLOCK {
    $g_RPCX_DEFINITION_BLOCK = $g_RPCX_DEFINITION_BLOCK.$g_RPCX_FUNCTION_INPUTSTRUCT;
    $g_RPCX_DEFINITION_BLOCK = $g_RPCX_DEFINITION_BLOCK.$g_RPCX_FUNCTION_OUTPUTSTRUCT;
    $g_RPCX_FUNCTION_INPUTSTRUCT = "";
    $g_RPCX_FUNCTION_OUTPUTSTRUCT = "";
}

# >--------------------------------------------------------------------------<
# > Subroutine: NoteClassIdentifier                                          <
# >             Notice class name as reminder                                <
# > Parameter:  $Expression -> Class name                                    <
# > Return:     -                                                            <
# > Author:     A. Neidhardt                                                 <
# > Date:       09.02.2007                                                   <
# > Revision:   -                                                            <
# > Info:       -                                                            <
# >--------------------------------------------------------------------------<
sub NoteClassIdentifier {
    my ($Expression)=@_;
    
    $g_RPCX_CLASS_IDENTIFIER = $Expression;
}

# >--------------------------------------------------------------------------<
# > Subroutine: GetClassIdentifier                                           <
# >             Get saved class reminder                                     <
# > Parameter:  -                                                            <
# > Return:     <- Class name                                                <
# > Author:     A. Neidhardt                                                 <
# > Date:       09.02.2007                                                   <
# > Revision:   -                                                            <
# > Info:       -                                                            <
# >--------------------------------------------------------------------------<
sub GetClassIdentifier {
    return $g_RPCX_CLASS_IDENTIFIER;
}

# >--------------------------------------------------------------------------<
# > Subroutine: NoteProgramNumber                                            <
# >             Notice class name as reminder                                <
# > Parameter:  $Expression -> Class name                                    <
# > Return:     -                                                            <
# > Author:     A. Neidhardt                                                 <
# > Date:       05.10.2007                                                   <
# > Revision:   -                                                            <
# > Info:       -                                                            <
# >--------------------------------------------------------------------------<
sub NoteProgramNumber {
    my ($Expression,$ProgramNumberPrefix)=@_;
    my $Index = 0;
    my $Input = $Expression;
    my $Character;
    my $Mult = 1;
    
    $g_RPCX_PROGRAM_NUMBER = 0;
    
    while (length ($Input) > 0) {
        ($Character,$Input) = ($Input =~ /^(\w)(.*)$/);
        $g_RPCX_PROGRAM_NUMBER = $g_RPCX_PROGRAM_NUMBER + ord($Character)*$Mult;
        $g_RPCX_PROGRAM_NUMBER = $g_RPCX_PROGRAM_NUMBER % 1000000;
        $Mult = $Mult *10;
        if ($Mult > 1000) {
            $Mult = 1;
        }
    }
    $g_RPCX_PROGRAM_NUMBER = $g_RPCX_PROGRAM_NUMBER + $ProgramNumberPrefix;
}

# >--------------------------------------------------------------------------<
# > Subroutine: GetProgramNumber                                             <
# >             Get saved program number reminder                            <
# > Parameter:  -                                                            <
# > Return:     <- Class name                                                <
# > Author:     A. Neidhardt                                                 <
# > Date:       05.10.2007                                                   <
# > Revision:   -                                                            <
# > Info:       -                                                            <
# >--------------------------------------------------------------------------<
sub GetProgramNumber {
    return $g_RPCX_PROGRAM_NUMBER;
}

# >--------------------------------------------------------------------------<
# > Subroutine: GetInterfaceVersion                                          <
# >             Get saved interface version                                  <
# > Parameter:  -                                                            <
# > Return:     <- Version                                                   <
# > Author:     A. Neidhardt                                                 <
# > Date:       30.10.2008                                                   <
# > Revision:   -                                                            <
# > Info:       -                                                            <
# >--------------------------------------------------------------------------<
sub GetInterfaceVersion {
    return $g_RPCX_INTERFACE_VERSION;
}

# >--------------------------------------------------------------------------<
# > Subroutine: NoteInterfaceVersion                                         <
# >             Set interface version                                        <
# > Parameter:  -> Version                                                   <
# > Return:     -                                                            <
# > Author:     A. Neidhardt                                                 <
# > Date:       30.10.2008                                                   <
# > Revision:   -                                                            <
# > Info:       -                                                            <
# >--------------------------------------------------------------------------<
sub NoteInterfaceVersion {
    my ($Expression)=@_;
    
    $g_RPCX_INTERFACE_VERSION = $Expression;
}

# >--------------------------------------------------------------------------<
# > Subroutine: GetProgramNumberHex                                          <
# >             Get saved program number reminder                            <
# > Parameter:  -                                                            <
# > Return:     <- Class name                                                <
# > Author:     A. Neidhardt                                                 <
# > Date:       05.10.2007                                                   <
# > Revision:   -                                                            <
# > Info:       -                                                            <
# >--------------------------------------------------------------------------<
sub GetProgramNumberHex {
    return ("0x".(sprintf ("%lx", $g_RPCX_PROGRAM_NUMBER)));
}

# >--------------------------------------------------------------------------<
# > Subroutine: NoteFunctionIdentifier                                       <
# >             Notice function name as reminder                             <
# > Parameter:  $Expression -> Function name                                 <
# > Return:     -                                                            <
# > Author:     A. Neidhardt                                                 <
# > Date:       07.02.2007                                                   <
# > Revision:   -                                                            <
# > Info:       -                                                            <
# >--------------------------------------------------------------------------<
sub NoteFunctionIdentifier {
    my ($Expression)=@_;
    
    $g_RPCX_FUNCTION_IDENTIFIER = $Expression;
}

# >--------------------------------------------------------------------------<
# > Subroutine: GetFunctionIdentifier                                        <
# >             Get saved function reminder                                  <
# > Parameter:  -                                                            <
# > Return:     <- Function name                                             <
# > Author:     A. Neidhardt                                                 <
# > Date:       07.02.2007                                                   <
# > Revision:   -                                                            <
# > Info:       -                                                            <
# >--------------------------------------------------------------------------<
sub GetFunctionIdentifier {
    return $g_RPCX_FUNCTION_IDENTIFIER;
}

# >--------------------------------------------------------------------------<
# > Subroutine: NoteFunctionReturnType                                       <
# >             Notice function return type as reminder                      <
# > Parameter:  $Expression -> Function return type                          <
# > Return:     -                                                            <
# > Author:     A. Neidhardt                                                 <
# > Date:       20.02.2007                                                   <
# > Revision:   -                                                            <
# > Info:       -                                                            <
# >--------------------------------------------------------------------------<
sub NoteFunctionReturnType {
    my ($Expression)=@_;
    
    $g_RPCX_FUNCTION_RETURN = $Expression;
}

# >--------------------------------------------------------------------------<
# > Subroutine: GetFunctionReturnType                                        <
# >             Get saved function return type reminder                      <
# > Parameter:  -                                                            <
# > Return:     <- Function return type                                      <
# > Author:     A. Neidhardt                                                 <
# > Date:       07.02.2007                                                   <
# > Revision:   -                                                            <
# > Info:       -                                                            <
# >--------------------------------------------------------------------------<
sub GetFunctionReturnType {
    return $g_RPCX_FUNCTION_RETURN;
}

# >--------------------------------------------------------------------------<
# > Subroutine: AddToRPCX_FUNCTION_INPUTSTRUCT                               <
# >             Add expressions to input structure definition of a current   <
# >             function (later it will be added to definition block)        <
# > Parameter:  $Expression -> Expression which should be added              <
# > Return:     -                                                            <
# > Author:     A. Neidhardt                                                 <
# > Date:       07.02.2007                                                   <
# > Revision:   -                                                            <
# > Info:       -                                                            <
# >--------------------------------------------------------------------------<
sub AddToRPCX_FUNCTION_INPUTSTRUCT {
    my ($Expression)=@_;
    
    $g_RPCX_FUNCTION_INPUTSTRUCT = $g_RPCX_FUNCTION_INPUTSTRUCT.$Expression;
}

# >--------------------------------------------------------------------------<
# > Subroutine: AddToRPCX_FUNCTION_OUTPUTSTRUCT                              <
# >             Add expressions to output structure definition of a current  <
# >             function (later it will be added to definition block)        <
# > Parameter:  $Expression -> Expression which should be added              <
# > Return:     -                                                            <
# > Author:     A. Neidhardt                                                 <
# > Date:       07.02.2007                                                   <
# > Revision:   -                                                            <
# > Info:       -                                                            <
# >--------------------------------------------------------------------------<
sub AddToRPCX_FUNCTION_OUTPUTSTRUCT {
    my ($Expression)=@_;
    
    $g_RPCX_FUNCTION_OUTPUTSTRUCT = $g_RPCX_FUNCTION_OUTPUTSTRUCT.$Expression;
}


# >--------------------------------------------------------------------------<
# > Subroutine: ReplaceAtRPCX_FUNCTION_OUTPUTSTRUCT                          <
# >             Replace speficied wildcards with another expression at       <
# >             output structure definition                                  <
# > Parameter:  $ReplaceExpression -> Expression which should be replaced    <
# >             $NewExpression -> Expression which is new                    <
# > Return:     -                                                            <
# > Author:     A. Neidhardt                                                 <
# > Date:       07.02.2007                                                   <
# > Revision:   -                                                            <
# > Info:       -                                                            <
# >--------------------------------------------------------------------------<
sub ReplaceAtRPCX_FUNCTION_OUTPUTSTRUCT {
    my ($ReplaceExpression,$NewExpression)=@_;
    
    $g_RPCX_FUNCTION_OUTPUTSTRUCT =~ s/$ReplaceExpression/$NewExpression/g;;
}

# >--------------------------------------------------------------------------<
# > Subroutine: FunctionHasOutputStructure                                   <
# >             Check if output structure is defined                         <
# > Parameter:  -                                                            <
# > Return:     <- Bool (yes = greater 0, no = 0)                            <
# > Author:     A. Neidhardt                                                 <
# > Date:       07.02.2007                                                   <
# > Revision:   -                                                            <
# > Info:       -                                                            <
# >--------------------------------------------------------------------------<
sub FunctionHasOutputStructure {
    return length ($g_RPCX_FUNCTION_OUTPUTSTRUCT);
}

# >--------------------------------------------------------------------------<
# > Subroutine: FunctionHasInputStructure                                    <
# >             Check if input structure is defined                          <
# > Parameter:  -                                                            <
# > Return:     <- Bool (yes = greater 0, no = 0)                            <
# > Author:     A. Neidhardt                                                 <
# > Date:       07.02.2007                                                   <
# > Revision:   -                                                            <
# > Info:       -                                                            <
# >--------------------------------------------------------------------------<
sub FunctionHasInputStructure {
    return length ($g_RPCX_FUNCTION_INPUTSTRUCT);
}

# >--------------------------------------------------------------------------<
# > Subroutine: NoteParameterIO                                              <
# >             Notice parameter inout/ouput set as reminder                 <
# > Parameter:  $Expression -> Parameter io set                              <
# > Return:     -                                                            <
# > Author:     A. Neidhardt                                                 <
# > Date:       07.02.2007                                                   <
# > Revision:   -                                                            <
# > Info:       -                                                            <
# >--------------------------------------------------------------------------<
sub NoteParameterIO {
    my ($Expression)=@_;
    
    $g_RPCX_PARAMETER_IO = $Expression;
}

# >--------------------------------------------------------------------------<
# > Subroutine: ParameterIsInput                                             <
# >             Check if current parameter is an input parameter             <
# > Parameter:  -                                                            <
# > Return:     <- Bool (yes = 1, no = 0)                                    <
# > Author:     A. Neidhardt                                                 <
# > Date:       07.02.2007                                                   <
# > Revision:   -                                                            <
# > Info:       -                                                            <
# >--------------------------------------------------------------------------<
sub ParameterIsInput {
    
    if ($g_RPCX_PARAMETER_IO =~ /^.*in.*$/) {
        return 1;
    }
    return 0;
}

# >--------------------------------------------------------------------------<
# > Subroutine: ParameterIsOutput                                            <
# >             Check if current parameter is an output parameter            <
# > Parameter:  -                                                            <
# > Return:     <- Bool (yes = 1, no = 0)                                    <
# > Author:     A. Neidhardt                                                 <
# > Date:       07.02.2007                                                   <
# > Revision:   -                                                            <
# > Info:       -                                                            <
# >--------------------------------------------------------------------------<
sub ParameterIsOutput {
    
    if ($g_RPCX_PARAMETER_IO =~ /^.*out.*$/) {
        return 1;
    }
    return 0;
}

# >--------------------------------------------------------------------------<
# > Subroutine: NoteParameterType                                            <
# >             Notice current parameter type set as reminder                <
# > Parameter:  $Type -> Parameter type                                      <
# > Return:     -                                                            <
# > Author:     A. Neidhardt                                                 <
# > Date:       19.02.2007                                                   <
# > Revision:   -                                                            <
# > Info:       -                                                            <
# >--------------------------------------------------------------------------<
sub NoteParameterType {
    my ($Type)=@_;
    
    if ($g_RPCX_PARAMETER_TYPE =~ /^unsigned$/) {
        # Combination of unsigned types
        $g_RPCX_PARAMETER_TYPE = $g_RPCX_PARAMETER_TYPE." ".$Type;
    }
    else {
        $g_RPCX_PARAMETER_TYPE = $Type;
    }
}

# >--------------------------------------------------------------------------<
# > Subroutine: GetParameterType                                             <
# >             Get current parameter type set as reminder                   <
# > Parameter:  -                                                            <
# > Return:     <- Type                                                      <
# > Author:     A. Neidhardt                                                 <
# > Date:       19.02.2007                                                   <
# > Revision:   -                                                            <
# > Info:       -                                                            <
# >--------------------------------------------------------------------------<
sub GetParameterType {
    return $g_RPCX_PARAMETER_TYPE;
}

# >--------------------------------------------------------------------------<
# > Subroutine: NoteParameterIdentifier                                      <
# >             Notice current parameter name set as reminder                <
# > Parameter:  $Name -> Parameter identifier                                <
# > Return:     -                                                            <
# > Author:     A. Neidhardt                                                 <
# > Date:       19.02.2007                                                   <
# > Revision:   -                                                            <
# > Info:       -                                                            <
# >--------------------------------------------------------------------------<
sub NoteParameterIdentifier {
    my ($Name)=@_;
    
    $g_RPCX_PARAMETER_IDENTIFIER = $Name;
    InitRPCX_LENVARIABLE_FOR_PARAMETER ();
}

# >--------------------------------------------------------------------------<
# > Subroutine: GetParameterIdentifier                                       <
# >             Get current parameter name set as reminder                   <
# > Parameter:  -                                                            <
# > Return:     <- Identifier                                                <
# > Author:     A. Neidhardt                                                 <
# > Date:       19.02.2007                                                   <
# > Revision:   -                                                            <
# > Info:       -                                                            <
# >--------------------------------------------------------------------------<
sub GetParameterIdentifier {
    return $g_RPCX_PARAMETER_IDENTIFIER;
}

# >--------------------------------------------------------------------------<
# > Subroutine: GetProgramName                                               <
# >             Return name of current program                               <
# > Parameter:  -                                                            <
# > Return:     <- Program name                                              <
# > Author:     A. Neidhardt                                                 <
# > Date:       07.02.2007                                                   <
# > Revision:   -                                                            <
# > Info:       -                                                            <
# >--------------------------------------------------------------------------<
sub GetProgramName {
    my $ProgramName = "";
    
    if (length($g_RPCX_PROGRAM_BLOCK) > 0) {
        ($ProgramName) = ($g_RPCX_PROGRAM_BLOCK =~ /^program\s+(\w+)\W+.*/);
    }
    
    return $ProgramName;
}

# >--------------------------------------------------------------------------<
# > Subroutine: NoteNewtypeType                                              <
# >             Notice current new type of type definition set as reminder   <
# > Parameter:  $Type -> Parameter type                                      <
# > Return:     -                                                            <
# > Author:     A. Neidhardt                                                 <
# > Date:       30.03.2007                                                   <
# > Revision:   -                                                            <
# > Info:       -                                                            <
# >--------------------------------------------------------------------------<
sub NoteNewtypeType {
    my ($Type)=@_;
    
    if ($g_RPCX_NEWTYPE_TYPE =~ /^unsigned$/) {
        # Combination of unsigned types
        $g_RPCX_NEWTYPE_TYPE = $g_RPCX_NEWTYPE_TYPE." ".$Type;
    }
    else {
        $g_RPCX_NEWTYPE_TYPE = $Type;
    }
}

# >--------------------------------------------------------------------------<
# > Subroutine: GetNewtypeType                                               <
# >             Get current type of new type definition set as reminder      <
# > Parameter:  -                                                            <
# > Return:     <- Type                                                      <
# > Author:     A. Neidhardt                                                 <
# > Date:       30.03.2007                                                   <
# > Revision:   -                                                            <
# > Info:       -                                                            <
# >--------------------------------------------------------------------------<
sub GetNewtypeType {
    return $g_RPCX_NEWTYPE_TYPE;
}

# >--------------------------------------------------------------------------<
# > Subroutine: NoteNewtypeIdentifier                                        <
# >             Notice current type name set as reminder                     <
# > Parameter:  $Name -> Type identifier                                     <
# > Return:     -                                                            <
# > Author:     A. Neidhardt                                                 <
# > Date:       30.03.2007                                                   <
# > Revision:   -                                                            <
# > Info:       -                                                            <
# >--------------------------------------------------------------------------<
sub NoteNewtypeIdentifier {
    my ($Name)=@_;
    
    $g_RPCX_NEWTYPE_IDENTIFIER = $Name;
}

# >--------------------------------------------------------------------------<
# > Subroutine: GetNewtypeIdentifier                                         <
# >             Get current type name set as reminder                        <
# > Parameter:  -                                                            <
# > Return:     <- Identifier                                                <
# > Author:     A. Neidhardt                                                 <
# > Date:       30.03.2007                                                   <
# > Revision:   -                                                            <
# > Info:       -                                                            <
# >--------------------------------------------------------------------------<
sub GetNewtypeIdentifier {
    return $g_RPCX_NEWTYPE_IDENTIFIER;
}

# >--------------------------------------------------------------------------<
# > Subroutine: MergeDefinitionAndProgramBlock                               <
# >             Merge the created definition and the created program blocks  <
# > Parameter:  -                                                            <
# > Return:     -                                                            <
# > Author:     A. Neidhardt                                                 <
# > Date:       07.02.2007                                                   <
# > Revision:   -                                                            <
# > Info:       -                                                            <
# >--------------------------------------------------------------------------<
sub MergeDefinitionAndProgramBlock {
    $g_RPCX_PROGRAM_BLOCK = $g_RPCX_DEFINITION_BLOCK.$g_RPCX_PROGRAM_BLOCK;
}

# >--------------------------------------------------------------------------<
# > Subroutine: PrintProgramBlockToFile                                      <
# >             Prints the created program block into RPC-X-file             <
# > Parameter:  $RPCXFilepath -> Filepath to RPCX-file                       <
# > Return:     <- Errorcode (0 = ok, 1 = error)                             <
# > Author:     A. Neidhardt                                                 <
# > Date:       07.02.2007                                                   <
# > Revision:   -                                                            <
# > Info:       -                                                            <
# >--------------------------------------------------------------------------<
sub PrintProgramBlockToFile {
    my ($RPCXFilepath)=@_;
    
    # Save old file as backup
    if (-r $RPCXFilepath) {
        rename ($RPCXFilepath, $RPCXFilepath."~");
    }
    
    # Open file (old style open, so that older perl versions can handle it)
    open (RPCXFileHandle,"> $RPCXFilepath") or return 1;
    
    print RPCXFileHandle $g_RPCX_PROGRAM_BLOCK;
    
    close (RPCXFileHandle);
    
    return 0;
}

# >--------------------------------------------------------------------------<
# > Subroutine: InitRPCX_LENVARIABLE_FOR_PARAMETER                           <
# >             Initialise new length variable for dynamic length parameter  <
# > Parameter:  -                                                            <
# > Return:     -                                                            <
# > Author:     A. Neidhardt                                                 <
# > Date:       09.02.2007                                                   <
# > Revision:   -                                                            <
# > Info:       -                                                            <
# >--------------------------------------------------------------------------<
sub InitRPCX_LENVARIABLE_FOR_PARAMETER {
    my $Count;
    
    $g_RPCX_LENVARIABLE_NAME = "    unsigned int _".$g_RPCX_PARAMETER_IDENTIFIER."_len";
}

# >--------------------------------------------------------------------------<
# > Subroutine: NextRPCX_LENVARIABLE_FOR_PARAMETER                           <
# >             Derive following length variable                             <
# > Parameter:  -                                                            <
# > Return:     -                                                            <
# > Author:     A. Neidhardt                                                 <
# > Date:       09.02.2007                                                   <
# > Revision:   -                                                            <
# > Info:       -                                                            <
# >--------------------------------------------------------------------------<
sub NextRPCX_LENVARIABLE_FOR_PARAMETER {
    my $Count;
    my $ParameterPart;
    
    if (length ($g_RPCX_LENVARIABLE_NAME) == 0) {
        return;
    }

    if ($g_RPCX_LENVARIABLE_NAME =~ /.*_len$/) {
        $g_RPCX_LENVARIABLE_NAME =~ s/_len/_len1/g;
    }
    else {
        ($ParameterPart) = ($g_RPCX_LENVARIABLE_NAME =~ /(.*)_len\d+$/);
        ($Count) = ($g_RPCX_LENVARIABLE_NAME =~ /.*_len(\d+)$/);
        $Count = $Count + 1;
        $g_RPCX_LENVARIABLE_NAME = $ParameterPart."_len".$Count;
    }
}

# >--------------------------------------------------------------------------<
# > Subroutine: AddLENVARIABLEToRPCX_FUNCTION_INPUTSTRUCT                    <
# >             Add length parameter to RPCX input structure                 <
# > Parameter:  -                                                            <
# > Return:     -                                                            <
# > Author:     A. Neidhardt                                                 <
# > Date:       19.02.2007                                                   <
# > Revision:   -                                                            <
# > Info:       -                                                            <
# >--------------------------------------------------------------------------<
sub AddLENVARIABLEToRPCX_FUNCTION_INPUTSTRUCT {
    my $Count;
    my $LenVarName;
    
    if (length ($g_RPCX_LENVARIABLE_NAME) == 0) {
        return;
    }

    ($LenVarName) = ($g_RPCX_LENVARIABLE_NAME =~ /\W+(\w+_len(\d+)?)$/);
    
    $g_RPCX_FUNCTION_INPUTSTRUCT = $g_RPCX_FUNCTION_INPUTSTRUCT.";\n".$g_RPCX_LENVARIABLE_NAME;
    # Add dummy variables to prevent compiler warnings in xdr because of optimisation
    if (GetParameterType() =~ /^char$/) {
        AddToRPCX_FUNCTION_INPUTSTRUCT (";\n    unsigned char Dummy".$LenVarName);
    }
    else {
        AddToRPCX_FUNCTION_INPUTSTRUCT (";\n    char Dummy".$LenVarName);
    }
}

# >--------------------------------------------------------------------------<
# > Subroutine: AddLENVARIABLEToRPCX_FUNCTION_OUTPUTSTRUCT                   <
# >             Add length parameter to RPCX output structure                <
# > Parameter:  -                                                            <
# > Return:     -                                                            <
# > Author:     A. Neidhardt                                                 <
# > Date:       19.02.2007                                                   <
# > Revision:   -                                                            <
# > Info:       -                                                            <
# >--------------------------------------------------------------------------<
sub AddLENVARIABLEToRPCX_FUNCTION_OUTPUTSTRUCT {
    my $Count;
    my $LenVarName;
    
    if (length ($g_RPCX_LENVARIABLE_NAME) == 0) {
        return;
    }
    
    ($LenVarName) = ($g_RPCX_LENVARIABLE_NAME =~ /\W+(\w+_len(\d+)?)$/);
    
    $g_RPCX_FUNCTION_OUTPUTSTRUCT = $g_RPCX_FUNCTION_OUTPUTSTRUCT.";\n".$g_RPCX_LENVARIABLE_NAME;
    # Add dummy variables to prevent compiler warnings in xdr because of optimisation
    if (GetParameterType() =~ /^char$/) {
        AddToRPCX_FUNCTION_OUTPUTSTRUCT (";\n    unsigned char Dummy".$LenVarName);
    }
    else {
        AddToRPCX_FUNCTION_OUTPUTSTRUCT (";\n    char Dummy".$LenVarName);
    }
}

# ===================================================================================
# RPC-ABSTRACT-H-file part
# ------------------------
# The following elements and functions are used to create the parts of the abstract RPC-h-file
# which is used by C++-client and -server as an interface class
# ===================================================================================
# Global variables: blocks of the resulting files
# The following variables are only handled by the RPCABSTRH-functions and not directly while running other functions
my $g_RPCABSTRH_DEFINITION_BLOCK = "";        # Here are the definitions of abstract RPC-h-file, constructed while parsing
my $g_RPCABSTRH_DEFINITION = "";              # Here is the complete content of abstract RPC-h-file
my $g_RPCABSTRH_LENVARIABLE_NAME = "";        # This is a marker for additional length-variables which are added automatically for variable arrays
my $g_RPCCLIENTCPP_LENVARIABLE_NAME = "";     # This is a marker for additional length-variables which are added automatically for variable arrays
my $g_ClientClassRPCMethodDefinition = "";   # This is a temporary used element to create one client class RPC method
my $g_ServerClassRPCMethodDefinition = "";   # This is a temporary used element to create one server class RPC method
my $g_ServerProcRPCMethodDefinition = "";    # This is a temporary used element to create one server proc RPC method
my $g_CopyRunnerVariableIsSetClient = 0;      # Notify if a client copy variable is set to copy string arrays
my $g_CopyRunnerVariableIsSetServer = 0;      # Notify if a server copy variable is set to copy string arrays
my $g_CheckTransportProtocol = 0;             # Transport protocol check is filled in
my $g_DynamicDimensionCounter = 0;            # Counter for dynamic dimensions of array
my $g_ASD = 0;                                # Automatic Safety Device activated (0=off, 1=on)

# >--------------------------------------------------------------------------<
# > Subroutine: ResetCopyRunnerVariableIsSet                                 <
# >             Resets marker for copy runner of variable arrays             <
# > Parameter:  -                                                            <
# > Return:     -                                                            <
# > Author:     A. Neidhardt                                                 <
# > Date:       16.04.2007                                                   <
# > Revision:   -                                                            <
# > Info:       -                                                            <
# >--------------------------------------------------------------------------<
sub ResetCopyRunnerVariableIsSet {
    
    $g_CopyRunnerVariableIsSetClient = 0;
    $g_CopyRunnerVariableIsSetServer = 0;
    $g_CheckTransportProtocol = 0;
}

# >--------------------------------------------------------------------------<
# > Subroutine: AddToRPCABSTRH_DEFINITION_BLOCK                              <
# >             Add an expression to definition block of abstract RPC-h-file <
# > Parameter:  $Expression -> Expression which should be added              <
# > Return:     -                                                            <
# > Author:     A. Neidhardt                                                 <
# > Date:       08.02.2007                                                   <
# > Revision:   -                                                            <
# > Info:       -                                                            <
# >--------------------------------------------------------------------------<
sub AddToRPCABSTRH_DEFINITION_BLOCK {
    my ($Expression)=@_;
    
    $g_RPCABSTRH_DEFINITION_BLOCK = $g_RPCABSTRH_DEFINITION_BLOCK.$Expression;
}

# >--------------------------------------------------------------------------<
# > Subroutine: ReplaceAtRPCABSTRH_DEFINITION_BLOCK                          <
# >             Replace speficied wildcards with another expression at       <
# >             definition block of abstract RPC-h-file                      <
# > Parameter:  $ReplaceExpression -> Expression which should be replaced    <
# >             $NewExpression -> Expression which is new                    <
# > Return:     -                                                            <
# > Author:     A. Neidhardt                                                 <
# > Date:       07.02.2007                                                   <
# > Revision:   -                                                            <
# > Info:       -                                                            <
# >--------------------------------------------------------------------------<
sub ReplaceAtRPCABSTRH_DEFINITION_BLOCK {
    my ($ReplaceExpression,$NewExpression)=@_;
    
    $g_RPCABSTRH_DEFINITION_BLOCK =~ s/$ReplaceExpression/$NewExpression/g;
}
# >--------------------------------------------------------------------------<
# > Subroutine: AddToRPCABSTRH_OPERATIONSTATEVARIABLE                        <
# >             Add operation state variable to definition block of          <
# >             abstract RPC-h-file                                          <
# > Parameter:  -                                                            <
# > Return:     -                                                            <
# > Author:     A. Neidhardt                                                 <
# > Date:       15.02.2007                                                   <
# > Revision:   -                                                            <
# > Info:       -                                                            <
# >--------------------------------------------------------------------------<
sub AddToRPCABSTRH_OPERATIONSTATEVARIABLE {
    $g_RPCABSTRH_DEFINITION_BLOCK = $g_RPCABSTRH_DEFINITION_BLOCK."unsigned short & _operation_state";
}

# >--------------------------------------------------------------------------<
# > Subroutine: InitRPCABSTRH_LENVARIABLE_FOR_PARAMETER                      <
# >             Initialise new length variable for dynamic length parameter  <
# > Parameter:  $Parameteridentifier -> Identifier of function parameter     <
# > Return:     -                                                            <
# > Author:     A. Neidhardt                                                 <
# > Date:       09.02.2007                                                   <
# > Revision:   -                                                            <
# > Info:       -                                                            <
# >--------------------------------------------------------------------------<
sub InitRPCABSTRH_LENVARIABLE_FOR_PARAMETER {
    my ($Parameteridentifier)=@_;
    my $Count;
    
    if (ParameterIsOutput()) {
        $g_RPCABSTRH_LENVARIABLE_NAME = " unsigned int & _".$Parameteridentifier."_len";
    }
    else {
        $g_RPCABSTRH_LENVARIABLE_NAME = " unsigned int _".$Parameteridentifier."_len";
    }
}

# >--------------------------------------------------------------------------<
# > Subroutine: AddToRPCABSTRH_LENVARIABLE                                   <
# >             Add length parameter to function at definition block of      <
# >             abstract RPC-h-file                                          <
# > Parameter:  -                                                            <
# > Return:     -                                                            <
# > Author:     A. Neidhardt                                                 <
# > Date:       09.02.2007                                                   <
# > Revision:   -                                                            <
# > Info:       -                                                            <
# >--------------------------------------------------------------------------<
sub AddToRPCABSTRH_LENVARIABLE {
    my $Count;
    my $ParameterPart;
    
    if (length ($g_RPCABSTRH_LENVARIABLE_NAME) == 0) {
        return;
    }
    
    $g_RPCABSTRH_DEFINITION_BLOCK = $g_RPCABSTRH_DEFINITION_BLOCK.",".$g_RPCABSTRH_LENVARIABLE_NAME;

    if ($g_RPCABSTRH_LENVARIABLE_NAME =~ /.*_len$/) {
        $g_RPCABSTRH_LENVARIABLE_NAME =~ s/_len/_len1/g;
    }
    else {
        ($ParameterPart) = ($g_RPCABSTRH_LENVARIABLE_NAME =~ /(.*)_len\d+$/);
        ($Count) = ($g_RPCABSTRH_LENVARIABLE_NAME =~ /.*_len(\d+)$/);
        $Count = $Count + 1;
        $g_RPCABSTRH_LENVARIABLE_NAME = $ParameterPart."_len".$Count;
    }
}

# >--------------------------------------------------------------------------<
# > Subroutine: InitRPCCPP_LENVARIABLE_FOR_PARAMETER                   <
# >             Initialise new length variable for dynamic length parameter  <
# > Parameter:  $Parameteridentifier -> Identifier of function parameter     <
# > Return:     -                                                            <
# > Author:     A. Neidhardt                                                 <
# > Date:       20.02.2007                                                   <
# > Revision:   -                                                            <
# > Info:       -                                                            <
# >--------------------------------------------------------------------------<
sub InitRPCCPP_LENVARIABLE_FOR_PARAMETER {
    my ($Parameteridentifier)=@_;
    my $Count;
    
    if (ParameterIsOutput()) {
        $g_RPCCLIENTCPP_LENVARIABLE_NAME = " unsigned int & _".$Parameteridentifier."_len";
    }
    else {
        $g_RPCCLIENTCPP_LENVARIABLE_NAME = " unsigned int _".$Parameteridentifier."_len";
    }
    
    ResetCountedDynamicDimensions ();
}

# >--------------------------------------------------------------------------<
# > Subroutine: ResetRPCCLIENTCPP_TemporaryTemplates                         <
# >             Deletes all temporary templates ��...��                      <
# > Parameter:  -                                                            <
# > Return:     -                                                            <
# > Author:     A. Neidhardt                                                 <
# > Date:       20.02.2007                                                   <
# > Revision:   -                                                            <
# > Info:       -                                                            <
# >--------------------------------------------------------------------------<
sub ResetRPCCLIENTCPP_TemporaryTemplates {
    
    $g_ClientClassRPCMethodDefinition =~ s/��\w+��//g;
}

# >--------------------------------------------------------------------------<
# > Subroutine: ResetRPCProcRPC_TemporaryTemplates                           <
# >             Deletes all temporary templates ��...��                      <
# > Parameter:  -                                                            <
# > Return:     -                                                            <
# > Author:     A. Neidhardt                                                 <
# > Date:       08.03.2007                                                   <
# > Revision:   -                                                            <
# > Info:       -                                                            <
# >--------------------------------------------------------------------------<
sub ResetRPCProcRPC_TemporaryTemplates {
    
    $g_ServerProcRPCMethodDefinition =~ s/��\w+��//g;
}

# >--------------------------------------------------------------------------<
# > Subroutine: CreatePreviousLenHelperVariable                              <
# >             Create a helping variable mith previous len variable name    <
# > Parameter:  -                                                            <
# > Return:     -                                                            <
# > Author:     A. Neidhardt                                                 <
# > Date:       20.02.2007                                                   <
# > Revision:   -                                                            <
# > Info:       -                                                            <
# >--------------------------------------------------------------------------<
sub CreatePreviousLenHelperVariable {
    my ($HelperVariable)=@_;
    my $HeadPartOfVariable;
    my $CountOfVariable;
    my $TrailPartOfVariable;
    
    if ($HelperVariable =~ /^.*_len\d+.*$/) {
        ($HeadPartOfVariable,$CountOfVariable,$TrailPartOfVariable) = ($HelperVariable =~ /^(.*_len)(\d*)(.*)$/);
        $CountOfVariable = $CountOfVariable - 1;
        if ($CountOfVariable == 0) {
            $CountOfVariable = "";
        }
        return ($HeadPartOfVariable.$CountOfVariable.$TrailPartOfVariable);
    }
    else {
        return "";
    }

    return "";
}

# >--------------------------------------------------------------------------<
# > Subroutine: NextRPCCPP_LENVARIABLE_FOR_PARAMETER                         <
# >             Derive following length variable                             <
# > Parameter:  -                                                            <
# > Return:     -                                                            <
# > Author:     A. Neidhardt                                                 <
# > Date:       20.02.2007                                                   <
# > Revision:   -                                                            <
# > Info:       -                                                            <
# >--------------------------------------------------------------------------<
sub NextRPCCPP_LENVARIABLE_FOR_PARAMETER {
    my $Count;                    # Number of current length variable
    my $ParameterPart;            # Parameter name which belongs to current length variable
    
    # -------------------------- New len variable ----------------------------------------------
    if ($g_RPCCLIENTCPP_LENVARIABLE_NAME =~ /.*_len$/) {
        $g_RPCCLIENTCPP_LENVARIABLE_NAME =~ s/_len/_len1/g;
    }
    else {
        ($ParameterPart) = ($g_RPCCLIENTCPP_LENVARIABLE_NAME =~ /(.*)_len\d+$/);
        ($Count) = ($g_RPCCLIENTCPP_LENVARIABLE_NAME =~ /.*_len(\d+)$/);
        $Count = $Count + 1;
        $g_RPCCLIENTCPP_LENVARIABLE_NAME = $ParameterPart."_len".$Count;
    }
    
    CountDynamicDimensions ();
}

# >--------------------------------------------------------------------------<
# > Subroutine: CountDynamicDimensions                                       <
# >             Used to count number of dynamic dimensions                   <
# > Parameter:  -                                                            <
# > Return:     -                                                            <
# > Author:     A. Neidhardt                                                 <
# > Date:       03.05.2007                                                   <
# > Revision:   -                                                            <
# > Info:       -                                                            <
# >--------------------------------------------------------------------------<
sub CountDynamicDimensions {
    $g_DynamicDimensionCounter = $g_DynamicDimensionCounter + 1;
}

# >--------------------------------------------------------------------------<
# > Subroutine: ResetCountedDynamicDimensions                                <
# >             Resets the counted number of dynamic dimensions              <
# > Parameter:  -                                                            <
# > Return:     -                                                            <
# > Author:     A. Neidhardt                                                 <
# > Date:       03.05.2007                                                   <
# > Revision:   -                                                            <
# > Info:       -                                                            <
# >--------------------------------------------------------------------------<
sub ResetCountedDynamicDimensions {
    $g_DynamicDimensionCounter = 0;
}

# >--------------------------------------------------------------------------<
# > Subroutine: AddToRPCCLIENTCPP_DYNAMICARRAY                               <
# >             Add dynamic handling to client part of RPC                   <
# > Parameter:  -                                                            <
# > Return:     -                                                            <
# > Author:     A. Neidhardt                                                 <
# > Date:       03.05.2007                                                   <
# > Revision:   -                                                            <
# > Info:       -                                                            <
# >--------------------------------------------------------------------------<
sub AddToRPCCLIENTCPP_DYNAMICARRAY {
    my $DimensionIndex = 0;    # Index to run through dimensions
    my $ArrayIndex = 0;        # Index to run through array []
    my $LengthExtension = "";  # Variable to create length variable extension number
    my $FollowingLengthExtension = "";  # Variable to create length variable of following extension number
    my $HelperLine = "";       # Variable to construct one line before replacing template
    my $Spaces = "";           # Variable with white spaces derived from template
    my $MultipleSpaces = "";   # Concatenation of white spaces derived from template
    my $SpacesIndex = 0;       # Index to run through spaces
    
    # Create length parameters ======================================================================================================================
    for ($DimensionIndex = 0; $DimensionIndex < $g_DynamicDimensionCounter; $DimensionIndex++) {
        if ($DimensionIndex == 0) {
            $LengthExtension = "";
        }
        else {
            $LengthExtension = $DimensionIndex;
        }
        if (ParameterIsOutput ()){
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�Parameters�",", unsigned int & _".GetParameterIdentifier()."_len".$LengthExtension);
        }
        else {
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�Parameters�",", unsigned int _".GetParameterIdentifier()."_len".$LengthExtension);
        }
    }
    
    # Create Variabledefinitions ====================================================================================================================
    if ($g_DynamicDimensionCounter > 0) {
        ReplaceTemplateAtClientClassRPCMethodDefinition ("�VariableDefinitions�","unsigned int SingleArrayIndex_".GetParameterIdentifier()."_len;");
    }
    for ($DimensionIndex = 0; $DimensionIndex < $g_DynamicDimensionCounter; $DimensionIndex++) {
        if ($DimensionIndex == 0) {
            $LengthExtension = "";
        }
        else {
            $LengthExtension = $DimensionIndex;
        }
        ReplaceTemplateAtClientClassRPCMethodDefinition ("�VariableDefinitions�","unsigned int Index_".GetParameterIdentifier()."_len".$LengthExtension.";");
        if (ParameterIsOutput() &&
            $DimensionIndex < $g_DynamicDimensionCounter-1) {
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�VariableDefinitions�","unsigned int Increase_".GetParameterIdentifier()."_len".$LengthExtension.";");
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�VariableDefinitions�","unsigned int Stop_".GetParameterIdentifier()."_len".$LengthExtension.";");
        }
    }
    
    # Fill in RPC structure =========================================================================================================================
#    if ($g_DynamicDimensionCounter > 0) {
#        if (!$g_CheckTransportProtocol) {
#            # Check if transport protocol is set to TCP when using dynamic arrays
#            $Spaces = GetSpacesInFrontOfTemplateAtClientClassRPCMethodDefinition ("�FillINVariables�");
#            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillINVariables�","if (priv_usTransportProtocol != 1)");
#            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillINVariables�","{");
#            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillINVariables�",$Spaces."priv_strError = \"Wrong transport protocol for dynamic arrays\";");
#            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillINVariables�",$Spaces."CInterfaceExcept.strErrorMsg = priv_strError;");
#            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillINVariables�",$Spaces."CInterfaceExcept._operation_state = 1;");
#            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillINVariables�",$Spaces."__usInternalError = 1;");
#            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillINVariables�",$Spaces."goto ".lc(GetProgramName()."_".GetFunctionIdentifier()."_1")."_Return;");
#            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillINVariables�","}");
#            $g_CheckTransportProtocol = 1;
#        }
#    }
    if (ParameterIsInput ()) {
        # Set input length variables
        $Spaces = GetSpacesInFrontOfTemplateAtClientClassRPCMethodDefinition ("�FillINVariables�");
        ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillINVariables�","if (".GetParameterIdentifier()."_val == NULL)");
        ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillINVariables�","{");
        for ($DimensionIndex = 0; $DimensionIndex < $g_DynamicDimensionCounter; $DimensionIndex++) {
            if ($DimensionIndex == 0) {
                $LengthExtension = "";
            }
            else {
                $LengthExtension = $DimensionIndex;
            }
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillINVariables�",$Spaces."_".GetParameterIdentifier()."_len".$LengthExtension." = 0;");
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillINVariables�",$Spaces."SInput._".GetParameterIdentifier()."_len".$LengthExtension." = 0;");
        }
        ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillINVariables�",$Spaces."SInput.".GetParameterIdentifier().".".GetParameterIdentifier()."_len = 0;");
        ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillINVariables�",$Spaces."SInput.".GetParameterIdentifier().".".GetParameterIdentifier()."_val = NULL;");
        ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillINVariables�","}");
        ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillINVariables�","else");
        ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillINVariables�","{");
        for ($DimensionIndex = 0; $DimensionIndex < $g_DynamicDimensionCounter; $DimensionIndex++) {
            if ($DimensionIndex == 0) {
                $LengthExtension = "";
            }
            else {
                $LengthExtension = $DimensionIndex;
            }
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillINVariables�",$Spaces."SInput._".GetParameterIdentifier()."_len".$LengthExtension." = _".GetParameterIdentifier()."_len".$LengthExtension.";");
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�VariableInit�","SInput._".GetParameterIdentifier()."_len".$LengthExtension." = 0;");
        }
        # Calculate multiplication of length variables
        if ($g_DynamicDimensionCounter > 0) {
            $HelperLine = "SInput.".GetParameterIdentifier().".".GetParameterIdentifier()."_len = SInput._".GetParameterIdentifier()."_len";
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�VariableInit�","SInput.".GetParameterIdentifier().".".GetParameterIdentifier()."_len = 0;");
            for ($DimensionIndex = 1; $DimensionIndex < $g_DynamicDimensionCounter; $DimensionIndex++) {
                if ($DimensionIndex == 0) {
                    $LengthExtension = "";
                }
                else {
                    $LengthExtension = $DimensionIndex;
                }
                $HelperLine = $HelperLine." * SInput._".GetParameterIdentifier()."_len".$LengthExtension;
            }
            $HelperLine = $HelperLine.";";
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillINVariables�",$Spaces.$HelperLine);
        }
        # Allocate single array
        $Spaces = GetSpacesInFrontOfTemplateAtClientClassRPCMethodDefinition ("�FillINVariables�");
        if ($g_DynamicDimensionCounter > 0) {
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�VariableInit�","SInput.".GetParameterIdentifier().".".GetParameterIdentifier()."_val = NULL;");
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillINVariables�",$Spaces."if ((SInput.".GetParameterIdentifier().".".GetParameterIdentifier()."_val = (".GetParameterType()." * ) malloc (sizeof(".GetParameterType().")*SInput.".GetParameterIdentifier().".".GetParameterIdentifier()."_len)) == NULL)");
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillINVariables�",$Spaces."{");
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillINVariables�",$Spaces.$Spaces."priv_strError = \"Can't allocate enough memory\";");
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillINVariables�",$Spaces.$Spaces."CInterfaceExcept.strErrorMsg = priv_strError;");
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillINVariables�",$Spaces.$Spaces."CInterfaceExcept._operation_state = 1;");
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillINVariables�",$Spaces.$Spaces."__usInternalError = 1;");
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillINVariables�",$Spaces.$Spaces."goto ".lc(GetProgramName()."_".GetFunctionIdentifier()."_1")."_Return;");
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillINVariables�",$Spaces."}");
        }
        # Copy multiple array into single array
        $Spaces = GetSpacesInFrontOfTemplateAtClientClassRPCMethodDefinition ("�FillParameterReturn�");
        if ($g_DynamicDimensionCounter > 0) {
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillINVariables�",$Spaces."SingleArrayIndex_".GetParameterIdentifier()."_len = 0;");
        }
        # Create opening part of for-loop
        $MultipleSpaces = "";
        for ($DimensionIndex = 0; $DimensionIndex < $g_DynamicDimensionCounter; $DimensionIndex++) {
            if ($DimensionIndex == 0) {
                $LengthExtension = "";
            }
            else {
                $LengthExtension = $DimensionIndex;
            }
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillINVariables�",$Spaces.$MultipleSpaces."for (Index_".GetParameterIdentifier()."_len".$LengthExtension." = 0; Index_".GetParameterIdentifier()."_len".$LengthExtension." < _".GetParameterIdentifier()."_len".$LengthExtension."; Index_".GetParameterIdentifier()."_len".$LengthExtension."++)"); 
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillINVariables�",$Spaces.$MultipleSpaces."{"); 
            $MultipleSpaces = $MultipleSpaces.$Spaces;
        }
        # Create closing part of for-loop
        for ($DimensionIndex = $g_DynamicDimensionCounter-1; $DimensionIndex >= 0; $DimensionIndex--) {
            if ($DimensionIndex == 0) {
                $LengthExtension = "";
            }
            else {
                $LengthExtension = $DimensionIndex;
            }
            $MultipleSpaces = "";
            for ($SpacesIndex = 0; $SpacesIndex < $DimensionIndex; $SpacesIndex++) {
                $MultipleSpaces = $MultipleSpaces.$Spaces;
            }
            $HelperLine = "";
            for ($ArrayIndex = 0; $ArrayIndex <= $DimensionIndex; $ArrayIndex++) {
                if ($ArrayIndex == 0) {
                    $HelperLine = $HelperLine."[Index_".GetParameterIdentifier()."_len]";
                }
                else {
                    $HelperLine = $HelperLine."[Index_".GetParameterIdentifier()."_len".$ArrayIndex."]";
                }
            }
            if ($DimensionIndex != $g_DynamicDimensionCounter-1) {
                if (ParameterIsInput () && ParameterIsOutput ()) {
                    ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillINVariables�",$Spaces.$MultipleSpaces.$Spaces."delete [] ".GetParameterIdentifier()."_val ".$HelperLine.";"); 
                }
            }
            else
            {
                $HelperLine = "SInput.".GetParameterIdentifier().".".GetParameterIdentifier()."_val [SingleArrayIndex_".GetParameterIdentifier()."_len] = ".GetParameterIdentifier()."_val ".$HelperLine;
                $HelperLine = $HelperLine.";";
                ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillINVariables�",$Spaces.$MultipleSpaces.$Spaces.$HelperLine); 
                ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillINVariables�",$Spaces.$MultipleSpaces.$Spaces."SingleArrayIndex_".GetParameterIdentifier()."_len++;"); 
            }
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillINVariables�",$Spaces.$MultipleSpaces."}"); 
        }
        # Create final delete of Array
        if ($g_DynamicDimensionCounter > 0 &&
            ParameterIsInput () && ParameterIsOutput ()) {
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillINVariables�",$Spaces."delete [] ".GetParameterIdentifier()."_val;"); 
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillINVariables�",$Spaces.GetParameterIdentifier()."_val = NULL;"); 
        }
        ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillINVariables�","}");
        ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillINVariables�","priv_ulRoundTripByteSum += (SInput.".GetParameterIdentifier().".".GetParameterIdentifier()."_len*sizeof(".GetParameterType()."));");
    }
    
    # Call RPC ======================================================================================================================================
    # Nothing has to be done, cause it is done outside
    
    # Fill return values ============================================================================================================================
    # Fill return values
    if (ParameterIsOutput ()) {
        $Spaces = GetSpacesInFrontOfTemplateAtClientClassRPCMethodDefinition ("�FillParameterReturn�");
        ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillParameterReturn�","if (SOutput->".GetParameterIdentifier().".".GetParameterIdentifier()."_val == NULL)"); 
        ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillParameterReturn�","{"); 
        ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillParameterReturn�",$Spaces.GetParameterIdentifier()."_val = NULL;");
        for ($DimensionIndex = 0; $DimensionIndex < $g_DynamicDimensionCounter; $DimensionIndex++) {
            if ($DimensionIndex == 0) {
                $LengthExtension = "";
            }
            else {
                $LengthExtension = $DimensionIndex;
            }
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillParameterReturn�",$Spaces."_".GetParameterIdentifier()."_len".$LengthExtension." = 0;"); 
        }
        ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillParameterReturn�","}"); 
        ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillParameterReturn�","else"); 
        ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillParameterReturn�","{"); 
        ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillParameterReturn�",$Spaces."priv_ulRoundTripByteSum += (SOutput->".GetParameterIdentifier().".".GetParameterIdentifier()."_len*sizeof(".GetParameterType()."));");
        # Init length varaibles
        for ($DimensionIndex = 0; $DimensionIndex < $g_DynamicDimensionCounter; $DimensionIndex++) {
            if ($DimensionIndex == 0) {
                $LengthExtension = "";
            }
            else {
                $LengthExtension = $DimensionIndex;
            }
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillParameterReturn�",$Spaces."_".GetParameterIdentifier()."_len".$LengthExtension." = SOutput->_".GetParameterIdentifier()."_len".$LengthExtension.";"); 
        }
        # Create first dimension of Array
        if ($g_DynamicDimensionCounter > 0) {
            $HelperLine = "";
            for ($ArrayIndex = 0; $ArrayIndex <= $g_DynamicDimensionCounter-2; $ArrayIndex++) {
                $HelperLine = $HelperLine."*";
            }
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillParameterReturn�",$Spaces."try"); 
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillParameterReturn�",$Spaces."{"); 
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillParameterReturn�",$Spaces.$Spaces."if ((".GetParameterIdentifier()."_val = new ".GetParameterType()." ".$HelperLine." [SOutput->_".GetParameterIdentifier()."_len]) == NULL)"); 
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillParameterReturn�",$Spaces.$Spaces."{");
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillParameterReturn�",$Spaces.$Spaces.$Spaces."priv_strError = \"Can't allocate enough memory\";");
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillParameterReturn�",$Spaces.$Spaces.$Spaces."CInterfaceExcept.strErrorMsg = priv_strError;");
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillParameterReturn�",$Spaces.$Spaces.$Spaces."CInterfaceExcept._operation_state = 1;");
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillParameterReturn�",$Spaces.$Spaces.$Spaces."__usInternalError = 1;");
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillParameterReturn�",$Spaces.$Spaces.$Spaces."goto ".lc(GetProgramName()."_".GetFunctionIdentifier()."_1")."_Return;");
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillParameterReturn�",$Spaces.$Spaces."}"); 
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillParameterReturn�",$Spaces."}"); 
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillParameterReturn�",$Spaces."catch(...)"); 
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillParameterReturn�",$Spaces."{"); 
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillParameterReturn�",$Spaces.$Spaces.GetParameterIdentifier()."_val = NULL;");
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillParameterReturn�",$Spaces.$Spaces."priv_strError = \"Can't allocate enough memory\";");
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillParameterReturn�",$Spaces.$Spaces."CInterfaceExcept.strErrorMsg = priv_strError;");
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillParameterReturn�",$Spaces.$Spaces."CInterfaceExcept._operation_state = 1;");
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillParameterReturn�",$Spaces.$Spaces."__usInternalError = 1;");
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillParameterReturn�",$Spaces.$Spaces."goto ".lc(GetProgramName()."_".GetFunctionIdentifier()."_1")."_Return;");
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillParameterReturn�",$Spaces."}"); 
        }
        # Create opening part of for-loop
        if ($g_DynamicDimensionCounter > 0) {
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillParameterReturn�",$Spaces."SingleArrayIndex_".GetParameterIdentifier()."_len = 0;");
        }
        $MultipleSpaces = "";
        for ($DimensionIndex = 0; $DimensionIndex < $g_DynamicDimensionCounter-1; $DimensionIndex++) {
            if ($DimensionIndex == 0) {
                $LengthExtension = "";
                $FollowingLengthExtension = "1";
            }
            else {
                $LengthExtension = $DimensionIndex;
                $FollowingLengthExtension = $DimensionIndex + 1;
            }
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillParameterReturn�",$Spaces.$MultipleSpaces."Index_".GetParameterIdentifier()."_len".$LengthExtension." = 0;"); 
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillParameterReturn�",$Spaces.$MultipleSpaces."Stop_".GetParameterIdentifier()."_len".$LengthExtension." = 0;"); 
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillParameterReturn�",$Spaces.$MultipleSpaces."Increase_".GetParameterIdentifier()."_len".$LengthExtension." = 1;"); 
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillParameterReturn�",$Spaces.$MultipleSpaces."for (Index_".GetParameterIdentifier()."_len".$LengthExtension." = Index_".GetParameterIdentifier()."_len".$LengthExtension."; (Index_".GetParameterIdentifier()."_len".$LengthExtension." < _".GetParameterIdentifier()."_len".$LengthExtension.") && (!Stop_".GetParameterIdentifier()."_len".$LengthExtension."); Increase_".GetParameterIdentifier()."_len".$LengthExtension."?Index_".GetParameterIdentifier()."_len".$LengthExtension."++:Index_".GetParameterIdentifier()."_len".$LengthExtension."--)"); 
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillParameterReturn�",$Spaces.$MultipleSpaces."{"); 
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillParameterReturn�",$Spaces.$MultipleSpaces.$Spaces."if (Increase_".GetParameterIdentifier()."_len)"); 
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillParameterReturn�",$Spaces.$MultipleSpaces.$Spaces."{"); 
            $HelperLine = "";
            for ($ArrayIndex = 0; $ArrayIndex <= $DimensionIndex; $ArrayIndex++) {
                if ($ArrayIndex == 0) {
                    $HelperLine = $HelperLine."[Index_".GetParameterIdentifier()."_len]";
                }
                else {
                    $HelperLine = $HelperLine."[Index_".GetParameterIdentifier()."_len".$ArrayIndex."]";
                }
            }
            $HelperLine = $HelperLine." = new ".GetParameterType()." ";
            for ($ArrayIndex = ($g_DynamicDimensionCounter-1)-($DimensionIndex+1)-1; $ArrayIndex >= 0 ; $ArrayIndex--) {
                $HelperLine = $HelperLine."*";
            }
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillParameterReturn�",$Spaces.$MultipleSpaces.$Spaces.$Spaces."try");
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillParameterReturn�",$Spaces.$MultipleSpaces.$Spaces.$Spaces."{");
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillParameterReturn�",$Spaces.$MultipleSpaces.$Spaces.$Spaces.$Spaces."if ((".GetParameterIdentifier()."_val ".$HelperLine." [SOutput->_".GetParameterIdentifier()."_len".$FollowingLengthExtension."]) == NULL)"); 
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillParameterReturn�",$Spaces.$MultipleSpaces.$Spaces.$Spaces.$Spaces."{");
            for ($ArrayIndex = 0; $ArrayIndex <= $DimensionIndex; $ArrayIndex++) {
                if ($ArrayIndex == 0) {
                    ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillParameterReturn�",$Spaces.$MultipleSpaces.$Spaces.$Spaces.$Spaces.$Spaces."Increase_".GetParameterIdentifier()."_len = 0;");
                }
                else {
                    ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillParameterReturn�",$Spaces.$MultipleSpaces.$Spaces.$Spaces.$Spaces.$Spaces."Increase_".GetParameterIdentifier()."_len".$ArrayIndex." = 0;");
                }
            }
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillParameterReturn�",$Spaces.$MultipleSpaces.$Spaces.$Spaces.$Spaces.$Spaces."continue;"); 
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillParameterReturn�",$Spaces.$MultipleSpaces.$Spaces.$Spaces.$Spaces."}");
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillParameterReturn�",$Spaces.$MultipleSpaces.$Spaces.$Spaces."}");
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillParameterReturn�",$Spaces.$MultipleSpaces.$Spaces.$Spaces."catch(...)");
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillParameterReturn�",$Spaces.$MultipleSpaces.$Spaces.$Spaces."{");
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillParameterReturn�",$Spaces.$MultipleSpaces.$Spaces.$Spaces.$Spaces.GetParameterIdentifier()."_val = NULL;");
            for ($ArrayIndex = 0; $ArrayIndex <= $DimensionIndex; $ArrayIndex++) {
                if ($ArrayIndex == 0) {
                    ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillParameterReturn�",$Spaces.$MultipleSpaces.$Spaces.$Spaces.$Spaces."Increase_".GetParameterIdentifier()."_len = 0;");
                }
                else {
                    ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillParameterReturn�",$Spaces.$MultipleSpaces.$Spaces.$Spaces.$Spaces."Increase_".GetParameterIdentifier()."_len".$ArrayIndex." = 0;");
                }
            }
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillParameterReturn�",$Spaces.$MultipleSpaces.$Spaces.$Spaces.$Spaces."continue;"); 
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillParameterReturn�",$Spaces.$MultipleSpaces.$Spaces.$Spaces."}");
            if ($DimensionIndex == $g_DynamicDimensionCounter-2) {
                ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillParameterReturn�",$Spaces.$MultipleSpaces.$Spaces.$Spaces."for (Index_".GetParameterIdentifier()."_len".$FollowingLengthExtension." = 0; Index_".GetParameterIdentifier()."_len".$FollowingLengthExtension." < SOutput->_".GetParameterIdentifier()."_len".$FollowingLengthExtension."; Index_".GetParameterIdentifier()."_len".$FollowingLengthExtension."++)"); 
                ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillParameterReturn�",$Spaces.$MultipleSpaces.$Spaces.$Spaces."{");
                $HelperLine = "";
                for ($DimensionIndex = 0; $DimensionIndex < $g_DynamicDimensionCounter; $DimensionIndex++) {
                    if ($DimensionIndex == 0) {
                        $LengthExtension = "";
                    }
                    else {
                        $LengthExtension = $DimensionIndex;
                    }
                    $HelperLine = $HelperLine."[Index_".GetParameterIdentifier()."_len".$LengthExtension."]";
                }
                $HelperLine = GetParameterIdentifier()."_val ".$HelperLine." = SOutput->".GetParameterIdentifier().".".GetParameterIdentifier()."_val[SingleArrayIndex_".GetParameterIdentifier()."_len];";
                ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillParameterReturn�",$Spaces.$MultipleSpaces.$Spaces.$Spaces.$Spaces.$HelperLine); 
                ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillParameterReturn�",$Spaces.$MultipleSpaces.$Spaces.$Spaces.$Spaces."SingleArrayIndex_".GetParameterIdentifier()."_len++;"); 
                ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillParameterReturn�",$Spaces.$MultipleSpaces.$Spaces.$Spaces."}"); 
            }
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillParameterReturn�",$Spaces.$MultipleSpaces.$Spaces."}"); 
            $MultipleSpaces = $MultipleSpaces.$Spaces;
        }
        if ($g_DynamicDimensionCounter == 1) {
            $Spaces = GetSpacesInFrontOfTemplateAtClientClassRPCMethodDefinition ("�FillParameterReturn�");
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillParameterReturn�",$Spaces."for (Index_".GetParameterIdentifier()."_len".$FollowingLengthExtension." = 0; Index_".GetParameterIdentifier()."_len".$FollowingLengthExtension." < SOutput->_".GetParameterIdentifier()."_len".$FollowingLengthExtension."; Index_".GetParameterIdentifier()."_len".$FollowingLengthExtension."++)"); 
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillParameterReturn�",$Spaces."{");
            $HelperLine = "";
            for ($DimensionIndex = 0; $DimensionIndex < $g_DynamicDimensionCounter; $DimensionIndex++) {
                if ($DimensionIndex == 0) {
                    $LengthExtension = "";
                }
                else {
                    $LengthExtension = $DimensionIndex;
                }
                $HelperLine = $HelperLine."[Index_".GetParameterIdentifier()."_len".$LengthExtension."]";
            }
            $HelperLine = GetParameterIdentifier()."_val ".$HelperLine." = SOutput->".GetParameterIdentifier().".".GetParameterIdentifier()."_val[SingleArrayIndex_".GetParameterIdentifier()."_len];";
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillParameterReturn�",$Spaces.$Spaces.$HelperLine); 
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillParameterReturn�",$Spaces.$Spaces."SingleArrayIndex_".GetParameterIdentifier()."_len++;"); 
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillParameterReturn�",$Spaces."}"); 
        }
        # Create closing part of for-loop
        $Spaces = GetSpacesInFrontOfTemplateAtClientClassRPCMethodDefinition ("�FillParameterReturn�");
        $MultipleSpaces = "";
        for ($DimensionIndex = $g_DynamicDimensionCounter-2; $DimensionIndex >= 0; $DimensionIndex--) {
            if ($DimensionIndex == 0) {
                $LengthExtension = "";
            }
            else {
                $LengthExtension = $DimensionIndex;
            }
            $MultipleSpaces = "";
            for ($SpacesIndex = 0; $SpacesIndex < $DimensionIndex; $SpacesIndex++) {
                $MultipleSpaces = $MultipleSpaces.$Spaces;
            }
            $HelperLine = "";
            for ($ArrayIndex = 0; $ArrayIndex <= $DimensionIndex; $ArrayIndex++) {
                if ($ArrayIndex == 0) {
                    $HelperLine = $HelperLine."[Index_".GetParameterIdentifier()."_len]";
                }
                else {
                    $HelperLine = $HelperLine."[Index_".GetParameterIdentifier()."_len".$ArrayIndex."]";
                }
            }
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillParameterReturn�",$Spaces.$MultipleSpaces.$Spaces."if (!Increase_".GetParameterIdentifier()."_len)");
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillParameterReturn�",$Spaces.$MultipleSpaces.$Spaces."{");
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillParameterReturn�",$Spaces.$MultipleSpaces.$Spaces.$Spaces."delete [] ".GetParameterIdentifier()."_val ".$HelperLine.";");
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillParameterReturn�",$Spaces.$MultipleSpaces.$Spaces.$Spaces.GetParameterIdentifier()."_val ".$HelperLine." = NULL;");
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillParameterReturn�",$Spaces.$MultipleSpaces.$Spaces.$Spaces."if (Increase_".GetParameterIdentifier()."_len".$LengthExtension." == 0 && Index_".GetParameterIdentifier()."_len".$LengthExtension." == 0)");
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillParameterReturn�",$Spaces.$MultipleSpaces.$Spaces.$Spaces.$Spaces."Stop_".GetParameterIdentifier()."_len".$LengthExtension." = 1;");
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillParameterReturn�",$Spaces.$MultipleSpaces.$Spaces."}");
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillParameterReturn�",$Spaces.$MultipleSpaces."}");
        }
        if ($g_DynamicDimensionCounter > 1) {
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillParameterReturn�",$Spaces."if (!Increase_".GetParameterIdentifier()."_len)"); 
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillParameterReturn�",$Spaces."{");
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillParameterReturn�",$Spaces.$Spaces."delete [] ".GetParameterIdentifier()."_val;");
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillParameterReturn�",$Spaces.$Spaces.GetParameterIdentifier()."_val = NULL;");
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillParameterReturn�",$Spaces.$Spaces."priv_strError = \"Can't allocate enough memory\";");
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillParameterReturn�",$Spaces.$Spaces."CInterfaceExcept.strErrorMsg = priv_strError;");
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillParameterReturn�",$Spaces.$Spaces."CInterfaceExcept._operation_state = 1;");
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillParameterReturn�",$Spaces.$Spaces."__usInternalError = 1;");
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillParameterReturn�",$Spaces.$Spaces."goto ".lc(GetProgramName()."_".GetFunctionIdentifier()."_1")."_Return;");
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillParameterReturn�",$Spaces."}");
        }
        ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillParameterReturn�","}"); 
        # Final clean up
        $Spaces = GetSpacesInFrontOfTemplateAtClientClassRPCMethodDefinition ("�FinalCleanUp�");
        if ($g_DynamicDimensionCounter > 0) {
            # Free SOutput    
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FinalCleanUp�","if (SOutput != NULL &&"); 
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FinalCleanUp�","    SOutput->".GetParameterIdentifier().".".GetParameterIdentifier()."_val != NULL)"); 
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FinalCleanUp�","{"); 
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FinalCleanUp�",$Spaces."free (SOutput->".GetParameterIdentifier().".".GetParameterIdentifier()."_val);"); 
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FinalCleanUp�",$Spaces."SOutput->".GetParameterIdentifier().".".GetParameterIdentifier()."_val = NULL;"); 
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FinalCleanUp�",$Spaces."SOutput->".GetParameterIdentifier().".".GetParameterIdentifier()."_len = 0;"); 
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FinalCleanUp�","}"); 
        }
    }
    if (ParameterIsInput ()) {
        $Spaces = GetSpacesInFrontOfTemplateAtClientClassRPCMethodDefinition ("�FinalCleanUp�");
        if ($g_DynamicDimensionCounter > 0) {
            # Free Input    
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FinalCleanUp�","if (SInput.".GetParameterIdentifier().".".GetParameterIdentifier()."_val != NULL)");
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FinalCleanUp�","{");
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FinalCleanUp�",$Spaces."free (SInput.".GetParameterIdentifier().".".GetParameterIdentifier()."_val);");
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FinalCleanUp�",$Spaces."SInput.".GetParameterIdentifier().".".GetParameterIdentifier()."_val = NULL;");
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FinalCleanUp�",$Spaces."SInput.".GetParameterIdentifier().".".GetParameterIdentifier()."_len = 0;"); 
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FinalCleanUp�","}");
        }
        # Delete existing dynamic arrays
        # Create opening part of for-loop
        if (ParameterIsInput () && ParameterIsOutput ()) {
            $MultipleSpaces = $Spaces;
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FinalCleanUp�","if (__usInternalError &&"); 
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FinalCleanUp�","    ".GetParameterIdentifier()."_val != NULL)"); 
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FinalCleanUp�","{"); 
            for ($DimensionIndex = 0; $DimensionIndex < $g_DynamicDimensionCounter-1; $DimensionIndex++) {
                if ($DimensionIndex == 0) {
                    $LengthExtension = "";
                }
                else {
                    $LengthExtension = $DimensionIndex;
                }
                ReplaceTemplateAtClientClassRPCMethodDefinition ("�FinalCleanUp�",$MultipleSpaces."for (Index_".GetParameterIdentifier()."_len".$LengthExtension." = 0; Index_".GetParameterIdentifier()."_len".$LengthExtension." < _".GetParameterIdentifier()."_len".$LengthExtension."; Index_".GetParameterIdentifier()."_len".$LengthExtension."++)"); 
                ReplaceTemplateAtClientClassRPCMethodDefinition ("�FinalCleanUp�",$MultipleSpaces."{"); 
                $MultipleSpaces = $MultipleSpaces.$Spaces;
            }
            # Create closing part of for-loop
            for ($DimensionIndex = $g_DynamicDimensionCounter-2; $DimensionIndex >= 0; $DimensionIndex--) {
                if ($DimensionIndex == 0) {
                    $LengthExtension = "";
                }
                else {
                    $LengthExtension = $DimensionIndex;
                }
                $MultipleSpaces = "";
                for ($SpacesIndex = 0; $SpacesIndex < $DimensionIndex; $SpacesIndex++) {
                    $MultipleSpaces = $MultipleSpaces.$Spaces;
                }
                $HelperLine = "";
                for ($ArrayIndex = 0; $ArrayIndex <= $DimensionIndex; $ArrayIndex++) {
                    if ($ArrayIndex == 0) {
                        $HelperLine = $HelperLine."[Index_".GetParameterIdentifier()."_len]";
                    }
                    else {
                        $HelperLine = $HelperLine."[Index_".GetParameterIdentifier()."_len".$ArrayIndex."]";
                    }
                }
                ReplaceTemplateAtClientClassRPCMethodDefinition ("�FinalCleanUp�",$MultipleSpaces.$Spaces.$Spaces."delete [] ".GetParameterIdentifier()."_val ".$HelperLine.";"); 
                ReplaceTemplateAtClientClassRPCMethodDefinition ("�FinalCleanUp�",$MultipleSpaces.$Spaces."}"); 
            }
            # Create final delete of Array
            if ($g_DynamicDimensionCounter > 0) {
                ReplaceTemplateAtClientClassRPCMethodDefinition ("�FinalCleanUp�",$Spaces."delete [] ".GetParameterIdentifier()."_val;"); 
                ReplaceTemplateAtClientClassRPCMethodDefinition ("�FinalCleanUp�",$Spaces.GetParameterIdentifier()."_val = NULL;"); 
            }
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FinalCleanUp�","}"); 
        }
    }
 }

# >--------------------------------------------------------------------------<
# > Subroutine: AddToRPCCLIENTCPP_DYNAMICSTRINGARRAY                         <
# >             Add dynamic handling to client part of RPC for string arrays <
# > Parameter:  -                                                            <
# > Return:     -                                                            <
# > Author:     A. Neidhardt                                                 <
# > Date:       03.05.2007                                                   <
# > Revision:   -                                                            <
# > Info:       -                                                            <
# >--------------------------------------------------------------------------<
sub AddToRPCCLIENTCPP_DYNAMICSTRINGARRAY {
    my $DimensionIndex = 0;    # Index to run through dimensions
    my $ArrayIndex = 0;        # Index to run through array []
    my $LengthExtension = "";  # Variable to create length variable extension number
    my $FollowingLengthExtension = "";  # Variable to create length variable of following extension number
    my $HelperLine = "";       # Variable to construct one line before replacing template
    my $Spaces = "";           # Variable with white spaces derived from template
    my $MultipleSpaces = "";   # Concatenation of white spaces derived from template
    my $SpacesIndex = 0;       # Index to run through spaces
    
    # Create length parameters ======================================================================================================================
    for ($DimensionIndex = 0; $DimensionIndex < $g_DynamicDimensionCounter; $DimensionIndex++) {
        if ($DimensionIndex == 0) {
            $LengthExtension = "";
        }
        else {
            $LengthExtension = $DimensionIndex;
        }
        if (ParameterIsOutput ()){
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�Parameters�",", unsigned int & _".GetParameterIdentifier()."_len".$LengthExtension);
        }
        else {
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�Parameters�",", unsigned int _".GetParameterIdentifier()."_len".$LengthExtension);
        }
    }

    # Create Variabledefinitions ====================================================================================================================
    if ($g_DynamicDimensionCounter > 0) {
        if (!$g_CopyRunnerVariableIsSetClient) {
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�VariableDefinitions�","char * pcCopyRunner = NULL;");
            $g_CopyRunnerVariableIsSetClient = 1;
        }
    }
    for ($DimensionIndex = 0; $DimensionIndex < $g_DynamicDimensionCounter; $DimensionIndex++) {
        if ($DimensionIndex == 0) {
            $LengthExtension = "";
        }
        else {
            $LengthExtension = $DimensionIndex;
        }
        ReplaceTemplateAtClientClassRPCMethodDefinition ("�VariableDefinitions�","unsigned int Index_".GetParameterIdentifier()."_len".$LengthExtension.";");
        if (ParameterIsOutput() &&
            $DimensionIndex < $g_DynamicDimensionCounter-1) {
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�VariableDefinitions�","unsigned int Increase_".GetParameterIdentifier()."_len".$LengthExtension.";");
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�VariableDefinitions�","unsigned int Stop_".GetParameterIdentifier()."_len".$LengthExtension.";");
        }
    }
    
    # Fill in RPC structure =========================================================================================================================
    if ($g_DynamicDimensionCounter > 0) {
        if (ParameterIsInput()) {
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�VariableInit�","SInput.".GetParameterIdentifier().".".GetParameterIdentifier()."_val = NULL;");
            # Set input length variables
            for ($DimensionIndex = 0; $DimensionIndex < $g_DynamicDimensionCounter; $DimensionIndex++) {
                if ($DimensionIndex == 0) {
                    $LengthExtension = "";
                }
                else {
                    $LengthExtension = $DimensionIndex;
                }
                ReplaceTemplateAtClientClassRPCMethodDefinition ("�VariableInit�","SInput._".GetParameterIdentifier()."_len".$LengthExtension." = 0;");
            }
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�VariableInit�","SInput.".GetParameterIdentifier().".".GetParameterIdentifier()."_len = 0;");
        }
#        if (!$g_CheckTransportProtocol) {
#            # Check if transport protocol is set to TCP when using dynamic arrays
#            $Spaces = GetSpacesInFrontOfTemplateAtClientClassRPCMethodDefinition ("�FillINVariables�");
#            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillINVariables�","if (priv_usTransportProtocol != 1)");
#            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillINVariables�","{");
#            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillINVariables�",$Spaces."priv_strError = \"Wrong transport protocol for dynamic arrays\";");
#            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillINVariables�",$Spaces."CInterfaceExcept.strErrorMsg = priv_strError;");
#            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillINVariables�",$Spaces."CInterfaceExcept._operation_state = 1;");
#            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillINVariables�",$Spaces."__usInternalError = 1;");
#            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillINVariables�",$Spaces."goto ".lc(GetProgramName()."_".GetFunctionIdentifier()."_1")."_Return;");
#            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillINVariables�","}");
#            $g_CheckTransportProtocol = 1;
#        }
    }
    if (ParameterIsInput ()) {
        $Spaces = GetSpacesInFrontOfTemplateAtClientClassRPCMethodDefinition ("�FillINVariables�");
        ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillINVariables�","if (".GetParameterIdentifier()."_val == NULL)");
        ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillINVariables�","{");
        for ($DimensionIndex = 0; $DimensionIndex < $g_DynamicDimensionCounter; $DimensionIndex++) {
            if ($DimensionIndex == 0) {
                $LengthExtension = "";
            }
            else {
                $LengthExtension = $DimensionIndex;
            }
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillINVariables�",$Spaces."SInput._".GetParameterIdentifier()."_len".$LengthExtension." = 0;");
        }
        ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillINVariables�",$Spaces."SInput.".GetParameterIdentifier().".".GetParameterIdentifier()."_len = 0;");
        ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillINVariables�",$Spaces."SInput.".GetParameterIdentifier().".".GetParameterIdentifier()."_val = NULL;");
        ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillINVariables�","}");
        ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillINVariables�","else");
        ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillINVariables�","{");
        # Set input length variables
        for ($DimensionIndex = 0; $DimensionIndex < $g_DynamicDimensionCounter; $DimensionIndex++) {
            if ($DimensionIndex == 0) {
                $LengthExtension = "";
            }
            else {
                $LengthExtension = $DimensionIndex;
            }
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillINVariables�",$Spaces."SInput._".GetParameterIdentifier()."_len".$LengthExtension." = _".GetParameterIdentifier()."_len".$LengthExtension.";");
        }
        ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillINVariables�",$Spaces."SInput.".GetParameterIdentifier().".".GetParameterIdentifier()."_len = 0;");
        # Count characters to calculate size of single array
        $Spaces = GetSpacesInFrontOfTemplateAtClientClassRPCMethodDefinition ("�FillINVariables�");
        $MultipleSpaces = "";
        $HelperLine = "";
        for ($DimensionIndex = 0; $DimensionIndex < $g_DynamicDimensionCounter; $DimensionIndex++) {
            if ($DimensionIndex == 0) {
                $LengthExtension = "";
            }
            else {
                $LengthExtension = $DimensionIndex;
            }
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillINVariables�",$Spaces.$MultipleSpaces."for (Index_".GetParameterIdentifier()."_len".$LengthExtension." = 0; Index_".GetParameterIdentifier()."_len".$LengthExtension." < _".GetParameterIdentifier()."_len".$LengthExtension."; Index_".GetParameterIdentifier()."_len".$LengthExtension."++)"); 
            $MultipleSpaces = $MultipleSpaces.$Spaces;
            $HelperLine = $HelperLine."[Index_".GetParameterIdentifier()."_len".$LengthExtension."]";
        }
        ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillINVariables�",$Spaces.$MultipleSpaces."SInput.".GetParameterIdentifier().".".GetParameterIdentifier()."_len += ".GetParameterIdentifier()."_val ".$HelperLine.".length()+1;"); 
        # Allocate single array
        $Spaces = GetSpacesInFrontOfTemplateAtClientClassRPCMethodDefinition ("�FillINVariables�");
        if ($g_DynamicDimensionCounter > 0) {
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillINVariables�",$Spaces."if ((SInput.".GetParameterIdentifier().".".GetParameterIdentifier()."_val = (char *) malloc (sizeof(char)*SInput.".GetParameterIdentifier().".".GetParameterIdentifier()."_len)) == NULL)");
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillINVariables�",$Spaces."{");
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillINVariables�",$Spaces.$Spaces."priv_strError = \"Can't allocate enough memory\";");
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillINVariables�",$Spaces.$Spaces."CInterfaceExcept.strErrorMsg = priv_strError;");
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillINVariables�",$Spaces.$Spaces."CInterfaceExcept._operation_state = 1;");
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillINVariables�",$Spaces.$Spaces."__usInternalError = 1;");
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillINVariables�",$Spaces.$Spaces."goto ".lc(GetProgramName()."_".GetFunctionIdentifier()."_1")."_Return;");
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillINVariables�",$Spaces."}");
        }
        # Copy multiple array into single array
        $Spaces = GetSpacesInFrontOfTemplateAtClientClassRPCMethodDefinition ("�FillINVariables�");
        ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillINVariables�",$Spaces."pcCopyRunner = SInput.".GetParameterIdentifier().".".GetParameterIdentifier()."_val;");
        # Delete existing dynamic arrays
        $Spaces = GetSpacesInFrontOfTemplateAtClientClassRPCMethodDefinition ("�FillINVariables�");
        # Create opening part of for-loop
        $MultipleSpaces = "";
        for ($DimensionIndex = 0; $DimensionIndex < $g_DynamicDimensionCounter; $DimensionIndex++) {
            if ($DimensionIndex == 0) {
                $LengthExtension = "";
            }
            else {
                $LengthExtension = $DimensionIndex;
            }
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillINVariables�",$Spaces.$MultipleSpaces."for (Index_".GetParameterIdentifier()."_len".$LengthExtension." = 0; Index_".GetParameterIdentifier()."_len".$LengthExtension." < _".GetParameterIdentifier()."_len".$LengthExtension."; Index_".GetParameterIdentifier()."_len".$LengthExtension."++)"); 
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillINVariables�",$Spaces.$MultipleSpaces."{"); 
            $MultipleSpaces = $MultipleSpaces.$Spaces;
        }
        # Create closing part of for-loop
        for ($DimensionIndex = $g_DynamicDimensionCounter-1; $DimensionIndex >= 0; $DimensionIndex--) {
            if ($DimensionIndex == 0) {
                $LengthExtension = "";
            }
            else {
                $LengthExtension = $DimensionIndex;
            }
            $MultipleSpaces = "";
            for ($SpacesIndex = 0; $SpacesIndex < $DimensionIndex; $SpacesIndex++) {
                $MultipleSpaces = $MultipleSpaces.$Spaces;
            }
            $HelperLine = "";
            for ($ArrayIndex = 0; $ArrayIndex <= $DimensionIndex; $ArrayIndex++) {
                if ($ArrayIndex == 0) {
                    $HelperLine = $HelperLine."[Index_".GetParameterIdentifier()."_len]";
                }
                else {
                    $HelperLine = $HelperLine."[Index_".GetParameterIdentifier()."_len".$ArrayIndex."]";
                }
            }
            if ($DimensionIndex != $g_DynamicDimensionCounter-1) {
                if (ParameterIsInput () && ParameterIsOutput ()) {
                    ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillINVariables�",$Spaces.$MultipleSpaces.$Spaces."delete [] ".GetParameterIdentifier()."_val ".$HelperLine.";"); 
                }
            }
            else {
                ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillINVariables�",$Spaces.$MultipleSpaces.$Spaces."strncpy (pcCopyRunner, ".GetParameterIdentifier()."_val ".$HelperLine.".c_str(), ".GetParameterIdentifier()."_val ".$HelperLine.".length());");
                ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillINVariables�",$Spaces.$MultipleSpaces.$Spaces."pcCopyRunner += ".GetParameterIdentifier()."_val ".$HelperLine.".length();");
                ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillINVariables�",$Spaces.$MultipleSpaces.$Spaces."*pcCopyRunner = '\\0';");
                ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillINVariables�",$Spaces.$MultipleSpaces.$Spaces."pcCopyRunner++;");
            }
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillINVariables�",$Spaces.$MultipleSpaces."}"); 
        }
        # Create final delete of Array
        if ($g_DynamicDimensionCounter > 0 &&
            ParameterIsInput () && ParameterIsOutput ()) {
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillINVariables�",$Spaces."delete [] ".GetParameterIdentifier()."_val;"); 
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillINVariables�",$Spaces.GetParameterIdentifier()."_val = NULL;"); 
        }
        ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillINVariables�","}");
        ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillINVariables�","priv_ulRoundTripByteSum += (SInput.".GetParameterIdentifier().".".GetParameterIdentifier()."_len*sizeof(char));");
    }   
    # Call RPC ======================================================================================================================================
    # Nothing has to be done, cause it is done outside
    
    # Fill return values ============================================================================================================================
    # Fill return values
    if (ParameterIsOutput ()) {
        $Spaces = GetSpacesInFrontOfTemplateAtClientClassRPCMethodDefinition ("�FillParameterReturn�");
        ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillParameterReturn�","if (SOutput->".GetParameterIdentifier().".".GetParameterIdentifier()."_val == NULL)");
        ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillParameterReturn�","{");
        for ($DimensionIndex = 0; $DimensionIndex < $g_DynamicDimensionCounter; $DimensionIndex++) {
            if ($DimensionIndex == 0) {
                $LengthExtension = "";
            }
            else {
                $LengthExtension = $DimensionIndex;
            }
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillParameterReturn�",$Spaces."_".GetParameterIdentifier()."_len".$LengthExtension." = 0;"); 
        }
        ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillParameterReturn�",$Spaces.GetParameterIdentifier()."_val = NULL;");
        ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillParameterReturn�","}");
        ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillParameterReturn�","else");
        ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillParameterReturn�","{");
        ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillParameterReturn�",$Spaces."priv_ulRoundTripByteSum += (SOutput->".GetParameterIdentifier().".".GetParameterIdentifier()."_len*sizeof(char));");
        # Init length varaibles
        for ($DimensionIndex = 0; $DimensionIndex < $g_DynamicDimensionCounter; $DimensionIndex++) {
            if ($DimensionIndex == 0) {
                $LengthExtension = "";
            }
            else {
                $LengthExtension = $DimensionIndex;
            }
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillParameterReturn�",$Spaces."_".GetParameterIdentifier()."_len".$LengthExtension." = SOutput->_".GetParameterIdentifier()."_len".$LengthExtension.";"); 
        }
        # Create first dimension of Array
        if ($g_DynamicDimensionCounter > 0) {
            $HelperLine = "";
            for ($ArrayIndex = 0; $ArrayIndex <= $g_DynamicDimensionCounter-2; $ArrayIndex++) {
                $HelperLine = $HelperLine."*";
            }
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillParameterReturn�",$Spaces."try");
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillParameterReturn�",$Spaces."{");
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillParameterReturn�",$Spaces.$Spaces."if ((".GetParameterIdentifier()."_val = new std::".GetParameterType()." ".$HelperLine." [SOutput->_".GetParameterIdentifier()."_len]) == NULL)"); 
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillParameterReturn�",$Spaces.$Spaces."{");
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillParameterReturn�",$Spaces.$Spaces.$Spaces."priv_strError = \"Can't allocate enough memory\";");
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillParameterReturn�",$Spaces.$Spaces.$Spaces."CInterfaceExcept.strErrorMsg = priv_strError;");
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillParameterReturn�",$Spaces.$Spaces.$Spaces."CInterfaceExcept._operation_state = 1;");
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillParameterReturn�",$Spaces.$Spaces.$Spaces."__usInternalError = 1;");
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillParameterReturn�",$Spaces.$Spaces.$Spaces."goto ".lc(GetProgramName()."_".GetFunctionIdentifier()."_1")."_Return;");
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillParameterReturn�",$Spaces.$Spaces."}"); 
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillParameterReturn�",$Spaces."}"); 
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillParameterReturn�",$Spaces."catch (...)");
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillParameterReturn�",$Spaces."{");
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillParameterReturn�",$Spaces.$Spaces.GetParameterIdentifier()."_val = NULL;");
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillParameterReturn�",$Spaces.$Spaces."priv_strError = \"Can't allocate enough memory\";");
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillParameterReturn�",$Spaces.$Spaces."CInterfaceExcept.strErrorMsg = priv_strError;");
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillParameterReturn�",$Spaces.$Spaces."CInterfaceExcept._operation_state = 1;");
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillParameterReturn�",$Spaces.$Spaces."__usInternalError = 1;");
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillParameterReturn�",$Spaces.$Spaces."goto ".lc(GetProgramName()."_".GetFunctionIdentifier()."_1")."_Return;");
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillParameterReturn�",$Spaces."}"); 
        }
        # Create opening part of for-loop
        $MultipleSpaces = "";
        ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillParameterReturn�",$Spaces."pcCopyRunner = SOutput->".GetParameterIdentifier().".".GetParameterIdentifier()."_val;");
        for ($DimensionIndex = 0; $DimensionIndex < $g_DynamicDimensionCounter-1; $DimensionIndex++) {
            if ($DimensionIndex == 0) {
                $LengthExtension = "";
                $FollowingLengthExtension = "1";
            }
            else {
                $LengthExtension = $DimensionIndex;
                $FollowingLengthExtension = $DimensionIndex + 1;
            }
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillParameterReturn�",$Spaces.$MultipleSpaces."Index_".GetParameterIdentifier()."_len".$LengthExtension." = 0;"); 
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillParameterReturn�",$Spaces.$MultipleSpaces."Stop_".GetParameterIdentifier()."_len".$LengthExtension." = 0;"); 
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillParameterReturn�",$Spaces.$MultipleSpaces."Increase_".GetParameterIdentifier()."_len".$LengthExtension." = 1;"); 
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillParameterReturn�",$Spaces.$MultipleSpaces."for (Index_".GetParameterIdentifier()."_len".$LengthExtension." = Index_".GetParameterIdentifier()."_len".$LengthExtension."; (Index_".GetParameterIdentifier()."_len".$LengthExtension." < _".GetParameterIdentifier()."_len".$LengthExtension.") && (!Stop_".GetParameterIdentifier()."_len".$LengthExtension."); Increase_".GetParameterIdentifier()."_len".$LengthExtension."?Index_".GetParameterIdentifier()."_len".$LengthExtension."++:Index_".GetParameterIdentifier()."_len".$LengthExtension."--)"); 
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillParameterReturn�",$Spaces.$MultipleSpaces."{"); 
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillParameterReturn�",$Spaces.$MultipleSpaces.$Spaces."if (Increase_".GetParameterIdentifier()."_len)"); 
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillParameterReturn�",$Spaces.$MultipleSpaces.$Spaces."{"); 
            $HelperLine = "";
            for ($ArrayIndex = 0; $ArrayIndex <= $DimensionIndex; $ArrayIndex++) {
                if ($ArrayIndex == 0) {
                    $HelperLine = $HelperLine."[Index_".GetParameterIdentifier()."_len]";
                }
                else {
                    $HelperLine = $HelperLine."[Index_".GetParameterIdentifier()."_len".$ArrayIndex."]";
                }
            }
            $HelperLine = $HelperLine." = new std::".GetParameterType()." ";
            for ($ArrayIndex = ($g_DynamicDimensionCounter-1)-($DimensionIndex+1)-1; $ArrayIndex >= 0 ; $ArrayIndex--) {
                $HelperLine = $HelperLine."*";
            }
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillParameterReturn�",$Spaces.$MultipleSpaces.$Spaces.$Spaces."try");
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillParameterReturn�",$Spaces.$MultipleSpaces.$Spaces.$Spaces."{");
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillParameterReturn�",$Spaces.$MultipleSpaces.$Spaces.$Spaces.$Spaces."if ((".GetParameterIdentifier()."_val ".$HelperLine." [SOutput->_".GetParameterIdentifier()."_len".$FollowingLengthExtension."]) == NULL)"); 
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillParameterReturn�",$Spaces.$MultipleSpaces.$Spaces.$Spaces.$Spaces."{");
            for ($ArrayIndex = 0; $ArrayIndex <= $DimensionIndex; $ArrayIndex++) {
                if ($ArrayIndex == 0) {
                    ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillParameterReturn�",$Spaces.$MultipleSpaces.$Spaces.$Spaces.$Spaces.$Spaces."Increase_".GetParameterIdentifier()."_len = 0;");
                }
                else {
                    ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillParameterReturn�",$Spaces.$MultipleSpaces.$Spaces.$Spaces.$Spaces.$Spaces."Increase_".GetParameterIdentifier()."_len".$ArrayIndex." = 0;");
                }
            }
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillParameterReturn�",$Spaces.$MultipleSpaces.$Spaces.$Spaces.$Spaces.$Spaces."continue;"); 
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillParameterReturn�",$Spaces.$MultipleSpaces.$Spaces.$Spaces.$Spaces."}"); 
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillParameterReturn�",$Spaces.$MultipleSpaces.$Spaces.$Spaces."}"); 
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillParameterReturn�",$Spaces.$MultipleSpaces.$Spaces.$Spaces."catch(...)"); 
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillParameterReturn�",$Spaces.$MultipleSpaces.$Spaces.$Spaces."{");
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillParameterReturn�",$Spaces.$MultipleSpaces.$Spaces.$Spaces.$Spaces.GetParameterIdentifier()."_val = NULL;");
            for ($ArrayIndex = 0; $ArrayIndex <= $DimensionIndex; $ArrayIndex++) {
                if ($ArrayIndex == 0) {
                    ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillParameterReturn�",$Spaces.$MultipleSpaces.$Spaces.$Spaces.$Spaces."Increase_".GetParameterIdentifier()."_len = 0;");
                }
                else {
                    ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillParameterReturn�",$Spaces.$MultipleSpaces.$Spaces.$Spaces.$Spaces."Increase_".GetParameterIdentifier()."_len".$ArrayIndex." = 0;");
                }
            }
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillParameterReturn�",$Spaces.$MultipleSpaces.$Spaces.$Spaces.$Spaces."continue;"); 
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillParameterReturn�",$Spaces.$MultipleSpaces.$Spaces.$Spaces."}"); 
            if ($DimensionIndex == $g_DynamicDimensionCounter-2) {
                ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillParameterReturn�",$Spaces.$MultipleSpaces.$Spaces.$Spaces."for (Index_".GetParameterIdentifier()."_len".$FollowingLengthExtension." = 0; Index_".GetParameterIdentifier()."_len".$FollowingLengthExtension." < SOutput->_".GetParameterIdentifier()."_len".$FollowingLengthExtension."; Index_".GetParameterIdentifier()."_len".$FollowingLengthExtension."++)"); 
                ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillParameterReturn�",$Spaces.$MultipleSpaces.$Spaces.$Spaces."{");
                $HelperLine = "";
                for ($DimensionIndex = 0; $DimensionIndex < $g_DynamicDimensionCounter; $DimensionIndex++) {
                    if ($DimensionIndex == 0) {
                        $LengthExtension = "";
                    }
                    else {
                        $LengthExtension = $DimensionIndex;
                    }
                    $HelperLine = $HelperLine."[Index_".GetParameterIdentifier()."_len".$LengthExtension."]";
                }
                ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillParameterReturn�",$Spaces.$MultipleSpaces.$Spaces.$Spaces.$Spaces.GetParameterIdentifier()."_val ".$HelperLine." = pcCopyRunner;");
                ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillParameterReturn�",$Spaces.$MultipleSpaces.$Spaces.$Spaces.$Spaces."pcCopyRunner += strlen(pcCopyRunner)+1;");
                ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillParameterReturn�",$Spaces.$MultipleSpaces.$Spaces.$Spaces."}"); 
            }
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillParameterReturn�",$Spaces.$MultipleSpaces.$Spaces."}"); 
            $MultipleSpaces = $MultipleSpaces.$Spaces;
        }
        if ($g_DynamicDimensionCounter == 1) {
            $Spaces = GetSpacesInFrontOfTemplateAtClientClassRPCMethodDefinition ("�FillParameterReturn�");
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillParameterReturn�",$Spaces."for (Index_".GetParameterIdentifier()."_len".$FollowingLengthExtension." = 0; Index_".GetParameterIdentifier()."_len".$FollowingLengthExtension." < SOutput->_".GetParameterIdentifier()."_len".$FollowingLengthExtension."; Index_".GetParameterIdentifier()."_len".$FollowingLengthExtension."++)"); 
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillParameterReturn�",$Spaces."{");
            $HelperLine = "";
            for ($DimensionIndex = 0; $DimensionIndex < $g_DynamicDimensionCounter; $DimensionIndex++) {
                if ($DimensionIndex == 0) {
                    $LengthExtension = "";
                }
                else {
                    $LengthExtension = $DimensionIndex;
                }
                $HelperLine = $HelperLine."[Index_".GetParameterIdentifier()."_len".$LengthExtension."]";
            }
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillParameterReturn�",$Spaces.$Spaces.GetParameterIdentifier()."_val ".$HelperLine." = pcCopyRunner;");
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillParameterReturn�",$Spaces.$Spaces."pcCopyRunner += strlen(pcCopyRunner)+1;");
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillParameterReturn�",$Spaces."}"); 
        }
        # Create closing part of for-loop
        $Spaces = GetSpacesInFrontOfTemplateAtClientClassRPCMethodDefinition ("�FillParameterReturn�");
        $MultipleSpaces = "";
        for ($DimensionIndex = $g_DynamicDimensionCounter-2; $DimensionIndex >= 0; $DimensionIndex--) {
            if ($DimensionIndex == 0) {
                $LengthExtension = "";
            }
            else {
                $LengthExtension = $DimensionIndex;
            }
            $MultipleSpaces = "";
            for ($SpacesIndex = 0; $SpacesIndex < $DimensionIndex; $SpacesIndex++) {
                $MultipleSpaces = $MultipleSpaces.$Spaces;
            }
            $HelperLine = "";
            for ($ArrayIndex = 0; $ArrayIndex <= $DimensionIndex; $ArrayIndex++) {
                if ($ArrayIndex == 0) {
                    $HelperLine = $HelperLine."[Index_".GetParameterIdentifier()."_len]";
                }
                else {
                    $HelperLine = $HelperLine."[Index_".GetParameterIdentifier()."_len".$ArrayIndex."]";
                }
            }
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillParameterReturn�",$Spaces.$MultipleSpaces.$Spaces."if (!Increase_".GetParameterIdentifier()."_len)");
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillParameterReturn�",$Spaces.$MultipleSpaces.$Spaces."{");
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillParameterReturn�",$Spaces.$MultipleSpaces.$Spaces.$Spaces."delete [] ".GetParameterIdentifier()."_val ".$HelperLine.";");
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillParameterReturn�",$Spaces.$MultipleSpaces.$Spaces.$Spaces.GetParameterIdentifier()."_val ".$HelperLine." = NULL;");
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillParameterReturn�",$Spaces.$MultipleSpaces.$Spaces.$Spaces."if (Increase_".GetParameterIdentifier()."_len".$LengthExtension." == 0 && Index_".GetParameterIdentifier()."_len".$LengthExtension." == 0)");
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillParameterReturn�",$Spaces.$MultipleSpaces.$Spaces.$Spaces.$Spaces."Stop_".GetParameterIdentifier()."_len".$LengthExtension." = 1;");
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillParameterReturn�",$Spaces.$MultipleSpaces.$Spaces."}");
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillParameterReturn�",$Spaces.$MultipleSpaces."}");
        }
        if ($g_DynamicDimensionCounter > 1) {
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillParameterReturn�",$Spaces."if (!Increase_".GetParameterIdentifier()."_len)"); 
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillParameterReturn�",$Spaces."{");
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillParameterReturn�",$Spaces.$Spaces."delete [] ".GetParameterIdentifier()."_val;");
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillParameterReturn�",$Spaces.$Spaces.GetParameterIdentifier()."_val = NULL;");
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillParameterReturn�",$Spaces.$Spaces."priv_strError = \"Can't allocate enough memory\";");
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillParameterReturn�",$Spaces.$Spaces."CInterfaceExcept.strErrorMsg = priv_strError;");
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillParameterReturn�",$Spaces.$Spaces."CInterfaceExcept._operation_state = 1;");
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillParameterReturn�",$Spaces.$Spaces."__usInternalError = 1;");
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillParameterReturn�",$Spaces.$Spaces."goto ".lc(GetProgramName()."_".GetFunctionIdentifier()."_1")."_Return;");
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillParameterReturn�",$Spaces."}"); 
        }
        ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillParameterReturn�","}");
        # Final clean up
        $Spaces = GetSpacesInFrontOfTemplateAtClientClassRPCMethodDefinition ("�FinalCleanUp�");
        if ($g_DynamicDimensionCounter > 0) {
            # Free SOutput    
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FinalCleanUp�","if (SOutput != NULL &&"); 
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FinalCleanUp�","    SOutput->".GetParameterIdentifier().".".GetParameterIdentifier()."_val != NULL)"); 
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FinalCleanUp�","{"); 
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FinalCleanUp�",$Spaces."free (SOutput->".GetParameterIdentifier().".".GetParameterIdentifier()."_val);"); 
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FinalCleanUp�",$Spaces."SOutput->".GetParameterIdentifier().".".GetParameterIdentifier()."_val = NULL;"); 
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FinalCleanUp�",$Spaces."SOutput->".GetParameterIdentifier().".".GetParameterIdentifier()."_len = 0;"); 
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FinalCleanUp�","}"); 
        }
    }
    if (ParameterIsInput ()) {
        $Spaces = GetSpacesInFrontOfTemplateAtClientClassRPCMethodDefinition ("�FinalCleanUp�");
        if ($g_DynamicDimensionCounter > 0) {
            # Free Input    
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FinalCleanUp�","if (SInput.".GetParameterIdentifier().".".GetParameterIdentifier()."_val != NULL)");
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FinalCleanUp�","{");
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FinalCleanUp�",$Spaces."free (SInput.".GetParameterIdentifier().".".GetParameterIdentifier()."_val);");
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FinalCleanUp�",$Spaces."SInput.".GetParameterIdentifier().".".GetParameterIdentifier()."_val = NULL;");
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FinalCleanUp�",$Spaces."SInput.".GetParameterIdentifier().".".GetParameterIdentifier()."_len = 0;"); 
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FinalCleanUp�","}");
        }
        # Delete existing dynamic arrays
        if (ParameterIsInput () && ParameterIsOutput ()) {
            # Create opening part of for-loop
            $MultipleSpaces = $Spaces;
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FinalCleanUp�","if (__usInternalError &&"); 
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FinalCleanUp�","    ".GetParameterIdentifier()."_val != NULL)"); 
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FinalCleanUp�","{"); 
            for ($DimensionIndex = 0; $DimensionIndex < $g_DynamicDimensionCounter-1; $DimensionIndex++) {
                if ($DimensionIndex == 0) {
                    $LengthExtension = "";
                }
                else {
                    $LengthExtension = $DimensionIndex;
                }
                ReplaceTemplateAtClientClassRPCMethodDefinition ("�FinalCleanUp�",$MultipleSpaces."for (Index_".GetParameterIdentifier()."_len".$LengthExtension." = 0; Index_".GetParameterIdentifier()."_len".$LengthExtension." < _".GetParameterIdentifier()."_len".$LengthExtension."; Index_".GetParameterIdentifier()."_len".$LengthExtension."++)"); 
                ReplaceTemplateAtClientClassRPCMethodDefinition ("�FinalCleanUp�",$MultipleSpaces."{"); 
                $MultipleSpaces = $MultipleSpaces.$Spaces;
            }    
            # Create closing part of for-loop
            for ($DimensionIndex = $g_DynamicDimensionCounter-2; $DimensionIndex >= 0; $DimensionIndex--) {
                if ($DimensionIndex == 0) {
                    $LengthExtension = "";
                }
                else {
                    $LengthExtension = $DimensionIndex;
                }
                $MultipleSpaces = "";
                for ($SpacesIndex = 0; $SpacesIndex < $DimensionIndex; $SpacesIndex++) {
                    $MultipleSpaces = $MultipleSpaces.$Spaces;
                }
                $HelperLine = "";
                for ($ArrayIndex = 0; $ArrayIndex <= $DimensionIndex; $ArrayIndex++) {
                    if ($ArrayIndex == 0) {
                        $HelperLine = $HelperLine."[Index_".GetParameterIdentifier()."_len]";
                    }
                    else {
                        $HelperLine = $HelperLine."[Index_".GetParameterIdentifier()."_len".$ArrayIndex."]";
                    }
                }
                ReplaceTemplateAtClientClassRPCMethodDefinition ("�FinalCleanUp�",$MultipleSpaces.$Spaces.$Spaces."delete [] ".GetParameterIdentifier()."_val ".$HelperLine.";"); 
                ReplaceTemplateAtClientClassRPCMethodDefinition ("�FinalCleanUp�",$MultipleSpaces.$Spaces."}"); 
            }
            # Create final delete of Array
            if ($g_DynamicDimensionCounter > 0) {
                ReplaceTemplateAtClientClassRPCMethodDefinition ("�FinalCleanUp�",$Spaces."delete [] ".GetParameterIdentifier()."_val;"); 
                ReplaceTemplateAtClientClassRPCMethodDefinition ("�FinalCleanUp�",$Spaces.GetParameterIdentifier()."_val = NULL;"); 
            }
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�FinalCleanUp�","}"); 
        }
    }
}

# >--------------------------------------------------------------------------<
# > Subroutine: AddToRPCSERVERPROCCPP_DYNAMICARRAY                           <
# >             Add dynamic handling to server part of RPC                   <
# > Parameter:  -                                                            <
# > Return:     -                                                            <
# > Author:     A. Neidhardt                                                 <
# > Date:       03.05.2007                                                   <
# > Revision:   -                                                            <
# > Info:       -                                                            <
# >--------------------------------------------------------------------------<
sub AddToRPCSERVERPROCCPP_DYNAMICARRAY {
    my $DimensionIndex = 0;    # Index to run through dimensions
    my $ArrayIndex = 0;        # Index to run through array []
    my $LengthExtension = "";  # Variable to create length variable extension number
    my $FollowingLengthExtension = "";  # Variable to create length variable of following extension number
    my $HelperLine = "";       # Variable to construct one line before replacing template
    my $Spaces = "";           # Variable with white spaces derived from template
    my $MultipleSpaces = "";   # Concatenation of white spaces derived from template
    my $SpacesIndex = 0;       # Index to run through spaces

    # Create Variabledefinitions ====================================================================================================================
    if ($g_DynamicDimensionCounter > 0) {
        $Spaces = GetSpacesInFrontOfTemplateAtServerProcRPCMethodDefinition ("�UDPPackagePossibility�");
        ReplaceTemplateAtServerProcRPCMethodDefinition ("�UDPPackagePossibility�","if (g_ulUDPPort == pSSvc->rq_xprt->xp_port)\n".
                                                                                   $Spaces."{\n".
                                                                                   $Spaces.$Spaces."__usInternalError = 1;\n".
                                                                                   $Spaces.$Spaces."SOutput._operation_state = 5; // Wrong transport protocol\n".
                                                                                   $Spaces.$Spaces."goto ".lc(GetProgramName()."_".GetFunctionIdentifier()."_1_svc")."_Return;\n".
                                                                                   $Spaces."}\n");
        ReplaceTemplateAtServerProcRPCMethodDefinition ("�VariableDefinitions�","unsigned int SingleArrayIndex_".GetParameterIdentifier()."_len;");
        $HelperLine = "";
        for ($DimensionIndex = 0; $DimensionIndex < $g_DynamicDimensionCounter; $DimensionIndex++) {
            $HelperLine = $HelperLine."*";
        }
        ReplaceTemplateAtServerProcRPCMethodDefinition ("�VariableDefinitions�",GetParameterType()." ".$HelperLine." ".GetParameterIdentifier()."_val;");
    }
    for ($DimensionIndex = 0; $DimensionIndex < $g_DynamicDimensionCounter; $DimensionIndex++) {
        if ($DimensionIndex == 0) {
            $LengthExtension = "";
        }
        else {
            $LengthExtension = $DimensionIndex;
        }
        if (ParameterIsInput ()) {
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�VariableDefinitions�","unsigned int _".GetParameterIdentifier()."_len".$LengthExtension." = pSInput->_".GetParameterIdentifier()."_len".$LengthExtension.";");
        }
        else {
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�VariableDefinitions�","unsigned int _".GetParameterIdentifier()."_len".$LengthExtension.";");
        }
        ReplaceTemplateAtServerProcRPCMethodDefinition ("�VariableDefinitions�","unsigned int Index_".GetParameterIdentifier()."_len".$LengthExtension.";");
        if (ParameterIsInput() &&
            $DimensionIndex < $g_DynamicDimensionCounter-1) {
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�VariableDefinitions�","unsigned int Increase_".GetParameterIdentifier()."_len".$LengthExtension." = 1;");
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�VariableDefinitions�","unsigned int Stop_".GetParameterIdentifier()."_len".$LengthExtension.";");
        }
    }
    if (ParameterIsInput ()) {
        ReplaceTemplateAtServerProcRPCMethodDefinition ("�VariableInit�",GetParameterIdentifier()."_val = NULL;"); 
    }
    # Fill in from RPC structure =========================================================================================================================
    if (ParameterIsOutput ()) {
        if ($g_DynamicDimensionCounter > 0) {
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillINVariables�","SOutput.".GetParameterIdentifier().".".GetParameterIdentifier()."_len = 0;"); 
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillINVariables�","SOutput.".GetParameterIdentifier().".".GetParameterIdentifier()."_val = NULL;"); 
        }
    }
    if (ParameterIsInput ()) {
        $Spaces = GetSpacesInFrontOfTemplateAtServerProcRPCMethodDefinition ("�FillINVariables�");
        ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillINVariables�","if (pSInput->".GetParameterIdentifier().".".GetParameterIdentifier()."_val != NULL)");
        ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillINVariables�","{");
        # Create first dimension of Array
        if ($g_DynamicDimensionCounter > 0) {
            $HelperLine = "";
            for ($ArrayIndex = 0; $ArrayIndex <= $g_DynamicDimensionCounter-2; $ArrayIndex++) {
                $HelperLine = $HelperLine."*";
            }
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillINVariables�",$Spaces."try");
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillINVariables�",$Spaces."{");
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillINVariables�",$Spaces.$Spaces."if ((".GetParameterIdentifier()."_val = new ".GetParameterType()." ".$HelperLine." [pSInput->_".GetParameterIdentifier()."_len]) == NULL)"); 
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillINVariables�",$Spaces.$Spaces."{");
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillINVariables�",$Spaces.$Spaces.$Spaces."__usInternalError = 1;");
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillINVariables�",$Spaces.$Spaces.$Spaces."SOutput._operation_state = 3; // Memory error");
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillINVariables�",$Spaces.$Spaces.$Spaces."goto ".lc(GetProgramName()."_".GetFunctionIdentifier()."_1_svc")."_Return;");
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillINVariables�",$Spaces.$Spaces."}"); 
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillINVariables�",$Spaces."}"); 
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillINVariables�",$Spaces."catch(...)"); 
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillINVariables�",$Spaces."{");
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillINVariables�",$Spaces.$Spaces.GetParameterIdentifier()."_val = NULL;");
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillINVariables�",$Spaces.$Spaces."__usInternalError = 1;");
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillINVariables�",$Spaces.$Spaces."SOutput._operation_state = 3; // Memory error");
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillINVariables�",$Spaces.$Spaces."goto ".lc(GetProgramName()."_".GetFunctionIdentifier()."_1_svc")."_Return;");
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillINVariables�",$Spaces."}"); 
        }
        # Copy single array into multidim array
        if ($g_DynamicDimensionCounter > 0) {
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillINVariables�",$Spaces."SingleArrayIndex_".GetParameterIdentifier()."_len = 0;"); 
        }
        # Create opening part of for-loop
        $MultipleSpaces = "";
        for ($DimensionIndex = 0; $DimensionIndex < $g_DynamicDimensionCounter-1; $DimensionIndex++) {
            if ($DimensionIndex == 0) {
                $LengthExtension = "";
                $FollowingLengthExtension = "1";
            }
            else {
                $LengthExtension = $DimensionIndex;
                $FollowingLengthExtension = $DimensionIndex + 1;
            }
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillINVariables�",$Spaces.$MultipleSpaces."Index_".GetParameterIdentifier()."_len".$LengthExtension." = 0;"); 
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillINVariables�",$Spaces.$MultipleSpaces."Stop_".GetParameterIdentifier()."_len".$LengthExtension." = 0;"); 
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillINVariables�",$Spaces.$MultipleSpaces."Increase_".GetParameterIdentifier()."_len".$LengthExtension." = 1;"); 
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillINVariables�",$Spaces.$MultipleSpaces."for (Index_".GetParameterIdentifier()."_len".$LengthExtension." = Index_".GetParameterIdentifier()."_len".$LengthExtension."; (Index_".GetParameterIdentifier()."_len".$LengthExtension." < _".GetParameterIdentifier()."_len".$LengthExtension.") && (!Stop_".GetParameterIdentifier()."_len".$LengthExtension."); Increase_".GetParameterIdentifier()."_len".$LengthExtension."?Index_".GetParameterIdentifier()."_len".$LengthExtension."++:Index_".GetParameterIdentifier()."_len".$LengthExtension."--)"); 
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillINVariables�",$Spaces.$MultipleSpaces."{"); 
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillINVariables�",$Spaces.$MultipleSpaces.$Spaces."if (Increase_".GetParameterIdentifier()."_len)"); 
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillINVariables�",$Spaces.$MultipleSpaces.$Spaces."{"); 
            $HelperLine = "";
            for ($ArrayIndex = 0; $ArrayIndex <= $DimensionIndex; $ArrayIndex++) {
                if ($ArrayIndex == 0) {
                    $HelperLine = $HelperLine."[Index_".GetParameterIdentifier()."_len]";
                }
                else {
                    $HelperLine = $HelperLine."[Index_".GetParameterIdentifier()."_len".$ArrayIndex."]";
                }
            }
            $HelperLine = $HelperLine." = new ".GetParameterType()." ";
            for ($ArrayIndex = ($g_DynamicDimensionCounter-1)-($DimensionIndex+1)-1; $ArrayIndex >= 0 ; $ArrayIndex--) {
                $HelperLine = $HelperLine."*";
            }
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillINVariables�",$Spaces.$MultipleSpaces.$Spaces.$Spaces."try");
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillINVariables�",$Spaces.$MultipleSpaces.$Spaces.$Spaces."{");
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillINVariables�",$Spaces.$MultipleSpaces.$Spaces.$Spaces.$Spaces."if ((".GetParameterIdentifier()."_val ".$HelperLine." [pSInput->_".GetParameterIdentifier()."_len".$FollowingLengthExtension."]) == NULL)"); 
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillINVariables�",$Spaces.$MultipleSpaces.$Spaces.$Spaces.$Spaces."{");
            for ($ArrayIndex = 0; $ArrayIndex <= $DimensionIndex; $ArrayIndex++) {
                if ($ArrayIndex == 0) {
                    ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillINVariables�",$Spaces.$MultipleSpaces.$Spaces.$Spaces.$Spaces.$Spaces."Increase_".GetParameterIdentifier()."_len = 0;");
                }
                else {
                    ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillINVariables�",$Spaces.$MultipleSpaces.$Spaces.$Spaces.$Spaces.$Spaces."Increase_".GetParameterIdentifier()."_len".$ArrayIndex." = 0;");
                }
            }
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillINVariables�",$Spaces.$MultipleSpaces.$Spaces.$Spaces.$Spaces.$Spaces."continue;"); 
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillINVariables�",$Spaces.$MultipleSpaces.$Spaces.$Spaces.$Spaces."}"); 
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillINVariables�",$Spaces.$MultipleSpaces.$Spaces.$Spaces."}"); 
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillINVariables�",$Spaces.$MultipleSpaces.$Spaces.$Spaces."catch(...)"); 
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillINVariables�",$Spaces.$MultipleSpaces.$Spaces.$Spaces."{");
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillINVariables�",$Spaces.$MultipleSpaces.$Spaces.$Spaces.$Spaces.GetParameterIdentifier()."_val = NULL;");
            for ($ArrayIndex = 0; $ArrayIndex <= $DimensionIndex; $ArrayIndex++) {
                if ($ArrayIndex == 0) {
                    ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillINVariables�",$Spaces.$MultipleSpaces.$Spaces.$Spaces.$Spaces."Increase_".GetParameterIdentifier()."_len = 0;");
                }
                else {
                    ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillINVariables�",$Spaces.$MultipleSpaces.$Spaces.$Spaces.$Spaces."Increase_".GetParameterIdentifier()."_len".$ArrayIndex." = 0;");
                }
            }
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillINVariables�",$Spaces.$MultipleSpaces.$Spaces.$Spaces.$Spaces."continue;"); 
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillINVariables�",$Spaces.$MultipleSpaces.$Spaces.$Spaces."}"); 
            if ($DimensionIndex == $g_DynamicDimensionCounter-2) {
                $HelperLine = "";
                for ($ArrayIndex = 0; $ArrayIndex <= $g_DynamicDimensionCounter-1; $ArrayIndex++) {
                    if ($ArrayIndex == 0) {
                        $HelperLine = $HelperLine."[Index_".GetParameterIdentifier()."_len]";
                    }
                    else {
                        $HelperLine = $HelperLine."[Index_".GetParameterIdentifier()."_len".$ArrayIndex."]";
                    }
                }
                ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillINVariables�",$Spaces.$MultipleSpaces.$Spaces.$Spaces."for (Index_".GetParameterIdentifier()."_len".$FollowingLengthExtension." = 0; Index_".GetParameterIdentifier()."_len".$FollowingLengthExtension." < pSInput->_".GetParameterIdentifier()."_len".$FollowingLengthExtension."; Index_".GetParameterIdentifier()."_len".$FollowingLengthExtension."++)"); 
                ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillINVariables�",$Spaces.$MultipleSpaces.$Spaces.$Spaces."{");
                $HelperLine = GetParameterIdentifier()."_val ";
                for ($DimensionIndex = 0; $DimensionIndex < $g_DynamicDimensionCounter; $DimensionIndex++) {
                    if ($DimensionIndex == 0) {
                        $LengthExtension = "";
                    }
                    else {
                        $LengthExtension = $DimensionIndex;
                    }
                    $HelperLine = $HelperLine."[Index_".GetParameterIdentifier()."_len".$LengthExtension."]";
                }
                $HelperLine = $HelperLine." = pSInput->".GetParameterIdentifier().".".GetParameterIdentifier()."_val[SingleArrayIndex_".GetParameterIdentifier()."_len];";
                ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillINVariables�",$Spaces.$MultipleSpaces.$Spaces.$Spaces.$Spaces.$HelperLine); 
                ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillINVariables�",$Spaces.$MultipleSpaces.$Spaces.$Spaces.$Spaces."SingleArrayIndex_".GetParameterIdentifier()."_len++;"); 
                ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillINVariables�",$Spaces.$MultipleSpaces.$Spaces.$Spaces."}"); 
            }
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillINVariables�",$Spaces.$MultipleSpaces.$Spaces."}"); 
            $MultipleSpaces = $MultipleSpaces.$Spaces;
        }
        # Create closing part of for-loop
        $Spaces = GetSpacesInFrontOfTemplateAtServerProcRPCMethodDefinition ("�FillINVariables�");
        $MultipleSpaces = "";
        for ($DimensionIndex = $g_DynamicDimensionCounter-2; $DimensionIndex >= 0; $DimensionIndex--) {
            if ($DimensionIndex == 0) {
                $LengthExtension = "";
            }
            else {
                $LengthExtension = $DimensionIndex;
            }
            $MultipleSpaces = "";
            for ($SpacesIndex = 0; $SpacesIndex < $DimensionIndex; $SpacesIndex++) {
                $MultipleSpaces = $MultipleSpaces.$Spaces;
            }
            $HelperLine = "";
            for ($ArrayIndex = 0; $ArrayIndex <= $DimensionIndex; $ArrayIndex++) {
                if ($ArrayIndex == 0) {
                    $HelperLine = $HelperLine."[Index_".GetParameterIdentifier()."_len]";
                }
                else {
                    $HelperLine = $HelperLine."[Index_".GetParameterIdentifier()."_len".$ArrayIndex."]";
                }
            }
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillINVariables�",$Spaces.$MultipleSpaces.$Spaces."if (!Increase_".GetParameterIdentifier()."_len)");
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillINVariables�",$Spaces.$MultipleSpaces.$Spaces."{");
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillINVariables�",$Spaces.$MultipleSpaces.$Spaces.$Spaces."delete [] ".GetParameterIdentifier()."_val ".$HelperLine.";");
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillINVariables�",$Spaces.$MultipleSpaces.$Spaces.$Spaces."if (Increase_".GetParameterIdentifier()."_len".$LengthExtension." == 0 && Index_".GetParameterIdentifier()."_len".$LengthExtension." == 0)");
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillINVariables�",$Spaces.$MultipleSpaces.$Spaces.$Spaces.$Spaces."Stop_".GetParameterIdentifier()."_len".$LengthExtension." = 1;");
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillINVariables�",$Spaces.$MultipleSpaces.$Spaces."}");
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillINVariables�",$Spaces.$MultipleSpaces."}");
        }
        if ($g_DynamicDimensionCounter > 1) {
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillINVariables�",$Spaces."if (!Increase_".GetParameterIdentifier()."_len)"); 
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillINVariables�",$Spaces."{");
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillINVariables�",$Spaces.$Spaces."delete [] ".GetParameterIdentifier()."_val;");
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillINVariables�",$Spaces.$Spaces.GetParameterIdentifier()."_val = NULL;");
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillINVariables�",$Spaces.$Spaces."__usInternalError = 1;");
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillINVariables�",$Spaces.$Spaces."SOutput._operation_state = 3; // Memory error");
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillINVariables�",$Spaces.$Spaces."goto ".lc(GetProgramName()."_".GetFunctionIdentifier()."_1_svc")."_Return;");
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillINVariables�",$Spaces."}"); 
        }
        if ($g_DynamicDimensionCounter == 1) {
            $Spaces = GetSpacesInFrontOfTemplateAtServerProcRPCMethodDefinition ("�FillINVariables�");
            $LengthExtension = "";
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillINVariables�",$Spaces."for (Index_".GetParameterIdentifier()."_len".$LengthExtension." = 0; Index_".GetParameterIdentifier()."_len".$LengthExtension." < pSInput->_".GetParameterIdentifier()."_len".$LengthExtension."; Index_".GetParameterIdentifier()."_len".$LengthExtension."++)"); 
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillINVariables�",$Spaces."{");
            $HelperLine = GetParameterIdentifier()."_val ";
            for ($DimensionIndex = 0; $DimensionIndex < $g_DynamicDimensionCounter; $DimensionIndex++) {
                if ($DimensionIndex == 0) {
                    $LengthExtension = "";
                }
                else {
                    $LengthExtension = $DimensionIndex;
                }
                $HelperLine = $HelperLine."[Index_".GetParameterIdentifier()."_len".$LengthExtension."]";
            }
            $HelperLine = $HelperLine." = pSInput->".GetParameterIdentifier().".".GetParameterIdentifier()."_val[SingleArrayIndex_".GetParameterIdentifier()."_len];";
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillINVariables�",$Spaces.$Spaces.$HelperLine); 
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillINVariables�",$Spaces.$Spaces."SingleArrayIndex_".GetParameterIdentifier()."_len++;"); 
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillINVariables�",$Spaces."}"); 
        }
        ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillINVariables�","}");
    }
    # Call RPC ======================================================================================================================================
    # Create length parameters
    if ($g_DynamicDimensionCounter > 0) {
        if (ParameterIsOutput ()) {
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�Parameters�", GetParameterIdentifier()."_val");
        }
        else {
            $HelperLine = "";
            for ($DimensionIndex = 0; $DimensionIndex < $g_DynamicDimensionCounter; $DimensionIndex++) {
                $HelperLine = $HelperLine."*";
            }
#            ReplaceTemplateAtServerProcRPCMethodDefinition ("�Parameters�","(const ".GetParameterType()." ".$HelperLine.") ".GetParameterIdentifier()."_val");
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�Parameters�",GetParameterIdentifier()."_val");
        }
    }
    for ($DimensionIndex = 0; $DimensionIndex < $g_DynamicDimensionCounter; $DimensionIndex++) {
        if ($DimensionIndex == 0) {
            $LengthExtension = "";
        }
        else {
            $LengthExtension = $DimensionIndex;
        }
        ReplaceTemplateAtServerProcRPCMethodDefinition ("�Parameters�",", _".GetParameterIdentifier()."_len".$LengthExtension);
    }
    # Fill return values ============================================================================================================================
    if (ParameterIsOutput ()) {
        $Spaces = GetSpacesInFrontOfTemplateAtServerProcRPCMethodDefinition ("�FillParameterReturn�");
        ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillParameterReturn�","if (".GetParameterIdentifier()."_val == NULL)");
        ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillParameterReturn�","{");
        ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillParameterReturn�",$Spaces."SOutput.".GetParameterIdentifier().".".GetParameterIdentifier()."_val = NULL;");
        ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillParameterReturn�",$Spaces."SOutput.".GetParameterIdentifier().".".GetParameterIdentifier()."_len = 0;");
        for ($DimensionIndex = 0; $DimensionIndex < $g_DynamicDimensionCounter; $DimensionIndex++) {
            if ($DimensionIndex == 0) {
                $LengthExtension = "";
            }
            else {
                $LengthExtension = $DimensionIndex;
            }
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillParameterReturn�",$Spaces."SOutput._".GetParameterIdentifier()."_len".$LengthExtension." = 0;");
        }
        ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillParameterReturn�","}");
        ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillParameterReturn�","else");
        ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillParameterReturn�","{");
        # Set input length variables
        for ($DimensionIndex = 0; $DimensionIndex < $g_DynamicDimensionCounter; $DimensionIndex++) {
            if ($DimensionIndex == 0) {
                $LengthExtension = "";
            }
            else {
                $LengthExtension = $DimensionIndex;
            }
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillParameterReturn�",$Spaces."SOutput._".GetParameterIdentifier()."_len".$LengthExtension." = _".GetParameterIdentifier()."_len".$LengthExtension.";");
        }
        $HelperLine = "";
        for ($DimensionIndex = 1; $DimensionIndex < $g_DynamicDimensionCounter; $DimensionIndex++) {
            if ($DimensionIndex == 0) {
                $LengthExtension = "";
            }
            else {
                $LengthExtension = $DimensionIndex;
            }
            $HelperLine = $HelperLine." * SOutput._".GetParameterIdentifier()."_len".$LengthExtension;
        }
        if ($g_DynamicDimensionCounter > 0) {
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillParameterReturn�",$Spaces."SOutput.".GetParameterIdentifier().".".GetParameterIdentifier()."_len = SOutput._".GetParameterIdentifier()."_len".$HelperLine.";");
        }
        # Check maximum of dynamic parameters
        $Spaces = GetSpacesInFrontOfTemplateAtServerProcRPCMethodDefinition ("�FillParameterReturn�");
        if ($g_DynamicDimensionCounter > 0) {
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillParameterReturn�",$Spaces."if (ulGetNextDynVarIndex() == MAXDYNVARIABLES)");
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillParameterReturn�",$Spaces."{");
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillParameterReturn�",$Spaces.$Spaces."__usInternalError = 1;");
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillParameterReturn�",$Spaces.$Spaces."SOutput._operation_state = 4; // Too many parameter");
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillParameterReturn�",$Spaces.$Spaces."goto ".lc(GetProgramName()."_".GetFunctionIdentifier()."_1_svc")."_Return;");
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillParameterReturn�",$Spaces."}");
        }
        # Allocate single array
        $Spaces = GetSpacesInFrontOfTemplateAtServerProcRPCMethodDefinition ("�FillParameterReturn�");
        if ($g_DynamicDimensionCounter > 0) {
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillParameterReturn�",$Spaces."if ((SOutput.".GetParameterIdentifier().".".GetParameterIdentifier()."_val = (".GetParameterType()." * ) malloc (sizeof(".GetParameterType().")*SOutput.".GetParameterIdentifier().".".GetParameterIdentifier()."_len)) == NULL)");
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillParameterReturn�",$Spaces."{");
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillParameterReturn�",$Spaces.$Spaces."__usInternalError = 1;");
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillParameterReturn�",$Spaces.$Spaces."SOutput._operation_state = 3; // Memory error");
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillParameterReturn�",$Spaces.$Spaces."SOutput.".GetParameterIdentifier().".".GetParameterIdentifier()."_len = 0;"); 
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillParameterReturn�",$Spaces.$Spaces."goto ".lc(GetProgramName()."_".GetFunctionIdentifier()."_1_svc")."_Return;");
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillParameterReturn�",$Spaces."}");
        }
        if ($g_DynamicDimensionCounter > 0) {
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillParameterReturn�",$Spaces."g_pvDynVarMemory[ulGetNextDynVarIndex()] = SOutput.".GetParameterIdentifier().".".GetParameterIdentifier()."_val;");
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillParameterReturn�",$Spaces."SingleArrayIndex_".GetParameterIdentifier()."_len = 0;");
        }
    }
    # Delete multidim array
    if (ParameterIsOutput ()) {
        $Spaces = GetSpacesInFrontOfTemplateAtServerProcRPCMethodDefinition ("�FillParameterReturn�");
        # Create opening part of for-loop
        $MultipleSpaces = "";
        for ($DimensionIndex = 0; $DimensionIndex < $g_DynamicDimensionCounter; $DimensionIndex++) {
            if ($DimensionIndex == 0) {
                $LengthExtension = "";
            }
            else {
                $LengthExtension = $DimensionIndex;
            }
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillParameterReturn�",$Spaces.$MultipleSpaces."for (Index_".GetParameterIdentifier()."_len".$LengthExtension." = 0; Index_".GetParameterIdentifier()."_len".$LengthExtension." < _".GetParameterIdentifier()."_len".$LengthExtension."; Index_".GetParameterIdentifier()."_len".$LengthExtension."++)"); 
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillParameterReturn�",$Spaces.$MultipleSpaces."{"); 
            $MultipleSpaces = $MultipleSpaces.$Spaces;
        }
        # Create closing part of for-loop
        for ($DimensionIndex = $g_DynamicDimensionCounter-1; $DimensionIndex >= 0; $DimensionIndex--) {
            if ($DimensionIndex == 0) {
                $LengthExtension = "";
            }
            else {
                $LengthExtension = $DimensionIndex;
            }
            $MultipleSpaces = "";
            for ($SpacesIndex = 0; $SpacesIndex < $DimensionIndex; $SpacesIndex++) {
                $MultipleSpaces = $MultipleSpaces.$Spaces;
            }
            $HelperLine = "";
            for ($ArrayIndex = 0; $ArrayIndex <= $DimensionIndex; $ArrayIndex++) {
                if ($ArrayIndex == 0) {
                    $HelperLine = $HelperLine."[Index_".GetParameterIdentifier()."_len]";
                }
                else {
                    $HelperLine = $HelperLine."[Index_".GetParameterIdentifier()."_len".$ArrayIndex."]";
                }
            }
            if ($DimensionIndex == $g_DynamicDimensionCounter-1){
                $HelperLine = "SOutput.".GetParameterIdentifier().".".GetParameterIdentifier()."_val [SingleArrayIndex_".GetParameterIdentifier()."_len] = ".GetParameterIdentifier()."_val ".$HelperLine.";";
                ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillParameterReturn�",$Spaces.$MultipleSpaces.$Spaces.$HelperLine); 
                ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillParameterReturn�",$Spaces.$MultipleSpaces.$Spaces."SingleArrayIndex_".GetParameterIdentifier()."_len++;"); 
            }
            else {
                ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillParameterReturn�",$Spaces.$MultipleSpaces.$Spaces."delete [] ".GetParameterIdentifier()."_val ".$HelperLine.";"); 
            }
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillParameterReturn�",$Spaces.$MultipleSpaces."}"); 
        }
        # Create final delete of Array
        if ($g_DynamicDimensionCounter > 0) {
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillParameterReturn�",$Spaces."delete [] ".GetParameterIdentifier()."_val;"); 
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillParameterReturn�",$Spaces.GetParameterIdentifier()."_val = NULL;"); 
        }
        ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillParameterReturn�","}");
    }
    # Final cleanup
    if (ParameterIsOutput ()) {
        $Spaces = GetSpacesInFrontOfTemplateAtServerProcRPCMethodDefinition ("�FinalCleanUp�");
        ReplaceTemplateAtServerProcRPCMethodDefinition ("�FinalCleanUp�","if (".GetParameterIdentifier()."_val != NULL)"); 
        ReplaceTemplateAtServerProcRPCMethodDefinition ("�FinalCleanUp�","{"); 
        # Create opening part of for-loop
        $MultipleSpaces = "";
        for ($DimensionIndex = 0; $DimensionIndex < $g_DynamicDimensionCounter-1; $DimensionIndex++) {
            if ($DimensionIndex == 0) {
                $LengthExtension = "";
            }
            else {
                $LengthExtension = $DimensionIndex;
            }
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�FinalCleanUp�",$MultipleSpaces.$Spaces."for (Index_".GetParameterIdentifier()."_len".$LengthExtension." = 0; Index_".GetParameterIdentifier()."_len".$LengthExtension." < _".GetParameterIdentifier()."_len".$LengthExtension."; Index_".GetParameterIdentifier()."_len".$LengthExtension."++)"); 
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�FinalCleanUp�",$MultipleSpaces.$Spaces."{"); 
            $MultipleSpaces = $MultipleSpaces.$Spaces;
        }
        # Create closing part of for-loop
        for ($DimensionIndex = $g_DynamicDimensionCounter-2; $DimensionIndex >= 0; $DimensionIndex--) {
            if ($DimensionIndex == 0) {
                $LengthExtension = "";
            }
            else {
                $LengthExtension = $DimensionIndex;
            }
            $MultipleSpaces = "";
            for ($SpacesIndex = 0; $SpacesIndex < $DimensionIndex; $SpacesIndex++) {
                $MultipleSpaces = $MultipleSpaces.$Spaces;
            }
            $HelperLine = "";
            for ($ArrayIndex = 0; $ArrayIndex <= $DimensionIndex; $ArrayIndex++) {
                if ($ArrayIndex == 0) {
                    $HelperLine = $HelperLine."[Index_".GetParameterIdentifier()."_len]";
                }
                else {
                    $HelperLine = $HelperLine."[Index_".GetParameterIdentifier()."_len".$ArrayIndex."]";
                }
            }            
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�FinalCleanUp�",$MultipleSpaces.$Spaces.$Spaces."delete [] ".GetParameterIdentifier()."_val ".$HelperLine.";"); 
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�FinalCleanUp�",$MultipleSpaces.$Spaces."}"); 
        }
        # Create final delete of Array
        if ($g_DynamicDimensionCounter > 0) {
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�FinalCleanUp�",$Spaces."delete [] ".GetParameterIdentifier()."_val;"); 
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�FinalCleanUp�",$Spaces.GetParameterIdentifier()."_val = NULL;"); 
        }
        ReplaceTemplateAtServerProcRPCMethodDefinition ("�FinalCleanUp�","}"); 
        if (ParameterIsOutput ()) {
            $Spaces = GetSpacesInFrontOfTemplateAtServerProcRPCMethodDefinition ("�FinalCleanUp�");
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�ErrorDelete�","if (SOutput.".GetParameterIdentifier().".".GetParameterIdentifier()."_val != NULL)"); 
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�ErrorDelete�","{"); 
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�ErrorDelete�",$Spaces."free (SOutput.".GetParameterIdentifier().".".GetParameterIdentifier()."_val);"); 
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�ErrorDelete�",$Spaces."SOutput.".GetParameterIdentifier().".".GetParameterIdentifier()."_val = NULL;"); 
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�ErrorDelete�",$Spaces."SOutput.".GetParameterIdentifier().".".GetParameterIdentifier()."_len = 0;"); 
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�ErrorDelete�","}"); 
            # Set input length variables
            for ($DimensionIndex = 0; $DimensionIndex < $g_DynamicDimensionCounter; $DimensionIndex++) {
                if ($DimensionIndex == 0) {
                    $LengthExtension = "";
                }
                else {
                    $LengthExtension = $DimensionIndex;
                }
                ReplaceTemplateAtServerProcRPCMethodDefinition ("�ErrorDelete�","SOutput._".GetParameterIdentifier()."_len".$LengthExtension." = 0;");
            }
        }
    }
    if (ParameterIsInput ()) {
        if ($g_DynamicDimensionCounter > 0) {
            # Free SOutput
            $Spaces = GetSpacesInFrontOfTemplateAtServerProcRPCMethodDefinition ("�FinalCleanUp�");
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�FinalCleanUp�","if (pSInput->".GetParameterIdentifier().".".GetParameterIdentifier()."_val != NULL)"); 
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�FinalCleanUp�","{"); 
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�FinalCleanUp�",$Spaces."free (pSInput->".GetParameterIdentifier().".".GetParameterIdentifier()."_val);"); 
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�FinalCleanUp�",$Spaces."pSInput->".GetParameterIdentifier().".".GetParameterIdentifier()."_val = NULL;"); 
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�FinalCleanUp�","}"); 
        }
    }
}

# >--------------------------------------------------------------------------<
# > Subroutine: AddToRPCSERVERPROCCPP_DYNAMICSTRINGARRAY                     <
# >             Add dynamic handling to server part of RPC for string arrays <
# > Parameter:  -                                                            <
# > Return:     -                                                            <
# > Author:     A. Neidhardt                                                 <
# > Date:       03.05.2007                                                   <
# > Revision:   -                                                            <
# > Info:       -                                                            <
# >--------------------------------------------------------------------------<
sub AddToRPCSERVERPROCCPP_DYNAMICSTRINGARRAY {
    my $DimensionIndex = 0;    # Index to run through dimensions
    my $ArrayIndex = 0;        # Index to run through array []
    my $LengthExtension = "";  # Variable to create length variable extension number
    my $FollowingLengthExtension = "";  # Variable to create length variable of following extension number
    my $HelperLine = "";       # Variable to construct one line before replacing template
    my $Spaces = "";           # Variable with white spaces derived from template
    my $MultipleSpaces = "";   # Concatenation of white spaces derived from template
    my $SpacesIndex = 0;       # Index to run through spaces

    # Create Variabledefinitions ====================================================================================================================
    if ($g_DynamicDimensionCounter > 0) {
        $Spaces = GetSpacesInFrontOfTemplateAtServerProcRPCMethodDefinition ("�UDPPackagePossibility�");
        ReplaceTemplateAtServerProcRPCMethodDefinition ("�UDPPackagePossibility�","if (g_ulUDPPort == pSSvc->rq_xprt->xp_port)\n".
                                                                                   $Spaces."{\n".
                                                                                   $Spaces.$Spaces."__usInternalError = 1;\n".
                                                                                   $Spaces.$Spaces."SOutput._operation_state = 5; // Wrong transport protocol\n".
                                                                                   $Spaces.$Spaces."goto ".lc(GetProgramName()."_".GetFunctionIdentifier()."_1_svc")."_Return;\n".
                                                                                   $Spaces."}\n");
        if (!$g_CopyRunnerVariableIsSetServer) {
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�VariableDefinitions�","char * pcCopyRunner = NULL;");
            $g_CopyRunnerVariableIsSetServer = 1;
        }
        $HelperLine = "";
        for ($DimensionIndex = 0; $DimensionIndex < $g_DynamicDimensionCounter; $DimensionIndex++) {
            $HelperLine = $HelperLine."*";
        }
        ReplaceTemplateAtServerProcRPCMethodDefinition ("�VariableDefinitions�","std::".GetParameterType()." ".$HelperLine." ".GetParameterIdentifier()."_val;");
    }
    for ($DimensionIndex = 0; $DimensionIndex < $g_DynamicDimensionCounter; $DimensionIndex++) {
        if ($DimensionIndex == 0) {
            $LengthExtension = "";
        }
        else {
            $LengthExtension = $DimensionIndex;
        }
        if (ParameterIsInput ()) {
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�VariableDefinitions�","unsigned int _".GetParameterIdentifier()."_len".$LengthExtension." = pSInput->_".GetParameterIdentifier()."_len".$LengthExtension.";");
        }
        else {
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�VariableDefinitions�","unsigned int _".GetParameterIdentifier()."_len".$LengthExtension.";");
        }
        ReplaceTemplateAtServerProcRPCMethodDefinition ("�VariableDefinitions�","unsigned int Index_".GetParameterIdentifier()."_len".$LengthExtension.";");
        if (ParameterIsInput() &&
            $DimensionIndex < $g_DynamicDimensionCounter-1) {
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�VariableDefinitions�","unsigned int Increase_".GetParameterIdentifier()."_len".$LengthExtension." = 1;");
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�VariableDefinitions�","unsigned int Stop_".GetParameterIdentifier()."_len".$LengthExtension.";");
        }
    }
    if (ParameterIsInput ()) {
        ReplaceTemplateAtServerProcRPCMethodDefinition ("�VariableInit�",GetParameterIdentifier()."_val = NULL;"); 
    }
    # Fill in from RPC structure =========================================================================================================================
    if (ParameterIsOutput ()) {
        if ($g_DynamicDimensionCounter > 0) {
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillINVariables�","SOutput.".GetParameterIdentifier().".".GetParameterIdentifier()."_len = 0;"); 
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillINVariables�","SOutput.".GetParameterIdentifier().".".GetParameterIdentifier()."_val = NULL;"); 
        }
    }
    if (ParameterIsInput ()) {
        $Spaces = GetSpacesInFrontOfTemplateAtServerProcRPCMethodDefinition ("�FillINVariables�");
        ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillINVariables�","if (pSInput->".GetParameterIdentifier().".".GetParameterIdentifier()."_val != NULL)");
        ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillINVariables�","{");
        # Create first dimension of Array
        if ($g_DynamicDimensionCounter > 0) {
            $HelperLine = "";
            for ($ArrayIndex = 0; $ArrayIndex <= $g_DynamicDimensionCounter-2; $ArrayIndex++) {
                $HelperLine = $HelperLine."*";
            }
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillINVariables�",$Spaces."try");
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillINVariables�",$Spaces."{");
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillINVariables�",$Spaces.$Spaces."if ((".GetParameterIdentifier()."_val = new std::".GetParameterType()." ".$HelperLine." [pSInput->_".GetParameterIdentifier()."_len]) == NULL)"); 
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillINVariables�",$Spaces.$Spaces."{");
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillINVariables�",$Spaces.$Spaces.$Spaces."__usInternalError = 1;");
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillINVariables�",$Spaces.$Spaces.$Spaces."SOutput._operation_state = 3; // Memory error");
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillINVariables�",$Spaces.$Spaces.$Spaces."goto ".lc(GetProgramName()."_".GetFunctionIdentifier()."_1_svc")."_Return;");
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillINVariables�",$Spaces.$Spaces."}"); 
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillINVariables�",$Spaces."}"); 
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillINVariables�",$Spaces."catch(...)"); 
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillINVariables�",$Spaces."{");
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillINVariables�",$Spaces.$Spaces.GetParameterIdentifier()."_val = NULL;");
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillINVariables�",$Spaces.$Spaces."__usInternalError = 1;");
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillINVariables�",$Spaces.$Spaces."SOutput._operation_state = 3; // Memory error");
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillINVariables�",$Spaces.$Spaces."goto ".lc(GetProgramName()."_".GetFunctionIdentifier()."_1_svc")."_Return;");
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillINVariables�",$Spaces."}"); 
        }
        # Copy single array into multidim array
        if ($g_DynamicDimensionCounter > 0) {
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillINVariables�",$Spaces."pcCopyRunner = pSInput->".GetParameterIdentifier().".".GetParameterIdentifier()."_val;"); 
        }
        # Create opening part of for-loop
        $MultipleSpaces = "";
        for ($DimensionIndex = 0; $DimensionIndex < $g_DynamicDimensionCounter-1; $DimensionIndex++) {
            if ($DimensionIndex == 0) {
                $LengthExtension = "";
                $FollowingLengthExtension = "1";
            }
            else {
                $LengthExtension = $DimensionIndex;
                $FollowingLengthExtension = $DimensionIndex + 1;
            }
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillINVariables�",$Spaces.$MultipleSpaces."Index_".GetParameterIdentifier()."_len".$LengthExtension." = 0;"); 
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillINVariables�",$Spaces.$MultipleSpaces."Stop_".GetParameterIdentifier()."_len".$LengthExtension." = 0;"); 
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillINVariables�",$Spaces.$MultipleSpaces."Increase_".GetParameterIdentifier()."_len".$LengthExtension." = 1;"); 
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillINVariables�",$Spaces.$MultipleSpaces."for (Index_".GetParameterIdentifier()."_len".$LengthExtension." = Index_".GetParameterIdentifier()."_len".$LengthExtension."; (Index_".GetParameterIdentifier()."_len".$LengthExtension." < _".GetParameterIdentifier()."_len".$LengthExtension.") && (!Stop_".GetParameterIdentifier()."_len".$LengthExtension."); Increase_".GetParameterIdentifier()."_len".$LengthExtension."?Index_".GetParameterIdentifier()."_len".$LengthExtension."++:Index_".GetParameterIdentifier()."_len".$LengthExtension."--)"); 
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillINVariables�",$Spaces.$MultipleSpaces."{"); 
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillINVariables�",$Spaces.$MultipleSpaces.$Spaces."if (Increase_".GetParameterIdentifier()."_len)"); 
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillINVariables�",$Spaces.$MultipleSpaces.$Spaces."{"); 
            $HelperLine = "";
            for ($ArrayIndex = 0; $ArrayIndex <= $DimensionIndex; $ArrayIndex++) {
                if ($ArrayIndex == 0) {
                    $HelperLine = $HelperLine."[Index_".GetParameterIdentifier()."_len]";
                }
                else {
                    $HelperLine = $HelperLine."[Index_".GetParameterIdentifier()."_len".$ArrayIndex."]";
                }
            }
            $HelperLine = $HelperLine." = new std::".GetParameterType()." ";
            for ($ArrayIndex = ($g_DynamicDimensionCounter-1)-($DimensionIndex+1)-1; $ArrayIndex >= 0 ; $ArrayIndex--) {
                $HelperLine = $HelperLine."*";
            }
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillINVariables�",$Spaces.$MultipleSpaces.$Spaces.$Spaces."try");
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillINVariables�",$Spaces.$MultipleSpaces.$Spaces.$Spaces."{");
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillINVariables�",$Spaces.$MultipleSpaces.$Spaces.$Spaces.$Spaces."if ((".GetParameterIdentifier()."_val ".$HelperLine." [pSInput->_".GetParameterIdentifier()."_len".$FollowingLengthExtension."]) == NULL)"); 
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillINVariables�",$Spaces.$MultipleSpaces.$Spaces.$Spaces.$Spaces."{");
            for ($ArrayIndex = 0; $ArrayIndex <= $DimensionIndex; $ArrayIndex++) {
                if ($ArrayIndex == 0) {
                    ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillINVariables�",$Spaces.$MultipleSpaces.$Spaces.$Spaces.$Spaces.$Spaces."Increase_".GetParameterIdentifier()."_len = 0;");
                }
                else {
                    ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillINVariables�",$Spaces.$MultipleSpaces.$Spaces.$Spaces.$Spaces.$Spaces."Increase_".GetParameterIdentifier()."_len".$ArrayIndex." = 0;");
                }
            }
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillINVariables�",$Spaces.$MultipleSpaces.$Spaces.$Spaces.$Spaces.$Spaces."continue;"); 
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillINVariables�",$Spaces.$MultipleSpaces.$Spaces.$Spaces.$Spaces."}"); 
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillINVariables�",$Spaces.$MultipleSpaces.$Spaces.$Spaces."}"); 
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillINVariables�",$Spaces.$MultipleSpaces.$Spaces.$Spaces."catch(...)"); 
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillINVariables�",$Spaces.$MultipleSpaces.$Spaces.$Spaces."{");
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillINVariables�",$Spaces.$MultipleSpaces.$Spaces.$Spaces.$Spaces.GetParameterIdentifier()."_val = NULL;");
            for ($ArrayIndex = 0; $ArrayIndex <= $DimensionIndex; $ArrayIndex++) {
                if ($ArrayIndex == 0) {
                    ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillINVariables�",$Spaces.$MultipleSpaces.$Spaces.$Spaces.$Spaces."Increase_".GetParameterIdentifier()."_len = 0;");
                }
                else {
                    ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillINVariables�",$Spaces.$MultipleSpaces.$Spaces.$Spaces.$Spaces."Increase_".GetParameterIdentifier()."_len".$ArrayIndex." = 0;");
                }
            }
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillINVariables�",$Spaces.$MultipleSpaces.$Spaces.$Spaces.$Spaces."continue;"); 
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillINVariables�",$Spaces.$MultipleSpaces.$Spaces.$Spaces."}"); 
            if ($DimensionIndex == $g_DynamicDimensionCounter-2) {
                $HelperLine = "";
                for ($ArrayIndex = 0; $ArrayIndex <= $g_DynamicDimensionCounter-1; $ArrayIndex++) {
                    if ($ArrayIndex == 0) {
                        $HelperLine = $HelperLine."[Index_".GetParameterIdentifier()."_len]";
                    }
                    else {
                        $HelperLine = $HelperLine."[Index_".GetParameterIdentifier()."_len".$ArrayIndex."]";
                    }
                }
                ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillINVariables�",$Spaces.$MultipleSpaces.$Spaces.$Spaces."for (Index_".GetParameterIdentifier()."_len".$FollowingLengthExtension." = 0; Index_".GetParameterIdentifier()."_len".$FollowingLengthExtension." < pSInput->_".GetParameterIdentifier()."_len".$FollowingLengthExtension."; Index_".GetParameterIdentifier()."_len".$FollowingLengthExtension."++)"); 
                ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillINVariables�",$Spaces.$MultipleSpaces.$Spaces.$Spaces."{");
                $HelperLine = GetParameterIdentifier()."_val ".$HelperLine;
                $HelperLine = $HelperLine." = pcCopyRunner;";
                ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillINVariables�",$Spaces.$MultipleSpaces.$Spaces.$Spaces.$Spaces.$HelperLine); 
                ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillINVariables�",$Spaces.$MultipleSpaces.$Spaces.$Spaces.$Spaces."pcCopyRunner += strlen (pcCopyRunner)+1;"); 
                ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillINVariables�",$Spaces.$MultipleSpaces.$Spaces.$Spaces."}"); 
            }
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillINVariables�",$Spaces.$MultipleSpaces.$Spaces."}"); 
            $MultipleSpaces = $MultipleSpaces.$Spaces;
        }
        # Create closing part of for-loop
        $Spaces = GetSpacesInFrontOfTemplateAtServerProcRPCMethodDefinition ("�FillINVariables�");
        $MultipleSpaces = "";
        for ($DimensionIndex = $g_DynamicDimensionCounter-2; $DimensionIndex >= 0; $DimensionIndex--) {
            if ($DimensionIndex == 0) {
                $LengthExtension = "";
            }
            else {
                $LengthExtension = $DimensionIndex;
            }
            $MultipleSpaces = "";
            for ($SpacesIndex = 0; $SpacesIndex < $DimensionIndex; $SpacesIndex++) {
                $MultipleSpaces = $MultipleSpaces.$Spaces;
            }
            $HelperLine = "";
            for ($ArrayIndex = 0; $ArrayIndex <= $DimensionIndex; $ArrayIndex++) {
                if ($ArrayIndex == 0) {
                    $HelperLine = $HelperLine."[Index_".GetParameterIdentifier()."_len]";
                }
                else {
                    $HelperLine = $HelperLine."[Index_".GetParameterIdentifier()."_len".$ArrayIndex."]";
                }
            }
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillINVariables�",$Spaces.$MultipleSpaces.$Spaces."if (!Increase_".GetParameterIdentifier()."_len)");
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillINVariables�",$Spaces.$MultipleSpaces.$Spaces."{");
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillINVariables�",$Spaces.$MultipleSpaces.$Spaces.$Spaces."delete [] ".GetParameterIdentifier()."_val ".$HelperLine.";");
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillINVariables�",$Spaces.$MultipleSpaces.$Spaces.$Spaces."if (Increase_".GetParameterIdentifier()."_len".$LengthExtension." == 0 && Index_".GetParameterIdentifier()."_len".$LengthExtension." == 0)");
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillINVariables�",$Spaces.$MultipleSpaces.$Spaces.$Spaces.$Spaces."Stop_".GetParameterIdentifier()."_len".$LengthExtension." = 1;");
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillINVariables�",$Spaces.$MultipleSpaces.$Spaces."}");
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillINVariables�",$Spaces.$MultipleSpaces."}");
        }
        if ($g_DynamicDimensionCounter > 1) {
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillINVariables�",$Spaces."if (!Increase_".GetParameterIdentifier()."_len)"); 
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillINVariables�",$Spaces."{");
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillINVariables�",$Spaces.$Spaces."delete [] ".GetParameterIdentifier()."_val;");
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillINVariables�",$Spaces.$Spaces.GetParameterIdentifier()."_val = NULL;");
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillINVariables�",$Spaces.$Spaces."__usInternalError = 1;");
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillINVariables�",$Spaces.$Spaces."SOutput._operation_state = 3; // Memory error");
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillINVariables�",$Spaces.$Spaces."goto ".lc(GetProgramName()."_".GetFunctionIdentifier()."_1_svc")."_Return;");
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillINVariables�",$Spaces."}"); 
        }
        if ($g_DynamicDimensionCounter == 1) {
            $Spaces = GetSpacesInFrontOfTemplateAtServerProcRPCMethodDefinition ("�FillINVariables�");
            $LengthExtension = "";
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillINVariables�",$Spaces."for (Index_".GetParameterIdentifier()."_len".$LengthExtension." = 0; Index_".GetParameterIdentifier()."_len".$LengthExtension." < pSInput->_".GetParameterIdentifier()."_len".$LengthExtension."; Index_".GetParameterIdentifier()."_len".$LengthExtension."++)"); 
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillINVariables�",$Spaces."{");
            $HelperLine = "";
            for ($DimensionIndex = 0; $DimensionIndex < $g_DynamicDimensionCounter; $DimensionIndex++) {
                if ($DimensionIndex == 0) {
                    $LengthExtension = "";
                }
                else {
                    $LengthExtension = $DimensionIndex;
                }
                $HelperLine = $HelperLine."[Index_".GetParameterIdentifier()."_len".$LengthExtension."]";
            }
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillINVariables�",$Spaces.$Spaces.GetParameterIdentifier()."_val ".$HelperLine." = pcCopyRunner;");
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillINVariables�",$Spaces.$Spaces."pcCopyRunner += strlen(pcCopyRunner)+1;");
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillINVariables�",$Spaces."}"); 
        }
        ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillINVariables�","}");
    }
    # Call RPC ======================================================================================================================================
    # Create length parameters
    if ($g_DynamicDimensionCounter > 0) {
        if (ParameterIsOutput ()) {
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�Parameters�", GetParameterIdentifier()."_val");
        }
        else {
            $HelperLine = "";
            for ($DimensionIndex = 0; $DimensionIndex < $g_DynamicDimensionCounter; $DimensionIndex++) {
                $HelperLine = $HelperLine."*";
            }
#            ReplaceTemplateAtServerProcRPCMethodDefinition ("�Parameters�","(const std::".GetParameterType()." ".$HelperLine.") ".GetParameterIdentifier()."_val");
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�Parameters�",GetParameterIdentifier()."_val");
        }
    }
    for ($DimensionIndex = 0; $DimensionIndex < $g_DynamicDimensionCounter; $DimensionIndex++) {
        if ($DimensionIndex == 0) {
            $LengthExtension = "";
        }
        else {
            $LengthExtension = $DimensionIndex;
        }
        ReplaceTemplateAtServerProcRPCMethodDefinition ("�Parameters�",", _".GetParameterIdentifier()."_len".$LengthExtension);
    }
    # Fill return values ============================================================================================================================
    if (ParameterIsOutput ()) {
        $Spaces = GetSpacesInFrontOfTemplateAtServerProcRPCMethodDefinition ("�FillParameterReturn�");
        ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillParameterReturn�","if (".GetParameterIdentifier()."_val == NULL)");
        ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillParameterReturn�","{");
        for ($DimensionIndex = 0; $DimensionIndex < $g_DynamicDimensionCounter; $DimensionIndex++) {
            if ($DimensionIndex == 0) {
                $LengthExtension = "";
            }
            else {
                $LengthExtension = $DimensionIndex;
            }
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillParameterReturn�",$Spaces."SOutput._".GetParameterIdentifier()."_len".$LengthExtension." = 0;");
        }
        if ($g_DynamicDimensionCounter > 0) {
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillParameterReturn�",$Spaces."SOutput.".GetParameterIdentifier().".".GetParameterIdentifier()."_len = 0;");
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillParameterReturn�",$Spaces."SOutput.".GetParameterIdentifier().".".GetParameterIdentifier()."_val = NULL;"); 
        }
        ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillParameterReturn�","}");
        ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillParameterReturn�","else");
        ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillParameterReturn�","{");
        # Set input length variables
        for ($DimensionIndex = 0; $DimensionIndex < $g_DynamicDimensionCounter; $DimensionIndex++) {
            if ($DimensionIndex == 0) {
                $LengthExtension = "";
            }
            else {
                $LengthExtension = $DimensionIndex;
            }
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillParameterReturn�",$Spaces."SOutput._".GetParameterIdentifier()."_len".$LengthExtension." = _".GetParameterIdentifier()."_len".$LengthExtension.";");
        }
        $HelperLine = "";
        for ($DimensionIndex = 1; $DimensionIndex < $g_DynamicDimensionCounter; $DimensionIndex++) {
            if ($DimensionIndex == 0) {
                $LengthExtension = "";
            }
            else {
                $LengthExtension = $DimensionIndex;
            }
            $HelperLine = $HelperLine." * SOutput._".GetParameterIdentifier()."_len".$LengthExtension;
        }
        if ($g_DynamicDimensionCounter > 0) {
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillParameterReturn�",$Spaces."SOutput.".GetParameterIdentifier().".".GetParameterIdentifier()."_len = 0;");
            $Spaces = GetSpacesInFrontOfTemplateAtServerProcRPCMethodDefinition ("�FillParameterReturn�");
            $MultipleSpaces = "";
            $HelperLine = "";
            for ($DimensionIndex = 0; $DimensionIndex < $g_DynamicDimensionCounter; $DimensionIndex++) {
                if ($DimensionIndex == 0) {
                    $LengthExtension = "";
                }
                else {
                    $LengthExtension = $DimensionIndex;
                }
                ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillParameterReturn�",$Spaces.$MultipleSpaces."for (Index_".GetParameterIdentifier()."_len".$LengthExtension." = 0; Index_".GetParameterIdentifier()."_len".$LengthExtension." < _".GetParameterIdentifier()."_len".$LengthExtension."; Index_".GetParameterIdentifier()."_len".$LengthExtension."++)"); 
                $MultipleSpaces = $MultipleSpaces.$Spaces;
                $HelperLine = $HelperLine."[Index_".GetParameterIdentifier()."_len".$LengthExtension."]";
            }
            if ($g_DynamicDimensionCounter > 0) {
                ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillParameterReturn�",$Spaces.$MultipleSpaces."SOutput.".GetParameterIdentifier().".".GetParameterIdentifier()."_len += ".GetParameterIdentifier()."_val ".$HelperLine.".length()+1;"); 
            }
        }
        # Check maximum of dynamic parameters
        $Spaces = GetSpacesInFrontOfTemplateAtServerProcRPCMethodDefinition ("�FillParameterReturn�");
        if ($g_DynamicDimensionCounter > 0) {
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillParameterReturn�",$Spaces."if (ulGetNextDynVarIndex() == MAXDYNVARIABLES)");
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillParameterReturn�",$Spaces."{");
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillParameterReturn�",$Spaces.$Spaces."__usInternalError = 1;");
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillParameterReturn�",$Spaces.$Spaces."SOutput._operation_state = 4; // Too many parameter");
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillParameterReturn�",$Spaces.$Spaces."goto ".lc(GetProgramName()."_".GetFunctionIdentifier()."_1_svc")."_Return;");
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillParameterReturn�",$Spaces."}");
        }
        # Allocate single array
        $Spaces = GetSpacesInFrontOfTemplateAtServerProcRPCMethodDefinition ("�FillParameterReturn�");
        if ($g_DynamicDimensionCounter > 0) {
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillParameterReturn�",$Spaces."if ((SOutput.".GetParameterIdentifier().".".GetParameterIdentifier()."_val = (char * ) malloc (sizeof(char)*SOutput.".GetParameterIdentifier().".".GetParameterIdentifier()."_len)) == NULL)");
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillParameterReturn�",$Spaces."{");
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillParameterReturn�",$Spaces.$Spaces."__usInternalError = 1;");
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillParameterReturn�",$Spaces.$Spaces."SOutput._operation_state = 3; // Memory error");
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillParameterReturn�",$Spaces.$Spaces."SOutput.".GetParameterIdentifier().".".GetParameterIdentifier()."_len = 0;"); 
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillParameterReturn�",$Spaces.$Spaces."goto ".lc(GetProgramName()."_".GetFunctionIdentifier()."_1_svc")."_Return;");
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillParameterReturn�",$Spaces."}");
        }
        if ($g_DynamicDimensionCounter > 0) {
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillParameterReturn�",$Spaces."g_pvDynVarMemory[ulGetNextDynVarIndex()] = SOutput.".GetParameterIdentifier().".".GetParameterIdentifier()."_val;");
        }
        # Copy multiple array into single array
        $Spaces = GetSpacesInFrontOfTemplateAtServerProcRPCMethodDefinition ("�FillParameterReturn�");
        $MultipleSpaces = "";
        if ($g_DynamicDimensionCounter > 0) {
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillParameterReturn�",$Spaces."pcCopyRunner = SOutput.".GetParameterIdentifier().".".GetParameterIdentifier()."_val;");
        }
    }
    # Delete multidim array
    if (ParameterIsOutput ()) {
        $Spaces = GetSpacesInFrontOfTemplateAtServerProcRPCMethodDefinition ("�FillParameterReturn�");
        # Create opening part of for-loop
        $MultipleSpaces = "";
        for ($DimensionIndex = 0; $DimensionIndex < $g_DynamicDimensionCounter; $DimensionIndex++) {
            if ($DimensionIndex == 0) {
                $LengthExtension = "";
            }
            else {
                $LengthExtension = $DimensionIndex;
            }
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillParameterReturn�",$Spaces.$MultipleSpaces."for (Index_".GetParameterIdentifier()."_len".$LengthExtension." = 0; Index_".GetParameterIdentifier()."_len".$LengthExtension." < _".GetParameterIdentifier()."_len".$LengthExtension."; Index_".GetParameterIdentifier()."_len".$LengthExtension."++)"); 
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillParameterReturn�",$Spaces.$MultipleSpaces."{"); 
            $MultipleSpaces = $MultipleSpaces.$Spaces;
        }
        # Create closing part of for-loop
        for ($DimensionIndex = $g_DynamicDimensionCounter-1; $DimensionIndex >= 0; $DimensionIndex--) {
            if ($DimensionIndex == 0) {
                $LengthExtension = "";
            }
            else {
                $LengthExtension = $DimensionIndex;
            }
            $MultipleSpaces = "";
            for ($SpacesIndex = 0; $SpacesIndex < $DimensionIndex; $SpacesIndex++) {
                $MultipleSpaces = $MultipleSpaces.$Spaces;
            }
            $HelperLine = "";
            for ($ArrayIndex = 0; $ArrayIndex <= $DimensionIndex; $ArrayIndex++) {
                if ($ArrayIndex == 0) {
                    $HelperLine = $HelperLine."[Index_".GetParameterIdentifier()."_len]";
                }
                else {
                    $HelperLine = $HelperLine."[Index_".GetParameterIdentifier()."_len".$ArrayIndex."]";
                }
            }
            if ($DimensionIndex == $g_DynamicDimensionCounter-1){
                ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillParameterReturn�",$Spaces.$MultipleSpaces.$Spaces."strncpy (pcCopyRunner, ".GetParameterIdentifier()."_val ".$HelperLine.".c_str(), ".GetParameterIdentifier()."_val ".$HelperLine.".length());");
                ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillParameterReturn�",$Spaces.$MultipleSpaces.$Spaces."pcCopyRunner += ".GetParameterIdentifier()."_val ".$HelperLine.".length();");
                ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillParameterReturn�",$Spaces.$MultipleSpaces.$Spaces."*pcCopyRunner = '\\0';");
                ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillParameterReturn�",$Spaces.$MultipleSpaces.$Spaces."pcCopyRunner++;");
            }
            else {
                ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillParameterReturn�",$Spaces.$MultipleSpaces.$Spaces."delete [] ".GetParameterIdentifier()."_val ".$HelperLine.";"); 
            }
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillParameterReturn�",$Spaces.$MultipleSpaces."}"); 
        }
        # Create final delete of Array
        if ($g_DynamicDimensionCounter > 0) {
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillParameterReturn�",$Spaces."delete [] ".GetParameterIdentifier()."_val;"); 
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillParameterReturn�",$Spaces.GetParameterIdentifier()."_val = NULL;"); 
        }
        ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillParameterReturn�","}");
    } 
    # Final cleanup
    if (ParameterIsOutput ()) {
        $Spaces = GetSpacesInFrontOfTemplateAtServerProcRPCMethodDefinition ("�FinalCleanUp�");
        ReplaceTemplateAtServerProcRPCMethodDefinition ("�FinalCleanUp�","if (".GetParameterIdentifier()."_val != NULL)"); 
        ReplaceTemplateAtServerProcRPCMethodDefinition ("�FinalCleanUp�","{"); 
        # Create opening part of for-loop
        $MultipleSpaces = "";
        for ($DimensionIndex = 0; $DimensionIndex < $g_DynamicDimensionCounter-1; $DimensionIndex++) {
            if ($DimensionIndex == 0) {
                $LengthExtension = "";
            }
            else {
                $LengthExtension = $DimensionIndex;
            }
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�FinalCleanUp�",$MultipleSpaces.$Spaces."for (Index_".GetParameterIdentifier()."_len".$LengthExtension." = 0; Index_".GetParameterIdentifier()."_len".$LengthExtension." < _".GetParameterIdentifier()."_len".$LengthExtension."; Index_".GetParameterIdentifier()."_len".$LengthExtension."++)"); 
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�FinalCleanUp�",$MultipleSpaces.$Spaces."{"); 
            $MultipleSpaces = $MultipleSpaces.$Spaces;
        }
        # Create closing part of for-loop
        for ($DimensionIndex = $g_DynamicDimensionCounter-2; $DimensionIndex >= 0; $DimensionIndex--) {
            if ($DimensionIndex == 0) {
                $LengthExtension = "";
            }
            else {
                $LengthExtension = $DimensionIndex;
            }
            $MultipleSpaces = "";
            for ($SpacesIndex = 0; $SpacesIndex < $DimensionIndex; $SpacesIndex++) {
                $MultipleSpaces = $MultipleSpaces.$Spaces;
            }
            $HelperLine = "";
            for ($ArrayIndex = 0; $ArrayIndex <= $DimensionIndex; $ArrayIndex++) {
                if ($ArrayIndex == 0) {
                    $HelperLine = $HelperLine."[Index_".GetParameterIdentifier()."_len]";
                }
                else {
                    $HelperLine = $HelperLine."[Index_".GetParameterIdentifier()."_len".$ArrayIndex."]";
                }
            }            
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�FinalCleanUp�",$MultipleSpaces.$Spaces.$Spaces."delete [] ".GetParameterIdentifier()."_val ".$HelperLine.";"); 
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�FinalCleanUp�",$MultipleSpaces.$Spaces."}"); 
        }
        # Create final delete of Array
        if ($g_DynamicDimensionCounter > 0) {
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�FinalCleanUp�",$Spaces."delete [] ".GetParameterIdentifier()."_val;"); 
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�FinalCleanUp�",$Spaces.GetParameterIdentifier()."_val = NULL;"); 
        }
        ReplaceTemplateAtServerProcRPCMethodDefinition ("�FinalCleanUp�","}"); 
        if (ParameterIsOutput ()) {
            $Spaces = GetSpacesInFrontOfTemplateAtServerProcRPCMethodDefinition ("�FinalCleanUp�");
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�ErrorDelete�","if (SOutput.".GetParameterIdentifier().".".GetParameterIdentifier()."_val != NULL)"); 
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�ErrorDelete�","{"); 
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�ErrorDelete�",$Spaces."free (SOutput.".GetParameterIdentifier().".".GetParameterIdentifier()."_val);"); 
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�ErrorDelete�",$Spaces."SOutput.".GetParameterIdentifier().".".GetParameterIdentifier()."_val = NULL;"); 
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�ErrorDelete�",$Spaces."SOutput.".GetParameterIdentifier().".".GetParameterIdentifier()."_len = 0;"); 
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�ErrorDelete�","}"); 
            # Set input length variables
            for ($DimensionIndex = 0; $DimensionIndex < $g_DynamicDimensionCounter; $DimensionIndex++) {
                if ($DimensionIndex == 0) {
                    $LengthExtension = "";
                }
                else {
                    $LengthExtension = $DimensionIndex;
                }
                ReplaceTemplateAtServerProcRPCMethodDefinition ("�ErrorDelete�","SOutput._".GetParameterIdentifier()."_len".$LengthExtension." = 0;");
            }
        }
    }
    if (ParameterIsInput ()) {
        if ($g_DynamicDimensionCounter > 0) {
            # Free SOutput
            $Spaces = GetSpacesInFrontOfTemplateAtServerProcRPCMethodDefinition ("�FinalCleanUp�");
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�FinalCleanUp�","if (pSInput->".GetParameterIdentifier().".".GetParameterIdentifier()."_val != NULL)"); 
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�FinalCleanUp�","{"); 
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�FinalCleanUp�",$Spaces."free (pSInput->".GetParameterIdentifier().".".GetParameterIdentifier()."_val);"); 
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�FinalCleanUp�",$Spaces."pSInput->".GetParameterIdentifier().".".GetParameterIdentifier()."_val = NULL;"); 
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�FinalCleanUp�","}"); 
        }
    }
}

# >--------------------------------------------------------------------------<
# > Subroutine: AddToRPCSERVERCPP_DYNAMICARRAY                               <
# >             Add dynamic handling to server part of RPC                   <
# > Parameter:  -                                                            <
# > Return:     -                                                            <
# > Author:     A. Neidhardt                                                 <
# > Date:       04.05.2007                                                   <
# > Revision:   -                                                            <
# > Info:       -                                                            <
# >--------------------------------------------------------------------------<
sub AddToRPCSERVERCPP_DYNAMICARRAY {
    my $DimensionIndex = 0;    # Index to run through dimensions
    my $LengthExtension = "";  # Variable to create length variable extension number

    # Create length parameters ======================================================================================================================
    for ($DimensionIndex = 0; $DimensionIndex < $g_DynamicDimensionCounter; $DimensionIndex++) {
        if ($DimensionIndex == 0) {
            $LengthExtension = "";
        }
        else {
            $LengthExtension = $DimensionIndex;
        }
        if (ParameterIsOutput ()){
            ReplaceTemplateAtServerClassRPCMethodDefinition ("�Parameters�",", unsigned int & _".GetParameterIdentifier()."_len".$LengthExtension);
        }
        else {
            ReplaceTemplateAtServerClassRPCMethodDefinition ("�Parameters�",", unsigned int _".GetParameterIdentifier()."_len".$LengthExtension);
        }
    }
}

# >--------------------------------------------------------------------------<
# > Subroutine: AddToRPCSERVERCPP_DYNAMICSTRINGARRAY                         <
# >             Add dynamic handling to server part of RPC for string arrays <
# > Parameter:  -                                                            <
# > Return:     -                                                            <
# > Author:     A. Neidhardt                                                 <
# > Date:       04.05.2007                                                   <
# > Revision:   -                                                            <
# > Info:       -                                                            <
# >--------------------------------------------------------------------------<
sub AddToRPCSERVERCPP_DYNAMICSTRINGARRAY {
    my $DimensionIndex = 0;    # Index to run through dimensions
    my $LengthExtension = "";  # Variable to create length variable extension number

    # Create length parameters ======================================================================================================================
    for ($DimensionIndex = 0; $DimensionIndex < $g_DynamicDimensionCounter; $DimensionIndex++) {
        if ($DimensionIndex == 0) {
            $LengthExtension = "";
        }
        else {
            $LengthExtension = $DimensionIndex;
        }
        if (ParameterIsOutput ()){
            ReplaceTemplateAtServerClassRPCMethodDefinition ("�Parameters�",", unsigned int & _".GetParameterIdentifier()."_len".$LengthExtension);
        }
        else {
            ReplaceTemplateAtServerClassRPCMethodDefinition ("�Parameters�",", unsigned int _".GetParameterIdentifier()."_len".$LengthExtension);
        }
    }
}

# >--------------------------------------------------------------------------<
# > Subroutine: PrintINTERFACEHPPFileUsingTemplate                           <
# >             Prints the created abstract interface class block into       <
# >             specific hpp-file                                            <
# > Parameter:  $IDLFilepath -> Filepath to IDL-file                         <
# > Return:     <- Errorcode (0 = ok, 1 = error)                             <
# > Author:     A. Neidhardt                                                 <
# > Date:       09.02.2007                                                   <
# > Revision:   -                                                            <
# > Info:       -                                                            <
# >--------------------------------------------------------------------------<
sub PrintINTERFACEHPPFileUsingTemplate {
    my ($IDLFilepath)=@_;
    my $InterfaceFilenameWithoutExt;
    my $InterfaceFilename;
    my $InterfaceClassname;
    
    # Check if the abstract interface is already created, because this is needed for client interface
    if (!defined ($g_RPCABSTRH_DEFINITION_BLOCK) ||
        length ($g_RPCABSTRH_DEFINITION_BLOCK) == 0) {
        $g_RPCABSTRH_DEFINITION_BLOCK = "";
        #return 1;
    }

    # Get template
    $g_RPCABSTRH_DEFINITION = $g_InterfaceClassDeclarationTemplate;
    
    # Get interface filename from idl filepath
    if ($IDLFilepath =~ /.*\/\w+\.\w+$/) {
        ($InterfaceFilenameWithoutExt) = ($IDLFilepath =~ /.*\/(\w+)\.\w+$/);
        ($InterfaceFilename) = ($IDLFilepath =~ /(.*\/\w+)\.\w+$/);
    }
    elsif ($IDLFilepath =~ /^\w+\.\w+$/) {
        ($InterfaceFilenameWithoutExt) = ($IDLFilepath =~ /^(\w+)\.\w+$/);
        ($InterfaceFilename) = ($IDLFilepath =~ /^(\w+)\.\w+$/);
    }
    else {
        return 1;
    }
    $InterfaceFilename = $InterfaceFilename."_interface.hpp";

    # Get name of interface
    $InterfaceClassname = GetClassIdentifier ();
    if (!defined ($InterfaceClassname) ||
        length ($InterfaceClassname) == 0) {
        return 1;
    }
    
    # Make unpleasant text parts more pleasant
    $g_RPCABSTRH_DEFINITION_BLOCK =~ s/\(\s+/(/g;
    $g_RPCABSTRH_DEFINITION_BLOCK =~ s/\s+\)/)/g;
    # Delete all empty lines
    $g_RPCABSTRH_DEFINITION_BLOCK =~ s/^\n//g;
    # Standardize function tabulator set
    $g_RPCABSTRH_DEFINITION_BLOCK =~ s/^\s+virtual/    virtual/g;

    # Replace templates at template definition for client interface declaration
    # Replace �ModulFilename�
    $g_RPCABSTRH_DEFINITION =~ s/�ModulFilename�/$InterfaceFilename/g;
    # Replace �InterfaceFilenameWithoutExt�
    $g_RPCABSTRH_DEFINITION =~ s/�InterfaceFilenameWithoutExt�/$InterfaceFilenameWithoutExt/g;
    # Replace �Interface�
    $g_RPCABSTRH_DEFINITION =~ s/�Interface�/$InterfaceClassname/g;
    # Replace �AbstractInterfaceFunctionDeclarations�
    $g_RPCABSTRH_DEFINITION =~ s/�AbstractInterfaceFunctionDeclarations�/$g_RPCABSTRH_DEFINITION_BLOCK/g;
    
    # Save old file as backup
    if (-r $InterfaceFilename) {
        rename ($InterfaceFilename, $InterfaceFilename."~");
    }

    # Open file (old style open, so that older perl versions can handle it)
    open (ABSTRHFileHandle,"> $InterfaceFilename") or return 1;
    
    if (length ($g_RPCABSTRH_DEFINITION) > 0) {
        print ABSTRHFileHandle $g_RPCABSTRH_DEFINITION;
    }
    else {
        return 1;
    }
    
    close (ABSTRHFileHandle);

    return 0;
}

# >--------------------------------------------------------------------------<
# > Subroutine: PrintClientHPPFileUsingTemplate                              <
# >             Prints the created client hpp definition into specific       <
# >             client hpp-file                                              <
# > Parameter:  $IDLFilepath -> Filepath to IDL-file                         <
# > Return:     <- Errorcode (0 = ok, 1 = error)                             <
# > Author:     A. Neidhardt                                                 <
# > Date:       13.02.2007                                                   <
# > Revision:   -                                                            <
# > Info:       -                                                            <
# >--------------------------------------------------------------------------<
sub PrintClientHPPFileUsingTemplate {
    my ($IDLFilepath)=@_;
    my $InterfaceFilenameWithoutExt;
    my $InterfaceFilename;
    my $DynamicClientHPPFileContent;
    my $InterfaceClassname;
    my $ClientClassDeclaration = $g_ClientClassDeclarationTemplate;
    my @LinesOfInterfaceTemplate;
    my $LineIndex;
    my $LinesAreValid = 0;
    
    # Check if the abstract interface is already created, because this is needed for client interface
    if (!defined ($g_RPCABSTRH_DEFINITION) ||
        length ($g_RPCABSTRH_DEFINITION) == 0) {
        return 1;
    }
   
    # Get interface filename from idl filepath
    if ($IDLFilepath =~ /.*\/\w+\.\w+$/) {
        ($InterfaceFilenameWithoutExt) = ($IDLFilepath =~ /.*\/(\w+)\.\w+$/);
        ($InterfaceFilename) = ($IDLFilepath =~ /(.*\/\w+)\.\w+$/);
    }
    elsif ($IDLFilepath =~ /^\w+\.\w+$/) {
        ($InterfaceFilenameWithoutExt) = ($IDLFilepath =~ /^(\w+)\.\w+$/);
        ($InterfaceFilename) = ($IDLFilepath =~ /^(\w+)\.\w+$/);
    }
    else {
        return 1;
    }
    $InterfaceFilename = $InterfaceFilename."_client.hpp";
    
    # Get name of interface
    $DynamicClientHPPFileContent = $g_RPCABSTRH_DEFINITION;
    $InterfaceClassname = GetClassIdentifier();
    if (!defined ($InterfaceClassname) ||
        length ($InterfaceClassname) == 0) {
        return 1;
    }

    # Create client function declarations by using existing abstract interface set (= �InterfaceFunctionDeclarations�)
    if (length ($DynamicClientHPPFileContent) > 0) {
        # Delete everything but not interface class
        @LinesOfInterfaceTemplate = split (/\n/,$DynamicClientHPPFileContent);
        $DynamicClientHPPFileContent = "";
        $LinesAreValid = 0;
        for ($LineIndex = 0; $LineIndex <= $#LinesOfInterfaceTemplate; $LineIndex++) {
            if ($LinesOfInterfaceTemplate[$LineIndex] =~ /^\s*class\s+$InterfaceClassname/ &&
                $LinesOfInterfaceTemplate[$LineIndex] !~ /^\s*class\s+$InterfaceClassname[_]/) {
                $LinesAreValid = 1;
            }
            if ($LinesOfInterfaceTemplate[$LineIndex] =~ /^\s*}/) {
                $LinesAreValid = 0;
            }
            if ($LinesAreValid == 1) {
                if (!($LinesOfInterfaceTemplate[$LineIndex] =~ /~/)) {
                    $DynamicClientHPPFileContent = $DynamicClientHPPFileContent.$LinesOfInterfaceTemplate[$LineIndex]."\n";
                }
            }
        }
        $DynamicClientHPPFileContent = $DynamicClientHPPFileContent."};\n";
        if (!defined ($DynamicClientHPPFileContent) ||
            length ($DynamicClientHPPFileContent) == 0) {
            return 1;
        }
        # Make unpleasant text parts more pleasant
        $DynamicClientHPPFileContent =~ s/\(\s+/(/g;
        $DynamicClientHPPFileContent =~ s/\s+\)/)/g;
        # Delete the abstract = 0;
        $DynamicClientHPPFileContent =~ s/ = 0;/ throw (_interface_throw);/g;
        # Delete all pre-processor lines
        $DynamicClientHPPFileContent =~ s/#\w+.*\n//g;
        # Extract just methods
        $DynamicClientHPPFileContent =~ s/\s*class\s+.*\n\s*{\s*\n\s*public:\s*\n//g;
        $DynamicClientHPPFileContent =~ s/\s*};\s*\n//g;
        # Delete all empty lines
        $DynamicClientHPPFileContent =~ s/^\n//g;
        # Standardize function tabulator set
        $DynamicClientHPPFileContent =~ s/^\s*virtual/    virtual/g;
    }
    $DynamicClientHPPFileContent =~ s/�Interface�/$InterfaceClassname/g;

    # Replace templates at template definition for client interface declaration
    # Replace �ModulFilename�
    $ClientClassDeclaration =~ s/�ModulFilename�/$InterfaceFilename/g;
    # Replace �InterfaceFilenameWithoutExt�
    $ClientClassDeclaration =~ s/�InterfaceFilenameWithoutExt�/$InterfaceFilenameWithoutExt/g;
    # Replace �Interface�
    $ClientClassDeclaration =~ s/�Interface�/$InterfaceClassname/g;
    # Replace �InterfaceFunctionDeclarations�
    $ClientClassDeclaration =~ s/�InterfaceFunctionDeclarations�/$DynamicClientHPPFileContent/g;
   
    # Save old file as backup
    if (-r $InterfaceFilename) {
        rename ($InterfaceFilename, $InterfaceFilename."~");
    }

    # Open file (old style open, so that older perl versions can handle it)
    open (ABSTRHFileHandle,"> $InterfaceFilename") or return 1;
    
    if (length ($ClientClassDeclaration) > 0) {
        print ABSTRHFileHandle $ClientClassDeclaration;
    }
    else {
        return 1;
    }
    
    close (ABSTRHFileHandle);
    
    return 0;
}

# >--------------------------------------------------------------------------<
# > Subroutine: PrintClientCPPFileUsingTemplate                              <
# >             Prints the created client cpp definition into specific       <
# >             client cpp-file                                              <
# > Parameter:  $IDLFilepath -> Filepath to IDL-file                         <
# >             $ClientRequestTimeoutSec -> Seconds of request timeout or 0  <
# >             $ClientRequestTimeoutUSec -> u-seconds of request timeout or 0<
# >             $ClientRetryTimeoutSec -> Seconds of retry timeout or 0      <
# >             $ClientRetryTimeoutUSec -> u-seconds of retry timeout or 0   <
# >             $TransportProtocol -> Transportprotocol (0 = UDP, 1 = TCP)   <
# > Return:     <- Errorcode (0 = ok, 1 = error)                             <
# > Author:     A. Neidhardt                                                 <
# > Date:       13.02.2007                                                   <
# > Revision:   -                                                            <
# > Info:       -                                                            <
# >--------------------------------------------------------------------------<
sub PrintClientCPPFileUsingTemplate {
    my ($IDLFilepath,$ClientRequestTimeoutSec,$ClientRequestTimeoutUSec,$ClientRetryTimeoutSec,$ClientRetryTimeoutUSec,$TransportProtocol,$FixedUDPPort,$FixedTCPPort)=@_;
    my $InterfaceFilenameWithoutExt;
    my $InterfaceFilename;
    my $DynamicClientCPPFileContent;
    my $InterfaceClassname;
    my $InterfaceClassnameLC;
    my $ClientClassDefinition = $g_ClientClassDefinitionTemplate;
    my $InterfaceVersion = GetInterfaceVersion();
    my $RPCProgramname;
    my $RPCVersionname;
    
    # Check if the abstract interface is already created, because this is needed for client interface
    if (!defined ($g_RPCABSTRH_DEFINITION) ||
        length ($g_RPCABSTRH_DEFINITION) == 0) {
        return 1;
    }
    if (!defined ($g_RPCX_PROGRAM_BLOCK) ||
        length ($g_RPCX_PROGRAM_BLOCK) == 0) {
        return 1;
    }
    
    # Get RPC-information
    ($RPCProgramname) = ($g_RPCX_PROGRAM_BLOCK =~ /program\s+(\w+)/);
    ($RPCVersionname) = ($g_RPCX_PROGRAM_BLOCK =~ /version\s+(\w+)/);
    if (!defined ($RPCProgramname) ||
        !defined ($RPCVersionname)) {
        return 1;
    }
    
    # Get interface filename from idl filepath
    if ($IDLFilepath =~ /.*\/\w+\.\w+$/) {
        ($InterfaceFilenameWithoutExt) = ($IDLFilepath =~ /.*\/(\w+)\.\w+$/);
        ($InterfaceFilename) = ($IDLFilepath =~ /(.*\/\w+)\.\w+$/);
    }
    elsif ($IDLFilepath =~ /^\w+\.\w+$/) {
        ($InterfaceFilenameWithoutExt) = ($IDLFilepath =~ /^(\w+)\.\w+$/);
        ($InterfaceFilename) = ($IDLFilepath =~ /^(\w+)\.\w+$/);
    }
    else {
        return 1;
    }
    $InterfaceFilename = $InterfaceFilename."_client.cpp";
    
    # Get name of interface
    $InterfaceClassname = GetClassIdentifier();
    $InterfaceClassnameLC = lc(GetClassIdentifier());
    if (!defined ($InterfaceClassname) ||
        length ($InterfaceClassname) == 0) {
        return 1;
    }
        
    # Replace templates at template definition for client interface declaration
    # Replace �ModulFilename�
    $ClientClassDefinition =~ s/�ModulFilename�/$InterfaceFilename/g;
    # Replace �InterfaceFilenameWithoutExt�
    $ClientClassDefinition =~ s/�InterfaceFilenameWithoutExt�/$InterfaceFilenameWithoutExt/g;
    # Replace �InterfaceLC� = lower case
    $ClientClassDefinition =~ s/�InterfaceLC�/$InterfaceClassnameLC/g;
    # Replace �Interface�
    $ClientClassDefinition =~ s/�Interface�/$InterfaceClassname/g;
    # Replace �InterfaceVersion�
    $ClientClassDefinition =~ s/�InterfaceVersion�/$InterfaceVersion/g;
    # Replace �RPCPROGRAM�
    $ClientClassDefinition =~ s/�RPCPROGRAM�/$RPCProgramname/g;
    # Replace �RPCPVERSION�
    $ClientClassDefinition =~ s/�RPCPVERSION�/$RPCVersionname/g;
    # Replace �InterfaceFunctionDefinitions�
    $ClientClassDefinition =~ s/�InterfaceFunctionDefinitions�//g;
    # Replace �RequestTimeoutSec�
    $ClientClassDefinition =~ s/�RequestTimeoutSec�/$ClientRequestTimeoutSec/g;
    # Replace �RequestTimeoutUSec�
    $ClientClassDefinition =~ s/�RequestTimeoutUSec�/$ClientRequestTimeoutUSec/g;
    # Replace �RetryTimeoutSec�
    $ClientClassDefinition =~ s/�RetryTimeoutSec�/$ClientRetryTimeoutSec/g;
    # Replace �RetryTimeoutUSec�
    $ClientClassDefinition =~ s/�RetryTimeoutUSec�/$ClientRetryTimeoutUSec/g;
    # Replace �TransportProtocol�
    if ($TransportProtocol) {
        $ClientClassDefinition =~ s/�TransportProtocol�/1/g;
    }
    else {
        $ClientClassDefinition =~ s/�TransportProtocol�/0/g;
    }
    # Replace �TCPPort� and �UDPPort�
    $ClientClassDefinition =~ s/�TCPPort�/$FixedTCPPort/g;
    $ClientClassDefinition =~ s/�UDPPort�/$FixedUDPPort/g;
   
    # Save old file as backup
    if (-r $InterfaceFilename) {
        rename ($InterfaceFilename, $InterfaceFilename."~");
    }

    # Open file (old style open, so that older perl versions can handle it)
    open (ABSTRHFileHandle,"> $InterfaceFilename") or return 1;
    
    if (length ($ClientClassDefinition) > 0) {
        print ABSTRHFileHandle $ClientClassDefinition;
    }
    else {
        return 1;
    }
    
    close (ABSTRHFileHandle);
    
    return 0;
}

# >--------------------------------------------------------------------------<
# > Subroutine: PrintServerHPPFileUsingTemplate                              <
# >             Prints the created server hpp definition into specific       <
# >             server hpp-file                                              <
# > Parameter:  $IDLFilepath -> Filepath to IDL-file                         <
# > Return:     <- Errorcode (0 = ok, 1 = error)                             <
# > Author:     A. Neidhardt                                                 <
# > Date:       13.02.2007                                                   <
# > Revision:   -                                                            <
# > Info:       -                                                            <
# >--------------------------------------------------------------------------<
sub PrintServerHPPFileUsingTemplate {
    my ($IDLFilepath)=@_;
    my $InterfaceFilenameWithoutExt;
    my $InterfaceFilename;
    my $DynamicServerHPPFileContent;
    my $InterfaceClassname;
    my $ServerClassDeclaration = $g_ServerClassDeclarationTemplate;
    my @LinesOfInterfaceTemplate;
    my $LineIndex;
    my $LinesAreValid = 0;
    my $AlreadySetUserDefines;
    my $ReadFileline;
    
    # Check if the abstract interface is already created, because this is needed for server interface
    if (!defined ($g_RPCABSTRH_DEFINITION) ||
        length ($g_RPCABSTRH_DEFINITION) == 0) {
        return 1;
    }
   
    # Get interface filename from idl filepath
    if ($IDLFilepath =~ /.*\/\w+\.\w+$/) {
        ($InterfaceFilenameWithoutExt) = ($IDLFilepath =~ /.*\/(\w+)\.\w+$/);
        ($InterfaceFilename) = ($IDLFilepath =~ /(.*\/\w+)\.\w+$/);
    }
    elsif ($IDLFilepath =~ /^\w+\.\w+$/) {
        ($InterfaceFilenameWithoutExt) = ($IDLFilepath =~ /^(\w+)\.\w+$/);
        ($InterfaceFilename) = ($IDLFilepath =~ /^(\w+)\.\w+$/);
    }
    else {
        return 1;
    }
    $InterfaceFilename = $InterfaceFilename."_server.hpp";
    
    # Get name of interface
    $DynamicServerHPPFileContent = $g_RPCABSTRH_DEFINITION;
    $InterfaceClassname = GetClassIdentifier();
    if (!defined ($InterfaceClassname) ||
        length ($InterfaceClassname) == 0) {
        return 1;
    }

    # Create server function declarations by using existing abstract interface set (= �InterfaceFunctionDeclarations�)
    if (length ($DynamicServerHPPFileContent) > 0) {
        # Delete everything but not interface class
        @LinesOfInterfaceTemplate = split (/\n/,$DynamicServerHPPFileContent);
        $DynamicServerHPPFileContent = "";
        $LinesAreValid = 0;
        for ($LineIndex = 0; $LineIndex <= $#LinesOfInterfaceTemplate; $LineIndex++) {
            if ($LinesOfInterfaceTemplate[$LineIndex] =~ /^\s*class\s+$InterfaceClassname/ &&
                $LinesOfInterfaceTemplate[$LineIndex] !~ /^\s*class\s+$InterfaceClassname[_]/) {
                $LinesAreValid = 1;
            }
            if ($LinesOfInterfaceTemplate[$LineIndex] =~ /^\s*}/) {
                $LinesAreValid = 0;
            }
            if ($LinesAreValid == 1) {
                if (!($LinesOfInterfaceTemplate[$LineIndex] =~ /~/)) {
                    $DynamicServerHPPFileContent = $DynamicServerHPPFileContent.$LinesOfInterfaceTemplate[$LineIndex]."\n";
                }
            }
        }
        $DynamicServerHPPFileContent = $DynamicServerHPPFileContent."};\n";
        if (!defined ($DynamicServerHPPFileContent) ||
            length ($DynamicServerHPPFileContent) == 0) {
            return 1;
        }
        # Make unpleasant text parts more pleasant
        $DynamicServerHPPFileContent =~ s/\(\s+/(/g;
        $DynamicServerHPPFileContent =~ s/\s+\)/)/g;
        # Delete the abstract = 0;
        $DynamicServerHPPFileContent =~ s/ = 0;/ throw (_interface_throw);/g;
        # Delete all pre-processor lines
        $DynamicServerHPPFileContent =~ s/#\w+.*\n//g;
        # Extract just methods
        $DynamicServerHPPFileContent =~ s/\s*class\s+.*\n\s*{\s*\n\s*public:\s*\n//g;
        $DynamicServerHPPFileContent =~ s/\s*};\s*\n//g;
        # Delete all empty lines
        $DynamicServerHPPFileContent =~ s/^\n//g;
        # Standardize function tabulator set
        $DynamicServerHPPFileContent =~ s/^\s*virtual/    virtual/g;
    }
    $DynamicServerHPPFileContent =~ s/�Interface�/$InterfaceClassname/g;

    # Replace templates at template definition for server interface declaration
    # Replace �ModulFilename�
    $ServerClassDeclaration =~ s/�ModulFilename�/$InterfaceFilename/g;
    # Replace �InterfaceFilenameWithoutExt�
    $ServerClassDeclaration =~ s/�InterfaceFilenameWithoutExt�/$InterfaceFilenameWithoutExt/g;
    # Replace �Interface�
    $ServerClassDeclaration =~ s/�Interface�/$InterfaceClassname/g;
    # Replace �InterfaceFunctionDeclarations�
    $ServerClassDeclaration =~ s/�InterfaceFunctionDeclarations�/$DynamicServerHPPFileContent/g;
    # Replace �UserDefinedAttributes�
    if (-r $InterfaceFilename) {
        open (FileHandle,"< $InterfaceFilename") or return 1;
        $AlreadySetUserDefines = "";
        $LinesAreValid = 0;
        while ($ReadFileline = <FileHandle> ) {
            if ($ReadFileline =~ /^\s*\/\/\s*USERDEFATTRIBBEG/) {
                $LinesAreValid = 1;
                next;
            }
            if ($ReadFileline =~ /^\s*\/\/\s*USERDEFATTRIBEND/) {
                $LinesAreValid = 0;
                next;
            }
            ($ReadFileline) = ($ReadFileline =~ /(.*)\n$/);
            if ($LinesAreValid == 1) {
                $AlreadySetUserDefines = $AlreadySetUserDefines."\n".$ReadFileline;
            }
        }
        $ServerClassDeclaration =~ s/\s*�UserDefinedAttributes�/$AlreadySetUserDefines/g;
    }
    else {
        $ServerClassDeclaration =~ s/�UserDefinedAttributes�//g;
    }
    # Replace �UserDefinedAttMethods�
    if (-r $InterfaceFilename) {
        open (FileHandle,"< $InterfaceFilename") or return 1;
        $AlreadySetUserDefines = "";
        $LinesAreValid = 0;
        while ($ReadFileline = <FileHandle> ) {
            if ($ReadFileline =~ /^\s*\/\/\s*USERDEFATTMETHODEBEG/ ||
                $ReadFileline =~ /^\s*\/\/\s*USERDEFATTMETHODBEG/) {
                $LinesAreValid = 1;
                next;
            }
            if ($ReadFileline =~ /^\s*\/\/\s*USERDEFATTMETHODEEND/ ||
                $ReadFileline =~ /^\s*\/\/\s*USERDEFATTMETHODEND/) {
                $LinesAreValid = 0;
                next;
            }
            ($ReadFileline) = ($ReadFileline =~ /(.*)\n$/);
            if ($LinesAreValid == 1) {
                $AlreadySetUserDefines = $AlreadySetUserDefines."\n".$ReadFileline;
            }
        }
        $ServerClassDeclaration =~ s/\s*�UserDefinedAttMethods�/$AlreadySetUserDefines/g;
    }
    else {
        $ServerClassDeclaration =~ s/�UserDefinedAttMethods�//g;
    }
    # Replace �UserDefinedIncludes�
    if (-r $InterfaceFilename) {
        open (FileHandle,"< $InterfaceFilename") or return 1;
        $AlreadySetUserDefines = "";
        $LinesAreValid = 0;
        while ($ReadFileline = <FileHandle> ) {
            if ($ReadFileline =~ /^\s*\/\/\s*USERDEFINCLUDEBEG/) {
                $LinesAreValid = 1;
                next;
            }
            if ($ReadFileline =~ /^\s*\/\/\s*USERDEFINCLUDEEND/) {
                $LinesAreValid = 0;
                next;
            }
            ($ReadFileline) = ($ReadFileline =~ /(.*)\n$/);
            if ($LinesAreValid == 1) {
                $AlreadySetUserDefines = $AlreadySetUserDefines."\n".$ReadFileline;
            }
        }
        $ServerClassDeclaration =~ s/\s*�UserDefinedIncludes�/$AlreadySetUserDefines/g;
    }
    else {
        $ServerClassDeclaration =~ s/�UserDefinedIncludes�//g;
    }
       
    # Save old file as backup
    if (-r $InterfaceFilename) {
        rename ($InterfaceFilename, $InterfaceFilename."~");
    }

    # Open file (old style open, so that older perl versions can handle it)
    open (ABSTRHFileHandle,"> $InterfaceFilename") or return 1;
    
    if (length ($ServerClassDeclaration) > 0) {
        print ABSTRHFileHandle $ServerClassDeclaration;
    }
    else {
        return 1;
    }
    
    close (ABSTRHFileHandle);
    
    return 0;
}

# >--------------------------------------------------------------------------<
# > Subroutine: PrintServerCPPFileUsingTemplate                              <
# >             Prints the created server cpp definition into specific       <
# >             server cpp-file                                              <
# > Parameter:  $IDLFilepath -> Filepath to IDL-file                         <
# > Return:     <- Errorcode (0 = ok, 1 = error)                             <
# > Author:     A. Neidhardt                                                 <
# > Date:       13.02.2007                                                   <
# > Revision:   -                                                            <
# > Info:       -                                                            <
# >--------------------------------------------------------------------------<
sub PrintServerCPPFileUsingTemplate {
    my ($IDLFilepath)=@_;
    my $InterfaceFilenameWithoutExt;
    my $InterfaceFilename;
    my $DynamicServerCPPFileContent;
    my $InterfaceClassname;
    my $InterfaceClassnameLC;
    my $ServerClassDefinition = $g_ServerClassDefinitionTemplate;
    my @LinesOfInterfaceTemplate;
    my $LinesAreValid = 0;
    my $AlreadySetUserDefines;
    my $ReadFileline;
    my $FunctionName;
    my $DownCompatibleFunctionNamePart1;
    my $DownCompatibleFunctionNamePart2;
    my $LineIndex;
    my $Line;
    my $BackCountLineIndex;
    my $ServerClassName;          # Identifier of Serverclassname
    my $FindServerClassName;      # Shows if server class name must be derived from template
    my $UserDefAttrState;         # State of finite state machine to replace userdefined attribute parts
    my $CountLines;
    
    # Check if the abstract interface is already created, because this is needed for server interface
    if (!defined ($g_RPCABSTRH_DEFINITION) ||
        length ($g_RPCABSTRH_DEFINITION) == 0) {
        return 1;
    }
    
    # Get interface filename from idl filepath
    if ($IDLFilepath =~ /.*\/\w+\.\w+$/) {
        ($InterfaceFilenameWithoutExt) = ($IDLFilepath =~ /.*\/(\w+)\.\w+$/);
        ($InterfaceFilename) = ($IDLFilepath =~ /(.*\/\w+)\.\w+$/);
    }
    elsif ($IDLFilepath =~ /^\w+\.\w+$/) {
        ($InterfaceFilenameWithoutExt) = ($IDLFilepath =~ /^(\w+)\.\w+$/);
        ($InterfaceFilename) = ($IDLFilepath =~ /^(\w+)\.\w+$/);
    }
    else {
        return 1;
    }
    $InterfaceFilename = $InterfaceFilename."_server.cpp";
    
    # Get name of interface
    $InterfaceClassname = GetClassIdentifier();
    $InterfaceClassnameLC = lc(GetClassIdentifier());
    if (!defined ($InterfaceClassname) ||
        length ($InterfaceClassname) == 0) {
        return 1;
    }
    
    # Replace templates at template definition for server interface declaration
    # Replace �ModulFilename�
    $ServerClassDefinition =~ s/�ModulFilename�/$InterfaceFilename/g;
    # Replace �InterfaceFilenameWithoutExt�
    $ServerClassDefinition =~ s/�InterfaceFilenameWithoutExt�/$InterfaceFilenameWithoutExt/g;
    # Replace �InterfaceLC� = lower case
    $ServerClassDefinition =~ s/�InterfaceLC�/$InterfaceClassnameLC/g;
    # Replace �Interface�
    $ServerClassDefinition =~ s/�Interface�/$InterfaceClassname/g;
    # Replace �InterfaceFunctionDefinitions�
    $ServerClassDefinition =~ s/�InterfaceFunctionDefinitions�//g;
    # Replace �UserDefinedIncludes�
    if (-r $InterfaceFilename) {
        open (FileHandle,"< $InterfaceFilename") or return 1;
        $AlreadySetUserDefines = "";
        $LinesAreValid = 0;
        while ($ReadFileline = <FileHandle> ) {
            if ($ReadFileline =~ /^\s*\/\/\s*USERDEFINCLUDEBEG/) {
                $LinesAreValid = 1;
                next;
            }
            if ($ReadFileline =~ /^\s*\/\/\s*USERDEFINCLUDEEND/) {
                $LinesAreValid = 0;
                next;
            }
            ($ReadFileline) = ($ReadFileline =~ /(.*)\n$/);
            if ($LinesAreValid == 1) {
                $AlreadySetUserDefines = $AlreadySetUserDefines."\n".$ReadFileline;
            }
        }
        $ServerClassDefinition =~ s/\s*�UserDefinedIncludes�/$AlreadySetUserDefines/g;
    }
    else {
        $ServerClassDefinition =~ s/�UserDefinedIncludes�//g;
    }
    # Replace �UserDefinedAttMethods�
    if (-r $InterfaceFilename) {
        open (FileHandle,"< $InterfaceFilename") or return 1;
        $AlreadySetUserDefines = "";
        $LinesAreValid = 0;
        while ($ReadFileline = <FileHandle> ) {
            if ($ReadFileline =~ /^\s*\/\/\s*USERDEFATTMETHODEBEG/ ||
                $ReadFileline =~ /^\s*\/\/\s*USERDEFATTMETHODBEG/) {
                $LinesAreValid = 1;
                next;
            }
            if ($ReadFileline =~ /^\s*\/\/\s*USERDEFATTMETHODEEND/ ||
                $ReadFileline =~ /^\s*\/\/\s*USERDEFATTMETHODEND/) {
                $LinesAreValid = 0;
                next;
            }
            ($ReadFileline) = ($ReadFileline =~ /(.*)\n$/);
            if ($LinesAreValid == 1) {
                $AlreadySetUserDefines = $AlreadySetUserDefines."\n".$ReadFileline;
            }
        }
        $ServerClassDefinition =~ s/\s*�UserDefinedAttMethods�/$AlreadySetUserDefines/g;
    }
    else {
        $ServerClassDefinition =~ s/�UserDefinedAttMethods�//g;
    }
    # Replace userdefined method bodies 
    if (-r $InterfaceFilename) {
        @LinesOfInterfaceTemplate = split (/\n/,$ServerClassDefinition);
        $ServerClassDefinition = "";
        $LinesAreValid = 0;
        for ($LineIndex = 0; $LineIndex <= $#LinesOfInterfaceTemplate; $LineIndex++) {
            $ServerClassDefinition = $ServerClassDefinition.$LinesOfInterfaceTemplate[$LineIndex]."\n";
            if ($LinesOfInterfaceTemplate[$LineIndex] =~ /^\s*\/\/\s*USERDEFMETHODEBEG/ ||
                $LinesOfInterfaceTemplate[$LineIndex] =~ /^\s*\/\/\s*USERDEFMETHODBEG/) {
                $BackCountLineIndex = $LineIndex;
                while ($BackCountLineIndex >= 0 &&
                       !($LinesOfInterfaceTemplate[$BackCountLineIndex] =~ /_server::/)) {
                    $BackCountLineIndex--;
                }
                if (!($LinesOfInterfaceTemplate[$BackCountLineIndex] =~ /_server::/)) {
                    return 1;
                }
                ($FunctionName) = ($LinesOfInterfaceTemplate[$BackCountLineIndex] =~ /(\w+_server::\w+)/);
                # Read user defined function body from existing file 
                open (ABSTRHFileHandle,"< $InterfaceFilename") or return 1;
                $LinesAreValid = 0;
                $CountLines = 0;
                while ($Line = <ABSTRHFileHandle>) {
                    if ($LinesAreValid == 0) {
                        if ($Line =~ /(unsigned\s+)?((short)|(int)|(long)|(float)|(double)|(char)|(string)|(std::string)|(void))\s+$FunctionName\W/) {
                            $LinesAreValid = 1;
                        }
                        # Extension to allow down compatibility
                        if ($FunctionName =~ /^.*::_vInitServerActivity$/ ||
                            $FunctionName =~ /^.*::_vPeriodicServerActivity$/ ||
                            $FunctionName =~ /^.*::_vOnExitServerActivity$/) {
                            ($DownCompatibleFunctionNamePart1, $DownCompatibleFunctionNamePart2) = ($FunctionName =~ /^(.*::)_(.*)$/);
                            $DownCompatibleFunctionNamePart1 = $DownCompatibleFunctionNamePart1.$DownCompatibleFunctionNamePart2;
                            if ($Line =~ /(unsigned\s+)?((short)|(int)|(long)|(float)|(double)|(char)|(string)|(std::string)|(void))\s+$DownCompatibleFunctionNamePart1\W/) {
                                $LinesAreValid = 1;
                            }
                        }
                        next;
                    }
                    if ($LinesAreValid == 1) {
                        if ($Line =~ /^\s*\{/) {
                            $LinesAreValid = 2;
                        }
                        next;
                    }
                    if ($LinesAreValid == 2) {
                        if ($Line =~ /^\s*\/\/\s*USERDEFMETHODEBEG/ ||
                            $Line =~ /^\s*\/\/\s*USERDEFMETHODBEG/) {
                            $LinesAreValid = 3;
                        }
                        else {
                            print "\nWrong line at method ".$FunctionName." at line ".$Line."\n";
                            close (ABSTRHFileHandle);
                            return 1;
                        }
                        next;
                    }
                    if ($LinesAreValid == 3) {
                        if ($Line =~ /^\s*\/\/\s*USERDEFMETHODEEND/ ||
                            $Line =~ /^\s*\/\/\s*USERDEFMETHODEND/) {
                            if ($FunctionName =~ /^.*::_vInitServerActivity$/ &&
                                $CountLines == 0) {
                                $ServerClassDefinition = $ServerClassDefinition."    (void)argc; // Reduce compiler warnings unused variables\n";
                                $ServerClassDefinition = $ServerClassDefinition."    (void)argv; // Reduce compiler warnings unused variables\n";
                            }
                            $LinesAreValid = 4;
                        }
                        else {
                            if ($Line =~ /^\s*\/\/\s*USERDEFMETHODEBEG/ ||
                                $Line =~ /^\s*\/\/\s*USERDEFMETHODBEG/) {
                                print "\nWrong line at method ".$FunctionName." at line ".$Line."\n";
                                close (ABSTRHFileHandle);
                                return 1;
                            }
                            $ServerClassDefinition = $ServerClassDefinition.$Line;
                            $CountLines++;
                        }
                        next;
                    }
                    if ($LinesAreValid == 4) {
                        if ($Line =~ /^\s*\}/) {
                            $LinesAreValid = 0;
                        }
                        else {
                            print "\nWrong line at method ".$FunctionName." at line ".$Line."\n";
                            close (ABSTRHFileHandle);
                            return 1;
                        }
                        next;
                    }
                }
                close (ABSTRHFileHandle);
            }
        }
    }

    # Replace userdefined attribute bodies 
    $FindServerClassName = 1;
    $UserDefAttrState = 0;
    if (-r $InterfaceFilename) {
        @LinesOfInterfaceTemplate = split (/\n/,$ServerClassDefinition);
        $ServerClassDefinition = "";
        $LinesAreValid = 0;
        for ($LineIndex = 0; $LineIndex <= $#LinesOfInterfaceTemplate; $LineIndex++) {
            # Add template line to final body
            $ServerClassDefinition = $ServerClassDefinition.$LinesOfInterfaceTemplate[$LineIndex]."\n";
            # Find server class name
            if ($FindServerClassName &&
                $LinesOfInterfaceTemplate[$LineIndex] =~ /^\s*\w+::\w+\s*\(/) {
                ($ServerClassName) = ($LinesOfInterfaceTemplate[$LineIndex] =~ /^\s*(\w+)::\w+\s*\(/);
                $FindServerClassName = 0;
            }
            if (($LinesOfInterfaceTemplate[$LineIndex] =~ /^\s*\/\/\s*USERDEFMETHODEBEG/ ||
                 $LinesOfInterfaceTemplate[$LineIndex] =~ /^\s*\/\/\s*USERDEFMETHODBEG/)&&
                $UserDefAttrState != 0) {
                print "\nWrong line at method ".$ServerClassName."::".$ServerClassName." at line ".$LinesOfInterfaceTemplate[$LineIndex]."\n";
                return 1;
            }
            if (!$FindServerClassName) {
                if ($LinesOfInterfaceTemplate[$LineIndex] =~ /^\s*$ServerClassName\:\:$ServerClassName/ ||
                    $LinesOfInterfaceTemplate[$LineIndex] =~ /^\s*$ServerClassName\:\:~$ServerClassName/ ||
                    $LinesOfInterfaceTemplate[$LineIndex] =~ /^.*$ServerClassName\:\:operator\s*=/) {
                    if ($UserDefAttrState != 0) {
                        print "\nWrong line at method ".$ServerClassName."::".$ServerClassName." at line ".$LinesOfInterfaceTemplate[$LineIndex]."\n";
                        return 1;
                    }
                    $UserDefAttrState = 1;
                    $FunctionName = $LinesOfInterfaceTemplate[$LineIndex];
                    $FunctionName =~ s/\:/\\:/g;
                    $FunctionName =~ s/\(/\\(/g;
                    $FunctionName =~ s/\)/\\)/g;
                    $FunctionName =~ s/throw.*//g;
                }
                if ($UserDefAttrState == 1) {
                    if ($LinesOfInterfaceTemplate[$LineIndex] =~ /^\s*\/\/\s*USERDEFATTRIBBEG/) {
                        $UserDefAttrState = 2;
                        # Read user defined function body from existing file 
                        open (ABSTRHFileHandle,"< $InterfaceFilename") or return 1;
                        $LinesAreValid = 0;
                        while ($Line = <ABSTRHFileHandle>) {
                            if ($LinesAreValid == 0) {
                                if ($Line =~ /^$FunctionName/) {
                                    $LinesAreValid = 1;
                                }
                                next;
                            }
                            if ($LinesAreValid == 1) {
                                if ($Line =~ /^\s*\{/) {
                                    $LinesAreValid = 2;
                                }
                                next;
                            }
                            if ($LinesAreValid == 2) {
                                if ($Line =~ /^\s*\/\/\s*USERDEFATTRIBBEG/) {
                                    $LinesAreValid = 3;
                                }
                                if ($Line =~ /^\s*\/\/\s*USERDEFATTRIBEND/) {
                                    print "\nWrong line at method ".$FunctionName." at line ".$Line."\n";
                                    close (ABSTRHFileHandle);
                                    return 1;
                                }
                                next;
                            }    
                            if ($LinesAreValid == 3) {
                                if ($Line =~ /^\s*\/\/\s*USERDEFATTRIBEND/) {
                                    $LinesAreValid = 4;
                                }
                                else {
                                    if ($Line =~ /^\s*\/\/\s*USERDEFATTRIBBEG/) {
                                        print "\nWrong line at method ".$FunctionName." at line ".$Line."\n";
                                        close (ABSTRHFileHandle);
                                        return 1;
                                    }
                                    $ServerClassDefinition = $ServerClassDefinition.$Line;
                                }
                                next;
                            }
                            if ($LinesAreValid == 4) {
                                if ($Line =~ /^\s*\}/) {
                                    $LinesAreValid = 0;
                                }
                                else {
                                    print "\nWrong line at method ".$FunctionName." at line ".$Line."\n";
                                    close (ABSTRHFileHandle);
                                    return 1;
                                }
                                next;
                            }
                        }
                        close (ABSTRHFileHandle);
                    }
                }
            
                if ($UserDefAttrState == 2) {
                    if ($LinesOfInterfaceTemplate[$LineIndex] =~ /^\s*\/\/\s*USERDEFATTRIBEND/) {
                        $UserDefAttrState = 0;
                    }
                }
            }
        }
    }
    
    # Save old file as backup
    if (-r $InterfaceFilename) {
        rename ($InterfaceFilename, $InterfaceFilename."~");
    }

    # Open file (old style open, so that older perl versions can handle it)
    open (ABSTRHFileHandle,"> $InterfaceFilename") or return 1;
    if (length ($ServerClassDefinition) > 0) {
        print ABSTRHFileHandle $ServerClassDefinition;
    }
    else {
        return 1;
    }
    close (ABSTRHFileHandle);
    
    return 0;
}

# >--------------------------------------------------------------------------<
# > Subroutine: PrintServerProcHFileUsingTemplate                            <
# >             Prints the created server proc definition into specific      <
# >             server cpp-file                                              <
# > Parameter:  $IDLFilepath -> Filepath to IDL-file                         <
# > Return:     <- Errorcode (0 = ok, 1 = error)                             <
# > Author:     A. Neidhardt                                                 <
# > Date:       05.03.2007                                                   <
# > Revision:   -                                                            <
# > Info:       -                                                            <
# >--------------------------------------------------------------------------<
sub PrintServerProcHFileUsingTemplate {
    my ($IDLFilepath)=@_;
    my $InterfaceFilenameWithoutExt;
    my $InterfaceFilename;
    my $DynamicServerCPPFileContent;
    my $InterfaceClassname;
    my $ServerProcDeclaration = $g_ServerProcDeclarationTemplate;
    
    # Check if the abstract interface is already created, because this is needed for server interface
    if (!defined ($g_RPCABSTRH_DEFINITION) ||
        length ($g_RPCABSTRH_DEFINITION) == 0) {
        return 1;
    }
    
    # Get interface filename from idl filepath
    if ($IDLFilepath =~ /.*\/\w+\.\w+$/) {
        ($InterfaceFilenameWithoutExt) = ($IDLFilepath =~ /.*\/(\w+)\.\w+$/);
        ($InterfaceFilename) = ($IDLFilepath =~ /(.*\/\w+)\.\w+$/);
    }
    elsif ($IDLFilepath =~ /^\w+\.\w+$/) {
        ($InterfaceFilenameWithoutExt) = ($IDLFilepath =~ /^(\w+)\.\w+$/);
        ($InterfaceFilename) = ($IDLFilepath =~ /^(\w+)\.\w+$/);
    }
    else {
        return 1;
    }
    $InterfaceFilename = $InterfaceFilename."_proc.hpp";
    
    # Get name of interface
    $InterfaceClassname = GetClassIdentifier();
    if (!defined ($InterfaceClassname) ||
        length ($InterfaceClassname) == 0) {
        return 1;
    }
    
    # Replace templates at template definition for server interface declaration
    # Replace �ModulFilename�
    $ServerProcDeclaration =~ s/�ModulFilename�/$InterfaceFilename/g;
    # Replace �InterfaceFilenameWithoutExt�
    $ServerProcDeclaration =~ s/�InterfaceFilenameWithoutExt�/$InterfaceFilenameWithoutExt/g;
    # Replace �Interface�
    $ServerProcDeclaration =~ s/�Interface�/$InterfaceClassname/g;
        
    # Save old file as backup
    if (-r $InterfaceFilename) {
        rename ($InterfaceFilename, $InterfaceFilename."~");
    }

    # Open file (old style open, so that older perl versions can handle it)
    open (ABSTRHFileHandle,"> $InterfaceFilename") or return 1;
    
    if (length ($ServerProcDeclaration) > 0) {
        print ABSTRHFileHandle $ServerProcDeclaration;
    }
    else {
        return 1;
    }
    
    close (ABSTRHFileHandle);
    
    return 0;
}

# >--------------------------------------------------------------------------<
# > Subroutine: PrintServerProcCPPFileUsingTemplate                          <
# >             Prints the created server proc definition into specific      <
# >             server cpp-file                                              <
# > Parameter:  $IDLFilepath -> Filepath to IDL-file                         <
# >             $ServerTimeoutSec -> Server loop timeout second part         <
# >             $ServerTimeoutUSec -> Server loop timeout microsecond part   <
# >             $UseThread -> Flag which shows if a thread should be used    <
# > Return:     <- Errorcode (0 = ok, 1 = error)                             <
# > Author:     A. Neidhardt                                                 <
# > Date:       05.03.2007                                                   <
# > Revision:   -                                                            <
# > Info:       -                                                            <
# >--------------------------------------------------------------------------<
sub PrintServerProcCPPFileUsingTemplate {
    my ($IDLFilepath,$ServerTimeoutSec,$ServerTimeoutUSec,$UseThread,
        $AutomaticSafetyDevice)=@_;
    my $InterfaceFilenameWithoutExt;
    my $InterfaceFilename;
    my $DynamicServerCPPFileContent;
    my $InterfaceClassname;
    my $InterfaceClassnameLC;
    my $ServerProcDefinition = $g_ServerProcDefinitionTemplate;
    my $InterfaceVersion = GetInterfaceVersion();
    my $SimpleThreadInclude = "#include \"�InterfaceFilenameWithoutExt�_simple_thread.hpp\"";
    my $SimpleThreadDefinition = "class �Interface�_CRPCSimpleThread : public �Interface�_CSimpleThread\
{\
    private:\
        void * pvEntry ()\
        {\
            struct timeval STTimeout;\
            STTimeout.tv_sec = �SimpleThreadTimeoutSec�; \
            STTimeout.tv_usec = �SimpleThreadTimeoutUSec�;\
            // First call of periodic activity after start
            _vPeriodicServerActivity ();\
            if (STTimeout.tv_sec == 0 &&\
                STTimeout.tv_usec == 0)\
            {\
                // Periodic loop is called once
                // Timing must be written by user within \"_vPeriodicServerActivity\"
                // After the go into endless loop
                while (1) {sleep(1000);};\
            }\
            else\
            {\
                // Periodic loop is called by using a timing
                while (1)\
                {\
                    if (usServerLoopStopOrderIsActive () ||\
                        usServerInitAlertIsActive ())\
                        break;\
                    STTimeout.tv_sec = �SimpleThreadTimeoutSec�; \
                    STTimeout.tv_usec = �SimpleThreadTimeoutUSec�;\
                    switch (select(0, NULL, NULL, NULL, &STTimeout))\
                    {\
                        case 0:\
                            _vPeriodicServerActivity ();\
                            break;\
                        default:\
                            perror (\"timing select failed\");\
                            break;\
                    }\
                }\
            }\
            \
            return NULL;\
        }\
    public:\
        �Interface�_CRPCSimpleThread () : �Interface�_CSimpleThread () {}\
        ~�Interface�_CRPCSimpleThread () {}\
};\
\
�Interface�_CRPCSimpleThread g_�Interface�CSimpleServerThread;\
";
    my $SimpleThreadActivation = "g_�Interface�CSimpleServerThread.iRun();";
    my $SimpleThreadDeactivation = "// g_�Interface�CSimpleServerThread.iKill();";
    my $ASDThreadDefinition = "class �Interface�_CASDSimpleThread : public �Interface�_CSimpleThread\
{\
    private:\
        unsigned long ulASDLastActivityTime; \ 
        unsigned short usASDAlert;         
    private:\
        void * pvEntry ()\
        {\
            struct timeval STTimeout;\
            unsigned short usState = 0;\
            \
            STTimeout.tv_sec = 0; \
            STTimeout.tv_usec = 100000;\
            \
            if (usServerLoopStopOrderIsActive () ||\
                usServerInitAlertIsActive ())\
                return NULL;\
            // First call of periodic activity after start
            while (1)\
            {\
                if (usServerLoopStopOrderIsActive () ||\
                    usServerInitAlertIsActive ())\
                    break;\
                STTimeout.tv_sec = 0; \
                STTimeout.tv_usec = 100000;\
                switch (select(0, NULL, NULL, NULL, &STTimeout))\
                {\
                    case 0:\
                        if (time(NULL)-ulASDLastActivityTime > ".$AutomaticSafetyDevice.") \
                        {\
                            if (usASDAlert == 0)\
                            {\
                                g_SServerMethods._vAutomaticSafetyDeviceAlert ();\
                                g_SServerMethods._vAutomaticSafetyDeviceAlertRepeated ();\
                                usASDAlert = 1;\
                                usState = 0;\
                            }\
                            if ((usState > 0 || usState == 0) && usState < 10)\
                            {\
                                usState++;\
                            }\
                            else\
                            {\
                                g_SServerMethods._vAutomaticSafetyDeviceAlertRepeated ();\
                                usState = 0;\
                            }\
                        }\
                        else\
                        {\
                            usASDAlert = 0;\
                            usState = 0;\
                        }\
                        break;\
                    default:\
                        perror (\"timing select failed\");\
                        break;\
                }\
            }\
            \
            return NULL;\
        }\
    public:\
        �Interface�_CASDSimpleThread () : �Interface�_CSimpleThread () 
        {\
            ulASDLastActivityTime = time(NULL); \ 
            usASDAlert = 0;         
        }\
        ~�Interface�_CASDSimpleThread () {}\
        void vTouch ()\
        {\
            ulASDLastActivityTime = time(NULL);\
        }\
};\
\
�Interface�_CASDSimpleThread g_�Interface�CASDServerThread;\
";
    my $ASDThreadActivation = "g_�Interface�CASDServerThread.iRun();";
    my $ASDThreadDeactivation = "// g_�Interface�CASDServerThread.iKill();";
    
    # Check if the abstract interface is already created, because this is needed for server interface
    if (!defined ($g_RPCABSTRH_DEFINITION) ||
        length ($g_RPCABSTRH_DEFINITION) == 0) {
        return 1;
    }
    
    # Get interface filename from idl filepath
    if ($IDLFilepath =~ /.*\/\w+\.\w+$/) {
        ($InterfaceFilenameWithoutExt) = ($IDLFilepath =~ /.*\/(\w+)\.\w+$/);
        ($InterfaceFilename) = ($IDLFilepath =~ /(.*\/\w+)\.\w+$/);
    }
    elsif ($IDLFilepath =~ /^\w+\.\w+$/) {
        ($InterfaceFilenameWithoutExt) = ($IDLFilepath =~ /^(\w+)\.\w+$/);
        ($InterfaceFilename) = ($IDLFilepath =~ /^(\w+)\.\w+$/);
    }
    else {
        return 1;
    }
    $InterfaceFilename = $InterfaceFilename."_proc.cpp";
    
    # Get name of interface
    $InterfaceClassname = GetClassIdentifier();
    $InterfaceClassnameLC = lc(GetClassIdentifier());
    if (!defined ($InterfaceClassname) ||
        length ($InterfaceClassname) == 0) {
        return 1;
    }
    
    # Replace templates at template definition for server interface declaration
    # First replace thread parts if necessary, cause they include tags which will be 
    # replaced with the after then following rules
    if ($UseThread) {
        $ServerProcDefinition =~ s/�SimpleThreadInclude�/$SimpleThreadInclude/g;
        $ServerProcDefinition =~ s/�SimpleThreadDefinition�/$SimpleThreadDefinition/g;
        $ServerProcDefinition =~ s/�SimpleThreadActivation�/$SimpleThreadActivation/g;
        $ServerProcDefinition =~ s/�SimpleThreadDeactivation�/$SimpleThreadDeactivation/g;
        $ServerProcDefinition =~ s/�SimpleThreadTimeoutSec�/$ServerTimeoutSec/g;
        $ServerProcDefinition =~ s/�SimpleThreadTimeoutUSec�/$ServerTimeoutUSec/g;
    }
    else {
        $ServerProcDefinition =~ s/�SimpleThreadInclude�//g;
        $ServerProcDefinition =~ s/�SimpleThreadDefinition�//g;
        $ServerProcDefinition =~ s/�SimpleThreadActivation�//g;
        $ServerProcDefinition =~ s/�SimpleThreadDeactivation�//g;
        $ServerProcDefinition =~ s/�SimpleThreadTimeoutSec�//g;
        $ServerProcDefinition =~ s/�SimpleThreadTimeoutUSec�//g;
    }
    if ($AutomaticSafetyDevice >= 0) {
        if (!$UseThread) {
            $ServerProcDefinition =~ s/�ASDThreadInclude�/$SimpleThreadInclude/g;
        }
        else {
            $ServerProcDefinition =~ s/�ASDThreadInclude�//g;
        }
        $ServerProcDefinition =~ s/�ASDThreadDefinition�/$ASDThreadDefinition/g;
        $ServerProcDefinition =~ s/�ASDThreadActivation�/$ASDThreadActivation/g;
        $ServerProcDefinition =~ s/�ASDThreadDeactivation�/$ASDThreadDeactivation/g;
    }
    else {
        $ServerProcDefinition =~ s/�ASDThreadInclude�//g;
        $ServerProcDefinition =~ s/�ASDThreadDefinition�//g;
        $ServerProcDefinition =~ s/�ASDThreadActivation�//g;
        $ServerProcDefinition =~ s/�ASDThreadDeactivation�//g;
    }
    # Replace �ModulFilename�
    $ServerProcDefinition =~ s/�ModulFilename�/$InterfaceFilename/g;
    # Replace �InterfaceFilenameWithoutExt�
    $ServerProcDefinition =~ s/�InterfaceFilenameWithoutExt�/$InterfaceFilenameWithoutExt/g;
    # Replace �InterfaceLC� = lower case
    $ServerProcDefinition =~ s/�InterfaceLC�/$InterfaceClassnameLC/g;
    # Replace �Interface�
    $ServerProcDefinition =~ s/�Interface�/$InterfaceClassname/g;
    # Replace �InterfaceFunctionDefinitions�
    $ServerProcDefinition =~ s/�InterfaceFunctionDefinitions�//g;
    # Replace �InterfaceVersion�
    $ServerProcDefinition =~ s/�InterfaceVersion�/$InterfaceVersion/g;
    # Replace �Timeout�, �TimeoutSec� and �TimeoutUSev�
    if ($UseThread) {
        $ServerProcDefinition =~ s/�TimeoutSec�/0/g;
        $ServerProcDefinition =~ s/�TimeoutUSec�/0/g;
        $ServerProcDefinition =~ s/�Timeout�/(struct timeval *) NULL/g;
    }
    else
    {
        $ServerProcDefinition =~ s/�TimeoutSec�/$ServerTimeoutSec/g;
        $ServerProcDefinition =~ s/�TimeoutUSec�/$ServerTimeoutUSec/g;
        if ($ServerTimeoutSec == 0 &&
            $ServerTimeoutUSec == 0) {
            $ServerProcDefinition =~ s/�Timeout�/(struct timeval *) NULL/g;
        }
        else {
            $ServerProcDefinition =~ s/�Timeout�/&STTimeout/g;
        }
    }
    
    # Save old file as backup
    if (-r $InterfaceFilename) {
        rename ($InterfaceFilename, $InterfaceFilename."~");
    }

    # Open file (old style open, so that older perl versions can handle it)
    open (ABSTRHFileHandle,"> $InterfaceFilename") or return 1;
    
    if (length ($ServerProcDefinition) > 0) {
        print ABSTRHFileHandle $ServerProcDefinition;
    }
    else {
        return 1;
    }
    
    close (ABSTRHFileHandle);
    
    return 0;
}

# >--------------------------------------------------------------------------<
# > Subroutine: PrintServerSimpleThreadHPPFileUsingTemplate                  <
# >             Prints the created server thread declaration into specific   <
# >             server hpp-file                                              <
# > Parameter:  $IDLFilepath -> Filepath to IDL-file                         <
# > Return:     <- Errorcode (0 = ok, 1 = error)                             <
# > Author:     A. Neidhardt                                                 <
# > Date:       21.08.2007                                                   <
# > Revision:   -                                                            <
# > Info:       -                                                            <
# >--------------------------------------------------------------------------<
sub PrintServerSimpleThreadHPPFileUsingTemplate {
    my ($IDLFilepath)=@_;
    my $InterfaceFilenameWithoutExt;
    my $InterfaceFilename;
    my $DynamicServerCPPFileContent;
    my $InterfaceClassname;
    my $SimpleThreadClassDeclaration = $g_SimpleThreadClassDeclarationTemplate;
    
    # Check if the abstract interface is already created, because this is needed for server interface
    if (!defined ($g_RPCABSTRH_DEFINITION) ||
        length ($g_RPCABSTRH_DEFINITION) == 0) {
        return 1;
    }
    
    # Get interface filename from idl filepath
    if ($IDLFilepath =~ /.*\/\w+\.\w+$/) {
        ($InterfaceFilenameWithoutExt) = ($IDLFilepath =~ /.*\/(\w+)\.\w+$/);
        ($InterfaceFilename) = ($IDLFilepath =~ /(.*\/\w+)\.\w+$/);
    }
    elsif ($IDLFilepath =~ /^\w+\.\w+$/) {
        ($InterfaceFilenameWithoutExt) = ($IDLFilepath =~ /^(\w+)\.\w+$/);
        ($InterfaceFilename) = ($IDLFilepath =~ /^(\w+)\.\w+$/);
    }
    else {
        return 1;
    }
    $InterfaceFilename = $InterfaceFilename."_simple_thread.hpp";
    
    # Get name of interface
    $InterfaceClassname = GetClassIdentifier();
    if (!defined ($InterfaceClassname) ||
        length ($InterfaceClassname) == 0) {
        return 1;
    }
    
    # Replace templates at template definition for server interface declaration
    # Replace �ModulFilename�
    $SimpleThreadClassDeclaration =~ s/�ModulFilename�/$InterfaceFilename/g;
    # Replace �InterfaceFilenameWithoutExt�
    $SimpleThreadClassDeclaration =~ s/�InterfaceFilenameWithoutExt�/$InterfaceFilenameWithoutExt/g;
    # Replace �Interface�
    $SimpleThreadClassDeclaration =~ s/�Interface�/$InterfaceClassname/g;
    
    # Save old file as backup
    if (-r $InterfaceFilename) {
        rename ($InterfaceFilename, $InterfaceFilename."~");
    }

    # Open file (old style open, so that older perl versions can handle it)
    open (ABSTRHFileHandle,"> $InterfaceFilename") or return 1;
    
    if (length ($SimpleThreadClassDeclaration) > 0) {
        print ABSTRHFileHandle $SimpleThreadClassDeclaration;
    }
    else {
        return 1;
    }
    
    close (ABSTRHFileHandle);
    
    return 0;
}

# >--------------------------------------------------------------------------<
# > Subroutine: PrintServerSimpleThreadCPPFileUsingTemplate                  <
# >             Prints the created server thread definition into specific    <
# >             server cpp-file                                              <
# > Parameter:  $IDLFilepath -> Filepath to IDL-file                         <
# > Return:     <- Errorcode (0 = ok, 1 = error)                             <
# > Author:     A. Neidhardt                                                 <
# > Date:       21.08.2007                                                   <
# > Revision:   -                                                            <
# > Info:       -                                                            <
# >--------------------------------------------------------------------------<
sub PrintServerSimpleThreadCPPFileUsingTemplate {
    my ($IDLFilepath)=@_;
    my $InterfaceFilenameWithoutExt;
    my $InterfaceFilename;
    my $DynamicServerCPPFileContent;
    my $InterfaceClassname;
    my $SimpleThreadClassDefinition = $g_SimpleThreadClassDefinitionTemplate;
    
    # Check if the abstract interface is already created, because this is needed for server interface
    if (!defined ($g_RPCABSTRH_DEFINITION) ||
        length ($g_RPCABSTRH_DEFINITION) == 0) {
        return 1;
    }
    
    # Get interface filename from idl filepath
    if ($IDLFilepath =~ /.*\/\w+\.\w+$/) {
        ($InterfaceFilenameWithoutExt) = ($IDLFilepath =~ /.*\/(\w+)\.\w+$/);
        ($InterfaceFilename) = ($IDLFilepath =~ /(.*\/\w+)\.\w+$/);
    }
    elsif ($IDLFilepath =~ /^\w+\.\w+$/) {
        ($InterfaceFilenameWithoutExt) = ($IDLFilepath =~ /^(\w+)\.\w+$/);
        ($InterfaceFilename) = ($IDLFilepath =~ /^(\w+)\.\w+$/);
    }
    else {
        return 1;
    }
    $InterfaceFilename = $InterfaceFilename."_simple_thread.cpp";
    
    # Get name of interface
    $InterfaceClassname = GetClassIdentifier();
    if (!defined ($InterfaceClassname) ||
        length ($InterfaceClassname) == 0) {
        return 1;
    }
    
    # Replace templates at template definition for server interface declaration
    # Replace �ModulFilename�
    $SimpleThreadClassDefinition =~ s/�ModulFilename�/$InterfaceFilename/g;
    # Replace �InterfaceFilenameWithoutExt�
    $SimpleThreadClassDefinition =~ s/�InterfaceFilenameWithoutExt�/$InterfaceFilenameWithoutExt/g;
    # Replace �Interface�
    $SimpleThreadClassDefinition =~ s/�Interface�/$InterfaceClassname/g;
    
    # Save old file as backup
    if (-r $InterfaceFilename) {
        rename ($InterfaceFilename, $InterfaceFilename."~");
    }

    # Open file (old style open, so that older perl versions can handle it)
    open (ABSTRHFileHandle,"> $InterfaceFilename") or return 1;
    
    if (length ($SimpleThreadClassDefinition) > 0) {
        print ABSTRHFileHandle $SimpleThreadClassDefinition;
    }
    else {
        return 1;
    }
    
    close (ABSTRHFileHandle);
    
    return 0;
}

# >--------------------------------------------------------------------------<
# > Subroutine: PrintServerSimpleSemaphoreVariableHPPFileUsingTemplate       <
# >             Prints the created server semvar declaration into specific   <
# >             server hpp-file                                              <
# > Parameter:  $IDLFilepath -> Filepath to IDL-file                         <
# >             $UseThread -> Show if threads are used => Semaphore needed   <
# >                           otherwise a semvar-dummy is created            <
# > Return:     <- Errorcode (0 = ok, 1 = error)                             <
# > Author:     A. Neidhardt                                                 <
# > Date:       21.08.2007                                                   <
# > Revision:   -                                                            <
# > Info:       -                                                            <
# >--------------------------------------------------------------------------<
sub PrintServerSimpleSemaphoreVariableHPPFileUsingTemplate {
    my ($IDLFilepath,$UseThread)=@_;
    my $InterfaceFilenameWithoutExt;
    my $InterfaceFilename;
    my $DynamicServerCPPFileContent;
    my $InterfaceClassname;
    my $SimpleSemVarClassDeclaration;
    
    if ($UseThread) {
        $SimpleSemVarClassDeclaration = $g_SimpleSemaphoreClassDeclarationTemplate."\n".$g_SimpleSemaphoreVariableClassDeclarationTemplate;
    }
    else {
        $SimpleSemVarClassDeclaration = $g_SimpleSemaphoreVariableDummyClassDeclarationTemplate;
    }
    
    # Check if the abstract interface is already created, because this is needed for server interface
    if (!defined ($g_RPCABSTRH_DEFINITION) ||
        length ($g_RPCABSTRH_DEFINITION) == 0) {
        return 1;
    }
    
    # Get interface filename from idl filepath
    if ($IDLFilepath =~ /.*\/\w+\.\w+$/) {
        ($InterfaceFilenameWithoutExt) = ($IDLFilepath =~ /.*\/(\w+)\.\w+$/);
        ($InterfaceFilename) = ($IDLFilepath =~ /(.*\/\w+)\.\w+$/);
    }
    elsif ($IDLFilepath =~ /^\w+\.\w+$/) {
        ($InterfaceFilenameWithoutExt) = ($IDLFilepath =~ /^(\w+)\.\w+$/);
        ($InterfaceFilename) = ($IDLFilepath =~ /^(\w+)\.\w+$/);
    }
    else {
        return 1;
    }
    $InterfaceFilename = $InterfaceFilename."_simple_semvar.hpp";
    
    # Get name of interface
    $InterfaceClassname = GetClassIdentifier();
    if (!defined ($InterfaceClassname) ||
        length ($InterfaceClassname) == 0) {
        return 1;
    }
    
    # Replace templates at template definition for server interface declaration
    # Replace �ModulFilename�
    $SimpleSemVarClassDeclaration =~ s/�ModulFilename�/$InterfaceFilename/g;
    # Replace �InterfaceFilenameWithoutExt�
    $SimpleSemVarClassDeclaration =~ s/�InterfaceFilenameWithoutExt�/$InterfaceFilenameWithoutExt/g;
    # Replace �Interface�
    $SimpleSemVarClassDeclaration =~ s/�Interface�/$InterfaceClassname/g;
    
    # Save old file as backup
    if (-r $InterfaceFilename) {
        rename ($InterfaceFilename, $InterfaceFilename."~");
    }

    # Open file (old style open, so that older perl versions can handle it)
    open (ABSTRHFileHandle,"> $InterfaceFilename") or return 1;
    
    if (length ($SimpleSemVarClassDeclaration) > 0) {
        print ABSTRHFileHandle $SimpleSemVarClassDeclaration;
    }
    else {
        return 1;
    }
    
    close (ABSTRHFileHandle);
    
    return 0;
}

# >--------------------------------------------------------------------------<
# > Subroutine: PrintServerSimpleSemaphoreVariableCPPFileUsingTemplate       <
# >             Prints the created server semvar definition into specific    <
# >             server cpp-file                                              <
# > Parameter:  $IDLFilepath -> Filepath to IDL-file                         <
# >             $UseThread -> Show if threads are used => Semaphore needed   <
# >                           otherwise a semvar-dummy is created            <
# > Return:     <- Errorcode (0 = ok, 1 = error)                             <
# > Author:     A. Neidhardt                                                 <
# > Date:       21.08.2007                                                   <
# > Revision:   -                                                            <
# > Info:       -                                                            <
# >--------------------------------------------------------------------------<
sub PrintServerSimpleSemaphoreVariableCPPFileUsingTemplate {
    my ($IDLFilepath,$UseThread)=@_;
    my $InterfaceFilenameWithoutExt;
    my $InterfaceFilename;
    my $DynamicServerCPPFileContent;
    my $InterfaceClassname;
    my $SimpleSemVarClassDefinition;
    
    if ($UseThread) {
        $SimpleSemVarClassDefinition = $g_SimpleSemaphoreClassDefinitionTemplate."\n".$g_SimpleSemaphoreVariableClassDefinitionTemplate;
    }
    else {
        $SimpleSemVarClassDefinition = "#include \"�InterfaceFilenameWithoutExt�_simple_semvar.hpp\"\n".$g_SimpleSemaphoreVariableDummyClassDefinitionTemplate;
    }

    # Check if the abstract interface is already created, because this is needed for server interface
    if (!defined ($g_RPCABSTRH_DEFINITION) ||
        length ($g_RPCABSTRH_DEFINITION) == 0) {
        return 1;
    }
    
    # Get interface filename from idl filepath
    if ($IDLFilepath =~ /.*\/\w+\.\w+$/) {
        ($InterfaceFilenameWithoutExt) = ($IDLFilepath =~ /.*\/(\w+)\.\w+$/);
        ($InterfaceFilename) = ($IDLFilepath =~ /(.*\/\w+)\.\w+$/);
    }
    elsif ($IDLFilepath =~ /^\w+\.\w+$/) {
        ($InterfaceFilenameWithoutExt) = ($IDLFilepath =~ /^(\w+)\.\w+$/);
        ($InterfaceFilename) = ($IDLFilepath =~ /^(\w+)\.\w+$/);
    }
    else {
        return 1;
    }
    $InterfaceFilename = $InterfaceFilename."_simple_semvar.cpp";
    
    # Get name of interface
    $InterfaceClassname = GetClassIdentifier();
    if (!defined ($InterfaceClassname) ||
        length ($InterfaceClassname) == 0) {
        return 1;
    }
    
    # Replace templates at template definition for server interface declaration
    # Replace �ModulFilename�
    $SimpleSemVarClassDefinition =~ s/�ModulFilename�/$InterfaceFilename/g;
    # Replace �InterfaceFilenameWithoutExt�
    $SimpleSemVarClassDefinition =~ s/�InterfaceFilenameWithoutExt�/$InterfaceFilenameWithoutExt/g;
    # Replace �Interface�
    $SimpleSemVarClassDefinition =~ s/�Interface�/$InterfaceClassname/g;
    
    # Save old file as backup
    if (-r $InterfaceFilename) {
        rename ($InterfaceFilename, $InterfaceFilename."~");
    }

    # Open file (old style open, so that older perl versions can handle it)
    open (ABSTRHFileHandle,"> $InterfaceFilename") or return 1;
    
    if (length ($SimpleSemVarClassDefinition) > 0) {
        print ABSTRHFileHandle $SimpleSemVarClassDefinition;
    }
    else {
        return 1;
    }
    
    close (ABSTRHFileHandle);
    
    return 0;
}

# >--------------------------------------------------------------------------<
# > Subroutine: PrintOSHFileUsingTemplate                                    <
# >             Prints the operating system dependent parts to h-file        <
# > Parameter:  $IDLFilepath -> Filepath to IDL-file                         <
# > Return:     <- Errorcode (0 = ok, 1 = error)                             <
# > Author:     A. Neidhardt                                                 <
# > Date:       06.11.2008                                                   <
# > Revision:   -                                                            <
# > Info:       -                                                            <
# >--------------------------------------------------------------------------<
sub PrintOSHFileUsingTemplate {
    my ($IDLFilepath)=@_;
    my $InterfaceFilenameWithoutExt;
    my $InterfaceFilename;
    my $DynamicServerCPPFileContent;
    my $InterfaceClassname;
    my $OSHDefinition = "#ifndef __�InterfaceFilenameWithoutExt�__OS__DEPENDANT__PARTS__\
#define __�InterfaceFilenameWithoutExt�__OS__DEPENDANT__PARTS__\
\
/* Under construction */\
#endif /*__�InterfaceFilenameWithoutExt�__OS__DEPENDANT__PARTS__*/\
";

    # Check if the abstract interface is already created, because this is needed for server interface
    if (!defined ($g_RPCABSTRH_DEFINITION) ||
        length ($g_RPCABSTRH_DEFINITION) == 0) {
        return 1;
    }
    
    # Get interface filename from idl filepath
    if ($IDLFilepath =~ /.*\/\w+\.\w+$/) {
        ($InterfaceFilenameWithoutExt) = ($IDLFilepath =~ /.*\/(\w+)\.\w+$/);
        ($InterfaceFilename) = ($IDLFilepath =~ /(.*\/\w+)\.\w+$/);
    }
    elsif ($IDLFilepath =~ /^\w+\.\w+$/) {
        ($InterfaceFilenameWithoutExt) = ($IDLFilepath =~ /^(\w+)\.\w+$/);
        ($InterfaceFilename) = ($IDLFilepath =~ /^(\w+)\.\w+$/);
    }
    else {
        return 1;
    }
    $InterfaceFilename = $InterfaceFilename."_os.h";
    
    # Get name of interface
    $InterfaceClassname = GetClassIdentifier();
    if (!defined ($InterfaceClassname) ||
        length ($InterfaceClassname) == 0) {
        return 1;
    }
    
    # Replace templates at template definition for server interface declaration
    $OSHDefinition =~ s/�InterfaceFilenameWithoutExt�/$InterfaceFilenameWithoutExt/g;
    
    # Save old file as backup
    if (-r $InterfaceFilename) {
        rename ($InterfaceFilename, $InterfaceFilename."~");
    }

    # Open file (old style open, so that older perl versions can handle it)
    open (ABSTRHFileHandle,"> $InterfaceFilename") or return 1;
    
    if (length ($OSHDefinition) > 0) {
        print ABSTRHFileHandle $OSHDefinition;
    }
    else {
        return 1;
    }
    
    close (ABSTRHFileHandle);
    
    return 0;
}

# >--------------------------------------------------------------------------<
# > Subroutine: PrintOSCFileUsingTemplate                                    <
# >             Prints the operating system dependent parts to c-file        <
# > Parameter:  $IDLFilepath -> Filepath to IDL-file                         <
# > Return:     <- Errorcode (0 = ok, 1 = error)                             <
# > Author:     A. Neidhardt                                                 <
# > Date:       06.11.2008                                                   <
# > Revision:   -                                                            <
# > Info:       -                                                            <
# >--------------------------------------------------------------------------<
sub PrintOSCFileUsingTemplate {
    my ($IDLFilepath)=@_;
    my $InterfaceFilenameWithoutExt;
    my $InterfaceFilename;
    my $DynamicServerCPPFileContent;
    my $InterfaceClassname;
    my $OSCDefinition = "#include \"�InterfaceFilenameWithoutExt�_os.h\"\
/* Under construction */\
";

    # Check if the abstract interface is already created, because this is needed for server interface
    if (!defined ($g_RPCABSTRH_DEFINITION) ||
        length ($g_RPCABSTRH_DEFINITION) == 0) {
        return 1;
    }
    
    # Get interface filename from idl filepath
    if ($IDLFilepath =~ /.*\/\w+\.\w+$/) {
        ($InterfaceFilenameWithoutExt) = ($IDLFilepath =~ /.*\/(\w+)\.\w+$/);
        ($InterfaceFilename) = ($IDLFilepath =~ /(.*\/\w+)\.\w+$/);
    }
    elsif ($IDLFilepath =~ /^\w+\.\w+$/) {
        ($InterfaceFilenameWithoutExt) = ($IDLFilepath =~ /^(\w+)\.\w+$/);
        ($InterfaceFilename) = ($IDLFilepath =~ /^(\w+)\.\w+$/);
    }
    else {
        return 1;
    }
    $InterfaceFilename = $InterfaceFilename."_os.c";
    
    # Get name of interface
    $InterfaceClassname = GetClassIdentifier();
    if (!defined ($InterfaceClassname) ||
        length ($InterfaceClassname) == 0) {
        return 1;
    }
    
    # Replace templates at template definition for server interface declaration
    $OSCDefinition =~ s/�InterfaceFilenameWithoutExt�/$InterfaceFilenameWithoutExt/g;
    
    # Save old file as backup
    if (-r $InterfaceFilename) {
        rename ($InterfaceFilename, $InterfaceFilename."~");
    }

    # Open file (old style open, so that older perl versions can handle it)
    open (ABSTRHFileHandle,"> $InterfaceFilename") or return 1;
    
    if (length ($OSCDefinition) > 0) {
        print ABSTRHFileHandle $OSCDefinition;
    }
    else {
        return 1;
    }
    
    close (ABSTRHFileHandle);
    
    return 0;
}

# >--------------------------------------------------------------------------<
# > Subroutine: ChangeServerSVRfile                                          <
# >             Change the rpcgen generated server file _svr.c               <
# > Parameter:  $IDLFilepath -> Filepath to IDL-file                         <
# > Return:     <- Errorcode (0 = ok, 1 = error)                             <
# > Author:     A. Neidhardt                                                 <
# > Date:       17.04.2007                                                   <
# > Revision:   -                                                            <
# > Info:       -                                                            <
# >--------------------------------------------------------------------------<
sub ChangeServerSVRfile {
    my ($IDLFilepath,$FixedUDPPort,$FixedTCPPort)=@_;
    my $InterfaceFilenameWithoutExt;  # Reduced file by extension
    my $InterfaceFilename;            # Filename of interface and derived server filename
    my $RPCProcHeaderFilename;        # Filename of interface header file of RPC
    my $Line;                         # Single line of read-in-file
    my $ServerSVRFileContent;         # Complete content
    my $MarkOfIncludeLineEnd = 0;     # Helper variable to find out end of include line
    my $InterfaceClassname;           # Classname of interface class
    my $ServerMainRPCReplacementsTemplate = $g_ServerMainRPCReplacementsTemplate; # Server replacement in main
    my $ServerMainRPCStartupReplacementsTemplate = $g_ServerMainRPCStartupReplacementsTemplate; # Server startup replacements
    my $ServerMainIncludeRPCReplacementsTemplate = $g_ServerMainIncludeRPCReplacementsTemplate; # Server replacement in include
    my $FixedPortReplacementTemplate = "    if (uiInitInetServer (�Port�, &iSocket, �SocketProtocol�))\
    {\
        fprintf (stderr, \"\%s\", \"cannot create tcp service.\");\
        exit (1);\
    }\
    ";
    my $FixedPortReplacement;     # Replacement is made
    
    # Check if the abstract interface is already created, because this is needed for server interface
    if (!defined ($g_RPCABSTRH_DEFINITION) ||
        length ($g_RPCABSTRH_DEFINITION) == 0) {
        return 1;
    }
    
    # Get interface filename from idl filepath
    if ($IDLFilepath =~ /.*\/\w+\.\w+$/) {
        ($InterfaceFilenameWithoutExt) = ($IDLFilepath =~ /.*\/(\w+)\.\w+$/);
        ($InterfaceFilename) = ($IDLFilepath =~ /(.*\/\w+)\.\w+$/);
    }
    elsif ($IDLFilepath =~ /^\w+\.\w+$/) {
        ($InterfaceFilenameWithoutExt) = ($IDLFilepath =~ /^(\w+)\.\w+$/);
        ($InterfaceFilename) = ($IDLFilepath =~ /^(\w+)\.\w+$/);
    }
    else {
        return 1;
    }
    $RPCProcHeaderFilename = $InterfaceFilename."_proc.hpp";
    $InterfaceFilename = $InterfaceFilename."_svc.c";
       
    # Get name of interface
    $InterfaceClassname = GetClassIdentifier();
    if (!defined ($InterfaceClassname) ||
        length ($InterfaceClassname) == 0) {
        return 1;
    }
    
    # Replace templates at template definition for server interface declaration
    # Replace �Interface�
    $ServerMainRPCReplacementsTemplate =~ s/�Interface�/$InterfaceClassname/g;
    $ServerMainIncludeRPCReplacementsTemplate =~ s/�Interface�/$InterfaceClassname/g;
    $ServerMainRPCStartupReplacementsTemplate =~ s/�Interface�/$InterfaceClassname/g;
    
    # Open file (old style open, so that older perl versions can handle it) and read in
    open (ABSTRHFileHandle,"< $InterfaceFilename") or return 1;
    while ($Line = <ABSTRHFileHandle>) {
        if ($MarkOfIncludeLineEnd == 0 &&
            $Line =~ /^#include/) {
            $MarkOfIncludeLineEnd = 1;
        }
        if ($MarkOfIncludeLineEnd == 1 &&
            !($Line =~ /^#include/)) {
            $MarkOfIncludeLineEnd = 2;
            $Line = $Line.$ServerMainIncludeRPCReplacementsTemplate."\n";
        }
        if ($Line =~ /transp = svctcp_create.*/){
            if ($FixedTCPPort != 0) {
                $FixedPortReplacement = $FixedPortReplacementTemplate;
                $FixedPortReplacement =~ s/�Port�/$FixedTCPPort/g;
                $FixedPortReplacement =~ s/�SocketProtocol�/1/g;
                $Line = $FixedPortReplacement."g_iTCPSocket = iSocket;\n    transp = svctcp_create(g_iTCPSocket, 0, 0);\n    vSetTCPPort ((unsigned long) transp->xp_port);\n";
            }
            else {
                $Line = $Line."    vSetTCPPort ((unsigned long) transp->xp_port);\n";
            }
        }
        if ($Line =~ /transp = svcudp_create.*/) {
            if ($FixedUDPPort != 0) {
                $FixedPortReplacement = $FixedPortReplacementTemplate;
                $FixedPortReplacement =~ s/�Port�/$FixedUDPPort/g;
                $FixedPortReplacement =~ s/�SocketProtocol�/0/g;
                $Line = $FixedPortReplacement."g_iUDPSocket = iSocket;\n    transp = svcudp_create(g_iUDPSocket);\n    vSetUDPPort ((unsigned long) transp->xp_port);\n";
            }
            else {
                $Line = $Line."    vSetUDPPort ((unsigned long) transp->xp_port);\n";
            }
        }
        if (($FixedTCPPort != 0 || $FixedUDPPort != 0) &&
             $Line =~ /register.*transp;.*/) {
            $Line = $Line."    int iSocket;\n    g_iUDPSocket = -1;\n    g_iTCPSocket = -1;\n";
        }
        $Line =~ s/\.h"/.h"\n#include "$RPCProcHeaderFilename"/g;
        $Line =~ s/svc_run\s*\(\);/\/\/ svc_run ();\n$ServerMainRPCReplacementsTemplate/g;
        if ($Line =~ /main \(int argc, char \*\*argv\).*/) {
            $Line = <ABSTRHFileHandle>;
            $Line = "main (int argc, char **argv)\n{\n".$ServerMainRPCStartupReplacementsTemplate."\n";
        }
        $ServerSVRFileContent = $ServerSVRFileContent.$Line;
    }
    close (ABSTRHFileHandle);

    # Open file (old style open, so that older perl versions can handle it) and write changed content
    open (ABSTRHFileHandle,"> $InterfaceFilename") or return 1;
    print ABSTRHFileHandle $ServerSVRFileContent;
    close (ABSTRHFileHandle);
    
    return 0;
}

# >--------------------------------------------------------------------------<
# > Subroutine: ChangeXDRfile                                                <
# >             The generated XDR-file has a lot of unused variables. To     <
# >             avoid these, add a dummy operation "buf = buf;"              <
# > Parameter:  $IDLFilepath -> Filepath to IDL-file                         <
# > Return:     <- Errorcode (0 = ok, 1 = error)                             <
# > Author:     A. Neidhardt                                                 <
# > Date:       07.05.2007                                                   <
# > Revision:   -                                                            <
# > Info:       -                                                            <
# >--------------------------------------------------------------------------<
sub ChangeXDRfile {
    my ($IDLFilepath)=@_;
    my $InterfaceFilenameWithoutExt;  # Reduced file by extension
    my $InterfaceFilename;            # Filename of interface and derived server filename
    my $Line;                         # Single line of read-in-file
    my $XDRFileContent;               # Complete content
    my $MarkOfIncludeLineEnd = 0;     # Helper variable to find out end of include line
    
    # Check if the abstract interface is already created, because this is needed for server interface
    if (!defined ($g_RPCABSTRH_DEFINITION) ||
        length ($g_RPCABSTRH_DEFINITION) == 0) {
        return 1;
    }
    
    # Get interface filename from idl filepath
    if ($IDLFilepath =~ /.*\/\w+\.\w+$/) {
        ($InterfaceFilenameWithoutExt) = ($IDLFilepath =~ /.*\/(\w+)\.\w+$/);
        ($InterfaceFilename) = ($IDLFilepath =~ /(.*\/\w+)\.\w+$/);
    }
    elsif ($IDLFilepath =~ /^\w+\.\w+$/) {
        ($InterfaceFilenameWithoutExt) = ($IDLFilepath =~ /^(\w+)\.\w+$/);
        ($InterfaceFilename) = ($IDLFilepath =~ /^(\w+)\.\w+$/);
    }
    else {
        return 1;
    }
    $InterfaceFilename = $InterfaceFilename."_xdr.c";
    
    # Open file (old style open, so that older perl versions can handle it) and read in
    open (ABSTRHFileHandle,"< $InterfaceFilename") or return 1;
    while ($Line = <ABSTRHFileHandle>) {
        $Line =~ s/\s*register\s+int32_t\s*\*\s*buf\s*;\s*/    register int32_t *buf = NULL;\n/g;
        $Line =~ s/return TRUE;\s*/buf = buf;  \/* Dummy to easily avoid unused variables *\/\n\treturn TRUE;\n/g;
        $XDRFileContent = $XDRFileContent.$Line;
    }
    close (ABSTRHFileHandle);

    # Open file (old style open, so that older perl versions can handle it) and write changed content
    open (ABSTRHFileHandle,"> $InterfaceFilename") or return 1;
    print ABSTRHFileHandle $XDRFileContent;
    close (ABSTRHFileHandle);
    
    return 0;
}

# >--------------------------------------------------------------------------<
# > Subroutine: InitNewClientClassRPCMethodDefinition                        <
# >             Prepares variables for templatereplacement of client RPC     <
# > Parameter:  -                                                            <
# > Return:     -                                                            <
# > Author:     A. Neidhardt                                                 <
# > Date:       19.02.2007                                                   <
# > Revision:   -                                                            <
# > Info:       -                                                            <
# >--------------------------------------------------------------------------<
sub InitNewClientClassRPCMethodDefinition {
    $g_ClientClassRPCMethodDefinition = $g_ClientClassRPCMethodDefinitionTemplate; 
}

# >--------------------------------------------------------------------------<
# > Subroutine: ReplaceTemplateAtClientClassRPCMethodDefinition             <
# >             Replace a template by a value                                <
# > Parameter:  $Template -> Expression which should be replaced
# >             $Value -> Expression which is new
# > Return:     -                                                            <
# > Author:     A. Neidhardt                                                 <
# > Date:       19.02.2007                                                   <
# > Revision:   -                                                            <
# > Info:       -                                                            <
# >--------------------------------------------------------------------------<
sub ReplaceTemplateAtClientClassRPCMethodDefinition {
    my ($Template,$Value)=@_;
    my $TemplateLine = "";
    my $Whitespaces = "";
   
    # Save templatelines which has to be added again
    if ($Template =~ /�VariableDefinitions�/ ||
        $Template =~ /�FillINVariables�/ ||
        $Template =~ /�SetDefaultParameterReturn�/ ||
        $Template =~ /�FillParameterReturn�/ ||
        $Template =~ /�FinalCleanUp�/ ||
        $Template =~ /�VariableInit�/ ||
        $Template =~ /�SetReturnValue�/) {
        $Whitespaces = GetSpacesInFrontOfTemplateAtClientClassRPCMethodDefinition ($Template);
        ($TemplateLine) = ($Template =~ /(�\w+�)/);
        $TemplateLine = "\n".$Whitespaces.$TemplateLine;
    }
    elsif ($Template =~ /�ReturnValue�/ ||
           $Template =~ /�Parameters�/) {
        ($TemplateLine) = ($Template =~ /(�\w+�)/);
    }
    
    # Replace template
    $g_ClientClassRPCMethodDefinition =~ s/$Template/$Value$TemplateLine/g;
}

# >--------------------------------------------------------------------------<
# > Subroutine: GetSpacesInFrontOfTemplateAtClientClassRPCMethodDefinition  <
# >             Returns string with spaces which are in front of a specified <
# >             template                                                     <
# > Parameter:  $Template -> Tag which specifies line in which the beginning <
# >                          spaces should be registered                     <
# > Return:     -                                                            <
# > Author:     A. Neidhardt                                                 <
# > Date:       22.02.2007                                                   <
# > Revision:   -                                                            <
# > Info:       -                                                            <
# >--------------------------------------------------------------------------<
sub GetSpacesInFrontOfTemplateAtClientClassRPCMethodDefinition {
    my ($Template)=@_;
    my $SpaceLine = "";
    
    if ($g_ClientClassRPCMethodDefinition =~ /\n\s+$Template/) {
        ($SpaceLine) = ($g_ClientClassRPCMethodDefinition =~ /\n(\s+)$Template/);
    }

    return $SpaceLine;
}

# >--------------------------------------------------------------------------<
# > Subroutine: AddRPCMethodToClientClassDefinitionTemplate                 <
# >             Add a newly defined RPC-method to template for client       <
# > Parameter:  -                                                            <
# > Return:     -                                                            <
# > Author:     A. Neidhardt                                                 <
# > Date:       19.02.2007                                                   <
# > Revision:   -                                                            <
# > Info:       -                                                            <
# >--------------------------------------------------------------------------<
sub AddRPCMethodToClientClassDefinitionTemplate {
    
    # Delete all template elements
    $g_ClientClassRPCMethodDefinition =~ s/�\w+�//g;
    # Delete all spaces in front of a ) and after a (
    $g_ClientClassRPCMethodDefinition =~ s/\s+\)/)/g;
    $g_ClientClassRPCMethodDefinition =~ s/\(\s+/(/g;
    # Delete all empty lines
    $g_ClientClassRPCMethodDefinition =~ s/\n\s*\n/\n/g;

    # Replace templatemarker for RPC-methods at ClientClassDefinitionTemplate
    $g_ClientClassDefinitionTemplate =~ s/�InterfaceFunctionDefinitions�/$g_ClientClassRPCMethodDefinition\n�InterfaceFunctionDefinitions�/g;
}

# >--------------------------------------------------------------------------<
# > Subroutine: InitNewServerClassRPCMethodDefinition                       <
# >             Prepares variables for templatereplacement of server RPC     <
# > Parameter:  -                                                            <
# > Return:     -                                                            <
# > Author:     A. Neidhardt                                                 <
# > Date:       19.02.2007                                                   <
# > Revision:   -                                                            <
# > Info:       -                                                            <
# >--------------------------------------------------------------------------<
sub InitNewServerClassRPCMethodDefinition {
    $g_ServerClassRPCMethodDefinition = $g_ServerClassRPCMethodDefinitionTemplate; 
}

# >--------------------------------------------------------------------------<
# > Subroutine: ReplaceTemplateAtServerClassRPCMethodDefinition             <
# >             Replace a template by a value                                <
# > Parameter:  $Template -> Expression which should be replaced
# >             $Value -> Expression which is new
# > Return:     -                                                            <
# > Author:     A. Neidhardt                                                 <
# > Date:       19.02.2007                                                   <
# > Revision:   -                                                            <
# > Info:       -                                                            <
# >--------------------------------------------------------------------------<
sub ReplaceTemplateAtServerClassRPCMethodDefinition {
    my ($Template,$Value)=@_;
    my $TemplateLine = "";
    my $Whitespaces = "";
    
    # Save templatelines which has to be added again
    if ($Template =~ /�VariableDefinitions�/ ||
        $Template =~ /�FillINVariables�/ ||
        $Template =~ /�SetDefaultParameterReturn�/ ||
        $Template =~ /�FillParameterReturn�/) {
        $Whitespaces = GetSpacesInFrontOfTemplateAtServerClassRPCMethodDefinition ($Template);
        ($TemplateLine) = ($Template =~ /(�\w+�)/);
        $TemplateLine = "\n".$Whitespaces.$TemplateLine;
    }
    elsif ($Template =~ /�ReturnValue�/ ||
           $Template =~ /�Parameters�/) {
        ($TemplateLine) = ($Template =~ /(�\w+�)/);
    }
    
    # Replace template
    $g_ServerClassRPCMethodDefinition =~ s/$Template/$Value$TemplateLine/g;
}

# >--------------------------------------------------------------------------<
# > Subroutine: GetSpacesInFrontOfTemplateAtServerClassRPCMethodDefinition  <
# >             Returns string with spaces which are in front of a specified <
# >             template                                                     <
# > Parameter:  $Template -> Tag which specifies line in which the beginning <
# >                          spaces should be registered                     <
# > Return:     -                                                            <
# > Author:     A. Neidhardt                                                 <
# > Date:       22.02.2007                                                   <
# > Revision:   -                                                            <
# > Info:       -                                                            <
# >--------------------------------------------------------------------------<
sub GetSpacesInFrontOfTemplateAtServerClassRPCMethodDefinition {
    my ($Template)=@_;
    my $SpaceLine = "";
    
    if ($g_ServerClassRPCMethodDefinition =~ /\n\s+$Template/) {
        ($SpaceLine) = ($g_ServerClassRPCMethodDefinition =~ /\n(\s+)$Template/);
    }

    return $SpaceLine;
}

# >--------------------------------------------------------------------------<
# > Subroutine: AddRPCMethodToServerClassDefinitionTemplate                 <
# >             Add a newly defined RPC-method to template for server       <
# > Parameter:  -                                                            <
# > Return:     -                                                            <
# > Author:     A. Neidhardt                                                 <
# > Date:       19.02.2007                                                   <
# > Revision:   -                                                            <
# > Info:       -                                                            <
# >--------------------------------------------------------------------------<
sub AddRPCMethodToServerClassDefinitionTemplate {
    
    # Delete all template elements
    $g_ServerClassRPCMethodDefinition =~ s/�\w+�//g;
    # Delete all spaces in front of a ) and after a (
    $g_ServerClassRPCMethodDefinition =~ s/\s+\)/)/g;
    $g_ServerClassRPCMethodDefinition =~ s/\(\s+/(/g;
    # Delete all empty lines
    $g_ServerClassRPCMethodDefinition =~ s/\n\s*\n/\n/g;

    # Replace templatemarker for RPC-methods at ServerClassDefinitionTemplate
    $g_ServerClassDefinitionTemplate =~ s/�InterfaceFunctionDefinitions�/$g_ServerClassRPCMethodDefinition\n�InterfaceFunctionDefinitions�/g;
}

# >--------------------------------------------------------------------------<
# > Subroutine: InitNewServerProcRPCMethodDefinition                        <
# >             Prepares variables for templatereplacement of client RPC     <
# > Parameter:  -                                                            <
# > Return:     -                                                            <
# > Author:     A. Neidhardt                                                 <
# > Date:       06.03.2007                                                   <
# > Revision:   -                                                            <
# > Info:       -                                                            <
# >--------------------------------------------------------------------------<
sub InitNewServerProcRPCMethodDefinition {
    $g_ServerProcRPCMethodDefinition = $g_ServerProcRPCMethodDefinitionTemplate; 
}

# >--------------------------------------------------------------------------<
# > Subroutine: ReplaceTemplateAtServerProcRPCMethodDefinition             <
# >             Replace a template by a value                                <
# > Parameter:  $Template -> Expression which should be replaced
# >             $Value -> Expression which is new
# > Return:     -                                                            <
# > Author:     A. Neidhardt                                                 <
# > Date:       06.03.2007                                                   <
# > Revision:   -                                                            <
# > Info:       -                                                            <
# >--------------------------------------------------------------------------<
sub ReplaceTemplateAtServerProcRPCMethodDefinition {
    my ($Template,$Value)=@_;
    my $TemplateLine = "";
    my $WhiteSpaces = "";
    
    # Save templatelines which has to be added again
    if ($Template =~ /�VariableDefinitions�/ ||
        $Template =~ /�FillINVariables�/ ||
        $Template =~ /�SetDefaultParameterReturn�/ ||
        $Template =~ /�ErrorDelete�/ ||
        $Template =~ /�FillParameterReturn�/ ||
        $Template =~ /�FinalCleanUp�/ ||
        $Template =~ /�VariableInit�/) {
        $WhiteSpaces = GetSpacesInFrontOfTemplateAtServerProcRPCMethodDefinition($Template);
        ($TemplateLine) = ($Template =~ /(�\w+�)/);
        $TemplateLine = "\n".$WhiteSpaces.$TemplateLine;
    }
    elsif ($Template =~ /�ReturnValue�/ ||
           $Template =~ /�Parameters�/) {
        ($TemplateLine) = ($Template =~ /(�\w+�)/);
    }
    
    # Replace template
    $g_ServerProcRPCMethodDefinition =~ s/$Template/$Value$TemplateLine/g;
}

# >--------------------------------------------------------------------------<
# > Subroutine: GetSpacesInFrontOfTemplateAtServerProcRPCMethodDefinition   <
# >             Returns string with spaces which are in front of a specified <
# >             template                                                     <
# > Parameter:  $Template -> Tag which specifies line in which the beginning <
# >                          spaces should be registered                     <
# > Return:     -                                                            <
# > Author:     A. Neidhardt                                                 <
# > Date:       22.02.2007                                                   <
# > Revision:   -                                                            <
# > Info:       -                                                            <
# >--------------------------------------------------------------------------<
sub GetSpacesInFrontOfTemplateAtServerProcRPCMethodDefinition {
    my ($Template)=@_;
    my $SpaceLine = "";
    
    if ($g_ServerProcRPCMethodDefinition =~ /\n\s+$Template/) {
        ($SpaceLine) = ($g_ServerProcRPCMethodDefinition =~ /\n(\s+)$Template/);
    }

    return $SpaceLine;
}

# >--------------------------------------------------------------------------<
# > Subroutine: AddRPCMethodToServerProcDefinitionTemplate                 <
# >             Add a newly defined RPC-method to template for server proc  <
# > Parameter:  -                                                            <
# > Return:     -                                                            <
# > Author:     A. Neidhardt                                                 <
# > Date:       06.03.2007                                                   <
# > Revision:   -                                                            <
# > Info:       -                                                            <
# >--------------------------------------------------------------------------<
sub AddRPCMethodToServerProcDefinitionTemplate {
    
    # Delete all template elements
    $g_ServerProcRPCMethodDefinition =~ s/�\w+�//g;
    # Delete all spaces in front of a ) and after a (
    $g_ServerProcRPCMethodDefinition =~ s/\s+\)/)/g;
    $g_ServerProcRPCMethodDefinition =~ s/\(\s+/(/g;
    # Delete all empty lines
    $g_ServerProcRPCMethodDefinition =~ s/\n\s*\n/\n/g;

    # Replace templatemarker for RPC-methods at ServerProcDefinitionTemplate
    $g_ServerProcDefinitionTemplate =~ s/�InterfaceFunctionDefinitions�/$g_ServerProcRPCMethodDefinition\n�InterfaceFunctionDefinitions�/g;
}

# ===================================================================================
# Parser
# ------
# The following functions are for parsing the given IDL-file. It is a combination of
# a lexical scanner and a syntactical parser. The parser has some elements to save
# special conditions (e.g. global definitions) to check semantical background. The
# parser itself is in general a finite state machine.
# ===================================================================================

# >--------------------------------------------------------------------------<
# > Subroutine: ParseToken                                                   <
# >             Parser with syntactical and semantical parts for IDL. Correct<
# >             token start the creation of the resulting files.             <
# > Parameter:  $TokenType -> Token type                                     <
# >             $Token -> Token content                                      <
# >             $rState <-> Current parser state                             <
# >             $rNewTypes <-> Defined types                                 <
# >             $rNewConsts <-> Defined constants                            <
# >             $rCurrentNamespace <-> Current namespace environment         <
# >             $rDefinedIdentifiers <-> Namspace taged identifiers          <
# >             $rNumberOfNamespaceFunctions <-> Number of functions at      <
# >                                              current namespace           <
# > Return:     <- Errorcode (0 = ok, 1 = error)                             <
# > Author:     A. Neidhardt                                                 <
# > Date:       07.02.2007                                                   <
# > Revision:   -                                                            <
# > Info:       -                                                            <
# >--------------------------------------------------------------------------<
sub ParseToken {
    my ($TokenType,$Token,$IDLFilepath,$rState,$rNewTypes,$rNewConsts,
        $rCurrentNamespace,$rDefinedIdentifiers,$rNumberOfNamespaceFunctions,$ProgramNumberPrefix)=@_;
    my $Error = 0;
    my $ErrorMsg = "OK";
    my $NumberOfNewTypes = 0; # Number of already defined new types
    my $NumberOfNewConsts = 0;# Number of already defined new constants
    my $NewType;              # Iterator for new types
    my $NewConst;             # Iterator for new consts
    my $NumberOfIdentifier = 0; # Number of registrated identifiers
    my $IdentifierIndex;      # Index into identifier array
    my $Identifier;           # Single identifier
    my $RPCHeaderFilename;    # Headerfile created by rpcgen
    my $Spaces;               # Structuring white spaces
    my $HexRepresentation;    # Hexadecimal representation of a number

    # Check if given memory values for parsing are defined and define them if necessary
    if (!defined $$rCurrentNamespace) {
        $$rCurrentNamespace = "";
    }
    if (!defined $$rNumberOfNamespaceFunctions) {
        $$rNumberOfNamespaceFunctions = 0;
    }
    if (!defined ($rState -> {'Part'})) {
        $rState -> {'Part'} = 'IDL';
    }
    
    # Count number of defined identifiers
    foreach (@$rDefinedIdentifiers) {
        $NumberOfIdentifier = $NumberOfIdentifier + 1;
    }
    
    # Create RPC-headerfile name
    if ($IDLFilepath =~ /.*\/.*$/) {
        ($RPCHeaderFilename) = ($IDLFilepath =~ /.*\/(.*\.)idl$/);
    }
    else {
        ($RPCHeaderFilename) = ($IDLFilepath =~ /(.*\.)idl$/);
    }
    $RPCHeaderFilename = $RPCHeaderFilename."h";
    
    # Finite state machine
    if ($rState -> {'Part'} =~ /^IDL$/) {
        if ($TokenType =~ /^NEWTYPE$/) {
            $rState -> {'Part'} = 'NEWTYPE_PREP';
        }
        elsif ($TokenType =~ /^INTERFACE$/) {
            $rState -> {'Part'} = 'INTERFACE_PREP';
            $$rNumberOfNamespaceFunctions = 0;
        }
        elsif ($TokenType =~ /^NEWCONST$/) {
            $rState -> {'Part'} = 'CONST_PREP';
            AddToRPCX_DEFINITION_BLOCK ("const");
        }
        else {
            $Error = 2;
            $ErrorMsg = "Syntactical error at line";
        }
        goto ParseToken_Return;
    }
    
    if ($rState -> {'Part'} =~ /^CONST_PREP$/) {
        if ($TokenType =~ /^IDENTIFIER$/) {
            $rState -> {'Part'} = 'CONST_NAMED';
            # Count new types, so that an additional type can be added at the end of type array
            foreach  $NewConst (@$rNewConsts) {
                if ($Token =~ /^$NewConst$/) {
                    $Error = 2;
                    $ErrorMsg = "Syntactical error at line";
                    goto ParseToken_Return;
                }
                $NumberOfNewConsts = $NumberOfNewConsts + 1;
            }
            # Add newly defined const
            @$rNewConsts[$NumberOfNewConsts] = $Token;
            $NumberOfNewConsts = $NumberOfNewConsts + 1;
            # Semantical scheck if identifier already exists
            foreach $Identifier (@$rDefinedIdentifiers) {
                if ($Identifier =~ /^$Token$/) {
                   $Error = 3;
                   $ErrorMsg = "Semantical error at line";
                }
            }
            # Add global seen identifier to identifier list (for semantical schecks)
            @$rDefinedIdentifiers[$NumberOfIdentifier] = $Token;
            AddToRPCX_DEFINITION_BLOCK (" ".$Token);
        }
        else {
            $Error = 2;
            $ErrorMsg = "Syntactical error at line";
        }
        goto ParseToken_Return;
    }
    
    if ($rState -> {'Part'} =~ /^CONST_NAMED$/) {
        if ($TokenType =~ /^EQUAL$/) {
            $rState -> {'Part'} = 'CONST_EQUAL';
            AddToRPCX_DEFINITION_BLOCK (" ".$Token);
        }
        else {
            $Error = 2;
            $ErrorMsg = "Syntactical error at line";
        }
        goto ParseToken_Return;
    }
    
    if ($rState -> {'Part'} =~ /^CONST_EQUAL$/) {
        if ($TokenType =~ /^NUMBER$/) {
            $rState -> {'Part'} = 'CONST_FINISH';
            AddToRPCX_DEFINITION_BLOCK (" ".$Token);
        }
        elsif ($TokenType =~ /^STRING$/) {
            $rState -> {'Part'} = 'CONST_FINISH';
            AddToRPCX_DEFINITION_BLOCK (" ".$Token);
        }
        elsif ($TokenType =~ /^CONST$/) {
            $rState -> {'Part'} = 'CONST_FINISH';
            AddToRPCX_DEFINITION_BLOCK (" ".$Token);
        }
        else {
            $Error = 2;
            $ErrorMsg = "Syntactical error at line";
        }
        goto ParseToken_Return;
    }
    
    if ($rState -> {'Part'} =~ /^CONST_FINISH$/) {
        if ($TokenType =~ /^SEMICOLON$/) {
            $rState -> {'Part'} = 'IDL';
            AddToRPCX_DEFINITION_BLOCK (";\n");
        }
        else {
            $Error = 2;
            $ErrorMsg = "Syntactical error at line";
        }
        goto ParseToken_Return;
    }

    if ($rState -> {'Part'} =~ /^NEWTYPE_FINISH$/) {
        if ($TokenType =~ /^NEWTYPE$/) {
            $rState -> {'Part'} = 'NEWTYPE_PREP';
        }
        elsif ($TokenType =~ /^INTERFACE$/) {
            $rState -> {'Part'} = 'INTERFACE_PREP';
            $$rNumberOfNamespaceFunctions = 0;
        }
        else {
            $Error = 2;
            $ErrorMsg = "Syntactical error at line";
        }
        goto ParseToken_Return;
    }
    
    if ($rState -> {'Part'} =~ /^NEWTYPE_PREP$/) {
        if ($TokenType =~ /^STRUCT$/) {
            $rState -> {'Part'} = 'NEWTYPE_STRUCT';
            $$rCurrentNamespace = $$rCurrentNamespace.".";
            # Semantical scheck if identifier already exists
            foreach $Identifier (@$rDefinedIdentifiers) {
                if ($Identifier =~ /^$$rCurrentNamespace$/) {
                   $Error = 3;
                   $ErrorMsg = "Semantical error at line";
                }
            }
            # Add global seen identifier to identifier list (for semantical schecks)
            @$rDefinedIdentifiers[$NumberOfIdentifier] = $$rCurrentNamespace;
            # Add expression to definition
            AddToRPCX_DEFINITION_BLOCK ("struct ������� \n{\n");
        }
        else {
            $Error = 2;
            $ErrorMsg = "Syntactical error at line";
        }
        goto ParseToken_Return;
    }
     
    if ($rState -> {'Part'} =~ /^NEWTYPE_STRUCT$/) {
        if ($TokenType =~ /^ACCOLADEOPEN$/) {
            $rState -> {'Part'} = 'STRUCT_CONTENT';
        }
        else {
            $Error = 2;
            $ErrorMsg = "Syntactical error at line";
        }
        goto ParseToken_Return;
    }
     
    if ($rState -> {'Part'} =~ /^STRUCT_CONTENT$/) {
        if ($TokenType =~ /^TYPE$/) {
            $rState -> {'Part'} = 'VARIABLE_PREP';
            AddToRPCX_DEFINITION_BLOCK ("    ".$Token);
            NoteNewtypeType ($Token);
        }
        elsif ($TokenType =~ /^UNSIGNED$/) {
            $rState -> {'Part'} = 'VARIABLE_PREP_UNSIGNED';
            AddToRPCX_DEFINITION_BLOCK ("    ".$Token);
            NoteNewtypeType ($Token);
        }
        else {
            $Error = 2;
            $ErrorMsg = "Syntactical error at line";
        }
        goto ParseToken_Return;
    }

    if ($rState -> {'Part'} =~ /^VARIABLE_PREP_UNSIGNED$/) {
        if ($TokenType =~ /^TYPE$/) {
            $rState -> {'Part'} = 'VARIABLE_PREP';
            AddToRPCX_DEFINITION_BLOCK (" ".$Token);
            NoteNewtypeType ($Token);
        }
        else {
            $Error = 2;
            $ErrorMsg = "Syntactical error at line";
        }
        goto ParseToken_Return;
    }
     
    if ($rState -> {'Part'} =~ /^VARIABLE_PREP$/) {
        if ($TokenType =~ /^IDENTIFIER$/) {
            $rState -> {'Part'} = 'VARIABLE_NAMED';
            $$rCurrentNamespace = $$rCurrentNamespace.$Token;
            # Semantical scheck if identifier already exists
            foreach $Identifier (@$rDefinedIdentifiers) {
                if ($Identifier =~ /^$$rCurrentNamespace$/) {
                   $Error = 3;
                   $ErrorMsg = "Semantical error at line";
                }
            }
            # Add global seen identifier to identifier list (for semantical schecks)
            @$rDefinedIdentifiers[$NumberOfIdentifier] = $$rCurrentNamespace;
            AddToRPCX_DEFINITION_BLOCK (" ".$Token);
            NoteNewtypeIdentifier ($Token);
        }
        else {
            $Error = 2;
            $ErrorMsg = "Syntactical error at line";
        }
        goto ParseToken_Return;
    }
     
    if ($rState -> {'Part'} =~ /^VARIABLE_NAMED$/) {
        if ($TokenType =~ /^SEMICOLON$/) {
            $rState -> {'Part'} = 'VARIABLE_FINISH';
            ($$rCurrentNamespace) = ($$rCurrentNamespace =~ /(.*\.)\w+$/);
            AddToRPCX_DEFINITION_BLOCK ($Token."\n");
            if (GetNewtypeType() =~ /^char/) {
                AddToRPCX_DEFINITION_BLOCK ("    unsigned char Dummy_".GetNewtypeIdentifier().";\n");
            }
            else {
                AddToRPCX_DEFINITION_BLOCK ("    char Dummy_".GetNewtypeIdentifier().";\n");
            }
        }
        else {
            $Error = 2;
            $ErrorMsg = "Syntactical error at line";
        }
        goto ParseToken_Return;
    }
     
    if ($rState -> {'Part'} =~ /^VARIABLE_FINISH$/) {
        if ($TokenType =~ /^ACCOLADECLOSE$/) {
            $rState -> {'Part'} = 'STRUCT_FINISH';
        }
        elsif ($TokenType =~ /^TYPE$/) {
            $rState -> {'Part'} = 'VARIABLE_PREP';
            AddToRPCX_DEFINITION_BLOCK ("    ".$Token);
            NoteNewtypeType ($Token);
        }
        elsif ($TokenType =~ /^UNSIGNED$/) {
            $rState -> {'Part'} = 'VARIABLE_PREP_UNSIGNED';
            AddToRPCX_DEFINITION_BLOCK ("    ".$Token);
            NoteNewtypeType ($Token);
        }
        else {
            $Error = 2;
            $ErrorMsg = "Syntactical error at line";
        }
        goto ParseToken_Return;
    }
     
    if ($rState -> {'Part'} =~ /^STRUCT_FINISH$/) {
        if ($TokenType =~ /^IDENTIFIER$/) {
            $rState -> {'Part'} = 'NEWTYPE_NAMED';
            # Count new types, so that an additional type can be added at the end of type array
            foreach  $NewType (@$rNewTypes) {
                if ($Token =~ /^$NewType$/) {
                    $Error = 2;
                    $ErrorMsg = "Syntactical error at line";
                    goto ParseToken_Return;
                }
                $NumberOfNewTypes = $NumberOfNewTypes + 1;
            }
            # Add newly defined type
            @$rNewTypes[$NumberOfNewTypes] = $Token;
            $NumberOfNewTypes = $NumberOfNewTypes + 1;
            # Add global seen identifier to identifier list (for semantical schecks)
            for  ($IdentifierIndex = 0; $IdentifierIndex < $NumberOfIdentifier; $IdentifierIndex++) {
                if (@$rDefinedIdentifiers[$IdentifierIndex] =~ /^\.\w/) {
                    @$rDefinedIdentifiers[$IdentifierIndex] =~ s/\./$Token./g;
                } 
                if (@$rDefinedIdentifiers[$IdentifierIndex] =~ /^\.$/) {
                    @$rDefinedIdentifiers[$IdentifierIndex] =~ s/\./$Token/g;
                } 
            }
            $$rCurrentNamespace = "";
            AddToRPCX_DEFINITION_BLOCK ("};\n");
            AddToRPCX_DEFINITION_BLOCK ("typedef struct ".$Token."Struct ".$Token.";\n");
            ReplaceAtRPCX_DEFINITION_BLOCK ("�������",$Token."Struct");
        }
        else {
            $Error = 2;
            $ErrorMsg = "Syntactical error at line";
        }
        goto ParseToken_Return;
    }
     
    if ($rState -> {'Part'} =~ /^NEWTYPE_NAMED$/) {
        if ($TokenType =~ /^SEMICOLON$/) {
            $rState -> {'Part'} = 'NEWTYPE_FINISH';
        }
        else {
            $Error = 2;
            $ErrorMsg = "Syntactical error at line";
        }
        goto ParseToken_Return;
    }
   
    if ($rState -> {'Part'} =~ /^INTERFACE_PREP$/) {
        if ($TokenType =~ /^IDENTIFIER$/) {
            $rState -> {'Part'} = 'INTERFACE_VERSION';
            $$rCurrentNamespace = $$rCurrentNamespace.$Token;
            # Semantical scheck if identifier already exists
            foreach $Identifier (@$rDefinedIdentifiers) {
                if ($Identifier =~ /^$$rCurrentNamespace$/) {
                   $Error = 3;
                   $ErrorMsg = "Semantical error at line";
                }
            }
            # Add global seen identifier to identifier list (for semantical schecks)
            @$rDefinedIdentifiers[$NumberOfIdentifier] = $$rCurrentNamespace;
            AddToRPCX_PROGRAM_BLOCK ("program SAP_".$Token." {\n");
            AddToRPCX_PROGRAM_BLOCK ("    version SAP_VERS_".$Token." {\n");
            NoteClassIdentifier ($Token);
            NoteProgramNumber ($Token,$ProgramNumberPrefix);
        }
        else {
            $Error = 2;
            $ErrorMsg = "Syntactical error at line";
        }
        goto ParseToken_Return;
    }
    
    if ($rState -> {'Part'} =~ /^INTERFACE_VERSION$/) {
        if ($TokenType =~ /^ACCOLADEOPEN$/) {
            $rState -> {'Part'} = 'INTERFACE';
            AddToRPCX_PROGRAM_BLOCK ("        unsigned long ".lc(GetProgramName())."_basicping () = 1;\n");
            $$rNumberOfNamespaceFunctions = $$rNumberOfNamespaceFunctions + 1;
            AddToRPCX_PROGRAM_BLOCK ("        void ".lc(GetProgramName())."_basicresetserver () = 2;\n");
            $$rNumberOfNamespaceFunctions = $$rNumberOfNamespaceFunctions + 1;
            AddToRPCX_PROGRAM_BLOCK ("        OUT".GetProgramName()."CheckIDLVersionStruct ".lc(GetProgramName())."_basiccheckidlversion (IN".GetProgramName()."CheckIDLVersionType) = 3;\n");
            $$rNumberOfNamespaceFunctions = $$rNumberOfNamespaceFunctions + 1;
            AddToRPCX_DEFINITION_BLOCK ("struct IN".GetProgramName()."CheckIDLVersionStruct\
{\
    char strIDL2RPCVersion <>;\
    char Dummy_strIDL2RPCVersion;\
    char strInterfaceVersion <>;\
};\
typedef struct IN".GetProgramName()."CheckIDLVersionStruct IN".GetProgramName()."CheckIDLVersionType;
struct OUT".GetProgramName()."CheckIDLVersionStruct\
{\
    char strIDL2RPCVersion <>;\
    char Dummy_strIDL2RPCVersion;\
    char strInterfaceVersion <>;\
    char Dummy_strInterfaceVersion;\
    int _Ret;\
    unsigned short _operation_state;\
    char Dummy_Ret;\
    int iInterfaceVersionOK;\
    char Dummy_iInterfaceVersionOK;\
    int iIDL2RPCVersionOK;\
};\
typedef struct OUT".GetProgramName()."CheckIDLVersionStruct OUT".GetProgramName()."CheckIDLVersionType;\n");
        }
        elsif ($TokenType =~ /^VERSION$/){
            NoteInterfaceVersion($Token);
            $rState -> {'Part'} = 'INTERFACE_NAMED';
        }
        else {
            $Error = 2;
            $ErrorMsg = "Syntactical error at line";
        }
        goto ParseToken_Return;
    }
    
    if ($rState -> {'Part'} =~ /^INTERFACE_NAMED$/) {
        if ($TokenType =~ /^ACCOLADEOPEN$/) {
            $rState -> {'Part'} = 'INTERFACE';
            AddToRPCX_PROGRAM_BLOCK ("        unsigned long ".lc(GetProgramName())."_basicping () = 1;\n");
            $$rNumberOfNamespaceFunctions = $$rNumberOfNamespaceFunctions + 1;
            AddToRPCX_PROGRAM_BLOCK ("        void ".lc(GetProgramName())."_basicresetserver () = 2;\n");
            $$rNumberOfNamespaceFunctions = $$rNumberOfNamespaceFunctions + 1;
            AddToRPCX_PROGRAM_BLOCK ("        OUT".GetProgramName()."CheckIDLVersionStruct ".lc(GetProgramName())."_basiccheckidlversion (IN".GetProgramName()."CheckIDLVersionType) = 3;\n");
            $$rNumberOfNamespaceFunctions = $$rNumberOfNamespaceFunctions + 1;
            AddToRPCX_DEFINITION_BLOCK ("struct IN".GetProgramName()."CheckIDLVersionStruct\
{\
    char strIDL2RPCVersion <>;\
    char Dummy_strIDL2RPCVersion;\
    char strInterfaceVersion <>;\
};\
typedef struct IN".GetProgramName()."CheckIDLVersionStruct IN".GetProgramName()."CheckIDLVersionType;
struct OUT".GetProgramName()."CheckIDLVersionStruct\
{\
    char strIDL2RPCVersion <>;\
    char Dummy_strIDL2RPCVersion;\
    char strInterfaceVersion <>;\
    char Dummy_strInterfaceVersion;\
    int _Ret;\
    unsigned short _operation_state;\
    char Dummy_Ret;\
    int iInterfaceVersionOK;\
    char Dummy_iInterfaceVersionOK;\
    int iIDL2RPCVersionOK;\
};\
typedef struct OUT".GetProgramName()."CheckIDLVersionStruct OUT".GetProgramName()."CheckIDLVersionType;\n");
        }
        else {
            $Error = 2;
            $ErrorMsg = "Syntactical error at line";
        }
        goto ParseToken_Return;
    }

    if ($rState -> {'Part'} =~ /^INTERFACE$/) {
        if ($TokenType =~ /^ACCOLADECLOSE$/) {
            $rState -> {'Part'} = 'INTERFACE_FINISH';
        }
        elsif ($TokenType =~ /^TYPE$/) {
            $rState -> {'Part'} = 'FUNCTION_PREP';
            AddToRPCX_FUNCTION_OUTPUTSTRUCT ("struct OUTSAP".GetClassIdentifier()."�������Struct\n{\n");
            AddToRPCX_FUNCTION_OUTPUTSTRUCT ("    unsigned short _operation_state;\n");
            AddToRPCX_FUNCTION_OUTPUTSTRUCT ("    ".$Token." _Ret;\n");
            AddToRPCABSTRH_DEFINITION_BLOCK ("    virtual ".$Token);
            NoteFunctionReturnType ($Token);
            InitNewClientClassRPCMethodDefinition ();
            InitNewServerClassRPCMethodDefinition ();
            InitNewServerProcRPCMethodDefinition ();
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�ReturnValue�",$Token);
            ReplaceTemplateAtServerClassRPCMethodDefinition ("�ReturnValue�",$Token);
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�ReturnValue�","SOutput._Ret =");
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillParameterReturn�","ulReturnByteSum += sizeof(".$Token.");");
        }
        elsif ($TokenType =~ /^UNSIGNED$/) {
            $rState -> {'Part'} = 'FUNCTION_PREP_UNISGNED';
            AddToRPCX_FUNCTION_OUTPUTSTRUCT ("struct OUTSAP".GetClassIdentifier()."�������Struct\n{\n");
            AddToRPCX_FUNCTION_OUTPUTSTRUCT ("    unsigned short _operation_state;\n");
            AddToRPCX_FUNCTION_OUTPUTSTRUCT ("    ".$Token);
            AddToRPCABSTRH_DEFINITION_BLOCK ("    virtual ".$Token);
            NoteFunctionReturnType ($Token);
            InitNewClientClassRPCMethodDefinition ();
            InitNewServerClassRPCMethodDefinition ();
            InitNewServerProcRPCMethodDefinition ();
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�ReturnValue�",$Token);
            ReplaceTemplateAtServerClassRPCMethodDefinition ("�ReturnValue�",$Token);
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�ReturnValue�","SOutput._Ret =");
        }
        elsif ($TokenType =~ /^VOID$/) {
            $rState -> {'Part'} = 'FUNCTION_PREP';
            AddToRPCX_FUNCTION_OUTPUTSTRUCT ("struct OUTSAP".GetClassIdentifier()."�������Struct\n{\n");
            AddToRPCX_FUNCTION_OUTPUTSTRUCT ("    unsigned short _operation_state;\n");
            AddToRPCABSTRH_DEFINITION_BLOCK ("    virtual ".$Token);
            NoteFunctionReturnType ($Token);
            InitNewClientClassRPCMethodDefinition ();
            InitNewServerClassRPCMethodDefinition ();
            InitNewServerProcRPCMethodDefinition ();
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�ReturnValue�",$Token);
            ReplaceTemplateAtServerClassRPCMethodDefinition ("�ReturnValue�",$Token);
        }
        else {
            $Error = 2;
            $ErrorMsg = "Syntactical error at line";
        }
        goto ParseToken_Return;
    }
    
    if ($rState -> {'Part'} =~ /^FUNCTION_PREP_UNISGNED$/) {
        if ($TokenType =~ /^TYPE$/) {
            $rState -> {'Part'} = 'FUNCTION_PREP';
            AddToRPCX_FUNCTION_OUTPUTSTRUCT (" ".$Token." _Ret;\n");
            AddToRPCABSTRH_DEFINITION_BLOCK (" ".$Token);
            NoteFunctionReturnType (GetFunctionReturnType()." ".$Token);
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�ReturnValue�"," ".$Token);
            ReplaceTemplateAtServerClassRPCMethodDefinition ("�ReturnValue�"," ".$Token);
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillParameterReturn�","ulReturnByteSum += sizeof(".GetFunctionReturnType().");");
        }
        else {
            $Error = 2;
            $ErrorMsg = "Syntactical error at line";
        }
        goto ParseToken_Return;
    }
    
    if ($rState -> {'Part'} =~ /^INTERFACE_FINISH$/) {
        if ($TokenType =~ /^SEMICOLON$/) {
            $rState -> {'Part'} = 'IDL_FINISH';
            $$rCurrentNamespace = "";
            AddToRPCX_PROGRAM_BLOCK ("    } = 1;\n");
            AddToRPCX_PROGRAM_BLOCK ("} = ".GetProgramNumberHex().";\n");
            MergeDefinitionAndProgramBlock();
        }
        else {
            $Error = 2;
            $ErrorMsg = "Syntactical error at line";
        }
        goto ParseToken_Return;
    }
    
    if ($rState -> {'Part'} =~ /^IDL_FINISH$/) {
        $Error = 2;
        $ErrorMsg = "Syntactical error at line";
        goto ParseToken_Return;
    }
    
    if ($rState -> {'Part'} =~ /^FUNCTION_PREP$/) {
        if ($TokenType =~ /^IDENTIFIER$/) {
            $rState -> {'Part'} = 'FUNCTION_NAMED';
            $$rCurrentNamespace = $$rCurrentNamespace.".".$Token;
            # Semantical scheck if identifier already exists
            foreach $Identifier (@$rDefinedIdentifiers) {
                if ($Identifier =~ /^$$rCurrentNamespace$/) {
                   $Error = 3;
                   $ErrorMsg = "Semantical error at line";
                }
            }
            # Add global seen identifier to identifier list (for semantical schecks)
            @$rDefinedIdentifiers[$NumberOfIdentifier] = $$rCurrentNamespace;
            $$rNumberOfNamespaceFunctions = $$rNumberOfNamespaceFunctions + 1;
            ResetCopyRunnerVariableIsSet ();
            NoteFunctionIdentifier ($Token);
            ReplaceAtRPCX_FUNCTION_OUTPUTSTRUCT ("�������",$Token);
            AddToRPCABSTRH_DEFINITION_BLOCK (" ".$Token);
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�Interface�",GetClassIdentifier());
            ReplaceTemplateAtServerClassRPCMethodDefinition ("�Interface�",GetClassIdentifier());
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�Method�",$Token);
            ReplaceTemplateAtServerClassRPCMethodDefinition ("�Method�",$Token);
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�OUTVariableDefinition�","OUTSAP".GetClassIdentifier().$Token."Type * SOutput = NULL;");
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�OUTVariable�","SOutput =");
            if (!(GetFunctionReturnType() =~ /^void/)) {
                ReplaceTemplateAtClientClassRPCMethodDefinition ("�SetReturnValue�","priv_ulRoundTripByteSum += sizeof(".GetFunctionReturnType().");");
                ReplaceTemplateAtClientClassRPCMethodDefinition ("�SetReturnValue�","return SOutput->_Ret;");
            }
            else {
                ReplaceTemplateAtClientClassRPCMethodDefinition ("�SetReturnValue�","return;");
            }
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�RPCMethod�",lc(GetProgramName()."_".GetFunctionIdentifier()."_1_svc"));
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�OUTStruct�","OUTSAP".GetClassIdentifier().GetFunctionIdentifier()."Type *");
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�Method�",GetFunctionIdentifier());
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�OUTVariableDefinition�","static OUTSAP".GetClassIdentifier().GetFunctionIdentifier()."Type SOutput;");
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillINVariables�","vResetDynVarMemory();");
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillINVariables�","SOutput._operation_state = 1; // Operation started");
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillParameterReturn�","SOutput._operation_state = 0; // Operation successfully done");
            #ReplaceTemplateAtServerProcRPCMethodDefinition ("�SetDefaultParameterReturn�","SOutput._operation_state = 2; // Operation with errors");
            #ReplaceTemplateAtServerProcRPCMethodDefinition ("�SetDefaultParameterReturn�","return &SOutput;");
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�SetReturnValue�","return &SOutput;");
        }
        else {
            $Error = 2;
            $ErrorMsg = "Syntactical error at line";
        }
        goto ParseToken_Return;
    }
    
    if ($rState -> {'Part'} =~ /^FUNCTION_NAMED$/) {
        if ($TokenType =~ /^BRACKETOPEN$/) {
            $rState -> {'Part'} = 'FUNCTION_PARAMETER';
            AddToRPCABSTRH_DEFINITION_BLOCK (" ".$Token);
            if ($g_ASD) {
                ReplaceTemplateAtServerProcRPCMethodDefinition ("�ASDTouch�", "g_".GetClassIdentifier()."CASDServerThread.vTouch();");
            }
            else {
                ReplaceTemplateAtServerProcRPCMethodDefinition ("�ASDTouch�", "");
            }
        }
        elsif ($TokenType =~ /^NOASD$/) {
            $rState -> {'Part'} = 'FUNCTION_NOASD';
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�ASDTouch�", "");
        }
        else {
            $Error = 2;
            $ErrorMsg = "Syntactical error at line";
        }
        goto ParseToken_Return;
    }
    
    if ($rState -> {'Part'} =~ /^FUNCTION_NOASD$/) {
        if ($TokenType =~ /^BRACKETOPEN$/) {
            $rState -> {'Part'} = 'FUNCTION_PARAMETER';
            AddToRPCABSTRH_DEFINITION_BLOCK (" ".$Token);
        }
        else {
            $Error = 2;
            $ErrorMsg = "Syntactical error at line";
        }
        goto ParseToken_Return;
    }

    if ($rState -> {'Part'} =~ /^FUNCTION_PARAMETER$/) {
        if ($TokenType =~ /^BRACKETCLOSE$/) {
            $rState -> {'Part'} = 'FUNCTION_FINISH';
            AddToRPCABSTRH_DEFINITION_BLOCK (" ".$Token);
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�INVariableDefinition�","void * vInput = NULL;");
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�INVariable�","vInput");
        }
        elsif ($TokenType =~ /^IO$/) {
            $rState -> {'Part'} = 'FUNCTION_PARAMETER_IO';
            NoteParameterIO ($Token);
            if (ParameterIsInput ()) {
                if (!FunctionHasInputStructure()) {
                    AddToRPCX_FUNCTION_INPUTSTRUCT ("struct INSAP".GetClassIdentifier().GetFunctionIdentifier()."Struct\n{\n");
                }
            }
            if (ParameterIsOutput ()) {
                if (!FunctionHasOutputStructure()) {
                    AddToRPCX_FUNCTION_OUTPUTSTRUCT ("struct OUTSAP".GetClassIdentifier().GetFunctionIdentifier()."Struct\n{\n");
                }
            }
            if (ParameterIsInput ()) {
                ReplaceTemplateAtClientClassRPCMethodDefinition ("�INVariableDefinition�","INSAP".GetClassIdentifier().GetFunctionIdentifier()."Type SInput;");
                ReplaceTemplateAtClientClassRPCMethodDefinition ("�INVariable�","&SInput");
                ReplaceTemplateAtServerProcRPCMethodDefinition ("�INStruct�","INSAP".GetClassIdentifier().GetFunctionIdentifier()."Type * pSInput");
            }
        }
        else {
            $Error = 2;
            $ErrorMsg = "Syntactical error at line";
        }
        goto ParseToken_Return;
    }

    if ($rState -> {'Part'} =~ /^FUNCTION_FINISH$/) {
        if ($TokenType =~ /^SEMICOLON$/) {
            $rState -> {'Part'} = 'INTERFACE';
            ($$rCurrentNamespace) = ($$rCurrentNamespace =~ /(.*)\.\w+$/);
            if (FunctionHasInputStructure()) {
                AddToRPCX_FUNCTION_INPUTSTRUCT ("};\n");
                AddToRPCX_FUNCTION_INPUTSTRUCT ("typedef struct INSAP".GetClassIdentifier().GetFunctionIdentifier()."Struct INSAP".GetClassIdentifier().GetFunctionIdentifier()."Type;\n");
            }
            if (FunctionHasOutputStructure()) {
                AddToRPCX_FUNCTION_OUTPUTSTRUCT ("};\n");
                AddToRPCX_FUNCTION_OUTPUTSTRUCT ("typedef struct OUTSAP".GetClassIdentifier().GetFunctionIdentifier()."Struct OUTSAP".GetClassIdentifier().GetFunctionIdentifier()."Type;\n");
            }
            if (FunctionHasOutputStructure()) {
                AddToRPCX_PROGRAM_BLOCK ("        OUTSAP".GetClassIdentifier().GetFunctionIdentifier()."Type ");
            }
            else {
                AddToRPCX_PROGRAM_BLOCK ("        void ");
            }
            AddToRPCX_PROGRAM_BLOCK (lc(GetProgramName()."_".GetFunctionIdentifier()));
            if (FunctionHasInputStructure()) {
                AddToRPCX_PROGRAM_BLOCK (" (INSAP".GetClassIdentifier().GetFunctionIdentifier()."Type) = ".$$rNumberOfNamespaceFunctions.";\n");
            }
            else {
                AddToRPCX_PROGRAM_BLOCK (" () = ".$$rNumberOfNamespaceFunctions.";\n");
            }
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�RPCFunction�",lc(GetProgramName()."_".GetFunctionIdentifier()."_1"));
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�INStruct�","void * pSInput");
            NoteFunctionIdentifier ("");
            AddFunctionStructuresToRPCX_DEFINITION_BLOCK ();
            AddToRPCABSTRH_DEFINITION_BLOCK (" = 0;\n");
            AddRPCMethodToClientClassDefinitionTemplate ();
            AddRPCMethodToServerClassDefinitionTemplate ();
            AddRPCMethodToServerProcDefinitionTemplate ();
        }
        else {
            $Error = 2;
            $ErrorMsg = "Syntactical error at line";
        }
        goto ParseToken_Return;
    }

    if ($rState -> {'Part'} =~ /^FUNCTION_PARAMETER_IO$/) {
        if ($TokenType =~ /^TYPE$/) {
            $rState -> {'Part'} = 'FUNCTION_PARAMETER_PREP';
            NoteParameterType ($Token);
            if (ParameterIsInput ()) {
                AddToRPCX_FUNCTION_INPUTSTRUCT ("    ".$Token);
#                if (!ParameterIsOutput ()) {
#                    AddToRPCABSTRH_DEFINITION_BLOCK (" const");
#                    ReplaceTemplateAtClientClassRPCMethodDefinition ("�Parameters�"," const");
#                    ReplaceTemplateAtServerClassRPCMethodDefinition ("�Parameters�"," const");
#                }
            }
            if (ParameterIsOutput ()) {
                AddToRPCX_FUNCTION_OUTPUTSTRUCT ("    ".$Token);
            }
            AddToRPCABSTRH_DEFINITION_BLOCK (" ".$Token." �");
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�Parameters�"," ".$Token." ��DeRef��");
            ReplaceTemplateAtServerClassRPCMethodDefinition ("�Parameters�"," ".$Token." ��DeRef��");
        }
        elsif ($TokenType =~ /^UNSIGNED$/) {
            $rState -> {'Part'} = 'FUNCTION_PARAMETER_PREP_UNISGNED';
            NoteParameterType ($Token);
            if (ParameterIsInput ()) {
                AddToRPCX_FUNCTION_INPUTSTRUCT ("    ".$Token);
#                if (!ParameterIsOutput ()) {
#                    AddToRPCABSTRH_DEFINITION_BLOCK (" const");
#                    ReplaceTemplateAtClientClassRPCMethodDefinition ("�Parameters�"," const");
#                    ReplaceTemplateAtServerClassRPCMethodDefinition ("�Parameters�"," const");
#                }
            }
            if (ParameterIsOutput ()) {
                AddToRPCX_FUNCTION_OUTPUTSTRUCT ("    ".$Token);
            }
            AddToRPCABSTRH_DEFINITION_BLOCK (" ".$Token);
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�Parameters�"," ".$Token);
            ReplaceTemplateAtServerClassRPCMethodDefinition ("�Parameters�"," ".$Token);
        }
        elsif ($TokenType =~ /^TYPESTRING$/) {
            $rState -> {'Part'} = 'FUNCTION_PARAMETER_STRING';
            NoteParameterType ($Token);
            if (ParameterIsInput ()) {
                AddToRPCX_FUNCTION_INPUTSTRUCT ("    char");
#                if (!ParameterIsOutput ()) {
#                    AddToRPCABSTRH_DEFINITION_BLOCK (" const");
#                    ReplaceTemplateAtClientClassRPCMethodDefinition ("�Parameters�"," const");
#                    ReplaceTemplateAtServerClassRPCMethodDefinition ("�Parameters�"," const");
#                }
            }
            if (ParameterIsOutput ()) {
                AddToRPCX_FUNCTION_OUTPUTSTRUCT ("    char");
            }
            AddToRPCABSTRH_DEFINITION_BLOCK (" std::".$Token." �");
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�Parameters�"," std::".$Token." ��DeRef��");
            ReplaceTemplateAtServerClassRPCMethodDefinition ("�Parameters�"," std::".$Token." ��DeRef��");
        }
        else {
            $Error = 2;
            $ErrorMsg = "Syntactical error at line";
        }
        goto ParseToken_Return;
    }

    if ($rState -> {'Part'} =~ /^FUNCTION_PARAMETER_PREP_UNISGNED$/) {
        if ($TokenType =~ /^TYPE$/) {
            $rState -> {'Part'} = 'FUNCTION_PARAMETER_PREP';
            NoteParameterType ($Token);
            if (ParameterIsInput ()) {
                AddToRPCX_FUNCTION_INPUTSTRUCT (" ".$Token);
            }
            if (ParameterIsOutput ()) {
                AddToRPCX_FUNCTION_OUTPUTSTRUCT (" ".$Token);
            }
            AddToRPCABSTRH_DEFINITION_BLOCK (" ".$Token." �");
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�Parameters�"," ".$Token." ��DeRef��");
            ReplaceTemplateAtServerClassRPCMethodDefinition ("�Parameters�"," ".$Token." ��DeRef��");
        }
        else {
            $Error = 2;
            $ErrorMsg = "Syntactical error at line";
        }
        goto ParseToken_Return;
    }
    
    if ($rState -> {'Part'} =~ /^FUNCTION_PARAMETER_STRING$/) {
        if ($TokenType =~ /^IDENTIFIER$/) {
            if ($Token =~ /^_Ret$/) {
                $Error = 3;
                $ErrorMsg = "Semantical error at line";
            }
            $rState -> {'Part'} = 'FUNCTION_PARAMETER_STRING_NAMED';
            $$rCurrentNamespace = $$rCurrentNamespace.".".$Token;
            # Semantical scheck if identifier already exists
            foreach $Identifier (@$rDefinedIdentifiers) {
                if ($Identifier =~ /^$$rCurrentNamespace$/) {
                   $Error = 3;
                   $ErrorMsg = "Semantical error at line";
                }
            }
            # Add global seen identifier to identifier list (for semantical schecks)
            @$rDefinedIdentifiers[$NumberOfIdentifier] = $$rCurrentNamespace;
            NoteParameterIdentifier ($Token);
            if (ParameterIsInput ()) {
                AddToRPCX_FUNCTION_INPUTSTRUCT (" ".$Token." <>");
            }
            if (ParameterIsOutput ()) {
                AddToRPCX_FUNCTION_OUTPUTSTRUCT (" ".$Token." <>");
                AddToRPCABSTRH_DEFINITION_BLOCK (" & ");
            }
            InitRPCX_LENVARIABLE_FOR_PARAMETER ($Token);
            AddToRPCABSTRH_DEFINITION_BLOCK (" ".$Token);
            InitRPCABSTRH_LENVARIABLE_FOR_PARAMETER ($Token);
            InitRPCCPP_LENVARIABLE_FOR_PARAMETER ($Token);
            if (ParameterIsOutput ()) {
                ReplaceTemplateAtClientClassRPCMethodDefinition ("�Parameters�"," &");
                ReplaceTemplateAtServerClassRPCMethodDefinition ("�Parameters�"," &");
            }
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�Parameters�"," ".$Token);
            ReplaceTemplateAtServerClassRPCMethodDefinition ("�Parameters�"," ".$Token);
        }
        else {
            $Error = 2;
            $ErrorMsg = "Syntactical error at line";
        }
        goto ParseToken_Return;
    }
    
    if ($rState -> {'Part'} =~ /^FUNCTION_PARAMETER_STRING_NAMED$/) {
        if ($TokenType =~ /^VARLENGTH$/) {
            $rState -> {'Part'} = 'FUNCTION_PARAMETER_MULTISTRING';
            if (ParameterIsInput ()) {
                # Add dummy variables to prevent compiler warnings in xdr because of optimisation
                AddToRPCX_FUNCTION_INPUTSTRUCT (";\n    char Dummy_".GetParameterIdentifier()."");
                AddLENVARIABLEToRPCX_FUNCTION_INPUTSTRUCT ();
            }
            if (ParameterIsOutput ()) {
                # Add dummy variables to prevent compiler warnings in xdr because of optimisation
                AddToRPCX_FUNCTION_OUTPUTSTRUCT (";\n    char Dummy_".GetParameterIdentifier()."");
                AddLENVARIABLEToRPCX_FUNCTION_OUTPUTSTRUCT ();
            }
            NextRPCX_LENVARIABLE_FOR_PARAMETER ();
            ReplaceAtRPCABSTRH_DEFINITION_BLOCK ("�","*�");
            AddToRPCABSTRH_DEFINITION_BLOCK ("_val");
            AddToRPCABSTRH_LENVARIABLE ();
            ReplaceTemplateAtClientClassRPCMethodDefinition ("��DeRef��"," *��DeRef��");
            ReplaceTemplateAtServerClassRPCMethodDefinition ("��DeRef��"," *��DeRef��");
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�Parameters�","_val");
            ReplaceTemplateAtServerClassRPCMethodDefinition ("�Parameters�","_val");
            NextRPCCPP_LENVARIABLE_FOR_PARAMETER ();
        }
        elsif ($TokenType =~ /^COMMA$/) {
            $rState -> {'Part'} = 'FUNCTION_PARAMETER';
            ($$rCurrentNamespace) = ($$rCurrentNamespace =~ /(.*)\.\w+$/);
            if (ParameterIsInput ()) {
                AddToRPCX_FUNCTION_INPUTSTRUCT (";\n");
                # Add dummy variables to prevent compiler warnings in xdr because of optimisation
                AddToRPCX_FUNCTION_INPUTSTRUCT ("    char Dummy_".GetParameterIdentifier().";\n");
            }
            if (ParameterIsOutput ()) {
                AddToRPCX_FUNCTION_OUTPUTSTRUCT (";\n");
                # Add dummy variables to prevent compiler warnings in xdr because of optimisation
                AddToRPCX_FUNCTION_OUTPUTSTRUCT ("    char Dummy_".GetParameterIdentifier().";\n");
            }
            AddToRPCABSTRH_DEFINITION_BLOCK (",");
            ReplaceAtRPCABSTRH_DEFINITION_BLOCK ("�","");
            ReplaceTemplateAtClientClassRPCMethodDefinition ("��DeRef��","");
            ReplaceTemplateAtServerClassRPCMethodDefinition ("��DeRef��","");
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�Parameters�",",");
            ReplaceTemplateAtServerClassRPCMethodDefinition ("�Parameters�",",");
            if (ParameterIsInput ()) {
                ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillINVariables�","SInput.".GetParameterIdentifier().".".GetParameterIdentifier()."_val = (char *) ".GetParameterIdentifier().".c_str();");
                ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillINVariables�","SInput.".GetParameterIdentifier().".".GetParameterIdentifier()."_len = ".GetParameterIdentifier().".length()+1;");
                ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillINVariables�","priv_ulRoundTripByteSum += ((".GetParameterIdentifier().".length()+1)*sizeof(char));");
            }
            if (ParameterIsOutput ()) {
                $Spaces = GetSpacesInFrontOfTemplateAtServerProcRPCMethodDefinition("�FillParameterReturn�");
                ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillParameterReturn�","if (SOutput != NULL &&");
                ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillParameterReturn�","    SOutput->".GetParameterIdentifier().".".GetParameterIdentifier()."_val != NULL)");
                ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillParameterReturn�","{");
                ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillParameterReturn�",$Spaces.GetParameterIdentifier()." = SOutput->".GetParameterIdentifier().".".GetParameterIdentifier()."_val;");
                ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillParameterReturn�",$Spaces."priv_ulRoundTripByteSum += ((".GetParameterIdentifier().".length()+1)*sizeof(char));");
                ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillParameterReturn�","}");
                ReplaceTemplateAtClientClassRPCMethodDefinition ("�FinalCleanUp�","if (SOutput != NULL &&");
                ReplaceTemplateAtClientClassRPCMethodDefinition ("�FinalCleanUp�","    SOutput->".GetParameterIdentifier().".".GetParameterIdentifier()."_val != NULL)");
                ReplaceTemplateAtClientClassRPCMethodDefinition ("�FinalCleanUp�","{");
                ReplaceTemplateAtClientClassRPCMethodDefinition ("�FinalCleanUp�","    free (SOutput->".GetParameterIdentifier().".".GetParameterIdentifier()."_val);");
                ReplaceTemplateAtClientClassRPCMethodDefinition ("�FinalCleanUp�","    SOutput->".GetParameterIdentifier().".".GetParameterIdentifier()."_val = NULL;");
                ReplaceTemplateAtClientClassRPCMethodDefinition ("�FinalCleanUp�","    SOutput->".GetParameterIdentifier().".".GetParameterIdentifier()."_len = 0;");
                ReplaceTemplateAtClientClassRPCMethodDefinition ("�FinalCleanUp�","}");
            }
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�VariableDefinitions�","std::string ".GetParameterIdentifier().";");
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�Parameters�",GetParameterIdentifier());
            if (ParameterIsInput ()) {
                ReplaceTemplateAtServerProcRPCMethodDefinition ("�VariableDefinitions�",GetParameterIdentifier()." = pSInput->".GetParameterIdentifier().".".GetParameterIdentifier()."_val;");
                ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillParameterReturn�","free (pSInput->".GetParameterIdentifier().".".GetParameterIdentifier()."_val);");
                ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillParameterReturn�","pSInput->".GetParameterIdentifier().".".GetParameterIdentifier()."_val = NULL;");
                ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillParameterReturn�","pSInput->".GetParameterIdentifier().".".GetParameterIdentifier()."_len = 0;");
                $Spaces = GetSpacesInFrontOfTemplateAtServerProcRPCMethodDefinition("�SetDefaultParameterReturn�");
                ReplaceTemplateAtServerProcRPCMethodDefinition ("�SetDefaultParameterReturn�","if (pSInput->".GetParameterIdentifier().".".GetParameterIdentifier()."_val != NULL)");
                ReplaceTemplateAtServerProcRPCMethodDefinition ("�SetDefaultParameterReturn�","{");
                ReplaceTemplateAtServerProcRPCMethodDefinition ("�SetDefaultParameterReturn�",$Spaces."free (pSInput->".GetParameterIdentifier().".".GetParameterIdentifier()."_val);");
                ReplaceTemplateAtServerProcRPCMethodDefinition ("�SetDefaultParameterReturn�",$Spaces."pSInput->".GetParameterIdentifier().".".GetParameterIdentifier()."_val = NULL;");
                ReplaceTemplateAtServerProcRPCMethodDefinition ("�SetDefaultParameterReturn�",$Spaces."pSInput->".GetParameterIdentifier().".".GetParameterIdentifier()."_len = 0;");
                ReplaceTemplateAtServerProcRPCMethodDefinition ("�SetDefaultParameterReturn�","}");
            }
            if (ParameterIsOutput ()) {
                $Spaces = GetSpacesInFrontOfTemplateAtServerProcRPCMethodDefinition("�VariableInit�");
                ReplaceTemplateAtServerProcRPCMethodDefinition ("�VariableInit�","SOutput.".GetParameterIdentifier().".".GetParameterIdentifier()."_val = NULL;");
                ReplaceTemplateAtServerProcRPCMethodDefinition ("�VariableInit�","SOutput.".GetParameterIdentifier().".".GetParameterIdentifier()."_len = 0;");
                $Spaces = GetSpacesInFrontOfTemplateAtServerProcRPCMethodDefinition("�FinalCleanUp�");
                ReplaceTemplateAtServerProcRPCMethodDefinition ("�SetDefaultParameterReturn�","if (SOutput.".GetParameterIdentifier().".".GetParameterIdentifier()."_val != NULL)");
                ReplaceTemplateAtServerProcRPCMethodDefinition ("�SetDefaultParameterReturn�","{");
                ReplaceTemplateAtServerProcRPCMethodDefinition ("�SetDefaultParameterReturn�",$Spaces."free (SOutput.".GetParameterIdentifier().".".GetParameterIdentifier()."_val);");
                ReplaceTemplateAtServerProcRPCMethodDefinition ("�SetDefaultParameterReturn�",$Spaces."SOutput.".GetParameterIdentifier().".".GetParameterIdentifier()."_val = NULL;");
                ReplaceTemplateAtServerProcRPCMethodDefinition ("�SetDefaultParameterReturn�",$Spaces."SOutput.".GetParameterIdentifier().".".GetParameterIdentifier()."_len = 0;");
                ReplaceTemplateAtServerProcRPCMethodDefinition ("�SetDefaultParameterReturn�","}");
            }
            if (ParameterIsOutput ()) {
                if (!ParameterIsInput ()) {
                    ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillParameterReturn�","SOutput.".GetParameterIdentifier().".".GetParameterIdentifier()."_val = NULL;");
                    ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillParameterReturn�","SOutput.".GetParameterIdentifier().".".GetParameterIdentifier()."_len = 0;");
                }
                $Spaces = GetSpacesInFrontOfTemplateAtServerProcRPCMethodDefinition("�FillParameterReturn�");
                ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillParameterReturn�","if (ulGetNextDynVarIndex() == MAXDYNVARIABLES)");
                ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillParameterReturn�","{");
                ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillParameterReturn�",$Spaces."__usInternalError = 1;");
                ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillParameterReturn�",$Spaces."SOutput._operation_state = 4; // Too many parameter");
                ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillParameterReturn�",$Spaces."goto ".lc(GetProgramName()."_".GetFunctionIdentifier()."_1_svc")."_Return;");
                ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillParameterReturn�","}");
                ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillParameterReturn�","if ((SOutput.".GetParameterIdentifier().".".GetParameterIdentifier()."_val = (char *) malloc (sizeof(char)*(".GetParameterIdentifier().".length()+1))) == NULL)");
                ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillParameterReturn�","{");
                ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillParameterReturn�",$Spaces."__usInternalError = 1;");
                ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillParameterReturn�",$Spaces."SOutput._operation_state = 3; // Memory error");
                ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillParameterReturn�",$Spaces."goto ".lc(GetProgramName()."_".GetFunctionIdentifier()."_1_svc")."_Return;");
                ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillParameterReturn�","}");
                ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillParameterReturn�","strcpy (SOutput.".GetParameterIdentifier().".".GetParameterIdentifier()."_val, ".GetParameterIdentifier().".c_str());");
                ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillParameterReturn�","SOutput.".GetParameterIdentifier().".".GetParameterIdentifier()."_len = ".GetParameterIdentifier().".length()+1;");
                ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillParameterReturn�","ulReturnByteSum += SOutput.".GetParameterIdentifier().".".GetParameterIdentifier()."_len;");
                ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillParameterReturn�","g_pvDynVarMemory[ulGetNextDynVarIndex()] = SOutput.".GetParameterIdentifier().".".GetParameterIdentifier()."_val;");
            }
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�Parameters�",", ");
        }
        elsif ($TokenType =~ /^BRACKETCLOSE$/) {
            $rState -> {'Part'} = 'FUNCTION_FINISH';
            ($$rCurrentNamespace) = ($$rCurrentNamespace =~ /(.*)\.\w+$/);
            if (ParameterIsInput ()) {
                AddToRPCX_FUNCTION_INPUTSTRUCT (";\n");
            }
            if (ParameterIsOutput ()) {
                AddToRPCX_FUNCTION_OUTPUTSTRUCT (";\n");
            }
            AddToRPCABSTRH_DEFINITION_BLOCK (")");
            ReplaceAtRPCABSTRH_DEFINITION_BLOCK ("�","");
            ReplaceTemplateAtClientClassRPCMethodDefinition ("��DeRef��","");
            ReplaceTemplateAtServerClassRPCMethodDefinition ("��DeRef��","");
            if (ParameterIsInput ()) {
                ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillINVariables�","SInput.".GetParameterIdentifier().".".GetParameterIdentifier()."_val = (char *) ".GetParameterIdentifier().".c_str();");
                ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillINVariables�","SInput.".GetParameterIdentifier().".".GetParameterIdentifier()."_len = ".GetParameterIdentifier().".length()+1;");
                ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillINVariables�","priv_ulRoundTripByteSum += ((".GetParameterIdentifier().".length()+1)*sizeof(char));");
            }
            if (ParameterIsOutput ()) {
                $Spaces = GetSpacesInFrontOfTemplateAtServerProcRPCMethodDefinition("�FillParameterReturn�");
                ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillParameterReturn�","if (SOutput != NULL &&");
                ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillParameterReturn�","    SOutput->".GetParameterIdentifier().".".GetParameterIdentifier()."_val != NULL)");
                ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillParameterReturn�","{");
                ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillParameterReturn�",$Spaces.GetParameterIdentifier()." = SOutput->".GetParameterIdentifier().".".GetParameterIdentifier()."_val;");
                ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillParameterReturn�",$Spaces."priv_ulRoundTripByteSum += ((".GetParameterIdentifier().".length()+1)*sizeof(char));");
                ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillParameterReturn�","}");
                ReplaceTemplateAtClientClassRPCMethodDefinition ("�FinalCleanUp�","if (SOutput != NULL &&");
                ReplaceTemplateAtClientClassRPCMethodDefinition ("�FinalCleanUp�","    SOutput->".GetParameterIdentifier().".".GetParameterIdentifier()."_val != NULL)");
                ReplaceTemplateAtClientClassRPCMethodDefinition ("�FinalCleanUp�","{");
                ReplaceTemplateAtClientClassRPCMethodDefinition ("�FinalCleanUp�","    free (SOutput->".GetParameterIdentifier().".".GetParameterIdentifier()."_val);");
                ReplaceTemplateAtClientClassRPCMethodDefinition ("�FinalCleanUp�","    SOutput->".GetParameterIdentifier().".".GetParameterIdentifier()."_val = NULL;");
                ReplaceTemplateAtClientClassRPCMethodDefinition ("�FinalCleanUp�","    SOutput->".GetParameterIdentifier().".".GetParameterIdentifier()."_len = 0;");
                ReplaceTemplateAtClientClassRPCMethodDefinition ("�FinalCleanUp�","}");
            }
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�INVariableDefinition�","void * vInput = NULL;");
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�INVariable�","vInput");
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�VariableDefinitions�","std::string ".GetParameterIdentifier().";");
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�Parameters�",GetParameterIdentifier());
            if (ParameterIsInput ()) {
                ReplaceTemplateAtServerProcRPCMethodDefinition ("�VariableDefinitions�",GetParameterIdentifier()." = pSInput->".GetParameterIdentifier().".".GetParameterIdentifier()."_val;");
                ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillParameterReturn�","free (pSInput->".GetParameterIdentifier().".".GetParameterIdentifier()."_val);");
                ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillParameterReturn�","pSInput->".GetParameterIdentifier().".".GetParameterIdentifier()."_val = NULL;");
                ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillParameterReturn�","pSInput->".GetParameterIdentifier().".".GetParameterIdentifier()."_len = 0;");
                $Spaces = GetSpacesInFrontOfTemplateAtServerProcRPCMethodDefinition("�SetDefaultParameterReturn�");
                ReplaceTemplateAtServerProcRPCMethodDefinition ("�SetDefaultParameterReturn�","if (pSInput->".GetParameterIdentifier().".".GetParameterIdentifier()."_val != NULL)");
                ReplaceTemplateAtServerProcRPCMethodDefinition ("�SetDefaultParameterReturn�","{");
                ReplaceTemplateAtServerProcRPCMethodDefinition ("�SetDefaultParameterReturn�",$Spaces."free (pSInput->".GetParameterIdentifier().".".GetParameterIdentifier()."_val);");
                ReplaceTemplateAtServerProcRPCMethodDefinition ("�SetDefaultParameterReturn�",$Spaces."pSInput->".GetParameterIdentifier().".".GetParameterIdentifier()."_val = NULL;");
                ReplaceTemplateAtServerProcRPCMethodDefinition ("�SetDefaultParameterReturn�",$Spaces."pSInput->".GetParameterIdentifier().".".GetParameterIdentifier()."_len = 0;");
                ReplaceTemplateAtServerProcRPCMethodDefinition ("�SetDefaultParameterReturn�","}");
            }
            if (ParameterIsOutput ()) {
                $Spaces = GetSpacesInFrontOfTemplateAtServerProcRPCMethodDefinition("�VariableInit�");
                ReplaceTemplateAtServerProcRPCMethodDefinition ("�VariableInit�","SOutput.".GetParameterIdentifier().".".GetParameterIdentifier()."_val = NULL;");
                ReplaceTemplateAtServerProcRPCMethodDefinition ("�VariableInit�","SOutput.".GetParameterIdentifier().".".GetParameterIdentifier()."_len = 0;");
                $Spaces = GetSpacesInFrontOfTemplateAtServerProcRPCMethodDefinition("�FinalCleanUp�");
                ReplaceTemplateAtServerProcRPCMethodDefinition ("�SetDefaultParameterReturn�","if (SOutput.".GetParameterIdentifier().".".GetParameterIdentifier()."_val != NULL)");
                ReplaceTemplateAtServerProcRPCMethodDefinition ("�SetDefaultParameterReturn�","{");
                ReplaceTemplateAtServerProcRPCMethodDefinition ("�SetDefaultParameterReturn�",$Spaces."free (SOutput.".GetParameterIdentifier().".".GetParameterIdentifier()."_val);");
                ReplaceTemplateAtServerProcRPCMethodDefinition ("�SetDefaultParameterReturn�",$Spaces."SOutput.".GetParameterIdentifier().".".GetParameterIdentifier()."_val = NULL;");
                ReplaceTemplateAtServerProcRPCMethodDefinition ("�SetDefaultParameterReturn�",$Spaces."SOutput.".GetParameterIdentifier().".".GetParameterIdentifier()."_len = 0;");
                ReplaceTemplateAtServerProcRPCMethodDefinition ("�SetDefaultParameterReturn�","}");
            }
            if (ParameterIsOutput ()) {
                if (!ParameterIsInput ()) {
                    ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillParameterReturn�","SOutput.".GetParameterIdentifier().".".GetParameterIdentifier()."_val = NULL;");
                    ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillParameterReturn�","SOutput.".GetParameterIdentifier().".".GetParameterIdentifier()."_len = 0;");
                }
                $Spaces = GetSpacesInFrontOfTemplateAtServerProcRPCMethodDefinition("�FillParameterReturn�");
                ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillParameterReturn�","if (ulGetNextDynVarIndex() == MAXDYNVARIABLES)");
                ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillParameterReturn�","{");
                ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillParameterReturn�",$Spaces."__usInternalError = 1;");
                ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillParameterReturn�",$Spaces."SOutput._operation_state = 4; // Too many parameter");
                ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillParameterReturn�",$Spaces."goto ".lc(GetProgramName()."_".GetFunctionIdentifier()."_1_svc")."_Return;");
                ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillParameterReturn�","}");
                ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillParameterReturn�","if ((SOutput.".GetParameterIdentifier().".".GetParameterIdentifier()."_val = (char *) malloc (sizeof(char)*(".GetParameterIdentifier().".length()+1))) == NULL)");
                ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillParameterReturn�","{");
                ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillParameterReturn�",$Spaces."__usInternalError = 1;");
                ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillParameterReturn�",$Spaces."SOutput._operation_state = 3; // Memory error");
                ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillParameterReturn�",$Spaces."goto ".lc(GetProgramName()."_".GetFunctionIdentifier()."_1_svc")."_Return;");
                ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillParameterReturn�","}");
                ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillParameterReturn�","strcpy (SOutput.".GetParameterIdentifier().".".GetParameterIdentifier()."_val, ".GetParameterIdentifier().".c_str());");
                ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillParameterReturn�","SOutput.".GetParameterIdentifier().".".GetParameterIdentifier()."_len = ".GetParameterIdentifier().".length()+1;");
                ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillParameterReturn�","ulReturnByteSum += SOutput.".GetParameterIdentifier().".".GetParameterIdentifier()."_len;");
                ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillParameterReturn�","g_pvDynVarMemory[ulGetNextDynVarIndex()] = SOutput.".GetParameterIdentifier().".".GetParameterIdentifier()."_val;");
            }
        }
        else {
            $Error = 2;
            $ErrorMsg = "Syntactical error at line";
        }
        goto ParseToken_Return;
    }

    if ($rState -> {'Part'} =~ /^FUNCTION_PARAMETER_PREP$/) {
        if ($TokenType =~ /^IDENTIFIER$/) {
            if ($Token =~ /^_Ret$/) {
                $Error = 3;
                $ErrorMsg = "Semantical error at line";
            }
            $rState -> {'Part'} = 'FUNCTION_PARAMETER_NAMED';
            $$rCurrentNamespace = $$rCurrentNamespace.".".$Token;
            # Semantical scheck if identifier already exists
            foreach $Identifier (@$rDefinedIdentifiers) {
                if ($Identifier =~ /^$$rCurrentNamespace$/) {
                   $Error = 3;
                   $ErrorMsg = "Semantical error at line";
                }
            }
            # Add global seen identifier to identifier list (for semantical schecks)
            @$rDefinedIdentifiers[$NumberOfIdentifier] = $$rCurrentNamespace;
            NoteParameterIdentifier ($Token);
            if (ParameterIsInput ()) {
                AddToRPCX_FUNCTION_INPUTSTRUCT (" ".$Token);
            }
            if (ParameterIsOutput ()) {
                AddToRPCX_FUNCTION_OUTPUTSTRUCT (" ".$Token);
                AddToRPCABSTRH_DEFINITION_BLOCK (" &");
            }
            AddToRPCABSTRH_DEFINITION_BLOCK (" ".$Token);
            InitRPCABSTRH_LENVARIABLE_FOR_PARAMETER ($Token);
            InitRPCCPP_LENVARIABLE_FOR_PARAMETER ($Token);
            if (ParameterIsOutput ()) {
                ReplaceTemplateAtClientClassRPCMethodDefinition ("�Parameters�"," &");
                ReplaceTemplateAtServerClassRPCMethodDefinition ("�Parameters�"," &");
            }
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�Parameters�"," ".$Token);
            ReplaceTemplateAtServerClassRPCMethodDefinition ("�Parameters�"," ".$Token);
        }
        else {
            $Error = 2;
            $ErrorMsg = "Syntactical error at line";
        }
        goto ParseToken_Return;
    }

    if ($rState -> {'Part'} =~ /^FUNCTION_PARAMETER_NAMED$/) {
        if ($TokenType =~ /^COMMA$/) {
            $rState -> {'Part'} = 'FUNCTION_PARAMETER';
            ($$rCurrentNamespace) = ($$rCurrentNamespace =~ /(.*)\.\w+$/);
            if (ParameterIsInput ()) {
                AddToRPCX_FUNCTION_INPUTSTRUCT (";\n");
                # Add dummy variables to prevent compiler warnings in xdr because of optimisation
                if (GetParameterType() =~ /^char$/) {
                    AddToRPCX_FUNCTION_INPUTSTRUCT ("    unsigned char Dummy_".GetParameterIdentifier().";\n");
                }
                else {
                    AddToRPCX_FUNCTION_INPUTSTRUCT ("    char Dummy_".GetParameterIdentifier().";\n");
                }
            }
            if (ParameterIsOutput ()) {
                AddToRPCX_FUNCTION_OUTPUTSTRUCT (";\n");
                # Add dummy variables to prevent compiler warnings in xdr because of optimisation
                if (GetParameterType() =~ /^char$/) {
                    AddToRPCX_FUNCTION_OUTPUTSTRUCT ("    unsigned char Dummy_".GetParameterIdentifier().";\n");
                }
                else {
                    AddToRPCX_FUNCTION_OUTPUTSTRUCT ("    char Dummy_".GetParameterIdentifier().";\n");
                }
            }
            AddToRPCABSTRH_DEFINITION_BLOCK (",");
            ReplaceAtRPCABSTRH_DEFINITION_BLOCK ("�","");
            ReplaceTemplateAtClientClassRPCMethodDefinition ("��DeRef��","");
            ReplaceTemplateAtServerClassRPCMethodDefinition ("��DeRef��","");
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�Parameters�",",");
            ReplaceTemplateAtServerClassRPCMethodDefinition ("�Parameters�",",");
            if (ParameterIsInput ()) {
                ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillINVariables�","SInput.".GetParameterIdentifier()." = ".GetParameterIdentifier().";");
                ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillINVariables�","priv_ulRoundTripByteSum += sizeof(".GetParameterType().");");
            }
            if (ParameterIsOutput ()) {
                ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillParameterReturn�",GetParameterIdentifier()." = SOutput->".GetParameterIdentifier().";");
                ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillParameterReturn�","priv_ulRoundTripByteSum += sizeof(".GetParameterType().");");
            }
            if (ParameterIsInput ()) {
                ReplaceTemplateAtServerProcRPCMethodDefinition ("�Parameters�","pSInput->".GetParameterIdentifier());
            }
            if (ParameterIsOutput ()) {
                if (ParameterIsInput ()) {
                    ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillParameterReturn�","SOutput.".GetParameterIdentifier()."= pSInput->".GetParameterIdentifier().";");
                }
                else {
                    ReplaceTemplateAtServerProcRPCMethodDefinition ("�Parameters�","SOutput.".GetParameterIdentifier());
                }
                ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillParameterReturn�","ulReturnByteSum += sizeof(".GetParameterType().");");
            }
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�Parameters�",", ");
        }
        elsif ($TokenType =~ /^BRACKETCLOSE$/) {
            $rState -> {'Part'} = 'FUNCTION_FINISH';
            ($$rCurrentNamespace) = ($$rCurrentNamespace =~ /(.*)\.\w+$/);
            if (ParameterIsInput ()) {
                AddToRPCX_FUNCTION_INPUTSTRUCT (";\n");
            }
            if (ParameterIsOutput ()) {
                AddToRPCX_FUNCTION_OUTPUTSTRUCT (";\n");
            }
            AddToRPCABSTRH_DEFINITION_BLOCK (")");
            ReplaceAtRPCABSTRH_DEFINITION_BLOCK ("�","");
            ReplaceTemplateAtClientClassRPCMethodDefinition ("��DeRef��","");
            ReplaceTemplateAtServerClassRPCMethodDefinition ("��DeRef��","");
            if (ParameterIsInput ()) {
                ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillINVariables�","SInput.".GetParameterIdentifier()." = ".GetParameterIdentifier().";");
                ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillINVariables�","priv_ulRoundTripByteSum += sizeof(".GetParameterType().");");
            }
            if (ParameterIsOutput ()) {
                ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillParameterReturn�",GetParameterIdentifier()." = SOutput->".GetParameterIdentifier().";");
                ReplaceTemplateAtClientClassRPCMethodDefinition ("�FillParameterReturn�","priv_ulRoundTripByteSum += sizeof(".GetParameterType().");");
            }
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�INVariableDefinition�","void * vInput = NULL;");
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�INVariable�","vInput");
            if (ParameterIsInput ()) {
                ReplaceTemplateAtServerProcRPCMethodDefinition ("�Parameters�","pSInput->".GetParameterIdentifier());
            }
            if (ParameterIsOutput ()) {
                if (ParameterIsInput ()) {
                    ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillParameterReturn�","SOutput.".GetParameterIdentifier()."= pSInput->".GetParameterIdentifier().";");
                }
                else {
                    ReplaceTemplateAtServerProcRPCMethodDefinition ("�Parameters�","SOutput.".GetParameterIdentifier());
                }
                ReplaceTemplateAtServerProcRPCMethodDefinition ("�FillParameterReturn�","ulReturnByteSum += sizeof(".GetParameterType().");");
            }
        }
        elsif ($TokenType =~ /^VARLENGTH$/) {
            $rState -> {'Part'} = 'FUNCTION_PARAMETER_VARLENGTH';
            if (ParameterIsInput ()) {
                AddToRPCX_FUNCTION_INPUTSTRUCT (" ".$Token);
                # Add dummy variables to prevent compiler warnings in xdr because of optimisation
                if (GetParameterType() =~ /^char$/) {
                    AddToRPCX_FUNCTION_INPUTSTRUCT (";\n    unsigned char Dummy_".GetParameterIdentifier()."");
                }
                else {
                    AddToRPCX_FUNCTION_INPUTSTRUCT (";\n    char Dummy_".GetParameterIdentifier()."");
                }
                AddLENVARIABLEToRPCX_FUNCTION_INPUTSTRUCT ();
            }
            if (ParameterIsOutput ()) {
                AddToRPCX_FUNCTION_OUTPUTSTRUCT (" ".$Token);
                # Add dummy variables to prevent compiler warnings in xdr because of optimisation
                if (GetParameterType() =~ /^char$/) {
                    AddToRPCX_FUNCTION_OUTPUTSTRUCT (";\n    unsigned char Dummy_".GetParameterIdentifier()."");
                }
                else {
                    AddToRPCX_FUNCTION_OUTPUTSTRUCT (";\n    char Dummy_".GetParameterIdentifier()."");
                }
                AddLENVARIABLEToRPCX_FUNCTION_OUTPUTSTRUCT ();
            }
            NextRPCX_LENVARIABLE_FOR_PARAMETER ();
            ReplaceAtRPCABSTRH_DEFINITION_BLOCK ("�","*�");
            AddToRPCABSTRH_DEFINITION_BLOCK ("_val");
            AddToRPCABSTRH_LENVARIABLE ();
            ReplaceTemplateAtClientClassRPCMethodDefinition ("��DeRef��"," *��DeRef��");
            ReplaceTemplateAtServerClassRPCMethodDefinition ("��DeRef��"," *��DeRef��");
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�Parameters�","_val");
            ReplaceTemplateAtServerClassRPCMethodDefinition ("�Parameters�","_val");
            NextRPCCPP_LENVARIABLE_FOR_PARAMETER ();
        }
        else {
            $Error = 2;
            $ErrorMsg = "Syntactical error at line";
        }
        goto ParseToken_Return;
    }

    if ($rState -> {'Part'} =~ /^FUNCTION_PARAMETER_VARLENGTH$/) {
        if ($TokenType =~ /^COMMA$/) {
            $rState -> {'Part'} = 'FUNCTION_PARAMETER';
            ($$rCurrentNamespace) = ($$rCurrentNamespace =~ /(.*)\.\w+$/);
            if (ParameterIsInput ()) {
                AddToRPCX_FUNCTION_INPUTSTRUCT (";\n");
            }
            if (ParameterIsOutput ()) {
                AddToRPCX_FUNCTION_OUTPUTSTRUCT (";\n");
            }
            AddToRPCABSTRH_DEFINITION_BLOCK (",");
            ReplaceAtRPCABSTRH_DEFINITION_BLOCK ("�","");
            AddToRPCCLIENTCPP_DYNAMICARRAY ();
            AddToRPCSERVERPROCCPP_DYNAMICARRAY ();
            AddToRPCSERVERCPP_DYNAMICARRAY ();
            ReplaceTemplateAtClientClassRPCMethodDefinition ("��DeRef��","");
            ReplaceTemplateAtServerClassRPCMethodDefinition ("��DeRef��","");
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�Parameters�",",");
            ReplaceTemplateAtServerClassRPCMethodDefinition ("�Parameters�",",");
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�Parameters�",", ");
            ResetRPCCLIENTCPP_TemporaryTemplates ();
            ResetRPCProcRPC_TemporaryTemplates ();
        }
        elsif ($TokenType =~ /^BRACKETCLOSE$/) {
            $rState -> {'Part'} = 'FUNCTION_FINISH';
            ($$rCurrentNamespace) = ($$rCurrentNamespace =~ /(.*)\.\w+$/);
            if (ParameterIsInput ()) {
                AddToRPCX_FUNCTION_INPUTSTRUCT (";\n");
            }
            if (ParameterIsOutput ()) {
                AddToRPCX_FUNCTION_OUTPUTSTRUCT (";\n");
            }
            AddToRPCABSTRH_DEFINITION_BLOCK (")");
            ReplaceAtRPCABSTRH_DEFINITION_BLOCK ("�","");
            AddToRPCCLIENTCPP_DYNAMICARRAY ();
            AddToRPCSERVERPROCCPP_DYNAMICARRAY ();
            AddToRPCSERVERCPP_DYNAMICARRAY ();
            ReplaceTemplateAtClientClassRPCMethodDefinition ("��DeRef��","");
            ReplaceTemplateAtServerClassRPCMethodDefinition ("��DeRef��","");
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�INVariableDefinition�","void * vInput = NULL;");
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�INVariable�","vInput");
            ResetRPCCLIENTCPP_TemporaryTemplates ();
            ResetRPCProcRPC_TemporaryTemplates ();
        }
        elsif ($TokenType =~ /^VARLENGTH$/) {
            $rState -> {'Part'} = 'FUNCTION_PARAMETER_MULTIVARLENGTH';
            if (ParameterIsInput ()) {
               AddLENVARIABLEToRPCX_FUNCTION_INPUTSTRUCT ();
            }
            if (ParameterIsOutput ()) {
               AddLENVARIABLEToRPCX_FUNCTION_OUTPUTSTRUCT ();
            }
            NextRPCX_LENVARIABLE_FOR_PARAMETER ();
            ReplaceAtRPCABSTRH_DEFINITION_BLOCK ("�","*�");
            AddToRPCABSTRH_LENVARIABLE ();
            ReplaceTemplateAtClientClassRPCMethodDefinition ("��DeRef��","*��DeRef��");
            ReplaceTemplateAtServerClassRPCMethodDefinition ("��DeRef��","*��DeRef��");
            NextRPCCPP_LENVARIABLE_FOR_PARAMETER ();
        }
        else {
            $Error = 2;
            $ErrorMsg = "Syntactical error at line";
        }
        goto ParseToken_Return;
    }

    if ($rState -> {'Part'} =~ /^FUNCTION_PARAMETER_MULTIVARLENGTH$/) {
        if ($TokenType =~ /^COMMA$/) {
            $rState -> {'Part'} = 'FUNCTION_PARAMETER';
            ($$rCurrentNamespace) = ($$rCurrentNamespace =~ /(.*)\.\w+$/);
            if (ParameterIsInput ()) {
                AddToRPCX_FUNCTION_INPUTSTRUCT (";\n");
            }
            if (ParameterIsOutput ()) {
                AddToRPCX_FUNCTION_OUTPUTSTRUCT (";\n");
            }
            AddToRPCABSTRH_DEFINITION_BLOCK (",");
            ReplaceAtRPCABSTRH_DEFINITION_BLOCK ("�","");
            AddToRPCCLIENTCPP_DYNAMICARRAY ();
            AddToRPCSERVERPROCCPP_DYNAMICARRAY ();
            AddToRPCSERVERCPP_DYNAMICARRAY ();
            ReplaceTemplateAtClientClassRPCMethodDefinition ("��DeRef��","");
            ReplaceTemplateAtServerClassRPCMethodDefinition ("��DeRef��","");
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�Parameters�",",");
            ReplaceTemplateAtServerClassRPCMethodDefinition ("�Parameters�",",");
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�Parameters�",", ");
            ResetRPCCLIENTCPP_TemporaryTemplates ();
            ResetRPCProcRPC_TemporaryTemplates ();
        }
        elsif ($TokenType =~ /^BRACKETCLOSE$/) {
            $rState -> {'Part'} = 'FUNCTION_FINISH';
            ($$rCurrentNamespace) = ($$rCurrentNamespace =~ /(.*)\.\w+$/);
            if (ParameterIsInput ()) {
                AddToRPCX_FUNCTION_INPUTSTRUCT (";\n");
            }
            if (ParameterIsOutput ()) {
                AddToRPCX_FUNCTION_OUTPUTSTRUCT (";\n");
            }
            AddToRPCABSTRH_DEFINITION_BLOCK (")");
            ReplaceAtRPCABSTRH_DEFINITION_BLOCK ("�","");
            AddToRPCCLIENTCPP_DYNAMICARRAY ();
            AddToRPCSERVERPROCCPP_DYNAMICARRAY ();
            AddToRPCSERVERCPP_DYNAMICARRAY ();
            ReplaceTemplateAtClientClassRPCMethodDefinition ("��DeRef��","");
            ReplaceTemplateAtServerClassRPCMethodDefinition ("��DeRef��","");
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�INVariableDefinition�","void * vInput = NULL;");
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�INVariable�","vInput");
            ResetRPCCLIENTCPP_TemporaryTemplates ();
            ResetRPCProcRPC_TemporaryTemplates ();
        }
        elsif ($TokenType =~ /^VARLENGTH$/) {
            $rState -> {'Part'} = 'FUNCTION_PARAMETER_MULTIVARLENGTH';
            if (ParameterIsInput ()) {
               AddLENVARIABLEToRPCX_FUNCTION_INPUTSTRUCT ();
            }
            if (ParameterIsOutput ()) {
               AddLENVARIABLEToRPCX_FUNCTION_OUTPUTSTRUCT ();
            }
            NextRPCX_LENVARIABLE_FOR_PARAMETER ();
            ReplaceAtRPCABSTRH_DEFINITION_BLOCK ("�","*�");
            AddToRPCABSTRH_LENVARIABLE ();
            ReplaceTemplateAtClientClassRPCMethodDefinition ("��DeRef��","*��DeRef��");
            ReplaceTemplateAtServerClassRPCMethodDefinition ("��DeRef��","*��DeRef��");
            NextRPCCPP_LENVARIABLE_FOR_PARAMETER ();
        }
        else {
            $Error = 2;
            $ErrorMsg = "Syntactical error at line";
        }
        goto ParseToken_Return;
    }

    if ($rState -> {'Part'} =~ /^FUNCTION_PARAMETER_MULTISTRING$/) {
        if ($TokenType =~ /^COMMA$/) {
            $rState -> {'Part'} = 'FUNCTION_PARAMETER';
            ($$rCurrentNamespace) = ($$rCurrentNamespace =~ /(.*)\.\w+$/);
            if (ParameterIsInput ()) {
                AddToRPCX_FUNCTION_INPUTSTRUCT (";\n");
            }
            if (ParameterIsOutput ()) {
                AddToRPCX_FUNCTION_OUTPUTSTRUCT (";\n");
            }
            AddToRPCABSTRH_DEFINITION_BLOCK (",");
            ReplaceAtRPCABSTRH_DEFINITION_BLOCK ("�","");
            AddToRPCCLIENTCPP_DYNAMICSTRINGARRAY ();
            AddToRPCSERVERPROCCPP_DYNAMICSTRINGARRAY ();
            AddToRPCSERVERCPP_DYNAMICSTRINGARRAY ();
            ReplaceTemplateAtClientClassRPCMethodDefinition ("��DeRef��","");
            ReplaceTemplateAtServerClassRPCMethodDefinition ("��DeRef��","");
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�Parameters�",",");
            ReplaceTemplateAtServerClassRPCMethodDefinition ("�Parameters�",",");
            ReplaceTemplateAtServerProcRPCMethodDefinition ("�Parameters�",", ");
            ResetRPCCLIENTCPP_TemporaryTemplates ();
            ResetRPCProcRPC_TemporaryTemplates ();
        }
        elsif ($TokenType =~ /^BRACKETCLOSE$/) {
            $rState -> {'Part'} = 'FUNCTION_FINISH';
            ($$rCurrentNamespace) = ($$rCurrentNamespace =~ /(.*)\.\w+$/);
            if (ParameterIsInput ()) {
                AddToRPCX_FUNCTION_INPUTSTRUCT (";\n");
            }
            if (ParameterIsOutput ()) {
                AddToRPCX_FUNCTION_OUTPUTSTRUCT (";\n");
            }
            AddToRPCABSTRH_DEFINITION_BLOCK (")");
            ReplaceAtRPCABSTRH_DEFINITION_BLOCK ("�","");
            AddToRPCCLIENTCPP_DYNAMICSTRINGARRAY ();
            AddToRPCSERVERPROCCPP_DYNAMICSTRINGARRAY ();
            AddToRPCSERVERCPP_DYNAMICSTRINGARRAY ();
            ReplaceTemplateAtClientClassRPCMethodDefinition ("��DeRef��","");
            ReplaceTemplateAtServerClassRPCMethodDefinition ("��DeRef��","");
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�INVariableDefinition�","void * vInput = NULL;");
            ReplaceTemplateAtClientClassRPCMethodDefinition ("�INVariable�","vInput");
            ResetRPCCLIENTCPP_TemporaryTemplates ();
            ResetRPCProcRPC_TemporaryTemplates ();
        }
        elsif ($TokenType =~ /^VARLENGTH$/) {
            $rState -> {'Part'} = 'FUNCTION_PARAMETER_MULTISTRING';
            if (ParameterIsInput ()) {
               AddLENVARIABLEToRPCX_FUNCTION_INPUTSTRUCT ();
            }
            if (ParameterIsOutput ()) {
               AddLENVARIABLEToRPCX_FUNCTION_OUTPUTSTRUCT ();
            }
            NextRPCX_LENVARIABLE_FOR_PARAMETER ();
            ReplaceAtRPCABSTRH_DEFINITION_BLOCK ("�","*�");
            AddToRPCABSTRH_LENVARIABLE ();
            ReplaceTemplateAtClientClassRPCMethodDefinition ("��DeRef��","*��DeRef��");
            ReplaceTemplateAtServerClassRPCMethodDefinition ("��DeRef��","*��DeRef��");
            NextRPCCPP_LENVARIABLE_FOR_PARAMETER ();
        }
        else {
            $Error = 2;
            $ErrorMsg = "Syntactical error at line";
        }
        goto ParseToken_Return;
    }

    $Error = 3;
    $ErrorMsg = "Internal finite state machine error: state not defined";

    ParseToken_Return:
    if ($Error) {
        $ErrorMsg = "(TOKEN='".$Token."') ".$ErrorMsg;
    }
    return ($Error,$ErrorMsg);
}

# >--------------------------------------------------------------------------<
# > Subroutine: Scanner                                                      <
# >             Prepares input: delete white spaces, delete '\n' etc. and    <
# >             hand tokens over to parser                                   <
# > Parameter:  $IDLFilepath -> Filepath to IDL-file                         <
# > Return:     <- Errorinfo: Error (0=ok, 1=error)                          <
# >                           Error message                                  <
# >                           Line number                                    <
# >                           Line content                                   <
# > Author:     A. Neidhardt                                                 <
# > Date:       02.02.2007                                                   <
# > Revision:   -                                                            <
# > Info:       -                                                            <
# >--------------------------------------------------------------------------<
sub Scanner {
    my ($IDLFilepath,$ProgramNumberPrefix)=@_;
    my $Line = "";        # Read line
    my $OrigLine = "";    # Originally read line
    my $Error = 0;        # Errorcode
    my $ErrorMsg = "OK";  # Errorcode
    my $Count = 0;        # Linecounter
    my %ParserState;      # State
    my $Token;            # Token content
    my $TokenType;        # Identified token type
    my $LineRest;         # Rest of the scanned line
    my @NewTypes;         # With typedef defined new types
    my $NewType;          # Iterator for types
    my @NewConsts;        # With const defined new constants
    my $NewConst;         # Iterator for constants
    my @DefinedIdentifiers; # Identifiers of current namespace
    my $CurrentNamespace; # Current namespace of identifiers
    my $NumberOfNamespaceFunctions; # Current number of functions at namespace
    my @SplitLine;        # Helping element to split line into command and comment

    # Check if IDL-file has extension ".idl"
    if (!($IDLFilepath =~ /.*\.idl$/)) {
        return (1,"File ".$IDLFilepath." has wrong extension!",0,"");
    }
    
    # Open file (old style open, so that older perl versions can handle it)
    open (FileHandle,"< $IDLFilepath") or return (1,"Can't open file ".$IDLFilepath."!",0,"");

    # Read lines until needed information is completed
    while (($Line = <FileHandle>)) {
        $Count = $Count + 1;
        $OrigLine = $Line;
        # Replace white spaces
        $Line =~ s/\s+/ /g;
        $Line =~ s/^\s+//g;
        $Line =~ s/\s+$//g;
        # Delete comments starting with //
        if ($Line =~ /^.*\/+\/.*$/) {
            @SplitLine = split(/\//, $Line);
            $Line = $SplitLine[0];
            if (!defined $Line) {
                $Line = "";
            }
        }

        while (length($Line) > 0) {
            # Qualifier
            if ($Line =~ /^interface(\W.*)?$/) {
                $Token = 'interface';
                $TokenType = 'INTERFACE';
                ($LineRest) = ($Line =~ /^interface(.*)/);
            }
            elsif ($Line =~ /^const(\W.*)?$/) {
                $Token = 'const';
                $TokenType = 'NEWCONST';
                ($LineRest) = ($Line =~ /^const(.*)/);
            }
            elsif ($Line =~ /^typedef(\W.*)?$/) {
                $Token = 'typedef';
                $TokenType = 'NEWTYPE';
                ($LineRest) = ($Line =~ /^typedef(.*)/);
            }
            elsif ($Line =~ /^struct(\W.*)?$/) {
                $Token = 'struct';
                $TokenType = 'STRUCT';
                ($LineRest) = ($Line =~ /^struct(.*)/);
            }
            elsif ($Line =~ /^in(\W.*)?$/) {
                $Token = 'in';
                $TokenType = 'IO';
                ($LineRest) = ($Line =~ /^in(.*)/);
            }
            elsif ($Line =~ /^out(\W.*)?$/) {
                $Token = 'out';
                $TokenType = 'IO';
                ($LineRest) = ($Line =~ /^out(.*)/);
            }
            elsif ($Line =~ /^inout(\W.*)?$/) {
                $Token = 'inout';
                $TokenType = 'IO';
                ($LineRest) = ($Line =~ /^inout(.*)/);
            }
            elsif ($Line =~ /^short(\W.*)?$/) {
                $Token = 'short';
                $TokenType = 'TYPE';
                ($LineRest) = ($Line =~ /^short(.*)/);
            }
            elsif ($Line =~ /^int(\W.*)?$/) {
                $Token = 'int';
                $TokenType = 'TYPE';
                ($LineRest) = ($Line =~ /^int(.*)/);
            }
            elsif ($Line =~ /^long(\W.*)?$/) {
                $Token = 'long';
                $TokenType = 'TYPE';
                ($LineRest) = ($Line =~ /^long(.*)/);
            }
            elsif ($Line =~ /^float(\W.*)?$/) {
                $Token = 'float';
                $TokenType = 'TYPE';
                ($LineRest) = ($Line =~ /^float(.*)/);
            }
            elsif ($Line =~ /^double(\W.*)?$/) {
                $Token = 'double';
                $TokenType = 'TYPE';
                ($LineRest) = ($Line =~ /^double(.*)/);
            }
            elsif ($Line =~ /^char(\W.*)?$/) {
                $Token = 'char';
                $TokenType = 'TYPE';
                ($LineRest) = ($Line =~ /^char(.*)/);
            }
            elsif ($Line =~ /^string(\W.*)?$/) {
                $Token = 'string';
                $TokenType = 'TYPESTRING';
                ($LineRest) = ($Line =~ /^string(.*)/);
            }
            elsif ($Line =~ /^void(\W.*)?$/) {
                $Token = 'void';
                $TokenType = 'VOID';
                ($LineRest) = ($Line =~ /^void(.*)/);
            }
            elsif ($Line =~ /^unsigned(\W.*)?$/) {
                $Token = 'unsigned';
                $TokenType = 'UNSIGNED';
                ($LineRest) = ($Line =~ /^unsigned(.*)/);
            }
           # Qualifiing character
            elsif ($Line =~ /^{/) {
                $Token = '{';
                $TokenType = 'ACCOLADEOPEN';
                ($LineRest) = ($Line =~ /^{(.*)/);
            }
            elsif ($Line =~ /^}/) {
                $Token = '}';
                $TokenType = 'ACCOLADECLOSE';
                ($LineRest) = ($Line =~ /^}(.*)/);
            }
            elsif ($Line =~ /^\(/) {
                $Token = '(';
                $TokenType = 'BRACKETOPEN';
                ($LineRest) = ($Line =~ /^\((.*)/);
            }
            elsif ($Line =~ /^\)/) {
                $Token = ')';
                $TokenType = 'BRACKETCLOSE';
                ($LineRest) = ($Line =~ /^\)(.*)/);
            }
            elsif ($Line =~ /^,/) {
                $Token = ',';
                $TokenType = 'COMMA';
                ($LineRest) = ($Line =~ /^,(.*)/);
            }
            elsif ($Line =~ /^;/) {
                $Token = ';';
                $TokenType = 'SEMICOLON';
                ($LineRest) = ($Line =~ /^;(.*)/);
            }
            elsif ($Line =~ /^<>/) {
                $Token = '<>';
                $TokenType = 'VARLENGTH';
                ($LineRest) = ($Line =~ /^<>(.*)/);
            }
            elsif ($Line =~ /^=/) {
                $Token = '=';
                $TokenType = 'EQUAL';
                ($LineRest) = ($Line =~ /^=(.*)/);
            }
            # Variable identifiers
            elsif ($Line =~ /^[a-zA-Z_]/) {
                ($Token) = ($Line =~ /^([a-zA-Z_][a-zA-Z0-9_]*).*/);
                $TokenType = 'IDENTIFIER';
                ($LineRest) = ($Line =~ /^[a-zA-Z_][a-zA-Z0-9_]*(.*)/);
                # Check if identifier is a known type
                foreach $NewType (@NewTypes) {
                    if ($Line =~ /^$NewType(\W.*)?$/) {
                        $TokenType = 'TYPE';
                    }
                }
                # Check if identifier is a known constant
                foreach $NewConst (@NewConsts) {
                    if ($Line =~ /^$NewConst(\W.*)?$/) {
                        $TokenType = 'CONST';
                    }
                }
            }
            # Version identifiers
            elsif ($Line =~ /^[#]/) {
                ($Token) = ($Line =~ /^([#][a-zA-Z0-9_]*).*/);
                $TokenType = 'VERSION';
                ($LineRest) = ($Line =~ /^[#][a-zA-Z0-9_]*(.*)/);
            }
            elsif ($Line =~ /^\!ASD(\W.*)?$/) {
                $Token = '!ASD';
                $TokenType = 'NOASD';
                ($LineRest) = ($Line =~ /^\!ASD(.*)/);
            }
            # Variable content
            elsif ($Line =~ /^\d\D/) {
                if ($Line =~ /^0x\d+/) {
                    ($Token) = ($Line =~ /^(0x\d+).*/);
                    $TokenType = 'NUMBER';
                    ($LineRest) = ($Line =~ /^0x\d+(.*)/);
                }
                # rpcgen doesn't support floating constants
                #elsif ($Line =~ /^\d\.\d+/) {
                #    ($Token) = ($Line =~ /^(\d\.\d+).*/);
                #    $TokenType = 'NUMBER';
                #    ($LineRest) = ($Line =~ /^\d\.\d+(.*)/);
                #}
                else {
                    # Single number
                    ($Token) = ($Line =~ /^(\d)\D.*/);
                    $TokenType = 'NUMBER';
                    ($LineRest) = ($Line =~ /^\d(\D.*)/);
                }
            }
            # rpcgen doesn't support floating constants
            #elsif ($Line =~ /^[1-9]\d*\.\d+/) {
            #    ($Token) = ($Line =~ /^([1-9]\d*\.\d+).*/);
            #    $TokenType = 'NUMBER';
            #    ($LineRest) = ($Line =~ /^[1-9]\d*\.\d+(.*)/);
            #}
            elsif ($Line =~ /^-?[1-9]\d*/) {
                ($Token) = ($Line =~ /^(-?[1-9]\d*).*/);
                $TokenType = 'NUMBER';
                ($LineRest) = ($Line =~ /^-?[1-9]\d*(.*)/);
            }
            elsif ($Line =~ /^".*"/) {
                ($Token) = ($Line =~ /^(".*").*/);
                $TokenType = 'STRING';
                ($LineRest) = ($Line =~ /^".*"(.*)/);
            }
            # Error at line
            else {
                $Error = 1;
                $ErrorMsg = "Lexical error at line";
                goto Scanner_Return;
            }
            ($Error,$ErrorMsg) = ParseToken ($TokenType,$Token,$IDLFilepath,
                                             \%ParserState,\@NewTypes,\@NewConsts,
                                             \$CurrentNamespace,\@DefinedIdentifiers,
                                             \$NumberOfNamespaceFunctions,$ProgramNumberPrefix);
            if ($Error) {
                goto Scanner_Return;
            }
            $Line = $LineRest;
            $Line =~ s/^\s+//g;
        }
    }
   
    # Finish state check
    if (!($ParserState {'Part'} =~ /^IDL_FINISH$/)) {
        # Finish state is not reached
        $Error = 1;
        $ErrorMsg = "IDL-File is not completed at line";
        return ($Error,$ErrorMsg,$Count,$OrigLine);
    }
    
    Scanner_Return:
    close (FileHandle);
    if ($Error) {
        return ($Error,$ErrorMsg,$Count,$OrigLine);
    }
    else {
        return ($Error,$ErrorMsg,0,"");   
    }
}

# >--------------------------------------------------------------------------<
# > Subroutine: ParseCallingParameter                                        <
# >             Parse the calling parameter of converter                     <
# > Parameter:  $ARGV -> Calling parameters                                  <
# >             $rIDLPath <- The parsed idl-filepath                         < 
# >             $rServerLoopTimeoutSec <- Periodic loop timeout sec          <
# >             $rServerLoopTimeoutUSec <-  Periodic loop timeout microsec   <
# >             $rClientRequestTimeoutSec <- Client timeout sec              <
# >             $rClientRequestTimeoutUSec <- Client timeout microsec        <
# >             $rClientRetryTimeoutSec <- Client retry timeout sec          <
# >             $rClientRetryTimeoutUSec <- Client retry timeout microsec    <
# >             $rUseThread <- Parameter to identify if a thead should be    <
# >                            used for periodic activities                  <
# >             $rCreateOnlyClient <- Only client should be created          <
# > Return:     <- Errorinfo: Error (0=ok, 1=error)                          <
# > Author:     A. Neidhardt                                                 <
# > Date:       17.04.2007                                                   <
# > Revision:   -                                                            <
# > Info:       -                                                            <
# >--------------------------------------------------------------------------<
sub ParseCallingParameter {
    my ($ARGV,$rIDLPath,$rServerLoopTimeoutSec,$rServerLoopTimeoutUSec,
        $rClientRequestTimeoutSec,$rClientRequestTimeoutUSec,$rClientRetryTimeoutSec,$rClientRetryTimeoutUSec,
        $rTransportProtocol,$rUseThread,$rCreateOnlyClient,$rProgramNumberPrefix,$rFixedUDPPort,$rFixedTCPPort,
        $rAutomaticSafetyDeviceTimeout,$rPrintVersion)=@_;
    my $ARGC = $#ARGV + 1;   # Number of program calling arguments
    my $ArgIndex;            # Index into arguments
    my $State = 0;           # Parserstate
    my $ProgClass = 0;
    my $IDLPathDefined = 0;  # Check if IDL-path is defined

    if ($ARGC < 1) {
        return 1;
    }
    
    $$rServerLoopTimeoutSec = 0;
    $$rServerLoopTimeoutUSec = 0;
    $$rClientRequestTimeoutSec = 0;
    $$rClientRequestTimeoutUSec = 0;
    $$rClientRetryTimeoutSec = 0;
    $$rClientRetryTimeoutUSec = 0;
    $$rTransportProtocol = 0;
    $$rUseThread = 0;
    $$rCreateOnlyClient = 0;
    $$rProgramNumberPrefix = 700000000;
    $$rFixedUDPPort = 0;
    $$rFixedTCPPort = 0;
    $$rAutomaticSafetyDeviceTimeout = -1; # No automatic safety device
    $$rPrintVersion = 0; # Don't print version info
    
    for ($ArgIndex = 0; $ArgIndex < $ARGC; $ArgIndex++) {
        if ($State == 0) {
            if ($ARGV[$ArgIndex] =~ /^-TCP$/) {
                $$rTransportProtocol = 1;
                next;
            }
            elsif ($ARGV[$ArgIndex] =~ /^-UDP$/) {
                $$rTransportProtocol = 0;
                next;
            }
            elsif ($ARGV[$ArgIndex] =~ /^-CL$/) {
                $$rCreateOnlyClient = 1;
                next;
            }
            elsif ($ARGV[$ArgIndex] =~ /^-V$/) {
                $$rPrintVersion = 1;
                next;
            }
            elsif ($ARGV[$ArgIndex] =~ /^-SLT$/) {
                if ($$rUseThread == 2) {
                    return 1;
                }
                $$rUseThread = 1;
                $State = 1;
                next;
            }
            elsif ($ARGV[$ArgIndex] =~ /^-TLT$/) {
                if ($$rUseThread == 1) {
                    return 1;
                }
                $$rUseThread = 2;
                $State = 1;
                next;
            }
            elsif ($ARGV[$ArgIndex] =~ /^-CT$/) {
                $State = 2;
                next;
            }
            elsif ($ARGV[$ArgIndex] =~ /^-CRT$/) {
                $State = 3;
                next;
            }
            elsif ($ARGV[$ArgIndex] =~ /^-PCL$/) {
                $State = 4;
                next;
            }
            elsif ($ARGV[$ArgIndex] =~ /^-PUDP$/) {
                $State = 5;
                next;
            }
            elsif ($ARGV[$ArgIndex] =~ /^-PTCP$/) {
                $State = 6;
                next;
            }
            elsif ($ARGV[$ArgIndex] =~ /^-ASD$/) {
                $State = 7;
                next;
            }
            elsif ($ARGV[$ArgIndex] =~ /\.[iI][dD][lL]$/) {
                if (($ARGC - ($ArgIndex + 1)) != 0) {
                    return 1;
                }
                $$rIDLPath = $ARGV[$ArgIndex];
                $IDLPathDefined = 1;
                last;
            }
            else {
                return 1;
            }
        }
        
        # -SLT, -TLT
        if ($State == 1) {
            if ($ARGV[$ArgIndex] =~ /^\d+\/\d+$/) {
                ($$rServerLoopTimeoutSec,$$rServerLoopTimeoutUSec) = ($ARGV[$ArgIndex] =~ /^(\d+)\/(\d+)$/);
                $State = 0;
                if ($$rServerLoopTimeoutSec <= 0 &&
                    $$rServerLoopTimeoutUSec <= 0) {
                    return 1;
                }
                next;
            }
            else {
                if ($$rUseThread != 2) {
                    return 1;
                }
                $$rServerLoopTimeoutSec = 0;
                $$rServerLoopTimeoutSec = 0;
                $ArgIndex--;
                $State = 0;
                next;
            }
        }
        
        # -CT
        if ($State == 2) {
            if ($ARGV[$ArgIndex] =~ /^\d+\/\d+$/) {
                ($$rClientRequestTimeoutSec,$$rClientRequestTimeoutUSec) = ($ARGV[$ArgIndex] =~ /^(\d+)\/(\d+)$/);
                $State = 0;
                if ($$rClientRequestTimeoutSec <= 0 &&
                    $$rClientRequestTimeoutUSec <= 0) {
                    return 1;
                }
                next;
            }
            else {
                return 1;
            }
        }
        
        # -CRT
        if ($State == 3) {
            if ($ARGV[$ArgIndex] =~ /^\d+\/\d+$/) {
                ($$rClientRetryTimeoutSec,$$rClientRetryTimeoutUSec) = ($ARGV[$ArgIndex] =~ /^(\d+)\/(\d+)$/);
                $State = 0;
                if ($$rClientRetryTimeoutSec <= 0 &&
                    $$rClientRetryTimeoutUSec <= 0) {
                    return 1;
                }
                next;
            }
            else {
                return 1;
            }
        }
        
        # -PCL = Program classification = Program number prefix
        if ($State == 4) {
            if ($ARGV[$ArgIndex] =~ /^\d?\d\d\d$/) {
                $ProgClass = $ARGV[$ArgIndex];
                if ($ProgClass < 600 || $ProgClass > 1070) {
                    return 1;
                }
                $$rProgramNumberPrefix = $ProgClass * 1000000;
                $State = 0;
                next;
            }
            else {
                return 1;
            }
        }
        
        # -PUDP = Fixed UDP port
        if ($State == 5) {
            if ($ARGV[$ArgIndex] =~ /^\d+$/) {
                $$rFixedUDPPort = $ARGV[$ArgIndex];
                if ($$rFixedUDPPort <= 0) {
                    return 1;
                }
                $State = 0;
                next;
            }
            else {
                return 1;
            }
        }
        
        # -PTCP = Fixed TCP port
        if ($State == 6) {
            if ($ARGV[$ArgIndex] =~ /^\d+$/) {
                $$rFixedTCPPort = $ARGV[$ArgIndex];
                if ($$rFixedTCPPort <= 0) {
                    return 1;
                }
                $State = 0;
                next;
            }
            else {
                return 1;
            }
        }
        
        # -ASD = automatic safety device (deadman safety control)
        if ($State == 7) {
            if ($ARGV[$ArgIndex] =~ /^\d+$/) {
                $$rAutomaticSafetyDeviceTimeout = $ARGV[$ArgIndex];
                if ($$rAutomaticSafetyDeviceTimeout < 0) {
                    return 1;
                }
                $State = 0;
                next;
            }
            else {
                return 1;
            }
        }
    }
    
    if ($$rUseThread >= 1) {
        $$rUseThread = $$rUseThread - 1;
    }
    
    if (!$IDLPathDefined && !$$rPrintVersion) {
        return 1;
    }
    
    return 0;
}

# >--------------------------------------------------------------------------<
# > Subroutine: CheckCompilerVersionCompatibilities                          <
# >             Check if the compiler compatibility is given                 <
# > Parameter:  -                                                            <
# > Return:     -                                                            <
# > Author:     A. Neidhardt                                                 <
# > Date:       28.05.2008                                                   <
# > Revision:   -                                                            <
# > Info:       -                                                            <
# >--------------------------------------------------------------------------<
sub CheckCompilerVersionCompatibilities {
    my $Error;
    my $Line;
    my $GCCMainVersion="";
    my $GCCSubVersion="";
    my $XDRTagFound = 0;

    # === Get compiler version ===============================================
    # Check compiler version
    if (($Error = system("g++ -v 2> g++_version.txt"))) {
       return (1, "Can't do system call \"g++ -v > g++_version.txt\"");
    }
    
    # Open file (old style open, so that older perl versions can handle it)
    open (FileHandle,"< g++_version.txt") or return (1,"Can't open file g++_version.txt!");

    # Read lines until needed information is completed
    while (($Line = <FileHandle>)) {
        if ($Line =~ /[gG][cC][cC].*[Vv][Ee][Rr][Ss][Ii][Oo][Nn]/)
        {
            ($GCCMainVersion,$GCCSubVersion) = ($Line =~ /[gG][cC][cC].*[Vv][Ee][Rr][Ss][Ii][Oo][Nn]\s*(\d+)\.(\d+)\./)
        }
    }

    # Close file 
    close (FileHandle);
    
    # Remove version file
    unlink ("g++_version.txt");
    
    # === Get XDR version ===============================================
    # Open file (old style open, so that older perl versions can handle it)
    open (FileHandle,"< /usr/include/rpc/xdr.h") or return (1,"Can't open file /usr/include/rpc/xdr.h!");

    # Read lines until needed information is completed
    while (($Line = <FileHandle>)) {
        if ($XDRTagFound == 0) {
            if ($Line =~ /IXDR_PUT_LONG/)
            {
                $XDRTagFound = 1;
                next;
            }
        }
        else {
            if ($Line =~ /\(\*__extension__\(\(u_int32_t\*\)\(buf\)\)\+\+ = \(long\)htonl\(\(u_long\)\(v\)\)\)/) {
                $XDRTagFound = 2;
                last;
            }
        }
    }

    # Close file 
    close (FileHandle);

    # === Check version combinations =====================================
    if (($GCCMainVersion > 3 ||
         ($GCCMainVersion == 3 && $GCCSubVersion > 3)) &&
         $XDRTagFound == 2) {
         return (1, "gcc-Version ".$GCCMainVersion.".".$GCCSubVersion." doesn't match with current XDR-version /usr/include/rpc/xdr.h");
    }
    
    return (0, "OK");
}

# >--------------------------------------------------------------------------<
# > Subroutine: PrintCallingInformation                                      <
# >             Print the calling help information                           <
# > Parameter:  -                                                            <
# > Return:     -                                                            <
# > Author:     A. Neidhardt                                                 <
# > Date:       17.04.2007                                                   <
# > Revision:   -                                                            <
# > Info:       -                                                            <
# >--------------------------------------------------------------------------<
sub PrintCallingInformation {
    print "\n\n"; 
    print "idl2rpc-version\n";
    print "===============\n".$g_VersionDate."\n\n"; 
    print $g_LicenseHead;
    print "\n\n";
    print "Usage:\n";
    print "======\n\n"; 
    print "idl2rpc.pl ([-SLT <sec>/<usec>] |  --> Server loop timeout for periodic activities\n"; 
    print "                                       (sec > 0 and/or usec > 0)\n"; 
    print "            [-TLT [<sec>/<usec>]]) --> Server loop timeout for periodic activities using threads\n";
    print "                                       (sec > 0 and/or usec > 0, without time setting periodic\n"; 
    print "                                       activity is called only once => user written timing)\n";
    print "           [-CT <sec>/<usec>]      --> Client request timeout for each request\n"; 
    print "                                       (sec > 0 and/or usec > 0)\n"; 
    print "           [-CRT <sec>/<usec>]     --> Client retry timeout after a request retry is started\n";
    print "                                       (sec > 0 and/or usec > 0)\n"; 
    print "           [-PCL <number>]         --> Program classification code >= 600 and <= 1070, standard is 700\n";
    print "           [-TCP|-UDP]             --> Mainly used transportprotocol\n";
    print "           [-PTCP <port>]          --> Fixed port for UDP connections\n";
    print "           [-PUDP <port>]          --> Fixed port for TCP connections\n";
    print "           [-CL]                   --> Create only client\n";
    print "           [-ASD <sec>]            --> Automatic safety device (\"deadman\" safety control)\n";
    print "                                       (sec >= 0 specifies the reaction time after client contact is lost)\n";
    print "           [-V]                    --> Print only idl2rpc version information without processing\n";
    print "           <IDL-filepath>.idl      --> IDL-filepath\n";
}

# >--------------------------------------------------------------------------<
# > Subroutine: MAIN                                                         <
# > Author:     A. Neidhardt                                                 <
# > Date:       17.04.2007                                                   <
# >--------------------------------------------------------------------------<
my $IDLPath = "test.idl";
my $ServerLoopTimeoutSec = 0;
my $ServerLoopTimeoutUSec = 0;
my $ClientRequestTimeoutSec = 0;
my $ClientRequestTimeoutUSec = 0;
my $ClientRetryTimeoutSec = 0;
my $ClientRetryTimeoutUSec = 0;
my $UseThread = 0;
my $CreateOnlyClient = 0;
my $TransportProtocol = 0;
my $ProgramNumberPrefix = 0;
my $FixedUDPPort = 0;
my $FixedTCPPort = 0;
my $AutomaticSafetyDevice = 0; # ASD (deadman safety control)
my $PrintVersion = 0; # Print only idl2rpc version without processing (0=no,1=yes)
my $StartingDir = cwd();      # Working directory
#my $VersionCode = "0x23456789";
my $Error = 0;
my $ErrorMsg = "OK";
my $LinePosition = 0;
my $LineContent = "";
my $IDLDirectory;
my $IDLFile;
my $RPCXPath = "";
my $RPCSvcPath = "";

# Parse calling parameters
if (ParseCallingParameter($ARGV,\$IDLPath,\$ServerLoopTimeoutSec,\$ServerLoopTimeoutUSec,
                          \$ClientRequestTimeoutSec,\$ClientRequestTimeoutUSec,
                          \$ClientRetryTimeoutSec,\$ClientRetryTimeoutUSec,
                          \$TransportProtocol,\$UseThread,\$CreateOnlyClient,
                          \$ProgramNumberPrefix,\$FixedUDPPort,\$FixedTCPPort,
                          \$AutomaticSafetyDevice,\$PrintVersion)) {
   PrintCallingInformation ();
   $Error = 1;
   goto idl2rpc_Return;
}
if ($AutomaticSafetyDevice >= 0) {
    $g_ASD = 1;
}

print "idl2rpc-version ".$g_VersionDate."\n";
if ($PrintVersion){
    goto idl2rpc_Return;
}
print $g_LicenseHead;

# Change into directory of IDL-file
if ($IDLPath =~ /.*\/.*$/) {
    ($IDLDirectory,$IDLFile) = ($IDLPath =~ /(.*\/)(.*)$/);
    if (!chdir ($IDLDirectory)) {
       print "[ERROR] Wrong IDL-filepath \n";
       $Error = 1;
       goto idl2rpc_Return;
    }
}
else {
    $IDLDirectory = "./";
    $IDLFile = $IDLPath;
}

# Check compiler compatibility
print "Check compiler version compatibility ";
($Error,$ErrorMsg) = CheckCompilerVersionCompatibilities ();
if ($Error) {
   print "... nok\n";
   print "[ERROR] ".$ErrorMsg."\n";
   goto idl2rpc_Return;
}
print "... ok\n";

# Parse IDL-file
print "Scan and parse given IDL-file ";
#($Error,$ErrorMsg,$LinePosition,$LineContent) = Scanner ($IDLPath,$ProgramNumberPrefix);
($Error,$ErrorMsg,$LinePosition,$LineContent) = Scanner ($IDLFile,$ProgramNumberPrefix);
if ($Error) {
   print "... nok\n";
   print "[ERROR] ".$ErrorMsg." ".$LinePosition.": ".$LineContent."\n";
   goto idl2rpc_Return;
}
print "... ok\n";

# Write RPC-X-file
($RPCXPath) = ($IDLFile =~ /(.*\.).*$/);
$RPCXPath = $RPCXPath."x";
print "Write rpc x-file ";
if ($Error = PrintProgramBlockToFile ($RPCXPath)) {
   print "... nok\n";
   print "[ERROR] Can't write rpc-x-file \n";
   goto idl2rpc_Return;
}
print "... ok\n";

# Call rpcgen
($RPCSvcPath) = ($IDLFile =~ /(.*)\.idl$/);
$RPCSvcPath = $RPCSvcPath."_svc.c";
print "Call rpcgen ".$RPCXPath." ";
if (($Error = system("rpcgen ".$RPCXPath)) ||
    ($Error = system("rm ".$RPCSvcPath)) ||
    ($Error = system("rpcgen -s tcp -s udp -o ".$RPCSvcPath." ".$RPCXPath))) {
   print "[ERROR] Can't generate rpc-files \n";
   goto idl2rpc_Return;
}
print "... ok\n";

print "Write abstract interface hpp-file ";
if ($Error = PrintINTERFACEHPPFileUsingTemplate ($IDLFile)) {
   print "... nok\n";
   print "[ERROR] Can't write hpp-file \n";
   goto idl2rpc_Return;
}
print "... ok\n";

print "Write client hpp-file ";
if ($Error = PrintClientHPPFileUsingTemplate ($IDLFile)) {
   print "... nok\n";
   print "[ERROR] Can't write hpp-file \n";
   goto idl2rpc_Return;
}
print "... ok\n";

print "Write client cpp-file ";
if ($Error = PrintClientCPPFileUsingTemplate ($IDLFile, $ClientRequestTimeoutSec, $ClientRequestTimeoutUSec, 
                                              $ClientRetryTimeoutSec, $ClientRetryTimeoutUSec, $TransportProtocol,
                                              $FixedUDPPort,$FixedTCPPort)) {
   print "... nok\n";
   print "[ERROR] Can't write cpp-file \n";
   goto idl2rpc_Return;
}
print "... ok\n";

if ($CreateOnlyClient == 0) {
   print "Write server hpp-file ";
   if ($Error = PrintServerHPPFileUsingTemplate ($IDLFile)) {
      print "... nok\n";
      print "[ERROR] Can't write hpp-file \n";
      goto idl2rpc_Return;
   }
   print "... ok\n";

   print "Write server cpp-file ";
   if ($Error = PrintServerCPPFileUsingTemplate ($IDLFile)) {
      print "... nok\n";
      print "[ERROR] Can't write cpp-file \n";
      goto idl2rpc_Return;
   }
   print "... ok\n";

   print "Write server-proc h-file ";
   if ($Error = PrintServerProcHFileUsingTemplate ($IDLFile)) {
      print "... nok\n";
      print "[ERROR] Can't write h-file \n";
      goto idl2rpc_Return;
   }
   print "... ok\n";

   print "Write server-proc cpp-file ";
   if ($Error = PrintServerProcCPPFileUsingTemplate ($IDLFile, $ServerLoopTimeoutSec, 
                                                     $ServerLoopTimeoutUSec, $UseThread,
                                                     $AutomaticSafetyDevice)) {
      print "... nok\n";
      print "[ERROR] Can't write cpp-file \n";
      goto idl2rpc_Return;
   }
   print "... ok\n";
   
   if ($UseThread ||
       $AutomaticSafetyDevice >= 0) {
       print "Write server-thread hpp-file ";
       if ($Error = PrintServerSimpleThreadHPPFileUsingTemplate ($IDLFile)) {
          print "... nok\n";
          print "[ERROR] Can't write hpp-file \n";
          goto idl2rpc_Return;
       }
       print "... ok\n";
       print "Write server-thread cpp-file ";
       if ($Error = PrintServerSimpleThreadCPPFileUsingTemplate ($IDLFile)) {
          print "... nok\n";
          print "[ERROR] Can't write cpp-file \n";
          goto idl2rpc_Return;
       }
       print "... ok\n";
   }

   print "Write semaphore-variable hpp-file ";
   # PrintServerSimpleSemaphoreVariableHPPFileUsingTemplate ($IDLPath,$UseThread) <= Always write complete semvar
   if ($Error = PrintServerSimpleSemaphoreVariableHPPFileUsingTemplate ($IDLFile,1)) {
      print "... nok\n";
      print "[ERROR] Can't write hpp-file \n";
      goto idl2rpc_Return;
   }
   print "... ok\n";
   print "Write semaphore-variable cpp-file ";
   # PrintServerSimpleSemaphoreVariableCPPFileUsingTemplate ($IDLPath,$UseThread) <= Always write complete semvar
   if ($Error = PrintServerSimpleSemaphoreVariableCPPFileUsingTemplate ($IDLFile,1)) {
      print "... nok\n";
      print "[ERROR] Can't write cpp-file \n";
      goto idl2rpc_Return;
   }
   print "... ok\n";

   print "Change server _svr.c-file ";
   if ($Error = ChangeServerSVRfile ($IDLFile,$FixedUDPPort,$FixedTCPPort)) {
      print "... nok\n";
      print "[ERROR] Can't change _svr.c-file \n";
      goto idl2rpc_Return;
   }
   print "... ok\n";
}
else
{
    print "Write semaphore-variable hpp-file ";
    # PrintServerSimpleSemaphoreVariableHPPFileUsingTemplate ($IDLPath,$UseThread) <= Always write complete semvar
    if ($Error = PrintServerSimpleSemaphoreVariableHPPFileUsingTemplate ($IDLFile,1)) {
       print "... nok\n";
       print "[ERROR] Can't write hpp-file \n";
       goto idl2rpc_Return;
    }
    print "... ok\n";
    print "Write semaphore-variable cpp-file ";
    # PrintServerSimpleSemaphoreVariableCPPFileUsingTemplate ($IDLPath,$UseThread) <= Always write complete semvar
    if ($Error = PrintServerSimpleSemaphoreVariableCPPFileUsingTemplate ($IDLFile,1)) {
       print "... nok\n";
       print "[ERROR] Can't write cpp-file \n";
       goto idl2rpc_Return;
    }
    print "... ok\n";

    print "rm ".$RPCSvcPath."\n";
    if (($Error = system("rm ".$RPCSvcPath))) {
       print "[ERROR] Can't delete server-files \n";
       goto idl2rpc_Return;
    }
}

print "Change _xdr.c-file ";
if ($Error = ChangeXDRfile ($IDLFile)) {
   print "... nok\n";
   print "[ERROR] Can't change _xdr.c-file \n";
   goto idl2rpc_Return;
}
print "... ok\n";

print "Write operating system h-file ";
if ($Error = PrintOSHFileUsingTemplate ($IDLFile)) {
   print "... nok\n";
   print "[ERROR] Can't write h-file \n";
   goto idl2rpc_Return;
}
print "... ok\n";

print "Write operating system c-file ";
if ($Error = PrintOSCFileUsingTemplate ($IDLFile)) {
   print "... nok\n";
   print "[ERROR] Can't write c-file \n";
   goto idl2rpc_Return;
}
print "... ok\n";
    
# Change back to original directory
if (!chdir ($StartingDir)) {
   print "[ERROR] Can't change into original directory \n";
   goto idl2rpc_Return;
}

idl2rpc_Return:
if ($Error) {
   print "Finish ... nok\n";
}
else {
   print "Finish ... ok\n";
}

1;

#***********************************************************************
#* END OF FILE (CVS Concurrent Versions Control)
#* ---------------------------------------------------------------------
#* $RCSfile: idl2rpc.pl,v $ 
#* $Revision: 1.34 $
#***********************************************************************/
