from wxPython import wx
import os

class MyApp(wx.wxApp):

    def OnInit(self):
        frame = wx.wxFrame(None, -1, "image test", size=(100, 100))
        panel = wx.wxPanel(frame, -1)
        
        frame.Show(1)

        path = os.path.join(os.path.split(__file__)[0], 'sizingHandle.bmp')
        bmp = wx.wxBitmap(path, wx.wxBITMAP_TYPE_BMP)
        #print bmp.Ok(), bmp
        size = (bmp.GetWidth(), bmp.GetHeight())
        self.btn1 = wx.wxBitmapButton(
            panel, 
            -1, 
            bmp, 
            (10, 10), 
            size,
            wx.wxCLIP_SIBLINGS,
        )

        self.btn2 = wx.wxStaticBitmap(
            panel, 
            -1, 
            bmp, 
            (50, 10), 
            size,
            wx.wxCLIP_SIBLINGS,
        )

        self.SetTopWindow(frame)
        return 1


app = MyApp(0)
app.MainLoop()
