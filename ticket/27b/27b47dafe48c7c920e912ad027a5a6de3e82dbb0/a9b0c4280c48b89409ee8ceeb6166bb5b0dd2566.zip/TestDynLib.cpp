//_______________________________________________________________________________________________
//
//! \file   TestDynLib.cpp
//! \brief  wxWidgets sample application to show wxDynamicLibrary usage. 
//!
//! \author Bernard Krummenacher
//_______________________________________________________________________________________________

// for compilers that support precompilation, includes "wx/wx.h".
#include "wx/wxprec.h"

#ifdef __BORLANDC__
    #pragma hdrstop
#endif

// for all others, include the necessary headers
#ifndef WX_PRECOMP
  #include "wx/app.h"
  #include "wx/log.h"
  #include "wx/frame.h"
  #include "wx/menu.h"

  #include "wx/button.h"
  #include "wx/checkbox.h"
  #include "wx/listbox.h"
  #include "wx/statbox.h"
  #include "wx/stattext.h"
  #include "wx/textctrl.h"
#endif

#include "wx/bookctrl.h"
#include "wx/choicdlg.h"
#include "wx/choice.h"
#include "wx/colordlg.h"
#include "wx/config.h"
#include "wx/dcclient.h"
#include "wx/dir.h"
#include "wx/dirdlg.h"
#include "wx/dynarray.h"
#include "wx/file.h"
#include "wx/filedlg.h"
#include "wx/filename.h"
#include "wx/fontdlg.h"
#include "wx/gauge.h"
#include "wx/image.h"
#include "wx/listctrl.h"
#include "wx/msgdlg.h"
#include "wx/radiobox.h"
#include "wx/sizer.h"
#include "wx/spinctrl.h"
#include "wx/statline.h"
#include "wx/statusbr.h"
#include "wx/textdlg.h"
#include "wx/timer.h"
#include "wx/toolbar.h"
#include "wx/txtstrm.h"
#include "wx/sysopt.h"
#include "wx/wfstream.h"

#include "wx/stockitem.h"

#include "wx/dynlib.h"

#include "DynLib.h"
//_______________________________________________________________________________________________

#define VERSION  1  //!< Primary version value.
#define REVISION 0  //!< Secondary version value.

//__________________________________________________________________________________________________


//! All the event IDs used in relation with the TestDynLibFrame class. 
typedef enum
{
  TestDynLib_CommRadioBox = wxID_HIGHEST + 1, //!< Event ID for the communication radio box ctrl.
  TestDynLib_ProcessorRadioBox,               //!< Event ID for the communication radio box ctrl.
  TestDynLib_Button,
  TestDynLib_ThreadEnd,
  TestDynLib_ThreadMessage
} T_TestDynLibFrameIds;
//_______________________________________________________________________________________________

class ProgConfig
{
public:
  wxString  CommPort;       //!< Name of the current in use communication port.
  wxPoint   FramePosition;  //!< Position of the frame on the screen.
  wxSize    FrameSize;      //!< Size of the frame.
public:
  ProgConfig()
  {
    ProgramConfig   = new wxConfig("Benchtop Serial Update");
    CommPort        = ProgramConfig->Read("CommPort","COM1:");
    FramePosition.x = ProgramConfig->Read("PosX",10);
    FramePosition.y = ProgramConfig->Read("PosY",50);
    FrameSize.x     = ProgramConfig->Read("SizeX",-1);
    FrameSize.y     = ProgramConfig->Read("SizeY",-1);
  };
  ~ProgConfig()
  {
    ProgramConfig->Write("CommPort",CommPort);
    ProgramConfig->Write("PosX",FramePosition.x);
    ProgramConfig->Write("PosY",FramePosition.y);
    ProgramConfig->Write("SizeX",FrameSize.x);
    ProgramConfig->Write("SizeY",FrameSize.y);
    delete ProgramConfig;
  };
private:
  wxConfig* ProgramConfig;  //!< Program configuration context.
};
//__________________________________________________________________________________________________

ProgConfig* FindConfig(void);
//__________________________________________________________________________________________________

typedef enum
{
  E_Idle,
  E_Running,
  E_Stop,
  E_Done
} T_ProcessState;
//__________________________________________________________________________________________________

//! Define a new frame type: this is going to be our main frame
class TestDynLibFrame : public wxFrame
{
private:
  wxDynamicLibrary   DynLib;
  static ProgConfig* Config;            //!< Configuration record.
  wxPanel*           Panel;             //!< The panel that contain every other wxWidgets elements.
  wxSizer*           SizerAppl;         //!< Main sizer for the frame.
  wxStaticText*      String_1;
  wxStaticText*      String_2;
  wxStaticText*      String_3;
  wxStaticText*      String_4;
  wxStaticText*      String_5;

  void OnExit(wxCommandEvent& event);                 //!< Application exit event callback function.
  void OnClose(wxCloseEvent& event);                  //!< Close Window event callback function.

  void InitDLL(void);
  void CleanDLL(void);
public:
  //! Constructor.
  TestDynLibFrame
  (
    const wxString& title //!< String to use as window title.
  );

  //! Destructor.
  virtual ~TestDynLibFrame();
  //_______________

  // Any class wishing to process wxWidgets events must use this macro.
  DECLARE_EVENT_TABLE()
};
//_______________________________________________________________________________________________

//! Define a new application type, each program should derive a class from wxApp
class TestDynLibApp : public wxApp
{
public:
  //! Called by the main program to initialize the application context.
  //! \return true if initialization ok, false if the application must terminate.
  virtual bool OnInit();
};
//_______________________________________________________________________________________________

ProgConfig* TestDynLibFrame::Config;                   //!< Configuration record.

static TestDynLibFrame* TestFrame;

IMPLEMENT_APP(TestDynLibApp)

BEGIN_EVENT_TABLE(TestDynLibFrame, wxFrame)
  EVT_CLOSE(                                                  TestDynLibFrame::OnClose)
  EVT_MENU(wxID_EXIT,                                         TestDynLibFrame::OnExit)
END_EVENT_TABLE()
//_______________________________________________________________________________________________

//! Function called at application initialisation time. Builds everything.
//! \return true if initialisation ok, false if application should terminate.
bool TestDynLibApp::OnInit()
{
  if (wxApp::OnInit())
  {
    // enter the main message loop and run the app
    wxInitAllImageHandlers();
    TestFrame = new TestDynLibFrame(_T("Test DynLib"));
    TestFrame->Show();
    SetTopWindow(TestFrame);
    return true;
  }
  return false;
}
//__________________________________________________________________________________________________

//! Main frame constructor.
TestDynLibFrame::TestDynLibFrame
(
  const wxString& title //!< Description text to be displayed in the window's title bar.
)
: wxFrame(NULL, wxID_ANY, title, wxPoint(0, 50), wxDefaultSize,
          wxDEFAULT_FRAME_STYLE | wxNO_FULL_REPAINT_ON_RESIZE | wxCLIP_CHILDREN | wxTAB_TRAVERSAL)
{
  //_________ Config ___________

  // init everything
  Config = new ProgConfig;
  SetPosition(Config->FramePosition);
  SetSize(Config->FrameSize);
  // Set a Debiotech icon on the window's title bar.
  //SetIcon(wxICON(debio));

  // create controls
  Panel = new wxPanel(this,wxID_ANY,wxDefaultPosition,wxDefaultSize,wxCLIP_CHILDREN);

  SizerAppl = new wxBoxSizer(wxVERTICAL);
  SizerAppl->Add(new wxStaticLine(Panel, wxID_ANY), 0, wxGROW);

  //__________ Menus __________

  // Create the menubar.
  wxMenuBar* mbar = new wxMenuBar;

  // Create the File menu.
  wxMenu* file_menu = new wxMenu;
  file_menu->Append(wxID_EXIT, _T("&Quit\tCtrl-Q"));
  mbar->Append(file_menu, _T("&File"));

#if 0
  // Create the Help menu.
  wxMenu* help_menu = new wxMenu;
  help_menu->Append(wxID_ABOUT, _T("&About TestDynLib..."));
  mbar->Append(help_menu, _T("&Help"));
#endif

  SetMenuBar(mbar);
  
  //__________ Static texts __________
  
  String_1 = new wxStaticText(Panel,wxID_ANY,"-----------------------------",wxDefaultPosition, wxDefaultSize);;
  String_2 = new wxStaticText(Panel,wxID_ANY,"-----------------------------",wxDefaultPosition, wxDefaultSize);;
  String_3 = new wxStaticText(Panel,wxID_ANY,"-----------------------------",wxDefaultPosition, wxDefaultSize);;
  String_4 = new wxStaticText(Panel,wxID_ANY,"-----------------------------",wxDefaultPosition, wxDefaultSize);;
  String_5 = new wxStaticText(Panel,wxID_ANY,"-----------------------------",wxDefaultPosition, wxDefaultSize);;
  
  SizerAppl->Add(String_1);
  SizerAppl->Add(String_2);
  SizerAppl->Add(String_3);
  SizerAppl->Add(String_4);
  SizerAppl->Add(String_5);
  
  //__________ Sizers definition __________

  Panel->SetSizer(SizerAppl);
  SizerAppl->Fit(this);
  SizerAppl->SetSizeHints(this);   // set size hints to honour minimum size.
  wxSize size = GetMinSize();
  SetSize(size);
  SetMinSize(size);
  SetMaxSize(size);

  InitDLL();
}
//_______________________________________________________________________________________________

//! Destructor.
//! Save the program configuration.
TestDynLibFrame::~TestDynLibFrame()
{
  Config->FramePosition = GetPosition();
  Config->FrameSize = GetSize();
  delete Config;
}
//_______________________________________________________________________________________________

void TestDynLibFrame::OnExit //!< Application exit event callback function.
(
  wxCommandEvent& WXUNUSED(event)
)
{
  Close();
}
//_______________________________________________________________________________________________

void TestDynLibFrame::OnClose //!< Close Window event callback function.
(
  wxCloseEvent& WXUNUSED(event)
)
{
  CleanDLL();
  this->Destroy();
}
//_______________________________________________________________________________________________

typedef wxString (*Func)(int val);

void TestDynLibFrame::InitDLL(void)
{
  Func Func_1;
  Func Func_2;
  Func Func_3;
  Func Func_4;
  Func Func_5;

  // Load the lib and get pointer to interface
  wxString filename("DynLib");
  DynLib.Load(filename,wxDL_NOW); // Do not add wxDL_VERBATIM as it would avoid automatically add the platform dependent extension.

  if (DynLib.IsLoaded())
  {
    Func_1 = (Func)DynLib.GetSymbol("Func_1" );
    Func_2 = (Func)DynLib.GetSymbol("Func_2" );
    Func_3 = (Func)DynLib.GetSymbol("Func_3" );
    Func_4 = (Func)DynLib.GetSymbol("Func_4" );
    Func_5 = (Func)DynLib.GetSymbol("Func_5" );
    
    if (Func_1 != NULL)
    {
      String_1->SetLabel(Func_1(1));
    }
    
    if (Func_2 != NULL)
    {
      String_2->SetLabel(Func_2(2));
    }
    
    if (Func_3 != NULL)
    {
      String_3->SetLabel(Func_3(3));
    }
    
    if (Func_4 != NULL)
    {
      String_4->SetLabel(Func_4(4));
    }
    
    if (Func_5 != NULL)
    {
      String_5->SetLabel(Func_5(5));
    }
  }
}
//_______________________________________________________________________________________________

void TestDynLibFrame::CleanDLL(void)
{
  DynLib.Unload();
}
//_______________________________________________________________________________________________
