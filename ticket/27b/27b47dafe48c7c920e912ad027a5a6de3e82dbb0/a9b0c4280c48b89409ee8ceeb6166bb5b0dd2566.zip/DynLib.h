
#ifndef DYN_LIB_H
#define DYN_LIB_H

/*---- compilation control switches ----------------------------------------*/
#ifdef __cplusplus
extern "C"
{
#endif

#ifdef _WIN32
#ifdef IMPLEMENT_DLL
  #define EXPORT __declspec(dllexport)
#else
  #define EXPORT __declspec(dllimport)
#endif
#else
#ifdef IMPLEMENT_DLL
#define EXPORT __attribute__((visibility("default")))
#else
#define EXPORT
#endif
#endif

EXPORT wxString Func_1(int val);
EXPORT wxString Func_2(int val);
EXPORT wxString Func_3(int val);
EXPORT wxString Func_4(int val);
EXPORT wxString Func_5(int val);

#ifdef __cplusplus
}
#endif

#endif

