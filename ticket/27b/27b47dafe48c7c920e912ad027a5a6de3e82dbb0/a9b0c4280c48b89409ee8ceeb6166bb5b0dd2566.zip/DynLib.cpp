
/*---- system and platform files -------------------------------------------*/
#ifdef _WIN32
  #if (_MSC_VER >= 900)
    #define	WIN32_LEAN_AND_MEAN
    #define INC_OLE2
    #define	NOSERVICE
  #endif 
  #include <windows.h>
  #include <process.h>
#endif  

#include <stdio.h>

// for compilers that support precompilation, includes "wx/wx.h".
#include "wx/wxprec.h"

#ifdef __BORLANDC__
#pragma hdrstop
#endif

// for all others, include the necessary headers
#ifndef WX_PRECOMP
#include "wx/app.h"
#include "wx/log.h"
#include "wx/frame.h"
#include "wx/menu.h"

#include "wx/button.h"
#include "wx/checkbox.h"
#include "wx/listbox.h"
#include "wx/statbox.h"
#include "wx/stattext.h"
#include "wx/textctrl.h"
#endif

#include "wx/bookctrl.h"
#include "wx/choicdlg.h"
#include "wx/choice.h"
#include "wx/colordlg.h"
#include "wx/config.h"
#include "wx/dcclient.h"
#include "wx/dir.h"
#include "wx/dirdlg.h"
#include "wx/dynarray.h"
#include "wx/file.h"
#include "wx/filedlg.h"
#include "wx/filename.h"
#include "wx/fontdlg.h"
#include "wx/gauge.h"
#include "wx/image.h"
#include "wx/listctrl.h"
#include "wx/msgdlg.h"
#include "wx/radiobox.h"
#include "wx/sizer.h"
#include "wx/spinctrl.h"
#include "wx/statline.h"
#include "wx/statusbr.h"
#include "wx/textdlg.h"
#include "wx/timer.h"
#include "wx/toolbar.h"
#include "wx/txtstrm.h"
#include "wx/sysopt.h"
#include "wx/wfstream.h"

#include "wx/stockitem.h"

#include "wx/dynlib.h"

#define IMPLEMENT_DLL
#include "DynLib.h"

EXPORT wxString Func_1(int val)
{   
  return wxString::Format("Func_1(%d)",val);
}

EXPORT wxString Func_2(int val)
{   
  return wxString::Format("Func_2(%d)",val);
}

EXPORT wxString Func_3(int val)
{   
  return wxString::Format("Func_3(%d)",val);
}

EXPORT wxString Func_4(int val)
{   
  return wxString::Format("Func_4(%d)",val);
}

EXPORT wxString Func_5(int val)
{   
  return wxString::Format("Func_5(%d)",val);
}
