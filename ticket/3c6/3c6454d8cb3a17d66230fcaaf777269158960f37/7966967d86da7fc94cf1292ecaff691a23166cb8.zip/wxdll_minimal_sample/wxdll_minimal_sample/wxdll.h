#ifndef _MY_DLL_H_
#define _MY_DLL_H_

#ifndef WX_PRECOMP
    #include "wx/wx.h"
#endif

enum {

ID_FRAME = 5000,
ID_TEXTCTRL,
ID_LABELTEXTCTRL,
ID_BUTTON1,
ID_BUTTON2,

};

class MyFrame : public wxFrame
{
public:
	MyFrame(const wxWindowID id,const wxString& title,
		const wxPoint& pos, const wxSize& size,long style);
	MyFrame(const wxWindowID id,const wxString& title);
virtual ~MyFrame();
wxPanel *mypanel;
wxTextCtrl *textctrl;
wxTextCtrl *labeltextctrl;
protected:
	void OnButton1(wxCommandEvent& event);
	void OnButton2(wxCommandEvent &event);
private:
    DECLARE_EVENT_TABLE()
};

class MyPanel : public wxPanel {
public:
	MyPanel() {}
	MyPanel(wxFrame *frame, int x, int y, int w, int h);
    MyPanel(wxWindow* parent,
		wxWindowID id = wxID_ANY,
		const wxPoint& pos = wxDefaultPosition,
		const wxSize& size = wxDefaultSize,
		long style = wxTAB_TRAVERSAL,
		const wxString& name = wxT("panel"))
		:wxPanel(parent,id,pos,size,style,name) {}
	virtual ~MyPanel() {};

};


class MyTextCtrl : public wxTextCtrl
{
public:
	MyTextCtrl(wxWindow* parent, wxWindowID id,
			const wxString& value = wxT(""),
			const wxPoint& pos = wxDefaultPosition,
			const wxSize& size = wxDefaultSize,
			long style = 0, const wxValidator& validator = wxDefaultValidator,
			const wxString& name = wxTextCtrlNameStr)
	:wxTextCtrl(parent,id,value,pos,size,style,validator,name) { }
protected:
	void OnTextCtrlType(wxCommandEvent& event);

};

#endif // _MY_DLL_H_