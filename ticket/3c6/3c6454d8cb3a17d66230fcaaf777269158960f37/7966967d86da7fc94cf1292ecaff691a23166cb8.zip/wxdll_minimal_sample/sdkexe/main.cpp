
#include <windows.h>
#include <windowsx.h>

#include <stdio.h>
#include <tchar.h>

#include "bindto_dll.h"

namespace {

// ----------------------------------------------------------------------------
// constants
// ----------------------------------------------------------------------------

const TCHAR *MAIN_WIN_CLASS_NAME = _TEXT("my_exe_main_win_class");
const int IDB_RUN_GUI_FROM_DLL = 100;


// ----------------------------------------------------------------------------
// globals
// ----------------------------------------------------------------------------

HINSTANCE g_hInstance;
HWND g_hwndMain;
HANDLE h_thread1;
HANDLE h_event1;
HANDLE h_thread2;
HANDLE h_event2;
// ============================================================================
// implementation
// ============================================================================

// ----------------------------------------------------------------------------
// callbacks
// ----------------------------------------------------------------------------

void
OnCommand(HWND /* hwnd */, int id, HWND /* hwndCtl */, UINT /* codeNotify */)
{
    if ( id == IDB_RUN_GUI_FROM_DLL )
    {
        run_wx_gui_from_dll("child instance");
    }
}

void OnDestroy(HWND hwnd)
{
//wx_dll_cleanup();
//PostQuitMessage(0);
}

LRESULT CALLBACK MainWndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
    switch ( msg )
    {
        //HANDLE_MSG(hwnd, WM_COMMAND, OnCommand);
        HANDLE_MSG(hwnd, WM_DESTROY, OnDestroy); 
        default:
            return DefWindowProc(hwnd, msg, wParam, lParam);
    }

    return 0;
}

// ----------------------------------------------------------------------------
// initialization functions
// ----------------------------------------------------------------------------

bool RegisterMainClass()
{
    WNDCLASS wc;
    ZeroMemory(&wc, sizeof(wc));
    wc.style         = CS_DBLCLKS | CS_HREDRAW | CS_VREDRAW;
    wc.lpfnWndProc   = MainWndProc;
    wc.hInstance     = g_hInstance;
    wc.hIcon         = LoadIcon(NULL, IDI_APPLICATION);
    wc.hCursor       = LoadCursor(NULL, IDC_ARROW);
    wc.hbrBackground = (HBRUSH)(COLOR_WINDOW + 1);
    wc.lpszClassName = MAIN_WIN_CLASS_NAME;

    return RegisterClass(&wc) != 0;
}

} // anonymous namespace



// ----------------------------------------------------------------------------
// entry point
// ----------------------------------------------------------------------------

int APIENTRY WinMain(HINSTANCE hInstance, HINSTANCE, LPSTR, int nCmdShow)
{
    //g_hInstance = hInstance;

    //if ( !RegisterMainClass() )
    //    return 1;
	
	run_wx_gui_from_dll("wxWidgets Sample");

	

	MSG msg;
	bool msg1;
	while(GetMessage(&msg, NULL, 0, 0)) {
		TranslateMessage(&msg);
        DispatchMessage(&msg);
	msg1 = isRunning();
	if(!msg1) {
			
			wx_dll_cleanup();
			PostQuitMessage(0);
			//::PostMessage(g_hwndMain,WM_DESTROY,0,0);
		}
	}
	
	return 0;
}