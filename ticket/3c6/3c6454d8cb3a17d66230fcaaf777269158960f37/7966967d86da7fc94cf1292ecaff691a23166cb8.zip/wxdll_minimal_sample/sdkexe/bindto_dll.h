#ifndef _BIND_H
#define _BIND_H

#ifdef MY_DLL_BUILDING
    #define MY_DLL_DECL __declspec(dllexport)
#else
    #define MY_DLL_DECL __declspec(dllimport)
#endif

#ifdef __cplusplus
extern "C" {
#endif

// launch wx UI from some application that may or may not be written in wx
MY_DLL_DECL void run_wx_gui_from_dll(const char *title);

MY_DLL_DECL bool isRunning();
MY_DLL_DECL void wx_dll_cleanup();

// run this to shutdown running threads etc.
//MY_DLL_DECL void wx_dll_cleanup();

#ifdef __cplusplus
}
#endif

#endif