/////////////////////////////////////////////////////////////////////////////
// Name:        project3app.h
// Purpose:     
// Author:      
// Modified by: 
// Created:     23/09/2008 17:11:46
// RCS-ID:      
// Copyright:   
// Licence:     
/////////////////////////////////////////////////////////////////////////////

#ifndef _PROJECT3APP_H_
#define _PROJECT3APP_H_


/*!
 * Includes
 */

////@begin includes
#include "wx/image.h"
////@end includes

/*!
 * Forward declarations
 */

////@begin forward declarations
////@end forward declarations

/*!
 * Control identifiers
 */

////@begin control identifiers
////@end control identifiers

/*!
 * Project3App class declaration
 */

class Project3App: public wxApp
{    
    DECLARE_CLASS( Project3App )
    DECLARE_EVENT_TABLE()

public:
    /// Constructor
    Project3App();

    void Init();

    /// Initialises the application
    virtual bool OnInit();

    /// Called on exit
    virtual int OnExit();

////@begin Project3App event handler declarations
////@end Project3App event handler declarations

////@begin Project3App member function declarations
////@end Project3App member function declarations

////@begin Project3App member variables
////@end Project3App member variables
};

/*!
 * Application instance declaration 
 */

////@begin declare app
DECLARE_APP(Project3App)
////@end declare app

#endif
    // _PROJECT3APP_H_
