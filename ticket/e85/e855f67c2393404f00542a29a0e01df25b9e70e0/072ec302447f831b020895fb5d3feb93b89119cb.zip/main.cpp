#include<stdio.h>
#include<dlfcn.h>
#include<unistd.h>

typedef int (*P_myfunc)(int argc,char**argv);

int main(int argc,char**argv)
{
	void*mainLib=0;
	P_myfunc myfunc=0;
	mainLib=dlopen("./libmylib.so",RTLD_NOW);
	if(!mainLib)
	{
		
		printf("Failed to load main library!\nError:%s\n", dlerror());
		return -1;
	}
	myfunc=(P_myfunc)dlsym(mainLib,"myfunc");
	if(!myfunc)
	{
		printf("Incorect main library detected!\n");
		dlclose(mainLib);
		return -1;
	}
	printf("Passing control to the main library.\n");
	myfunc(argc,argv);
	printf("Received control from the main library.\n");
	dlclose(mainLib);
	return 0;
}
