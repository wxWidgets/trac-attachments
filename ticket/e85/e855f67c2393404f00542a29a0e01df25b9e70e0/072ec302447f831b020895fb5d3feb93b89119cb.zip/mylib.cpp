#include<wx/wx.h>
#include<wx/app.h>

class myapp : public wxApp
{
public:
	myapp()
	{
	}
	
	virtual bool OnInit()
	{
		printf("All ok\n");
		return false;
	}
};

IMPLEMENT_APP_NO_MAIN(myapp);

int myfunc(int argc,char**argv)
{
	return wxEntry(argc, argv);
}
