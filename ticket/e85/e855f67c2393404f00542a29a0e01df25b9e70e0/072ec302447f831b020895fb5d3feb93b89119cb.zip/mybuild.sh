#!/bin/bash
g++ -Wall main.cpp -ldl -o main
g++ -shared -Wl,-soname,libmylib.so -Wall $(sh wx-config --cppflags --libs) mylib.cpp -o libmylib.so