///////////////////////////////////////////////////////////////////////////////////////////////
// Name:             des.h                                                                   //
// Purpose:          wxDES                                                                   //
// Author:           Carlos Dom�nguez                                                        //
// Last modified:    14/06/2001                                                              //
// Licence:          wxWindows license                                                       //
///////////////////////////////////////////////////////////////////////////////////////////////

//--- include guards --------------------------------------------------------------------------

#ifndef _WX_DES_H_
#define _WX_DES_H_

//--- standard header -------------------------------------------------------------------------

#ifdef __GNUG__
    #pragma interface "des.h"
#endif

///////////////////////////////////////////////////////////////////////////////////////////////
// classes                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////

/*
    DES is an algorithm that works with blocks of 8 bytes ;-)
    One key to cipher ... the same key to decipher

    1. Cipher.
                                     ----------------
           key block (8 bytes) ---->|                |
                                    |   DES cipher   |----> ciphered data block (8 bytes)
    plain data block (8 bytes) ---->|                |
                                     ----------------
    2. Decipher.
                                        ------------------
              key block (8 bytes) ---->|                  |
                                       |   DES decipher   |----> plain data block (8 bytes)
    ciphered data block (8 bytes) ---->|                  |
                                        ------------------

    - Validation set:

    key:       0123 4567 89ab cdef
    plain:     0123 4567 89ab cde7
    cipher:    c957 4425 6a5e d31d

    Class wxDES behaves as a cipher or decipher box determined in the constructor. Then just
    call method ProcessBlock.
*/

class WXDLLEXPORT wxDES {
    public:
        // constructor, key is an 8-byte array, mode is 0 to cipher and 1 to decipher
        wxDES(const char *key, char mode);

        // parity bits are taken the least significant bits of each byte
        // and are completely ignored in the cipher/decipher algorithm
        bool CheckParityByte(char b);
        bool CheckKeyParityBlock(char *key);
        void CorrectKeyParityBlock(char *key);

        // process block of 8 bytes, inBlock and outBlock may be the same
        void ProcessBlock(char *inBlock, char *outBlock);

    private:
        // key array
        wxUint32 m_KnL[32];

        // DES static const variables
        static const wxUint32 m_bytebit[];
        static const wxUint32 m_bigbyte[];
        static const char m_pc1[];
        static const char m_totrot[];
        static const char m_pc2[];
        static const wxUint32 m_SP1[];
        static const wxUint32 m_SP2[];
        static const wxUint32 m_SP3[];
        static const wxUint32 m_SP4[];
        static const wxUint32 m_SP5[];
        static const wxUint32 m_SP6[];
        static const wxUint32 m_SP7[];
        static const wxUint32 m_SP8[];
};

//--- end of file -----------------------------------------------------------------------------

#endif
