///////////////////////////////////////////////////////////////////////////////////////////////
// Name:             wxdes_sample.cpp                                                        //
// Purpose:          wxDES sample                                                            //
// Author:           Carlos Dom�nguez                                                        //
// Last modified:    14/06/2001                                                              //
// Licence:          wxWindows license                                                       //
///////////////////////////////////////////////////////////////////////////////////////////////

//--- standard header -------------------------------------------------------------------------

#ifdef __GNUG__
    #pragma implementation "wxdes_sample.cpp"
    #pragma interface "wxdes_sample.cpp"
#endif

// for compilers that support precompilation, includes "wx.h"
#include "wx/wxprec.h"

#ifdef __BORLANDC__
    #pragma hdrstop
#endif

// for all others
#ifndef WX_PRECOMP
    #include "wx/wx.h"
#endif

#include "wx/file.h"
#include "des.h"

///////////////////////////////////////////////////////////////////////////////////////////////
// Declarations                                                                              //
///////////////////////////////////////////////////////////////////////////////////////////////

//--- MyApp -----------------------------------------------------------------------------------

class MyApp : public wxApp {
    public:
        // called on startup, if returns FALSE the app terminates
        bool OnInit();
};

//--- MyFrame ---------------------------------------------------------------------------------

class MyFrame : public wxFrame {
    public:
        // constructor
        MyFrame(const wxString& title);

        // event handlers, should NOT be virtual
        void OnCipherFile(wxCommandEvent& event);
        void OnDecipherFile(wxCommandEvent& event);
        void OnQuit(wxCommandEvent& event);

    private:
        // process wxWindows events
        DECLARE_EVENT_TABLE()
};

// event table
enum {wxID_CipherFile, wxID_DecipherFile, wxID_Quit};

BEGIN_EVENT_TABLE(MyFrame, wxFrame)
  EVT_MENU(wxID_CipherFile, MyFrame::OnCipherFile)
  EVT_MENU(wxID_DecipherFile, MyFrame::OnDecipherFile)
  EVT_MENU(wxID_Quit, MyFrame::OnQuit)
END_EVENT_TABLE()

///////////////////////////////////////////////////////////////////////////////////////////////
/// MyApp implementation                                                                    ///
///////////////////////////////////////////////////////////////////////////////////////////////

IMPLEMENT_APP(MyApp)

// OnInit, called on startup, if returns FALSE the app terminates
bool MyApp::OnInit() {
    // create the app window
    (void) new MyFrame("wxDES sample");
    return TRUE;
}

///////////////////////////////////////////////////////////////////////////////////////////////
///   MyFrame implementation                                                                ///
///////////////////////////////////////////////////////////////////////////////////////////////

// constructor
MyFrame::MyFrame(const wxString& title) : wxFrame((wxWindow *) NULL, -1, title) {
    wxMenuBar *menuBar = new wxMenuBar();
    wxMenu *menuFile = new wxMenu();
    menuFile->Append(wxID_CipherFile, "Cipher file");
    menuFile->Append(wxID_DecipherFile, "Decipher file");
    menuFile->AppendSeparator();
    menuFile->Append(wxID_Quit, "Quit\tAlt-X");
    menuBar->Append(menuFile, "File");
    SetMenuBar(menuBar);

    Center();
    Show(TRUE);
}

// OnCipherFile, menuitem
void MyFrame::OnCipherFile(wxCommandEvent& event) {
    // get file name to cipher
    wxString filename = wxFileSelector(
	"Select file to cipher", "", "", "", "*.*", wxHIDE_READONLY);
    if (filename.IsSameAs("")) return;

    // open file
    wxFile file(filename.c_str(), wxFile::read_write);
    if (file.IsOpened() == FALSE) return;

    // check that file length is multiple of 8 (required for DES)
    size_t fileLength = file.Length();
    size_t nBlocks = fileLength / 8;
    if (nBlocks * 8 != fileLength) {
        wxMessageBox("File length is not multiple of 8 (required for DES)",
		"Error", wxOK | wxICON_EXCLAMATION);
        return;
    }

    // ask for password (max 8 chars for DES) and create cipher object
    wxString password = wxGetPasswordFromUser("Enter password");
    wxDES cipher = wxDES(wxString::Format("%-8s", password.c_str()).c_str(), 0);

    // process file
    size_t nBytes;
    char readBuffer[8];
    for (size_t i = 0; i < nBlocks; i++) {
        // read 8-bytes block and cipher it with DES
        nBytes = file.Read(readBuffer, 8);
        if (nBytes != 8) {
            wxMessageBox("Error reading file", "Error", wxOK | wxICON_EXCLAMATION);
            return;
        }
        cipher.ProcessBlock(readBuffer, readBuffer);

        // update 8-bytes block in file
        if (file.Seek(i * 8) == wxInvalidOffset) {
            wxMessageBox("Error seeking file", "Error", wxOK | wxICON_EXCLAMATION);
            return;
        }
        nBytes = file.Write(readBuffer, 8);
        if (nBytes != 8) {
            wxMessageBox("Error writing file", "Error", wxOK | wxICON_EXCLAMATION);
            return;
        }
    }

    wxMessageBox("File successfully ciphered", "Error", wxOK | wxICON_EXCLAMATION);
}

// OnDecipherFile, menuitem
void MyFrame::OnDecipherFile(wxCommandEvent& event) {
    // get file name to decipher
    wxString filename = wxFileSelector(
	"Select file to decipher", "", "", "", "*.*", wxHIDE_READONLY);
    if (filename.IsSameAs("")) return;

    // open file
    wxFile file(filename.c_str(), wxFile::read_write);
    if (file.IsOpened() == FALSE) return;

    // check that file length is multiple of 8 (required for DES)
    size_t fileLength = file.Length();
    size_t nBlocks = fileLength / 8;
    if (nBlocks * 8 != fileLength) {
        wxMessageBox("File length is not multiple of 8 (required for DES)",
		"Error", wxOK | wxICON_EXCLAMATION);
        return;
    }

    // ask for password (max 8 chars for DES) and create decipher object
    wxString password = wxGetTextFromUser("Enter password");
    wxDES decipher = wxDES(wxString::Format("%-8s", password.c_str()).c_str(), 1);

    // process file
    size_t nBytes;
    char readBuffer[8];
    for (size_t i = 0; i < nBlocks; i++) {
        // read 8-bytes block and decipher it with DES
        nBytes = file.Read(readBuffer, 8);
        if (nBytes != 8) {
            wxMessageBox("Error reading file", "Error", wxOK | wxICON_EXCLAMATION);
            return;
        }
        decipher.ProcessBlock(readBuffer, readBuffer);

        // update 8-bytes block in file
        if (file.Seek(i * 8) == wxInvalidOffset) {
            wxMessageBox("Error seeking file", "Error", wxOK | wxICON_EXCLAMATION);
            return;
        }
        nBytes = file.Write(readBuffer, 8);
        if (nBytes != 8) {
            wxMessageBox("Error writing file", "Error", wxOK | wxICON_EXCLAMATION);
            return;
        }
    }

    wxMessageBox("File successfully deciphered", "Error", wxOK | wxICON_EXCLAMATION);
}

// OnQuit, menuitem
void MyFrame::OnQuit(wxCommandEvent& event) {
    Close(TRUE);
}

//--- end of file -----------------------------------------------------------------------------
