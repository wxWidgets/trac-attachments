#include "wx/wx.h"   
#include <cstring>
class MyApp : public wxApp {
public:   
    virtual bool OnInit()
    {	
	//file name
	wxString file_name = wxString::FromUTF8("\xC3\xA0") +wxString(".pdf");
	
	
	//replace okular with your pdf viewer
	wxString command =  wxString("okular ") + "\""+file_name+"\"" ;
	
	//let's show command that are to be executed
	wxMessageDialog   *command_message =new wxMessageDialog (NULL, "i will try to execute command " + command);
        command_message->ShowModal ();
	
	
	//first let's try to execute wxString directly
	wxExecute(command);
	//it is not working, let's try with char.
	
	
	
	//we create variable "s" here that contains command (char type)
	wxCharBuffer temp_char_buffer = command.mb_str(wxConvLocal);
	char *s = new char [strlen(temp_char_buffer.data()) + 1]; 
	strcpy(s, temp_char_buffer.data());
	
	
	//print this command to console.
	std::cout << "\n###################################################################\n";
	std::cout << "\n###################################################################\n";
        std::cout << "\nnow  i will try to execute command  " << s<< "\n";  
	std::cout << "\n###################################################################\n";
	std::cout << "\n###################################################################\n";
	//P.S. you can copy shown command and run it directly(in console, without wxwidgets, it will work
	
	
	//execute command 
	wxExecute(s);
	// not working either.
	
	
	
        return true;
    }
};

IMPLEMENT_APP(MyApp)