import gui

def main():
    print 'hello world'
