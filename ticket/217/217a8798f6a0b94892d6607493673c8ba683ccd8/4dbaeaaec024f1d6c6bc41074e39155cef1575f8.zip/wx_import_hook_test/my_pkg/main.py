#!/usr/bin/env python

if __name__ == '__main__':
    import my_pkg
    my_pkg.main()
