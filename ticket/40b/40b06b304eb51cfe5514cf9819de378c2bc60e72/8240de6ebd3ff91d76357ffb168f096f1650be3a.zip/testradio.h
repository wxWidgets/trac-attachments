class TestRadio : public wxPanel
{
public:
    TestRadio(wxWindow *parent);

    void OnRadio(wxCommandEvent &evt);
    void OnButton(wxCommandEvent& event);
private:
    wxRadioBox *radio;
    wxButton *button;
};

class TestRadioDialogPanel : public wxFrame
{
public:
    TestRadioDialogPanel(wxWindow *parent);

    void OnClose(wxCloseEvent& event);
private:
    TestRadio *panel;
};

class TestRadioDialog : public wxFrame
{
public:
    TestRadioDialog(wxWindow *parent);

//    void OnButton(wxCommandEvent& event);
    void OnClose(wxCloseEvent& event);
    void OnRadio(wxCommandEvent &evt);
    void OnButton(wxCommandEvent& event);
private:
    wxRadioBox *radio;
    wxButton *button;
    TestRadio *panel;
};

