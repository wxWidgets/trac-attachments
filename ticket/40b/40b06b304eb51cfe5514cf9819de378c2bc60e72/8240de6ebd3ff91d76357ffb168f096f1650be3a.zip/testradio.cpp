#include "wx/wxprec.h"

#ifdef __BORLANDC__
#pragma hdrstop
#endif

#ifndef WX_PRECOMP
#include "wx/wx.h"
#endif

#include "testradio.h"

/*********** begin example bug code *********************/

/* The following code represents the change needed to work in 2.8.9 and 2.8.10 but I would rather not have to do this
   as the TestRadioDialog class works under 2.8.7 and should continue to work in 2.8.9 and 2.8.10
   This was compiled and tested on windows but also needs to work on solaris (gtk) and linux (gtk) but I have not tried it on those versions.
*/
TestRadio::TestRadio(wxWindow *parent)
: wxPanel(parent,-1,wxDefaultPosition,wxDefaultSize)
{
    wxBoxSizer *szr = new wxBoxSizer(wxVERTICAL);
    wxString choice[2];
    choice[0] = _("one");
    choice[1] = _("two");
    radio = new wxRadioBox(this,-1,_("Radio"),wxDefaultPosition,wxDefaultSize,2,choice);
    szr->Add(radio,0,wxGROW|wxALL,2);
    radio->SetSelection(0);
    button = new wxButton(this,-1,_("Button"),wxDefaultPosition,wxDefaultSize);
    szr->Add(button,0,wxGROW|wxALL);
    Layout();
    SetSizer(szr);
    szr->SetSizeHints(this);
    szr->Fit(this);
    Connect(radio->GetId(),wxEVT_COMMAND_RADIOBOX_SELECTED,(wxObjectEventFunction)TestRadio::OnRadio,NULL);
    Connect(button->GetId(),wxEVT_COMMAND_BUTTON_CLICKED,(wxObjectEventFunction)TestRadio::OnButton,NULL);
}

void TestRadio::OnButton(wxCommandEvent &evt)
{
    printf("on button");
}

void TestRadio::OnRadio(wxCommandEvent &evt)
{
    printf("on radio");
}

TestRadioDialogPanel::TestRadioDialogPanel(wxWindow *parent)
: wxFrame(parent,-1,wxT("Test Radio"),wxDefaultPosition,wxDefaultSize)
{
    wxBoxSizer *szr = new wxBoxSizer(wxVERTICAL);
    panel = new TestRadio(this);
    szr->Add(panel,1,wxEXPAND);
    Layout();
    SetSizer(szr);
    szr->SetSizeHints(this);
    szr->Fit(this);
    Layout();
    SetSizer(szr);
    szr->SetSizeHints(this);
    szr->Fit(this);
}

/* !!!! The following code displays how to reproduce the bug in 2.8.9 and 2.8.10.  This works in 2.8.7 but not in 2.8.9 nor 2.8.10
*/

TestRadioDialog::TestRadioDialog(wxWindow *parent)
: wxFrame(parent,-1,wxT("Test Radio"),wxDefaultPosition,wxDefaultSize)
{
    wxBoxSizer *szr = new wxBoxSizer(wxVERTICAL);
    wxString choice[2];
    choice[0] = _("one");
    choice[1] = _("two");
    radio = new wxRadioBox(this,-1,_("Radio"),wxDefaultPosition,wxDefaultSize,2,choice);
    szr->Add(radio,0,wxGROW|wxALL,2);
    radio->SetSelection(0);
    button = new wxButton(this,-1,_("Button"),wxDefaultPosition,wxDefaultSize);
    szr->Add(button,0,wxGROW|wxALL);
    Layout();
    SetSizer(szr);
    szr->SetSizeHints(this);
    szr->Fit(this);
    Connect(radio->GetId(),wxEVT_COMMAND_RADIOBOX_SELECTED,(wxObjectEventFunction)&TestRadioDialog::OnRadio,NULL);
    Connect(button->GetId(),wxEVT_COMMAND_BUTTON_CLICKED,(wxObjectEventFunction)&TestRadioDialog::OnButton,NULL);
}

void TestRadioDialog::OnButton(wxCommandEvent &evt)
{
    printf("on button");
}

void TestRadioDialog::OnRadio(wxCommandEvent &evt)
{
    //set breakpoint here and event does not get triggered so this does not get executed in 2.8.9 and 2.8.10
    printf("on radio");
}

/* include the following in the dialogs sample and add to the menu to show how this operates

void MyFrame::TestDlg(wxCommandEvent& WXUNUSED(event))
{
    TestRadioDialog *dlg = new TestRadioDialog(this);
    dlg->Show();
}

void MyFrame::TestPanelDlg(wxCommandEvent& WXUNUSED(event))
{
    TestRadioDialogPanel *dlg = new TestRadioDialogPanel(this);
    dlg->Show();
}
*/
/************* end example bug code ****************/


