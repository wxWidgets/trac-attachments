#ifndef __GUI__
#define __GUI__

#include "wx/wx.h"

class MyApp : public wxApp
{
public:
    virtual bool OnInit();
};
DECLARE_APP(MyApp);

#endif