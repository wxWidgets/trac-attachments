#include "GUI.h"

bool MyApp::OnInit()
{
    wxFrame *frame = new wxFrame(NULL, wxID_ANY, _T("MyApp"), wxDefaultPosition, wxSize(600, 400));
    wxPanel *colorpanel;
    wxBoxSizer *mainsizer = new wxBoxSizer(wxVERTICAL);
    wxSizer *mastersizer = new wxBoxSizer(wxHORIZONTAL);
    wxScrolledWindow *scroll = new wxScrolledWindow(frame, wxID_ANY);
    
    frame->SetBackgroundColour(*wxBLACK);
    
    for(int i=0; i<10; i++){
        colorpanel = new wxPanel(scroll, wxID_ANY, wxDefaultPosition, wxSize(-1, 40));
        colorpanel->SetBackgroundColour(wxColour(96, 114, 134));
        mainsizer->Add(colorpanel, 0, wxEXPAND | wxBOTTOM, 1);
    }
    
    scroll->SetSizer(mainsizer);
    scroll->FitInside();
    scroll->SetScrollRate(5, 5);
    mastersizer->Add(scroll, 1, wxEXPAND);
    frame->SetSizer(mastersizer);
    
    frame->Show();
    return true;
}
IMPLEMENT_APP(MyApp);