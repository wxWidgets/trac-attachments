/*
 * Copyright (C) 2018 Wayne Stambaugh <stambaughw@gmail.com>
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 3
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, you may find one here:
 * https://www.gnu.org/licenses/gpl-3.0.en.html
 * or you may search the http://www.gnu.org website for the version 3 license,
 * or you may write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
 */

#include <wx/app.h>
#include <wx/cmdline.h>
#include <wx/log.h>
#include <wx/string.h>
#include <wx/filename.h>

class CALLEE : public wxAppConsole
{
public:
    virtual bool OnInit() override;
    virtual int OnRun() override;
    virtual void OnInitCmdLine( wxCmdLineParser& parser ) override;
    virtual bool OnCmdLineParsed( wxCmdLineParser& parser ) override;

private:
    ///> Returns file extension for the selected output format
    wxString getOutputExt() const;

    wxString m_argv;
};


static const wxCmdLineEntryDesc cmdLineDesc[] =
{
    { wxCMD_LINE_PARAM, NULL, NULL, _( "argv" ).mb_str(),
      wxCMD_LINE_VAL_STRING, wxCMD_LINE_OPTION_MANDATORY },
    { wxCMD_LINE_NONE }
};


wxIMPLEMENT_APP_CONSOLE( CALLEE );


bool CALLEE::OnInit()
{
    if( !wxAppConsole::OnInit() )
        return false;

    return true;
}


void CALLEE::OnInitCmdLine( wxCmdLineParser& parser )
{
    parser.SetDesc( cmdLineDesc );
    parser.SetSwitchChars( "-" );
    return;
}


bool CALLEE::OnCmdLineParsed( wxCmdLineParser& parser )
{
    if( parser.GetParamCount() < 1 )
    {
        parser.Usage();
        return false;
    }

    m_argv = parser.GetParam( 0 );

    return true;
}


int CALLEE::OnRun()
{
    wxLogMessage( "argv=%s", m_argv );
    return 0;
}
