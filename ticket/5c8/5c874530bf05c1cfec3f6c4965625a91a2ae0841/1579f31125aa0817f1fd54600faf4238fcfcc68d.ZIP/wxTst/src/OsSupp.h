/****************************************************************/
/**@file OsSupp.h: 
 * Desctiption: OS dependent stuff.				*
 * Dependency: Windows (9x|2k|XP) 			        *
/****************************************************************/

#include <wx/bitmap.h>


/** OS dependent initialisation of miscellaneous stuff. */
void InitOsDependent(bool InitCom=true);

/** OS dependent cleanup of miscellaneous stuff. */
void DoneOsDependent(void);


/** Load cursor from OS specific storage e.g. resources. */
bool WxLoadCursor(wxCursor *cursor, const wxString& name);

/** Load bitmap from OS specific storage e.g. resources. */
bool WxLoadBitmap(wxBitmap *bitmap, const wxString & name);

extern bool ProblemsWithBrush;

//---Validate float---

#ifdef _MSC_VER

#include <float.h>

extern unsigned long nan[2];

inline bool IsNaN(double *d) {return _isnan(*d);};
inline void MakeNaN(double *d) {memcpy(d,nan,8);};

#else

typedef struct
   {
   int s:1;
   unsigned int Exponent:8;
   } FloatStruct;

inline bool IsNaN(float *f) {return (((FloatStruct *)(f))->Exponent==0xFF);};
inline void MakeNaN(float *f) {((FloatStruct *)(f))->Exponent=0xFF;};

/* Determination of IEEE NaN:  On most systems, the high word is
 * 0x7FF8 or 0xFFF8 (high bit is sign)
 * The 3 systems that don't seem to conform to this rule are:
 *    HPUX:  High word is 0x7FF4
 *    SGI:   High word is 0x7FFF */

inline bool IsNaN(double *d) {return (*((unsigned short *)(d)) & 0x7FF8) ==0x7FF8;};
inline void MakeNaN(double *d) {*((unsigned short *)(d))=0x7FF8;};

#endif