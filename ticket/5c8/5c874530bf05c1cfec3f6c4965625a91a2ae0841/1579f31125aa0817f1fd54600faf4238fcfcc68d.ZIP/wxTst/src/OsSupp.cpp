/****************************************************************/
/**@file OsSupp.cpp: 
 * Desctiption: OS dependent stuff.				*
 * Dependency: Windows (9x|2k|XP), WxWindows		        *
 ****************************************************************/
#include <windows.h>

#include <wx/wxprec.h>
#ifndef WX_PRECOMP
  #include <wx/wx.h>
#endif
#include <wx/cursor.h>
#include <wx/dcbuffer.h>
#include <wx/file.h> // loadfile
#include <wx/image.h>

#include "OsSupp.h"

bool ComInitialized=false;	///< Internal COM initialisation flag.

unsigned long nan[2]={0xffffffff, 0x7fffffff};

/** Searching paths for images. */
TCHAR *Paths[]={_T(""),_T("./images/"),_T("../images/")};

bool ProblemsWithBrush = false;


void InitOsDependent(bool InitCom)
{
HRESULT hr;
OSVERSIONINFO OS_Ver;  
    
  OS_Ver.dwOSVersionInfoSize=sizeof(OS_Ver);
  if(GetVersionEx(&OS_Ver)!=0)
    if(OS_Ver.dwPlatformId<=1) ProblemsWithBrush=true;  

  if(!InitCom) return;

  if(!ComInitialized)
    {
    hr = CoInitializeEx(NULL, COINIT_APARTMENTTHREADED);
    if(SUCCEEDED(hr)) ComInitialized=true;
    }

}


void DoneOsDependent(void)
{
  if (ComInitialized)  // unintialize COM
    {
    CoUninitialize();
    ComInitialized=false;
    }
}



bool WxLoadBitmap(wxBitmap *bitmap, const wxString & name)
{
  if(bitmap==NULL) return false;

  if(bitmap->LoadFile(name, wxBITMAP_TYPE_BMP_RESOURCE))
    return true;
    
  for(int i=0;i<3;i++)  // try to find the directory with our images
    {   
    if(wxFileExists(Paths[i]+name))
      {     
      if(bitmap->LoadFile(Paths[i]+name,wxBITMAP_TYPE_CUR))        
        return true;      
      }
    } 

  return false;
}


bool WxLoadCursor(wxCursor *cursor, const wxString& name)
{
  if(cursor==NULL) return false;

    { // Try to load cursor from windows resources first
    wxCursor Cursor2(name,wxBITMAP_TYPE_CUR_RESOURCE);
    if(Cursor2.Ok())
      {      
      *cursor=Cursor2;
      return true;
      }
    }

  for(int i=0;i<3;i++)  // try to find the directory with our images
    {   
    if(wxFileExists(Paths[i]+name))
      {
      wxImage image;
      if(image.LoadFile(Paths[i]+name,wxBITMAP_TYPE_CUR))
        {
        wxCursor cursor2(image);
        *cursor = cursor2;
        return true;   
        }
      }
    }

  return false;
}