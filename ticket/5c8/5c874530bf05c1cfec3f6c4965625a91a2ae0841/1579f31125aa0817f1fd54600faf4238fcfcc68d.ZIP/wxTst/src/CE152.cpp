/***************************************************************************/
/**@file CE152.cpp
 * Description: Main initialisation for CE152 model demo.		   *  
 * Dependency:  WxWindows				                   *
 ***************************************************************************/

/** Uses splash screen as the application is started if value is equal to 1 */
#define USE_SPLASH_SCREEN 0

#include "wx/wxprec.h"
#ifndef WX_PRECOMP
  #include "wx/wx.h" // For compilers that supports precompilation , includes "wx/wx.h"
#endif
#if USE_SPLASH_SCREEN
  #include <wx/bitmap.h> // wxSplashScreen
  #include <wx/image.h>  // wxSplashScreen
  #include <wx/splash.h> // wxSplashScreen
#endif

#include "CE152.h"
#include "MainFrame.h"
#include "OsSupp.h"



bool StandAloneApp::OnInit()
{
    InitOsDependent(false);    

    // application and vendor name are used by wxConfig to construct the name
    // of the config file/registry key and must be set before the first call
    // to Get() if you want to override the default values (the application
    // name is the name of the executable and the vendor name is the same)
    
    SetVendorName(_T("HUMUSOFT"));
    SetAppName(_T("CE152"));		// not needed, it's the default value   

    // initialise a configuration file
    wxFileConfig *pConfig = new wxFileConfig(GetAppName(), GetVendorName(), _T("CE152.ini"),  // _T("./config.cfg"), 
                                             wxEmptyString, wxCONFIG_USE_LOCAL_FILE|wxCONFIG_USE_RELATIVE_PATH);
    wxConfigBase::Set(pConfig);

    // where you can also specify the file names explicitly if you wish.
    // Of course, calling Set() is optional and you only must do it if
    // you want to later retrieve this pointer with Get().
    
    // Create the main application window     
    BnPMainFrame *frame = new BnPMainFrame(_T("CE152 Magnetic levitation ball Model"), 
                                            wxPoint(-1,-1), wxSize(600,500));
    
    // Show it and tell the application that it's our main window
    frame->Show(true);
    SetTopWindow(frame);
    
    return true;
}


int StandAloneApp::OnExit()
{
    // clean up: Set() returns the active config object as Get() does, but unlike
    // Get() it doesn't try to create one if there is none (definitely not what
    // we want here!)
    wxLog::EnableLogging(false);	//do not display warnings on RO filesytem on flush
    delete wxConfigBase::Set((wxConfigBase *) NULL);
    wxLog::EnableLogging(true); 

    DoneOsDependent();
    return 0;
}


/**  Create a new application object: this macro will allow wxWidgets to create
*  the application object during program execution (it's better than using a
*  static object for many reasons) and also declares the accessor function
*  wxGetApp() which will return the reference of the right type (i.e. MyApp and
*  not wxApp) */
IMPLEMENT_APP(StandAloneApp)

