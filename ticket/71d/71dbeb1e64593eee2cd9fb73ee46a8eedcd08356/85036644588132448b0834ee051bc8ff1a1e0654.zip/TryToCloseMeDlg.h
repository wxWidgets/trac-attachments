///////////////////////////////////////////////////////////////////////////
// C++ code generated with wxFormBuilder (version Dec 29 2008)
// http://www.wxformbuilder.org/
//
// PLEASE DO "NOT" EDIT THIS FILE!
///////////////////////////////////////////////////////////////////////////

#ifndef __TryToCloseMeDlg__
#define __TryToCloseMeDlg__

#include <wx/string.h>
#include <wx/dialog.h>
#include <wx/gdicmn.h>
#include <wx/font.h>
#include <wx/colour.h>
#include <wx/settings.h>

///////////////////////////////////////////////////////////////////////////


///////////////////////////////////////////////////////////////////////////////
/// Class TryToCloseMeDlg
///////////////////////////////////////////////////////////////////////////////
class TryToCloseMeDlg : public wxDialog 
{
	private:
	
	protected:
	
	public:
		TryToCloseMeDlg( wxWindow* parent, wxWindowID id = wxID_ANY, const wxString& title = wxT("Try to close me in Ubuntu 9.04"), const wxPoint& pos = wxDefaultPosition, const wxSize& size = wxSize( 400,300 ), long style = wxCAPTION|wxCLOSE_BOX|wxMAXIMIZE_BOX|wxMINIMIZE_BOX|wxRESIZE_BORDER|wxSYSTEM_MENU );
		~TryToCloseMeDlg();
	
};

#endif //__TryToCloseMeDlg__
