///////////////////////////////////////////////////////////////////////////
// C++ code generated with wxFormBuilder (version Dec 29 2008)
// http://www.wxformbuilder.org/
//
// PLEASE DO "NOT" EDIT THIS FILE!
///////////////////////////////////////////////////////////////////////////

#include "TryToCloseMeDlg.h"

///////////////////////////////////////////////////////////////////////////

TryToCloseMeDlg::TryToCloseMeDlg( wxWindow* parent, wxWindowID id, const wxString& title, const wxPoint& pos, const wxSize& size, long style ) : wxDialog( parent, id, title, pos, size, style )
{
	this->SetSizeHints( wxDefaultSize, wxDefaultSize );
	this->SetExtraStyle( wxDIALOG_EX_METAL );
	
}

TryToCloseMeDlg::~TryToCloseMeDlg()
{
}
