
// wxWidgets
#include <wx/wx.h>
#include <wx/webview.h>
#include <wx/dir.h>
#include <wx/stdpaths.h>
#include <wx/filename.h>
#include <wx/filesys.h>
#include <wx/vector.h>
#include <wx/webviewarchivehandler.h>

wxFileName GetStaticContent(wxString file)
{
	// Construct Filename
	wxFileName fname(wxStandardPaths::Get().GetExecutablePath().BeforeLast('\\') + 
					 wxFileName::GetPathSeparator()+ 
					 wxString("static") + 
					 wxFileName::GetPathSeparator() + 
					 "html" + 
					 wxFileName::GetPathSeparator() + 
					 file + wxString(".html"));

	wxString s = fname.GetFullPath();

	// Return full path, which is corrected by wxWidgets
	return fname;
}

class MyWebHandler : public wxWebViewHandler
{
public:
	MyWebHandler(const wxString& protocol)
		: wxWebViewHandler(protocol)
	{
		m_fs = new wxFileSystem();
	}

	virtual MyWebHandler::~MyWebHandler()
	{
		wxDELETE(m_fs);
	}
	
	virtual wxFSFile* GetFile (const wxString &uri)
	{
		wxString content = uri.substr(9, uri.length()).BeforeLast('/');
		wxFileName path = GetStaticContent(content);

		// It does not make any difference if this is used or not. It fails in both cases.
		wxString url = wxFileSystem::FileNameToURL(path);

		if ( wxFileSystem::HasHandlerForPath(url) )
		{
			return m_fs->OpenFile(url);
		}
		return NULL;
	}	

private:
	wxFileSystem* m_fs;
};


class Mainframe : public wxFrame
{
public:
	Mainframe() : wxFrame(NULL, wxID_ANY, "wxWebViewMinimal", wxDefaultPosition, wxSize(800,600))
	{
		wxWebView* c = wxWebView::New(this, -1);
		c->RegisterHandler(wxSharedPtr<wxWebViewHandler>(new MyWebHandler("static")));
		c->LoadURL(GetStaticContent("start").GetFullPath());
	}
};

class Application : public wxApp
{
public:
	virtual bool OnInit()
	{
		Mainframe* f = new Mainframe();
		SetTopWindow(f);
		f->Centre();
		f->Show();
		return true;
	}
};

IMPLEMENT_APP(Application)