/**
 * MainFrame and MainApp classes definition
 *
 *
 *
 */
#ifndef __mainapp_h_included__
#define __mainapp_h_included__

#include <wx/wx.h>
#include <wx/listctrl.h>

//////////////////////////////////////////////////////////////////////////
//
//  TestDialog
//
class TestDialog : public wxDialog
{
    DECLARE_EVENT_TABLE()

    enum {
        ID_ADD_ROWS = 201,
    };

    public:
        TestDialog(wxWindow* parent, wxWindowID id, const wxString& title,
                   const wxPoint& pos = wxDefaultPosition,
                   const wxSize& size = wxDefaultSize,
                   long style = wxDEFAULT_DIALOG_STYLE,
                   const wxString& name = wxDialogNameStr);
        virtual ~TestDialog();

        void OnAddRows(wxCommandEvent &event);
    
    private:
        wxListCtrl * m_list_ctrl;
}; // TestDialog


//////////////////////////////////////////////////////////////////////////
//
//  MainFrame
//
class MainFrame: 
    public wxFrame
{
    DECLARE_EVENT_TABLE()

    enum {
        ID_SHOW_DIALOG_NOW  = 101,
        ID_SHOW_DIALOG_ON_IDLE,
        ID_QUIT,
    };

public:
    // constructors and destructors
    MainFrame( wxWindow *parent, wxWindowID id, const wxString &title,
        const wxPoint& pos = wxDefaultPosition,
        const wxSize& size = wxDefaultSize,
        long style = wxDEFAULT_FRAME_STYLE );
    ~MainFrame();
    
private:
    void CreateMenuBar();

private:
    void OnIdle(wxIdleEvent & event);

    void OnShowDialogNow(wxCommandEvent &event);
    void OnShowDialogOnIdle(wxCommandEvent &event);
    void OnQuit(wxCommandEvent &event);

private:
    bool m_show_dialog_on_next_idle;
}; // MainFrame

//////////////////////////////////////////////////////////////////////////
//
//  MainApp
//
class MainApp: 
        public wxApp
{
public:
    MainApp();


public:
    // wxApp
    virtual bool OnInit();
    virtual int OnExit();

private:
    MainFrame *m_frame;
}; // MainApp

#endif // __mainapp_h_included__
