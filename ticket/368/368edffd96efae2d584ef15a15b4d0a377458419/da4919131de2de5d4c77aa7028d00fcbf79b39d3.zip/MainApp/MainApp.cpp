/**
 * MainFrame and MainApp classes implementation
 *
 *
 *
 */

#include <assert.h>

#include "MainApp.h"

//////////////////////////////////////////////////////////////////////////
//
//  TestDialog
//
BEGIN_EVENT_TABLE(TestDialog,wxDialog)
    EVT_BUTTON(ID_ADD_ROWS, TestDialog::OnAddRows)
END_EVENT_TABLE()

TestDialog::TestDialog(wxWindow* parent, wxWindowID id, const wxString& title,
                       const wxPoint& pos, const wxSize& size, long style, 
                       const wxString& name) :
    wxDialog(parent, id, title, pos, size, style, name),
    m_list_ctrl(NULL)
{
    wxBoxSizer* sizer = new wxBoxSizer(wxVERTICAL);
    assert(sizer);    

    // text
    wxStaticText * info = new wxStaticText(this, wxID_ANY, 
            _T("You should see 3 rows in the list control bellow:"));
    assert(info);
    sizer->Add(info, 0, wxALIGN_CENTER_HORIZONTAL | wxALL, 5);

    // list
    m_list_ctrl = new wxListCtrl(this, wxID_ANY, wxDefaultPosition, wxDefaultSize, 
            wxLC_REPORT | wxLC_SINGLE_SEL | wxLC_SORT_ASCENDING | wxSUNKEN_BORDER);
    assert(m_list_ctrl);
    
    // columns
    m_list_ctrl->InsertColumn(0, _T("Name"), wxLIST_FORMAT_LEFT, 100);
    m_list_ctrl->InsertColumn(1, _T("Description"), wxLIST_FORMAT_LEFT, 100);


    sizer->Add(m_list_ctrl, 1, wxGROW | wxALIGN_CENTER_HORIZONTAL | wxALL, 5);

    // buttons
    wxBoxSizer* buttons_sizer = new wxBoxSizer(wxHORIZONTAL);
    assert(buttons_sizer);    
    sizer->Add(buttons_sizer, 0, wxALIGN_CENTER_HORIZONTAL | wxALL, 5);

    wxButton* rows_button = new wxButton(this, ID_ADD_ROWS, _T("Add Rows"));
    assert(rows_button);
    buttons_sizer->Add(rows_button, 0, wxALL, 5);

    wxButton* close_button = new wxButton(this, wxID_OK, _T("Close"));
    assert(close_button);
    buttons_sizer->Add(close_button, 0, wxALL, 5);

    SetSizer(sizer);
    SetAutoLayout(TRUE);
}

TestDialog::~TestDialog()
{
}

void TestDialog::OnAddRows(wxCommandEvent &event)
{
    assert(m_list_ctrl);

    long index;

    m_list_ctrl->DeleteAllItems();
    
    index = m_list_ctrl->InsertItem(0, _T("Row 0"));
    m_list_ctrl->SetItem(index, 1, _T("This is Row 0"));
    
    index = m_list_ctrl->InsertItem(1, _T("Row 1"));
    m_list_ctrl->SetItem(index, 1, _T("This is Row 1"));

    index = m_list_ctrl->InsertItem(2, _T("Row 2"));
    m_list_ctrl->SetItem(index, 1, _T("This is Row 2"));
}

//////////////////////////////////////////////////////////////////////////
//
//  MainFrame
//
BEGIN_EVENT_TABLE(MainFrame,wxFrame)
    EVT_IDLE(MainFrame::OnIdle)

    EVT_MENU(ID_SHOW_DIALOG_NOW,     MainFrame::OnShowDialogNow)
    EVT_MENU(ID_SHOW_DIALOG_ON_IDLE, MainFrame::OnShowDialogOnIdle)
    EVT_MENU(ID_QUIT,                MainFrame::OnQuit)
END_EVENT_TABLE()

MainFrame::MainFrame( wxWindow *parent, wxWindowID id, const wxString &title,
    const wxPoint &position, const wxSize& size, long style ) :
    wxFrame( parent, id, title, position, size, style ),
    m_show_dialog_on_next_idle(false)
{
    CreateMenuBar();
    CreateStatusBar(1);
}

MainFrame::~MainFrame()
{
}

void MainFrame::CreateMenuBar()
{
    wxMenu *file_menu = new wxMenu;
    assert(file_menu);
    file_menu->Append(ID_SHOW_DIALOG_NOW,     _T("Show Dialog Now..."),  _T("Show dialog right away") );
    file_menu->Append(ID_SHOW_DIALOG_ON_IDLE, _T("Show Dialog On Idle..."),  _T("Show dialog on next idle event") );
    file_menu->AppendSeparator();
    file_menu->Append(ID_QUIT,          _T("Quit..."),         _T("Quit program") );

    wxMenuBar *menu_bar = new wxMenuBar();
    assert(menu_bar);
    menu_bar->Append( file_menu, _T("File") );

    SetMenuBar(menu_bar);
}

void MainFrame::OnIdle(wxIdleEvent & event)
{
    if(m_show_dialog_on_next_idle) {
        m_show_dialog_on_next_idle = false;

        TestDialog dlg(this, wxID_ANY, _T("Test Dialog On Idle"));
        dlg.ShowModal();
    }
}

void MainFrame::OnShowDialogNow(wxCommandEvent &event)
{
    TestDialog dlg(this, wxID_ANY, _T("Test Dialog Now"));
    dlg.ShowModal();
}

void MainFrame::OnShowDialogOnIdle(wxCommandEvent &event)
{
    m_show_dialog_on_next_idle = true;
}

void MainFrame::OnQuit( wxCommandEvent &event )
{
     Close(true);
}


//////////////////////////////////////////////////////////////////////////
//
//  MainApp
//
IMPLEMENT_APP(MainApp)

MainApp::MainApp() :
    m_frame(NULL)
{
}

bool MainApp::OnInit()
{
    m_frame = new MainFrame( NULL, -1, _T("Test Application"), wxPoint(20,30), wxSize(600,440) );
    m_frame->Show( true );

    return true;
}

int MainApp::OnExit()
{
    return 0;
}


