so...

main is the principal, extern the loaded movie

if you start main.swf, extern is displayed.
if you launch LoadMovie.py, extern is not loaded...

only code is

mc.loadMovie ("extern.swf");

on the main swf, and mc is an empty clip on the stage.

Regards