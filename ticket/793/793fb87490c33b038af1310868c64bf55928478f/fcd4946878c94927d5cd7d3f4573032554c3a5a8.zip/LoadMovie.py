# -*- coding: iso-8859-1 -*-

import  wx, os


if wx.Platform == '__WXMSW__':	
	# under windows, import flashlib library
	from wx.lib.flashwin import FlashWindow

#----------------------------------------------------------------------

class FlashFrame (wx.Frame) :
	""" frame of the application, who handle flash swf
	
	"""
	def _init_ctrls (self, parent) :

		wx.Frame.__init__ (self, parent, -1, "SMPS Design Toolkit",
						wx.DefaultPosition, wx.Size (800, 600),
						wx.DEFAULT_FRAME_STYLE | wx.MAXIMIZE)
						
		panel = wx.Panel(self, -1)

		sizer = wx.BoxSizer(wx.VERTICAL)
		
		panel.flash = FlashWindow(panel, style=wx.SUNKEN_BORDER)
		panel.flash.LoadMovie(0, 'file://' + os.path.abspath('main.swf'))
		panel.flash.Menu=False
		sizer.Add(panel.flash, 1, wx.EXPAND)
		self.flash = panel.flash
		self.flash.Play ()
		
		panel.SetSizer(sizer)
		panel.SetAutoLayout(True)

		self.Bind (wx.EVT_WINDOW_DESTROY, self.OnDestroy)



	def __init__(self, parent, id) :
		""" initilize the frame. 
		
		create panel, import flash file, resize the panel to the swf size
		bind methods
		"""
		self._init_ctrls (parent)



	def OnDestroy(self, evt) :
		""" destroy the frame
		
		"""
		if self.flash :
			self.flash = None
	

		
	def exitApplication (self) :
		""" exit application
		"""
		if self.flash :
			self.flash = None
		self.Destroy ()
		self.Close ()


class FlashApplication (wx.App) :
	""" Application class
	"""
	def OnInit (self) :
		
		# init frame 4 flash
		self.frame = FlashFrame (None, -1)
		self.frame.parent = self
		self.frame.Show (1)
		self.SetTopWindow (self.frame)
		
		return True
		


if wx.Platform == '__WXMSW__':
	app = FlashApplication (0)
	app.MainLoop ()

# if not windows, display messageBox and Exit
else :
	dlg = wx.MessageDialog(frame, 'This application only works on MS-Windows.',
			  'Sorry', wx.OK | wx.ICON_INFORMATION)
	dlg.ShowModal()
	dlg.Destroy()
