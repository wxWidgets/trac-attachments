//---------------------------------------------------------------------------
#include <time.h>
#include <memory>
#include <vector>
//---------------------------------------------------------------------------
#include <wx/wxprec.h>
//---------------------------------------------------------------------------
#ifdef __BORLANDC__
    #pragma hdrstop
#endif
//---------------------------------------------------------------------------
// for all others, include the necessary headers
#ifndef WX_PRECOMP
    #include <wx/wx.h>
    #include <wx/app.h>
    #include <wx/string.h>
    #include <wx/intl.h>
    #include <wx/frame.h>
    #include <wx/valgen.h>
    #include <wx/xrc/xmlres.h>
#endif
//---------------------------------------------------------------------------
void InitXmlResource(void);
//---------------------------------------------------------------------------
class WndMain : public wxFrame
{
private:
    wxString title;

public:
    WndMain(const wxString &sTitle,
            const wxPoint &pos=wxDefaultPosition,
            const wxSize &size=wxDefaultSize);

private:
    void OnOkClicked(wxCommandEvent &WXUNUSED(evt));
    void OnCancelClicked(wxCommandEvent &WXUNUSED(evt));

private:
    DECLARE_EVENT_TABLE();
};
//---------------------------------------------------------------------------
BEGIN_EVENT_TABLE(WndMain, wxFrame)
    EVT_BUTTON(XRCID("btnOK"), WndMain::OnOkClicked)
    EVT_BUTTON(XRCID("btnCancel"), WndMain::OnCancelClicked)
END_EVENT_TABLE()
//---------------------------------------------------------------------------
WndMain::WndMain(const wxString &sTitle,
                 const wxPoint &pos,
                 const wxSize &size)
    : wxFrame(NULL, wxID_ANY, sTitle, pos, size)
{
    wxBoxSizer *sz = new wxBoxSizer(wxVERTICAL);
    wxPanel *pnl = wxXmlResource::Get()->LoadPanel(this, _T("pnlAddressPerson"));
    assert(pnl!=NULL);
    sz->Add(pnl,
            1,
            wxEXPAND | wxALL,
            0);
    SetSizer(sz);
    //sz->SetSizeHints(this);

    std::vector<wxAcceleratorEntry> entries;
    entries.push_back(wxAcceleratorEntry(wxACCEL_NORMAL, WXK_ESCAPE, XRCID("btnCancel")));
    wxAcceleratorTable accel(entries.size(), &*entries.begin());
    SetAcceleratorTable(accel);

    SetExtraStyle(wxWS_EX_VALIDATE_RECURSIVELY);

    title=_T("Mr.");

    FindWindow(_T("txtTitle"))->SetValidator(wxGenericValidator(&title));

    TransferDataToWindow();
}
//---------------------------------------------------------------------------
void WndMain::OnOkClicked(wxCommandEvent &WXUNUSED(evt))
{
    Close();
}
//---------------------------------------------------------------------------
void WndMain::OnCancelClicked(wxCommandEvent &WXUNUSED(evt))
{
    Close();
}
//---------------------------------------------------------------------------
class TestAddress : public wxApp
{
public:
    bool OnInit(void);
};
//---------------------------------------------------------------------------
bool TestAddress::OnInit(void)
{
    if (!wxAppConsole::OnInit())
        return false;

    SetAppName(_T("TestAddress"));
    SetVendorName(_T("Test"));

    wxXmlResource::Get()->InitAllHandlers();
    InitXmlResource();

    WndMain *frmMain = new WndMain(_("Test"),
                                   wxDefaultPosition,
                                   wxDefaultSize);
    frmMain->Show();
    SetTopWindow(frmMain);

    return true;
}
//---------------------------------------------------------------------------
IMPLEMENT_APP(TestAddress)
//---------------------------------------------------------------------------
