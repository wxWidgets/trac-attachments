/////////////////////////////////////////////////////////////////////////////
// Name:        Test.cpp
// Purpose:     
// Author:      Quincy Liu
// Modified by: 
// Created:     17/05/2010 15:36:21
// RCS-ID:      
// Copyright:   
// Licence:     
/////////////////////////////////////////////////////////////////////////////

// For compilers that support precompilation, includes "wx/wx.h".
#include "wx/wxprec.h"

#ifdef __BORLANDC__
#pragma hdrstop
#endif

#ifndef WX_PRECOMP
#include "wx/wx.h"
#endif

#include <wx/print.h>

////@begin includes
////@end includes

#include "Test.h"

////@begin XPM images
////@end XPM images


/*
 * Test type definition
 */

IMPLEMENT_DYNAMIC_CLASS( Test, wxDialog )


/*
 * Test event table definition
 */

BEGIN_EVENT_TABLE( Test, wxDialog )

////@begin Test event table entries
    EVT_CHOICE( ID_CHOICE, Test::OnChoiceSelected )

    EVT_BUTTON( ID_BUTTON, Test::OnButtonClick )

	EVT_BUTTON( ID_BUTTON_PRINTERS, Test::OnPrinterButtonClick )

////@end Test event table entries

END_EVENT_TABLE()


/*
 * Test constructors
 */

Test::Test()
{
    Init();
}

Test::Test( wxWindow* parent, wxWindowID id, const wxString& caption, const wxPoint& pos, const wxSize& size, long style )
{
    Init();
    Create(parent, id, caption, pos, size, style);
}


/*
 * Test creator
 */

bool Test::Create( wxWindow* parent, wxWindowID id, const wxString& caption, const wxPoint& pos, const wxSize& size, long style )
{
////@begin Test creation
    SetExtraStyle(wxWS_EX_BLOCK_EVENTS);
    wxDialog::Create( parent, id, caption, pos, size, style );

    CreateControls();
    if (GetSizer())
    {
        GetSizer()->SetSizeHints(this);
    }
    Centre();
////@end Test creation
    return true;
}


/*
 * Test destructor
 */

Test::~Test()
{
////@begin Test destruction
////@end Test destruction
}


/*
 * Member initialisation
 */

void Test::Init()
{
////@begin Test member initialisation
////@end Test member initialisation
}


void Test::GetPrinterNames(wxArrayString& strings)
{
	/*
		DWORD cbNeeded = 0, nPrinters = 0;

	EnumPrintersW(PRINTER_ENUM_LOCAL | PRINTER_ENUM_CONNECTIONS,
		NULL, 2, NULL, 0, &cbNeeded, &nPrinters);

	HGLOBAL h_printer_info = GlobalAlloc(GHND, cbNeeded);
	LPBYTE p_printer_info = (LPBYTE) GlobalLock(h_printer_info);

	if (p_printer_info)
	{
		if (EnumPrintersW(PRINTER_ENUM_LOCAL | PRINTER_ENUM_CONNECTIONS,
			NULL, 2, p_printer_info, cbNeeded, &cbNeeded, &nPrinters))		
		{
			PRINTER_INFO_2W* pPrinters = reinterpret_cast<PRINTER_INFO_2W*>(p_printer_info);
			// cache printer names and other driver names and port names
			for (unsigned int i = 0; i < nPrinters; ++i, ++pPrinters)
			{
				std::wstring tmp_printer_name(pPrinters->pPrinterName);
				printerNames.push_back(tmp_printer_name);
				m_printer_driver_names.insert(std::pair<std::wstring, std::wstring>(tmp_printer_name, std::wstring(pPrinters->pDriverName)));
				m_printer_port_names.insert(std::pair<std::wstring, std::wstring>(tmp_printer_name, std::wstring(pPrinters->pPortName)));
			}
			result = true;
		}
		if (GlobalUnlock(h_printer_info))
		{
			result = false;
		}
	}	
	GlobalFree(h_printer_info);
	*/
}


/*
 * Control creation for Test
 */

void Test::CreateControls()
{    
////@begin Test content construction
    Test* itemDialog1 = this;

    wxBoxSizer* itemBoxSizer2 = new wxBoxSizer(wxHORIZONTAL);
    itemDialog1->SetSizer(itemBoxSizer2);

	wxButton* itemButton40 = new wxButton( itemDialog1, ID_BUTTON_PRINTERS, _("wxPrinters"), wxDefaultPosition, wxDefaultSize, 0 );
    itemBoxSizer2->Add(itemButton40, 0, wxALIGN_CENTER_VERTICAL|wxALL, 5);

    wxArrayString itemChoice3Strings;
	this->GetPrinterNames(itemChoice3Strings);
    wxChoice* itemChoice3 = new wxChoice( itemDialog1, ID_CHOICE, wxDefaultPosition, wxDefaultSize, itemChoice3Strings, 0 );
    itemBoxSizer2->Add(itemChoice3, 0, wxALIGN_CENTER_VERTICAL|wxALL, 5);

    wxButton* itemButton4 = new wxButton( itemDialog1, ID_BUTTON, _("Properties"), wxDefaultPosition, wxDefaultSize, 0 );
    itemBoxSizer2->Add(itemButton4, 0, wxALIGN_CENTER_VERTICAL|wxALL, 5);

////@end Test content construction
	
}


/*
 * Should we show tooltips?
 */

bool Test::ShowToolTips()
{
    return true;
}

/*
 * Get bitmap resources
 */

wxBitmap Test::GetBitmapResource( const wxString& name )
{
    // Bitmap retrieval
////@begin Test bitmap retrieval
    wxUnusedVar(name);
    return wxNullBitmap;
////@end Test bitmap retrieval
}

/*
 * Get icon resources
 */

wxIcon Test::GetIconResource( const wxString& name )
{
    // Icon retrieval
////@begin Test icon retrieval
    wxUnusedVar(name);
    return wxNullIcon;
////@end Test icon retrieval
}


/*
 * wxEVT_COMMAND_CHOICE_SELECTED event handler for ID_CHOICE
 */

void Test::OnChoiceSelected( wxCommandEvent& event )
{
////@begin wxEVT_COMMAND_CHOICE_SELECTED event handler for ID_CHOICE in Test.
    // Before editing this code, remove the block markers.
    event.Skip();
////@end wxEVT_COMMAND_CHOICE_SELECTED event handler for ID_CHOICE in Test. 
}


/*
 * wxEVT_COMMAND_BUTTON_CLICKED event handler for ID_BUTTON
 */

void Test::OnButtonClick( wxCommandEvent& event )
{
	wxPrinter p;
	//p.Print(this);
}


void Test::OnPrinterButtonClick( wxCommandEvent& event )
{   
	wxPrinter p;
	p.PrintDialog(this);
}
