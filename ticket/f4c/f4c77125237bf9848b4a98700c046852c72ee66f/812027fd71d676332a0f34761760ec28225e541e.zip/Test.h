/////////////////////////////////////////////////////////////////////////////
// Name:        Test.h
// Purpose:     
// Author:      Quincy Liu
// Modified by: 
// Created:     17/05/2010 15:36:21
// RCS-ID:      
// Copyright:   
// Licence:     
/////////////////////////////////////////////////////////////////////////////

#ifndef _TEST_H_
#define _TEST_H_


/*!
 * Includes
 */

////@begin includes
////@end includes

/*!
 * Forward declarations
 */

////@begin forward declarations
////@end forward declarations

/*!
 * Control identifiers
 */

////@begin control identifiers
#define ID_TEST 10000
#define ID_CHOICE 10001
#define ID_BUTTON 10002
#define ID_BUTTON_PRINTERS 10003
#define SYMBOL_TEST_STYLE wxCAPTION|wxRESIZE_BORDER|wxSYSTEM_MENU|wxCLOSE_BOX|wxTAB_TRAVERSAL
#define SYMBOL_TEST_TITLE _("test")
#define SYMBOL_TEST_IDNAME ID_TEST
#define SYMBOL_TEST_SIZE wxSize(400, 300)
#define SYMBOL_TEST_POSITION wxDefaultPosition
////@end control identifiers


/*!
 * Test class declaration
 */

class Test: public wxDialog
{    
    DECLARE_DYNAMIC_CLASS( Test )
    DECLARE_EVENT_TABLE()

public:
    /// Constructors
    Test();
    Test( wxWindow* parent, wxWindowID id = SYMBOL_TEST_IDNAME, const wxString& caption = SYMBOL_TEST_TITLE, const wxPoint& pos = SYMBOL_TEST_POSITION, const wxSize& size = SYMBOL_TEST_SIZE, long style = SYMBOL_TEST_STYLE );

    /// Creation
    bool Create( wxWindow* parent, wxWindowID id = SYMBOL_TEST_IDNAME, const wxString& caption = SYMBOL_TEST_TITLE, const wxPoint& pos = SYMBOL_TEST_POSITION, const wxSize& size = SYMBOL_TEST_SIZE, long style = SYMBOL_TEST_STYLE );

    /// Destructor
    ~Test();

    /// Initialises member variables
    void Init();

    /// Creates the controls and sizers
    void CreateControls();

////@begin Test event handler declarations

    /// wxEVT_COMMAND_CHOICE_SELECTED event handler for ID_CHOICE
    void OnChoiceSelected( wxCommandEvent& event );

    /// wxEVT_COMMAND_BUTTON_CLICKED event handler for ID_BUTTON
    void OnButtonClick( wxCommandEvent& event );

	void OnPrinterButtonClick(wxCommandEvent& event);
////@end Test event handler declarations

////@begin Test member function declarations

    /// Retrieves bitmap resources
    wxBitmap GetBitmapResource( const wxString& name );

    /// Retrieves icon resources
    wxIcon GetIconResource( const wxString& name );
////@end Test member function declarations

    /// Should we show tooltips?
    static bool ShowToolTips();

////@begin Test member variables
////@end Test member variables

	void GetPrinterNames(wxArrayString& strings);
};

#endif
    // _TEST_H_
