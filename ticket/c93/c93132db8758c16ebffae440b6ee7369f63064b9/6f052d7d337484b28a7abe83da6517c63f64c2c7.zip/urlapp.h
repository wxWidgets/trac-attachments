/////////////////////////////////////////////////////////////////////////////
// Name:        urlapp.h
// Purpose:     
// Author:      Ralph Pass
// Modified by: 
// Created:     Sun  5 Feb 13:02:34 2012
// RCS-ID:      
// Copyright:   Copyright (c) 2012 Ralph P. Pass III
// Licence:     
/////////////////////////////////////////////////////////////////////////////

#ifndef _URLAPP_H_
#define _URLAPP_H_


/*!
 * Includes
 */

////@begin includes
#include "wx/image.h"
#include "urlandmonospacetests.h"
////@end includes

/*!
 * Forward declarations
 */

////@begin forward declarations
////@end forward declarations

/*!
 * Control identifiers
 */

////@begin control identifiers
////@end control identifiers

/*!
 * UrlApp class declaration
 */

class UrlApp: public wxApp
{    
    DECLARE_CLASS( UrlApp )
    DECLARE_EVENT_TABLE()

public:
    /// Constructor
    UrlApp();

    void Init();

    /// Initialises the application
    virtual bool OnInit();

    /// Called on exit
    virtual int OnExit();

////@begin UrlApp event handler declarations

////@end UrlApp event handler declarations

////@begin UrlApp member function declarations

////@end UrlApp member function declarations

////@begin UrlApp member variables
////@end UrlApp member variables
};

/*!
 * Application instance declaration 
 */

////@begin declare app
DECLARE_APP(UrlApp)
////@end declare app

#endif
    // _URLAPP_H_
