/////////////////////////////////////////////////////////////////////////////
// Name:        urlapp.cpp
// Purpose:     
// Author:      Ralph Pass
// Modified by: 
// Created:     Sun  5 Feb 13:02:34 2012
// RCS-ID:      
// Copyright:   Copyright (c) 2012 Ralph P. Pass III
// Licence:     
/////////////////////////////////////////////////////////////////////////////

// For compilers that support precompilation, includes "wx/wx.h".
#include "wx/wxprec.h"

#ifdef __BORLANDC__
#pragma hdrstop
#endif

#ifndef WX_PRECOMP
#include "wx/wx.h"
#endif

////@begin includes
////@end includes

#include "urlapp.h"

#include <fstream>
using namespace std;
extern ofstream ooo;
#include "urltest.h"

////@begin XPM images
////@end XPM images


/*
 * Application instance implementation
 */

////@begin implement app
IMPLEMENT_APP( UrlApp )
////@end implement app


/*
 * UrlApp type definition
 */

IMPLEMENT_CLASS( UrlApp, wxApp )


/*
 * UrlApp event table definition
 */

BEGIN_EVENT_TABLE( UrlApp, wxApp )

////@begin UrlApp event table entries
////@end UrlApp event table entries

END_EVENT_TABLE()


/*
 * Constructor for UrlApp
 */

UrlApp::UrlApp()
{
    Init();
}


/*
 * Member initialisation
 */

void UrlApp::Init()
{
////@begin UrlApp member initialisation
////@end UrlApp member initialisation
}

/*
 * Initialisation for UrlApp
 */

bool UrlApp::OnInit()
{    
    ooo << "Entrance to OnInit " << endl;
    URLTest test1;

////@begin UrlApp initialisation
	// Remove the comment markers above and below this block
	// to make permanent changes to the code.

#if wxUSE_XPM
	wxImage::AddHandler(new wxXPMHandler);
#endif
#if wxUSE_LIBPNG
	wxImage::AddHandler(new wxPNGHandler);
#endif
#if wxUSE_LIBJPEG
	wxImage::AddHandler(new wxJPEGHandler);
#endif
#if wxUSE_GIF
	wxImage::AddHandler(new wxGIFHandler);
#endif
	URLandMonoSpaceTests* mainWindow = new URLandMonoSpaceTests( NULL );
	mainWindow->Show(true);
////@end UrlApp initialisation
    ooo << "After mainWindow show " << endl;
    URLTest test2;
    return true;
}


/*
 * Cleanup for UrlApp
 */

int UrlApp::OnExit()
{    
////@begin UrlApp cleanup
	return wxApp::OnExit();
////@end UrlApp cleanup
}

