// urltest.h
// 02/05/2012 18:19  Ralph Pass
// Copyright (c) 2012   Ralph Pass
//
//

//-------------------------------------------------------------
// Class: URLTest
//
// Description:
//
//
// Usage:
//
//-------------------------------------------------------------

#ifndef URLTEST_H
#define URLTEST_H

class URLTest
{
  public:
	URLTest();
	virtual ~URLTest();


  private:
	URLTest(const URLTest & );
	URLTest & operator=(const URLTest & );
};

#endif

