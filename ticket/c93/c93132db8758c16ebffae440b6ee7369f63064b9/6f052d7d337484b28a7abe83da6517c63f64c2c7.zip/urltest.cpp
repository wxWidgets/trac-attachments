// urltest.cpp
// 02/05/2012 18:19  Ralph Pass
// Copyright (c) 2012   Ralph Pass
//
//
#ifndef URLTEST_H
#include "urltest.h"
#endif

#include <fstream>
using namespace std;
extern ofstream ooo;

#include "wx/string.h"
#include "wx/url.h"

//------------------------------------------------------------------------------
// constants

//-------------------------------------------------------------
URLTest::URLTest()
{
  wxString text("http://www.minorplanetcenter.net/iau/Ephemerides/Comets/Soft06Cmt.txt");
  wxURL url(text);
  if (url.GetError() == wxURL_NOERR) 
    { 
        ooo << "url, no error" << endl;
      wxInputStream *in_stream; 
      in_stream = url.GetInputStream(); 
      if (in_stream)
	{
    ooo << "url GetInputStream returned non null" << endl;
	  wxInt32 size = (wxInt32)(in_stream->GetSize());
      ooo << "Returned stream size " << size << endl;
	  if (size > 0)
	    {
	    }
	  delete in_stream;
	}
    } 
}

//-------------------------------------------------------------
// URLTest::URLTest(const URLTest & copy)
// {
// }

//-------------------------------------------------------------
URLTest::~URLTest()
{
}

//-------------------------------------------------------------
// URLTest & URLTest::operator=(const URLTest & copy)
// {
//     if (this != &copy)
//     {
//         //real assignment work goes here,
//         //dont forget to delete existing allocations
//     }
//     return *this;
// }

