/////////////////////////////////////////////////////////////////////////////
// Name:        urlandmonospacetests.h
// Purpose:     
// Author:      Ralph Pass
// Modified by: 
// Created:     Sun  5 Feb 13:47:55 2012
// RCS-ID:      
// Copyright:   Copyright (c) 2012 Ralph P. Pass III
// Licence:     
/////////////////////////////////////////////////////////////////////////////

#ifndef _URLANDMONOSPACETESTS_H_
#define _URLANDMONOSPACETESTS_H_


/*!
 * Includes
 */

////@begin includes
#include "wx/frame.h"
////@end includes

/*!
 * Forward declarations
 */

////@begin forward declarations
////@end forward declarations

/*!
 * Control identifiers
 */

////@begin control identifiers
#define ID_URLANDMONOSPACETESTS 10000
#define ID_MENUITEM 10002
#define ID_TEXTCTRL 10003
#define ID_LISTBOX 10004
#define SYMBOL_URLANDMONOSPACETESTS_STYLE wxCAPTION|wxRESIZE_BORDER|wxSYSTEM_MENU|wxCLOSE_BOX
#define SYMBOL_URLANDMONOSPACETESTS_TITLE _("MonoSpace Tests")
#define SYMBOL_URLANDMONOSPACETESTS_IDNAME ID_URLANDMONOSPACETESTS
#define SYMBOL_URLANDMONOSPACETESTS_SIZE wxSize(400, 300)
#define SYMBOL_URLANDMONOSPACETESTS_POSITION wxDefaultPosition
////@end control identifiers


/*!
 * URLandMonoSpaceTests class declaration
 */

class URLandMonoSpaceTests: public wxFrame
{    
    DECLARE_CLASS( URLandMonoSpaceTests )
    DECLARE_EVENT_TABLE()

public:
    /// Constructors
    URLandMonoSpaceTests();
    URLandMonoSpaceTests( wxWindow* parent, wxWindowID id = SYMBOL_URLANDMONOSPACETESTS_IDNAME, const wxString& caption = SYMBOL_URLANDMONOSPACETESTS_TITLE, const wxPoint& pos = SYMBOL_URLANDMONOSPACETESTS_POSITION, const wxSize& size = SYMBOL_URLANDMONOSPACETESTS_SIZE, long style = SYMBOL_URLANDMONOSPACETESTS_STYLE );

    bool Create( wxWindow* parent, wxWindowID id = SYMBOL_URLANDMONOSPACETESTS_IDNAME, const wxString& caption = SYMBOL_URLANDMONOSPACETESTS_TITLE, const wxPoint& pos = SYMBOL_URLANDMONOSPACETESTS_POSITION, const wxSize& size = SYMBOL_URLANDMONOSPACETESTS_SIZE, long style = SYMBOL_URLANDMONOSPACETESTS_STYLE );

    /// Destructor
    ~URLandMonoSpaceTests();

    /// Initialises member variables
    void Init();

    /// Creates the controls and sizers
    void CreateControls();

////@begin URLandMonoSpaceTests event handler declarations

    /// wxEVT_COMMAND_MENU_SELECTED event handler for ID_MENUITEM
    void OnMenuitemClick( wxCommandEvent& event );

////@end URLandMonoSpaceTests event handler declarations

////@begin URLandMonoSpaceTests member function declarations

    /// Retrieves bitmap resources
    wxBitmap GetBitmapResource( const wxString& name );

    /// Retrieves icon resources
    wxIcon GetIconResource( const wxString& name );
////@end URLandMonoSpaceTests member function declarations

    /// Should we show tooltips?
    static bool ShowToolTips();

////@begin URLandMonoSpaceTests member variables
    wxTextCtrl* mText;
    wxListBox* mList;
////@end URLandMonoSpaceTests member variables
};

#endif
    // _URLANDMONOSPACETESTS_H_
