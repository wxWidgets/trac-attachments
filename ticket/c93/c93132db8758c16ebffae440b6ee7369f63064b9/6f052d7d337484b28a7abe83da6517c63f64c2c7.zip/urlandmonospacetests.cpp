/////////////////////////////////////////////////////////////////////////////
// Name:        urlandmonospacetests.cpp
// Purpose:     
// Author:      Ralph Pass
// Modified by: 
// Created:     Sun  5 Feb 13:47:55 2012
// RCS-ID:      
// Copyright:   Copyright (c) 2012 Ralph P. Pass III
// Licence:     
/////////////////////////////////////////////////////////////////////////////

// For compilers that support precompilation, includes "wx/wx.h".
#include "wx/wxprec.h"

#ifdef __BORLANDC__
#pragma hdrstop
#endif

#ifndef WX_PRECOMP
#include "wx/wx.h"
#endif

////@begin includes
////@end includes

#include "urlandmonospacetests.h"

#include <fstream>
using namespace std;
ofstream ooo("debug.txt");
#include "urltest.h"
#include <wx/arrstr.h>

////@begin XPM images
////@end XPM images


/*
 * URLandMonoSpaceTests type definition
 */

IMPLEMENT_CLASS( URLandMonoSpaceTests, wxFrame )


/*
 * URLandMonoSpaceTests event table definition
 */

BEGIN_EVENT_TABLE( URLandMonoSpaceTests, wxFrame )

////@begin URLandMonoSpaceTests event table entries
    EVT_MENU( ID_MENUITEM, URLandMonoSpaceTests::OnMenuitemClick )

////@end URLandMonoSpaceTests event table entries

END_EVENT_TABLE()


/*
 * URLandMonoSpaceTests constructors
 */

URLandMonoSpaceTests::URLandMonoSpaceTests()
{
    Init();
}

URLandMonoSpaceTests::URLandMonoSpaceTests( wxWindow* parent, wxWindowID id, const wxString& caption, const wxPoint& pos, const wxSize& size, long style )
{
    Init();
    Create( parent, id, caption, pos, size, style );
}


/*
 * URLandMonoSpaceTests creator
 */

bool URLandMonoSpaceTests::Create( wxWindow* parent, wxWindowID id, const wxString& caption, const wxPoint& pos, const wxSize& size, long style )
{
////@begin URLandMonoSpaceTests creation
    wxFrame::Create( parent, id, caption, pos, size, style );

    CreateControls();
    Centre();
////@end URLandMonoSpaceTests creation
    return true;
}


/*
 * URLandMonoSpaceTests destructor
 */

URLandMonoSpaceTests::~URLandMonoSpaceTests()
{
////@begin URLandMonoSpaceTests destruction
////@end URLandMonoSpaceTests destruction
}


/*
 * Member initialisation
 */

void URLandMonoSpaceTests::Init()
{
////@begin URLandMonoSpaceTests member initialisation
    mText = NULL;
    mList = NULL;
////@end URLandMonoSpaceTests member initialisation
}


/*
 * Control creation for URLandMonoSpaceTests
 */

void URLandMonoSpaceTests::CreateControls()
{    
////@begin URLandMonoSpaceTests content construction
    URLandMonoSpaceTests* itemFrame1 = this;

    wxMenuBar* menuBar = new wxMenuBar;
    wxMenu* itemMenu3 = new wxMenu;
    itemMenu3->Append(ID_MENUITEM, _("Test Monospace"), wxEmptyString, wxITEM_NORMAL);
    menuBar->Append(itemMenu3, _("&Test"));
    itemFrame1->SetMenuBar(menuBar);

    wxBoxSizer* itemBoxSizer5 = new wxBoxSizer(wxVERTICAL);
    itemFrame1->SetSizer(itemBoxSizer5);

    mText = new wxTextCtrl( itemFrame1, ID_TEXTCTRL, _("This is a sample text.  See how long it is"), wxDefaultPosition, wxSize(400, 100), wxTE_MULTILINE );
    itemBoxSizer5->Add(mText, 0, wxALIGN_CENTER_HORIZONTAL|wxALL, 5);

    wxArrayString mListStrings;
    mListStrings.Add(_("asfouq asouf qwe asf qwenfluh qoweuhf "));
    mList = new wxListBox( itemFrame1, ID_LISTBOX, wxDefaultPosition, wxSize(400, 100), mListStrings, wxLB_SINGLE );
    mList->SetStringSelection(_("Second list of tests.  See how long it is"));
    itemBoxSizer5->Add(mList, 0, wxALIGN_CENTER_HORIZONTAL|wxALL, 5);

////@end URLandMonoSpaceTests content construction
}


/*
 * Should we show tooltips?
 */

bool URLandMonoSpaceTests::ShowToolTips()
{
    return true;
}

/*
 * Get bitmap resources
 */

wxBitmap URLandMonoSpaceTests::GetBitmapResource( const wxString& name )
{
    // Bitmap retrieval
////@begin URLandMonoSpaceTests bitmap retrieval
    wxUnusedVar(name);
    return wxNullBitmap;
////@end URLandMonoSpaceTests bitmap retrieval
}

/*
 * Get icon resources
 */

wxIcon URLandMonoSpaceTests::GetIconResource( const wxString& name )
{
    // Icon retrieval
////@begin URLandMonoSpaceTests icon retrieval
    wxUnusedVar(name);
    return wxNullIcon;
////@end URLandMonoSpaceTests icon retrieval
}


/*
 * wxEVT_COMMAND_MENU_SELECTED event handler for ID_MENUITEM
 */

void URLandMonoSpaceTests::OnMenuitemClick( wxCommandEvent& event )
{
    ooo << endl << "Selected from menu " << endl;
    wxArrayString t;
    t.Add("One Line of text to see the size");
    mList->InsertItems(t, 0);
    mText->ChangeValue("One Line of text to see the size");
    wxFont font = mText->GetFont();
        font.SetFamily(wxFONTFAMILY_MODERN);
        font.SetFaceName("Courier");
        mText->SetFont(font);
        font = mList->GetFont();
        font.SetFamily(wxFONTFAMILY_MODERN);
        font.SetFaceName("Courier");
        mList->SetFont(font);
        mList->Refresh();
        Refresh();
    
////@begin wxEVT_COMMAND_MENU_SELECTED event handler for ID_MENUITEM in URLandMonoSpaceTests.
    // Before editing this code, remove the block markers.
    event.Skip();
////@end wxEVT_COMMAND_MENU_SELECTED event handler for ID_MENUITEM in URLandMonoSpaceTests. 
}

