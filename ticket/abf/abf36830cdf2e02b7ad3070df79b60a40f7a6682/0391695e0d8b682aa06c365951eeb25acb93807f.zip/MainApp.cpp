#include "MainApp.h"

IMPLEMENT_APP(MainApp)

MainApp::MainApp() : wxApp()
{
}

bool MainApp::OnInit()
{
	_pMainFrame = new wxFrame(NULL, wxID_ANY, _("Some Frame"),
			wxDefaultPosition, wxSize(600,400));

	long flags = wxWANTS_CHARS|wxSTATIC_BORDER|wxTE_PROCESS_TAB|
		wxTE_AUTO_SCROLL|wxTE_PROCESS_ENTER|wxALWAYS_SHOW_SB;

	wxGrid* pGrid = new wxGrid(_pMainFrame, wxID_ANY, wxDefaultPosition,
				wxDefaultSize, flags);

	pGrid->CreateGrid(5,2);

	this->SetTopWindow(_pMainFrame);
	_pMainFrame->Show();
}

