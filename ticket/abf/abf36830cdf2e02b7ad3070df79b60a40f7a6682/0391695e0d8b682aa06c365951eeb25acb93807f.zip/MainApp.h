#ifndef MAINAPP
#define MAINAPP

#include <wx/wxprec.h>
#ifndef WX_PRECOMP
#include <wx/wx.h>
#endif

#include <wx/frame.h>
#include <wx/grid.h>

class MainApp : public wxApp
{
	public:
		MainApp();
		virtual bool OnInit();
	private:
		wxFrame* _pMainFrame;
};

DECLARE_APP(MainApp)

#endif //MAINAPP

