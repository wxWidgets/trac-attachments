/////////////////////////////////////////////////////////////////////////////
// Name:        samples/except/except_cpp98.h
// Purpose:     check stacktrace works correctly with non-ASCII identifiers
// Author:      Suzumizaki-Kimitaka
// Modified by:
// Created:     2015-06-15
// RCS-ID:
// Copyright:   (C) Suzumizaki-Kimitaka
// Licence:     wxWindows licence
/////////////////////////////////////////////////////////////////////////////

#ifndef wxSTACKTRACE_WITH_UNICODE
#ifdef _MSC_VER
#define wxSTACKTRACE_WITH_UNICODE 1
#else
#define wxSTACKTRACE_WITH_UNICODE 0
#endif
#endif // wxSTACKTRACE_WITH_UNICODE

#if wxSTACKTRACE_WITH_UNICODE
#include "wx/dialog.h"
#include "wx/frame.h"
wxDialog* GenerateDialogUnicode(wxFrame* parent);

#endif
