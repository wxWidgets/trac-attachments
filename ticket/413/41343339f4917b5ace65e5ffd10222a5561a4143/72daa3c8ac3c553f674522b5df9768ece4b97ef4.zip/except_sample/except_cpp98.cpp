/////////////////////////////////////////////////////////////////////////////
// Name:        samples/except/except_utf8.cpp
// Purpose:
// Author:      Suzumizaki-Kimitaka
// Modified by:
// Created:     2015-06-14
// RCS-ID:
// Copyright:   (C) Suzumizaki-Kimitaka
// Licence:     wxWindows licence
/////////////////////////////////////////////////////////////////////////////

/*
From C++98, the C++ specifications allow universal identifiers.
But the encoding which the compilers or linkers allow is optional even
with C++11 or later.

This means we can ues \uXXXX and \U0010XXXX style identifiers anywhere,
besides any Non-ASCII encoding is not portable even if it is UTF-8.

In fact we should consider:

- g++ has -fextended-identifiers, but the option is experimental even in 2015.
- Windows XP or earlier can't treat such identifiers within stack trace.
*/

// ============================================================================
// declarations
// ============================================================================

// ----------------------------------------------------------------------------
// headers
// ----------------------------------------------------------------------------

// For compilers that support precompilation, includes "wx/wx.h".
#include "wx/wxprec.h"

#ifdef __BORLANDC__
    #pragma hdrstop
#endif

#include "except_cpp98.h"

#if wxSTACKTRACE_WITH_UNICODE

#ifndef WX_PRECOMP
    #include "wx/button.h"
    #include "wx/sizer.h"
    #include "wx/stattext.h"
    #include "wx/dynlib.h"
    #include "wx/msgdlg.h"
#endif

// ----------------------------------------------------------------------------
// private classes
// ----------------------------------------------------------------------------

// named 'Thai language, Japanese, Hindi' only for test purpose
class \u0e20\u0e32\u0e29\u0e32\u0e44\u0e17\u0e22\u65e5\u672c\u8a9e\u0939\u093f\u0928\u094d\u0926\u0940
 : public wxDialog
{
public:
    \u0e20\u0e32\u0e29\u0e32\u0e44\u0e17\u0e22\u65e5\u672c\u8a9e\u0939\u093f\u0928\u094d\u0926\u0940(wxFrame *parent);

    // event handlers
    void OnShowAssert(wxCommandEvent& event);
    void OnThrowObject(wxCommandEvent& event);
    void OnInvalidStringFormat(wxCommandEvent& event);
    void OnListLoadedModules(wxCommandEvent& event);

    // 'format string includes error'
    wxString \u66f8\u5f0f\u5b57\u5217\u306e\u8aa4\u308a();

private:
    DECLARE_EVENT_TABLE()
};

// A trivial exception class
class MyException
{
public:
    MyException(const wxString& msg) : m_msg(msg) { }

    const wxChar *what() const { return m_msg.c_str(); }

private:
    wxString m_msg;
};

// ----------------------------------------------------------------------------
// constants
// ----------------------------------------------------------------------------

// IDs for the controls and the menu commands
enum
{
    // control ids and menu items
    Except_utf8_ShowAssert = wxID_HIGHEST,
    Except_utf8_ListLoadedModules,
    Except_utf8_ThrowObject,
    Except_utf8_InvalidStringFormat,
};

// ----------------------------------------------------------------------------
// event tables and other macros for wxWidgets
// ----------------------------------------------------------------------------

BEGIN_EVENT_TABLE(\u0e20\u0e32\u0e29\u0e32\u0e44\u0e17\u0e22\u65e5\u672c\u8a9e\u0939\u093f\u0928\u094d\u0926\u0940, wxDialog)
    EVT_BUTTON(Except_utf8_ShowAssert, \u0e20\u0e32\u0e29\u0e32\u0e44\u0e17\u0e22\u65e5\u672c\u8a9e\u0939\u093f\u0928\u094d\u0926\u0940::OnShowAssert)
    EVT_BUTTON(Except_utf8_ListLoadedModules, \u0e20\u0e32\u0e29\u0e32\u0e44\u0e17\u0e22\u65e5\u672c\u8a9e\u0939\u093f\u0928\u094d\u0926\u0940::OnListLoadedModules)
    EVT_BUTTON(Except_utf8_ThrowObject, \u0e20\u0e32\u0e29\u0e32\u0e44\u0e17\u0e22\u65e5\u672c\u8a9e\u0939\u093f\u0928\u094d\u0926\u0940::OnThrowObject)
    EVT_BUTTON(Except_utf8_InvalidStringFormat,
               \u0e20\u0e32\u0e29\u0e32\u0e44\u0e17\u0e22\u65e5\u672c\u8a9e\u0939\u093f\u0928\u094d\u0926\u0940::OnInvalidStringFormat)
END_EVENT_TABLE()

// ============================================================================
// \u0e20\u0e32\u0e29\u0e32\u0e44\u0e17\u0e22\u65e5\u672c\u8a9e\u0939\u093f\u0928\u094d\u0926\u0940 implementation
// ============================================================================

\u0e20\u0e32\u0e29\u0e32\u0e44\u0e17\u0e22\u65e5\u672c\u8a9e\u0939\u093f\u0928\u094d\u0926\u0940::\u0e20\u0e32\u0e29\u0e32\u0e44\u0e17\u0e22\u65e5\u672c\u8a9e\u0939\u093f\u0928\u094d\u0926\u0940(wxFrame *parent)
        : wxDialog(parent, wxID_ANY, wxString(wxT("Throw exception dialog")))
{
    wxSizer *sizerTop = new wxBoxSizer(wxVERTICAL);

    sizerTop->Add(new wxStaticText(this, wxNewId(),
        wxT("Welcome. Now you can check whether your stack trace\ncorrectly ")
        wxT("shows non-ASCII identifier used as class name.\n\n")
        wxT("The name of this dialog class is '\u0e20\u0e32\u0e29\u0e32\u0e44\u0e17\u0e22\u65e5\u672c\u8a9e\u0939\u093f\u0928\u094d\u0926\u0940'. ")),
                  0, wxCENTRE | wxALL, 5);

    sizerTop->Add(new wxButton(this, Except_utf8_ThrowObject, wxT("Throw &object")),
                  0, wxCENTRE | wxALL, 5);
    sizerTop->Add(new wxButton(this, Except_utf8_ShowAssert,
                               wxT("Show &Assert invoked from wxArrayString")),
                  0, wxCENTRE | wxALL, 5);
    sizerTop->Add(new wxButton(this, Except_utf8_InvalidStringFormat,
                               wxT("Call wxString::&Format with bad parameter")),
                  0, wxCENTRE | wxALL, 5);
    sizerTop->Add(new wxButton(this, Except_utf8_ListLoadedModules,
                               wxT("List loaded modules")),
                  0, wxCENTRE | wxALL, 5);
    sizerTop->Add(new wxButton(this, wxID_CANCEL, wxT("&Cancel")),
                  0, wxCENTRE | wxALL, 5);

    SetSizerAndFit(sizerTop);
}

void \u0e20\u0e32\u0e29\u0e32\u0e44\u0e17\u0e22\u65e5\u672c\u8a9e\u0939\u093f\u0928\u094d\u0926\u0940::OnThrowObject(wxCommandEvent& WXUNUSED(event))
{
    throw MyException(wxT("Exception thrown from \u0e20\u0e32\u0e29\u0e32\u0e44\u0e17\u0e22\u65e5\u672c\u8a9e\u0939\u093f\u0928\u094d\u0926\u0940"));
}

void \u0e20\u0e32\u0e29\u0e32\u0e44\u0e17\u0e22\u65e5\u672c\u8a9e\u0939\u093f\u0928\u094d\u0926\u0940::OnShowAssert(wxCommandEvent& WXUNUSED(event))
{
    // provoke an assert from wxArrayString.
    // to test stack trace can include non-ASCII named class.
    wxArrayString arr;
    arr[0];
}

void \u0e20\u0e32\u0e29\u0e32\u0e44\u0e17\u0e22\u65e5\u672c\u8a9e\u0939\u093f\u0928\u094d\u0926\u0940::OnListLoadedModules(wxCommandEvent& WXUNUSED(event))
{
    wxDynamicLibraryDetailsArray list = wxDynamicLibrary::ListLoaded();
    wxString s;
    for (size_t i=0; i<list.Count(); ++i)
    {
        s << list[i].GetName() << wxT(" ");
        if (list[i].GetVersion().Trim().Trim(false).size())
        {
            s << list[i].GetVersion() << wxT("\n");
        }
        else
        {
            s << wxT("(not versioned)\n");
        }
    }
    wxMessageBox(s, wxT("The modules currently loaded are:"));
}


wxString \u0e20\u0e32\u0e29\u0e32\u0e44\u0e17\u0e22\u65e5\u672c\u8a9e\u0939\u093f\u0928\u094d\u0926\u0940::\u66f8\u5f0f\u5b57\u5217\u306e\u8aa4\u308a()
{
    // provoke an assert from wxString::Format.
    // currently, assertion faied in wxArgNormalizer<int>::wxArgNormalizer<int>.
    return wxString::Format("%s", 1717);
}

void \u0e20\u0e32\u0e29\u0e32\u0e44\u0e17\u0e22\u65e5\u672c\u8a9e\u0939\u093f\u0928\u094d\u0926\u0940::OnInvalidStringFormat(wxCommandEvent& WXUNUSED(event))
{
    // to test stack trace can include non-ASCII named function.
    \u66f8\u5f0f\u5b57\u5217\u306e\u8aa4\u308a();
}

// ============================================================================
// global functions implementation
// ============================================================================

wxDialog* GenerateDialogUnicode(wxFrame* parent)
{
    return new \u0e20\u0e32\u0e29\u0e32\u0e44\u0e17\u0e22\u65e5\u672c\u8a9e\u0939\u093f\u0928\u094d\u0926\u0940(parent);
}

#endif // wxSTACKTRACE_WITH_UNICODE
