//---------------------------------------------------------------------------
//
// Name:        IP0_TestApp.h
// Author:      Simon Peacock
// Created:     27/10/2011 3:10:54 p.m.
// Description: 
//
//---------------------------------------------------------------------------

#ifndef __IP0_TESTDLGApp_h__
#define __IP0_TESTDLGApp_h__

#ifdef __BORLANDC__
	#pragma hdrstop
#endif

#ifndef WX_PRECOMP
	#include <wx/wx.h>
#else
	#include <wx/wxprec.h>
#endif

class IP0_TestDlgApp : public wxApp
{
	public:
		bool OnInit();
		int OnExit();
};

#endif
