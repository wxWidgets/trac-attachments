///-----------------------------------------------------------------
///
/// @file      IP0_TestDlg.h
/// @author    Simon Peacock
/// Created:   27/10/2011 3:10:54 p.m.
/// @section   DESCRIPTION
///            IP0_TestDlg class declaration
///
///------------------------------------------------------------------

#ifndef __IP0_TESTDLG_H__
#define __IP0_TESTDLG_H__

#ifdef __BORLANDC__
	#pragma hdrstop
#endif

#ifndef WX_PRECOMP
	#include <wx/wx.h>
	#include <wx/dialog.h>
#else
	#include <wx/wxprec.h>
#endif

//Do not add custom headers between 
//Header Include Start and Header Include End.
//wxDev-C++ designer will remove them. Add custom headers after the block.
////Header Include Start
#include <wx/timer.h>
////Header Include End

#include <wx/socket.h>

////Dialog Style Start
#undef IP0_TestDlg_STYLE
#define IP0_TestDlg_STYLE wxCAPTION | wxSYSTEM_MENU | wxDIALOG_NO_PARENT | wxMINIMIZE_BOX | wxCLOSE_BOX
////Dialog Style End

class IP0_TestDlg : public wxDialog
{
	private:
		DECLARE_EVENT_TABLE();
		
	public:
		IP0_TestDlg(wxWindow *parent, wxWindowID id = 1, const wxString &title = wxT("IP0_Test"), const wxPoint& pos = wxDefaultPosition, const wxSize& size = wxDefaultSize, long style = IP0_TestDlg_STYLE);
		virtual ~IP0_TestDlg();
	
	private:
		//Do not add custom control declarations between 
		//GUI Control Declaration Start and GUI Control Declaration End.
		//wxDev-C++ will remove them. Add custom code after the block.
		////GUI Control Declaration Start
		wxTimer *WxTimer;
		////GUI Control Declaration End
		
	private:
		//Note: if you receive any error with these enum IDs, then you need to
		//change your old form code that are based on the #define control IDs.
		//#defines may replace a numeric value for the enum names.
		//Try copy and pasting the below block in your old form header files.
		enum
		{
			////GUI Enum Control ID Start
			ID_WXTIMER = 1001,
			////GUI Enum Control ID End
			ID_DUMMY_VALUE_ //don't remove this value unless you have other enum values
		};
        enum {
            CONFIG_PORT = 9997,
            LOCAL_PORT  = 49152,
            ID_WXUDP_EVENT = 1000
        };
	
	private:
		void OnClose(wxCloseEvent& event);
		void CreateGUIControls();
		void OnUDPEvent(wxSocketEvent& event);
        void OnTimer(wxTimerEvent& event);

        wxIPV4address       LocalAddr, PollAddr;
        wxDatagramSocket    *PollSocket;

};

#endif
