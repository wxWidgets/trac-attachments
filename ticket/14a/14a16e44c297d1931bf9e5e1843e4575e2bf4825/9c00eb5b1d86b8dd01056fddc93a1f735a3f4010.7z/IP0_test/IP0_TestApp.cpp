//---------------------------------------------------------------------------
//
// Name:        IP0_TestApp.cpp
// Author:      Simon Peacock
// Created:     27/10/2011 3:10:54 p.m.
// Description: 
//
//---------------------------------------------------------------------------

#include "IP0_TestApp.h"
#include "IP0_TestDlg.h"

IMPLEMENT_APP(IP0_TestDlgApp)

bool IP0_TestDlgApp::OnInit()
{
	IP0_TestDlg* dialog = new IP0_TestDlg(NULL);
	SetTopWindow(dialog);
	dialog->Show(true);		
	return true;
}
 
int IP0_TestDlgApp::OnExit()
{
	return 0;
}
