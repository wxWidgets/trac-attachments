///-----------------------------------------------------------------
///
/// @file      IP0_TestDlg.cpp
/// @author    Simon Peacock
/// Created:   27/10/2011 3:10:54 p.m.
/// @section   DESCRIPTION
///            IP0_TestDlg class implementation
///
///------------------------------------------------------------------

#include "IP0_TestDlg.h"

//Do not add custom headers
//wxDev-C++ designer will remove them
////Header Include Start
////Header Include End

//----------------------------------------------------------------------------
// IP0_TestDlg
//----------------------------------------------------------------------------
//Add Custom Events only in the appropriate block.
//Code added in other places will be removed by wxDev-C++
////Event Table Start
BEGIN_EVENT_TABLE(IP0_TestDlg,wxDialog)
	////Manual Code Start
	EVT_SOCKET(ID_WXUDP_EVENT,IP0_TestDlg::OnUDPEvent)
	////Manual Code End
	
	EVT_CLOSE(IP0_TestDlg::OnClose)
	EVT_TIMER(ID_WXTIMER,IP0_TestDlg::OnTimer)
END_EVENT_TABLE()
////Event Table End

IP0_TestDlg::IP0_TestDlg(wxWindow *parent, wxWindowID id, const wxString &title, const wxPoint &position, const wxSize& size, long style)
: wxDialog(parent, id, title, position, size, style)
{
	CreateGUIControls();
}

IP0_TestDlg::~IP0_TestDlg()
{
} 

void IP0_TestDlg::CreateGUIControls()
{
	//Do not add custom code between
	//GUI Items Creation Start and GUI Items Creation End.
	//wxDev-C++ designer will remove them.
	//Add the custom code before or after the blocks
	////GUI Items Creation Start

	WxTimer = new wxTimer();
	WxTimer->SetOwner(this, ID_WXTIMER);

	SetTitle(wxT("IP0_Test"));
	SetIcon(wxNullIcon);
	SetSize(8,8,320,334);
	Center();
	
	////GUI Items Creation End
    PollAddr.Hostname("255.255.255.255");       // Send to Broadcast Address
	PollAddr.Service(CONFIG_PORT);

    LocalAddr.AnyAddress();
    LocalAddr.Service(LOCAL_PORT);
    
    WxTimer = new wxTimer();
	WxTimer->SetOwner(this, ID_WXTIMER);

    // Setup the Poll Socket
    PollSocket = new wxDatagramSocket(LocalAddr, wxSOCKET_NONE);
    static int b = 1;
    PollSocket->SetOption(SOL_SOCKET, SO_BROADCAST, &b, sizeof(b));

    PollSocket->SetEventHandler(*(GetEventHandler()), ID_WXUDP_EVENT);
    PollSocket->SetNotify(wxSOCKET_INPUT_FLAG);
    PollSocket->Notify(true);

    FILE *fp = fopen("log.txt", "w");
    fclose (fp);
    WxTimer->Start(1000);
}

void IP0_TestDlg::OnClose(wxCloseEvent& /*event*/)
{
	Destroy();
}

/***************************************************************************
***************************************************************************/
void IP0_TestDlg::OnTimer(wxTimerEvent& event) {
    static int count = 0;
    

    static const uint8_t data[] = {0x40, 0x28, 0x24, 0xfa, 0xbf, 0x29, 0xe4, 0x49};
    PollSocket->SendTo(PollAddr, &data, sizeof(data));
    
    if (++count > 10) Destroy();
}

/***************************************************************************
***************************************************************************/
void IP0_TestDlg::OnUDPEvent(wxSocketEvent& event) {
    uint8_t *buffer = new uint8_t [1000];
    wxIPV4address RemoteAddr;
    
    PollSocket->RecvFrom(RemoteAddr, buffer, 1000);

    FILE *fp = fopen("log.txt", "a");
    
    if(PollSocket->Error()) {
        if (fp) {
            fprintf(fp, "received error");
        }
        return;
    }

    size_t nSize = PollSocket->LastCount();
    if (fp) {
        fprintf(fp, "received %d bytes from %s ", nSize, RemoteAddr.IPAddress().c_str());
    }
    
    char buf[10000];
    for (int i = 0; i < nSize; i++) {
        sprintf(&buf[i*3], "%02x ", buffer[i]);
    }
    if (fp) {    
        time_t rawtime;
        struct tm * timeinfo;

        time(&rawtime);
        timeinfo = localtime(&rawtime);

        fprintf(fp, "%s @ %s", buf, asctime(timeinfo));
    }
    
    delete [] buffer;
    fclose (fp);
}
