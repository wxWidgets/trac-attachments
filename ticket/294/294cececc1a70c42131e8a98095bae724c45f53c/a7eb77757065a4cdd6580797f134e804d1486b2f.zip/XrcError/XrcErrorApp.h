#ifndef _XRCERRORAPP_H_
#define _XRCERRORAPP_H_


//#include <wx/wx.h>
//#include <wx/intl.h>
#include "wx/xrc/xmlres.h"


class XrcErrorApp : public wxApp
{
    DECLARE_CLASS(XrcErrorApp)
    DECLARE_EVENT_TABLE()

public:
    XrcErrorApp();
    ~XrcErrorApp() = default;
    virtual bool OnInit();
    void Init();
    virtual int OnExit();
private:

};

DECLARE_APP(XrcErrorApp)

#endif //_XRCERRORAPP_H_