
#include "wx/wxprec.h"
#include "MainUI.h"

IMPLEMENT_DYNAMIC_CLASS(MainUI, wxDialog)

BEGIN_EVENT_TABLE(MainUI, wxDialog)
    EVT_CLOSE(MainUI::OnExit)
    EVT_BUTTON(XRCID("ID_BUTTON"), MainUI::OnButtonClick)
END_EVENT_TABLE()
    
MainUI::MainUI()
{
}

MainUI::MainUI(wxWindow* parent, wxWindowID id, const wxString& caption, const wxPoint& pos, const wxSize& size, long style)
{
    SetExtraStyle(wxWS_EX_VALIDATE_RECURSIVELY | wxWS_EX_BLOCK_EVENTS);
    SetParent(parent);
    if (!wxXmlResource::Get()->LoadDialog(this, GetParent(), wxT("XrcErrorUI")))
        wxLogError(wxT("Missing wxXmlResource::Get()->Load() in OnInit()?"));

    if (GetSizer())
    {
        GetSizer()->SetSizeHints(this);
    }
    Centre();
}

void MainUI::OnButtonClick(wxCommandEvent& event)
{
    wxChoice* choice = XRCCTRL(*this, "ID_WXCHOICE", wxChoice);
    if (choice == nullptr)
        return;
    choice->Clear();
    choice->Append(L"AAAAAAA");
}

void MainUI::OnExit(wxCloseEvent& event)
{
    Destroy();
}