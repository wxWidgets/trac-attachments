
#include "wx/wxprec.h"

#include "XrcErrorApp.h"
#include "MainUI.h"

IMPLEMENT_APP(XrcErrorApp)
IMPLEMENT_CLASS(XrcErrorApp, wxApp)
BEGIN_EVENT_TABLE(XrcErrorApp, wxApp)
END_EVENT_TABLE()

XrcErrorApp::XrcErrorApp()
{
	Init();
}

void XrcErrorApp::Init()
{
}

bool XrcErrorApp::OnInit()
{
	wxXmlResource::Get()->InitAllHandlers();
	wxXmlResource::Get()->Load(wxT("Xrcerror.xrc"));

	MainUI* ui = new MainUI(NULL);
	ui->Show();
	return true;
}

int XrcErrorApp::OnExit()
{
	::ExitProcess(0);
	return wxApp::OnExit();
}

