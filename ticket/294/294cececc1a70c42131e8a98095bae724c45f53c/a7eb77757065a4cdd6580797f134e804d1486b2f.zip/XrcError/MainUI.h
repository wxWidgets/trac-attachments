
#ifndef _MAINUI_H_
#define _MAINUI_H_

#ifndef WX_PRECOMP
#include "wx/wx.h"
#endif

#include "wx/xrc/xmlres.h"
#include "wx/dialog.h"

#define ID_LAUNCHER 10000
#define SYMBOL_LAUNCHER_STYLE wxDEFAULT_DIALOG_STYLE|wxCAPTION|wxRESIZE_BORDER|wxSYSTEM_MENU|wxCLOSE_BOX|wxTAB_TRAVERSAL
#define SYMBOL_LAUNCHER_TITLE wxGetTranslation(wxString() + (wxChar) 0x6E38 + (wxChar) 0x620F )
#define SYMBOL_LAUNCHER_IDNAME ID_LAUNCHER
#define SYMBOL_LAUNCHER_SIZE wxSize(600, 400)
#define SYMBOL_LAUNCHER_POSITION wxDefaultPosition

class MainUI : public wxDialog
{
    DECLARE_DYNAMIC_CLASS(MainUI)
    DECLARE_EVENT_TABLE()

public:
    MainUI();
     ~MainUI() = default;
    MainUI(wxWindow* parent, wxWindowID id = SYMBOL_LAUNCHER_IDNAME, const wxString& caption = SYMBOL_LAUNCHER_TITLE, const wxPoint& pos = SYMBOL_LAUNCHER_POSITION, const wxSize& size = SYMBOL_LAUNCHER_SIZE, long style = SYMBOL_LAUNCHER_STYLE);
    void OnButtonClick(wxCommandEvent& event);
    void OnExit(wxCloseEvent& event);
};

#endif
