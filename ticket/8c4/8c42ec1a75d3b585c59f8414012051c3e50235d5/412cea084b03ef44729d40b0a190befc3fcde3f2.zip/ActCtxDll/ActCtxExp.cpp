#include "Python.h"
#include "ActCtxExp.h"
#include <afxwin.h>
#include <stdio.h>

#define SCRIPT "hello.py"

int Init(void)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());

	if (!Py_IsInitialized())
		Py_Initialize();

	return 0;
}

void Exit(void)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());

	Py_Finalize();
}

void Run(void)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());

	FILE* file=NULL;

	if (fopen_s(&file,SCRIPT,"r") == 0)
	{
		if (PyRun_SimpleFile(file,SCRIPT) != 0)
		{
			PyObject* pType=PySys_GetObject("last_type");
			PyObject* pValue=PySys_GetObject("last_value");
			PyObject* pTraceback=PySys_GetObject("last_traceback");

			if (pType!=NULL)
			{
				CString str;
				PyObject* pModule=PyImport_ImportModule("traceback");

				if (pModule)
				{
					PyObject* pResult=NULL;
					PyObject* pLinecache=PyImport_ImportModule("linecache");

					if (pLinecache)
					{
						pResult=PyObject_CallMethod(pLinecache,"clearcache",NULL);
						Py_XDECREF(pResult);
						pResult=NULL;
					}
					if (pTraceback)
						pResult=PyObject_CallMethod(pModule,"format_exception","OOO",pType,pValue?pValue:Py_None,pTraceback);
					else
						pResult=PyObject_CallMethod(pModule,"format_exception_only","OO",pType,pValue?pValue:Py_None);
					if (pResult&&PyList_Check(pResult))
					{
						for (int nIndex=0;nIndex<PyList_Size(pResult);nIndex++)
						{
							PyObject* pItem=PyList_GetItem(pResult,nIndex);
							if (pItem&&PyString_Check(pItem))
							{
								CString txt(PyString_AsString(pItem));
								str.Append(txt);
							}
						}
					}
					Py_XDECREF(pResult);                     
				}
				Py_XDECREF(pModule);
				PyErr_Restore(pType,pValue,pTraceback);
				AfxMessageBox(str);
			}
			else
			{
				AfxMessageBox(_T("Unknown error in script."));
			}
		}
	}
	fclose(file);
}
