extern "C"
{
	int Init(void);
	void Exit(void);
	void Run(void);
}
