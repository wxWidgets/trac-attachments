// ActCtxDll.h : main header file for the ActCtxDll DLL
//

#pragma once

#ifndef __AFXWIN_H__
	#error "include 'stdafx.h' before including this file for PCH"
#endif

#include "resource.h"		// main symbols


// CActCtxDllApp
// See ActCtxDll.cpp for the implementation of this class
//

class CActCtxDllApp : public CWinApp
{
public:
	CActCtxDllApp();

// Overrides
public:
	virtual BOOL InitInstance();

	DECLARE_MESSAGE_MAP()
};

