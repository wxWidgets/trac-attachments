import wx

class MyFrame(wx.Frame):
    def __init__(self,parent,ID,title,pos=wx.DefaultPosition,size=wx.DefaultSize,style=wx.DEFAULT_FRAME_STYLE|wx.STAY_ON_TOP):
        wx.Frame.__init__(self,parent,ID,title,pos,size,style)
        panel=wx.Panel(self,-1)
        button=wx.Button(panel,1003,"Close")
        button.SetPosition((15,15))
        self.Bind(wx.EVT_BUTTON,self.OnCloseMe,button)
        self.Bind(wx.EVT_CLOSE,self.OnCloseWindow)

    def OnCloseMe(self,event):
        self.Destroy()

    def OnCloseWindow(self,event):
        self.Destroy()
		
class MyApp(wx.App):
    def OnInit(self):
        frame=MyFrame(None,-1,"ActCtxWx")
        frame.Show(True) 
        self.SetTopWindow(frame)
        return True

def run():
	app=MyApp(0)
	app.MainLoop()

if __name__ == "__main__":          
    run()            

