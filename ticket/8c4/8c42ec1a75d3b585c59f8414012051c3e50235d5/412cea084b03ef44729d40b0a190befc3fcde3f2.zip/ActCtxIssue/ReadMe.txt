Activation context issue with using embedded Python/wxPython

First of all, I am really sorry to bring this up.
I have read about the struggles behind the addition of an activation context (revision 60299).
Please accept my sympathy.
However, this has caused problems for us so I hope something can be done about this without breaking anything else.

We are developing an application where we embed Python to allow users to customize the application.

In our latest release we have upgraded to Python 2.6.4.

We do not support wxPython, but many of our users have found this to be a particularly good package to do GUI customization with.
When we upgraded to Python 2.6.4, users were recommended to upgrade to wxPython 2.8.11.

Unfortunately, this has caused problems for users since they can no longer use wxPython.

Typical configuration:

Microsoft Windows XP SP3
Microsoft Visual Studio 2008 SP1
Python 2.6.4
wxPython 2.8.11.0

How to reproduce:

Build the attached solution in Release mode.
Run the program.
Press the "Run Script" button in the "ActCtxIssue" dialog.
Press the "Close" button in the "ActCtxWx" dialog.

This will (at least in my environment) cause the following:

	Unhandled exception at 0x7c94482a in ActCtxIssue.exe: 0xC015000F: The activation context being deactivated is not the most recently activated one.

After this exception, the application behaves in an unpredictable way and must be closed down.

Probable cause:

In Run() in ActCtxExp.cpp we must use the AFX_MANAGE_STATE() macro to get MFC to work properly.
This macro activates an activation context (cookie=111111111).

Later in Run() we use the Python C API to do some magic and run a script.
During this process (when Python loads libraries) activation contexts are being activated and deactivated before and after DLLs are loaded.

When the wx._core_ module is loaded, __wxPyPreStart() in helpers.cpp is called.
This will in turn call wxPySetActivationContext() that creates and activates an activation context (cookie=999999999).

When we get back to our code and exit Run(), some desctructor from an object created during the AFX_MANAGE_STATE macro is called.
This destructor will try to deactivate the activation context created earlier (cookie=111111111).
However this is not the most recently activated one as it should be.
The reason is that the activation context activated by wxPySetActivationContext() (cookie=999999999) has never been deactivated.

In fact, the cookie returned by wxPySetActivationContext() is ignored.
This means that there is no way of deactivating this activation context when wx._core_ is unloaded.

Current workaround:

We have recommended our users to use wxPython 2.8.9.2 until this issue has been solved.
This is of course not ideal but it will do for a short period of time.

wxPython is not a part of our application so our users download this themselves.
This means that it is not an option for us or our users to fix this ourselves by building wxPython.

Solution:

I have tried to build wxPython with ISOLATION_AWARE_ENABLED unset and this solves our problem.
I know far too little about why this activation context must be created so I am unable to propose a solution that solves the initial problem and ours.
