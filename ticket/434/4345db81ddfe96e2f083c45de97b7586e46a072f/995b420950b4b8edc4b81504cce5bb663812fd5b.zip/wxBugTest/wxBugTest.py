#!/usr/bin/env python
print "Checking dependencies..."
import sys

try:
    import wx
    print "wxPython - OK"
except:
    print "you need to have wxPython installed !"
    print "download it at: http://www.wxpython.org/download.php"
    print "this app does not run without it !"
    print "leaving...."    
    sys.exit()
        
import testGUI


class BugTest(wx.App):

    def ShowFirst(self, event):
        self.First = testGUI.xrcDIALOG1(self.main)
        self.First.Botton.Bind(wx.EVT_BUTTON, self.ShowSecond)
        self.First.ShowModal()


    def ShowSecond(self, event):
        self.Second = testGUI.xrcDIALOG2(self.main)
        self.Second.one.Bind(wx.EVT_BUTTON, self.DoSomething)
        self.Second.two.Bind(wx.EVT_BUTTON, self.DoSomething)
        self.Second.three.Bind(wx.EVT_BUTTON, self.DoSomething)
        
        
        self.Second.ShowModal()

    def DoSomething(self, event):
        self.Second.text.AppendText("x-")
    
    def OnInit(self):
                        
        wx.InitAllImageHandlers()
        self.main = testGUI.xrcFRAME1(None)
        
        self.main.First.Bind(wx.EVT_BUTTON, self.ShowFirst)
        
        # display GUI
        self.main.Show(True)
        self.SetTopWindow(self.main)   
        wx.Yield()
        return True


   


def main():
    application = BugTest(0)
    application.MainLoop()
    
   
if __name__ == '__main__':
    main()
