#include <wx/frame.h>
#include <wx/statusbr.h>
#include <wx/wx.h>
#include <wx/wxprec.h>

class FoobarFrm : public wxFrame {
  public:
    FoobarFrm(wxWindow *parent, wxWindowID id = 1, const wxString &title = _T("Bug?"),
        const wxPoint& pos = wxDefaultPosition,
        const wxSize& size = wxSize(320, 240),
        long style = wxDEFAULT_FRAME_STYLE);
    virtual ~FoobarFrm();

	wxMenuBar *WxMenuBar1;
	wxMenu *MenuView;
	wxStatusBar *WxStatusBar1;

	enum {
    ID_WXSTATUSBAR1 = 10901,
    };

    void FoobarFrmClose(wxCloseEvent& event);
};

class MyApp:public wxApp {
  public:
	bool OnInit();
	int OnExit();
};

IMPLEMENT_APP(MyApp)

bool MyApp::OnInit() {
    FoobarFrm *myFrame = new  FoobarFrm(NULL);
    SetTopWindow(myFrame);
    myFrame->Show(TRUE);
    return TRUE;
}
 
int MyApp::OnExit() {
	return 0;
}


//----------------------------------------------------------------------------
// Form here
//----------------------------------------------------------------------------

FoobarFrm::FoobarFrm(wxWindow *parent, wxWindowID id, const wxString &title, const wxPoint &position, const wxSize& size, long style)
    : wxFrame(parent, id, title, position, size, style) {

	WxStatusBar1 =  new wxStatusBar(this, ID_WXSTATUSBAR1);
	WxMenuBar1 =  new wxMenuBar();
	wxMenu *MenuFile = new wxMenu(0);
	WxMenuBar1->Append(MenuFile, _("&File"));

	// Replace the order of SetMenuBar and SetStatusBar and check what happends
	this->SetMenuBar(WxMenuBar1);
	this->SetStatusBar(WxStatusBar1);
    this->Center();
}

FoobarFrm::~FoobarFrm() {}

void FoobarFrm::FoobarFrmClose(wxCloseEvent& event) {
    Destroy();
}
