/***************************************************************
 * Name:      TestMenuBugMain.cpp
 * Purpose:   Code for Application Frame
 * Author:    Biplab Kumar Modak (bkmodak@gmail.com)
 * Created:   2007-07-14
 * Copyright: Biplab Kumar Modak (http://biplab.in)
 * License:
 **************************************************************/

#include "TestMenuBugMain.h"
#include <wx/msgdlg.h>

//(*InternalHeaders(TestMenuBugFrame)
#include <wx/bitmap.h>
#include <wx/font.h>
#include <wx/fontenum.h>
#include <wx/fontmap.h>
#include <wx/image.h>
#include <wx/intl.h>
#include <wx/settings.h>
#include <wx/string.h>
//*)

//helper functions
enum wxbuildinfoformat {
    short_f, long_f };

wxString wxbuildinfo(wxbuildinfoformat format)
{
    wxString wxbuild(wxVERSION_STRING);

    if (format == long_f )
    {
#if defined(__WXMSW__)
        wxbuild << _T("-Windows");
#elif defined(__UNIX__)
        wxbuild << _T("-Linux");
#endif

#if wxUSE_UNICODE
        wxbuild << _T("-Unicode build");
#else
        wxbuild << _T("-ANSI build");
#endif // wxUSE_UNICODE
    }

    return wxbuild;
}

//(*IdInit(TestMenuBugFrame)
const long TestMenuBugFrame::ID_PANEL1 = wxNewId();
const long TestMenuBugFrame::ID_BUTTON1 = wxNewId();
const long TestMenuBugFrame::ID_BUTTON2 = wxNewId();
const long TestMenuBugFrame::idMenuQuit = wxNewId();
const long TestMenuBugFrame::idNone = wxNewId();
const long TestMenuBugFrame::idMenuAbout = wxNewId();
const long TestMenuBugFrame::ID_STATUSBAR1 = wxNewId();
//*)

BEGIN_EVENT_TABLE(TestMenuBugFrame,wxFrame)
    //(*EventTable(TestMenuBugFrame)
    //*)
END_EVENT_TABLE()

TestMenuBugFrame::TestMenuBugFrame(wxWindow* parent,wxWindowID id)
{
    //(*Initialize(TestMenuBugFrame)
    wxMenuBar* MenuBar1;
    wxMenu* Menu1;
    wxMenuItem* MenuItem1;
    wxMenu* Menu2;
    wxMenuItem* MenuItem2;

    Create(parent,id,wxEmptyString,wxDefaultPosition,wxDefaultSize,wxDEFAULT_FRAME_STYLE,_T("wxFrame"));
    Panel1 = new wxPanel(this,ID_PANEL1,wxDefaultPosition,wxDefaultSize,wxTAB_TRAVERSAL,_T("ID_PANEL1"));
    BoxSizer1 = new wxBoxSizer(wxHORIZONTAL);
    Button1 = new wxButton(Panel1,ID_BUTTON1,_("Remove"),wxDefaultPosition,wxDefaultSize,0,wxDefaultValidator,_T("ID_BUTTON1"));
    BoxSizer1->Add(Button1,1,wxALL|wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL,5);
    Button2 = new wxButton(Panel1,ID_BUTTON2,_("Re-add"),wxDefaultPosition,wxDefaultSize,0,wxDefaultValidator,_T("ID_BUTTON2"));
    BoxSizer1->Add(Button2,1,wxALL|wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL,5);
    Panel1->SetSizer(BoxSizer1);
    BoxSizer1->Fit(Panel1);
    BoxSizer1->SetSizeHints(Panel1);
    MenuBar1 = new wxMenuBar();
    Menu1 = new wxMenu();
    MenuItem1 = new wxMenuItem(Menu1,idMenuQuit,_("Quit\tAlt-F4"),_("Quit the application"),wxITEM_NORMAL);
    Menu1->Append(MenuItem1);
    MenuItem3 = new wxMenuItem(Menu1,idNone,_("&Test"),wxEmptyString,wxITEM_NORMAL);
    MenuItem3->SetBitmap(wxBitmap(wxImage(_T("C:\\Projects\\TestMenuBug\\std.png"))));
    Menu1->Append(MenuItem3);
    MenuBar1->Append(Menu1,_("&File"));
    Menu2 = new wxMenu();
    MenuItem2 = new wxMenuItem(Menu2,idMenuAbout,_("About\tF1"),_("Show info about this application"),wxITEM_NORMAL);
    Menu2->Append(MenuItem2);
    MenuBar1->Append(Menu2,_("Help"));
    SetMenuBar(MenuBar1);
    StatusBar1 = new wxStatusBar(this,ID_STATUSBAR1,0,_T("ID_STATUSBAR1"));
    int StatusBar1__widths[1] = { -1 };
    int StatusBar1__styles[1] = { wxSB_NORMAL };
    StatusBar1->SetFieldsCount(1,StatusBar1__widths);
    StatusBar1->SetStatusStyles(1,StatusBar1__styles);
    SetStatusBar(StatusBar1);
    Connect(ID_BUTTON1,wxEVT_COMMAND_BUTTON_CLICKED,(wxObjectEventFunction)&TestMenuBugFrame::OnRemoveClick);
    Connect(ID_BUTTON2,wxEVT_COMMAND_BUTTON_CLICKED,(wxObjectEventFunction)&TestMenuBugFrame::OnReaddClick);
    Connect(idMenuQuit,wxEVT_COMMAND_MENU_SELECTED,(wxObjectEventFunction)&TestMenuBugFrame::OnQuit);
    Connect(idMenuAbout,wxEVT_COMMAND_MENU_SELECTED,(wxObjectEventFunction)&TestMenuBugFrame::OnAbout);
    //*)
}

TestMenuBugFrame::~TestMenuBugFrame()
{
    //(*Destroy(TestMenuBugFrame)
    //*)
}

void TestMenuBugFrame::OnQuit(wxCommandEvent& event)
{
    Close();
}

void TestMenuBugFrame::OnAbout(wxCommandEvent& event)
{
    wxString msg = wxbuildinfo(long_f);
    wxMessageBox(msg, _("Welcome to..."));
}

void TestMenuBugFrame::OnRemoveClick(wxCommandEvent& event)
{
    wxMenuBar* main_menu = this->GetMenuBar();
    if (main_menu)
    {
        wxMenu* file_menu = main_menu->GetMenu(0);
        if (file_menu)
        {
            menu_item = file_menu->Remove(idNone);
        }
    }
}

void TestMenuBugFrame::OnReaddClick(wxCommandEvent& event)
{
    wxMenuBar* main_menu = this->GetMenuBar();
    if (main_menu)
    {
        wxMenu* file_menu = main_menu->GetMenu(0);
        if (file_menu && menu_item)
        {
            file_menu->Append(menu_item);
            menu_item = 0L;
        }
    }
}
