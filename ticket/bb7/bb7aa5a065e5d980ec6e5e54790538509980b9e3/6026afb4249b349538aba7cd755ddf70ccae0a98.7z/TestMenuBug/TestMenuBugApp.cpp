/***************************************************************
 * Name:      TestMenuBugApp.cpp
 * Purpose:   Code for Application Class
 * Author:    Biplab Kumar Modak (bkmodak@gmail.com)
 * Created:   2007-07-14
 * Copyright: Biplab Kumar Modak (http://biplab.in)
 * License:
 **************************************************************/

#include "TestMenuBugApp.h"

//(*AppHeaders
#include "TestMenuBugMain.h"
#include <wx/image.h>
//*)

IMPLEMENT_APP(TestMenuBugApp);

bool TestMenuBugApp::OnInit()
{
    //(*AppInitialize
    bool wxsOK = true;
    wxInitAllImageHandlers();
    if ( wxsOK )
    {
        TestMenuBugFrame* Frame = new TestMenuBugFrame(0);
        Frame->Show();
        SetTopWindow(Frame);
    }
    //*)
    return wxsOK;

}
