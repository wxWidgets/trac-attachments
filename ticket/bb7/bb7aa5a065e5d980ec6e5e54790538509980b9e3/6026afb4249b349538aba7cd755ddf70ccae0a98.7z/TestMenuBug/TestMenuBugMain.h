/***************************************************************
 * Name:      TestMenuBugMain.h
 * Purpose:   Defines Application Frame
 * Author:    Biplab Kumar Modak (bkmodak@gmail.com)
 * Created:   2007-07-14
 * Copyright: Biplab Kumar Modak (http://biplab.in)
 * License:
 **************************************************************/

#ifndef TESTMENUBUGMAIN_H
#define TESTMENUBUGMAIN_H

//(*Headers(TestMenuBugFrame)
#include <wx/button.h>
#include <wx/frame.h>
#include <wx/menu.h>
#include <wx/panel.h>
#include <wx/sizer.h>
#include <wx/statusbr.h>
//*)

class TestMenuBugFrame: public wxFrame
{
    public:

        TestMenuBugFrame(wxWindow* parent,wxWindowID id = -1);
        virtual ~TestMenuBugFrame();

    private:

        //(*Handlers(TestMenuBugFrame)
        void OnQuit(wxCommandEvent& event);
        void OnAbout(wxCommandEvent& event);
        void OnRemoveClick(wxCommandEvent& event);
        void OnReaddClick(wxCommandEvent& event);
        //*)

        //(*Identifiers(TestMenuBugFrame)
        static const long ID_PANEL1;
        static const long ID_BUTTON1;
        static const long ID_BUTTON2;
        static const long idMenuQuit;
        static const long idNone;
        static const long idMenuAbout;
        static const long ID_STATUSBAR1;
        //*)

        //(*Declarations(TestMenuBugFrame)
        wxPanel* Panel1;
        wxBoxSizer* BoxSizer1;
        wxButton* Button1;
        wxButton* Button2;
        wxMenuItem* MenuItem3;
        wxStatusBar* StatusBar1;
        //*)
        wxMenuItem* menu_item;

        DECLARE_EVENT_TABLE()
};

#endif // TESTMENUBUGMAIN_H
