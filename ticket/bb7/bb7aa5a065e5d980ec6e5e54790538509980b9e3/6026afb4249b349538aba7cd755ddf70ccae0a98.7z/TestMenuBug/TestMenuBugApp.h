/***************************************************************
 * Name:      TestMenuBugApp.h
 * Purpose:   Defines Application Class
 * Author:    Biplab Kumar Modak (bkmodak@gmail.com)
 * Created:   2007-07-14
 * Copyright: Biplab Kumar Modak (http://biplab.in)
 * License:
 **************************************************************/

#ifndef TESTMENUBUGAPP_H
#define TESTMENUBUGAPP_H

#include <wx/app.h>

class TestMenuBugApp : public wxApp
{
    public:
        virtual bool OnInit();
};

#endif // TESTMENUBUGAPP_H
