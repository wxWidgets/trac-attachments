#include <wx/wx.h>
#include "testmdi.h"

BEGIN_EVENT_TABLE( MdiFrame, wxMDIParentFrame )
	EVT_MENU( Menu_File_New, MdiFrame::OnNew )
	EVT_MENU( Menu_File_Quit, MdiFrame::OnQuit )
	EVT_MENU( Menu_File_About, MdiFrame::OnAbout )
END_EVENT_TABLE()

IMPLEMENT_APP(testmdiapp)
	

wxString progname = _T("wxMDIChildFrame test");

wxMenuBar *MakeMenu(int type)
{//==========================
	wxMenu *menuFile = new wxMenu;
	
	menuFile->Append( Menu_File_New, wxT( "&New..." ) );
	if(type==1)
		menuFile->Append( Menu_File_Close, wxT( "&Close..." ) );
	menuFile->Append( Menu_File_About, wxT( "&About..." ) );
	menuFile->AppendSeparator();
	menuFile->Append( Menu_File_Quit, wxT( "E&xit" ) );
	
	wxMenuBar *menuBar = new wxMenuBar;
	menuBar->Append( menuFile, wxT( "&File" ) );

	return(menuBar);
 }  //  end of MakeMenu



bool testmdiapp::OnInit()
{
	MdiFrame *frame = new MdiFrame( progname, wxPoint(50,50), wxSize(450,340) );

	frame->Show(TRUE);
	SetTopWindow(frame);
	return TRUE;
} 


MdiFrame::MdiFrame( const wxString& title, const wxPoint& pos, const wxSize& size )
	: wxMDIParentFrame((wxFrame *)NULL, -1, title, pos, size)
{
	SetMenuBar( MakeMenu(0) );
	
	CreateStatusBar();
	SetStatusText(progname);
}


void MdiFrame::OnNew( wxCommandEvent& WXUNUSED( event ) )
{
	static int winnum = 1;
	MdiChild *childframe = new MdiChild(this, _T("Test"),
                                      wxPoint(10, 10), wxSize(300, 300), wxDEFAULT_FRAME_STYLE);

	childframe->SetTitle(wxString::Format(_T("W%d"),winnum++));
	childframe->CreateStatusBar();
	childframe->SetMenuBar(MakeMenu(1));
	childframe->Show(TRUE);
}


void MdiFrame::OnQuit( wxCommandEvent& WXUNUSED( event ) )
{
	Close(TRUE);
}

void MdiFrame::OnAbout( wxCommandEvent& WXUNUSED( event ) )
{
	wxMessageBox( wxT( "This is a test of wxMDIChildFrame" ),
			_T("About ")+progname, wxOK | wxICON_INFORMATION, this );
}



BEGIN_EVENT_TABLE( MdiChild, wxMDIChildFrame)
	EVT_MENU( Menu_File_Close, MdiChild::OnClose )
END_EVENT_TABLE()


MdiChild::MdiChild(wxMDIParentFrame *parent, const wxString& title, const wxPoint& pos, const wxSize& size,
const long style):
  wxMDIChildFrame(parent, -1, title, pos, size, style)
{
}


void MdiChild::OnClose (wxCommandEvent& WXUNUSED(event))
{
	Destroy();
}


