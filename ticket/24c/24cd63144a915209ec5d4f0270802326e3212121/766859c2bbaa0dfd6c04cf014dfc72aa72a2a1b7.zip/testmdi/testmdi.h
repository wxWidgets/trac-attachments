
#ifndef _TESTMDI_H_
#define _TESTMDI_H_


class testmdiapp : public wxApp
{
	public:
		virtual bool OnInit();
};


class MdiFrame : public wxMDIParentFrame
{
	public:
		MdiFrame( const wxString& title, const wxPoint& pos, const wxSize& pos );
		void OnNew( wxCommandEvent& event );
		void OnQuit( wxCommandEvent& event );
		void OnAbout( wxCommandEvent& event );

	private:
		DECLARE_EVENT_TABLE()
};


class MdiChild : public wxMDIChildFrame
{
  public:
	MdiChild(wxMDIParentFrame *parent, const wxString& title, const wxPoint& pos, const wxSize& size, const long style);
//	~MdiChild(void);
	void OnActivate(wxActivateEvent& event);
	void OnClose(wxCommandEvent& event);

	private:
		DECLARE_EVENT_TABLE()
};


enum
{
	Menu_File_Quit = 100,
	Menu_File_New,
	Menu_File_Close,
	Menu_File_About
};

#endif // _TESTMDI_H_
