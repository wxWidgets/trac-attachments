import wx
import wx.xrc
import mymod

class MyApp(wx.App):
    def OnInit(self):
        self.res = wx.xrc.EmptyXmlResource()
        self.res.InsertHandler(mymod.FrameXmlHandler())        
        self.res.Load('mygui.xrc')        
        frame = self.res.LoadObject(None, "MyFrame", "wxFrame")
        print frame
        print 'Hello, World! Where did you come from?'
        print frame.Show()
        return True


def main():
    app = MyApp(False)
    print "MainLoop starting..."
    app.MainLoop()
    print "MainLoop exited"


if __name__ == '__main__':
    main()
    
