import wx
import wx.xrc

class FrameXmlHandler(wx.xrc.XmlResourceHandler):
    def __init__(self):
        wx.xrc.XmlResourceHandler.__init__(self)
        self.AddStyle("wxCAPTION", wx.CAPTION);
        self.AddStyle("wxRESIZE_BORDER", wx.RESIZE_BORDER);
        self.AddStyle("wxSYSTEM_MENU", wx.SYSTEM_MENU);
        self.AddStyle("wxMINIMIZE_BOX", wx.MINIMIZE_BOX);
        self.AddStyle("wxMAXIMIZE_BOX", wx.MAXIMIZE_BOX);
        self.AddStyle("wxCLOSE_BOX", wx.CLOSE_BOX);
        self.AddWindowStyles()

    def CanHandle(self, node):
        return self.IsOfClass(node, "wxFrame")

    def DoCreateResource(self):
        print 'FrameXmlHandler.DoCreateResource'
        
        frame = self.GetInstance()
        print frame
        if frame is None:
            print "creating frame..."
            frame = wx.PreFrame()
            frame.Create(self.GetParentAsWindow(),
                         self.GetID(),
                         self.GetText("title"),
                         self.GetPosition(),
                         self.GetSize(),
                         self.GetStyle("style", wx.DEFAULT_FRAME_STYLE),
                         self.GetName())
        print 'calling SetupWindow'
        self.SetupWindow(frame)
        print 'calling CreateChildren'
        self.CreateChildren(frame)
        print 'returning frame'
        return frame    
