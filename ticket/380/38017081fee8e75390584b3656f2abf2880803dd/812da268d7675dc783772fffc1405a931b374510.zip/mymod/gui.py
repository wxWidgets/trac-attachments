__version__ = '$Revision$'

import wx

class MyMDIParentFrame(wx.MDIParentFrame):
    def __init__(self):
        pre = wx.PreMDIParentFrame()
        # Create is done by XRC
        self.PostCreate(pre)
        print 'Bye, World!'
        pass

    pass
    
class MyFrame(wx.Frame):
    def __init__(self):
        pre = wx.PreMDIParentFrame()
        # Create is done by XRC
        self.PostCreate(pre)
        print 'Bye, World!'
        pass

    pass