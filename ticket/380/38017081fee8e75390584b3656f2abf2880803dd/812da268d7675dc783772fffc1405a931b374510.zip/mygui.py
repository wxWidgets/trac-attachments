import wx
import wx.xrc
import mymod

class MyApp(wx.App):
    def OnInit(self):
        self.res = wx.xrc.EmptyXmlResource()
        self.res.InsertHandler(mymod.FrameXmlHandler())        
        self.res.Load('mygui.xrc')        
        frame = self.res.LoadObject(None, "MyFrame", "wxFrame")
        print type(frame)
        print 'Hello, World! Where did you come from?'
        frame.Show()
        return True

    pass

def main():
    app = MyApp(False)
    app.MainLoop()
    pass

if __name__ == '__main__':
    main()
    pass
