#ifndef TEST_DIALOG_H
#define TEST_DIALOG_H
#include <wx/wx.h>

class TestDialog : public wxDialog
{

public:
	TestDialog(wxWindow* parent, wxWindowID id, const wxString& title, const wxPoint& pos = wxDefaultPosition, const wxSize& size = wxDefaultSize, long style = wxDEFAULT_DIALOG_STYLE | wxRESIZE_BORDER);
	virtual ~TestDialog();
};

#endif

