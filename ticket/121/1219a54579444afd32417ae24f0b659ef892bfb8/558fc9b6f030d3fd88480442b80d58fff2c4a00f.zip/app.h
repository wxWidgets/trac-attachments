#include <wx/wx.h>

class Application : public wxApp
{

public:
	virtual bool OnInit();
	virtual int OnExit();
};

