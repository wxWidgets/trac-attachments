#include <wx/wx.h>
#include "app.h"
#include "test.h"

IMPLEMENT_APP(Application)

bool Application::OnInit()
{

    TestDialog* test_dialog = new TestDialog(NULL, wxID_ANY,_T("TEST"));
    test_dialog->ShowModal();
    return FALSE;
}


int Application::OnExit()
{

    return 1;
}

