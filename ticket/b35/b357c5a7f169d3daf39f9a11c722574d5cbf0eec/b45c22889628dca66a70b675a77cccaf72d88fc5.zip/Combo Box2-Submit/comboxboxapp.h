/////////////////////////////////////////////////////////////////////////////
// Name:        comboxboxapp.h
// Purpose:     
// Author:      Angshuman
// Modified by: 
// Created:     28/03/2012 12:34:32
// RCS-ID:      
// Copyright:   
// Licence:     
/////////////////////////////////////////////////////////////////////////////

#ifndef _COMBOXBOXAPP_H_
#define _COMBOXBOXAPP_H_


/*!
 * Includes
 */

////@begin includes
#include "wx/image.h"
#include "comboboxdemo.h"
////@end includes

/*!
 * Forward declarations
 */

////@begin forward declarations
////@end forward declarations

/*!
 * Control identifiers
 */

////@begin control identifiers
////@end control identifiers

/*!
 * ComboxBoxApp class declaration
 */

class ComboxBoxApp: public wxApp
{    
    DECLARE_CLASS( ComboxBoxApp )
    DECLARE_EVENT_TABLE()

public:
    /// Constructor
    ComboxBoxApp();

    void Init();

    /// Initialises the application
    virtual bool OnInit();

    /// Called on exit
    virtual int OnExit();

////@begin ComboxBoxApp event handler declarations

////@end ComboxBoxApp event handler declarations

////@begin ComboxBoxApp member function declarations

////@end ComboxBoxApp member function declarations

////@begin ComboxBoxApp member variables
////@end ComboxBoxApp member variables
};

/*!
 * Application instance declaration 
 */

////@begin declare app
DECLARE_APP(ComboxBoxApp)
////@end declare app

#endif
    // _COMBOXBOXAPP_H_
