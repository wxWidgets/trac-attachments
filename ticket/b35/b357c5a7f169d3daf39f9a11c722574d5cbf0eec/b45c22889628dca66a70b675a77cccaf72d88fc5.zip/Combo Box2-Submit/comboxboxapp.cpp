/////////////////////////////////////////////////////////////////////////////
// Name:        comboxboxapp.cpp
// Purpose:     
// Author:      Angshuman
// Modified by: 
// Created:     28/03/2012 12:34:32
// RCS-ID:      
// Copyright:   
// Licence:     
/////////////////////////////////////////////////////////////////////////////

// For compilers that support precompilation, includes "wx/wx.h".
#include "wx/wxprec.h"

#ifdef __BORLANDC__
#pragma hdrstop
#endif

#ifndef WX_PRECOMP
#include "wx/wx.h"
#endif

////@begin includes
////@end includes

#include "comboxboxapp.h"

////@begin XPM images
////@end XPM images


/*
 * Application instance implementation
 */

////@begin implement app
IMPLEMENT_APP( ComboxBoxApp )
////@end implement app


/*
 * ComboxBoxApp type definition
 */

IMPLEMENT_CLASS( ComboxBoxApp, wxApp )


/*
 * ComboxBoxApp event table definition
 */

BEGIN_EVENT_TABLE( ComboxBoxApp, wxApp )

////@begin ComboxBoxApp event table entries
////@end ComboxBoxApp event table entries

END_EVENT_TABLE()


/*
 * Constructor for ComboxBoxApp
 */

ComboxBoxApp::ComboxBoxApp()
{
    Init();
}


/*
 * Member initialisation
 */

void ComboxBoxApp::Init()
{
////@begin ComboxBoxApp member initialisation
////@end ComboxBoxApp member initialisation
}

/*
 * Initialisation for ComboxBoxApp
 */

bool ComboxBoxApp::OnInit()
{    
////@begin ComboxBoxApp initialisation
	// Remove the comment markers above and below this block
	// to make permanent changes to the code.

#if wxUSE_XPM
	wxImage::AddHandler(new wxXPMHandler);
#endif
#if wxUSE_LIBPNG
	wxImage::AddHandler(new wxPNGHandler);
#endif
#if wxUSE_LIBJPEG
	wxImage::AddHandler(new wxJPEGHandler);
#endif
#if wxUSE_GIF
	wxImage::AddHandler(new wxGIFHandler);
#endif
	ComboBoxDemo2* mainWindow = new ComboBoxDemo2(NULL);
	/* int returnValue = */ mainWindow->ShowModal();

	mainWindow->Destroy();
	// A modal dialog application should return false to terminate the app.
	return false;
////@end ComboxBoxApp initialisation

    return true;
}


/*
 * Cleanup for ComboxBoxApp
 */

int ComboxBoxApp::OnExit()
{    
////@begin ComboxBoxApp cleanup
	return wxApp::OnExit();
////@end ComboxBoxApp cleanup
}

