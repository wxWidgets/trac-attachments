
#pragma once
#include "StdAfx.h"


class Main : public wxApp
{
public:
	virtual bool OnInit();
	
};

DECLARE_APP(Main);
