
#pragma once
#include "StdAfx.h"

class frmMain:public wxFrame
{

public:
    frmMain();
};