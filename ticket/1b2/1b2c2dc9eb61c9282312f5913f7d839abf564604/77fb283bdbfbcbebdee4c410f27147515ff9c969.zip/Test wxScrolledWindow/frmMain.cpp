
#include "StdAfx.h"
#include "frmMain.h"

frmMain::frmMain()
:wxFrame(0,wxID_ANY,"Test wxScrolledWindow",wxDefaultPosition,wxSize(200,200))
{
	
	//Set the Scroll Window
	wxScrolledWindow *scrollWindow=new wxScrolledWindow(this,wxID_ANY);


	// ====== The higher the value - more empty space will be shown ====== //
	scrollWindow->SetScrollRate(20,20);
    
	//Create a sizer to put in the Scroll - and add how many buttons to it
	wxBoxSizer *vSizer=new wxBoxSizer(wxVERTICAL);
	for(int i=0;i<10;i++)
		vSizer->Add(new wxButton(scrollWindow,wxID_ANY,"tst"));
	//Put the sizer in the ScrollWindow
	scrollWindow->SetSizer(vSizer);

	Show();
}