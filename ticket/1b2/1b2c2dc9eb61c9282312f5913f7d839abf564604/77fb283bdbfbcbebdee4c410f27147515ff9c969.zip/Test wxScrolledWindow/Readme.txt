Bs"d

You cold use wxScrolledWindow just by assigning a sizer to it
http://www.wxwindows.org/manuals/2.6.3/wx_wxscrolledwindow.html
But the calculation have a problem
When you call the function SetScrollRate
The scroll bar need to go faster but...
It also put space
One picture = 10000 words
http://img226.imageshack.us/img226/6587/theresult3dh.png


