
#include "StdAfx.h"
#include "main.h"
#include "frmMain.h"

bool Main::OnInit() 
{
    new frmMain();	
	return true;
}

IMPLEMENT_APP(Main);
