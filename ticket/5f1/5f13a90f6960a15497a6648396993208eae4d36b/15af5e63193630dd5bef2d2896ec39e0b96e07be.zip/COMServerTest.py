# SimpleCOMServer.py - A sample COM server - almost as small as they come!
#
# We simply expose a single method in a Python COM object.

import wx

class PythonUtilities:
    _public_methods_ = [ 'SplitString' ]
    _reg_progid_ = "PythonAddIn.Runner"
    # NEVER copy the following ID
    # Use "print pythoncom.CreateGuid()" to make a new one.
    _reg_clsid_ = "{91D9FEF4-B762-43AF-A0A5-965DA7B6A8EB}"

    def SplitString(self, val, item=None):
        import string
        app = wx.PySimpleApp(0)
        if item != None: item = str(item)
        res = string.split(str(val), item)
        for i,x in enumerate(res):
           wx.MessageBox(str(x),str(i))
        return res

# Add code so that when this script is run by
# Python.exe, it self-registers.
if __name__ == '__main__':
    print "Registering COM server..."
    import win32com.server.register
    win32com.server.register.UseCommandLine(PythonUtilities)
