// This app will crash.
// If you do not subclass the control, it will work properly.
// If you use a plain edit control, it will work either subclasses or not.

#define WINVER 0x0600
#define _WIN32_WINNT 0x0600
#define _WIN32_WINDOWS 0x0410
#define _WIN32_IE 0x0700
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <tchar.h>
#include <assert.h>
#include <objbase.h>

#define CTRL_CLASS _T("INKEDIT")
//#define CTRL_CLASS _T("EDIT")


WNDPROC oldProc = NULL; // Yes, global is bad - quick/dirty test to demonstrate problem
bool doSubclass = true;


LRESULT CALLBACK RichProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	if (oldProc)
		return CallWindowProc(oldProc, hWnd, message, wParam, lParam);
	else
		return DefWindowProc(hWnd, message, wParam, lParam);
}


LRESULT CALLBACK WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	static HWND hwndCtrl = NULL; // Yes, static is bad - quick/dirty test to demonstrate problem
	switch (message)
	{
	case WM_CREATE:
		hwndCtrl = CreateWindow(CTRL_CLASS, NULL, WS_CHILD | WS_VISIBLE, 0, 0, 0, 0, hWnd, NULL, (HINSTANCE)GetWindowLongPtr(hWnd, GWLP_HINSTANCE), NULL);
		if (doSubclass)
		{
			oldProc = (WNDPROC)GetWindowLongPtr(hwndCtrl, GWL_WNDPROC);
			SetWindowLongPtr(hwndCtrl, GWL_WNDPROC, (LONG_PTR)RichProc);
		}
		assert(hwndCtrl);
		break;
	case WM_SIZE:
		if (hwndCtrl)
		{
			RECT r;
			GetClientRect(hWnd, &r);
			SetWindowPos(hwndCtrl, NULL, 0, 0, r.right - r.left, r.bottom - r.top, SWP_NOMOVE | SWP_NOZORDER);
		}
		break;
	case WM_DESTROY:
		PostQuitMessage(0);
		break;
	default:
		return DefWindowProc(hWnd, message, wParam, lParam);
	}
	return 0;
}


int APIENTRY _tWinMain(
		HINSTANCE hInstance,
		HINSTANCE /*hPrevInstance*/,
		LPTSTR /*lpCmdLine*/,
		int nCmdShow)
{
	CoInitialize(0);
	if (!LoadLibrary(_T("inked.dll")))
	{
		::MessageBox(NULL, _T("This test will only run on an ink enabled device (inked.dll is present)"), _T("error"), 0);
		return 0;
	}



	WNDCLASSEX wcex;
	wcex.cbSize = sizeof(WNDCLASSEX);
	wcex.style = CS_HREDRAW | CS_VREDRAW;
	wcex.lpfnWndProc = WndProc;
	wcex.cbClsExtra = 0;
	wcex.cbWndExtra = 0;
	wcex.hInstance = hInstance;
	wcex.hIcon = 0;
	wcex.hCursor = LoadCursor(NULL, IDC_ARROW);
	wcex.hbrBackground = (HBRUSH)(COLOR_APPWORKSPACE+1);
	wcex.lpszMenuName = 0;
	wcex.lpszClassName = _T("INKTEST");
	wcex.hIconSm = 0;
	RegisterClassEx(&wcex);

	HWND hWnd = CreateWindow(_T("INKTEST"), _T("Test app"), WS_OVERLAPPEDWINDOW,
		CW_USEDEFAULT, 0, CW_USEDEFAULT, 0, NULL, NULL, hInstance, NULL);
	if (!hWnd)
	{
		return 0;
	}

	ShowWindow(hWnd, nCmdShow);
	UpdateWindow(hWnd);

	// Main message loop:
	MSG msg;
	while (GetMessage(&msg, NULL, 0, 0))
	{
		TranslateMessage(&msg);
		DispatchMessage(&msg);
	}

	return (int)msg.wParam;
}
