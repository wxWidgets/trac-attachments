/////////////////////////////////////////////////////////////////////////////
// Name:        mainframe.cpp
// Purpose:     
// Author:      
// Modified by: 
// Created:     12/01/2007 19:57:15
// RCS-ID:      
// Copyright:   
// Licence:     
/////////////////////////////////////////////////////////////////////////////

#if defined(__GNUG__) && !defined(NO_GCC_PRAGMA)
#pragma implementation "mainframe.h"
#endif

// For compilers that support precompilation, includes "wx/wx.h".
#include "wx/wxprec.h"

#ifdef __BORLANDC__
#pragma hdrstop
#endif

#ifndef WX_PRECOMP
#include "wx/wx.h"
#endif

////@begin includes
////@end includes

#include "mainframe.h"

////@begin XPM images
#include "target.xpm"
////@end XPM images

/*!
 * MainFrame type definition
 */

IMPLEMENT_CLASS( MainFrame, wxFrame )

/*!
 * MainFrame event table definition
 */

BEGIN_EVENT_TABLE( MainFrame, wxFrame )
	EVT_TIMER( -1, OnTimer )

////@begin MainFrame event table entries
    EVT_MENU( ID_PLUSPLUS, MainFrame::OnPlusplusClick )

    EVT_MENU( ID_TOOL1, MainFrame::OnTool1Click )

////@end MainFrame event table entries

END_EVENT_TABLE()

/*!
 * MainFrame constructors
 */

MainFrame::MainFrame( )
{
    Init();
}

MainFrame::MainFrame( wxWindow* parent, wxWindowID id, const wxString& caption, const wxPoint& pos, const wxSize& size, long style )
{
    Init();
    Create( parent, id, caption, pos, size, style );
}

/*!
 * MainFrame creator
 */

bool MainFrame::Create( wxWindow* parent, wxWindowID id, const wxString& caption, const wxPoint& pos, const wxSize& size, long style )
{
////@begin MainFrame creation
    wxFrame::Create( parent, id, caption, pos, size, style );

    CreateControls();
    Centre();
////@end MainFrame creation

	m_Timer.SetOwner(this);
	m_Timer.Start(10);
    return true;
}

/*!
 * Member initialisation 
 */

void MainFrame::Init()
{
////@begin MainFrame member initialisation
////@end MainFrame member initialisation
}
/*!
 * Control creation for MainFrame
 */

void MainFrame::CreateControls()
{    
////@begin MainFrame content construction
    MainFrame* itemFrame1 = this;

    wxMenuBar* menuBar = new wxMenuBar;
    wxMenu* itemMenu5 = new wxMenu;
    itemMenu5->Append(ID_PLUSPLUS, _("Menu 1\tCtrl+KP_ADD"), _T(""), wxITEM_NORMAL);
    menuBar->Append(itemMenu5, _("Menu"));
    itemFrame1->SetMenuBar(menuBar);

    wxBoxSizer* itemBoxSizer2 = new wxBoxSizer(wxHORIZONTAL);
    itemFrame1->SetSizer(itemBoxSizer2);

    wxPanel* itemPanel3 = new wxPanel( itemFrame1, ID_PANEL1, wxDefaultPosition, wxDefaultSize, wxNO_BORDER|wxTAB_TRAVERSAL );
    itemBoxSizer2->Add(itemPanel3, 1, wxGROW, 5);

    wxToolBar* itemToolBar7 = CreateToolBar( wxTB_FLAT|wxTB_HORIZONTAL, ID_TOOLBAR1 );
    wxBitmap itemtool8Bitmap(itemFrame1->GetBitmapResource(wxT("target.xpm")));
    wxBitmap itemtool8BitmapDisabled;
    itemToolBar7->AddTool(ID_TOOL1, _("Tool"), itemtool8Bitmap, itemtool8BitmapDisabled, wxITEM_NORMAL, _T(""), wxEmptyString);
    itemToolBar7->AddSeparator();
    itemToolBar7->Realize();
    itemFrame1->SetToolBar(itemToolBar7);

////@end MainFrame content construction
}

/*!
 * Should we show tooltips?
 */

bool MainFrame::ShowToolTips()
{
    return true;
}

/*!
 * Get bitmap resources
 */

wxBitmap MainFrame::GetBitmapResource( const wxString& name )
{
    // Bitmap retrieval
////@begin MainFrame bitmap retrieval
    wxUnusedVar(name);
    if (name == _T("target.xpm"))
    {
        wxBitmap bitmap(target_xpm);
        return bitmap;
    }
    return wxNullBitmap;
////@end MainFrame bitmap retrieval
}

/*!
 * Get icon resources
 */

wxIcon MainFrame::GetIconResource( const wxString& name )
{
    // Icon retrieval
////@begin MainFrame icon retrieval
    wxUnusedVar(name);
    return wxNullIcon;
////@end MainFrame icon retrieval
}
/*!
 * wxEVT_COMMAND_MENU_SELECTED event handler for ID_PLUSPLUS
 */

void MainFrame::OnPlusplusClick( wxCommandEvent& event )
{
	wxMessageBox("In handler");
}


/*!
 * wxEVT_COMMAND_MENU_SELECTED event handler for ID_TOOL1
 */

void MainFrame::OnTool1Click( wxCommandEvent& event )
{
	wxMessageBox("In handler");
}


