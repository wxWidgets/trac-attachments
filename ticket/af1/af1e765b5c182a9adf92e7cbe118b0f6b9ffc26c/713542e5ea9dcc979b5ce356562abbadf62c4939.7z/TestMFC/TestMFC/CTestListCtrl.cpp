// CTestListCtrl.cpp : implementation file
//

#include "pch.h"
#include "resource.h"
#include "TestMFC.h"
#include "CTestListCtrl.h"


// CTestListCtrl

IMPLEMENT_DYNAMIC(CTestListCtrl, CListCtrl)

CTestListCtrl::CTestListCtrl()
{

}

CTestListCtrl::~CTestListCtrl()
{
}

bool CTestListCtrl::Init()
{
    { // init image list
        BOOL ok = _imageList.Create(IDB_TEST, 16, 1, RGB(0, 0, 0));
        ASSERT(ok);
        SetImageList(&_imageList, LVSIL_SMALL);
    }

    { // insert a column
        LVCOLUMN lvc = { 0 };
        WCHAR buf[64];
        lvc.mask = LVCF_TEXT | LVCF_WIDTH;
        { // text
            lvc.pszText = buf;
            lvc.cchTextMax = _countof(buf);
            StrCpy(buf, L"Test Test Test");
        }
        { // width
            CClientDC dc(this);
            CSize size = dc.GetTextExtent(buf);
            lvc.cx = size.cx;
        }
        int n = InsertColumn(0, &lvc);
    }

    { // prepare column header
        CHeaderCtrl * pHC = GetHeaderCtrl();
        HDITEM hdi = { 0 };        
        hdi.mask = HDI_FORMAT | HDI_IMAGE;

        { // format
            hdi.fmt = HDF_STRING | HDF_BITMAP_ON_RIGHT;
        }        
        { // image
            hdi.iImage = 0;
        }
        BOOL ok = pHC->SetItem(0, &hdi);
        ASSERT(ok);
    }

    return true;
}


BEGIN_MESSAGE_MAP(CTestListCtrl, CListCtrl)
    ON_NOTIFY_REFLECT(LVN_COLUMNCLICK, &CTestListCtrl::OnLvnColumnclick)
END_MESSAGE_MAP()



// CTestListCtrl message handlers




void CTestListCtrl::OnLvnColumnclick(NMHDR * pNMHDR, LRESULT * pResult)
{
    LPNMLISTVIEW pNMLV = reinterpret_cast<LPNMLISTVIEW>(pNMHDR);

    ASSERT(pNMLV->iItem == -1 && pNMLV->iSubItem == 0);

    static bool bHasImage = true; // for test

    CHeaderCtrl * pHC = GetHeaderCtrl();
    HDITEM hdi = { 0 };

    if (bHasImage)
    {
        hdi.mask = HDI_FORMAT;
        hdi.fmt = HDF_STRING;
    }
    else
    {
        hdi.mask = HDI_FORMAT | HDI_IMAGE;
        hdi.fmt = HDF_STRING | HDF_BITMAP_ON_RIGHT;
        hdi.iImage = 0;

    }
    BOOL ok = pHC->SetItem(0, &hdi);
    ASSERT(ok);

    bHasImage = !bHasImage;

    *pResult = 0;
}
