#pragma once


// CTestListCtrl

class CTestListCtrl : public CListCtrl
{
	DECLARE_DYNAMIC(CTestListCtrl)

public:
	CTestListCtrl();
	virtual ~CTestListCtrl();

public:
	bool Init();

private:
	CImageList _imageList;
	CBitmap _bmpTest;
protected:
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnLvnColumnclick(NMHDR * pNMHDR, LRESULT * pResult);
};


