#include <iostream>
using namespace std;
#include "wx/wxprec.h"


#ifndef WX_PRECOMP
#include "wx/wx.h"
#endif

#include <ctype.h>
void printEvent(wxKeyEvent &evt, char *msg)
{
	char s[2000];
	sprintf(s,"In func %s. Shift=%d, Ctrl=%d, Alt=%d, KeyCode=%d\n",msg,(int)evt.ShiftDown(), (int)evt.ControlDown(), (int)evt.AltDown(), (int)evt.GetKeyCode());
	cout<<s<<endl;
#ifdef _WIN32
	OutputDebugString(s);
#endif
}

// Define a new application
class MyApp: public wxApp
{
  public:
    MyApp(void){};
    bool OnInit(void);
};

class MyWindow: public wxWindow
{
public:
	MyWindow(){}
	MyWindow(wxWindow *parent, wxWindowID id, const wxPoint& pos = wxDefaultPosition, const wxSize& size = wxDefaultSize, long style = 0, const wxString& name = wxPanelNameStr):wxWindow(parent,id,pos,size,style,name){}
	void OnKeyDown(wxKeyEvent& event){printEvent(event,"OnKeyDown");}
    void OnKeyUp(wxKeyEvent& event){printEvent(event,"OnKeyUp");}
 DECLARE_EVENT_TABLE()
};
class MyFrame: public wxFrame
{
  public:
    wxWindow *panel;
	MyFrame(wxWindow *parent, const wxWindowID id, const wxString& title, const wxPoint& pos, const wxSize& size): wxFrame(parent, id, title, pos, size){panel=0;}
 DECLARE_EVENT_TABLE()
};

IMPLEMENT_APP(MyApp)
BEGIN_EVENT_TABLE(MyWindow, wxWindow)
    EVT_KEY_DOWN(MyWindow::OnKeyDown)
    EVT_KEY_UP(MyWindow::OnKeyUp)
END_EVENT_TABLE()

bool MyApp::OnInit(void)
{
  // Create the main frame window
  MyFrame   *frame = new MyFrame(NULL, wxID_ANY, _T("wxWidgets Native Dialog Sample"), wxPoint(50, 50), wxSize(300, 250));

  // Make a panel
  frame->panel = new MyWindow(frame, wxID_ANY, wxPoint(0, 0), wxSize(400, 400), 0, _T("MyMainFrame"));
  frame->Show(true);

  // Return the main frame window
  SetTopWindow(frame);

  return true;
}

BEGIN_EVENT_TABLE(MyFrame, wxFrame)
END_EVENT_TABLE()

