/////////////////////////////////////////////////////////////////////////////
// Name:        fs_zip.h
// Purpose:     ZIP file system
// Author:      Vaclav Slavik
// Copyright:   (c) 1999 Vaclav Slavik
// CVS-ID:      $Id: fs_zip.h,v 1.17 2003/08/09 12:37:12 VS Exp $
// Licence:     wxWindows Licence
/////////////////////////////////////////////////////////////////////////////

#ifndef _WX_FS_TAR_H_
#define _WX_FS_TAR_H_

#if defined(__GNUG__) && !defined(NO_GCC_PRAGMA)
#pragma interface "fs_tar.h"
#endif

#include "wx/defs.h"

#if wxUSE_FILESYSTEM && /*wxUSE_FS_TAR &&*/ wxUSE_STREAMS

#include "wx/filesys.h"

class WXDLLIMPEXP_BASE wxLongToLongHashMap;


/////////////////////////////////////////////////////////////////////////////
// wxTarFSHandler

class wxTarFSHandler : public wxFileSystemHandler
{
public:
    wxTarFSHandler();
    virtual bool CanOpen(const wxString& location);
    virtual wxFSFile *OpenFile(wxFileSystem& fs, const wxString& location);
    virtual wxString FindFirst(const wxString& spec, int flags = 0);
    virtual wxString FindNext();
    ~wxTarFSHandler();

private:
    // these vars are used by FindFirst/Next:
    class wxTarInputStream *m_Archive;
    wxString m_Pattern, m_BaseDir, m_TarFile;
    bool m_AllowDirs, m_AllowFiles;
    wxLongToLongHashMap *m_DirsFound;

    wxString DoFind();

    DECLARE_NO_COPY_CLASS(wxTarFSHandler)
};


#endif // wxUSE_FILESYSTEM && wxUSE_FS_TAR && wxUSE_STREAMS

#endif // _WX_FS_TAR_H_

