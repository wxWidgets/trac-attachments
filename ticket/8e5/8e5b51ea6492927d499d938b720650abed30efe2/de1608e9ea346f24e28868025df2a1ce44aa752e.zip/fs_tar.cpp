/////////////////////////////////////////////////////////////////////////////
// Name:        fs_zip.cpp
// Purpose:     ZIP file system
// Author:      Vaclav Slavik
// Copyright:   (c) 1999 Vaclav Slavik
// CVS-ID:      $Id: fs_zip.cpp,v 1.26 2003/08/29 20:10:31 MBN Exp $
// Licence:     wxWindows Licence
/////////////////////////////////////////////////////////////////////////////

#if defined(__GNUG__) && !defined(NO_GCC_PRAGMA)
#pragma implementation "fs_tar.h"
#endif

// For compilers that support precompilation, includes "wx.h".
#include "wx/wxprec.h"

#ifdef __BORLANDC__
#pragma hdrstop
#endif

#if wxUSE_FILESYSTEM // && wxUSE_FS_TAR && wxUSE_TARSTREAM

#include "wx/log.h"
#include "wx/intl.h"
#include "wx/hashmap.h"
#include "wx/filesys.h"

#include "tarstrm.h"
#include "fs_tar.h"

//#include "wx/gzstream.h"

WX_DECLARE_EXPORTED_HASH_MAP( long, long, wxIntegerHash, wxIntegerEqual,
                              wxLongToLongHashMap );


class wxTarFSInputStream : public wxTarInputStream
{
public:
    wxTarFSInputStream(wxFSFile *pFile, wxMBConv& conv = wxConvFile)
    :  wxTarInputStream(*pFile->GetStream(), conv), m_pFile(pFile) { }

    ~wxTarFSInputStream() { delete m_pFile; }
private:
    wxFSFile *m_pFile;
};



wxTarFSHandler::wxTarFSHandler() : wxFileSystemHandler()
{
    m_Archive = NULL;
    m_TarFile = m_Pattern = m_BaseDir = wxEmptyString;
    m_AllowDirs = m_AllowFiles = TRUE;
    m_DirsFound = NULL;
}



wxTarFSHandler::~wxTarFSHandler()
{
    if (m_Archive)
        delete m_Archive;
    if (m_DirsFound)
        delete m_DirsFound;
}


bool wxTarFSHandler::CanOpen(const wxString& location)
{
    return GetProtocol(location) == wxT("tar");
}


wxFSFile *wxTarFSHandler::OpenFile(wxFileSystem& fs, const wxString& location)
{
    wxString right = GetRightLocation(location);
    wxString left = GetLeftLocation(location);

    if (left.empty()) {
        wxLogError(_("no location to the left of the tar 'protocol'"));
        return NULL;
    }

    wxFSFile *pTarFile = fs.OpenFile(left);
    if (pTarFile) {
        //wxGzipInputStream *pGzip = new wxGzipInputStream(*pTarFile->GetStream());
        //wxTarInputStream *pStream = new wxTarInputStream(pGzip);
        wxTarInputStream *pStream = new wxTarFSInputStream(pTarFile);
    
        if (pStream->OpenEntry(right))
            return new wxFSFile(
                pStream, location,
                GetMimeTypeFromExt(location),
                GetAnchor(location)
#if wxUSE_DATETIME
                , pStream->GetModifyTime()
#endif
                );
        delete pStream;    // owns pTarFile
    }

    return NULL;
}


wxString wxTarFSHandler::FindFirst(const wxString& spec, int flags)
{
    wxString right = GetRightLocation(spec);
    wxString left = GetLeftLocation(spec);

    if (right.Last() == wxT('/')) right.RemoveLast();

    if (m_Archive)
    {
        delete m_Archive;
        m_Archive = NULL;
    }

    switch (flags)
    {
        case wxFILE:
            m_AllowDirs = FALSE, m_AllowFiles = TRUE; break;
        case wxDIR:
            m_AllowDirs = TRUE, m_AllowFiles = FALSE; break;
        default:
            m_AllowDirs = m_AllowFiles = TRUE; break;
    }

    wxFileSystem fs;
    wxFSFile *pTarFile = fs.OpenFile(left);
    m_Archive = pTarFile ? new wxTarFSInputStream(pTarFile): NULL;

    m_TarFile = left;
    m_Pattern = right.AfterLast(wxT('/'));
    m_BaseDir = right.BeforeLast(wxT('/'));

    if (m_Archive)
    {
        if (m_AllowDirs)
        {
            delete m_DirsFound;
            m_DirsFound = new wxLongToLongHashMap();
        }
        return DoFind();
    }
    return wxEmptyString;
}



wxString wxTarFSHandler::FindNext()
{
    if (!m_Archive) return wxEmptyString;
    return DoFind();
}



wxString wxTarFSHandler::DoFind()
{
    wxString namestr, dir, filename;
    wxString match = wxEmptyString;

    while (match == wxEmptyString)
    {
        if (!m_Archive->OpenEntry()) {
            delete m_Archive;
            m_Archive = NULL;
            return wxEmptyString;
        }

        namestr = m_Archive->GetName();

        if (m_AllowDirs)
        {
            dir = namestr.BeforeLast(wxT('/'));
            while (!dir.IsEmpty())
            {
                long key = 0;
                for (size_t i = 0; i < dir.Length(); i++) key += (wxUChar)dir[i];
                wxLongToLongHashMap::iterator it = m_DirsFound->find(key);
                if (it == m_DirsFound->end())
                {
                    (*m_DirsFound)[key] = 1;
                    filename = dir.AfterLast(wxT('/'));
                    dir = dir.BeforeLast(wxT('/'));
                    if (!filename.IsEmpty() && m_BaseDir == dir &&
                                wxMatchWild(m_Pattern, filename, FALSE))
                        match = m_TarFile + wxT("#tar:") + dir + wxT("/") + filename;
                }
                else
                    break; // already tranversed
            }
        }

        filename = namestr.AfterLast(wxT('/'));
        dir = namestr.BeforeLast(wxT('/'));
        if (m_AllowFiles && !filename.IsEmpty() && m_BaseDir == dir &&
                            wxMatchWild(m_Pattern, filename, FALSE))
            match = m_TarFile + wxT("#tar:") + namestr;
    }

    return match;
}


#endif //wxUSE_FILESYSTEM && wxUSE_FS_TAR && wxUSE_TARSTREAM
