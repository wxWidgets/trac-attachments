--- E:\devel\projects\my patches\mslu\mslu.h	Thu Jan 13 15:53:19 2005
+++ E:\devel\projects\my patches\mslu\mslu_ddj.h	Thu Jan 13 16:03:12 2005
@@ -2,7 +2,7 @@
 // Name:        wx/msw/mslu.h
 // Purpose:     Fixes for bugs in MSLU
 // Author:      Vaclav Slavik
-// Modified by:
+// Modified by: Dario de Judicibus
 // Created:     2002/02/17
 // RCS-ID:      $Id: mslu.h,v 1.13 2005/01/07 18:48:28 RR Exp $
 // Copyright:   (c) 2002 Vaclav Slavik
@@ -61,8 +61,13 @@
 WXDLLIMPEXP_BASE int wxMSLU__waccess(const wxChar *name, int mode);
 WXDLLIMPEXP_BASE int wxMSLU__wmkdir(const wxChar *name);
 WXDLLIMPEXP_BASE int wxMSLU__wrmdir(const wxChar *name);
+// Modified by DdJ because BCC5 does not use _stati64 but stati64
 WXDLLIMPEXP_BASE int wxMSLU__wstat(const wxChar *name, struct _stat *buffer);
+#if ( defined(__BORLANDC__) && (__BORLANDC__ > 0x460) )
+WXDLLIMPEXP_BASE int wxMSLU__wstati64(const wxChar *name, struct stati64 *buffer);
+#else
 WXDLLIMPEXP_BASE int wxMSLU__wstati64(const wxChar *name, struct _stati64 *buffer);
+#endif // __BORLANDC__ > 0x460
 #endif
 
 #endif // wxUSE_UNICODE_MSLU
