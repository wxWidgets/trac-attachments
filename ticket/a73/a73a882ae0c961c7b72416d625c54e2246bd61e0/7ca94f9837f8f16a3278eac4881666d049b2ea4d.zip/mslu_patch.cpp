--- E:\devel\projects\my patches\mslu\mslu.cpp	Thu Jan 13 15:53:50 2005
+++ E:\devel\projects\my patches\mslu\mslu_ddj.cpp	Thu Jan 13 16:03:34 2005
@@ -2,7 +2,7 @@
 // Name:        msw/mslu.cpp
 // Purpose:     Fixes for bugs in MSLU
 // Author:      Vaclav Slavik
-// Modified by:
+// Modified by: Dario de Judicibus
 // Created:     2002/02/17
 // RCS-ID:      $Id: mslu.cpp,v 1.18 2005/01/07 18:48:30 RR Exp $
 // Copyright:   (c) 2002 Vaclav Slavik
@@ -226,7 +226,12 @@
         return _wstat(name, buffer);
 }
 
+// Modified by DdJ because BCC5 does not use _stati64 but stati64
+#if ( defined(__BORLANDC__) && (__BORLANDC__ > 0x460) )
+WXDLLIMPEXP_BASE int wxMSLU__wstati64(const wxChar *name, struct stati64 *buffer)
+#else
 WXDLLIMPEXP_BASE int wxMSLU__wstati64(const wxChar *name, struct _stati64 *buffer)
+#endif // __BORLANDC__ > 0x460
 {
     if ( wxUsingUnicowsDll() )
         return _stati64((const char*)wxConvFile.cWX2MB(name), buffer);
