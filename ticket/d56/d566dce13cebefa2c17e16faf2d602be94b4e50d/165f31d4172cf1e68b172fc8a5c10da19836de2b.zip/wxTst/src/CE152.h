/**@file CE152.h: Application for CE152 magnetic levitation ball modell. */
#ifndef _STANDALONEAPP_H
#define _STANDALONEAPP_H

#include <wx/fileconf.h> // for wxFileConfig


 /** 
 *  \mainpage CE152  Ball and Plate Model  
 *  \section intro_sec CE152 BnP API 
 *  This is the API for Ball and Plate Model. 
 */

 /**
 *  The Standalone Application (Ball&Plate Model) 
 *  This class shows a window containing a graph, simulation controls and buttons 
 */


class StandAloneApp: public wxApp
{

public:
    /**
    *  '<CODE>Main()</CODE>' equivalent: the program execution "starts" here
    *  \warning override base class virtuals
    *  \warning ----------------------------
    *  \warning this one is called on application startup and is a good place for the app
    *  \warning initialization (doing it here and not in the ctor allows to have an error
    *  \warning return: if <CODE>OnInit()</CODE> returns <CODE>false</CODE>, the application terminates)
    */
    virtual bool OnInit();
    
    /**
    *  OnExit is called after destroying all application windows and controls. 
    *  @see wxApp::OnExit()
    */
    int OnExit();
          
};


DECLARE_APP(StandAloneApp)


#endif _STANDALONEAPP_H

