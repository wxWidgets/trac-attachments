/**@file MainFrame.cpp: Form with main frame fo Ball & plate model. */

#include <wx/wxprec.h>
#ifndef WX_PRECOMP
 #include <wx/wx.h>
#endif
#include <wx/dcbuffer.h> // for preview 

#include "MainFrame.h"


const TCHAR *APP_NAME = _T("Magnetic levitation demo");

#define VIDEO_REFRESH_RATE 90	///< Screen repaint rate


/** Create main frame.
 *  @param[in] title The caption to be displayed on the frame's title bar
 *  @param[in] pos The window position
 *  @param[in] size The window size      */
BnPMainFrame::BnPMainFrame(const wxString& title, const wxPoint& pos, const wxSize& size):     
     wxFrame((wxFrame*)NULL, -1, title, pos, size),     
     mPreviewTimer(this,ID_TIMER), m_bmpBkg(NULL)
{    
   


    // Make a menubar
    menuBar = new wxMenuBar;

    // create Hardware
    menuHardware = new wxMenu;
    menuBar->Append(menuHardware, _T("&Hardware"));
    menuHardware->Append(ID_HARDWARE, _T("&Hardware"), _T("Control the hardware."));    

    menuHardware->Append(ID_SAVECONFIG, _T("&Save config"), _T("Save configuration to ini file."));
    menuHardware->Append(ID_RELOADCONFIG, _T("&Reload config"), _T("Reload configuration from ini file."));

    // create Controller
    menuController = new wxMenu;
    menuBar->Append(menuController, _T("&Controller"));

    menuController->Append(ID_CONTROL, _T("&Parameters"), _T("Parameters of model controler."));
    menuController->AppendSeparator();
    menuController->Append(ID_START, _T("&Start"), _T("Start the model."));
    menuController->Append(ID_STOP, _T("&Stop"), _T("Stop the model."));

    // create Model
    menuModel = new wxMenu;
    menuBar->Append(menuModel, _T("&Model"));
		// append menu entries    
    menuModel->Append(ID_PLOT, _T("&Plot"), _T("Plot the model graphs."));
    menuModel->AppendSeparator();
    menuModel->Append(ID_CALIBRATE, _T("&Reset"), _T("Set the model to the initial values."));
    menuModel->Append(ID_SET_DEFAULT, _T("&Set Default All"), _T("Set the default values."));

    // create Help
    menuHelp = new wxMenu;
    menuBar->Append(menuHelp, _T("&Help"));
    // append menu entries
    menuHelp->Append(ID_ABOUT, _T("&About"), _T("About the model software."));
   
    // Associate the menu bar with the frame
    SetMenuBar(menuBar);

    // create frame statusbar
    CreateStatusBar();
    // set statusbar text
    SetStatusText("Welcome to Magnetic Levitation Ball Model!");
    

    ////************* Arrange widgets **************************************
    BnPMainFrame* itemFrame = this;    

      /** create vertical stack with  ball plate and box. */
    SzrChart = new wxBoxSizer(wxVERTICAL);    

      /** ~vertical stack with  ball plate and combo box. */

    itemBoxSizerTop = new wxBoxSizer(wxHORIZONTAL); //Main sizer for Main frame
    itemFrame->SetSizer(itemBoxSizerTop);    

    itemBoxSizerTop->Add(SzrChart,1, wxGROW|wxALL, 0);

    itemBoxSTop = new wxBoxSizer(wxVERTICAL);    
    itemBoxSizerTop->Add(itemBoxSTop);

	/** PID controller constants. */
    wxPanel* iPanelControl = new wxPanel(itemFrame, ID_PANEL_CONTROL, wxDefaultPosition, wxDefaultSize, wxTAB_TRAVERSAL );    
    itemBoxSTop->Add(iPanelControl, 0, wxALIGN_CENTER_HORIZONTAL|wxALL, 5);
    
    wxFont LabelFont(8,wxSWISS,wxNORMAL,wxBOLD,FALSE,_T("Microsoft Sans Serif"));

    wxStaticText* LblProp = new wxStaticText( iPanelControl, wxID_STATIC, _("Kp"), wxDefaultPosition, wxDefaultSize, 0 );
    LblProp->SetFont(LabelFont);
    wxStaticText* LblInteg = new wxStaticText( iPanelControl, wxID_STATIC, _("Ki"), wxDefaultPosition, wxDefaultSize, 0 );
    LblInteg->SetFont(LabelFont);
    wxStaticText* LblDeriv = new wxStaticText( iPanelControl, wxID_STATIC, _("Kd"), wxDefaultPosition, wxDefaultSize, 0 );
    LblDeriv->SetFont(LabelFont);

    Edt_k = new wxTextCtrl(iPanelControl, ID_TEXTCTRL_P, _T(""), wxDefaultPosition, wxSize(60, -1), 0); //wxTE_READONLY);
    Edt_Ti = new wxTextCtrl(iPanelControl, ID_TEXTCTRL_I, _T(""), wxDefaultPosition, wxSize(60, -1), 0); // wxTE_READONLY);
    Edt_Td = new wxTextCtrl(iPanelControl, ID_TEXTCTRL_D, _T(""), wxDefaultPosition, wxSize(60, -1), 0); //wxTE_READONLY);    
    
    Scr_P = new wxScrollBar(iPanelControl, ID_SPINBUTTON_P, wxDefaultPosition, wxSize(50,-1), wxVERTICAL); //, wxSP_WRAP|wxSP_ARROW_KEYS );
    Scr_I = new wxScrollBar(iPanelControl, ID_SPINBUTTON_I, wxDefaultPosition, wxSize(50,-1), wxVERTICAL); //, wxSP_WRAP|wxSP_ARROW_KEYS );
    Scr_D = new wxScrollBar(iPanelControl, ID_SPINBUTTON_D, wxDefaultPosition, wxSize(50,-1), wxVERTICAL); //, wxSP_WRAP|wxSP_ARROW_KEYS );
    //itemSpinI = new wxSpinButton(iPanelControl, ID_SPINBUTTON_I, wxDefaultPosition, wxSize(50, 28), wxSP_WRAP|wxSP_ARROW_KEYS );
    //itemSpinD = new wxSpinButton(iPanelControl, ID_SPINBUTTON_D, wxDefaultPosition, wxSize(50, 28), wxSP_WRAP|wxSP_ARROW_KEYS );

	//PID widget placement
    wxSizer *SzrPID = new wxBoxSizer(wxHORIZONTAL);
    iPanelControl->SetSizer(SzrPID);
    wxSizer *SzrP = new wxBoxSizer(wxVERTICAL);
    wxSizer *SzrI = new wxBoxSizer(wxVERTICAL);
    wxSizer *SzrD = new wxBoxSizer(wxVERTICAL);        
    
    SzrP->Add(LblProp, 0, wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL|wxALL|wxADJUST_MINSIZE, 5);
    SzrP->Add(Edt_k, 0, wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL|wxALL, 5);
    SzrP->Add(Scr_P, 0, wxALIGN_CENTER_HORIZONTAL|wxALIGN_TOP|wxALL, 5);

    SzrI->Add(LblInteg, 0, wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL|wxALL|wxADJUST_MINSIZE, 5);
    SzrI->Add(Edt_Ti, 0, wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL|wxALL, 5);
    SzrI->Add(Scr_I, 0, wxALIGN_CENTER_HORIZONTAL|wxALIGN_TOP|wxALL, 5);    

    SzrD->Add(LblDeriv, 0, wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL|wxALL|wxADJUST_MINSIZE, 5);        
    SzrD->Add(Edt_Td, 0, wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL|wxALL, 5);            
    SzrD->Add(Scr_D, 0, wxALIGN_CENTER_HORIZONTAL|wxALIGN_TOP|wxALL, 5);

    SzrPID->Add(SzrP);  SzrPID->Add(SzrI);  SzrPID->Add(SzrD);
	/** ~PID controller constants. */

	/** Panel with coordinates. */
    iPanelCoor = new wxPanel(itemFrame, ID_PANEL_COOR, wxDefaultPosition, wxDefaultSize, wxTAB_TRAVERSAL );    
    itemBoxSTop->Add(iPanelCoor, 0, wxALIGN_CENTER_HORIZONTAL|wxALL, 5);

    //iPanelCoor->SetBackgroundColour(wxColour("YELLOW"));
    itcVideoY = new wxTextCtrl(iPanelCoor, ID_TEXTCTRL_XBLUE, _T("?.??"), wxDefaultPosition, wxSize(40, -1), wxTE_READONLY);
    itcVideoY->SetBackgroundColour(wxColour("GREY"));
    itcVideoY->SetForegroundColour(wxColour("BLUE"));    

    itcTargetY = new wxTextCtrl(iPanelCoor, ID_TEXTCTRL_YRED, _T("?.??"), wxDefaultPosition, wxSize(40, -1), wxTE_READONLY);
    itcTargetY->SetBackgroundColour(wxColour("GREY"));
    itcTargetY->SetForegroundColour(wxColour("RED"));    

    wxStaticText *itsCoorY = new wxStaticText( iPanelCoor, wxID_STATIC, _("Y"), wxDefaultPosition, wxDefaultSize, 0 );
    itsCoorY->SetFont(wxFont(8, wxSWISS, wxNORMAL, wxBOLD, FALSE, _T("Microsoft Sans Serif")));    

    wxGridSizer *igsCoor = new wxGridSizer(1, 3, 0, 0);
    iPanelCoor->SetSizer(igsCoor);
    
    igsCoor->Add(itcVideoY, 0, wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL|wxALL, 5);
    igsCoor->Add(itsCoorY, 0, wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL|wxALL|wxADJUST_MINSIZE, 5);
    igsCoor->Add(itcTargetY, 0, wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL|wxALL, 5);    
	/** ~Panel with coordinates. */

        /** Panel with buttons. */
    wxPanel* iPanelButton = new wxPanel(itemFrame, ID_PANEL_BUTTON, wxDefaultPosition, wxDefaultSize, wxSUNKEN_BORDER|wxTAB_TRAVERSAL );
    itemBoxSTop->Add(iPanelButton, 0, wxALIGN_CENTER_HORIZONTAL|wxALL, 5);    
    
    BtnStart = new wxButton( iPanelButton, ID_BUTTON_START, _("Start"), wxDefaultPosition, wxDefaultSize, 0 );
    BtnStop = new wxButton( iPanelButton, ID_BUTTON_STOP, _("Stop"), wxDefaultPosition, wxDefaultSize, 0 );
    itemButtonPlot = new wxButton( iPanelButton, ID_BUTTON_PLOT, _("Plot"), wxDefaultPosition, wxDefaultSize, 0 );
    BtnCalibrate = new wxButton( iPanelButton, ID_BUTTON_RESET, _("Calibrate"), wxDefaultPosition, wxDefaultSize, 0 );

    itemFGridButton = new wxFlexGridSizer(2, 2, 0, 0);
    iPanelButton->SetSizer(itemFGridButton);

    itemFGridButton->Add(BtnStart, 0, wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL|wxALL, 5);
    itemFGridButton->Add(BtnStop, 0, wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL|wxALL, 5);
    itemFGridButton->Add(itemButtonPlot, 0, wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL|wxALL, 5);
    itemFGridButton->Add(BtnCalibrate, 0, wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL|wxALL, 5);    
	/** ~Panel with buttons. */

    #ifdef __WXMSW__
    SetIcon(wxICON(MagLevitation.ico));
    #endif		/// \todo set icon also for other OS
    
    // restore the control's values from the config    
 

    const wxSize& minSize = wxSize(500, 400); 
    itemFrame->SetSizeHints(minSize);
    
    

    wxCommandEvent EvtNull;
    OnLoadConfig(EvtNull);
    RepaintPID();    

    SetBackgroundColour(iPanelButton->GetBackgroundColour());

    SetAutoLayout(true);
    Layout();
    
    mPreviewTimer.Start(VIDEO_REFRESH_RATE);	//video refresh rate    
}


BnPMainFrame::~BnPMainFrame() 
{
  if(m_bmpBkg) {delete m_bmpBkg;m_bmpBkg=NULL;}

    // save the frame position
    
}


/**
 * // ----------------------------------------------------------------------------
 * // event tables and other macros for wxWidgets
 * // ----------------------------------------------------------------------------
 *
 * // the event tables connect the wxWidgets events with the functions (event
 * // handlers) which process them. It can be also done at run-time, but for the
 * // simple menu events like this the static method is much simpler.
 */
BEGIN_EVENT_TABLE(BnPMainFrame, wxFrame)
    EVT_TIMER(ID_TIMER,         BnPMainFrame::OnTimer)  //place timer first to speedup table search.
    //EVT_PAINT(                  BnPMainFrame::OnPaint)
    //EVT_ERASE_BACKGROUND(       BnPMainFrame::OnEraseBackground)

    EVT_MENU(ID_ABOUT,          BnPMainFrame::OnAbout)
    EVT_MENU(ID_CONTROL,        BnPMainFrame::OnController)
    EVT_MENU(ID_HARDWARE,       BnPMainFrame::OnHardware)    
    EVT_MENU(ID_SAVECONFIG,     BnPMainFrame::OnSaveConfig)
    EVT_MENU(ID_RELOADCONFIG,   BnPMainFrame::OnLoadConfig)    
    EVT_MENU(ID_PLOT,           BnPMainFrame::OnPlot)
    EVT_BUTTON(ID_BUTTON_PLOT,  BnPMainFrame::OnPlot)
    EVT_BUTTON(ID_BUTTON_RESET, BnPMainFrame::OnCalibrate)
    EVT_MENU(ID_CALIBRATE,      BnPMainFrame::OnCalibrate)
    //// There is conflict between RESET and SETDEFAULT Original program is confusing
    EVT_MENU(ID_SET_DEFAULT,    BnPMainFrame::OnSetDefault)
    EVT_SIZE(                   BnPMainFrame::OnSize)
    EVT_MENU(ID_START,          BnPMainFrame::OnStart)
    EVT_BUTTON(ID_BUTTON_START, BnPMainFrame::OnStart)
    EVT_MENU(ID_STOP,           BnPMainFrame::OnStop) 
    EVT_BUTTON(ID_BUTTON_STOP,  BnPMainFrame::OnStop)
    EVT_SPIN_DOWN(ID_SPINBUTTON_P,BnPMainFrame::OnSpinDownP)
    EVT_SPIN_DOWN(ID_SPINBUTTON_I,BnPMainFrame::OnSpinDownI)
    EVT_SPIN_DOWN(ID_SPINBUTTON_D,BnPMainFrame::OnSpinDownD)
    EVT_SPIN_UP(ID_SPINBUTTON_P,BnPMainFrame::OnSpinUpP)
    EVT_SPIN_UP(ID_SPINBUTTON_I,BnPMainFrame::OnSpinUpI)
    EVT_SPIN_UP(ID_SPINBUTTON_D,BnPMainFrame::OnSpinUpD)
    EVT_COMMAND_SCROLL_THUMBTRACK(ID_SPINBUTTON_P,BnPMainFrame::OnThumbP)
    EVT_COMMAND_SCROLL_THUMBTRACK(ID_SPINBUTTON_I,BnPMainFrame::OnThumbI)
    EVT_COMMAND_SCROLL_THUMBTRACK(ID_SPINBUTTON_D,BnPMainFrame::OnThumbD)
    EVT_COMMAND_SCROLL_PAGEUP(ID_SPINBUTTON_P,BnPMainFrame::OnThumbP)
    EVT_COMMAND_SCROLL_PAGEUP(ID_SPINBUTTON_I,BnPMainFrame::OnThumbI)
    EVT_COMMAND_SCROLL_PAGEUP(ID_SPINBUTTON_D,BnPMainFrame::OnThumbD)
    EVT_COMMAND_SCROLL_PAGEDOWN(ID_SPINBUTTON_P,BnPMainFrame::OnThumbP)
    EVT_COMMAND_SCROLL_PAGEDOWN(ID_SPINBUTTON_I,BnPMainFrame::OnThumbI)
    EVT_COMMAND_SCROLL_PAGEDOWN(ID_SPINBUTTON_D,BnPMainFrame::OnThumbD)
    EVT_TEXT(ID_TEXTCTRL_P,	BnPMainFrame::OnChangedP)
    EVT_TEXT(ID_TEXTCTRL_I,	BnPMainFrame::OnChangedI)
    EVT_TEXT(ID_TEXTCTRL_D,	BnPMainFrame::OnChangedD)
    //EVT_CLOSE(			BnPMainFrame::OnClose)

   // EVT_COMMAND(-1, wxEVT_FORMCLOSED, BnPMainFrame::OnPlotClose)
   // EVT_COMMAND(-1, wxEVT_DAQCHANGED, BnPMainFrame::OnDaqChanged)
END_EVENT_TABLE()


/** Plot window was shut down - Reactive the plot button */
void BnPMainFrame::OnPlotClose(wxCommandEvent & WXUNUSED(event))
{
  itemButtonPlot->Enable(true);
}


void BnPMainFrame::OnPaint(wxPaintEvent &WXUNUSED(event))
{
int width;
int height;
wxCoord w,h;
static const char *Humusoft = "TEST";

  wxPaintDC dc(this);
  GetClientSize(&width, &height);

  dc.Clear();

    //Paint Humusoft logo
  dc.SetFont(wxFont(30, wxROMAN, wxNORMAL, wxBOLD));
  dc.GetTextExtent(Humusoft,&w,&h);  	
  dc.DrawText(Humusoft, width-w-3, height-h);
}


/** DAQ hardware was changed, re-attach controls to a new device. */
void BnPMainFrame::OnDaqChanged(wxCommandEvent & WXUNUSED(event))
{
  
}


void BnPMainFrame::OnTimer(wxTimerEvent & event)
{
}


/** Repaint PID values on a main frame. */
void BnPMainFrame::RepaintPID(void)
{
}


/** Opens an about dialog 
 *  @param[in] event Unused event  */
void BnPMainFrame::OnAbout(wxCommandEvent& WXUNUSED(event))
{    
}


void BnPMainFrame::OnSaveConfig(wxCommandEvent & WXUNUSED(event))
{
}


void BnPMainFrame::OnLoadConfig(wxCommandEvent & WXUNUSED(event))
{
}


void BnPMainFrame::OnController(wxCommandEvent& WXUNUSED(event))
{
}


void BnPMainFrame::OnHardware(wxCommandEvent& WXUNUSED(event))
{
}


void BnPMainFrame::ButtonMode(bool Control)
{
  BtnStart->Enable(!Control);
  BtnCalibrate->Enable(!Control);
  Edt_k->Enable(!Control);	//disable direct editing of PID constants
  Edt_Ti->Enable(!Control);
  Edt_Td->Enable(!Control);

  menuHardware->Enable(ID_HARDWARE, !Control);  
  menuController->Enable(ID_START, !Control);
  menuModel->Enable(ID_CALIBRATE, !Control);
  menuModel->Enable(ID_SET_DEFAULT, !Control);
}


/** Opens plot frame for the graphs of signals
 *  @param[in] event Unused event  */
void BnPMainFrame::OnPlot(wxCommandEvent& WXUNUSED(event))
{ 

}


/**
 * Resets the values. 
 *  @param[in] event Unused event  */
void BnPMainFrame::OnCalibrate(wxCommandEvent& WXUNUSED(event))
{       
}


/** Starts the simulation
 *  @param[in] event Unused event */
void BnPMainFrame::OnStart(wxCommandEvent& WXUNUSED(event))
{   
}


/** Decrease P compound with delta.
 *  Note: This do not emit thumb event when changing ScrollBar.
 *  Note2:Edt_k is refreshed twice, second refresh is triggered by LastChange. */
void BnPMainFrame::OnSpinDownP(wxSpinEvent & WXUNUSED(event))
{
}


/** Decrease I compound with delta.
 *  Note: This do not emit thumb event when changing ScrollBar.
 *  Note2:Edt_Ki is refreshed twice, second refresh is triggered by LastChange. */
void BnPMainFrame::OnSpinDownI(wxSpinEvent& WXUNUSED(event))
{
}


/** Decrease D compound with delta.
 *  Note: This do not emit thumb event when changing ScrollBar.
 *  Note2:Edt_Kd is refreshed twice, second refresh is triggered by LastChange. */
void BnPMainFrame::OnSpinDownD(wxSpinEvent& WXUNUSED(event))
{
}


/** Increase P compound with delta.
 *  Note: This do not emit thumb event when changing ScrollBar.
 *  Note2:Edt_k is refreshed twice, second refresh is triggered by LastChange. */
void BnPMainFrame::OnSpinUpP(wxSpinEvent& WXUNUSED(event))
{ 
}


/** Increase I compound with delta.
 *  Note: This do not emit thumb event when changing ScrollBar.
    Note2:Edt_Ti is refreshed twice, second refresh is triggered by LastChange. */
void BnPMainFrame::OnSpinUpI(wxSpinEvent& WXUNUSED(event))
{
}


/** Increase D compound with delta.
 *  Note: This do not emit thumb event when changing ScrollBar.
 *  Note2:Edt_Td is refreshed twice, second refresh is triggered by LastChange. */
void BnPMainFrame::OnSpinUpD(wxSpinEvent& WXUNUSED(event))
{
  
}


/** Scrollbar is moved, set a new P compound value.
 *  Note:Scr_P is refreshed twice, second refresh is triggered by
       LastChange++ -> OnChangedP(). */
void BnPMainFrame::OnThumbP(wxScrollEvent& WXUNUSED(event))
{
  
}


/** Scrollbar is moved, set a new I compound value.
 *  Note:Scr_I is refreshed twice, second refresh is triggered by
       LastChange++ -> OnChangedI(). */
void BnPMainFrame::OnThumbI(wxScrollEvent& WXUNUSED(event))
{
 
}


/** Scrollbar is moved, set a new D compound value.
 *  Note:Scr_D is refreshed twice, second refresh is triggered by
       LastChange++ -> OnChangedD(). */
void BnPMainFrame::OnThumbD(wxScrollEvent& WXUNUSED(event))
{
 
}


/** Stops the timer */
void BnPMainFrame::StopCapturing(void)
{
  if(mPreviewTimer.IsRunning())
           mPreviewTimer.Stop();
};


/** Starts the timer. */
void BnPMainFrame::StartCapturing(void)
{
 if(!mPreviewTimer.IsRunning())
     mPreviewTimer.Start();
};


/**
 *  Stops the controller, but timer still paints MagnetBall and detects
 *  a position of a ball.
 *  @param[in] event Unused event   */
void BnPMainFrame::OnStop(wxCommandEvent& WXUNUSED(event))
{
  ButtonMode(false);
}


/**
 *  Initializes all the values to the default one.
 *  @param[in] event Unused event  */
void BnPMainFrame::OnSetDefault(wxCommandEvent& WXUNUSED(event))
{  
}


/**
 *  When the size is changed, it is called and then it refreshs the screen and sets the layouts   
 *
 *  @param[in] event Unused event
 *
 *  \warning If the drawing depends on the size of the window, 
 *  \warning clearing the DC explicitly may be needed and repainting the whole window. 
 *  \warning In which case, calling <CODE>wxWindow::Refresh()</CODE> may be needed to invalidate the entire window.  */
void BnPMainFrame::OnSize(wxSizeEvent& WXUNUSED(event))
{   // if your drawing depends on the size of the window, 
    // you may need to clear the DC explicitly and repaint the whole window. 
    // In which case, you may need to call wxWindow::Refresh() to invalidate the entire window.
    SetAutoLayout(true);
    Layout();
    Refresh();
}


/** When a size is changed, it is called and then it refreshs the screen and sets the layouts 
 *  @param[in] event Unused event
 *  \warning If the drawing depends on the size of the window, 
 *  \warning clearing the DC explicitly may be needed and repainting the whole window. 
 *  \warning In which case, calling <CODE>wxWindow::Refresh()</CODE> may be needed to invalidate the entire window. */
void BnPMainFrame::OnEraseBackground(wxEraseEvent& WXUNUSED(event))
{
 // do nothing
}


/** Change k value */
void BnPMainFrame::OnChangedP(wxCommandEvent& WXUNUSED(event))
{
}


/** Change Ti value */
void BnPMainFrame::OnChangedI(wxCommandEvent& WXUNUSED(event))
{
}


/** Change Td value */
void BnPMainFrame::OnChangedD(wxCommandEvent& WXUNUSED(event))
{
}


void BnPMainFrame::OnClose(wxCloseEvent & event)
{
  Show(false);
  event.Skip();
}