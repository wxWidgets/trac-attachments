/**@file MainFrame.h: Prototypes for a main frame */

#ifndef _BNPMAINFRAME_H
#define _BNPMAINFRAME_H

#include <wx/spinbutt.h>
#include <wx/bitmap.h>
#include <wx/image.h>


 /**
 *  "Main frame" 
 *
 *  This is to be our main frame and it shows ball position graph and 
 *  widgets controlling the simulation as the application is running */
class BnPMainFrame: public wxFrame
{
public:
   
    /** Create main frame. */
    BnPMainFrame(const wxString& title, const wxPoint& pos, const wxSize& size);        
    ~BnPMainFrame();
               
    void OnPaint(wxPaintEvent &WXUNUSED(event));
    void OnEraseBackground(wxEraseEvent& event); ///< When the size is changed, it is called and then it refreshs the screen and sets the layouts
    void OnAbout(wxCommandEvent& event);       ///< Display about dialog

    /** Manages the position view, video capture view  and thresholed view of the model. */
    void OnController(wxCommandEvent& event);   ///< Opens a PID controller dialog
       
    void OnHardware(wxCommandEvent& event);	///< Opens a hardware setup dialog    
   
    void OnSaveConfig(wxCommandEvent& event);
    void OnLoadConfig(wxCommandEvent & event);
    void OnClose(wxCloseEvent & event);

    void OnPlot(wxCommandEvent& event);		///< Opens plot frame for the graphs of signals
    void OnCalibrate(wxCommandEvent& event);	///< Resets the values       
    void OnSetDefault(wxCommandEvent& event);   ///< Initializes all the values to the default one.       
    void OnSize(wxSizeEvent &event);		///< When the size is changed, it is called and then it refreshs the screen and sets the layouts.
       
    void OnStart(wxCommandEvent& event);	///< Starts the simulation      
    void OnStop(wxCommandEvent& event);		///< Stops the simulation             
    void RepaintPID(void);	                ///< Repaint PID values on canvas        

    void StartCapturing(void);		///< Starts the timer.
    void StopCapturing(void);

private:    
    DECLARE_EVENT_TABLE()	// any class wishing to process wxWidgets events must use this macro

    long AcceptedPidChange;	///< accepted PID values in a form

    wxTimer mPreviewTimer;

    wxMenu *menuHardware; 
    wxMenu *menuController;
    wxMenu *menuModel;
    wxMenu *menuHelp;
    wxMenuBar *menuBar; 

    wxBoxSizer* SzrChart;
    wxPanel* iPanelRight;
    wxBoxSizer *itemBoxSizerTop;
    wxBoxSizer* itemBoxSTop;
    wxTextCtrl* Edt_k;
    wxTextCtrl* Edt_Ti;
    wxTextCtrl* Edt_Td;
    wxScrollBar *Scr_P;
    wxScrollBar *Scr_I;
    wxScrollBar *Scr_D;
    wxTextCtrl* itcTargetY;
    wxTextCtrl* itcVideoY;    
    wxPanel* iPanelCoor;
    wxFlexGridSizer* itemFGridButton;
    wxButton* BtnStart;
    wxButton* BtnStop;
    wxButton* itemButtonPlot;
    wxButton* BtnCalibrate;    
    wxBitmap *m_bmpBkg;

    void OnPlotClose(wxCommandEvent & event); ///< Receive a signal that plot window was shut down
    void OnDaqChanged(wxCommandEvent & event);  ///< Receive signal that DAQ device is beeing changed.

    void OnSpinUpP(wxSpinEvent & event);
    void OnSpinUpI(wxSpinEvent & event);
    void OnSpinUpD(wxSpinEvent & event);
    void OnSpinDownP(wxSpinEvent & event);
    void OnSpinDownI(wxSpinEvent & event);
    void OnSpinDownD(wxSpinEvent & event);
    void OnChangedP(wxCommandEvent & event);
    void OnChangedI(wxCommandEvent & event);
    void OnChangedD(wxCommandEvent & event);
    void OnThumbP(wxScrollEvent & event);
    void OnThumbI(wxScrollEvent & event);
    void OnThumbD(wxScrollEvent & event);

    void OnTimer(wxTimerEvent & event);
    void ButtonMode(bool Control);

    /** Decides what it is on, ie, either graph illustration
     *  or raw picture or thresholded picture    */
    enum VISION_STATES {   
         GRAPH = 0,      ///< Indicates graph with target and video circle
         RAW_PIC,        ///< Indicates raw picture from webcam
         THRESHOLDED_PIC,///< Indicates thresholded picture (which is used for detecting the ball position)
	 RAW_COLOR
    };
    
    wxImage  img;		      ///< Captured image        

public:    

    /**  Constants:
    *  IDs for the controls and the menu commands. Excluding those already defined
    *  by wxWidgets, such as wxID_NEW.   */
    enum
    {
        ID_ABOUT = 1,
        ID_CONTROL,
        ID_HARDWARE,        
        ID_PLOT,
        ID_CALIBRATE,
        ID_SET_DEFAULT,
        ID_START,
        ID_STOP,
        ID_SAVECONFIG,
	ID_RELOADCONFIG,
        ID_TIMER,

        // GUI items
        ID_BUTTON_START,
        ID_BUTTON_STOP,
        ID_BUTTON_PLOT,
        ID_BUTTON_RESET,        
        ID_PANEL_BUTTON,
        ID_PANEL_CONTROL,
        ID_PANEL_COOR,
        ID_PANEL_RIGHT,
        ID_PANEL_LEFT,
        ID_SPINBUTTON_P,
        ID_SPINBUTTON_I,
        ID_SPINBUTTON_D,
        ID_TEXTCTRL_P,
        ID_TEXTCTRL_I,
        ID_TEXTCTRL_D,
        ID_TEXTCTRL_XRED,
        ID_TEXTCTRL_YRED,
        ID_TEXTCTRL_XBLUE,
        ID_TEXTCTRL_YBLUE   
    };  
};



#endif _BNPMAINFRAME_H
