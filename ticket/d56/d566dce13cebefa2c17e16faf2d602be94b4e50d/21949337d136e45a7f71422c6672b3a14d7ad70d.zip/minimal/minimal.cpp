/////////////////////////////////////////////////////////////////////////////
// Name:        minimal.cpp
// Purpose:     Minimal wxWidgets sample
// Author:      Julian Smart
// Modified by:
// Created:     04/01/98
// RCS-ID:      $Id: minimal.cpp,v 1.67 2005/02/20 16:14:03 JS Exp $
// Copyright:   (c) Julian Smart
// Licence:     wxWindows licence
/////////////////////////////////////////////////////////////////////////////

// ============================================================================
// declarations
// ============================================================================

// ----------------------------------------------------------------------------
// headers
// ----------------------------------------------------------------------------

// For compilers that support precompilation, includes "wx/wx.h".
#include "wx/wxprec.h"

#ifdef __BORLANDC__
    #pragma hdrstop
#endif

// for all others, include the necessary headers (this file is usually all you
// need because it includes almost all "standard" wxWidgets headers)
#ifndef WX_PRECOMP
    #include "wx/wx.h"
#endif

// ----------------------------------------------------------------------------
// resources
// ----------------------------------------------------------------------------

// the application icon (under Windows and OS/2 it is in resources and even
// though we could still include the XPM here it would be unused)
#if !defined(__WXMSW__) && !defined(__WXPM__)
    #include "../sample.xpm"
#endif

// ----------------------------------------------------------------------------
// private classes
// ----------------------------------------------------------------------------

// Define a new application type, each program should derive a class from wxApp
class MyApp : public wxApp
{
public:
    // override base class virtuals
    // ----------------------------

    // this one is called on application startup and is a good place for the app
    // initialization (doing it here and not in the ctor allows to have an error
    // return: if OnInit() returns false, the application terminates)
    virtual bool OnInit();
};

// Define a new frame type: this is going to be our main frame
class MyFrame : public wxFrame
{
public:
    // ctor(s)
    MyFrame(const wxString& title);

    // event handlers (these functions should _not_ be virtual)
    void OnQuit(wxCommandEvent& event);
    void OnAbout(wxCommandEvent& event);

private:
    // any class wishing to process wxWidgets events must use this macro
    DECLARE_EVENT_TABLE()

    wxBoxSizer* SzrChart;
    wxPanel* iPanelRight;
    wxBoxSizer *itemBoxSizerTop;
    wxBoxSizer* itemBoxSTop;
    wxTextCtrl* Edt_k;
    wxTextCtrl* Edt_Ti;
    wxTextCtrl* Edt_Td;
    wxScrollBar *Scr_P;
    wxScrollBar *Scr_I;
    wxScrollBar *Scr_D;
    wxTextCtrl* itcTargetY;
    wxTextCtrl* itcVideoY;    
    wxPanel* iPanelCoor;
    wxFlexGridSizer* itemFGridButton;
    wxButton* BtnStart;
    wxButton* BtnStop;
    wxButton* itemButtonPlot;
    wxButton* BtnCalibrate;    
    wxBitmap *m_bmpBkg;

    /**  Constants:
    *  IDs for the controls and the menu commands. Excluding those already defined
    *  by wxWidgets, such as wxID_NEW.   */
    enum
    {
        ID_ABOUT = 1,
        ID_CONTROL,
        ID_HARDWARE,        
        ID_PLOT,
        ID_CALIBRATE,
        ID_SET_DEFAULT,
        ID_START,
        ID_STOP,
        ID_SAVECONFIG,
	ID_RELOADCONFIG,
        ID_TIMER,

        // GUI items
        ID_BUTTON_START,
        ID_BUTTON_STOP,
        ID_BUTTON_PLOT,
        ID_BUTTON_RESET,        
        ID_PANEL_BUTTON,
        ID_PANEL_CONTROL,
        ID_PANEL_COOR,
        ID_PANEL_RIGHT,
        ID_PANEL_LEFT,
        ID_SPINBUTTON_P,
        ID_SPINBUTTON_I,
        ID_SPINBUTTON_D,
        ID_TEXTCTRL_P,
        ID_TEXTCTRL_I,
        ID_TEXTCTRL_D,
        ID_TEXTCTRL_XRED,
        ID_TEXTCTRL_YRED,
        ID_TEXTCTRL_XBLUE,
        ID_TEXTCTRL_YBLUE   
    };  
};

// ----------------------------------------------------------------------------
// constants
// ----------------------------------------------------------------------------

// IDs for the controls and the menu commands
enum
{
    // menu items
    Minimal_Quit = wxID_EXIT,

    // it is important for the id corresponding to the "About" command to have
    // this standard value as otherwise it won't be handled properly under Mac
    // (where it is special and put into the "Apple" menu)
    Minimal_About = wxID_ABOUT
};

// ----------------------------------------------------------------------------
// event tables and other macros for wxWidgets
// ----------------------------------------------------------------------------

// the event tables connect the wxWidgets events with the functions (event
// handlers) which process them. It can be also done at run-time, but for the
// simple menu events like this the static method is much simpler.
BEGIN_EVENT_TABLE(MyFrame, wxFrame)
    EVT_MENU(Minimal_Quit,  MyFrame::OnQuit)
    EVT_MENU(Minimal_About, MyFrame::OnAbout)
END_EVENT_TABLE()

// Create a new application object: this macro will allow wxWidgets to create
// the application object during program execution (it's better than using a
// static object for many reasons) and also implements the accessor function
// wxGetApp() which will return the reference of the right type (i.e. MyApp and
// not wxApp)
IMPLEMENT_APP(MyApp)

// ============================================================================
// implementation
// ============================================================================

// ----------------------------------------------------------------------------
// the application class
// ----------------------------------------------------------------------------

// 'Main program' equivalent: the program execution "starts" here
bool MyApp::OnInit()
{
    // create the main application window
    MyFrame *frame = new MyFrame(_T("Minimal wxWidgets App"));

    // and show it (the frames, unlike simple controls, are not shown when
    // created initially)
    frame->Show(true);

    // success: wxApp::OnRun() will be called which will enter the main message
    // loop and the application will run. If we returned false here, the
    // application would exit immediately.
    return true;
}

// ----------------------------------------------------------------------------
// main frame
// ----------------------------------------------------------------------------

// frame constructor
MyFrame::MyFrame(const wxString& title)
       : wxFrame(NULL, wxID_ANY, title)         
{
    // set the frame icon
    SetIcon(wxICON(sample));

#if wxUSE_MENUS
    // create a menu bar
    wxMenu *fileMenu = new wxMenu;

    // the "About" item should be in the help menu
    wxMenu *helpMenu = new wxMenu;
    helpMenu->Append(Minimal_About, _T("&About...\tF1"), _T("Show about dialog"));

    fileMenu->Append(Minimal_Quit, _T("E&xit\tAlt-X"), _T("Quit this program"));

    // now append the freshly created menu to the menu bar...
    wxMenuBar *menuBar = new wxMenuBar();
    menuBar->Append(fileMenu, _T("&File"));
    menuBar->Append(helpMenu, _T("&Help"));

    // ... and attach this menu bar to the frame
    SetMenuBar(menuBar);
#endif // wxUSE_MENUS

    ////************* Arrange widgets **************************************
    MyFrame* itemFrame = this;    

      /** create vertical stack with  ball plate and box. */
    SzrChart = new wxBoxSizer(wxVERTICAL);    

      /** ~vertical stack with  ball plate and combo box. */

    itemBoxSizerTop = new wxBoxSizer(wxHORIZONTAL); //Main sizer for Main frame
    itemFrame->SetSizer(itemBoxSizerTop);    

    itemBoxSizerTop->Add(SzrChart,1, wxGROW|wxALL, 0);

    itemBoxSTop = new wxBoxSizer(wxVERTICAL);    
    itemBoxSizerTop->Add(itemBoxSTop);

	/** PID controller constants. */
    wxPanel* iPanelControl = new wxPanel(itemFrame, ID_PANEL_CONTROL, wxDefaultPosition, wxDefaultSize, wxTAB_TRAVERSAL );    
    itemBoxSTop->Add(iPanelControl, 0, wxALIGN_CENTER_HORIZONTAL|wxALL, 5);
    
    wxFont LabelFont(8,wxSWISS,wxNORMAL,wxBOLD,FALSE,_T("Microsoft Sans Serif"));

    wxStaticText* LblProp = new wxStaticText( iPanelControl, wxID_STATIC, _("Kp"), wxDefaultPosition, wxDefaultSize, 0 );
    LblProp->SetFont(LabelFont);
    wxStaticText* LblInteg = new wxStaticText( iPanelControl, wxID_STATIC, _("Ki"), wxDefaultPosition, wxDefaultSize, 0 );
    LblInteg->SetFont(LabelFont);
    wxStaticText* LblDeriv = new wxStaticText( iPanelControl, wxID_STATIC, _("Kd"), wxDefaultPosition, wxDefaultSize, 0 );
    LblDeriv->SetFont(LabelFont);

    Edt_k = new wxTextCtrl(iPanelControl, ID_TEXTCTRL_P, _T(""), wxDefaultPosition, wxSize(60, -1), 0); //wxTE_READONLY);
    Edt_Ti = new wxTextCtrl(iPanelControl, ID_TEXTCTRL_I, _T(""), wxDefaultPosition, wxSize(60, -1), 0); // wxTE_READONLY);
    Edt_Td = new wxTextCtrl(iPanelControl, ID_TEXTCTRL_D, _T(""), wxDefaultPosition, wxSize(60, -1), 0); //wxTE_READONLY);    
    
    Scr_P = new wxScrollBar(iPanelControl, ID_SPINBUTTON_P, wxDefaultPosition, wxSize(50,-1), wxVERTICAL); //, wxSP_WRAP|wxSP_ARROW_KEYS );
    Scr_I = new wxScrollBar(iPanelControl, ID_SPINBUTTON_I, wxDefaultPosition, wxSize(50,-1), wxVERTICAL); //, wxSP_WRAP|wxSP_ARROW_KEYS );
    Scr_D = new wxScrollBar(iPanelControl, ID_SPINBUTTON_D, wxDefaultPosition, wxSize(50,-1), wxVERTICAL); //, wxSP_WRAP|wxSP_ARROW_KEYS );
    //itemSpinI = new wxSpinButton(iPanelControl, ID_SPINBUTTON_I, wxDefaultPosition, wxSize(50, 28), wxSP_WRAP|wxSP_ARROW_KEYS );
    //itemSpinD = new wxSpinButton(iPanelControl, ID_SPINBUTTON_D, wxDefaultPosition, wxSize(50, 28), wxSP_WRAP|wxSP_ARROW_KEYS );

	//PID widget placement
    wxSizer *SzrPID = new wxBoxSizer(wxHORIZONTAL);
    iPanelControl->SetSizer(SzrPID);
    wxSizer *SzrP = new wxBoxSizer(wxVERTICAL);
    wxSizer *SzrI = new wxBoxSizer(wxVERTICAL);
    wxSizer *SzrD = new wxBoxSizer(wxVERTICAL);        
    
    SzrP->Add(LblProp, 0, wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL|wxALL|wxADJUST_MINSIZE, 5);
    SzrP->Add(Edt_k, 0, wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL|wxALL, 5);
    SzrP->Add(Scr_P, 0, wxALIGN_CENTER_HORIZONTAL|wxALIGN_TOP|wxALL, 5);

    SzrI->Add(LblInteg, 0, wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL|wxALL|wxADJUST_MINSIZE, 5);
    SzrI->Add(Edt_Ti, 0, wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL|wxALL, 5);
    SzrI->Add(Scr_I, 0, wxALIGN_CENTER_HORIZONTAL|wxALIGN_TOP|wxALL, 5);    

    SzrD->Add(LblDeriv, 0, wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL|wxALL|wxADJUST_MINSIZE, 5);        
    SzrD->Add(Edt_Td, 0, wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL|wxALL, 5);            
    SzrD->Add(Scr_D, 0, wxALIGN_CENTER_HORIZONTAL|wxALIGN_TOP|wxALL, 5);

    SzrPID->Add(SzrP);  SzrPID->Add(SzrI);  SzrPID->Add(SzrD);
	/** ~PID controller constants. */

	/** Panel with coordinates. */
    iPanelCoor = new wxPanel(itemFrame, ID_PANEL_COOR, wxDefaultPosition, wxDefaultSize, wxTAB_TRAVERSAL );    
    itemBoxSTop->Add(iPanelCoor, 0, wxALIGN_CENTER_HORIZONTAL|wxALL, 5);

    //iPanelCoor->SetBackgroundColour(wxColour("YELLOW"));
    itcVideoY = new wxTextCtrl(iPanelCoor, ID_TEXTCTRL_XBLUE, _T("?.??"), wxDefaultPosition, wxSize(40, -1), wxTE_READONLY);
    itcVideoY->SetBackgroundColour(wxColour("GREY"));
    itcVideoY->SetForegroundColour(wxColour("BLUE"));    

    itcTargetY = new wxTextCtrl(iPanelCoor, ID_TEXTCTRL_YRED, _T("?.??"), wxDefaultPosition, wxSize(40, -1), wxTE_READONLY);
    itcTargetY->SetBackgroundColour(wxColour("GREY"));
    itcTargetY->SetForegroundColour(wxColour("RED"));    

    wxStaticText *itsCoorY = new wxStaticText( iPanelCoor, wxID_STATIC, _("Y"), wxDefaultPosition, wxDefaultSize, 0 );
    itsCoorY->SetFont(wxFont(8, wxSWISS, wxNORMAL, wxBOLD, FALSE, _T("Microsoft Sans Serif")));    

    wxGridSizer *igsCoor = new wxGridSizer(1, 3, 0, 0);
    iPanelCoor->SetSizer(igsCoor);
    
    igsCoor->Add(itcVideoY, 0, wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL|wxALL, 5);
    igsCoor->Add(itsCoorY, 0, wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL|wxALL|wxADJUST_MINSIZE, 5);
    igsCoor->Add(itcTargetY, 0, wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL|wxALL, 5);    
	/** ~Panel with coordinates. */

        /** Panel with buttons. */
    wxPanel* iPanelButton = new wxPanel(itemFrame, ID_PANEL_BUTTON, wxDefaultPosition, wxDefaultSize, wxSUNKEN_BORDER|wxTAB_TRAVERSAL );
    itemBoxSTop->Add(iPanelButton, 0, wxALIGN_CENTER_HORIZONTAL|wxALL, 5);    
    
    BtnStart = new wxButton( iPanelButton, ID_BUTTON_START, _("Start"), wxDefaultPosition, wxDefaultSize, 0 );
    BtnStop = new wxButton( iPanelButton, ID_BUTTON_STOP, _("Stop"), wxDefaultPosition, wxDefaultSize, 0 );
    itemButtonPlot = new wxButton( iPanelButton, ID_BUTTON_PLOT, _("Plot"), wxDefaultPosition, wxDefaultSize, 0 );
    BtnCalibrate = new wxButton( iPanelButton, ID_BUTTON_RESET, _("Calibrate"), wxDefaultPosition, wxDefaultSize, 0 );

    itemFGridButton = new wxFlexGridSizer(2, 2, 0, 0);
    iPanelButton->SetSizer(itemFGridButton);

    itemFGridButton->Add(BtnStart, 0, wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL|wxALL, 5);
    itemFGridButton->Add(BtnStop, 0, wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL|wxALL, 5);
    itemFGridButton->Add(itemButtonPlot, 0, wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL|wxALL, 5);
    itemFGridButton->Add(BtnCalibrate, 0, wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL|wxALL, 5);    
	/** ~Panel with buttons. */
    
    // restore the control's values from the config              

#if wxUSE_STATUSBAR
    // create a status bar just for fun (by default with 1 pane only)
    CreateStatusBar(2);
    SetStatusText(_T("Welcome to wxWidgets!"));
#endif // wxUSE_STATUSBAR

    const wxSize& minSize = wxSize(500, 600); 
    itemFrame->SetSizeHints(minSize); 
    wxCommandEvent EvtNull;
   
    itemFrame->SetSize(minSize);
 
   SetBackgroundColour(iPanelButton->GetBackgroundColour());

    SetAutoLayout(true);
    Layout();

}


// event handlers

void MyFrame::OnQuit(wxCommandEvent& WXUNUSED(event))
{
    // true is to force the frame to close
    Close(true);
}

void MyFrame::OnAbout(wxCommandEvent& WXUNUSED(event))
{
    wxString msg;
    msg.Printf( _T("This is the About dialog of the minimal sample.\n")
                _T("Welcome to %s"), wxVERSION_STRING);

    wxMessageBox(msg, _T("About Minimal"), wxOK | wxICON_INFORMATION, this);
}
