// imaggif.h

#ifndef _STDINT_H
typedef unsigned char uint8_t;
#endif

typedef short GifWord;
typedef uint8_t GifByteType;

struct GifHashTableType;
class wxImageArray;

class wxGIFHandlerEx : public wxGIFHandler
{
public:
   wxGIFHandlerEx() : wxGIFHandler(), m_HashTable(NULL)
   {
   }
   virtual ~wxGIFHandlerEx()
   {
      wxASSERT(NULL == m_HashTable);
   }
   virtual bool SaveFile(wxImage *image, wxOutputStream& stream, bool verbose);
   
   virtual bool SaveFile(const wxImageArray&, wxOutputStream&, bool verbose); // new virtual

protected:
   unsigned long m_CrntShiftDWord;   /* For bytes decomposition into codes. */
   int m_PixelCount;
   GifHashTableType* m_HashTable;
    GifWord 
      m_EOFCode,     /* The EOF LZ code. */
      m_ClearCode,   /* The CLEAR LZ code. */
      m_RunningCode, /* The next code algorithm can generate. */
      m_RunningBits, /* The number of bits required to represent RunningCode. */
      m_MaxCode1,    /* 1 bigger than max. possible code, in RunningBits bits. */
      m_CrntCode,    /* Current algorithm code. */
       m_CrntShiftState;    /* Number of bits in CrntShiftDWord. */
    GifByteType m_LZBuf[256];   /* Compressed input is buffered here. */

   bool CompressOutput(int Code, wxOutputStream&);
   bool SetupCompress( wxOutputStream&);
   bool CompressLine( uint8_t *Line, int LineLen, wxOutputStream&);
   bool InitHashTable(void);
   void ClearHashTable(void);
   void InsertHashTable(unsigned long Key, int Code);
   int ExistsHashTable(unsigned long Key);

   static bool PutWord(int Word, wxOutputStream&);
   static int KeyItem(unsigned long Item);
   static int BitSize(int n);
   static bool BufferedOutput(uint8_t *Buf, int c, wxOutputStream&);
};
