/////////////////////////////////////////////////////////////////////////////
// Name:        imaggif.cpp
// Purpose:     wxGIFHandlerEx
// Author:      
// RCS-ID:      
// Copyright:   
// Licence:     wxWindows licence
/////////////////////////////////////////////////////////////////////////////

#include "precomp.h"

#if wxUSE_IMAGE && wxUSE_GIF

#include "wx/imaggif.h"
#include "wx/gifdecod.h"
#include "wx/wfstream.h"
#include "wx/log.h"
#include "wx/intl.h"
#include "wx/quantize.h"
#include "wx/palette.h"
#include "imaggif.h"
#include "gif_hash.h"

#define GIF89_HDR	"GIF89a"

#define FLUSH_OUTPUT        4096    /* Impossible code, to signal flush. */
#define FIRST_CODE          4097    /* Impossible code, to signal first. */
#define LZ_MAX_CODE         4095    /* Biggest code possible in 12 bits. */

typedef struct _wxRGB 
{  
   uint8_t red; 
   uint8_t green; 
   uint8_t blue; 
} wxRGB;

//IMPLEMENT_DYNAMIC_CLASS(wxGIFHandlerEx,wxGIFHandler)

//-----------------------------------------------------------------------------
// wxGIFHandlerEx
//-----------------------------------------------------------------------------

#if wxUSE_STREAMS

bool wxGIFHandlerEx::SaveFile(wxImage *image, wxOutputStream& stream, 
							bool WXUNUSED(verbose))
{
    bool ok = true;

	int palette_size = image->CountColours(); // 252
   palette_size = wxMin(palette_size, 256);
   wxPalette *palette = NULL;
   wxImage temp;   // destination for quantized image
	uint8_t *eightBitData;

	wxQuantize::Quantize( *image, temp, &palette, palette_size, &eightBitData, 
							wxQUANTIZE_FILL_DESTINATION_IMAGE | wxQUANTIZE_RETURN_8BIT_DATA);


	int iHeight = temp.GetHeight();
	int iWidth = temp.GetWidth();
   int iWidth_even = iWidth + ((iWidth % 2) ? 1 : 0);
	
	// write GIF header
    stream.Write(GIF89_HDR, sizeof(GIF89_HDR)-1);
	PutWord(iWidth, stream);
	PutWord(iHeight, stream);

   int bpp = BitSize(palette_size);

   uint8_t Buf[8];
 //Buf[0] = 0x80 | (wxMin(palette_size, 0x100-1) >> 2);
	Buf[0] = 0x80;
	Buf[0] |=(bpp - 1) << 5;
	Buf[0] |=(bpp - 1);

   Buf[1] = 0; // background color == entry 0
   Buf[2] = 0; // aspect ratio 1:1

   stream.Write(Buf, 3);

	// write out color palette
	for (int i = 0; i < (1 << bpp); i++)
	{
      wxRGB clr;
		if ( !palette->GetRGB(i, &clr.red, &clr.green, &clr.blue) )
      {
			clr.red = clr.green = clr.blue = 0;
      }
		Buf[0] = clr.red;
		Buf[1] = clr.green;
		Buf[2] = clr.blue;
		stream.Write(Buf, 3);
	}
	
	 if (image->HasMask())
    {
        wxRGB mask;
        // image->GetMask(&mask);
        mask.red   = image->GetMaskRed();
        mask.green = image->GetMaskGreen();
        mask.blue  = image->GetMaskBlue();

        // add a extension block for transparency
        Buf[0] = '!';	// extension marker
        Buf[1] = 0xf9;	// graphic control extension
        Buf[2] = 4;		// length of block
        Buf[3] = 0x01;	// has transparency
        Buf[4] = 0;		// no delay time
        Buf[5] = 0;
        Buf[6] = (uint8_t)palette->GetPixel(mask.red, mask.green, mask.blue); // transparent color index
        Buf[7] = 0;

        stream.Write(Buf, 8);
    }
		
    Buf[0] = ','; // image separator
    stream.Write(Buf, 1);
	 PutWord(0, stream); // left
	 PutWord(0, stream); // top
	 PutWord(iWidth, stream); // width
	 PutWord(iHeight, stream); // height

	 Buf[0] = 0;
    stream.Write(Buf, 1);

    wxDELETE(palette)

	 if (InitHashTable())
    {
        SetupCompress(stream);

	     uint8_t *pColors = eightBitData;
	     m_PixelCount = iHeight * iWidth_even;
	     for (int y = 0; y != iHeight; ++y)
        {
		      m_PixelCount -= iWidth;
		      if (image->HasAlpha())
            {
			       // map transparent pixels to transparent index
			       for (int x = 0; x != iWidth; ++x) 
                {
				        if (image->GetAlpha(x, y) == wxIMAGE_ALPHA_TRANSPARENT)
                    {
					         *(pColors+x) = palette_size;
                    }
                }
		      }
		      CompressLine(pColors, iWidth_even, stream);
		      pColors += iWidth;
        }

	     Buf[0] = ';';
	     stream.Write(Buf, 1);
    }
    else
    {
		  wxLogError(_("Couldn't initialize GIF hash table."));
    }
	 delete[] eightBitData;
	
	 if (m_HashTable)
    {
		free(m_HashTable);
		m_HashTable = NULL;
    }
    return ok;
}

bool wxGIFHandlerEx::CompressOutput(int Code, wxOutputStream& stream)
{
	if (Code == FLUSH_OUTPUT)
   {
		while (m_CrntShiftState > 0)
      {
			/* Get Rid of what is left in DWord, and flush it. */
			if (!BufferedOutput(m_LZBuf, m_CrntShiftDWord & 0xff, stream))
				return false;
			m_CrntShiftDWord >>= 8;
			m_CrntShiftState -= 8;
		}
		m_CrntShiftState = 0;                       /* For next time. */
		if (!BufferedOutput(m_LZBuf, FLUSH_OUTPUT, stream))
			return false;
	}
	else
   {
		m_CrntShiftDWord |= ((long) Code) << m_CrntShiftState;
		m_CrntShiftState += m_RunningBits;
		while (m_CrntShiftState >= 8)
      {
			/* Dump out full bytes: */
			if (!BufferedOutput(m_LZBuf, m_CrntShiftDWord & 0xff, stream))
				return false;
			m_CrntShiftDWord >>= 8;
			m_CrntShiftState -= 8;
		}
	}

	/* If code can't fit into RunningBits bits, must raise its size. Note */
	/* however that codes above 4095 are used for special signaling.      */
	if (m_RunningCode >= m_MaxCode1 && Code <= 4095)
   {
		m_MaxCode1 = 1 << ++m_RunningBits;
	}
	return true;
}

bool wxGIFHandlerEx::SetupCompress( wxOutputStream& stream )
{
	uint8_t Buf[1];

	Buf[0] = 8;
	stream.Write(Buf, 1);

	m_LZBuf[0] = 0;			  /* Nothing was output yet. */
	m_ClearCode = (1 << 8);
	m_EOFCode = m_ClearCode + 1;
	m_RunningCode = m_EOFCode + 1;
	m_RunningBits = 8 + 1;	 /* Number of bits per code. */
	m_MaxCode1 = 1 << m_RunningBits;	   /* Max. code + 1. */
	m_CrntCode = FIRST_CODE;	   /* Signal that this is first one! */
	m_CrntShiftState = 0;      /* No information in CrntShiftDWord. */
	m_CrntShiftDWord = 0;

	/* Clear hash table and send Clear to make sure the decoder do the same. */
	ClearHashTable();

	if (!CompressOutput(m_ClearCode, stream))
   {
		return false;
	}
	return true;
}

bool wxGIFHandlerEx::CompressLine( uint8_t *Line, int LineLen, wxOutputStream& stream )
{
    int i = 0, CrntCode, NewCode;
    unsigned long NewKey;
    uint8_t Pixel;
    if (m_CrntCode == FIRST_CODE)                  /* Its first time! */
        CrntCode = Line[i++];
    else
        CrntCode = m_CrntCode;     /* Get last code in compression. */

    while (i < LineLen)
    {                           /* Decode LineLen items. */
        Pixel = Line[i++];                    /* Get next pixel from stream. */
       /* Form a new unique key to search hash table for the code combines  */
       /* CrntCode as Prefix string with Pixel as postfix char.             */
       NewKey = (((unsigned long) CrntCode) << 8) + Pixel;
       if ((NewCode = ExistsHashTable(NewKey)) >= 0) {
           /* This Key is already there, or the string is old one, so       */
           /* simple take new code as our CrntCode:                         */
           CrntCode = NewCode;
       }
       else
       {
           /* Put it in hash table, output the prefix code, and make our    */
           /* CrntCode equal to Pixel.                                      */
           if (!CompressOutput(CrntCode, stream))
               return false;
           
           CrntCode = Pixel;

           /* If however the HashTable if full, we send a clear first and   */
           /* Clear the hash table.                                         */
           if (m_RunningCode >= LZ_MAX_CODE) {
               /* Time to do some clearance: */
               if (!CompressOutput(m_ClearCode, stream))
                   return false;

               m_RunningCode = m_EOFCode + 1;
               m_RunningBits = 8 + 1;
               m_MaxCode1 = 1 << m_RunningBits;
               ClearHashTable();
           }
           else
           {
               /* Put this unique key with its relative Code in hash table: */
               InsertHashTable(NewKey, m_RunningCode++);
           }
       }

    }

    /* Preserve the current state of the compression algorithm: */
    m_CrntCode = CrntCode;

    if (m_PixelCount == 0)
    {
        /* We are done - output last Code and flush output buffers: */
        if (!CompressOutput(CrntCode, stream))
        {
            return false;
        }
        if (!CompressOutput(m_EOFCode, stream))
        {
            return false;
        }
        if (!CompressOutput(FLUSH_OUTPUT, stream))
        {
            return false;
        }
    }
    return true;
}

bool wxGIFHandlerEx::InitHashTable(void)
{
   if (m_HashTable == NULL) m_HashTable = (GifHashTableType *) malloc(sizeof(GifHashTableType));
	if (!m_HashTable)
        return false;
    ClearHashTable();
	return true;
}

void wxGIFHandlerEx::ClearHashTable(void)
{
    int index = HT_SIZE;
    unsigned int* HTable = m_HashTable->HTable;
    while (--index>=0)
    {
        HTable[index] = 0xfffffffful;
    }
}

void wxGIFHandlerEx::InsertHashTable(unsigned long Key, int Code)
{
    int HKey = KeyItem(Key);
    unsigned int *HTable = m_HashTable->HTable;

    while (HT_GET_KEY(HTable[HKey]) != 0xFFFFFL)
    {
        HKey = (HKey + 1) & HT_KEY_MASK;
    }
    HTable[HKey] = HT_PUT_KEY(Key) | HT_PUT_CODE(Code);
}


int wxGIFHandlerEx::ExistsHashTable(unsigned long Key)
{
    int HKey = KeyItem(Key);
    unsigned int *HTable = m_HashTable->HTable, HTKey;

    while ((HTKey = HT_GET_KEY(HTable[HKey])) != 0xFFFFFL)
    {
        if (Key == HTKey) 
			return HT_GET_CODE(HTable[HKey]);
        HKey = (HKey + 1) & HT_KEY_MASK;
    }
    return -1;
}

/*static*/ bool wxGIFHandlerEx::PutWord(int Word, wxOutputStream& stream)
{
    uint8_t c[2];

    c[0] = Word & 0xff;
    c[1] = (Word >> 8) & 0xff;

	 stream.Write( c, 2 );
	 return stream.IsOk();
}

/*static*/ int wxGIFHandlerEx::KeyItem(unsigned long Item)
{
    return ((Item >> 12) ^ Item) & HT_KEY_MASK;
}

/*static*/ int wxGIFHandlerEx::BitSize(int n)
{
    for (int i = 1; i <= 8; i++)
        if ((1 << i) >= n)
            break;
    return(i);
}

/*static*/ bool wxGIFHandlerEx::BufferedOutput(uint8_t *Buf, int c, wxOutputStream& stream)
{
    if (c == FLUSH_OUTPUT)
    {
        /* Flush everything out. */
        if (Buf[0] != 0)
			stream.Write(Buf, Buf[0]+1);
        /* Mark end of compressed data, by an empty block (see GIF doc): */
        Buf[0] = 0;
        stream.Write(Buf, 1);
    }
    else
    {
        if (Buf[0] == 255) {
            /* Dump out this buffer - it is full: */
            stream.Write(Buf, Buf[0] + 1);
            Buf[0] = 0;
        }
        Buf[++Buf[0]] = c;
    }
    return true;
}

bool wxGIFHandlerEx::SaveFile(const wxImageArray& images, wxOutputStream& stream, bool WXUNUSED(verbose))
{
    return false;
}


#endif  // wxUSE_STREAMS

#endif  // wxUSE_GIF
