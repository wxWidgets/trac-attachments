// For compilers that support precompilation, includes "wx/wx.h".
#include "wx/wxprec.h"

#ifdef __BORLANDC__
    #pragma hdrstop
#endif

#ifndef WX_PRECOMP
    #include "wx/log.h"
    #include "wx/app.h"
    #include "wx/frame.h"
    #include "wx/menu.h"
	#include "wx/dnd.h"
	#include "wx/dataview.h"
	#include <wx/msgdlg.h>
    #include "wx/textdlg.h"
	#include <wx/kbdstate.h>
	#include <wx/utils.h>

#endif

#include "wx/splitter.h"

#ifndef __WXMSW__
    #include "sample.xpm"
#endif

/* use DnD method within wxDataViewCtrl */
//#define _USE_DND_DVC_

/* use standard DnD method for wxSplitterWindow */
#define _USE_DND_STD_

#ifdef _USE_DND_DVC_
	#ifdef _USE_DND_STD_
		#error define only one
	#endif
#else
	#ifndef _USE_DND_STD_
		#error define one
	#endif
#endif

// ----------------------------------------------------------------------------
// constants

// ID for the menu commands
enum
{
    SPLIT_QUIT = 1,

	ID_LEFT_CTRL = 50,
	ID_RIGHT_CTRL
};

// ----------------------------------------------------------------------------
// our classes

class MyLeftTreeModelNode;
WX_DEFINE_ARRAY_PTR( MyLeftTreeModelNode*, MyLeftTreeModelNodePtrArray );

class MyLeftTreeModelNode
{
public:
    MyLeftTreeModelNode( MyLeftTreeModelNode* parent, const wxString &title, bool bIsContainer )
    {
        m_parent = parent;
        m_title = title;
        m_container = bIsContainer;
    }

    ~MyLeftTreeModelNode()
    {
        // free all our children nodes
        size_t count = m_children.GetCount();
        for (size_t i = 0; i < count; i++)
        {
            MyLeftTreeModelNode *child = m_children[i];
            delete child;
        }
    }

    bool IsContainer() const { return m_container; }

    MyLeftTreeModelNode* GetParent() { return m_parent; }
    MyLeftTreeModelNodePtrArray& GetChildren() { return m_children; }
    void Append( MyLeftTreeModelNode* child ) { m_children.Add( child ); }
    unsigned int GetChildCount() const { return m_children.GetCount(); }

public:     // public to avoid getters/setters
    wxString                m_title;

    // TODO/FIXME:
    // the GTK version of wxDVC (in particular wxDataViewCtrlInternal::ItemAdded)
    // needs to know in advance if a node is or _will be_ a container.
    // Thus implementing:
    //   bool IsContainer() const
    //    { return m_children.GetCount()>0; }
    // doesn't work with wxGTK when MyLeftTreeModel::AddToClassical is called
    // AND the classical node was removed (a new node temporary without children
    // would be added to the control)
    bool m_container;

private:
    MyLeftTreeModelNode          *m_parent;
    MyLeftTreeModelNodePtrArray   m_children;
};

class MyLeftTreeModel: public wxDataViewModel
{
public:
    MyLeftTreeModel();
    ~MyLeftTreeModel()
    {
		// free all our children nodes
		size_t	count = m_children.GetCount();
		for ( size_t i=0; i<count; i++ )
		{
			MyLeftTreeModelNode*	Child = m_children[i];
			delete Child;
		}
    }

    // override sorting to always sort branches ascendingly
    int Compare( const wxDataViewItem &item1, const wxDataViewItem &item2, unsigned int column, bool ascending ) const;

    // implementation of base class virtuals to define model
    virtual unsigned int GetColumnCount() const { return 1; }
    virtual wxString GetColumnType( unsigned int WXUNUSED(col) ) const { return wxT("string"); }
	virtual bool HasContainerColumns(const wxDataViewItem& WXUNUSED(item)) const { return true; };

    virtual void GetValue( wxVariant &variant, const wxDataViewItem &item, unsigned int col ) const;
    virtual bool SetValue( const wxVariant &variant, const wxDataViewItem &item, unsigned int col );

    virtual wxDataViewItem GetParent( const wxDataViewItem &item ) const;
    virtual bool IsContainer( const wxDataViewItem &item ) const;
    virtual unsigned int GetChildren( const wxDataViewItem &parent, wxDataViewItemArray &array ) const;

    MyLeftTreeModelNodePtrArray   m_children;
};

MyLeftTreeModel::MyLeftTreeModel()
{
    // setup left
    MyLeftTreeModelNode*	pNode;
    MyLeftTreeModelNode*	pSubNode;
    MyLeftTreeModelNode*	pSubSubNode;

	pNode = new MyLeftTreeModelNode( NULL/*m_root*/, "A", true );
	m_children.Add(pNode);
	ItemAdded(NULL, pNode);
	    pNode->Append( pSubNode = new MyLeftTreeModelNode( pNode, "A1", false ) );
		ItemAdded(pNode, pSubNode);
	    pNode->Append( pSubNode = new MyLeftTreeModelNode( pNode, "A2", false ) );
		ItemAdded(pNode, pSubNode);
	    pNode->Append( pSubNode = new MyLeftTreeModelNode( pNode, "A3", false ) );
		ItemAdded(pNode, pSubNode);
    pNode = new MyLeftTreeModelNode( NULL, "B", false );
	m_children.Add(pNode);
	ItemAdded(NULL, pNode);
    pNode = new MyLeftTreeModelNode( NULL, "C", false );
	m_children.Add(pNode);
	ItemAdded(NULL, pNode);
    pNode = new MyLeftTreeModelNode( NULL, "D", false );
	m_children.Add(pNode);
	ItemAdded(NULL, pNode);
    pNode = new MyLeftTreeModelNode( NULL, "E", false );
	m_children.Add(pNode);
	ItemAdded(NULL, pNode);
    pNode = new MyLeftTreeModelNode( NULL, "F", false );
	m_children.Add(pNode);
	ItemAdded(NULL, pNode);
    pNode = new MyLeftTreeModelNode( NULL, "G", false );
	m_children.Add(pNode);
	ItemAdded(NULL, pNode);
	pNode = new MyLeftTreeModelNode( NULL, "H", true );
	m_children.Add(pNode);
	ItemAdded(NULL, pNode);
		pNode->Append( pSubNode = new MyLeftTreeModelNode( pNode, "H1", true ) );
		ItemAdded(pNode, pSubNode);
			pSubNode->Append( pSubSubNode = new MyLeftTreeModelNode( pSubNode, "HH1", false ) );
			ItemAdded(pSubNode, pSubSubNode);
		pNode->Append( pSubNode = new MyLeftTreeModelNode( pNode, "H2", true ) );
		ItemAdded(pNode, pSubNode);
			pSubNode->Append( pSubSubNode = new MyLeftTreeModelNode( pSubNode, "HH2", false ) );
			ItemAdded(pSubNode, pSubSubNode);
	pNode = new MyLeftTreeModelNode( NULL, "I", true );
	m_children.Add(pNode);
	ItemAdded(NULL, pNode);
		pNode->Append( pSubNode = new MyLeftTreeModelNode( pNode, "I1", true ) );
		ItemAdded(pNode, pSubNode);
			pSubNode->Append( pSubSubNode = new MyLeftTreeModelNode( pSubNode, "II1", false ) );
			ItemAdded(pSubNode, pSubSubNode);
		pNode->Append( pSubNode = new MyLeftTreeModelNode( pNode, "I2", true ) );
		ItemAdded(pNode, pSubNode);
			pSubNode->Append( pSubSubNode = new MyLeftTreeModelNode( pSubNode, "II2", false ) );
			ItemAdded(pSubNode, pSubSubNode);
		pNode->Append( pSubNode = new MyLeftTreeModelNode( pNode, "I3", true ) );
		ItemAdded(pNode, pSubNode);
			pSubNode->Append( pSubSubNode = new MyLeftTreeModelNode( pSubNode, "II3", false ) );
			ItemAdded(pSubNode, pSubSubNode);
	pNode = new MyLeftTreeModelNode( NULL/*m_root*/, "J", true );
	m_children.Add(pNode);
	ItemAdded(NULL, pNode);
		pNode->Append( pSubNode = new MyLeftTreeModelNode( pNode, "J1", false ) );
		ItemAdded(pNode, pSubNode);
}

int MyLeftTreeModel::Compare( const wxDataViewItem &item1, const wxDataViewItem &item2,
                              unsigned int column, bool ascending ) const
{
    wxASSERT(item1.IsOk() && item2.IsOk());
        // should never happen

    if (IsContainer(item1) && IsContainer(item2))
    {
        wxVariant value1, value2;
        GetValue( value1, item1, 0 );
        GetValue( value2, item2, 0 );

        wxString str1 = value1.GetString();
        wxString str2 = value2.GetString();
        int res = str1.Cmp( str2 );
        if (res) return res;
    }

    return wxDataViewModel::Compare( item1, item2, column, ascending );
}

void MyLeftTreeModel::GetValue( wxVariant &variant,
                                const wxDataViewItem &item,
								unsigned int WXUNUSED(col) ) const
{
    wxASSERT(item.IsOk());

    MyLeftTreeModelNode *node = (MyLeftTreeModelNode*) item.GetID();
    variant = node->m_title;
}

bool MyLeftTreeModel::SetValue( const wxVariant &variant,
                                const wxDataViewItem &item,
								unsigned int WXUNUSED(col) )
{
    wxASSERT(item.IsOk());

    MyLeftTreeModelNode *node = (MyLeftTreeModelNode*) item.GetID();
    node->m_title = variant.GetString();
    return false;
}

wxDataViewItem MyLeftTreeModel::GetParent( const wxDataViewItem &item ) const
{
    // the invisible root node has no parent
    if (!item.IsOk())
        return wxDataViewItem(0);

    MyLeftTreeModelNode *node = (MyLeftTreeModelNode*) item.GetID();

    // "root" also has no parent
    if (node == NULL)
        return wxDataViewItem(0);

    return wxDataViewItem( (void*) node->GetParent() );
}

bool MyLeftTreeModel::IsContainer( const wxDataViewItem &item ) const
{
    // the invisble root node can have children
    // (in our model always "root")
    if (!item.IsOk())
        return true;

    MyLeftTreeModelNode *node = (MyLeftTreeModelNode*) item.GetID();
    return node->IsContainer();
}

unsigned int MyLeftTreeModel::GetChildren( const wxDataViewItem &parent,
                                           wxDataViewItemArray &array ) const
{
    MyLeftTreeModelNode *node = (MyLeftTreeModelNode*) parent.GetID();
    if ( node == NULL )
    {
		unsigned int count = m_children.GetCount();
		for (unsigned int pos = 0; pos < count; pos++)
		{
			MyLeftTreeModelNode *child = m_children.Item( pos );
			array.Add( wxDataViewItem( (void*) child ) );
		}
		return count;
    }

    if (node->GetChildCount() == 0)
    {
        return 0;
    }

    unsigned int count = node->GetChildren().GetCount();
    for (unsigned int pos = 0; pos < count; pos++)
    {
        MyLeftTreeModelNode *child = node->GetChildren().Item( pos );
        array.Add( wxDataViewItem( (void*) child ) );
    }
    return count;
}

// ----------------------------------------------------------------------------

class MyRightTreeModelNode;
WX_DEFINE_ARRAY_PTR( MyRightTreeModelNode*, MyRightTreeModelNodePtrArray );

class MyRightTreeModelNode
{
public:
    MyRightTreeModelNode( MyRightTreeModelNode* parent,
                         const wxString &title,
                         const wxString &value,
						 bool bIsContainer )
    {
        m_parent = parent;
        m_title = title;
		m_value = value;
        m_container = bIsContainer;
    }

    ~MyRightTreeModelNode()
    {
        // free all our children nodes
        size_t count = m_children.GetCount();
        for (size_t i = 0; i < count; i++)
        {
            MyRightTreeModelNode *child = m_children[i];
            delete child;
        }
    }

    bool IsContainer() const { return m_container; }

    MyRightTreeModelNode* GetParent() { return m_parent; }
    MyRightTreeModelNodePtrArray& GetChildren() { return m_children; }
    void Append( MyRightTreeModelNode* child ) { m_children.Add( child ); }
    unsigned int GetChildCount() const { return m_children.GetCount(); }

public:     // public to avoid getters/setters
    wxString                m_title;
	wxString                m_value;

    // TODO/FIXME:
    // the GTK version of wxDVC (in particular wxDataViewCtrlInternal::ItemAdded)
    // needs to know in advance if a node is or _will be_ a container.
    // Thus implementing:
    //   bool IsContainer() const
    //    { return m_children.GetCount()>0; }
    // doesn't work with wxGTK when MyRightTreeModel::AddToClassical is called
    // AND the classical node was removed (a new node temporary without children
    // would be added to the control)
    bool m_container;

private:
    MyRightTreeModelNode          *m_parent;
    MyRightTreeModelNodePtrArray   m_children;
};

class MyRightTreeModel: public wxDataViewModel
{
public:
    MyRightTreeModel();
    ~MyRightTreeModel()
    {
		// free all our children nodes
		size_t	count = m_children.GetCount();
		for ( size_t i=0; i<count; i++ )
		{
			MyRightTreeModelNode*	Child = m_children[i];
			delete Child;
		}
    }

    // override sorting to always sort branches ascendingly
    int Compare( const wxDataViewItem &item1, const wxDataViewItem &item2, unsigned int column, bool ascending ) const;

    // implementation of base class virtuals to define model
    virtual unsigned int GetColumnCount() const { return 2; }
    virtual wxString GetColumnType( unsigned int WXUNUSED(col) ) const { return wxT("string"); }
	virtual bool HasContainerColumns(const wxDataViewItem& WXUNUSED(item)) const { return true; };

    virtual void GetValue( wxVariant &variant, const wxDataViewItem &item, unsigned int col ) const;
    virtual bool SetValue( const wxVariant &variant, const wxDataViewItem &item, unsigned int col );

    virtual wxDataViewItem GetParent( const wxDataViewItem &item ) const;
    virtual bool IsContainer( const wxDataViewItem &item ) const;
    virtual unsigned int GetChildren( const wxDataViewItem &parent, wxDataViewItemArray &array ) const;

    MyRightTreeModelNodePtrArray   m_children;
};

MyRightTreeModel::MyRightTreeModel()
{
    // setup global
    MyRightTreeModelNode*	pNode;
    MyRightTreeModelNode*	pSubNode;

	pNode = new MyRightTreeModelNode( NULL, "A", "A", false );
	m_children.Add(pNode);
	ItemAdded(NULL, pNode);
    pNode = new MyRightTreeModelNode( NULL, "B", "", false );
	m_children.Add(pNode);
	ItemAdded(NULL, pNode);
    pNode = new MyRightTreeModelNode( NULL, "C", "", false );
	m_children.Add(pNode);
	ItemAdded(NULL, pNode);

	pNode = new MyRightTreeModelNode( NULL, "D", "", true );
	m_children.Add(pNode);
	ItemAdded(NULL, pNode);
    pNode->Append( pSubNode = new MyRightTreeModelNode( pNode , "D1", "d1", false ) );
	ItemAdded(pNode, pSubNode);
    pNode->Append( pSubNode = new MyRightTreeModelNode( pNode , "D2", "d2", false ) );
	ItemAdded(pNode, pSubNode);

	pNode = new MyRightTreeModelNode( NULL, "E", "E", true );
	m_children.Add(pNode);
	ItemAdded(NULL, pNode);
    pNode->Append( pSubNode = new MyRightTreeModelNode( pNode , "E1", "e1", false ) );
	ItemAdded(pNode, pSubNode);
    pNode->Append( pSubNode = new MyRightTreeModelNode( pNode , "E2", "", false ) );
	ItemAdded(pNode, pSubNode);
    pNode->Append( pSubNode = new MyRightTreeModelNode( pNode , "E3", "e3", false ) );
	ItemAdded(pNode, pSubNode);

	pNode = new MyRightTreeModelNode( NULL, "F", "f", true );
	m_children.Add(pNode);
	ItemAdded(NULL, pNode);
    pNode->Append( pSubNode = new MyRightTreeModelNode( pNode , "G1", "g1", false ) );
	ItemAdded(pNode, pSubNode);

	pNode = new MyRightTreeModelNode( NULL, "H", "h", true );
	m_children.Add(pNode);
	ItemAdded(NULL, pNode);
    pNode->Append( pSubNode = new MyRightTreeModelNode( pNode , "H1", "h1", false ) );
	ItemAdded(pNode, pSubNode);
}

int MyRightTreeModel::Compare( const wxDataViewItem &item1, const wxDataViewItem &item2,
                              unsigned int column, bool ascending ) const
{
    wxASSERT(item1.IsOk() && item2.IsOk());
        // should never happen

    if (IsContainer(item1) && IsContainer(item2))
    {
        wxVariant value1, value2;
        GetValue( value1, item1, 0 );
        GetValue( value2, item2, 0 );

        wxString str1 = value1.GetString();
        wxString str2 = value2.GetString();
        int res = str1.Cmp( str2 );
        if (res) return res;
    }

    return wxDataViewModel::Compare( item1, item2, column, ascending );
}

void MyRightTreeModel::GetValue( wxVariant &variant,
                                const wxDataViewItem &item, unsigned int col ) const
{
    wxASSERT(item.IsOk());

    MyRightTreeModelNode *node = (MyRightTreeModelNode*) item.GetID();
    switch (col)
    {
    case 0:
        variant = node->m_title;
        break;
    case 1:
        variant = node->m_value;
        break;
    }
}

bool MyRightTreeModel::SetValue( const wxVariant &variant,
                                const wxDataViewItem &item, unsigned int col )
{
    wxASSERT(item.IsOk());

    MyRightTreeModelNode *node = (MyRightTreeModelNode*) item.GetID();
    switch (col)
    {
        case 0:
            node->m_title = variant.GetString();
            return true;
        case 1:
            node->m_value = variant.GetString();
            return true;
    }
    return false;
}

wxDataViewItem MyRightTreeModel::GetParent( const wxDataViewItem &item ) const
{
    // the invisible root node has no parent
    if (!item.IsOk())
        return wxDataViewItem(0);

    MyRightTreeModelNode *node = (MyRightTreeModelNode*) item.GetID();

    // "root" also has no parent
    if (node == NULL)
        return wxDataViewItem(0);

    return wxDataViewItem( (void*) node->GetParent() );
}

bool MyRightTreeModel::IsContainer( const wxDataViewItem &item ) const
{
    // the invisble root node can have children
    // (in our model always "root")
    if (!item.IsOk())
        return true;

    MyRightTreeModelNode *node = (MyRightTreeModelNode*) item.GetID();
    return node->IsContainer();
}

unsigned int MyRightTreeModel::GetChildren( const wxDataViewItem &parent,
                                           wxDataViewItemArray &array ) const
{
    MyRightTreeModelNode *node = (MyRightTreeModelNode*) parent.GetID();
    if ( node == NULL )
    {
		unsigned int count = m_children.GetCount();
		for (unsigned int pos = 0; pos < count; pos++)
		{
			MyRightTreeModelNode *child = m_children.Item( pos );
			array.Add( wxDataViewItem( (void*) child ) );
		}
		return count;
    }

    if (node->GetChildCount() == 0)
    {
        return 0;
    }

    unsigned int count = node->GetChildren().GetCount();
    for (unsigned int pos = 0; pos < count; pos++)
    {
        MyRightTreeModelNode *child = node->GetChildren().Item( pos );
        array.Add( wxDataViewItem( (void*) child ) );
    }
    return count;
}

// ----------------------------------------------------------------------------

class MyApp: public wxApp
{
public:
    MyApp() { }

    virtual bool OnInit();

    wxDECLARE_NO_COPY_CLASS(MyApp);
};

class MySplitterWindow;

class MyFrame: public wxFrame
{
public:
    MyFrame();
	virtual ~MyFrame() {};

    // Menu commands
    void OnQuit(wxCommandEvent& WXUNUSED(event)) { Close(true); };

    MySplitterWindow*					m_splitter;

    wxDataViewCtrl*						m_left;
	wxObjectDataPtr<MyLeftTreeModel>	m_left_model;
	wxDataViewCtrl*						m_right;
	wxObjectDataPtr<MyRightTreeModel>	m_right_model;

private:
    DECLARE_EVENT_TABLE()
    wxDECLARE_NO_COPY_CLASS(MyFrame);
};

class MySplitterWindow : public wxSplitterWindow
{
public:
    MySplitterWindow(wxFrame *parent);

	// DnD
    void OnBeginDragLeft( wxDataViewEvent &event );
#if defined _USE_DND_DVC_
    void OnDropPossibleLeftDVC( wxDataViewEvent &event );
    void OnDroppedLeftDVC( wxDataViewEvent &event );
#elif defined _USE_DND_STD_
	wxDragResult OnDropPossibleLeftSTD(wxCoord x, wxCoord y, wxDragResult def);
	bool OnDroppedLeftSTD(wxCoord x, wxCoord y, const wxString& strSource);
#endif

	void OnBeginDragRight( wxDataViewEvent &event );
#if defined _USE_DND_DVC_
    void OnDropPossibleRightDVC( wxDataViewEvent &event );
    void OnDroppedRightDVC( wxDataViewEvent &event );
#elif defined _USE_DND_STD_
	wxDragResult OnDropPossibleRightSTD(wxCoord x, wxCoord y, wxDragResult def);
	bool OnDroppedRightSTD(wxCoord x, wxCoord y, const wxString& strSource);
#endif

private:
    wxFrame*							m_frame;

	wxString							m_strDragSource;
	int									m_nTests;
#if defined _USE_DND_STD_
	wxDragResult						m_nDragResultLast;
#endif

    DECLARE_EVENT_TABLE()
    wxDECLARE_NO_COPY_CLASS(MySplitterWindow);
};

#if defined _USE_DND_STD_

class TextDropTargetLeft : public wxTextDropTarget
{
public:
	//! ctor
	TextDropTargetLeft(MySplitterWindow* pSplitterWnd) { m_pSplitterWnd = pSplitterWnd; };

	//! override OnDragOver
	virtual wxDragResult OnDragOver(wxCoord x, wxCoord y, wxDragResult def) { return m_pSplitterWnd->OnDropPossibleLeftSTD(x, y, def); };

	//! override OnDrop
	virtual bool OnDropText(wxCoord x, wxCoord y, const wxString& strSource) { return m_pSplitterWnd->OnDroppedLeftSTD(x, y, strSource); };

private:
	MySplitterWindow*	m_pSplitterWnd;
};

class TextDropTargetRight : public wxTextDropTarget
{
public:
	//! ctor
	TextDropTargetRight(MySplitterWindow* pSplitterWnd) { m_pSplitterWnd = pSplitterWnd; };

	//! override OnDragOver
	virtual wxDragResult OnDragOver(wxCoord x, wxCoord y, wxDragResult def) { return m_pSplitterWnd->OnDropPossibleRightSTD(x, y, def); };

	//! override OnDrop
	virtual bool OnDropText(wxCoord x, wxCoord y, const wxString& strSource) { return m_pSplitterWnd->OnDroppedRightSTD(x, y, strSource); };

private:
	MySplitterWindow*	m_pSplitterWnd;
};

#endif // _USE_DND_STD_

// ----------------------------------------------------------------------------
// MyApp

IMPLEMENT_APP(MyApp)

bool MyApp::OnInit()
{
    if ( !wxApp::OnInit() )
        return false;

    // create and show the main frame
    MyFrame* frame = new MyFrame;
    frame->Show(true);
    return true;
}

// ----------------------------------------------------------------------------
// MyFrame

BEGIN_EVENT_TABLE(MyFrame, wxFrame)
    EVT_MENU(SPLIT_QUIT, MyFrame::OnQuit)
END_EVENT_TABLE()

// My frame constructor
MyFrame::MyFrame()
       : wxFrame(NULL, wxID_ANY, wxT("wxSplitterWindow sample"),
                 wxDefaultPosition, wxSize(420, 300),
                 wxDEFAULT_FRAME_STYLE | wxNO_FULL_REPAINT_ON_RESIZE)
{
    SetIcon(wxICON(sample));

    // Make a menubar
    wxMenu *splitMenu = new wxMenu;
    splitMenu->Append(SPLIT_QUIT, wxT("E&xit\tAlt-X"), wxT("Exit"));
    wxMenuBar *menuBar = new wxMenuBar;
    menuBar->Append(splitMenu, wxT("&File"));
    SetMenuBar(menuBar);

    m_splitter = new MySplitterWindow(this);
    m_splitter->SetSashGravity(1.0);

	wxDataViewTextRenderer *tr;
	wxDataViewColumn *column0, *column1;
    m_left = new wxDataViewCtrl( m_splitter, ID_LEFT_CTRL, wxDefaultPosition,
                                 wxDefaultSize, wxDV_HORIZ_RULES );
    m_left_model = new MyLeftTreeModel;
	m_left->AssociateModel( m_left_model.get() );
#if defined _USE_DND_DVC_
	m_left->EnableDragSource( wxDF_UNICODETEXT );	// prepare for dragging
	m_left->EnableDropTarget( wxDF_UNICODETEXT );
#elif defined _USE_DND_STD_
	m_left->EnableDragSource( wxDF_UNICODETEXT );	// prepare for dragging, not required
	m_left->GetMainWindow()->SetDropTarget(new TextDropTargetLeft(m_splitter));	// prepare for dropping
#endif
    // column 0 of the view control:
    tr = new wxDataViewTextRenderer( "string", wxDATAVIEW_CELL_INERT );
    column0 = new wxDataViewColumn( "LEFT", tr, 0, 200, wxALIGN_LEFT,
                                    wxDATAVIEW_COL_SORTABLE | wxDATAVIEW_COL_RESIZABLE );
    m_left->AppendColumn( column0 );

    m_right = new wxDataViewCtrl( m_splitter, ID_RIGHT_CTRL, wxDefaultPosition,
                                  wxDefaultSize, wxDV_HORIZ_RULES );
    m_right_model = new MyRightTreeModel;
    m_right->AssociateModel( m_right_model.get() );
#if defined _USE_DND_DVC_
	m_right->EnableDragSource( wxDF_UNICODETEXT );	// prepare for dragging
	m_right->EnableDropTarget( wxDF_UNICODETEXT );
#elif defined _USE_DND_STD_
	m_right->EnableDragSource( wxDF_UNICODETEXT );	// prepare for dragging, not required
	m_right->GetMainWindow()->SetDropTarget(new TextDropTargetRight(m_splitter));	// prepare for dropping
#endif
    // column 0 of the view control:
    tr = new wxDataViewTextRenderer( "string", wxDATAVIEW_CELL_INERT );
    column0 = new wxDataViewColumn( "RIGHT entries", tr, 0, 200, wxALIGN_LEFT, wxDATAVIEW_COL_RESIZABLE );
    m_right->AppendColumn( column0 );
    // column 1 of the view control:
    tr = new wxDataViewTextRenderer( "string", wxDATAVIEW_CELL_EDITABLE );
    column1 = new wxDataViewColumn( "values", tr, 1, 200, wxALIGN_LEFT, wxDATAVIEW_COL_RESIZABLE );
    m_right->AppendColumn( column1 );

    m_splitter->SplitVertically(m_left, m_right, 100);
}

// ----------------------------------------------------------------------------
// MySplitterWindow

BEGIN_EVENT_TABLE(MySplitterWindow, wxSplitterWindow)

    EVT_DATAVIEW_ITEM_BEGIN_DRAG( ID_LEFT_CTRL, MySplitterWindow::OnBeginDragLeft )
#if defined _USE_DND_DVC_
    EVT_DATAVIEW_ITEM_DROP_POSSIBLE( ID_LEFT_CTRL, MySplitterWindow::OnDropPossibleLeftDVC )
    EVT_DATAVIEW_ITEM_DROP( ID_LEFT_CTRL, MySplitterWindow::OnDroppedLeftDVC )
#endif // _USE_DND_DVC_

    EVT_DATAVIEW_ITEM_BEGIN_DRAG( ID_RIGHT_CTRL, MySplitterWindow::OnBeginDragRight )
#if defined _USE_DND_DVC_
    EVT_DATAVIEW_ITEM_DROP_POSSIBLE( ID_RIGHT_CTRL, MySplitterWindow::OnDropPossibleRightDVC )
    EVT_DATAVIEW_ITEM_DROP( ID_RIGHT_CTRL, MySplitterWindow::OnDroppedRightDVC )
#endif // _USE_DND_DVC_

END_EVENT_TABLE()

MySplitterWindow::MySplitterWindow(wxFrame *parent)
                : wxSplitterWindow(parent, wxID_ANY,
                                   wxDefaultPosition, wxDefaultSize,
                                   wxSP_3D | wxSP_LIVE_UPDATE |
                                   wxCLIP_CHILDREN /* | wxSP_NO_XP_THEME */ )
{
    m_frame = parent;
	m_nTests = 0;
}

void MySplitterWindow::OnBeginDragLeft( wxDataViewEvent &event )
{
    wxDataViewItem item( event.GetItem() );
	if ( item == wxDataViewItem(0) )
	{
        event.Veto();
        return;
	}

	m_nTests = 0;
    MyLeftTreeModelNode*	node = (MyLeftTreeModelNode*)item.GetID();
	m_strDragSource = node->m_title;
#if defined _USE_DND_DVC_
	wxTextDataObject*		obj = new wxTextDataObject;
    obj->SetText( m_strDragSource );
    event.SetDataObject( obj );
    event.SetDragFlags(wxDrag_AllowMove); // allows both copy and move
#elif defined _USE_DND_STD_
	event.Veto();				// veto, we ride our own horse
	wxTextDataObject	MyLeftData(m_strDragSource);
	wxDropSource		MyLeftDragSource(this);
	MyLeftDragSource.SetData(MyLeftData);
	wxDragResult		result = MyLeftDragSource.DoDragDrop(wxDrag_AllowMove);
	switch ( result )
	{
	case wxDragCopy:
		break;			// copy the data
	case wxDragMove:
		break;			// move the data
	case wxDragLink:
		break;			// link the data
	default:
		break;			// do nothing
	}
#endif
}

#if defined _USE_DND_DVC_

void MySplitterWindow::OnDropPossibleLeftDVC( wxDataViewEvent &event )
{
	++m_nTests;
    wxDataViewItem item( event.GetItem() );
	if ( item == wxDataViewItem(0) )
	{
        event.Veto();
        return;
	}
    if (event.GetDataFormat() != wxDF_UNICODETEXT)
	{
        event.Veto();
        return;
	}
}

void MySplitterWindow::OnDroppedLeftDVC( wxDataViewEvent &event )
{
    wxDataViewItem item( event.GetItem() );
	if ( item == wxDataViewItem(0) )
	{
        event.Veto();
        return;
	}
    if (event.GetDataFormat() != wxDF_UNICODETEXT)
	{
        event.Veto();
        return;
	}

	wxDataViewItem			item2;
	wxDataViewColumn*		pColumn;
	wxPoint					pt = event.GetPosition();
	((MyFrame*)m_frame)->m_left->HitTest(pt, item2, pColumn);	// check item == item2

    MyLeftTreeModelNode*	node = (MyLeftTreeModelNode*)item.GetID();
	wxString				s;
	s.Printf("DVC\n%s\n%d\n%s\n", node->m_title, m_nTests, ( event.GetDropEffect() == wxDragMove ) ? "move" : "copy");
	if ( item2.GetID() != item.GetID() )
	{
	    MyLeftTreeModelNode*	node2 = (MyLeftTreeModelNode*)item2.GetID();
		s += wxString::Format("items %s!=%s\n", node->m_title, node2->m_title);
	}
	wxMessageBox(s, "result");
}

#elif defined _USE_DND_STD_

wxDragResult MySplitterWindow::OnDropPossibleLeftSTD(wxCoord x, wxCoord y, wxDragResult def)
{
	++m_nTests;
	wxDataViewItem		item;
	wxDataViewColumn*	pColumn;
	wxPoint				pt(x, y);
	((MyFrame*)m_frame)->m_left->HitTest(pt, item, pColumn);			// analyse
	if ( pColumn == NULL )
	{
		m_nDragResultLast = wxDragNone;
		return wxDragNone;
	}
	if ( ! item.IsOk() )
	{
		m_nDragResultLast = wxDragNone;
		return wxDragNone;
	}
	m_nDragResultLast = def;
	return m_nDragResultLast;
}

bool MySplitterWindow::OnDroppedLeftSTD(wxCoord x, wxCoord y, const wxString& strSource)
{
	wxDataViewItem		item;
	wxDataViewColumn*	pColumn;
	wxPoint				pt(x, y);
	((MyFrame*)m_frame)->m_left->HitTest(pt, item, pColumn);			// analyse
	if ( pColumn == NULL )
	{
		return false;
	}
	if ( ! item.IsOk() )
	{
		return false;
	}

    MyLeftTreeModelNode*	node = (MyLeftTreeModelNode*)item.GetID();
	wxString				s;
	s.Printf("STD\n%s\n%s\n%d\n%s\n", strSource, node->m_title, m_nTests, ( m_nDragResultLast == wxDragMove ) ? "move" : "copy");
	wxMessageBox(s, "result");
	return true;
}

#endif

void MySplitterWindow::OnBeginDragRight( wxDataViewEvent &event )
{
    wxDataViewItem item( event.GetItem() );
	if ( item == wxDataViewItem(0) )
	{
        event.Veto();
        return;
	}

	m_nTests = 0;
    MyRightTreeModelNode *node = (MyRightTreeModelNode*)item.GetID();
	m_strDragSource = node->m_title + " - " + node->m_value;
#if defined _USE_DND_DVC_
	wxTextDataObject *obj = new wxTextDataObject;
	obj->SetText( m_strDragSource );
    event.SetDataObject( obj );
    event.SetDragFlags(wxDrag_AllowMove); // allows both copy and move
#elif defined _USE_DND_STD_
	event.Veto();				// veto, we ride our own horse
	wxTextDataObject	MyRightData(m_strDragSource);
	wxDropSource		MyRightDragSource(this);
	MyRightDragSource.SetData(MyRightData);
	wxDragResult		result = MyRightDragSource.DoDragDrop(wxDrag_AllowMove);
	switch ( result )
	{
	case wxDragCopy:
		break;			// copy the data
	case wxDragMove:
		break;			// move the data
	case wxDragLink:
		break;			// link the data
	default:
		break;			// do nothing
	}
#endif
}

#if defined _USE_DND_DVC_

void MySplitterWindow::OnDropPossibleRightDVC( wxDataViewEvent &event )
{
	++m_nTests;
    wxDataViewItem item( event.GetItem() );
	if ( item == wxDataViewItem(0) )
	{
        event.Veto();
        return;
	}
    if (event.GetDataFormat() != wxDF_UNICODETEXT)
	{
        event.Veto();
		return;
	}
}

void MySplitterWindow::OnDroppedRightDVC( wxDataViewEvent &event )
{
    wxDataViewItem item( event.GetItem() );
	if ( item == wxDataViewItem(0) )
	{
        event.Veto();
        return;
	}
    if (event.GetDataFormat() != wxDF_UNICODETEXT)
	{
        event.Veto();
        return;
	}

	wxDataViewItem			item2;
	wxDataViewColumn*		pColumn;
	wxPoint					pt = event.GetPosition();
	((MyFrame*)m_frame)->m_right->HitTest(pt, item2, pColumn);	// check item == item2

    MyRightTreeModelNode*	node = (MyRightTreeModelNode*)item.GetID();
	wxString				s;
	s.Printf("DVC\n%s\n%d\n%s\n", node->m_title, m_nTests, ( event.GetDropEffect() == wxDragMove ) ? "move" : "copy");
	if ( item2.GetID() != item.GetID() )
	{
	    MyRightTreeModelNode*	node2 = (MyRightTreeModelNode*)item2.GetID();
		s += wxString::Format("items %s!=%s\n", node->m_title, node2->m_title);
	}
	wxMessageBox(s, "result");
}

#elif defined _USE_DND_STD_

wxDragResult MySplitterWindow::OnDropPossibleRightSTD(wxCoord x, wxCoord y, wxDragResult def)
{
	++m_nTests;
	wxDataViewItem		item;
	wxDataViewColumn*	pColumn;
	wxPoint				pt(x, y);
	((MyFrame*)m_frame)->m_right->HitTest(pt, item, pColumn);	// analyse
	if ( pColumn == NULL )
	{
		m_nDragResultLast = wxDragNone;
		return wxDragNone;
	}
	if ( ! item.IsOk() )
	{
		m_nDragResultLast = wxDragNone;
		return wxDragNone;
	}
	m_nDragResultLast = def;
	return m_nDragResultLast;
}

bool MySplitterWindow::OnDroppedRightSTD(wxCoord x, wxCoord y, const wxString& strSource)
{
	wxDataViewItem		item;
	wxDataViewColumn*	pColumn;
	wxPoint				pt(x, y);
	((MyFrame*)m_frame)->m_right->HitTest(pt, item, pColumn);			// analyse
	if ( pColumn == NULL )
	{
		return false;
	}
	if ( ! item.IsOk() )
	{
		return false;
	}

    MyRightTreeModelNode*	node = (MyRightTreeModelNode*)item.GetID();
	wxString				s;
	s.Printf("STD\n%s\n%s\n%d\n%s\n", strSource, node->m_title, m_nTests, ( m_nDragResultLast == wxDragMove ) ? "move" : "copy");
	wxMessageBox(s, "result");
	return true;
}

#endif
