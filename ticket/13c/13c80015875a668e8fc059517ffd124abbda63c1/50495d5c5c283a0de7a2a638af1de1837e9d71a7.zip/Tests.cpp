

// For compilers that support precompilation, includes "wx/wx.h".
#include "wx/wxprec.h"

#ifdef __BORLANDC__
    #pragma hdrstop
#endif

// for all others, include the necessary headers
#ifndef WX_PRECOMP
    #include "wx/wx.h"
#endif
#pragma warning ( disable : 4018 )

#include "wx/cmdline.h"

enum Menu_IDs
{
    ID_TEXTOUT = 10,
};

// ----------------------------------------------------------------------------
// TestsApp - the application class
// ----------------------------------------------------------------------------
class TestsApp : public wxApp
{
public:
    TestsApp() : wxApp(), m_frame(NULL) {}
    virtual bool OnInit();
    virtual int OnExit();

    wxFrame* m_frame;
};

IMPLEMENT_APP(TestsApp)

// ----------------------------------------------------------------------------
// TestsFrame - the application frame
// ----------------------------------------------------------------------------
class TestsFrame : public wxFrame
{
public:
    TestsFrame();
    ~TestsFrame();

    void OnTextOut(wxCommandEvent& event);

private:
    DECLARE_EVENT_TABLE()
};

// ----------------------------------------------------------------------------
// TestsApp - the application class
// ----------------------------------------------------------------------------

bool TestsApp::OnInit()
{
    wxFrame *frame = new TestsFrame();
    frame->Show(true);

    return true;
}

int TestsApp::OnExit()
{
    return wxApp::OnExit();
}

// ----------------------------------------------------------------------------
// TestsFrame - the application frame
// ----------------------------------------------------------------------------
BEGIN_EVENT_TABLE(TestsFrame, wxFrame)
    EVT_MENU                        (ID_TEXTOUT, TestsFrame::OnTextOut)
END_EVENT_TABLE()

TestsFrame::TestsFrame() : wxFrame()
{
    if (!wxFrame::Create(NULL, wxID_ANY, wxT("Tests"),
                         wxDefaultPosition, wxSize(600, 400)))
        return;

    wxStatusBar* statusBar = CreateStatusBar(1);
    SetStatusBar(statusBar);

    // create a menu bar
    wxMenu *fileMenu = new wxMenu;
    fileMenu->Append(ID_TEXTOUT, _T("&TextOut"), _T("TextOut"));
    // now append the freshly created menu to the menu bar...
    wxMenuBar *menuBar = new wxMenuBar();
    menuBar->Append(fileMenu, _T("&Tests"));

    // ... and attach this menu bar to the frame
    SetMenuBar(menuBar);

	wxBoxSizer *mainv = new wxBoxSizer(wxVERTICAL);
	SetSizer(mainv);

}

TestsFrame::~TestsFrame()
{
}

void TestsFrame::OnTextOut(wxCommandEvent& event)
{
	wxClientDC dc(this);
	wxFont fnt = dc.GetFont();
	fnt.SetUnderlined(true);
	dc.SetFont(fnt);
	dc.DrawText("The text", 100, 100);
}

