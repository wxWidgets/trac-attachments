from wxPython import wx

class MyApp(wx.wxApp):

    def OnInit(self):
        frame = wx.wxFrame(None, -1, "transparency bug", size=(200, 150))
        panel = wx.wxPanel(frame, -1)
        frame.Show(1)
        self.SetTopWindow(frame)

        wx.wxInitAllImageHandlers()

        # comment these lines to see the panel without a background image
        self.tileBmp = wx.wxBitmap('background.jpg', wx.wxBITMAP_TYPE_JPEG)
        wx.EVT_ERASE_BACKGROUND(panel, self.OnEraseBackground)
        
        panel.SetBackgroundColour(wx.wxNamedColour('green'))

        #s = 0
        s = wx.wxCLIP_SIBLINGS
        
        editBmp = wx.wxBitmap('edit.gif', wx.wxBITMAP_TYPE_GIF)
        edit = wx.wxStaticBitmap(panel, -1, editBmp, (15, 30), wx.wxDefaultSize, style=s)
        editBtn = wx.wxBitmapButton(panel, -1, editBmp, (15, 70), wx.wxDefaultSize, style=s)
        trashBmp = wx.wxBitmap('trash.gif', wx.wxBITMAP_TYPE_GIF)
        trash = wx.wxStaticBitmap(panel, -1, trashBmp, (100, 30), wx.wxDefaultSize, style=s)
        trashBtn = wx.wxBitmapButton(panel, -1, trashBmp, (100, 70), wx.wxDefaultSize, style=s)

        text1 = wx.wxTextCtrl(panel, -1, pos=(5, 40), size=(130, 40), style=s)

        # binding event erase background never has no effect
        # on Windows with wxStaticBitmap, but it does for wxBitmapButton
        # uncomment these lines to get the trans4.png test image
        wx.EVT_ERASE_BACKGROUND(edit, lambda evt: None)
        wx.EVT_ERASE_BACKGROUND(trash, lambda evt: None)
        wx.EVT_ERASE_BACKGROUND(editBtn, lambda evt: None)
        wx.EVT_ERASE_BACKGROUND(trashBtn, lambda evt: None)

        # on Windows 2000 at least, the panel color won't be changed until
        # the window is minimized/restored or resized
        # if the panel has EVT_ERASE_BACKGROUND bound then
        # you won't see the blue, but the green will still
        # show up as part of the wxStaticBitmap and wxBitmapButton controls
        panel.SetBackgroundColour(wx.wxNamedColour('blue'))
        
        return 1

    def OnEraseBackground(self, event):
        deviceContext = event.GetDC()
        if not deviceContext :
            deviceContext = wx.wxClientDC(self)
            r = self.GetUpdateRegion().GetBox()
            deviceContext.SetClippingRegion(r.x, r.y, r.width, r.height)
            print "OnEraseBackground no device context", r
        else:
            print "OnEraseBackground", deviceContext.GetSize()
        deviceContext.DrawBitmap(self.tileBmp, 0, 0)

app = MyApp(0)
app.MainLoop()
