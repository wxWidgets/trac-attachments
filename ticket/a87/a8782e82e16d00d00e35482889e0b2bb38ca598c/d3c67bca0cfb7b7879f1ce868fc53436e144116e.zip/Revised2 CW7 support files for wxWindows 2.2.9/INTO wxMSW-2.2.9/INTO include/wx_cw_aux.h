#define NEED_STRDUP
#define WINVER 0x0400
#include <ansi_prefix.win32.h>

