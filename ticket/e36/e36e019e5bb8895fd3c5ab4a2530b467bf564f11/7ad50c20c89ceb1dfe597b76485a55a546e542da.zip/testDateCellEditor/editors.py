import debug
import wx
from DateControl import *


class ControlCellEditor(wx.grid.PyGridCellEditor):
	"""
	This is a sample GridCellEditor that shows you how to make your own custom
	grid editors.  All the methods that can be overridden are show here.  The
	ones that must be overridden are marked with "*Must Override*" in the
	docstring.

	Notice that in order to call the base class version of these special
	methods we use the method name preceded by "base_".  This is because these
	methods are "virtual" in C++ so if we try to call wx.grid.GridCellEditor.Create
	for example, then when the wx-Python extension module tries to call
	ptr->Create(...) then it actually calls the derived class version which
	looks up the method in this class and calls it, causing a recursion loop.
	If you don't understand any of this, don't worry, just call the "base_"
	version instead.
	"""
	def __init__(self):
		wx.grid.PyGridCellEditor.__init__(self)
		self._startValue = None
		self._editStarted = 0

	def getValueAsText(self, grid, row, col):
		return str(grid.GetTable().GetValue(row, col))

	def setValueAsText(self, grid, row, col, value):
		grid.GetTable().SetValue(row, col, value)

	def createControl(self, parent, id):
		raise "abstract"

	def startEdit(self, grid, row, col):
		"""
		Prepare control to edit. do not set focus.
		returns start value.
		it will be
			control.SetValue(start value) in case of Reset by default
		"""
		raise "abstract. Returns start control value"
	
	def stopEdit(self, grid, row, col):
		raise "abstract"

	def getControl(self):
		return self._control

	def getStartValue(self):
		return self._startValue

	def prepareControl(self, value):
		pass

	def releaseControl(self):
		pass
		
	def Create(self, parent, id, evtHandler):
		"""
		Called to create the control, which must derive from wxControl.
		*Must Override*
		"""
		debug.trace("Create")
		self._control = self.createControl(parent, id)
		self.SetControl(self._control)
		self._control.PushEventHandler(evtHandler)
		self._startValue = None

	def SetSize(self, rect):
		"""
		Called to position/size the edit control within the cell rectangle.
		If you don't fill the cell (the rect) then be sure to override
		PaintBackground and do something meaningful there.
		"""
		debug.trace("SetSize(%s)"%(rect,))
		self.getControl().SetDimensions(rect.x, rect.y, rect.width+2, rect.height+2, wx.SIZE_ALLOW_MINUS_ONE)

	def IsAcceptedKey(self, evt):
		"""
		Return True to allow the given key to start editing: the base class
		version only checks that the event has no modifiers.  F2 is special
		and will always start the editor.
		"""
		debug.trace("IsAcceptedKey: %d" % (evt.GetKeyCode()))
		## Oops, there's a bug here, we'll have to do it ourself..
		return (    not evt.ControlDown()
				and not evt.AltDown()
				and	evt.GetKeyCode() != wx.WXK_SHIFT
		)

	def Clone(self):
		"""
		Create a new object which is the copy of this one
		*Must Override*
		"""
		# TODO: initargs here (like pickle)
		return self.__class__()

	def BeginEdit(self, row, col, grid):
		"""
		Fetch the value from the table and prepare the edit control
		to begin editing.  Set the focus to the edit control.
		*Must Override*
		"""
		debug.trace("BeginEdit (%d,%d)" % (row, col))
		if not self._editStarted:
			self._editStarted = 1
			self._startValue = self.startEdit(grid, row, col)
			self.prepareControl(self._startValue)
			self.getControl().SetFocus()
		else:
			debug.warning("superfluous startEdit skipped")
			pass

	def EndEdit(self, row, col, grid):
		"""
		Complete the editing of the current cell. Returns True if the value
		has changed.  If necessary, the control may be destroyed.
		*Must Override*
		"""
		debug.trace("EndEdit (%d,%d)\n" % (row, col))
		try:
			if self._editStarted:	# wx bug(?) fix (two finishes)
				self._editStarted = 0
				try:
					return self.stopEdit(grid, row, col)
				except ValueError, e:
					wxutils.messageBox(self.getControl(), e[0], "Error", wx.ICON_HAND)
			else:
				debug.warning("superfluous stopEdit skipped")
				pass
		finally:
			self.releaseControl()

	def Reset(self):
		"""
		Reset the value in the control back to its starting value.
		*Must Override*
		"""
		debug.trace("Reset")
		self._control.SetValue(self._startValue)

	def Destroy(self):
		#Does not goes, this is a wx-Python bug!
		print "Destroy called! Bug is fixed!"
		self.base_Destroy()


class TextCellEditor(ControlCellEditor):
	def __init__(self, style = 0):
		ControlCellEditor.__init__(self)
		self._style = style

	def StartingKey(self, evt):
		"""
		If the editor is enabled by pressing keys on the grid, this will be
		called to let the editor do something about that first key if desired.
		"""
		if not self.getControl().EmulateKeyPress(evt):
			evt.Skip()

	def createControl(self, parent, id):
		return wx.TextCtrl(parent, id, style=self._style)

	def startEdit(self, grid, row, col):
		return self.getValueAsText(grid, row, col)
	
	def stopEdit(self, grid, row, col):
		"""
		get control value and set to grid
		"""
		value = self.getControl().GetValue()
		if value != self.getStartValue():
			self.setValueAsText(grid, row, col, value)
			return True
		return False

	def prepareControl(self, value):
		c = self.getControl()
		c.SetValue(value)
		c.SetInsertionPointEnd()
		c.SetSelection(0, c.GetLastPosition())

	def releaseControl(self):
		self.getControl().SetValue("")

class DateCellEditor(TextCellEditor):
	def __init__(self, format=DEFAULT_DATE_FORMAT):
		ControlCellEditor.__init__(self)
		self._format = format

	#def pushEventHandler(self, evtHandler):
		#pass
		#self.getControl().getTextControl().PushEventHandler(evtHandler)

	def createControl(self, parent, id):
		c = DateControl(parent, id)
		c.setFormat(self._format)
		return c

	def startEdit(self, grid, row, col):
		value = self.getValueAsText(grid, row, col)
		#self.getControl().SetValue(value)
		return value
	
	def stopEdit(self, grid, row, col):
		"""
		get control value and set to grid
		"""
		value = self.getControl().GetValue()
		if value != self.getStartValue():
			self.setValueAsText(grid, row, col, value)
			return True
		return False

	def releaseControl(self):
		self.getControl().SetValue("")

	def Reset(self):
		pass
