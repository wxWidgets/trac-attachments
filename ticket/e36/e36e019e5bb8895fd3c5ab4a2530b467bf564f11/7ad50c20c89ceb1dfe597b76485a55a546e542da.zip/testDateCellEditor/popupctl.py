###############################################################################
#
'''
wrapper about missfeatured PopupControl
'''
__author__  = "Oleg Noga"
__date__	= "$Date: 2005/08/12 14:53:19 $"
__version__ = "$Revision: 1.2 $"
# $Source: \\\\BOLIVAR\\CVSROOT/toolib/wx/controls/popupctl.py,v $
###############################################################################

import  wx
import  wx.lib.popupctl as original

class PopButton(original.PopButton):

	def DrawArrow(self,dc):
		"""
		arrow position adjusted: -2, -2
		"""
		w, h = self.GetSize()
		mx = w / 2 - 2
		my = h / 2 - 2
		dc.SetPen(self.highlightPen)
		dc.DrawLine(mx-5,my-5, mx+5,my-5)
		dc.DrawLine(mx-5,my-5, mx,my+5)
		dc.SetPen(self.shadowPen)
		dc.DrawLine(mx+4,my-5, mx,my+5)
		dc.SetPen(self.blackPen)
		dc.DrawLine(mx+5,my-5, mx,my+5)


class PopupControl(original.PopupControl):

	def __init__(self, *args, **kwargs):
		"""
		textCtrl looks better with STATIC_BORDER

		Next methods added to delegate control to textControl.
		This allows control to work as Grid Cell Editor

		def EmulateKeyPress(self, evt)
		def SetInsertionPointEnd(self)
		def SetSelection(self, p1, p2)
		def GetLastPosition(self)
		def PushEventHandler(self, handler)
		def PopEventHandler(self, delete)

		This is even not full but minimal set

		"""
		original.PopupControl.__init__(self, *args, **kwargs)
		self.textCtrl.SetWindowStyle(wx.STATIC_BORDER)
		self.bCtrl.__class__ = PopButton
	
	def EmulateKeyPress(self, evt):
		return self.textCtrl.EmulateKeyPress(evt)

	def SetInsertionPointEnd(self):
		return self.textCtrl.SetInsertionPointEnd()

	def SetSelection(self, p1, p2):
		return self.textCtrl.SetSelection(p1, p2)

	def GetLastPosition(self):
		return self.textCtrl.GetLastPosition()

	def PushEventHandler(self, handler):
		self.textCtrl.PushEventHandler(handler)

	def PopEventHandler(self, delete):
		self.textCtrl.PopEventHandler(delete)
