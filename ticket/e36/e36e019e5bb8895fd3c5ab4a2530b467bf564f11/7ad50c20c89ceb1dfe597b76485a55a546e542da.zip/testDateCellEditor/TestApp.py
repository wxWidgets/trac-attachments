import wx

def static():
	import locale
	locale.setlocale(locale.LC_ALL, "")
	
class MainFrame(wx.Frame):
	def __init__(self, *p, **pp):
		self._oninit		= pp.pop('oninit')
		self._ondestroy	= pp.pop('ondestroy')
		wx.Frame.__init__(self, *p, **pp)
		self.Bind(wx.EVT_CLOSE, self.OnClose)
		self._resources=None
		self._oninit(self)

	def OnClose(self, event):
		self._ondestroy(self)
		self.Destroy()

class TestApp(wx.PySimpleApp):

	def __init__(self, oninit=lambda frame: None, ondestroy=lambda frame: None, frameClass=MainFrame):
		self._oninit		= oninit
		self._ondestroy	= ondestroy
		self._frameClass= frameClass
		wx.PySimpleApp.__init__(self)

	def OnInit(self):
		try:
			static()
			del staitc
		except NameError:
			pass

		f = self._frameClass(None, wx.NewId(), "test frame", oninit=self._oninit, ondestroy=self._ondestroy)
		f.Show()
		return True


		

if __name__ == '__main__':
	from TestApp import TestApp
	from dbgenie.Storage import Storage

	def oninit(self):
		pass
		
	def ondestroy(self):
		pass

	TestApp(oninit, ondestroy).MainLoop()
