import mx.DateTime
import wx.grid
from TestApp import TestApp
from editors import DateCellEditor

class Table(wx.grid.PyGridTableBase):
	
	def __init__(self, data=[]):
		wx.grid.PyGridTableBase.__init__(self)
		self._data = data

	def GetNumberRows(self):
		return len(self._data)

	def GetNumberCols(self):
		return len(self._data[0])

	def IsEmptyCell(self, row, col):
		return self._data[row][col] is None

	def GetValue(self, row, col):
		return self._data[row][col]

	def SetValue(self, row, col, value):
		self._data[row][col] = value

	def GetTypeName(self, row, col):
		return "date"

def test():
	def oninit(self):
		self.grid = wx.grid.Grid(self)
		self.grid.SetTable(Table([['', '2005-01-01'], ['2004-02-02', '']]))
		self.grid.RegisterDataType('date', None, DateCellEditor())

		#self.grid.CreateGrid(2,2)
		#self.grid.SetValue(1,1, mx.DateTime.today())
		pass
		
	def ondestroy(self):
		pass

	TestApp(oninit, ondestroy).MainLoop()


if __name__ == '__main__':
	test()