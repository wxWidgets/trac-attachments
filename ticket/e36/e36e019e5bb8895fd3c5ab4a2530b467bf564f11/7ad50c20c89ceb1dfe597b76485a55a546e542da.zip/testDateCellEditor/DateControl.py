"""
TODO: Extract from locale DEFAULT_DATETIME_FORMAT and DEFAULT_DATE_FORMAT 
"""
import wx
import wx.calendar

from popupctl import PopupControl

import mx.DateTime

DEFAULT_DATE_FORMAT = "%Y-%m-%d"
DEFAULT_DATETIME_FORMAT = '%Y-%m-%d %H:%M:%S'

__all__ = ['DateControl', 'DEFAULT_DATE_FORMAT', 'DEFAULT_DATETIME_FORMAT']

class DateControl(PopupControl):

	def __init__(self, parent, id=-1, format=DEFAULT_DATE_FORMAT, size=(100, 22), *args, **kwargs):
		PopupControl.__init__(self, parent, id, style=wx.WANTS_CHARS, size=size, *args, **kwargs)
		self._format = format
		self._ls = []
		self._popupWindow = wx.Window(self,-1, pos=(0,0), style=0)
		self._calendarControl = wx.calendar.CalendarCtrl(self._popupWindow, -1, pos=(0,0))
		self._popupWindow.SetSize(self._calendarControl.GetBestSize())
		self.SetPopupContent(self._popupWindow)
		self.SetMinSize(size)
		wx.calendar.EVT_CALENDAR_DAY(self._calendarControl, self._calendarControl.GetId(), self.OnDateSelected)

	def getDate(self):
		"""
		returns mxDateTime or None if bad date
		"""
		value = self.GetValue()
		if value:
			try:
				return mx.DateTime.DateTimeFrom(value)
			except:
				pass

	def setDate(self, date):
		self.SetValue(date.Format(self._format))

	def addValueListener(self, l):
		self._ls.append(l)

	def _fireValueChanged(self, oldValue, value):
		for l in self._ls:
			l.OnValueSelected(self, oldValue, value)

	def SetValue(self, v):
		old = self.GetValue()
		if old != v:
			PopupControl.SetValue(self, v)
			self._fireValueChanged(old, v)

	def setFormat(self, format):
		self._format = format

	def	getFormat(self):
		return self._format

	# Method called when a day is selected in the calendar
	def OnDateSelected(self, evt):
		self.PopDown()
		self.SetValue(self._calendarControl.GetDate().Format(self._format))
		evt.Skip()

	def FormatContent(self):
		"""
		Method overridden from PopupControl
		This method is called just before the popup is displayed
		Use this method to format any controls in the popup

		Parse the value in the text part to resemble the correct date in
		the calendar control
		"""
		value = self.GetValue()
		if value:
			try:
				date = wx.DateTime()
				date.ParseFormat(value, self._format)
				self._calendarControl.SetDate(date)
				return
			except:
				print "Can't parse date: '%s'. Setting today" % (value,)

		try:
			self._calendarControl.SetDate(wx.DateTime_Today())
		except Exception, e:
			# date is valid but this strange exception...
			print "Some bug in calendar... Cant set today: %s" % e

