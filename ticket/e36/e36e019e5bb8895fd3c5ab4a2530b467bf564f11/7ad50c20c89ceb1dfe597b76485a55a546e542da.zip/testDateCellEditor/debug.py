

def trace(msg, level=0):
	print "+", msg

def warning(msg, level=0):
	print "*", msg

def error(msg, level=0):
	print "!", msg

