#include "wx/wxprec.h"

#ifndef WX_PRECOMP
#include "wx/wx.h"
#endif

#include <wx/html/htmlwin.h>

wxString filename("content.htm");

class MyApp : public wxApp
{
public:
    virtual bool OnInit()
    {
        wxFrame *frame = new wxFrame(NULL, wxID_ANY, "Test wxHtmlWindow");

        wxHtmlWindow *html = new wxHtmlWindow(frame);

        wxButton *btn = new wxButton(frame, wxID_OK);
        btn->SetLabel("Load HTML from " + filename);
        btn->Bind(wxEVT_BUTTON, [=](wxCommandEvent&) {
                html->SetSize(wxSize(0,0));
                html->LoadPage(filename);
                html->SetSize(html->GetVirtualSize());
                html->SetMinClientSize(html->GetVirtualSize());
                frame->Fit();
                frame->Center();
            });

        wxBoxSizer *sizer = new wxBoxSizer(wxVERTICAL);
        sizer->Add(btn, wxSizerFlags().Expand().Border(wxALL, 10));
        sizer->Add(html, wxSizerFlags().Expand().Border(wxALL, 10));

        frame->SetSizerAndFit(sizer);
        frame->Center();
        frame->Show(true);
        return true;
    }
};

wxIMPLEMENT_APP(MyApp);
