/////////////////////////////////////////////////////////////////////////////
// Name:        numdlg.h
// Purpose:     wxNumberEntryDialog class
// Author:      Julian Smart
// Modified by:
// Created:     01/02/97
// RCS-ID:      $Id: numdlg.h,v 1.19 2003/08/09 12:37:30 VS Exp $
// Copyright:   (c) Julian Smart
// Licence:     wxWindows licence
/////////////////////////////////////////////////////////////////////////////

#ifndef _WX_NUMDLGDLG_H_BASE_
#define _WX_NUMDLGDLG_H_BASE_

#if wxUSE_NUMBERDLG

#include "wx/generic/numdlgg.h"

#endif
    // wxUSE_NUMBERDLG
#endif
    // _WX_NUMDLGDLG_H_BASE_
