/////////////////////////////////////////////////////////////////////////////
// Name:        email.h
// Purpose:     wxEmail: portable email client class
// Author:      Julian Smart
// Modified by:
// Created:     2001-08-21
// RCS-ID:      $Id: email.cpp,v 1.4 2004/05/25 11:14:25 JS Exp $
// Copyright:   (c) Julian Smart
// Licence:     wxWindows licence
/////////////////////////////////////////////////////////////////////////////
#include <wx/wxprec.h>
#ifdef __GNUG__
#pragma implementation "email.h"
#endif

// For compilers that support precompilation, includes "wx/wx.h".
#include "wx/wxprec.h"

#ifdef __BORLANDC__
	#pragma hdrstop
#endif

#ifndef WX_PRECOMP
	#include "wx/wx.h"
#endif

#include "wx/string.h"
#include "email.h"

#ifdef __WXMSW__
	#include "smapi.h"
#endif

#ifdef __UNIX__
	#include "wx/filename.h"
	#include "wx/filefn.h"
	#include "wx/timer.h"
	#include "wx/wfstream.h"
#endif // __UNIX__


// Send a message.
// Specify profile, or leave it to wxWidgets to find the current user name

#ifdef __WXMSW__
bool wxEmail::Send(wxMailMessage& message, const wxString& profileName, const wxString& WXUNUSED(sendMail), wxMailClient WXUNUSED(client) )
{
    wxASSERT (message.m_to.GetCount() > 0) ;

    wxString profile(profileName);
    if (profile.IsEmpty())
        profile = wxGetUserName();

    wxMapiSession session;

    if (!session.MapiInstalled())
    {
        ::wxLogError(_TR("MAPI is not installed or properly configured!"));
        return FALSE;
    }
    if (!session.Logon(profile))
    {
        ::wxLogError(_TR("MAPI: %s logon error!"), profile);
        return FALSE;
    }

    return session.Send(message);
}
#elif defined(__DARWIN__)

#if !defined( __OBJC__ ) || !defined( __cplusplus )
	#error This file should be compiled as Objective-C++
#endif

#import <CSMail/CSMail.h>
#import <Cocoa/Cocoa.h>

#include <wx/cocoa/string.h>
#include <wx/confbase.h>
#include <wx/stdpaths.h>

bool
wxEmail::Send(wxMailMessage& message,
              const wxString& WXUNUSED(profileName),
              const wxString& WXUNUSED(sendMail),
			  wxMailClient client)
{
	bool output = false;
	
	NSAutoreleasePool * pool = [[NSAutoreleasePool alloc] init];
	
@try
{	
	wxString client_string = wxEmptyString;
	
	if ( client == wxDEFAULT_MAIL_CLIENT )
	{
		SInt32 mac_version;
		Gestalt(gestaltSystemVersion, &mac_version);

		CFStringRef default_handler = NULL;
		
		if ( mac_version >= 0x1040 )
			default_handler = LSCopyDefaultHandlerForURLScheme( CFSTR("mailto") );
		
		if ( default_handler == NULL )
			default_handler = CFSTR("com.apple.mail");
			
		if ( CFStringCompare( default_handler, CFSTR("com.apple.mail"), kCFCompareNumerically) EQ 0 )
		{
			client = wxAPPLE_MAIL_CLIENT;
		} else if ( CFStringCompare( default_handler, CFSTR("com.qualcomm.eudora"), kCFCompareNumerically) EQ 0 )
		{
			client = wxEUDORA_MAIL_CLIENT;
		} else if ( CFStringCompare( default_handler, CFSTR("com.microsoft.Entourage"), kCFCompareNumerically) EQ 0 )
		{
			client = wxENTOURAGE_MAIL_CLIENT;
		}
		else
		{
			client = wxAPPLE_MAIL_CLIENT;
		}
		
		CFRelease( default_handler );
	}
	
	
	switch ( client )
	{
		case wxEUDORA_MAIL_CLIENT:
			client_string = wxT("Eudora");
			break;
			
		case wxENTOURAGE_MAIL_CLIENT:
			client_string = wxT("Entourage");
			break;
		
		case wxAPPLE_MAIL_CLIENT:
			client_string = wxT("Mail.app");
			break;
			
		case wxDEFAULT_MAIL_CLIENT:
		default:
			wxFAIL_MSG( wxT("A client should have already been chosen!") );
			break;
	}
	
		
	
	
	[CSMailClient initialize];
	wxSafeYield();
	NSArray *installed_clients = [[CSMailClient installedClients] retain];
	CSMailClient *desired_client = nil;
	CSMailClient *current_client = nil;
	
	unsigned int count = [installed_clients count];
	
	for( unsigned int i = 0; i < count; i++ )
	{
		current_client = [installed_clients objectAtIndex: i];
		if ( current_client EQ nil )
			continue;

		NSString * ns_appname = [current_client applicationName];
		if ( ns_appname EQ nil )
			continue;
		
		wxString app_name = wxStringWithNSString( ns_appname );
		wxLogDebug( app_name );
		
		if ( app_name EQ client_string )
		{
			desired_client = current_client;
			[desired_client retain];
		}
		
		[ns_appname release];
	}
	
	[installed_clients release];
	installed_clients = nil;
	
	if ( desired_client NE nil )
	{		
		NSMutableAttributedString * message_body = [NSMutableAttributedString alloc];
		[message_body initWithString: wxNSStringWithWxString( message.m_body + wxT("\n\n") )];
		
		NSFileWrapper * file_wrapper = nil;
		NSTextAttachment * attachment = nil;
		
		for( size_t i = 0; i < message.m_attachments.Count(); i++ )
		{
			wxLogDebug( wxT("Attempting to attach:  %s"),
						message.m_attachments.Item(0).c_str() );
			
			file_wrapper = [[[NSFileWrapper alloc] initWithPath: wxNSStringWithWxString( message.m_attachments.Item(i) )] autorelease];
			if ( file_wrapper == nil )
				continue;
			
			attachment = [[[NSTextAttachment alloc] initWithFileWrapper: file_wrapper] autorelease];
			if ( attachment == nil )
				continue;
			
			[message_body appendAttributedString: [NSAttributedString attributedStringWithAttachment: attachment] ];
		}
		
		
		NSMutableDictionary * headers = [[NSMutableDictionary alloc] init];
		
		[headers setObject: wxNSStringWithWxString( message.m_subject )
					forKey: @"Subject"];
		
		wxString to_field = wxEmptyString;
		for( size_t i = 0; i < message.m_to.Count(); i++ )
		{
			if ( i > 0 )
				to_field += wxT(",");

			to_field += message.m_to.Item(i);
		}
		
		[headers setObject: wxNSStringWithWxString( to_field )
					forKey: @"To" ];
		
		
		output = [desired_client constructMessage: message_body
										  headers: headers ];
		
		[message_body release];
		[headers release];
		[desired_client release];
	}
	else
	{
		wxLogError( _TR("Could not find a plug-in to send your file(s).") );
	}
}
@catch ( id )
{
	throw;
}
	
//	wxSafeYield();
	[pool release];
	
    return output;
}

#elif defined(__UNIX__)
bool
wxEmail::Send(wxMailMessage& message,
              const wxString& WXUNUSED(profileName),
              const wxString& sendMail,
			  wxMailClient WXUNUSED(client))
{
    wxASSERT (message.m_to.GetCount() > 0) ;

    // The 'from' field is optionally supplied by the app; it's not needed
    // by MAPI, and on Unix, will be guessed if not supplied.
    wxString from = message.m_from;
    if (from.IsEmpty())
    {
        from = wxGetEmailAddress();
    }

    wxASSERT (!from.IsEmpty());

    wxString msg;
    msg << wxT("To: ");

    for (size_t i = 0; i < message.m_to.GetCount(); i++)
    {
        if ( i )
            msg << wxT(", ");
        msg << message.m_to[i];
    }

    msg << wxT("\nFrom: ") << from << wxT("\nSubject: ") << message.m_subject;
    msg << wxT("\n\n") << message.m_body;

    // TODO: attachments!!

    wxFile file;
    const wxString filename = wxFileName::CreateTempFileName(wxT("wxemail"), &file);
    if ( filename.empty() )
        return false;

    if ( !file.Write(msg) )
        return false;

    // TODO search for a suitable sendmail if sendMail is empty
    wxString sendmail(sendMail);
    if ( sendmail.empty() )
    {
        sendmail = wxT("/usr/sbin/sendmail -t");
    }

    wxString cmd;
    cmd << sendmail << wxT(" < ") << filename;

    // TODO: check return code
    wxSystem(cmd.c_str());

    wxRemoveFile(filename);

    return false;
}
#else
	#error Send not yet implemented for this platform.
#endif

