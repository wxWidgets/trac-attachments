//
//  CSMailTest.h
//  CSMail
//
//  Created by Alastair Houghton on 09/01/2006.
//  Copyright 2006 Coriolis Systems Limited. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import <CSMail/CSMail.h>

@interface CSMailTest : NSObject
{
  IBOutlet NSPopUpButton *mailClients;
  IBOutlet NSTextField *mailAddress;

  NSArray *allClients;
}

- (IBAction)deliverMail:(id)sender;
- (IBAction)constructMail:(id)sender;

@end

/*
 * Local Variables:
 * mode: objc
 * End Local Variables:
 *
 */
