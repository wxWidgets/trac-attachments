//
//  CSEudoraMailClient.h
//  CSMail
//
//  Created by Alastair Houghton on 08/01/2006.
//  Copyright 2006 Coriolis Systems Limited. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import "CSMailClient.h"

@interface CSEudoraMailClient : CSMailClient
{
	NSAppleScript *script;
}

- (NSString *)name;
- (NSString *)version;

- (NSString *)applicationName;
- (NSString *)applicationBundleIdentifier;

- (BOOL)applicationIsInstalled;

- (BOOL)deliverMessage:(NSAttributedString *)messageBody
	       headers:(NSDictionary *)messageHeaders;

@end

/*
 * Local Variables:
 * mode: objc
 * End Local Variables:
 *
 */
