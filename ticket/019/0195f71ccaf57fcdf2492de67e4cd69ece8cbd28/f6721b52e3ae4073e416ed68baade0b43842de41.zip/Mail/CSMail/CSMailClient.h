//
//  CSMailClient.h
//  CSMail
//
//  Created by Alastair Houghton on 07/01/2006.
//  Copyright 2006 Coriolis Systems Limited. All rights reserved.
//

#import <Cocoa/Cocoa.h>

enum {
  kCSMCMessageDispatchFeature = 0x0001,
  kCSMCMessageConstructionFeature = 0x0002,
  kCSMCConfigureFeature = 0x0004,
};

@interface CSMailClient : NSObject
{
}

+ (NSArray *)installedClients;

- (NSString *)name;
- (NSString *)version;

- (NSString *)applicationName;
- (NSString *)applicationBundleIdentifier;
- (NSImage *)applicationIcon;

- (int)features;
- (BOOL)supportsFeature:(int)feature;

- (BOOL)applicationIsInstalled;

- (BOOL)deliverMessage:(NSAttributedString *)messageBody
	       headers:(NSDictionary *)messageHeaders;
- (BOOL)constructMessage:(NSAttributedString *)messageBody
		 headers:(NSDictionary *)messageHeaders;
- (void)configure:(id)sender;

@end

@interface NSObject (CSMailClientPlugin)

- (CSMailClient *)mailClient;

@end

/*
 * Local Variables:
 * mode: objc
 * End Local Variables:
 *
 */
