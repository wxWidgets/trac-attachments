//
//  CSMailTest.m
//  CSMail
//
//  Created by Alastair Houghton on 09/01/2006.
//  Copyright 2006 Coriolis Systems Limited. All rights reserved.
//

#import "CSMailTest.h"
#import <CSMail/CSMail.h>

@implementation CSMailTest

- (void)awakeFromNib
{
  NSMenu *menu;

  unsigned n, count;

  allClients = [CSMailClient installedClients];

  count = [allClients count];

  [mailClients removeAllItems];
  menu = [mailClients menu];
  for (n = 0; n < count; ++n) {
    CSMailClient *client = [allClients objectAtIndex:n];
    NSString *name = [client name];
    NSImage *icon = [[[client applicationIcon] copy] autorelease];
    NSMenuItem *item = [[[NSMenuItem alloc] initWithTitle:name
						   action:NULL
					    keyEquivalent:@""] autorelease];

    [icon setScalesWhenResized:YES];
    [icon setSize:NSMakeSize (16.0, 16.0)];

    [item setImage:icon];
    [menu addItem:item];
  }
}

- (NSAttributedString *)testMailBody
{
  NSString *body = @"This is a test message.\n\n"
    @"This is in bold.\n\n"
    @"This is in italic.\n\n";
  NSMutableAttributedString *attribBody 
    = [[[NSMutableAttributedString alloc] initWithString:body] autorelease];
  unichar attachment[] = { NSAttachmentCharacter };
  NSFileWrapper *fileWrapper;
  NSTextAttachment *fileAttach;
  NSFontManager *fontManager = [NSFontManager sharedFontManager];
  NSFont *baseFont = [NSFont fontWithName:@"Myriad Pro" size:12];
  NSFont *boldFont = [fontManager convertFont:baseFont
				  toHaveTrait:NSBoldFontMask];
  NSFont *italicFont = [fontManager convertFont:baseFont
				    toHaveTrait:NSItalicFontMask];

  [attribBody beginEditing];
  [attribBody addAttributes:
		[NSDictionary dictionaryWithObjectsAndKeys:
				baseFont, NSFontAttributeName,
			      nil]
	      range:NSMakeRange (0, 25)];

  [attribBody addAttributes:
		[NSDictionary dictionaryWithObjectsAndKeys:
				boldFont, NSFontAttributeName,
			      nil]
	      range:NSMakeRange (25, 18)];
  [attribBody addAttributes:
		[NSDictionary dictionaryWithObjectsAndKeys:
				italicFont, NSFontAttributeName,
			      nil]
	      range:NSMakeRange (43, 20)];

  fileWrapper = [[[NSFileWrapper alloc] initWithPath:@"/Applications/Mail.app/Contents/Resources/app.icns"]
		  autorelease];
  fileAttach = [[[NSTextAttachment alloc] initWithFileWrapper:fileWrapper]
		 autorelease];

  [attribBody insertAttributedString:
		[[[NSAttributedString alloc] 
		   initWithString:
		     [NSString stringWithCharacters:attachment length:1]
		   attributes:
		     [NSDictionary dictionaryWithObjectsAndKeys:
				     fileAttach, NSAttachmentAttributeName,
				   nil]] autorelease]
	      atIndex:25];

  fileWrapper = [[[NSFileWrapper alloc] initWithPath:@"/etc/syslog.conf"]
		  autorelease];
  fileAttach = [[[NSTextAttachment alloc] initWithFileWrapper:fileWrapper]
		 autorelease];

  [attribBody appendAttributedString:
		[[[NSAttributedString alloc] 
		   initWithString:
		     [NSString stringWithCharacters:attachment length:1]
		   attributes:
		     [NSDictionary dictionaryWithObjectsAndKeys:
				     fileAttach, NSAttachmentAttributeName,
				   nil]] autorelease]];
  [attribBody endEditing];

  return attribBody;
}

- (IBAction)deliverMail:(id)sender
{
  int idx = [mailClients indexOfSelectedItem];
  CSMailClient *client = [allClients objectAtIndex:idx];

  [client deliverMessage:[self testMailBody]
		 headers:[NSDictionary dictionaryWithObjectsAndKeys:
			   [mailAddress stringValue], @"To",
			   [mailAddress stringValue], @"From",
			   @"CSMail Framework Test Message", @"Subject",
			   nil]];
}

- (IBAction)constructMail:(id)sender
{
  int idx = [mailClients indexOfSelectedItem];
  CSMailClient *client = [allClients objectAtIndex:idx];

  [client constructMessage:[self testMailBody]
		   headers:[NSDictionary dictionaryWithObjectsAndKeys:
			     [mailAddress stringValue], @"To",
			     [mailAddress stringValue], @"From",
			     @"CSMail Framework Test Message", @"Subject",
			     nil]];
}

@end
