//
//  CSEntourageMailClient.h
//  CSMail
//
//  Created by Alastair Houghton on 07/01/2006.
//  Copyright 2006 Coriolis Systems Limited. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import "CSMailClient.h"

@interface CSEntourageMailClient : CSMailClient
{
	NSAppleScript *script;
}

- (NSString *)name;
- (NSString *)version;

- (NSString *)applicationName;
- (NSString *)applicationBundleIdentifier;
- (NSImage *)applicationIcon;

- (int)features;

- (BOOL)applicationIsInstalled;

- (BOOL)deliverMessage:(NSAttributedString *)messageBody
	       headers:(NSDictionary *)messageHeaders;
- (BOOL)constructMessage:(NSAttributedString *)messageBody
		 headers:(NSDictionary *)messageHeaders;

- (NSString *)buildRawSourceFromBody:(NSAttributedString *)body
	                  andHeaders:(NSDictionary *)headers
		pushAttachmentsToEnd:(BOOL)pushToEnd;

@end

/*
 * Local Variables:
 * mode: objc
 * End Local Variables:
 *
 */
