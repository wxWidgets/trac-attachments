//
//  CSMailMailClient.h
//  CSMail
//
//  Created by Alastair Houghton on 27/01/2006.
//  Copyright 2006 Coriolis Systems Limited. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import "CSMailClient.h"

@interface CSMailMailClient : CSMailClient
{
	NSAppleScript *script;
}

- (NSString *)name;
- (NSString *)version;

- (NSString *)applicationName;
- (NSString *)applicationBundleIdentifier;

- (BOOL)applicationIsInstalled;
- (NSImage *)applicationIcon;

- (int)features;

- (BOOL)deliverMessage:(NSAttributedString *)messageBody
	       headers:(NSDictionary *)messageHeaders;
- (BOOL)constructMessage:(NSAttributedString *)messageBody
		 headers:(NSDictionary *)messageHeaders;

@end

/*
 * Local Variables:
 * mode: objc
 * End Local Variables:
 *
 */
