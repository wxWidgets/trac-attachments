//
//  CSMailClient.m
//  CSMail
//
//  Created by Alastair Houghton on 07/01/2006.
//  Copyright 2006 Coriolis Systems Limited. All rights reserved.
//

#import "CSMailClient.h"
#import "CSMailMailClient.h"

static NSMutableArray *installedMailClients = nil;
static NSMutableSet *loadedClients = nil;

static void
loadAllPluginsAtPath (NSString *path)
{
	NSFileManager *fileManager = [NSFileManager defaultManager];
	NSArray *files = [fileManager directoryContentsAtPath:path];
	unsigned n, count = [files count];
	
	for (n = 0; n < count; ++n) {
		NSString *file = [files objectAtIndex:n];
		if ([loadedClients containsObject:file])
			continue;
		
		if ([[file pathExtension] isEqualToString:@"bundle"]) {
			NSBundle *bundle = [NSBundle bundleWithPath:
				[path stringByAppendingPathComponent:file]];
			
			if (bundle) {
				Class principalClass = [bundle principalClass];
				
				if ([principalClass respondsToSelector:@selector(mailClient)]) {
					id client = [principalClass mailClient];
					if (!client) {
						NSLog (@"%@ plug-in did not load correctly.", file);
					} else {
						[installedMailClients addObject:client];
						[loadedClients addObject:file];
						NSLog (@"%@ plug-in loaded.", file);
					}
				} else {
					NSLog (@"%@ is not a CSMail plugin", file);
				}
			} else {
				NSLog (@"%@ is not a CSMail plugin bundle", file);
			}
		}
	}
}

@implementation CSMailClient

+ (void)loadPlugins
{
	NSArray *searchPath = NSSearchPathForDirectoriesInDomains (NSLibraryDirectory,
															   NSAllDomainsMask,
															   YES);
	unsigned count, n;
	id mailClient;
	NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
	
	if (![defaults boolForKey:@"disableMailSupport"]) {
		/* Add the Mail client (built-in) */
		mailClient = [[CSMailMailClient alloc] init];
		if (mailClient)
			[installedMailClients addObject:mailClient];
		else {
			NSLog (@"Unable to initialise built-in Mail.app support.  This probably "
				   @"means the user has deleted Mail.app!");
		}
	}
	
	count = [searchPath count];
	for (n = 0; n < count; ++n)
	{
		NSString *path = [[searchPath objectAtIndex:n]
		       stringByAppendingString:
			@"/Application Support/Coriolis/CSMail Plugins/"];
		NSLog( path );
		loadAllPluginsAtPath (path);
	}
	
	// Now we check the "Coriolis" folder within the default plugins folder.
	CFBundleRef app_bundle = CFBundleGetMainBundle();
	
	
	if ( app_bundle != NULL )
	{
		CFURLRef relativeURL = CFBundleCopyBuiltInPlugInsURL( app_bundle );
		
		if ( relativeURL != NULL )
		{
			CFURLRef absoluteURL = CFURLCopyAbsoluteURL(relativeURL);
			if ( absoluteURL != NULL )
			{
				CFStringRef cfStrPath = CFURLCopyFileSystemPath(absoluteURL,kCFURLPOSIXPathStyle);
				
				if ( cfStrPath != NULL )
				{
					NSString * str_sub_path = [(NSString *)cfStrPath stringByAppendingPathComponent: @"CSMail" ]; 
					
					if ( str_sub_path != NULL )
					{
						loadAllPluginsAtPath( str_sub_path );
					}
					CFRelease(cfStrPath);
				}
				CFRelease(absoluteURL);
			}
			CFRelease(relativeURL);
		}
	}
}

+ (void)initialize
{
	/* If we're already initialised, return straight away */
	if (installedMailClients)
		return;
	
	/* Initialise the client array */
	installedMailClients = [[NSMutableArray alloc] init];
	loadedClients = [[NSMutableSet alloc] init];
	
	/* Do this after a delay to avoid interfering with application startup if the
		AppleScript compilation involves displaying a dialog box. */
	[self performSelector:@selector(loadPlugins)
			   withObject:nil
			   afterDelay:0];
}


+ (NSArray *)installedClients
{
	return installedMailClients;
}

- (NSString *)name
{
	[self doesNotRecognizeSelector:_cmd];
	return nil;
}

- (NSString *)version
{
	[self doesNotRecognizeSelector:_cmd];
	return nil;
}

- (NSString *)applicationName
{
	[self doesNotRecognizeSelector:_cmd];
	return nil;
}

- (NSString *)applicationBundleIdentifier;
{
	[self doesNotRecognizeSelector:_cmd];
	return nil;
}

- (NSImage *)applicationIcon
{
	return nil;
}

- (int)features
{
	return kCSMCMessageDispatchFeature;
}

- (BOOL)supportsFeature:(int)feature
{
	return [self features] & feature;
}

- (BOOL)applicationIsInstalled
{
	[self doesNotRecognizeSelector:_cmd];
	return NO;
}

- (BOOL)deliverMessage:(NSAttributedString *)messageBody
			   headers:(NSDictionary *)messageHeaders
{
	[self doesNotRecognizeSelector:_cmd];
	return NO;
}

- (BOOL)constructMessage:(NSAttributedString *)messageBody
				 headers:(NSDictionary *)messageHeaders
{
	[self doesNotRecognizeSelector:_cmd];
	return NO;
}

- (void)configure:(id)sender
{
	[self doesNotRecognizeSelector:_cmd];
}

@end
