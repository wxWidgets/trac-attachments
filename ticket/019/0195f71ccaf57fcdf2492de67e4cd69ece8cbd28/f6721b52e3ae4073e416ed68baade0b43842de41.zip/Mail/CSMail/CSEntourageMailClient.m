//
//  CSEntourageMailClient.m
//  CSMail
//
//  Created by Alastair Houghton on 07/01/2006.
//  Copyright 2006 Coriolis Systems Limited. All rights reserved.
//

#import "CSEntourageMailClient.h"

#import <ApplicationServices/ApplicationServices.h>
#import <Carbon/Carbon.h>

#include <stdlib.h>
#include <ctype.h>

typedef enum { 
	EOLStateStart,
	EOLStateSeenCR,
	EOLStateSeenLF,
} eol_state_t;

/* Run the EOL detection state machine; this knows how to match end-of-line
characters in all the common configurations. */
static eol_state_t
eolNextState (unichar ch, eol_state_t state, bool *emitCRLF)
{
	if (ch == '\n') {
		switch (state) {
			case EOLStateStart:
				state = EOLStateSeenLF;
				break;
			case EOLStateSeenCR:
				state = EOLStateStart;
				*emitCRLF = true;
				break;
			case EOLStateSeenLF:
				*emitCRLF = true;
				break;
		}
	} else if (ch == '\r') {
		switch (state) {
			case EOLStateStart:
				state = EOLStateSeenCR;
				break;
			case EOLStateSeenCR:
				state = EOLStateStart;
				*emitCRLF = true;
				break;
			case EOLStateSeenLF:
				*emitCRLF = true;
				break;
		}
	} else if (state != EOLStateStart) {
		state = EOLStateStart;
		*emitCRLF = true;
	}
	
	return state;
}

/* Convert a string into UTF-8 encoded using quoted-printable; note that
this function passes spaces and tabs at the ends of lines, which technically
it shouldn't (it should encode them instead). */
static NSString *
quotedPrintable (NSString *input)
{
	NSMutableString *output = [NSMutableString string];
	NSData *utf8 = [input dataUsingEncoding:NSUTF8StringEncoding];
	const unsigned char *bytes = [utf8 bytes];
	unsigned len = [utf8 length];
	unsigned lineLen = 0;
	eol_state_t eolState = EOLStateStart;
	
	while (len--) {
		unsigned char ch = *bytes++;
		bool emitCRLF = false;
		
		eolState = eolNextState (ch, eolState, &emitCRLF);
		
		if (emitCRLF) {
			[output appendString:@"\r\n"];
			lineLen = 0;
		}
		
		if (ch == '\n' || ch == '\r')
			continue;
		
		if (iscntrl (ch)
			|| ch > 126 || ch == '=' || ch == '!' || ch == '@'
			|| ch == '[' || ch == '\\' || ch == ']' || ch == '^'
			|| ch == '`' || ch == '{' || ch == '|' || ch == '}' 
			|| ch == '~') {
			if (lineLen + 3 > 76) {
				[output appendString:@"=\r\n"];
				lineLen = 0;
			}
			[output appendFormat:@"=%02X", ch];
			lineLen += 3;
			continue;
		}
		
		if (lineLen + 1 >= 76) {
			[output appendString:@"=\r\n"];
			lineLen = 0;
		}
		
		[output appendFormat:@"%c", ch];
		++lineLen;
	}
	
	return output;
}

/* Encode a file, identified by an NSFileWrapper, in base64 */
static NSString *
base64Encode (NSFileWrapper *fileWrapper)
{
	NSData *data = [fileWrapper regularFileContents];
	const unsigned char *bytes = [data bytes];
	unsigned len = [data length];
	static const char table[65] = 
		"ABCDEFGHIJKLMNOPQRSTUVWXYZ"
		"abcdefghijklmnopqrstuvwxyz"
		"0123456789+/";
	NSMutableString *base64String = [NSMutableString string];
	unsigned buffer;
	unsigned n;
	unsigned width;
	
	for (n = 0, width = 0; n < len; n += 3) {
		unichar chars[4];
		
		buffer = bytes[n] << 16;
		
		if (n + 1 < len)
			buffer |= bytes[n + 1] << 8;
		
		if (n + 2 < len)
			buffer |= bytes[n + 2];
		
		chars[0] = table[(buffer >> 18) & 0x3f];
		chars[1] = table[(buffer >> 12) & 0x3f];
		
		if (n + 1 < len)
			chars[2] = table[(buffer >> 6) & 0x3f];
		else
			chars[2] = '=';
		
		if (n + 2 < len)
			chars[3] = table[buffer & 0x3f];
		else
			chars[3] = '=';
		
		if (width + 4 > 76) {
			[base64String appendString:@"\r\n"];
			width = 0;
		}
		
		[base64String appendString:[NSString stringWithCharacters:chars length:4]];
		
		width += 4;
	}
	
	return base64String;
}

/* Quote special characters for HTML */
static NSString *
htmlQuote (NSString *input, eol_state_t *peolState)
{
	NSMutableString *output = [NSMutableString string];
	NSCharacterSet *allowedChars
		= [NSCharacterSet characterSetWithCharactersInString:
			@"0123456789"
			@"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz"
										  @" !\"#$%'()*+,-./:;=?@[\\]^_`{|}~\t"];
	NSScanner *scanner = [NSScanner scannerWithString:input];
	eol_state_t eolState = peolState ? *peolState : EOLStateStart;
	
	[scanner setCharactersToBeSkipped:nil];
	[scanner setCaseSensitive:YES];
	
	while (![scanner isAtEnd]) {
		NSString *tmp;
		
		while ([scanner scanCharactersFromSet:allowedChars
								   intoString:&tmp]) {
			if (eolState != EOLStateStart) {
				[output appendString:@"<br />\r\n"];
				eolState = EOLStateStart;
			}
			[output appendString:tmp];
		}
		
		if ([scanner scanUpToCharactersFromSet:allowedChars
									intoString:&tmp] && [tmp length]) {
			unsigned count = [tmp length];
			unsigned n;
			
			for (n = 0; n < count; ++n) {
				unichar ch = [tmp characterAtIndex:n];
				bool emitCRLF = false;
				
				eolState = eolNextState (ch, eolState, &emitCRLF);
				
				if (emitCRLF)
					[output appendString:@"<br />\r\n"];
				
				if (ch == '\r' || ch == '\n')
					continue;
				
				[output appendFormat:@"&#%u;", ch];
			}
		}
	}
	
	if (peolState)
		*peolState = eolState;
	
	return output;
}

@implementation CSEntourageMailClient

+ (id)mailClient
{
	return [[CSEntourageMailClient alloc] init];
}

- (id)init
{
	if ((self = [super init])) 
	{
		script = nil;
	}
	
	return self;
}

- (void)dealloc
{
	[script release];
	[super dealloc];
}

- (NSString *)name
{
	return @"Entourage Plugin";
}

- (NSString *)applicationName
{
	return @"Entourage";
}

- (NSString *)applicationBundleIdentifier;
{
	return @"com.microsoft.Entourage";
}

- (NSString *)version
{
	return @"1.1.0";
}

- (BOOL)applicationIsInstalled
{
	OSStatus ret = LSFindApplicationForInfo ('OPIM',
											 NULL,
											 CFSTR ("Microsoft Entourage"),
											 NULL,
											 NULL);
	
	if (ret != noErr) {
		ret = LSFindApplicationForInfo ('OPIM',
										NULL,
										NULL,
										NULL,
										NULL);
	}
	
	if (ret != noErr) {
		ret = LSFindApplicationForInfo (kLSUnknownCreator,
										NULL,
										CFSTR ("Microsoft Entourage"),
										NULL,
										NULL);
	}
	
	if (ret != noErr) {
		ret = LSFindApplicationForInfo (kLSUnknownCreator,
										NULL,
										CFSTR ("Entourage"),
										NULL,
										NULL);
	}
	
	return ret == noErr ? YES : NO;
}

- (NSImage *)applicationIcon
{
	CFURLRef url = NULL;
	OSStatus ret = LSFindApplicationForInfo ('OPIM',
											 NULL,
											 CFSTR ("Microsoft Entourage"),
											 NULL,
											 &url);
	
	if (ret != noErr) {
		ret = LSFindApplicationForInfo ('OPIM',
										NULL,
										NULL,
										NULL,
										&url);
	}
	
	if (ret != noErr) {
		ret = LSFindApplicationForInfo (kLSUnknownCreator,
										NULL,
										CFSTR ("Microsoft Entourage"),
										NULL,
										&url);
	}
	
	if (ret != noErr) {
		ret = LSFindApplicationForInfo (kLSUnknownCreator,
										NULL,
										CFSTR ("Entourage"),
										NULL,
										&url);
	}
	
	if (ret != noErr)
		return nil;
	else {
		NSString *path = [(NSURL *)url path];
		[(NSURL *)url autorelease];
		
		return [[NSWorkspace sharedWorkspace] iconForFile:path];
	}
}

- (NSAppleEventDescriptor *)descriptorForThisProcess
{
	ProcessSerialNumber thePSN = { 0, kCurrentProcess };
	
	return [NSAppleEventDescriptor descriptorWithDescriptorType:typeProcessSerialNumber
														  bytes:&thePSN
														 length:sizeof (thePSN)];
}

- (BOOL)doHandler:(NSString *)handler
       forMessage:(NSAttributedString *)messageBody
		  headers:(NSDictionary *)messageHeaders
pushAttachmentsToEnd:(BOOL)pushToEnd
{
	if ( script == nil )
	{
		NSDictionary *errorInfo = nil;
		
		/* This AppleScript code is here to communicate with Entourage */
		NSString *ourScript =
			@"on build_message(messageSource)\n"
			@"  tell application \"Microsoft Entourage\"\n"
			@"    set msg to make new outgoing message at out box folder with "
			@"               properties { source: messageSource }\n"
			@"    return msg\n"
			@"  end tell\n"
			@"end deliver_message\n"
			@"\n"
			@"on deliver_message(messageSource)\n"
			@"  set msg to build_message(messageSource)\n"
			@"  tell application \"Microsoft Entourage\"\n"
			@"    send msg\n"
			@"  end tell\n"
			@"end deliver_message\n"
			@"\n"
			@"on construct_message(messageSource)\n"
			@"  set msg to build_message(messageSource)\n"
			@"  tell application \"Microsoft Entourage\"\n"
			@"    open msg\n"
			@"  end tell\n"
			@"end construct_message\n";
		
		script = [[NSAppleScript alloc] initWithSource:ourScript];
		
		if (![script compileAndReturnError:&errorInfo])
		{
			NSLog (@"Unable to compile script: %@", errorInfo);
			return NO;
		}
	}
	
	NSString *source = [self buildRawSourceFromBody:messageBody
										 andHeaders:messageHeaders
							   pushAttachmentsToEnd:pushToEnd];
	NSDictionary *errorInfo = nil;
	NSAppleEventDescriptor *target = [self descriptorForThisProcess];
	NSAppleEventDescriptor *event = [NSAppleEventDescriptor
				    appleEventWithEventClass:'ascr'
									 eventID:kASSubroutineEvent
							targetDescriptor:target
									returnID:kAutoGenerateReturnID
							   transactionID:kAnyTransactionID];
	NSAppleEventDescriptor *params = [NSAppleEventDescriptor listDescriptor];
	
	[event setParamDescriptor:
		[NSAppleEventDescriptor descriptorWithString:handler]
				   forKeyword:keyASSubroutineName];
	[params insertDescriptor:
	    [NSAppleEventDescriptor descriptorWithString:source]
					 atIndex:1];
	[event setParamDescriptor:params forKeyword:keyDirectObject];
	
	if (![script executeAppleEvent:event error:&errorInfo]) {
		NSLog (@"Unable to deliver e-mail with Entourage.  Error was %@.\n",
			   errorInfo);
		return NO;
	}
	
	return YES;
}

- (NSString *)buildRawSourceFromBody:(NSAttributedString *)body
						  andHeaders:(NSDictionary *)headers
				pushAttachmentsToEnd:(BOOL)pushToEnd
{
	NSMutableString *rawSource = [NSMutableString string];
	NSMutableString *rawAttach = [NSMutableString string];
	NSDate *now = [NSDate date];
	NSDateFormatter *dateFormatter
		= [[[NSDateFormatter alloc] initWithDateFormat:
									 @"%a, %e %b %Y %H:%M:%S %z"
								  allowNaturalLanguage:NO] autorelease];
	NSEnumerator *keyEnum;
	NSString *key;
	unsigned tag1 = (unsigned)random (), tag2 = (unsigned)random ();
	NSMutableString *htmlBody = [NSMutableString string];
	NSMutableString *plainBody = [NSMutableString string];
	NSDictionary *attributes;
	NSRange range;
	unsigned pos = 0;
	unsigned length = [body length];
	NSFont *baseFont = [NSFont userFontOfSize:12];
	NSString *baseFamily = [baseFont familyName];
	float baseSize = [baseFont pointSize];
	NSFontManager *fontManager = [NSFontManager sharedFontManager];
	BOOL wantBold = NO, wantItalic = NO;
	eol_state_t htmlEOLState = EOLStateStart;
	
	[rawSource appendString:
			 @"Mime-Version: 1.0 (CSMail Entourage Plugin version 1.0)\r\n"
			   @"User-Agent: CSMail Entourage Plugin\r\n"];
	[rawSource appendFormat:@"Content-Type: multipart/mixed;\r\n"
		@"\tboundary=CSMail-=-1--%u\r\n", tag1];
	[rawSource appendFormat:@"Date: %@\r\n", [dateFormatter stringFromDate:now]];
	
	keyEnum = [headers keyEnumerator];
	while ((key = (NSString *)[keyEnum nextObject])) {
		NSString *value = [headers objectForKey:key];
		
		if ([key isEqualToString:@"Mime-Version"]
			|| [key isEqualToString:@"User-Agent"]
			|| [key isEqualToString:@"Date"]
			|| [key isEqualToString:@"Content-Type"]) {
			NSLog (@"Ignoring header %@ when sending e-mail.\n", key);
		} else {
			[rawSource appendFormat:@"%@: %@\r\n", key, value];
		}
	}
	
	[rawSource appendString:@"\r\n"
		@"This message is in MIME format.  Since your mail client does not\r\n"
		@"understand this format, some or all of the message may not be\r\n"
		@"legible.\r\n\r\n"];
	
	while (pos < length) {
		NSTextAttachment *attachment;
		NSMutableString *style = [NSMutableString string];
		
		attributes = [body attributesAtIndex:pos effectiveRange:&range];
		
		attachment = [attributes objectForKey:NSAttachmentAttributeName];
		
		if (attachment) {
			NSFileWrapper *fileWrapper = [attachment fileWrapper];
			NSDictionary *attributes = [fileWrapper fileAttributes];
			NSNumber *typeCodeN = [attributes objectForKey:NSFileHFSTypeCode];
			NSString *uniformType;
			NSString *mimeType;
			NSMutableString *attachTarget;
			
			if (typeCodeN) {
				OSType typeCode = [typeCodeN unsignedLongValue];
				CFStringRef typeCodeAsString = UTCreateStringForOSType (typeCode);
				
				[(NSString *)typeCodeAsString autorelease];
				uniformType 
					= (NSString *)
					UTTypeCreatePreferredIdentifierForTag (kUTTagClassOSType,
														   typeCodeAsString,
														   CFSTR("public.data"));
				[uniformType autorelease];
			} else {
				uniformType
				= (NSString *)
				UTTypeCreatePreferredIdentifierForTag (kUTTagClassFilenameExtension,
													   (CFStringRef)
													   [[fileWrapper 
														   preferredFilename] 
														   pathExtension],
													   CFSTR("public.data"));
			}
			
			mimeType 
				= (NSString *)UTTypeCopyPreferredTagWithClass ((CFStringRef)uniformType,
															   kUTTagClassMIMEType);
			[mimeType autorelease];
			
			if (!mimeType)
				mimeType = @"application/octet-stream";
			
			if (pushToEnd)
				attachTarget = rawAttach;
			else {
				attachTarget = rawSource;
				
				[rawSource appendFormat:@"--CSMail-=-1--%u\r\n"
						 @"Content-Type: multipart/alternative;\r\n"
					@"\tboundary=CSMail-=-2--%u\r\n\r\n"
					@"--CSMail-=-2--%u\r\n"
			@"Content-Transfer-Encoding: quoted-printable\r\n"
						 @"Content-Type: text/plain;\r\n"
					@"\tcharset=UTF-8;\r\n"
					@"\tformat=flowed\r\n\r\n"
					@"%@\r\n\r\n"
					@"--CSMail-=-2--%u\r\n"
			@"Content-Transfer-Encoding: 7bit\r\n"
						 @"Content-Type: text/html;\r\n"
					@"\tcharset=US-ASCII\r\n\r\n"
		@"<html><body style=\"word-wrap: break-word; -khtml-nbsp-mode: "
					@"space; -khtml-line-break: after-white-space;\">"
					@"%@</body></html>\r\n\r\n"
					@"--CSMail-=-2--%u--\r\n\r\n", tag1, tag2,
					tag2, quotedPrintable (plainBody),
					tag2, htmlBody,
					tag2];
				[plainBody setString:@""];
				[htmlBody setString:@""];
			}
			
			[attachTarget appendFormat:@"--CSMail-=-1--%u\r\n"
						@"Content-Type: %@; name=\"%@\"\r\n"
				 @"Content-Disposition: attachment\r\n"
		   @"Content-Transfer-Encoding: base64\r\n\r\n",
				tag1,
				mimeType, [fileWrapper preferredFilename]];
			
			[attachTarget appendString:base64Encode (fileWrapper)];
			[attachTarget appendString:@"\r\n\r\n"];
			
			if (pushToEnd) {
				[plainBody appendFormat:@"<%@>\r\n", [fileWrapper preferredFilename]];
				if (htmlEOLState != EOLStateStart) {
					[htmlBody appendString:@"<br />\r\n"];
					htmlEOLState = EOLStateStart;
				}
				[htmlBody appendFormat:@"<tt>&lt;%@&gt;</tt><br />",
					htmlQuote ([fileWrapper preferredFilename], &htmlEOLState)];
			}
			
			pos = range.location + range.length;
			continue;
		}
		
		[plainBody appendString:[[body string] substringWithRange:range]];
		
		if ([attributes objectForKey:NSForegroundColorAttributeName]) {
			NSColor *color = [attributes objectForKey:NSForegroundColorAttributeName];
			NSColor *rgbColor
				= [color colorUsingColorSpaceName:NSCalibratedRGBColorSpace];
			float r, g, b, a;
			unsigned red, green, blue;
			
			[rgbColor getRed:&r green:&g blue:&b alpha:&a];
			
			red = 255 * r;
			green = 255 * g;
			blue = 255 * b;
			
			[style appendFormat:@"color: #%02x%02x%02x; ",
				red, green, blue];
		}
		
		if ([attributes objectForKey:NSBackgroundColorAttributeName]) {
			NSColor *color = [attributes objectForKey:NSForegroundColorAttributeName];
			NSColor *rgbColor
				= [color colorUsingColorSpaceName:NSCalibratedRGBColorSpace];
			float r, g, b, a;
			unsigned red, green, blue;
			
			[rgbColor getRed:&r green:&g blue:&b alpha:&a];
			
			red = 255 * r;
			green = 255 * g;
			blue = 255 * b;
			
			[style appendFormat:@"background-color: #%02x%02x%02x; ",
				red, green, blue]; 
		}
		
		if ([attributes objectForKey:NSUnderlineStyleAttributeName]) {
			NSNumber *styleN = [attributes objectForKey:NSUnderlineStyleAttributeName];
			int sty = [styleN intValue];
			
			if (sty & (NSUnderlineStyleSingle 
					   | NSUnderlineStyleDouble 
					   | NSUnderlineStyleThick))
				[style appendString:@"text-decoration: underline; "];
			else if (sty & NSUnderlineStrikethroughMask)
				[style appendString:@"text-decoration: line-through; "];
		} else if ([attributes objectForKey:NSStrikethroughStyleAttributeName]) {
			NSNumber *styleN = [attributes objectForKey:NSUnderlineStyleAttributeName];
			int sty = [styleN intValue];
			
			if (sty & (NSUnderlineStyleSingle
					   | NSUnderlineStyleDouble
					   | NSUnderlineStyleThick))
				[style appendString:@"text-decoration: line-through; "];
		}
		
		if ([attributes objectForKey:NSFontAttributeName]) {
			NSFont *newFont = [attributes objectForKey:NSFontAttributeName];
			
			if (newFont != baseFont) {
				NSString *family = [newFont familyName];
				NSFontTraitMask traits = [fontManager traitsOfFont:newFont];
				float size = [newFont pointSize];
				
				if (![family isEqualToString:baseFamily])
					[style appendFormat:@"font-family: %@; ", family];
				
				if (size != baseSize) {
					[style appendFormat:@"font-size: %f%%; ", 
						100.0 * size / baseSize];
				}
				
				if (traits & NSCondensedFontMask)
					[style appendString:@"font-stretch: condensed; "];
				
				if (traits & NSExpandedFontMask)
					[style appendString:@"font-stretch: expanded; "];
				
				if (traits & NSSmallCapsFontMask)
					[style appendString:@"font-variant: small-caps; "];
				
				if (traits & NSBoldFontMask)
					wantBold = YES;
				else
					wantBold = NO;
				
				if (traits & NSItalicFontMask)
					wantItalic = YES;
				else
					wantItalic = NO;
			}
		}
		
		if ([style length])
			[htmlBody appendFormat:@"<span style=\"%@\">", style];
		
		if (wantBold)
			[htmlBody appendString:@"<b>"];
		if (wantItalic)
			[htmlBody appendString:@"<i>"];
		
		[htmlBody appendString:htmlQuote ([[body string] substringWithRange:range],
										  &htmlEOLState)];
		
		if (wantItalic)
			[htmlBody appendString:@"</i>"];
		if (wantBold)
			[htmlBody appendString:@"</b>"];
		
		if ([style length])
			[htmlBody appendString:@"</span>"];
		
		pos = range.location + range.length;
	}
	
	if ([plainBody length] || [htmlBody length]) {
		[rawSource appendFormat:@"--CSMail-=-1--%u\r\n"
				 @"Content-Type: multipart/alternative;\r\n"
			@"\tboundary=CSMail-=-2--%u\r\n\r\n"
			@"--CSMail-=-2--%u\r\n"
	@"Content-Transfer-Encoding: quoted-printable\r\n"
				 @"Content-Type: text/plain;\r\n"
			@"\tcharset=UTF-8;\r\n"
			@"\tformat=flowed\r\n\r\n"
			@"%@\r\n\r\n"
			@"--CSMail-=-2--%u\r\n"
	@"Content-Transfer-Encoding: 7bit\r\n"
				 @"Content-Type: text/html;\r\n"
			@"\tcharset=US-ASCII\r\n\r\n"
@"<html><body style=\"word-wrap: break-word; -khtml-nbsp-mode: "
			@"space; -khtml-line-break: after-white-space;\">"
			@"%@</body></html>\r\n\r\n"
			@"--CSMail-=-2--%u--\r\n\r\n", tag1, tag2,
			tag2, quotedPrintable (plainBody),
			tag2, htmlBody,
			tag2];
	}
	
	if ([rawAttach length])
		[rawSource appendString:rawAttach];
	
	[rawSource appendFormat:@"--CSMail-=-1--%u--\r\n", tag1];
	
	return rawSource;
}

- (BOOL)deliverMessage:(NSAttributedString *)messageBody
			   headers:(NSDictionary *)messageHeaders
{
	return [self doHandler:@"deliver_message"
				forMessage:messageBody
				   headers:messageHeaders
	  pushAttachmentsToEnd:NO];
}

- (BOOL)constructMessage:(NSAttributedString *)messageBody
				 headers:(NSDictionary *)messageHeaders
{
	return [self doHandler:@"construct_message"
				forMessage:messageBody
				   headers:messageHeaders
	  pushAttachmentsToEnd:YES];
}

- (int)features
{
	return (kCSMCMessageDispatchFeature
			| kCSMCMessageConstructionFeature);
}

@end
