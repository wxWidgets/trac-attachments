//
//  main.m
//  CSMailTest test application
//
//  Created by Alastair Houghton on 09/01/2006.
//  Copyright 2006 Coriolis Systems Limited. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int
main (int argc, const char **argv)
{
  return NSApplicationMain (argc, argv);
}
