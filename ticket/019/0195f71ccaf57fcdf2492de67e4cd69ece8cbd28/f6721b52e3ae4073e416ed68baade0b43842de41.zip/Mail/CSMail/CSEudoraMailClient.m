//
//  CSEudoraMailClient.m
//  CSMail
//
//  Created by Alastair Houghton on 08/01/2006.
//  Copyright 2006 Coriolis Systems Limited. All rights reserved.
//

#import "CSEudoraMailClient.h"

#import <ApplicationServices/ApplicationServices.h>
#import <CoreServices/CoreServices.h>
#import <Carbon/Carbon.h>

@implementation CSEudoraMailClient

+ (id)mailClient
{
	return [[CSEudoraMailClient alloc] init];
}

- (id)init
{
	if ((self = [super init])) 
	{
		script = nil;
	}
	
	return self;
}

- (void)dealloc
{
	if ( script != nil )
		[script release];
	[super dealloc];
}

- (NSString *)name
{
	return @"Eudora Plugin";
}

- (NSString *)version
{
	return @"1.1.0";
}

- (NSString *)applicationName
{
	return @"Eudora";
}

- (NSString *)applicationBundleIdentifier;
{
	return @"com.qualcomm.eudora";
}

- (BOOL)applicationIsInstalled
{
	OSStatus ret = LSFindApplicationForInfo (kLSUnknownCreator,
											 CFSTR ("com.qualcomm.eudora"),
											 NULL,
											 NULL,
											 NULL);
	
	if (ret != noErr) {
		ret = LSFindApplicationForInfo (kLSUnknownCreator,
										NULL,
										CFSTR ("Eudora"),
										NULL,
										NULL);
	}
	
	return ret == noErr ? YES : NO;
}

- (NSImage *)applicationIcon
{
	CFURLRef url = NULL;
	OSStatus ret = LSFindApplicationForInfo (kLSUnknownCreator,
											 CFSTR ("com.qualcomm.eudora"),
											 NULL,
											 NULL,
											 &url);
	
	if (ret != noErr) {
		ret = LSFindApplicationForInfo (kLSUnknownCreator,
										NULL,
										CFSTR ("Eudora"),
										NULL,
										&url);
	}
	
	if (ret != noErr)
		return nil;
	else {
		NSString *path = [(NSURL *)url path];
		[(NSURL *)url autorelease];
		
		return [[NSWorkspace sharedWorkspace] iconForFile:path];
	}
}

- (NSAppleEventDescriptor *)descriptorForThisProcess
{
	ProcessSerialNumber thePSN = { 0, kCurrentProcess };
	
	return [NSAppleEventDescriptor descriptorWithDescriptorType:typeProcessSerialNumber
														  bytes:&thePSN
														 length:sizeof (thePSN)];
}

- (BOOL)doHandler:(NSString *)handler
       forMessage:(NSAttributedString *)messageBody
		  headers:(NSDictionary *)messageHeaders
{
	if ( script == nil )
	{
		NSDictionary *errorInfo = nil;
		
		/* This AppleScript code is here to communicate with Eudora */
		NSString *ourScript =
			@"on build_message(sendr, recip, subj, ccrec, bccrec, msgbody,"
			@"                   attachfiles)\n"
			@"  tell application \"Eudora\"\n"
			@"    set msg to make message at end of mailbox \"Out\" of "
			@"       mail folder \"\"\n"
			@"    set field \"to\" of msg to recip\n"
			@"    if (sendr is not equal to \"\") then\n"
			@"      set field \"from\" of msg to sendr\n"
			@"    end if\n"
			@"    if (ccrec is not equal to \"\") then\n"
			@"      set field \"cc\" of msg to ccrec\n"
			@"    end if\n"
			@"    if (bccrec is not equal to \"\") then\n"
			@"      set field \"bcc\" of msg to bccrec\n"
			@"    end if\n"
			@"    set field \"subject\" of msg to subj\n"
			@"    set field \"\" of msg to msgbody\n"
			@"    repeat with attch in attachfiles\n"
			@"      attach to msg documents alias attch\n"
			@"    end repeat\n"
			@"    set destroy attachments of msg to true\n"
			@"    return msg\n"
			@"  end tell\n"
			@"end build_message\n"
			@"\n"
			@"on deliver_message(sendr, recip, subj, ccrec, bccrec, msgbody,"
			@"                   attachfiles)\n"
			@"  set msg to build_message(sendr, recip, subj, ccrec, bccrec, msgbody,"
			@"                           attachfiles)\n"
			@"  tell application \"Eudora\"\n"
			@"    queue msg\n"
			@"  end tell\n"
			@"end deliver_message\n"
			@"\n"
			@"on construct_message(sendr, recip, subj, ccrec, bccrec, msgbody,"
			@"                     attachfiles)\n"
			@"  set msg to build_message(sendr, recip, subj, ccrec, bccrec, msgbody,"
			@"                           attachfiles)\n"
			@"  tell application \"Eudora\"\n"
			@"    open msg\n"
			@"  end tell\n"
			@"end construct_message\n";
			
		script = [[NSAppleScript alloc] initWithSource:ourScript];
			
		if (![script compileAndReturnError:&errorInfo]) 
		{
			NSLog (@"Unable to compile script: %@", errorInfo);
			return NO;
		}
	}
	
	NSMutableString *body = [NSMutableString string];
	NSDictionary *errorInfo = nil;
	NSAppleEventDescriptor *target = [self descriptorForThisProcess];
	NSAppleEventDescriptor *event = [NSAppleEventDescriptor
				    appleEventWithEventClass:'ascr'
									 eventID:kASSubroutineEvent
							targetDescriptor:target
									returnID:kAutoGenerateReturnID
							   transactionID:kAnyTransactionID];
	NSAppleEventDescriptor *params = [NSAppleEventDescriptor listDescriptor];
	NSAppleEventDescriptor *files = [NSAppleEventDescriptor listDescriptor];
	NSString *tmpdir = NSTemporaryDirectory ();
	NSString *attachtmp = nil;
	NSFileManager *fileManager = [NSFileManager defaultManager];
	NSString *sendr = @"", *recip = @"", *subj = @"", *ccrec = @"", *bccrec = @"";
	unsigned pos = 0, length = [messageBody length];
	NSRange range;
	unsigned index = 1;
	
	if ([messageHeaders objectForKey:@"From"])
		sendr = [messageHeaders objectForKey:@"From"];
	if ([messageHeaders objectForKey:@"To"])
		recip = [messageHeaders objectForKey:@"To"];
	if ([messageHeaders objectForKey:@"Subject"])
		subj = [messageHeaders objectForKey:@"Subject"];
	if ([messageHeaders objectForKey:@"Cc"])
		ccrec = [messageHeaders objectForKey:@"Cc"];
	if ([messageHeaders objectForKey:@"Bcc"])
		bccrec = [messageHeaders objectForKey:@"Bcc"];
	
	/* Find all the attachments and replace them with placeholder text */
	while (pos < length) {
		NSDictionary *attributes = [messageBody attributesAtIndex:pos
												   effectiveRange:&range];
		NSTextAttachment *attachment
			= [attributes objectForKey:NSAttachmentAttributeName];
		
		if (attachment && !attachtmp) {
			/* Create a temporary directory to hold the attachments (we have to do this
			because we can't get the full path from the NSFileWrapper) */
			do {
				attachtmp = [tmpdir stringByAppendingPathComponent:
					[NSString stringWithFormat:@"csmail-%08lx",
						random ()]];
			} while (![fileManager createDirectoryAtPath:attachtmp attributes:nil]);
		}
		
		if (attachment) {
			NSFileWrapper *fileWrapper = [attachment fileWrapper];
			NSString *filename = [attachtmp stringByAppendingPathComponent:
				[fileWrapper preferredFilename]];
			NSString *oldPath = nil;
			CFURLRef url;
			
			url = CFURLCreateWithFileSystemPath (kCFAllocatorDefault,
												 (CFStringRef)filename,
												 kCFURLPOSIXPathStyle,
												 NO);
			
			if (!url) {
				NSLog (@"Unable to convert %@ to CFURL.\n", filename);
				return NO;
			}
			
			oldPath = (NSString *)CFURLCopyFileSystemPath (url, kCFURLHFSPathStyle);
			
			if (!oldPath) {
				CFRelease (url);
				NSLog (@"Unable to obtain old-style ':'-delimited path for %@.\n",
					   filename);
				return NO;
			}
			
			[oldPath autorelease];
			
			[fileWrapper writeToFile:filename atomically:NO
					 updateFilenames:NO];
			
			[body appendFormat:@"<%@>\n", [fileWrapper preferredFilename]];
			
			[files insertDescriptor:
				[NSAppleEventDescriptor descriptorWithString:oldPath]
							atIndex:index++];
			
			pos = range.location + range.length;
			
			continue;
		}
		
		
		[body appendString:[[messageBody string] substringWithRange:range]];
		
		pos = range.location + range.length;
	}
	
	/* Replace any CF/LF pairs with just CR; also replace LFs with CRs */
	[body replaceOccurrencesOfString:@"\r\n" withString:@"\r"
							 options:NSLiteralSearch range:NSMakeRange (0, [body length])];
	[body replaceOccurrencesOfString:@"\n" withString:@"\r"
							 options:NSLiteralSearch range:NSMakeRange (0, [body length])];
	
	[event setParamDescriptor:
		[NSAppleEventDescriptor descriptorWithString:handler]
				   forKeyword:keyASSubroutineName];
	[params insertDescriptor:
	    [NSAppleEventDescriptor descriptorWithString:sendr]
					 atIndex:1];
	[params insertDescriptor:
	    [NSAppleEventDescriptor descriptorWithString:recip]
					 atIndex:2];
	[params insertDescriptor:
	    [NSAppleEventDescriptor descriptorWithString:subj]
					 atIndex:3];
	[params insertDescriptor:
	    [NSAppleEventDescriptor descriptorWithString:ccrec]
					 atIndex:4];
	[params insertDescriptor:
	    [NSAppleEventDescriptor descriptorWithString:bccrec]
					 atIndex:5];
	[params insertDescriptor:
	    [NSAppleEventDescriptor descriptorWithString:body]
					 atIndex:6];
	[params insertDescriptor:files atIndex:7];
	
	[event setParamDescriptor:params forKeyword:keyDirectObject];
	
	if (![script executeAppleEvent:event error:&errorInfo]) {
		NSLog (@"Unable to communicate with Eudora.  Error was %@.\n",
			   errorInfo);
		return NO;
	}
	
	return YES;
}

- (BOOL)deliverMessage:(NSAttributedString *)messageBody
			   headers:(NSDictionary *)messageHeaders
{
	return [self doHandler:@"deliver_message"
				forMessage:messageBody
				   headers:messageHeaders];
}

- (BOOL)constructMessage:(NSAttributedString *)messageBody
				 headers:(NSDictionary *)messageHeaders
{
	return [self doHandler:@"construct_message"
				forMessage:messageBody
				   headers:messageHeaders];
}

- (int)features
{
	return (kCSMCMessageDispatchFeature
			| kCSMCMessageConstructionFeature);
}

@end
