/////////////////////////////////////////////////////////////////////////////
// Name:        email.h
// Purpose:     wxEmail: portable email client class
// Author:      Julian Smart
// Modified by:
// Created:     2001-08-21
// RCS-ID:      $Id: email.h,v 1.5 2004/05/25 11:13:34 JS Exp $
// Copyright:   (c) Julian Smart
// Licence:     wxWindows licence
/////////////////////////////////////////////////////////////////////////////

#if defined(__GNUG__) && !defined(__APPLE__)
#pragma interface "email.h"
#endif

#ifndef _WX_EMAIL_H_
#define _WX_EMAIL_H_

#include "msg.h"

/*
 * wxEmail
 * Miscellaneous email functions
 */


#if defined( __WXMAC__ ) || defined( __WXCOCOA__ )
enum wxMailClient
{
	wxDEFAULT_MAIL_CLIENT = -1,
	wxAPPLE_MAIL_CLIENT = 0,
	wxEUDORA_MAIL_CLIENT,
	wxENTOURAGE_MAIL_CLIENT
};
#else
enum wxMailClient
{
	wxDEFAULT_MAIL_CLIENT = -1
};
#endif

class wxEmail
{
public:
//// Ctor/dtor
    wxEmail() {};

//// Operations

    // Send a message.
    // Specify profile, or leave it to wxWidgets to find the current user name
    static bool Send(wxMailMessage& message,
					 const wxString& profileName = wxEmptyString,
					 const wxString& sendMail = wxEmptyString,
					 wxMailClient client = wxDEFAULT_MAIL_CLIENT );
    
protected:
};


#endif //_WX_EMAIL_H_

