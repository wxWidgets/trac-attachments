///////////////////////////////////////////////////////////////////////////////
// Name:        src/generic/spinctlg.cpp
// Purpose:     implements wxSpinCtrl as a composite control
// Author:      Vadim Zeitlin
// Modified by:
// Created:     29.01.01
// RCS-ID:      $Id: spinctlg.cpp 42816 2006-10-31 08:50:17Z RD $
// Copyright:   (c) 2001 Vadim Zeitlin <zeitlin@dptmaths.ens-cachan.fr>
// License:     wxWindows licence
///////////////////////////////////////////////////////////////////////////////

// ============================================================================
// declarations
// ============================================================================

// ----------------------------------------------------------------------------
// headers
// ----------------------------------------------------------------------------

// For compilers that support precompilation, includes "wx.h".
#include "wx/wxprec.h"

#ifdef __BORLANDC__
    #pragma hdrstop
#endif

#ifndef WX_PRECOMP
    #include "wx/textctrl.h"
#endif //WX_PRECOMP

#include "wx/spinctrl.h"

#if wxUSE_SPINCTRL

IMPLEMENT_DYNAMIC_CLASS(wxSpinCtrlDoubleEvent, wxNotifyEvent)

// There are port-specific versions for the wxSpinCtrl, so exclude the
// contents of this file in those cases
#if !defined(__WXGTK__)

#include "wx/spinbutt.h"

#if wxUSE_SPINBTN

// ----------------------------------------------------------------------------
// constants
// ----------------------------------------------------------------------------

// the margin between the text control and the spin
static const wxCoord MARGIN = 2;

#define SPINCTRLBUT_MAX 32000 // large to avoid wrap around trouble

// ----------------------------------------------------------------------------
// wxSpinCtrlText: text control used by spin control
// ----------------------------------------------------------------------------

class wxSpinCtrlText : public wxTextCtrl
{
public:
    wxSpinCtrlText(wxSpinCtrlGenericBase *spin, const wxString& value)
        : wxTextCtrl(spin->GetParent(), wxID_ANY, value, wxDefaultPosition,
                     wxDefaultSize, wxTE_NOHIDESEL|wxTE_PROCESS_ENTER)
    {
        m_spin = spin;

        // remove the default minsize, the spinctrl will have one instead
        SetSizeHints(wxDefaultCoord,wxDefaultCoord);
    }

    virtual ~wxSpinCtrlText()
    {
        // MSW sends extra kill focus event on destroy
        if (m_spin)
            m_spin->m_textCtrl = NULL;

        m_spin = NULL;
    }

    void OnTextEnter(wxCommandEvent& event)
    {
        if (m_spin)
            m_spin->OnTextEnter(event);
    }

    void OnChar( wxKeyEvent &event )
    {
        if (m_spin)
            m_spin->OnTextChar( event );
    }

    void OnKillFocus( wxFocusEvent &event )
    {
        if (m_spin)
            m_spin->SyncSpinToText(true);

        event.Skip();
    }

    wxSpinCtrlGenericBase *m_spin;

private:
    DECLARE_EVENT_TABLE()
};

BEGIN_EVENT_TABLE(wxSpinCtrlText, wxTextCtrl)
    EVT_TEXT_ENTER( wxID_ANY, wxSpinCtrlText::OnTextEnter )
    EVT_CHAR(       wxSpinCtrlText::OnChar )
    EVT_KILL_FOCUS( wxSpinCtrlText::OnKillFocus )
END_EVENT_TABLE()

// ----------------------------------------------------------------------------
// wxSpinCtrlButton: spin button used by spin control
// ----------------------------------------------------------------------------

class wxSpinCtrlButton : public wxSpinButton
{
public:
    wxSpinCtrlButton(wxSpinCtrlGenericBase *spin, int style)
        : wxSpinButton(spin->GetParent(), wxID_ANY, wxDefaultPosition,
                       wxDefaultSize, style)
    {
        m_spin = spin;

        SetRange(-SPINCTRLBUT_MAX, SPINCTRLBUT_MAX);

        // remove the default minsize, the spinctrl will have one instead
        SetSizeHints(wxDefaultCoord,wxDefaultCoord);
    }

    void OnSpinButton(wxSpinEvent& event)
    {
        if (m_spin)
            m_spin->OnSpinButton(event);
    }

    wxSpinCtrlGenericBase *m_spin;

private:
    DECLARE_EVENT_TABLE()
};

BEGIN_EVENT_TABLE(wxSpinCtrlButton, wxSpinButton)
    EVT_SPIN_UP(  wxID_ANY, wxSpinCtrlButton::OnSpinButton)
    EVT_SPIN_DOWN(wxID_ANY, wxSpinCtrlButton::OnSpinButton)
END_EVENT_TABLE()

// ============================================================================
// wxSpinCtrlGenericBase
// ============================================================================

// ----------------------------------------------------------------------------
// wxSpinCtrlGenericBase creation
// ----------------------------------------------------------------------------

void wxSpinCtrlGenericBase::Init()
{
    m_value         = 0;
    m_min           = 0;
    m_max           = 100;
    m_increment     = 1;
    m_digits        = 0;
    m_snap_to_ticks = false;
    m_format        = wxT("%g");

    m_spin_value    = 0;

    m_textCtrl = NULL;
    m_spinButton  = NULL;
}

bool wxSpinCtrlGenericBase::Create(wxWindow *parent, wxWindowID id,
                                   const wxString& value,
                                   const wxPoint& pos, const wxSize& size,
                                   long style,
                                   double min, double max, double initial,
                                   double increment,
                                   const wxString& name)
{
    if ( !wxControl::Create(parent, id, wxDefaultPosition, wxDefaultSize, style,
                            wxDefaultValidator, name) )
    {
        return false;
    }

    m_value = initial;
    m_min   = min;
    m_max   = max;
    m_increment = increment;

    // Note that these windows do NOT have this as their parent
    m_textCtrl   = new wxSpinCtrlText(this, value);
    m_spinButton = new wxSpinCtrlButton(this, wxSP_ARROW_KEYS|wxSP_VERTICAL|wxSP_WRAP);

    m_spin_value = m_spinButton->GetValue();

    // the string value overrides the numeric one (for backwards compatibility
    // reasons and also because it is simpler to satisfy the string value which
    // comes much sooner in the list of arguments and leave the initial
    // parameter unspecified)
    if ( !value.empty() )
    {
        double d;
        if ( value.ToDouble(&d) )
        {
            m_value = d;
            m_textCtrl->SetValue(wxString::Format(m_format.c_str(), m_value));
        }
    }

    SetInitialSize(size);
    Move(pos);

    // have to disable this window to avoid interfering it with message
    // processing to the text and the button... but pretend it is enabled to
    // make IsEnabled() return true
    wxControl::Enable(false); // don't use non virtual Disable() here!
    m_isEnabled = true;

    // we don't even need to show this window itself - and not doing it avoids
    // that it overwrites the text control
    wxControl::Show(false);
    m_isShown = true;
    return true;
}

wxSpinCtrlGenericBase::~wxSpinCtrlGenericBase()
{
    // delete the controls now, don't leave them alive even though they would
    // still be eventually deleted by our parent - but it will be too late, the
    // user code expects them to be gone now

    if (m_textCtrl)
    {
        // null this since MSW sends KILL_FOCUS on deletion, see ~wxSpinCtrlText
        wxDynamicCast(m_textCtrl, wxSpinCtrlText)->m_spin = NULL;

        wxSpinCtrlText *text = (wxSpinCtrlText*)m_textCtrl;
        m_textCtrl = NULL;
        delete text;
    }

    delete m_spinButton;
    m_spinButton = NULL ;
}

// ----------------------------------------------------------------------------
// geometry
// ----------------------------------------------------------------------------

wxSize wxSpinCtrlGenericBase::DoGetBestSize() const
{
    wxSize sizeBtn  = m_spinButton->GetBestSize(),
           sizeText = m_textCtrl->GetBestSize();

    return wxSize(sizeBtn.x + sizeText.x + MARGIN, sizeText.y);
}

void wxSpinCtrlGenericBase::DoMoveWindow(int x, int y, int width, int height)
{
    wxControl::DoMoveWindow(x, y, width, height);

    // position the subcontrols inside the client area
    wxSize sizeBtn = m_spinButton->GetSize();

    wxCoord wText = width - sizeBtn.x;
    m_textCtrl->SetSize(x, y, wText, height);
    m_spinButton->SetSize(x + wText + MARGIN, y, wxDefaultCoord, height);
}

// ----------------------------------------------------------------------------
// operations forwarded to the subcontrols
// ----------------------------------------------------------------------------

bool wxSpinCtrlGenericBase::Enable(bool enable)
{
    if ( !wxControl::Enable(enable) )
        return false;

    m_spinButton->Enable(enable);
    m_textCtrl->Enable(enable);

    return true;
}

bool wxSpinCtrlGenericBase::Show(bool show)
{
    if ( !wxControl::Show(show) )
        return false;

    // under GTK Show() is called the first time before we are fully
    // constructed
    if ( m_spinButton )
    {
        m_spinButton->Show(show);
        m_textCtrl->Show(show);
    }

    return true;
}

// ----------------------------------------------------------------------------
// Handle sub controls events
// ----------------------------------------------------------------------------

void wxSpinCtrlGenericBase::OnSpinButton(wxSpinEvent& event)
{
    event.Skip();

    // Sync the textctrl since the user expects that the button will modify
    // what they see in the textctrl.
    if (m_textCtrl && m_textCtrl->IsModified())
        SyncSpinToText(false);

    int spin_value = event.GetPosition();
    double step = (event.GetEventType() == wxEVT_SCROLL_LINEUP) ? 1 : -1;

    // Use the spinbutton's acceleration, if any, but not if wrapping around
    if (((spin_value >= 0) && (m_spin_value >= 0)) || ((spin_value <= 0) && (m_spin_value <= 0)))
        step *= abs(spin_value - m_spin_value);

    double value = m_value + step*m_increment;

    // we can always reach the ends using the spinbutton
    if (value < m_min) value = m_min;
    if (value > m_max) value = m_max;

    // Ignore the edges when it wraps since the up/down event may be opposite
    // They are in GTK and Mac
    if (abs(spin_value - m_spin_value) > SPINCTRLBUT_MAX)
    {
        m_spin_value = spin_value;
        return;
    }

    m_spin_value = spin_value;

    if (InRange(value) && DoSetValue(value))
        DoSendEvent();
}

void wxSpinCtrlGenericBase::OnTextEnter(wxCommandEvent& event)
{
    SyncSpinToText(true);
    event.Skip();
}

void wxSpinCtrlGenericBase::OnTextChar(wxKeyEvent& event)
{
    switch ( event.GetKeyCode() )
    {
        case WXK_UP :
        {
            if (m_textCtrl && m_textCtrl->IsModified()) SyncSpinToText(false);
            if (DoSetValue( m_value + m_increment ))
                DoSendEvent();
            break;
        }
        case WXK_DOWN :
        {
            if (m_textCtrl && m_textCtrl->IsModified()) SyncSpinToText(false);
            if (DoSetValue( m_value - m_increment ))
                DoSendEvent();
            break;
        }
        case WXK_PAGEUP :
        {
            if (m_textCtrl && m_textCtrl->IsModified()) SyncSpinToText(false);
            if (DoSetValue( m_value + m_increment * 10.0 ))
                DoSendEvent();
            break;
        }
        case WXK_PAGEDOWN :
        {
            if (m_textCtrl && m_textCtrl->IsModified()) SyncSpinToText(false);
            if (DoSetValue( m_value - m_increment * 10.0 ))
                DoSendEvent();
            break;
        }
        default : event.Skip(); break;
    }
}

// ----------------------------------------------------------------------------
// Textctrl functions
// ----------------------------------------------------------------------------

void wxSpinCtrlGenericBase::SyncSpinToText(bool send_event, bool force_valid)
{
    if (!m_textCtrl)
        return;

    double txt_value;
    if ( m_textCtrl->GetValue().ToDouble( &txt_value ) )
    {
        if ( force_valid || InRange(txt_value) )
        {
            if (force_valid)
            {
                if (txt_value > m_max)
                    txt_value = m_max;
                else if (txt_value < m_min)
                    txt_value = m_min;
            }

            if (m_value != txt_value)
            {
                DoSetValue( txt_value );
                if (send_event)
                    DoSendEvent();
            }
        }
    }
    else if (force_valid)
    {
        // textctrl is out of sync, discard and reset
        DoSetValue(m_value);
    }
}

// ----------------------------------------------------------------------------
// changing value and range
// ----------------------------------------------------------------------------

void wxSpinCtrlGenericBase::SetValue(const wxString& text)
{
    wxCHECK_RET( m_textCtrl, _T("invalid call to wxSpinCtrl::SetValue") );

    double val;
    if ( text.ToDouble(&val) && InRange(val) )
    {
        DoSetValue(val);
    }
    else // not a number at all or out of range
    {
        m_textCtrl->SetValue(text);
        m_textCtrl->SetSelection(0, -1);
    }
}

bool wxSpinCtrlGenericBase::DoSetValue(double val)
{
    wxCHECK_MSG( m_textCtrl, false, _T("invalid call to wxSpinCtrl::SetValue") );

    if (!InRange(val))
        return false;

    if ( m_snap_to_ticks && (m_increment != 0) )
    {
        double snap_value = val / m_increment;

        if (wxFinite(snap_value)) // FIXME what to do about a failure?
        {
            if ((snap_value - floor(snap_value)) < (ceil(snap_value) - snap_value))
                val = floor(snap_value) * m_increment;
            else
                val = ceil(snap_value) * m_increment;
        }
    }

    wxString str(wxString::Format(m_format.c_str(), val));

    if ((val != m_value) || (str != m_textCtrl->GetValue()))
    {
        m_value = val;
        str.ToDouble( &m_value );    // wysiwyg for textctrl
        m_textCtrl->SetValue( str );
        m_textCtrl->DiscardEdits();
        return true;
    }

    return false;
}

void wxSpinCtrlGenericBase::DoSetRange(double min, double max)
{
    m_min = min;
    m_max = max;
}

void wxSpinCtrlGenericBase::DoSetIncrement(double inc)
{
    m_increment = inc;
}

void wxSpinCtrlGenericBase::SetSnapToTicks(bool snap_to_ticks)
{
    m_snap_to_ticks = snap_to_ticks;
    DoSetValue(m_value);
}

void wxSpinCtrlGenericBase::SetSelection(long from, long to)
{
    wxCHECK_RET( m_textCtrl, _T("invalid call to wxSpinCtrl::SetSelection") );

    m_textCtrl->SetSelection(from, to);
}

//-----------------------------------------------------------------------------
// wxSpinCtrl
//-----------------------------------------------------------------------------

IMPLEMENT_DYNAMIC_CLASS(wxSpinCtrl, wxSpinCtrlGenericBase)

void wxSpinCtrl::DoSendEvent()
{
    wxSpinCtrlEvent event( wxEVT_COMMAND_SPINCTRL_UPDATED, GetId());
    event.SetEventObject( this );
    event.SetPosition((int)(m_value + 0.5)); // FIXME should be SetValue
    event.SetString(m_textCtrl->GetValue());
    GetEventHandler()->ProcessEvent( event );
}

//-----------------------------------------------------------------------------
// wxSpinCtrlDouble
//-----------------------------------------------------------------------------

IMPLEMENT_DYNAMIC_CLASS(wxSpinCtrlDouble, wxSpinCtrlGenericBase)

void wxSpinCtrlDouble::DoSendEvent()
{
    wxSpinCtrlDoubleEvent event( wxEVT_COMMAND_SPINCTRLDOUBLE_UPDATED, GetId());
    event.SetEventObject( this );
    event.SetValue(m_value);
    event.SetString(m_textCtrl->GetValue());
    GetEventHandler()->ProcessEvent( event );
}

void wxSpinCtrlDouble::SetDigits( int digits )
{
    wxCHECK_RET((digits >= -1) && (digits <= 20), wxT("Invalid number of digits for wxSpinCtrlDouble"));

    if (digits == -1)
        m_format = wxT("%g");
    else
        m_format.Printf(wxT("%%0.%dlf"), digits);

    DoSetValue(m_value);
}


#endif // wxUSE_SPINBTN
#endif // !wxPort-with-native-spinctrl
#endif // wxUSE_SPINCTRL
