/////////////////////////////////////////////////////////////////////////////
// Name:        spinctrl.h
// Purpose:     wxSpinCtrlBase class
// Author:      Vadim Zeitlin
// Modified by:
// Created:     22.07.99
// RCS-ID:      $Id: spinctrl.h 37066 2006-01-23 03:27:34Z MR $
// Copyright:   (c) Vadim Zeitlin
// Licence:     wxWindows licence
/////////////////////////////////////////////////////////////////////////////

#ifndef _WX_SPINCTRL_H_
#define _WX_SPINCTRL_H_

#include "wx/defs.h"

#if wxUSE_SPINCTRL

#include "wx/spinbutt.h"        // should make wxSpinEvent visible to the app

// ----------------------------------------------------------------------------
// a spin ctrl is a text control with a spin button which is usually used to
// prompt the user for a numeric input
// ----------------------------------------------------------------------------

class WXDLLEXPORT wxSpinCtrlBase : public wxControl
{
public:
    wxSpinCtrlBase() {}

    // accessors
    // T GetValue() const
    // T GetMin() const
    // T GetMax() const
    // T GetIncrement() const
    virtual bool GetSnapToTicks() const = 0;
    // int  GetDigits() const                       - wxSpinCtrlDouble only

    // operations
    virtual void SetValue(const wxString& value) = 0;
    // void SetValue(T val)
    // void SetRange(T minVal, T maxVal)
    // void SetIncrement(T inc)
    virtual void SetSnapToTicks(bool snap_to_ticks) = 0;
    // void SetDigits( int digits )                 - wxSpinCtrlDouble only

    // Select text in the textctrl
    virtual void SetSelection(long from, long to) = 0;

private:
    DECLARE_NO_COPY_CLASS(wxSpinCtrlBase)
};

//typedef wxControl wxSpinCtrlBase;

// ----------------------------------------------------------------------------
// wxSpinCtrlEvent
// ----------------------------------------------------------------------------

/*
class WXDLLEXPORT wxSpinCtrlEvent : public wxSpinEvent
{
public:
    wxSpinCtrlEvent(wxEventType commandType = wxEVT_NULL, int winid = 0,
                    int value = 0)
        : wxSpinEvent(commandType, winid)
    {
        SetPosition(value);
    }

    wxSpinCtrlEvent(const wxSpinCtrlEvent& event) : wxSpinEvent(event) // FIXME make wxSpinEvent() public
    {
    }

    int  GetValue() const    { return GetPosition(); }
    void SetValue(int value) { SetPosition(value); }

    virtual wxEvent *Clone() const { return new wxSpinCtrlEvent(*this); }

private:
    DECLARE_DYNAMIC_CLASS_NO_ASSIGN(wxSpinCtrlEvent)
};
*/

typedef wxSpinEvent wxSpinCtrlEvent;

// ----------------------------------------------------------------------------
// wxSpinCtrlDoubleEvent
// ----------------------------------------------------------------------------

class WXDLLEXPORT wxSpinCtrlDoubleEvent : public wxNotifyEvent
{
public:
    wxSpinCtrlDoubleEvent(wxEventType commandType = wxEVT_NULL, int winid = 0,
                          double value = 0)
        : wxNotifyEvent(commandType, winid), m_value(value)
    {
    }

    wxSpinCtrlDoubleEvent(const wxSpinCtrlDoubleEvent& event)
        : wxNotifyEvent(event), m_value(event.GetValue())
    {
    }

    double GetValue() const       { return m_value; }
    void   SetValue(double value) { m_value = value; }

    virtual wxEvent *Clone() const { return new wxSpinCtrlDoubleEvent(*this); }

protected:
    double m_value;

private:
    DECLARE_DYNAMIC_CLASS_NO_ASSIGN(wxSpinCtrlDoubleEvent)
};

// ----------------------------------------------------------------------------
// wxSpinCtrlEvent and wxSpinCtrlDoubleEvent event types
// ----------------------------------------------------------------------------

typedef void (wxEvtHandler::*wxSpinCtrlEventFunction)(wxSpinCtrlEvent&);
typedef void (wxEvtHandler::*wxSpinCtrlDoubleEventFunction)(wxSpinCtrlDoubleEvent&);


#define wxSpinCtrlEventHandler(func) \
    (wxObjectEventFunction)(wxEventFunction)wxStaticCastEvent(wxSpinCtrlEventFunction, &func)

#define wxSpinCtrlDoubleEventHandler(func) \
    (wxObjectEventFunction)(wxEventFunction)wxStaticCastEvent(wxSpinCtrlDoubleEventFunction, &func)


// macros for handling spinctrl events

#define EVT_SPINCTRL(id, fn) \
    wx__DECLARE_EVT1(wxEVT_COMMAND_SPINCTRL_UPDATED, id, wxSpinCtrlEventHandler(fn))

#define EVT_SPINCTRLDOUBLE(id, fn) \
    wx__DECLARE_EVT1(wxEVT_COMMAND_SPINCTRLDOUBLE_UPDATED, id, wxSpinCtrlDoubleEventHandler(fn))


// ----------------------------------------------------------------------------
// include the platform-dependent class implementation
// ----------------------------------------------------------------------------

#if defined(__WXGTK20__)
    #include "wx/gtk/spinctrl.h"
#elif defined(__WXGTK__)
    #include "wx/gtk1/spinctrl.h"
#else
    #include "wx/generic/spinctlg.h"
#endif // platform

#endif // wxUSE_SPINCTRL

#endif // _WX_SPINCTRL_H_
