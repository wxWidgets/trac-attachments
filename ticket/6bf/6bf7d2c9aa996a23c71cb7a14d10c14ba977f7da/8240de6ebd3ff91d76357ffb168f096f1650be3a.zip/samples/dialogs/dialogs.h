/////////////////////////////////////////////////////////////////////////////
// Name:        dialogs.h
// Purpose:     Common dialogs demo
// Author:      Julian Smart, Vadim Zeitlin, ABX
// Created:     04/01/98
// RCS-ID:      $Id: dialogs.h 69463 2011-10-18 21:57:02Z VZ $
// Copyright:   (c) Julian Smart
//              (c) 2004 ABX
//              (c) Vadim Zeitlin
// Licence:     wxWindows licence
/////////////////////////////////////////////////////////////////////////////

/*
This sample shows how to use the common dialogs available from wxWidgets.
It also shows that generic implementations of common dialogs can be exchanged
with native dialogs and can coexist in one application. The need for generic
dialogs addition is recognized thanks to setup of below USE_*** setting. Their
combinations reflects conditions of makefiles and project files to avoid unresolved
references during linking. For now some generic dialogs are added in static builds
of MSW, MAC and OS2
*/

#ifndef __DIALOGSH__
#define __DIALOGSH__

#ifdef __WXUNIVERSAL__
    #define USE_WXUNIVERSAL 1
#else
    #define USE_WXUNIVERSAL 0
#endif

#ifdef WXUSINGDLL
    #define USE_DLL 1
#else
    #define USE_DLL 0
#endif

#if defined(__WXWINCE__)
    #define USE_WXWINCE 1
#else
    #define USE_WXWINCE 0
#endif

#if defined(__WXMSW__) && !USE_WXWINCE
    #define USE_WXMSW 1
#else
    #define USE_WXMSW 0
#endif

#ifdef __WXMAC__
    #define USE_WXMAC 1
#else
    #define USE_WXMAC 0
#endif

#if defined(__WXMAC_OSX__) && ( MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_2) && USE_NATIVE_FONT_DIALOG_FOR_MACOSX
    #define USE_WXMACFONTDLG 1
#else
    #define USE_WXMACFONTDLG 0
#endif

#ifdef __WXGTK__
    #define USE_WXGTK 1
#else
    #define USE_WXGTK 0
#endif

#ifdef __WXPM__
    #define USE_WXPM 1
#else
    #define USE_WXPM 0
#endif

#define USE_GENERIC_DIALOGS (!USE_WXUNIVERSAL && !USE_DLL)

#define USE_COLOURDLG_GENERIC \
    ((USE_WXMSW || USE_WXMAC) && USE_GENERIC_DIALOGS && wxUSE_COLOURDLG)
#define USE_DIRDLG_GENERIC \
    ((USE_WXMSW || USE_WXMAC) && USE_GENERIC_DIALOGS && wxUSE_DIRDLG)
#define USE_FILEDLG_GENERIC \
    ((((USE_WXMSW || USE_WXMAC || USE_WXPM || USE_WXGTK) \
                    && USE_GENERIC_DIALOGS) || USE_WXWINCE) && wxUSE_FILEDLG)
#define USE_FONTDLG_GENERIC \
    ((USE_WXMSW || USE_WXMACFONTDLG || USE_WXPM) && USE_GENERIC_DIALOGS && wxUSE_FONTDLG)

// Turn USE_MODAL_PRESENTATION to 0 if there is any reason for not presenting difference
// between modal and modeless dialogs (ie. not implemented it in your port yet)
#if defined(__SMARTPHONE__) || !wxUSE_BOOKCTRL
    #define USE_MODAL_PRESENTATION 0
#else
    #define USE_MODAL_PRESENTATION 1
#endif


// Turn USE_SETTINGS_DIALOG to 0 if supported
#if wxUSE_BOOKCTRL
    #define USE_SETTINGS_DIALOG 1
#else
    #define USE_SETTINGS_DIALOG 0
#endif

// Define a new application type
class MyApp: public wxApp
{
public:
    MyApp() { m_startupProgressStyle = -1; }

    virtual bool OnInit();

protected:

private:
    // Flag set to a valid value if command line option "progress" is used,
    // this allows testing of wxProgressDialog before the main event loop is
    // started. If this option is not specified it is set to -1 by default
    // meaning that progress dialog shouldn't be shown at all.
    long m_startupProgressStyle;
};

// A class demonstrating CreateStdDialogButtonSizer()
class StdButtonSizerDialog : public wxDialog
{
public:
    StdButtonSizerDialog(wxWindow *parent);

    void OnEvent(wxCommandEvent& event);

private:
    void EnableDisableControls();

    wxCheckBox *m_chkboxAffirmativeButton;
    wxRadioButton *m_radiobtnOk,
                  *m_radiobtnYes;

    wxCheckBox *m_chkboxDismissButton;
    wxRadioButton *m_radiobtnClose,
                  *m_radiobtnCancel;

    wxCheckBox *m_chkboxApply,
               *m_chkboxNo,
               *m_chkboxHelp,
               *m_chkboxNoDefault;

    wxSizer *m_buttonsSizer;

    DECLARE_EVENT_TABLE()
};

// Test harness for wxMessageDialog.
class TestMessageBoxDialog : public wxDialog
{
public:
    TestMessageBoxDialog(wxWindow *parent);

    bool Create();

protected:
    wxString GetMessage() { return m_textMsg->GetValue(); }
    long GetStyle();

    void PrepareMessageDialog(wxMessageDialogBase &dlg);

    virtual void AddAdditionalTextOptions(wxSizer *WXUNUSED(sizer)) { }
    virtual void AddAdditionalFlags(wxSizer *WXUNUSED(sizer)) { }

    void OnApply(wxCommandEvent& event);
    void OnClose(wxCommandEvent& event);
    void OnUpdateLabelUI(wxUpdateUIEvent& event);
    void OnUpdateNoDefaultUI(wxUpdateUIEvent& event);

private:
    enum
    {
        Btn_Yes,
        Btn_No,
        Btn_Ok,
        Btn_Cancel,
        Btn_Help,
        Btn_Max
    };

    struct BtnInfo
    {
        int flag;
        const char *name;
    };

    static const BtnInfo ms_btnInfo[Btn_Max];

    enum
    {
        MsgDlgIcon_No,
        MsgDlgIcon_None,
        MsgDlgIcon_Info,
        MsgDlgIcon_Question,
        MsgDlgIcon_Warning,
        MsgDlgIcon_Error,
        MsgDlgIcon_Max
    };

    wxTextCtrl *m_textMsg,
               *m_textExtMsg;

    wxCheckBox *m_buttons[Btn_Max];
    wxTextCtrl *m_labels[Btn_Max];

    wxRadioBox *m_icons;

    wxCheckBox *m_chkNoDefault,
               *m_chkCentre;

    DECLARE_EVENT_TABLE()
    wxDECLARE_NO_COPY_CLASS(TestMessageBoxDialog);
};

class TestDefaultActionDialog: public wxDialog
{
public:
    TestDefaultActionDialog( wxWindow *parent );

    void OnListBoxDClick(wxCommandEvent& event);
    void OnDisableOK(wxCommandEvent& event);
    void OnDisableCancel(wxCommandEvent& event);
    void OnCatchListBoxDClick(wxCommandEvent& event);
    void OnTextEnter(wxCommandEvent& event);

private:
    bool   m_catchListBoxDClick;

private:
    DECLARE_EVENT_TABLE()
};

#if USE_SETTINGS_DIALOG
// Property sheet dialog
class SettingsDialog: public wxPropertySheetDialog
{
DECLARE_CLASS(SettingsDialog)
public:
    SettingsDialog(wxWindow* parent, int dialogType);
    ~SettingsDialog();

    wxPanel* CreateGeneralSettingsPage(wxWindow* parent);
    wxPanel* CreateAestheticSettingsPage(wxWindow* parent);
    wxPanel* CreateGeneral2SettingsPage(wxWindow* parent);
    wxPanel* CreateAesthetic2SettingsPage(wxWindow* parent);
    void OnChk12(wxCommandEvent&);
    void OnRad13(wxCommandEvent&);
    void OnChk14(wxCommandEvent&);
    void OnRad15(wxCommandEvent&);

protected:

    enum {
        ID_SHOW_TOOLTIPS = 100,
        ID_AUTO_SAVE,
        ID_AUTO_SAVE_MINS,
        ID_LOAD_LAST_PROJECT,

        ID_SHOW_TOOLTIPS2,
        ID_AUTO_SAVE2,
        ID_AUTO_SAVE_MINS2,
        ID_LOAD_LAST_PROJECT2,

        ID_SHOW_TOOLTIPS3,
        ID_AUTO_SAVE3,
        ID_AUTO_SAVE_MINS3,
        ID_LOAD_LAST_PROJECT3,

        ID_SHOW_TOOLTIPS4,
        ID_AUTO_SAVE4,
        ID_AUTO_SAVE_MINS4,
        ID_LOAD_LAST_PROJECT4
    };

    wxImageList*    m_imageList;

DECLARE_EVENT_TABLE()
};

#endif // USE_SETTINGS_DIALOG

// Define a new frame type
class MyFrame: public wxFrame
{
public:
    MyFrame(const wxString& title);
    virtual ~MyFrame();

    void Rearrange(wxCommandEvent& event);

    void OnPropertySheet(wxCommandEvent& event);

#if wxUSE_ABOUTDLG
    void ShowSimpleAboutDialog(wxCommandEvent& event);
    void ShowFancyAboutDialog(wxCommandEvent& event);
    void ShowFullAboutDialog(wxCommandEvent& event);
    void ShowCustomAboutDialog(wxCommandEvent& event);
#endif // wxUSE_ABOUTDLG

    void OnTestDefaultActionDialog(wxCommandEvent& event);

    void OnExit(wxCommandEvent& event);

private:

    // just a window which we use to show the effect of font/colours selection
    wxWindow *m_canvas;

    DECLARE_EVENT_TABLE()
};

class MyCanvas: public wxScrolledWindow
{
public:
    MyCanvas(wxWindow *parent) : wxScrolledWindow(parent, wxID_ANY)
    {
        SetForegroundColour(*wxBLACK);
        SetBackgroundColour(*wxWHITE);
        SetFont(*wxNORMAL_FONT);
    }

private:
    void OnPaint(wxPaintEvent& event);

    DECLARE_EVENT_TABLE()
};


// Menu IDs
enum
{
    DIALOGS_CHOOSE_COLOUR = wxID_HIGHEST,
    DIALOGS_GET_COLOUR,
    DIALOGS_CHOOSE_COLOUR_GENERIC,
    DIALOGS_CHOOSE_FONT,
    DIALOGS_CHOOSE_FONT_GENERIC,
    DIALOGS_MESSAGE_BOX,
    DIALOGS_MESSAGE_BOX_WINDOW_MODAL,
    DIALOGS_MESSAGE_DIALOG,
    DIALOGS_MESSAGE_BOX_WXINFO,
    DIALOGS_RICH_MESSAGE_DIALOG,
    DIALOGS_SINGLE_CHOICE,
    DIALOGS_MULTI_CHOICE,
    DIALOGS_REARRANGE,
    DIALOGS_LINE_ENTRY,
    DIALOGS_TEXT_ENTRY,
    DIALOGS_PASSWORD_ENTRY,
    DIALOGS_FILE_OPEN,
    DIALOGS_FILE_OPEN2,
    DIALOGS_FILES_OPEN,
    DIALOGS_FILE_SAVE,
    DIALOGS_FILE_OPEN_GENERIC,
    DIALOGS_FILES_OPEN_GENERIC,
    DIALOGS_FILE_SAVE_GENERIC,
    DIALOGS_DIR_CHOOSE,
    DIALOGS_DIRNEW_CHOOSE,
    DIALOGS_GENERIC_DIR_CHOOSE,
    DIALOGS_TIP,
    DIALOGS_NUM_ENTRY,
    DIALOGS_LOG_DIALOG,
    DIALOGS_INFOBAR_SIMPLE,
    DIALOGS_INFOBAR_ADVANCED,
    DIALOGS_MODAL,
    DIALOGS_MODELESS,
    DIALOGS_CENTRE_SCREEN,
    DIALOGS_CENTRE_PARENT,
    DIALOGS_MINIFRAME,
    DIALOGS_ONTOP,
    DIALOGS_MODELESS_BTN,
    DIALOGS_PROGRESS,
    DIALOGS_ABOUTDLG_SIMPLE,
    DIALOGS_ABOUTDLG_FANCY,
    DIALOGS_ABOUTDLG_FULL,
    DIALOGS_ABOUTDLG_CUSTOM,
    DIALOGS_BUSYINFO,
    DIALOGS_FIND,
    DIALOGS_REPLACE,
    DIALOGS_REQUEST,
    DIALOGS_NOTIFY_AUTO,
    DIALOGS_NOTIFY_SHOW,
    DIALOGS_NOTIFY_HIDE,
    DIALOGS_RICHTIP_DIALOG,
    DIALOGS_PROPERTY_SHEET,
    DIALOGS_PROPERTY_SHEET_TOOLBOOK,
    DIALOGS_PROPERTY_SHEET_BUTTONTOOLBOOK,
    DIALOGS_STANDARD_BUTTON_SIZER_DIALOG,
    DIALOGS_TEST_DEFAULT_ACTION
};

#endif

