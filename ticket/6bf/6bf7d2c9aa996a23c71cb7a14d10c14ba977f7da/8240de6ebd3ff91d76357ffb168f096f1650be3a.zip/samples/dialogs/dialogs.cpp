/////////////////////////////////////////////////////////////////////////////
// Name:        dialogs.cpp (MODIFIED)
// Purpose:     Common dialogs demo
// Author:      Julian Smart, Vadim Zeitlin, ABX
// Created:     04/01/98
// RCS-ID:      $Id: dialogs.cpp 70412 2012-01-20 16:51:09Z DS $
// Copyright:   (c) Julian Smart
//              (c) 2004 ABX
//              (c) Vadim Zeitlin
// Licence:     wxWindows licence
/////////////////////////////////////////////////////////////////////////////

// NEED THIS (for Solaris) SINCE USE OF Bind() HAS BEEN ADDED TO DEMO.
#define wxHAS_EVENT_BIND

// For compilers that support precompilation, includes "wx/wx.h".
#include "wx/wxprec.h"

#ifdef __BORLANDC__
#pragma hdrstop
#endif

#ifndef WX_PRECOMP
#include "wx/wx.h"
#endif

#include "../sample.xpm"

#include "wx/apptrait.h"
#include "wx/datetime.h"
#include "wx/image.h"
#include "wx/bookctrl.h"
#include "wx/artprov.h"
#include "wx/imaglist.h"
#include "wx/minifram.h"
#include "wx/sysopt.h"
#include "wx/notifmsg.h"
#include "wx/checkbox.h"
#include "wx/radiobut.h"

#if wxUSE_ABOUTDLG
    #include "wx/aboutdlg.h"

    // these headers are only needed for custom about dialog
    #include "wx/statline.h"
    #include "wx/generic/aboutdlgg.h"
#endif // wxUSE_ABOUTDLG

#include "wx/propdlg.h"

#include "dialogs.h"

IMPLEMENT_APP(MyApp)

BEGIN_EVENT_TABLE(MyCanvas, wxScrolledWindow)
    EVT_PAINT(MyCanvas::OnPaint)
END_EVENT_TABLE()



BEGIN_EVENT_TABLE(MyFrame, wxFrame)

#if USE_SETTINGS_DIALOG
    EVT_MENU(DIALOGS_PROPERTY_SHEET,                MyFrame::OnPropertySheet)
#endif // USE_SETTINGS_DIALOG

    EVT_MENU(wxID_EXIT,                             MyFrame::OnExit)
END_EVENT_TABLE()

// `Main program' equivalent, creating windows and returning main app frame
bool MyApp::OnInit()
{
    if ( !wxApp::OnInit() )
        return false;

#if wxUSE_IMAGE
    wxInitAllImageHandlers();
#endif

    // Create the main frame window
    MyFrame *frame = new MyFrame(wxT("wxWidgets dialogs example"));

    // Make a menubar
    wxMenu *menuDlg = new wxMenu;

#if USE_SETTINGS_DIALOG
    menuDlg->Append(DIALOGS_PROPERTY_SHEET, wxT("&Standard property sheet\tShift-Ctrl-P"));
#endif // USE_SETTINGS_DIALOG

    menuDlg->AppendSeparator();
    menuDlg->Append(wxID_EXIT, wxT("E&xit\tAlt-X"));

#if wxUSE_ABOUTDLG
    wxMenu *menuHelp = new wxMenu;
    menuHelp->Append(DIALOGS_ABOUTDLG_SIMPLE, wxT("&About (simple)...\tF1"));
    menuHelp->Append(DIALOGS_ABOUTDLG_FANCY, wxT("About (&fancy)...\tShift-F1"));
    menuHelp->Append(DIALOGS_ABOUTDLG_FULL, wxT("About (f&ull)...\tCtrl-F1"));
    menuHelp->Append(DIALOGS_ABOUTDLG_CUSTOM, wxT("About (&custom)...\tCtrl-Shift-F1"));
#endif // wxUSE_ABOUTDLG

    wxMenu* editMenu = new wxMenu;
    editMenu->Append(wxID_UNDO, _("&Undo\tCtrl+Z"));
    editMenu->Append(wxID_REDO, _("&Redo\tCtrl+Y"));
    editMenu->AppendSeparator();
    editMenu->Append(wxID_CUT, _("Cu&t\tCtrl+X"));
    editMenu->Append(wxID_COPY, _("&Copy\tCtrl+C"));
    editMenu->Append(wxID_PASTE, _("&Paste\tCtrl+V"));
    editMenu->Append(wxID_CLEAR, _("&Delete"));
    
    editMenu->AppendSeparator();
    editMenu->Append(wxID_SELECTALL, _("Select All\tCtrl+A"));

    wxMenuBar *menubar = new wxMenuBar;
    menubar->Append(menuDlg, wxT("&Dialogs"));
    
    menubar->Append(editMenu, wxT("&Edit"));
    
#if wxUSE_ABOUTDLG
    menubar->Append(menuHelp, wxT("&Help"));
#endif // wxUSE_ABOUTDLG

    frame->SetMenuBar(menubar);

    frame->Centre(wxBOTH);
    frame->Show(true);

    return true;
}

// My frame constructor
MyFrame::MyFrame(const wxString& title)
       : wxFrame(NULL, wxID_ANY, title)
{
    SetIcon(wxICON(sample));

#if wxUSE_STATUSBAR
    CreateStatusBar();
#endif // wxUSE_STATUSBAR

    m_canvas = new MyCanvas(this);

#ifdef __WXMSW__
    // Test MSW-specific function allowing to access the "system" menu.
    wxMenu * const menu = MSWGetSystemMenu();
    if ( menu )
    {
        menu->AppendSeparator();

        // The ids of the menu commands in MSW system menu must be multiple of
        // 16 so we can't use DIALOGS_ABOUTDLG_SIMPLE here because it might not
        // satisfy this condition and need to define and connect a separate id.
        static const int DIALOGS_SYSTEM_ABOUT = 0x4010;

        menu->Append(DIALOGS_SYSTEM_ABOUT, "&About");
        Connect(DIALOGS_SYSTEM_ABOUT, wxEVT_COMMAND_MENU_SELECTED,
                wxCommandEventHandler(MyFrame::ShowSimpleAboutDialog));
    }
#endif // __WXMSW__
}

MyFrame::~MyFrame()
{
}

#if USE_SETTINGS_DIALOG
void MyFrame::OnPropertySheet(wxCommandEvent& event)
{
    SettingsDialog dialog(this, event.GetId());
    dialog.ShowModal();
}
#endif // USE_SETTINGS_DIALOG

void MyFrame::OnExit(wxCommandEvent& WXUNUSED(event) )
{
    Close(true);
}

#if wxUSE_ABOUTDLG

static void InitAboutInfoMinimal(wxAboutDialogInfo& info)
{
    info.SetName(wxT("Dialogs Sample"));
    info.SetVersion(wxVERSION_NUM_DOT_STRING,
                    wxString::Format
                    (
                        "%s version %s",
                        wxMINOR_VERSION % 2 ? "Development" : "Stable",
                        wxVERSION_NUM_DOT_STRING
                    ));
    info.SetDescription(wxT("This sample shows different wxWidgets dialogs"));
    info.SetCopyright(wxT("(C) 1998-2006 wxWidgets dev team"));
    info.AddDeveloper(wxT("Vadim Zeitlin"));
}

static void InitAboutInfoWebsite(wxAboutDialogInfo& info)
{
    InitAboutInfoMinimal(info);

    info.SetWebSite(wxT("http://www.wxwidgets.org/"), wxT("wxWidgets web site"));
}

static void InitAboutInfoAll(wxAboutDialogInfo& info)
{
    InitAboutInfoWebsite(info);

    // we can add a second developer
    info.AddDeveloper(wxT("A.N. Other"));

    // or we can add several persons at once like this
    static const wxChar *docwriters[] =
    {
        wxT("First D. Writer"),
        wxT("Second One"),
    };

    info.SetDocWriters(wxArrayString(WXSIZEOF(docwriters), docwriters));
    info.SetLicence(wxString::FromAscii(
"                wxWindows Library Licence, Version 3.1\n"
"                ======================================\n"
"\n"
"  Copyright (c) 1998-2005 Julian Smart, Robert Roebling et al\n"
"\n"
"  Everyone is permitted to copy and distribute verbatim copies\n"
"  of this licence document, but changing it is not allowed.\n"
"\n"
"                       WXWINDOWS LIBRARY LICENCE\n"
"     TERMS AND CONDITIONS FOR COPYING, DISTRIBUTION AND MODIFICATION\n"
"\n"
"                    ...and so on and so forth...\n"
    ));

    info.AddTranslator(wxT("Wun Ngo Wen (Martian)"));
}

void MyFrame::ShowSimpleAboutDialog(wxCommandEvent& WXUNUSED(event))
{
    wxAboutDialogInfo info;
    InitAboutInfoMinimal(info);

    wxAboutBox(info, this);
}

void MyFrame::ShowFancyAboutDialog(wxCommandEvent& WXUNUSED(event))
{
    wxAboutDialogInfo info;
    InitAboutInfoWebsite(info);

    wxAboutBox(info, this);
}

void MyFrame::ShowFullAboutDialog(wxCommandEvent& WXUNUSED(event))
{
    wxAboutDialogInfo info;
    InitAboutInfoAll(info);

    wxAboutBox(info, this);
}

// a trivial example of a custom dialog class
class MyAboutDialog : public wxGenericAboutDialog
{
public:
    MyAboutDialog(const wxAboutDialogInfo& info, wxWindow* parent)
    {
        Create(info, parent);
    }

    // add some custom controls
    virtual void DoAddCustomControls()
    {
        AddControl(new wxStaticLine(this), wxSizerFlags().Expand());
        AddText(wxT("Some custom text"));
        AddControl(new wxStaticLine(this), wxSizerFlags().Expand());
    }
};

void MyFrame::ShowCustomAboutDialog(wxCommandEvent& WXUNUSED(event))
{
    wxAboutDialogInfo info;
    InitAboutInfoAll(info);

    MyAboutDialog dlg(info, this);
    dlg.ShowModal();
}

#endif // wxUSE_ABOUTDLG

// ----------------------------------------------------------------------------
// MyCanvas
// ----------------------------------------------------------------------------

void MyCanvas::OnPaint(wxPaintEvent& WXUNUSED(event) )
{
    wxPaintDC dc(this);
    dc.SetBackgroundMode(wxTRANSPARENT);
    dc.DrawText(
                wxT("wxWidgets common dialogs")
#if !defined(__SMARTPHONE__)
                wxT(" test application")
#endif
                , 10, 10);
}

#if USE_SETTINGS_DIALOG
// ----------------------------------------------------------------------------
// SettingsDialog
// ----------------------------------------------------------------------------

IMPLEMENT_CLASS(SettingsDialog, wxPropertySheetDialog)

BEGIN_EVENT_TABLE(SettingsDialog, wxPropertySheetDialog)
END_EVENT_TABLE()

SettingsDialog::SettingsDialog(wxWindow* win, int WXUNUSED(dialogType))
{
    SetExtraStyle(wxDIALOG_EX_CONTEXTHELP|wxWS_EX_VALIDATE_RECURSIVELY);

    m_imageList = NULL;

    Create(win, wxID_ANY, _("Preferences"), wxDefaultPosition, wxDefaultSize,
        wxDEFAULT_DIALOG_STYLE| (int)wxPlatform::IfNot(wxOS_WINDOWS_CE, wxRESIZE_BORDER)
    );

    // If using a toolbook, also follow Mac style and don't create buttons
    CreateButtons(wxOK | wxCANCEL |
                    (int)wxPlatform::IfNot(wxOS_WINDOWS_CE, wxHELP)
    );

    wxBookCtrlBase* notebook = GetBookCtrl();
    notebook->SetImageList(m_imageList);

    wxPanel* generalSettings = CreateGeneralSettingsPage(notebook);
    wxPanel* aestheticSettings = CreateAestheticSettingsPage(notebook);
    wxPanel* general2Settings = CreateGeneral2SettingsPage(notebook);
    wxPanel* aesthetic2Settings = CreateAesthetic2SettingsPage(notebook);

    notebook->AddPage(generalSettings, _("Bad CB"), true, -1);
    notebook->AddPage(aestheticSettings, _("Bad RB"), false, -1);
    notebook->AddPage(general2Settings, _("Good CB"), false, -1);
    notebook->AddPage(aesthetic2Settings, _("Good RB"), false, -1);

    LayoutDialog();
}

SettingsDialog::~SettingsDialog()
{
    delete m_imageList;
}

static wxCheckBox* checkBox12;
static wxTextCtrl* textCtrl12;

wxPanel* SettingsDialog::CreateGeneralSettingsPage(wxWindow* parent)
{
    wxPanel* panel = new wxPanel(parent, wxID_ANY);

    wxBoxSizer *topSizer = new wxBoxSizer( wxVERTICAL );
    wxBoxSizer *item0 = new wxBoxSizer( wxVERTICAL );

    //// AUTOSAVE

    wxString autoSaveLabel = _("&Auto-save every");
    wxString minsLabel = _("mins");

    wxBoxSizer* itemSizer12 = new wxBoxSizer( wxHORIZONTAL );
    checkBox12 = new wxCheckBox(panel, ID_AUTO_SAVE, autoSaveLabel, wxDefaultPosition, wxDefaultSize);

    textCtrl12 = new wxTextCtrl(panel, ID_AUTO_SAVE_MINS, wxEmptyString,
        wxDefaultPosition, wxSize(40, wxDefaultCoord));

    itemSizer12->Add(checkBox12, 0, wxALL|wxALIGN_CENTER_VERTICAL, 5);
    itemSizer12->Add(textCtrl12, 0, wxALL|wxALIGN_CENTER_VERTICAL, 5);
    itemSizer12->Add(new wxStaticText(panel, wxID_STATIC, minsLabel), 0, wxALL|wxALIGN_CENTER_VERTICAL, 5);
    item0->Add(itemSizer12, 0, wxGROW|wxALL, 0);

    textCtrl12->Enable(false);
    checkBox12->Bind(wxEVT_COMMAND_CHECKBOX_CLICKED,
                        &SettingsDialog::OnChk12, this);

    //// LOAD LAST FILE

    wxBoxSizer* itemSizer3 = new wxBoxSizer( wxHORIZONTAL );
    wxCheckBox* checkBox3 = new wxCheckBox(panel, ID_LOAD_LAST_PROJECT, _("&Load last project on startup"), wxDefaultPosition, wxDefaultSize);
    itemSizer3->Add(checkBox3, 0, wxALL|wxALIGN_CENTER_VERTICAL, 5);
    item0->Add(itemSizer3, 0, wxGROW|wxALL, 0);

    //// TOOLTIPS

    wxBoxSizer* itemSizer8 = new wxBoxSizer( wxHORIZONTAL );
    wxCheckBox* checkBox6 = new wxCheckBox(panel, ID_SHOW_TOOLTIPS, _("Show &tooltips"), wxDefaultPosition, wxDefaultSize);
    itemSizer8->Add(checkBox6, 0, wxALL|wxALIGN_CENTER_VERTICAL, 5);
    item0->Add(itemSizer8, 0, wxGROW|wxALL, 0);

    topSizer->Add( item0, 1, wxGROW|wxALIGN_CENTRE|wxALL, 5 );

    panel->SetSizerAndFit(topSizer);

    return panel;
}

void SettingsDialog::OnChk12(wxCommandEvent&)
{
    if (checkBox12->IsChecked())
    {
        textCtrl12->Enable(true);
        // Display problem happens even if SetFocus() is not done.
        textCtrl12->SetFocus();
    }
    else
        textCtrl12->Enable(false);
}

static wxRadioButton* radioBtn13;
static wxTextCtrl* textCtrl13;

wxPanel* SettingsDialog::CreateAestheticSettingsPage(wxWindow* parent)
{
    wxPanel* panel = new wxPanel(parent, wxID_ANY);

    wxBoxSizer *topSizer = new wxBoxSizer( wxVERTICAL );
    wxBoxSizer *item0 = new wxBoxSizer( wxVERTICAL );

    //// LOAD LAST FILE

    wxBoxSizer* itemSizer3 = new wxBoxSizer( wxHORIZONTAL );
    wxRadioButton* radioBtn3 = new wxRadioButton(panel, ID_LOAD_LAST_PROJECT2, _("&Load last project on startup"), wxDefaultPosition, wxDefaultSize, wxRB_GROUP);
    itemSizer3->Add(radioBtn3, 0, wxALL|wxALIGN_CENTER_VERTICAL, 5);
    item0->Add(itemSizer3, 0, wxGROW|wxALL, 0);
    radioBtn3->Bind(wxEVT_COMMAND_RADIOBUTTON_SELECTED,
                        &SettingsDialog::OnRad13, this);

    //// AUTOSAVE

    wxString autoSaveLabel = _("&Auto-save every");
    wxString minsLabel = _("mins");

    wxBoxSizer* itemSizer12 = new wxBoxSizer( wxHORIZONTAL );
    radioBtn13 = new wxRadioButton(panel, ID_AUTO_SAVE2, autoSaveLabel, wxDefaultPosition, wxDefaultSize);

    textCtrl13 = new wxTextCtrl(panel, ID_AUTO_SAVE_MINS2, wxEmptyString,
        wxDefaultPosition, wxSize(40, wxDefaultCoord));

    itemSizer12->Add(radioBtn13, 0, wxALL|wxALIGN_CENTER_VERTICAL, 5);
    itemSizer12->Add(textCtrl13, 0, wxALL|wxALIGN_CENTER_VERTICAL, 5);
    itemSizer12->Add(new wxStaticText(panel, wxID_STATIC, minsLabel), 0, wxALL|wxALIGN_CENTER_VERTICAL, 5);
    item0->Add(itemSizer12, 0, wxGROW|wxALL, 0);

    textCtrl13->Enable(false);
    radioBtn13->Bind(wxEVT_COMMAND_RADIOBUTTON_SELECTED,
                        &SettingsDialog::OnRad13, this);

    //// TOOLTIPS

    wxBoxSizer* itemSizer8 = new wxBoxSizer( wxHORIZONTAL );
    wxRadioButton* radioBtn6 = new wxRadioButton(panel, ID_SHOW_TOOLTIPS2, _("Show &tooltips"), wxDefaultPosition, wxDefaultSize);
    itemSizer8->Add(radioBtn6, 0, wxALL|wxALIGN_CENTER_VERTICAL, 5);
    item0->Add(itemSizer8, 0, wxGROW|wxALL, 0);
    radioBtn6->Bind(wxEVT_COMMAND_RADIOBUTTON_SELECTED,
                        &SettingsDialog::OnRad13, this);

    topSizer->Add( item0, 1, wxGROW|wxALIGN_CENTRE|wxALL, 5 );

    panel->SetSizerAndFit(topSizer);
    radioBtn3->SetValue(true);

    return panel;
}

void SettingsDialog::OnRad13(wxCommandEvent&)
{
    if (radioBtn13->GetValue())
    {
        textCtrl13->Enable(true);
        // Display problem happens even if SetFocus() is not done.
        textCtrl13->SetFocus();
    }
    else
        textCtrl13->Enable(false);
}

static wxCheckBox* checkBox14;
static wxTextCtrl* textCtrl14;

wxPanel* SettingsDialog::CreateGeneral2SettingsPage(wxWindow* parent)
{
    wxPanel* panel = new wxPanel(parent, wxID_ANY);

    wxBoxSizer *topSizer = new wxBoxSizer( wxVERTICAL );
    wxBoxSizer *item0 = new wxBoxSizer( wxVERTICAL );

    //// AUTOSAVE

    wxString autoSaveLabel = _("&Auto-save every");
    wxString minsLabel = _("mins");

    wxBoxSizer* itemSizer12 = new wxBoxSizer( wxHORIZONTAL );
    checkBox14 = new wxCheckBox(panel, ID_AUTO_SAVE3, autoSaveLabel, wxDefaultPosition, wxDefaultSize);

    textCtrl14 = new wxTextCtrl(panel, ID_AUTO_SAVE_MINS3, wxEmptyString,
        wxDefaultPosition, wxSize(40, wxDefaultCoord));

    itemSizer12->Add(checkBox14, 0, wxALL|wxALIGN_CENTER_VERTICAL, 5);
    itemSizer12->Add(textCtrl14, 0, wxALL|wxALIGN_CENTER_VERTICAL, 5);
    itemSizer12->Add(new wxStaticText(panel, wxID_STATIC, minsLabel), 0, wxALL|wxALIGN_CENTER_VERTICAL, 5);
    item0->Add(itemSizer12, 0, wxGROW|wxALL, 0);

    //textCtrl14->Enable(false);
    checkBox14->Bind(wxEVT_COMMAND_CHECKBOX_CLICKED,
                        &SettingsDialog::OnChk14, this);

    //// LOAD LAST FILE

    wxBoxSizer* itemSizer3 = new wxBoxSizer( wxHORIZONTAL );
    wxCheckBox* checkBox3 = new wxCheckBox(panel, ID_LOAD_LAST_PROJECT3, _("&Load last project on startup"), wxDefaultPosition, wxDefaultSize);
    itemSizer3->Add(checkBox3, 0, wxALL|wxALIGN_CENTER_VERTICAL, 5);
    item0->Add(itemSizer3, 0, wxGROW|wxALL, 0);

    //// TOOLTIPS

    wxBoxSizer* itemSizer8 = new wxBoxSizer( wxHORIZONTAL );
    wxCheckBox* checkBox6 = new wxCheckBox(panel, ID_SHOW_TOOLTIPS3, _("Show &tooltips"), wxDefaultPosition, wxDefaultSize);
    itemSizer8->Add(checkBox6, 0, wxALL|wxALIGN_CENTER_VERTICAL, 5);
    item0->Add(itemSizer8, 0, wxGROW|wxALL, 0);

    topSizer->Add( item0, 1, wxGROW|wxALIGN_CENTRE|wxALL, 5 );

    panel->SetSizerAndFit(topSizer);

    return panel;
}

void SettingsDialog::OnChk14(wxCommandEvent&)
{
    if (checkBox14->IsChecked())
    {
        //textCtrl14->Enable(true);
        // Display problem happens even if SetFocus() is not done.
        textCtrl14->SetFocus();
    }
    //else
        //textCtrl14->Enable(false);
}

static wxRadioButton* radioBtn15;
static wxTextCtrl* textCtrl15;

wxPanel* SettingsDialog::CreateAesthetic2SettingsPage(wxWindow* parent)
{
    wxPanel* panel = new wxPanel(parent, wxID_ANY);

    wxBoxSizer *topSizer = new wxBoxSizer( wxVERTICAL );
    wxBoxSizer *item0 = new wxBoxSizer( wxVERTICAL );

    //// LOAD LAST FILE

    wxBoxSizer* itemSizer3 = new wxBoxSizer( wxHORIZONTAL );
    wxRadioButton* radioBtn3 = new wxRadioButton(panel, ID_LOAD_LAST_PROJECT4, _("&Load last project on startup"), wxDefaultPosition, wxDefaultSize, wxRB_GROUP);
    itemSizer3->Add(radioBtn3, 0, wxALL|wxALIGN_CENTER_VERTICAL, 5);
    item0->Add(itemSizer3, 0, wxGROW|wxALL, 0);
    radioBtn3->Bind(wxEVT_COMMAND_RADIOBUTTON_SELECTED,
                        &SettingsDialog::OnRad15, this);

    //// AUTOSAVE

    wxString autoSaveLabel = _("&Auto-save every");
    wxString minsLabel = _("mins");

    wxBoxSizer* itemSizer12 = new wxBoxSizer( wxHORIZONTAL );
    radioBtn15 = new wxRadioButton(panel, ID_AUTO_SAVE4, autoSaveLabel, wxDefaultPosition, wxDefaultSize);

    textCtrl15 = new wxTextCtrl(panel, ID_AUTO_SAVE_MINS4, wxEmptyString,
        wxDefaultPosition, wxSize(40, wxDefaultCoord));

    itemSizer12->Add(radioBtn15, 0, wxALL|wxALIGN_CENTER_VERTICAL, 5);
    itemSizer12->Add(textCtrl15, 0, wxALL|wxALIGN_CENTER_VERTICAL, 5);
    itemSizer12->Add(new wxStaticText(panel, wxID_STATIC, minsLabel), 0, wxALL|wxALIGN_CENTER_VERTICAL, 5);
    item0->Add(itemSizer12, 0, wxGROW|wxALL, 0);

    //textCtrl15->Enable(false);
    radioBtn15->Bind(wxEVT_COMMAND_RADIOBUTTON_SELECTED,
                        &SettingsDialog::OnRad15, this);

    //// TOOLTIPS

    wxBoxSizer* itemSizer8 = new wxBoxSizer( wxHORIZONTAL );
    wxRadioButton* radioBtn6 = new wxRadioButton(panel, ID_SHOW_TOOLTIPS4, _("Show &tooltips"), wxDefaultPosition, wxDefaultSize);
    itemSizer8->Add(radioBtn6, 0, wxALL|wxALIGN_CENTER_VERTICAL, 5);
    item0->Add(itemSizer8, 0, wxGROW|wxALL, 0);
    radioBtn6->Bind(wxEVT_COMMAND_RADIOBUTTON_SELECTED,
                        &SettingsDialog::OnRad15, this);

    topSizer->Add( item0, 1, wxGROW|wxALIGN_CENTRE|wxALL, 5 );

    panel->SetSizerAndFit(topSizer);
    radioBtn3->SetValue(true);

    return panel;
}

void SettingsDialog::OnRad15(wxCommandEvent&)
{
    if (radioBtn15->GetValue())
    {
        //textCtrl15->Enable(true);
        // Display problem happens even if SetFocus() is not done.
        textCtrl15->SetFocus();
    }
    //else
        //textCtrl15->Enable(false);
}

#endif // USE_SETTINGS_DIALOG
