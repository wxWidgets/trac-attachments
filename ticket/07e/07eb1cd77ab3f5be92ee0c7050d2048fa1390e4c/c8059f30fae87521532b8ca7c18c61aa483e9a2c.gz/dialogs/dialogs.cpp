/////////////////////////////////////////////////////////////////////////////
// Name:        dialogs.cpp
// Purpose:     Common dialogs demo
// Author:      Julian Smart
// Modified by:
// Created:     04/01/98
// RCS-ID:      $Id: dialogs.cpp,v 1.85.2.4 2002/12/13 21:38:50 MBN Exp $
// Copyright:   (c) Julian Smart and Markus Holzem
// Licence:     wxWindows license
/////////////////////////////////////////////////////////////////////////////

#ifdef __GNUG__
#pragma implementation
#pragma interface
#endif

// For compilers that support precompilation, includes "wx/wx.h".
#include "wx/wxprec.h"

#ifdef __BORLANDC__
#pragma hdrstop
#endif

#ifndef WX_PRECOMP
#include "wx/wx.h"
#endif

#include "wx/notebook.h"
#include "dialogs.h"

IMPLEMENT_APP(MyApp)


BEGIN_EVENT_TABLE(MyFrame, wxFrame)
    EVT_MENU(DIALOGS_MODAL,                         MyFrame::ModalDlg)
    EVT_MENU(wxID_EXIT,                             MyFrame::OnExit)
END_EVENT_TABLE()


// `Main program' equivalent, creating windows and returning main app frame
bool MyApp::OnInit()
{
#if defined(__WXGTK__) && defined(wxUSE_UNICODE)
  wxConvCurrent = &wxConvLibc;
#endif

  // Create the main frame window
  MyFrame *frame = new MyFrame((wxFrame *) NULL, _T("wxWindows dialogs example"), wxPoint(20, 20), wxSize(400, 300));

  // Make a menubar
  wxMenu *file_menu = new wxMenu;

  file_menu->Append(DIALOGS_MODAL, _T("Mo&dal dialog\tCtrl-W"));
  file_menu->AppendSeparator();
  file_menu->Append(wxID_EXIT, _T("E&xit\tAlt-X"));
  wxMenuBar *menu_bar = new wxMenuBar;
  menu_bar->Append(file_menu, _T("&File"));
  frame->SetMenuBar(menu_bar);

  frame->Centre(wxBOTH);

  // Show the frame
  frame->Show(TRUE);

  SetTopWindow(frame);

  return TRUE;
}

// My frame constructor
MyFrame::MyFrame(wxWindow *parent,
                 const wxString& title,
                 const wxPoint& pos,
                 const wxSize& size)
       : wxFrame(parent, -1, title, pos, size)
{

    CreateStatusBar();
}

void MyFrame::ModalDlg(wxCommandEvent& WXUNUSED(event))
{
    MyModalDialog dlg(this);
    dlg.ShowModal();
}

void MyFrame::OnExit(wxCommandEvent& WXUNUSED(event) )
{
    Close(TRUE);
}


// ----------------------------------------------------------------------------
// MyModalDialog
// ----------------------------------------------------------------------------

MyModalDialog::MyModalDialog(wxWindow *p)
             : wxDialog(p, -1, wxString(_T("Modal dialog")), wxDefaultPosition,
             wxDefaultSize, wxDEFAULT_DIALOG_STYLE|wxRESIZE_BORDER)
{
    wxBoxSizer *dialogSizer = new wxBoxSizer( wxVERTICAL );

    ScrolledWindowContainer* panel = new ScrolledWindowContainer( this );
    
    dialogSizer->Add( panel, 1, wxGROW|wxALIGN_RIGHT|wxALIGN_CENTER_VERTICAL, 5 );
    dialogSizer->Add( new wxButton( this,
			            wxID_CANCEL,
				    _("&Cancel"),
				    wxDefaultPosition,
				    wxDefaultSize,
				    0 ),
		      0, wxALIGN_CENTRE|wxLEFT|wxBOTTOM, 5 );
    
    // Done by SetSizer in 2.4
    //SetAutoLayout( TRUE );
    SetSizer( dialogSizer );
    GetSizer()->SetSizeHints(this);

    panel->AdjustPropertyScrollbars();

    Centre(wxBOTH);
}


/* Any panel with a scrolling sub-panel containing
 * properties
 */

IMPLEMENT_CLASS(ScrolledWindowContainer, wxPanel)

ScrolledWindowContainer::ScrolledWindowContainer(wxWindow* win):
    wxPanel(win, -1, wxDefaultPosition, wxDefaultSize)
{
    wxBoxSizer *parentSizer = new wxBoxSizer( wxVERTICAL );

    m_scrolledWindow = new wxScrolledWindow(this, -1,
        wxDefaultPosition, wxSize(300, 100), wxSUNKEN_BORDER|wxTAB_TRAVERSAL);

    // Ideally done once here, but added below to make the logical
    // difference and debugging in this example a little clearer.
    //m_scrolledWindow->SetScrollRate( 0, 10 );

    // Now set up the layout for the children of the scrolled window
    wxBoxSizer *scrolledParentSizer = new wxBoxSizer( wxVERTICAL );
    m_scrolledWindow->SetSizer(scrolledParentSizer);

    parentSizer->Add(m_scrolledWindow, 1, wxGROW|wxALIGN_CENTER_VERTICAL|wxALL, 5 );

    int i;
    for (i = 0; i < 10; i++)
    {
        wxBoxSizer *horizSizer = new wxBoxSizer(wxHORIZONTAL);
        scrolledParentSizer->Add(horizSizer, 0, wxGROW|wxALIGN_CENTER|wxALL, 5 );

        wxTextCtrl* textCtrl1 = new wxTextCtrl(m_scrolledWindow, -1, wxT(""));
        wxTextCtrl* textCtrl2 = new wxTextCtrl(m_scrolledWindow, -1, wxT(""));

        horizSizer->Add(textCtrl1, 1, wxALIGN_CENTER_VERTICAL|wxALL, 5 );
        horizSizer->Add(textCtrl2, 1, wxALIGN_CENTER_VERTICAL|wxALL, 5 );
    }

    SetSizer( parentSizer );
    parentSizer->Fit( this );
}

void ScrolledWindowContainer::AdjustPropertyScrollbars()
{
   // Reenable this to show the bug.

#if 1

	// In this version we pit the two different methods of Scrollbar
	// management against each other.  A sizer inside a scrolled window in
	// 2.4 is capable of setting the scrollbars itself, but here we set a
	// sizer to do the initial layout and then override its operation on
	// the ScrollWin by examining the subsequent layout ourselves then
	// manually resetting the scrollbars.
	//
	// Sorry, I never catered for this in the original design.  The
	// original goal was to allow sizers to _replace_ manual calculation
	// and SetScrollbars calls by the user (but still support SetScrollbars
	// for non-sizer operation in legacy code).  I _think_ this is failing
	// under MSW because SizeEvents get optimised out if the size does not
	// actually change (and unlike gtk the initial SizeEvent happens before
	// ctor execution is complete rather than after it).  At construction
	// the original size event probably sets things correctly, but then the
	// subsequent SetScrollbars call mangles the layout in the way we saw
	// (width=0), and the SizeEvent that should have set things right never
	// arrives at the ScrollWin because the size does not actually change
	// anymore.
	//
	// It 'works' after a resize because we never catch the size event here
	// and then remangle the layout with another call to SetScrollbars, so
	// the automatic sizer operation does the right thing without facing
	// any further 'interference'.


    // Give the layout as much vertical space as it wants
    m_scrolledWindow->SetScrollbars(0, 1, 0 , 10000);
    m_scrolledWindow->Layout();

    // Then set the real virtual size
    // Find the size we'll have to set the scrollbars to.
    wxPoint pt(0, 0);
    wxNode* node = m_scrolledWindow->GetChildren().First();
    while (node)
    {
        wxWindow* win = (wxWindow*) node->Data();
        wxRect rect = win->GetRect();
        if (rect.GetRight() > pt.x)
            pt.x = rect.GetRight();
        if (rect.GetBottom() > pt.y)
            pt.y = rect.GetBottom();
        node = node->Next();
    }

    // Add a bit for space at the bottom
    pt.y += 5;

    int unitSize = 10;
    int noUnits = (pt.y/unitSize) + 1;
    m_scrolledWindow->SetScrollbars(0, unitSize, 0, noUnits);

#else

	// In this example, we just let the sizers handle everything
	// for the same (but working :) end result as the code above.

    	// This really only needs to be done once.
    m_scrolledWindow->SetScrollRate( 0, 10 );

    	// And this really only needs to be done if
	// internal layout changes after construction
	// without any associated external size change.
    m_scrolledWindow->FitInside();

#endif
}

