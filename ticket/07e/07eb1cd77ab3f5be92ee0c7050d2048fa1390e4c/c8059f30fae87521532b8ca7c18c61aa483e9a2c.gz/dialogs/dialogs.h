/////////////////////////////////////////////////////////////////////////////
// Name:        dialogs.h
// Purpose:     Common dialogs demo
// Author:      Julian Smart
// Modified by:
// Created:     04/01/98
// RCS-ID:      $Id: dialogs.h,v 1.23 2002/03/28 18:57:49 RR Exp $
// Copyright:   (c) Julian Smart and Markus Holzem
// Licence:     wxWindows license
/////////////////////////////////////////////////////////////////////////////

#ifndef __DIALOGSH__
#define __DIALOGSH__

// Define a new application type
class MyApp: public wxApp
{
public:
    bool OnInit();

};

// A custom modal dialog
class MyModalDialog : public wxDialog
{
public:
    MyModalDialog(wxWindow *parent);

private:

};

// Define a new frame type
class MyFrame: public wxFrame
{
public:
    MyFrame(wxWindow *parent, const wxString& title,
            const wxPoint& pos, const wxSize& size);

    void ModalDlg(wxCommandEvent& event);
    void OnExit(wxCommandEvent& event);

private:

    DECLARE_EVENT_TABLE()
};


/* Any panel with a scrolling sub-panel containing
 * properties
 */

class ScrolledWindowContainer: public wxPanel
{
DECLARE_CLASS(ScrolledWindowContainer)
public:
    ScrolledWindowContainer(wxWindow* parent);

    void AdjustPropertyScrollbars();

    wxScrolledWindow*   m_scrolledWindow;
};


// Menu IDs
enum
{
    DIALOGS_MODAL,
};

#endif

