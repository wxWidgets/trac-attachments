/////////////////////////////////////////////////////////////////////////////
// Name:        dialogs.cpp
// Purpose:     Common dialogs demo
// Author:      Julian Smart
// Modified by:
// Created:     04/01/98
// RCS-ID:      $Id: dialogs.cpp,v 1.85.2.4 2002/12/13 21:38:50 MBN Exp $
// Copyright:   (c) Julian Smart and Markus Holzem
// Licence:     wxWindows license
/////////////////////////////////////////////////////////////////////////////

#ifdef __GNUG__
#pragma implementation
#pragma interface
#endif

// For compilers that support precompilation, includes "wx/wx.h".
#include "wx/wxprec.h"

#ifdef __BORLANDC__
#pragma hdrstop
#endif

#ifndef WX_PRECOMP
#include "wx/wx.h"
#endif

#include "wx/notebook.h"
#include "dialogs.h"

IMPLEMENT_APP(MyApp)

BEGIN_EVENT_TABLE(MyCanvas, wxScrolledWindow)
//    EVT_PAINT(MyCanvas::OnPaint)
END_EVENT_TABLE()

BEGIN_EVENT_TABLE(MyFrame, wxFrame)
    EVT_MENU(DIALOGS_MODAL,                         MyFrame::ModalDlg)
    EVT_MENU(DIALOGS_MODELESS,                      MyFrame::ModelessDlg)
    EVT_MENU(wxID_EXIT,                             MyFrame::OnExit)
END_EVENT_TABLE()

BEGIN_EVENT_TABLE(MyModalDialog, wxDialog)
    EVT_BUTTON(-1, MyModalDialog::OnButton)
END_EVENT_TABLE()

BEGIN_EVENT_TABLE(MyModelessDialog, wxDialog)
    EVT_BUTTON(DIALOGS_MODELESS_BTN, MyModelessDialog::OnButton)

    EVT_CLOSE(MyModelessDialog::OnClose)
END_EVENT_TABLE()

// `Main program' equivalent, creating windows and returning main app frame
bool MyApp::OnInit()
{
#if defined(__WXGTK__) && defined(wxUSE_UNICODE)
  wxConvCurrent = &wxConvLibc;
#endif

  // Create the main frame window
  MyFrame *frame = new MyFrame((wxFrame *) NULL, _T("wxWindows dialogs example"), wxPoint(20, 20), wxSize(400, 300));

  // Make a menubar
  wxMenu *file_menu = new wxMenu;

  file_menu->Append(DIALOGS_MODAL, _T("Mo&dal dialog\tCtrl-W"));
  file_menu->Append(DIALOGS_MODELESS, _T("Modeless &dialog\tCtrl-Z"), _T(""), TRUE);
  file_menu->AppendSeparator();
  file_menu->Append(wxID_EXIT, _T("E&xit\tAlt-X"));
  wxMenuBar *menu_bar = new wxMenuBar;
  menu_bar->Append(file_menu, _T("&File"));
  frame->SetMenuBar(menu_bar);

  frame->Centre(wxBOTH);

  // Show the frame
  frame->Show(TRUE);

  SetTopWindow(frame);

  return TRUE;
}

// My frame constructor
MyFrame::MyFrame(wxWindow *parent,
                 const wxString& title,
                 const wxPoint& pos,
                 const wxSize& size)
       : wxFrame(parent, -1, title, pos, size)
{
    m_dialog = (MyModelessDialog *)NULL;

    CreateStatusBar();
}

void MyFrame::ModalDlg(wxCommandEvent& WXUNUSED(event))
{
    MyModalDialog dlg(this);
    dlg.ShowModal();
}

void MyFrame::ModelessDlg(wxCommandEvent& event)
{
    bool show = GetMenuBar()->IsChecked(event.GetId());

    if ( show )
    {
        if ( !m_dialog )
        {
            m_dialog = new MyModelessDialog(this);
        }

        m_dialog->Show(TRUE);
    }
    else // hide
    {
        m_dialog->Hide();
    }
}

void MyFrame::OnExit(wxCommandEvent& WXUNUSED(event) )
{
    Close(TRUE);
}

// ----------------------------------------------------------------------------
// MyCanvas
// ----------------------------------------------------------------------------

#if 0
void MyCanvas::OnPaint(wxPaintEvent& WXUNUSED(event) )
{
    wxPaintDC dc(this);
    dc.SetFont(wxGetApp().m_canvasFont);
    dc.SetTextForeground(wxGetApp().m_canvasTextColour);
    dc.SetBackgroundMode(wxTRANSPARENT);
    dc.DrawText(_T("wxWindows common dialogs test application"), 10, 10);
}
#endif

// ----------------------------------------------------------------------------
// MyModelessDialog
// ----------------------------------------------------------------------------

MyModelessDialog::MyModelessDialog(wxWindow *parent)
                : wxDialog(parent, -1, wxString(_T("Modeless dialog")))
{
    wxBoxSizer *sizerTop = new wxBoxSizer(wxVERTICAL);

    wxButton *btn = new wxButton(this, DIALOGS_MODELESS_BTN, _T("Press me"));
    wxCheckBox *check = new wxCheckBox(this, -1, _T("Should be disabled"));
    check->Disable();

    sizerTop->Add(btn, 1, wxEXPAND | wxALL, 5);
    sizerTop->Add(check, 1, wxEXPAND | wxALL, 5);

    SetAutoLayout(TRUE);
    SetSizer(sizerTop);

    sizerTop->SetSizeHints(this);
    sizerTop->Fit(this);
}

void MyModelessDialog::OnButton(wxCommandEvent& WXUNUSED(event))
{
    wxMessageBox(_T("Button pressed in modeless dialog"), _T("Info"),
                 wxOK | wxICON_INFORMATION, this);
}

void MyModelessDialog::OnClose(wxCloseEvent& event)
{
    if ( event.CanVeto() )
    {
        wxMessageBox(_T("Use the menu item to close this dialog"),
                     _T("Modeless dialog"),
                     wxOK | wxICON_INFORMATION, this);

        event.Veto();
    }
}

// ----------------------------------------------------------------------------
// MyModalDialog
// ----------------------------------------------------------------------------

MyModalDialog::MyModalDialog(wxWindow *p)
             : wxDialog(p, -1, wxString(_T("Modal dialog")), wxDefaultPosition,
             wxDefaultSize, wxDEFAULT_DIALOG_STYLE|wxRESIZE_BORDER)
{
    // Created tabbed dialog controls

    wxNotebook* notebook = new wxNotebook(this, -1, wxDefaultPosition, wxSize(200,160), 0 );

    wxWindow* parent = this;

    wxBoxSizer *item0 = new wxBoxSizer( wxVERTICAL );

    wxNotebookSizer *item1 = new wxNotebookSizer( notebook );
    item0->Add( item1, 1, wxGROW|wxALIGN_CENTER_VERTICAL|wxALL, 5 );

    wxBoxSizer *item3 = new wxBoxSizer( wxHORIZONTAL );

    wxButton *item4 = new wxButton( parent, wxID_OK, _("&OK"), wxDefaultPosition, wxDefaultSize, 0 );
    item3->Add( item4, 0, wxALIGN_CENTRE|wxLEFT|wxBOTTOM, 5 );

    wxButton *item5 = new wxButton( parent, wxID_CANCEL, _("&Cancel"), wxDefaultPosition, wxDefaultSize, 0 );
    item3->Add( item5, 0, wxALIGN_CENTRE|wxLEFT|wxBOTTOM, 5 );

    wxButton *item6 = new wxButton( parent, wxID_HELP, _("&Help"), wxDefaultPosition, wxDefaultSize, 0 );
    item3->Add( item6, 0, wxALIGN_CENTRE|wxLEFT|wxBOTTOM|wxRIGHT, 5 );

    item0->Add( item3, 0, wxALIGN_RIGHT|wxALIGN_CENTER_VERTICAL, 5 );
    parent->SetAutoLayout( TRUE );
    parent->SetSizer( item0 );

    ((wxButton*) FindWindow(wxID_OK))->SetDefault();

    ScrolledWindowContainer* panel = new ScrolledWindowContainer(notebook);

    notebook->AddPage(panel, wxT("Basics"), TRUE, 4);
    panel->TransferDataToWindow();

    notebook->SetSelection(0);

    GetSizer()->SetSizeHints(this);

    panel->AdjustPropertyScrollbars();

    Centre(wxBOTH);
}

void MyModalDialog::OnButton(wxCommandEvent& event)
{
    if ( event.GetEventObject() == m_btnDelete )
    {
        delete m_btnFocused;
        m_btnFocused = NULL;

        m_btnDelete->Disable();
    }
    else if ( event.GetEventObject() == m_btnFocused )
    {
        wxGetTextFromUser(_T("Dummy prompt"),
                          _T("Modal dialog called from dialog"),
                          _T(""), this);
    }
    else
    {
        event.Skip();
    }
}

/* Any panel with a scrolling sub-panel containing
 * properties
 */

IMPLEMENT_CLASS(ScrolledWindowContainer, wxPanel)

BEGIN_EVENT_TABLE(ScrolledWindowContainer, wxPanel)
END_EVENT_TABLE()

ScrolledWindowContainer::ScrolledWindowContainer(wxWindow* win):
    wxPanel(win, -1, wxDefaultPosition, wxDefaultSize)
{
    wxWindow* parent = this;

    wxBoxSizer *item0 = new wxBoxSizer( wxVERTICAL );
    wxBoxSizer *parentSizer = new wxBoxSizer( wxVERTICAL );
    item0->Add( parentSizer, 1, wxGROW|wxALIGN_CENTER_VERTICAL|wxALL, 5 );

    wxStaticText *descrText = new wxStaticText( parent, wxID_STATIC, wxT("Enter more detailed information."), wxDefaultPosition, wxDefaultSize, 0 );
    parentSizer->Add( descrText, 0, wxALIGN_CENTER_VERTICAL|wxALL, 5 );

    parentSizer->Add( 5, 5, 0, wxALIGN_CENTRE, 5 );

    wxBoxSizer *scrolledParentSizer = NULL;

    m_scrolledWindow = new wxScrolledWindow(parent, -1,
        wxDefaultPosition, wxSize(300, 100), wxSUNKEN_BORDER|wxTAB_TRAVERSAL);

    // Now set up the layout for the children of the scrolled window
    scrolledParentSizer = new wxBoxSizer( wxVERTICAL );
    m_scrolledWindow->SetSizer(scrolledParentSizer);
    m_scrolledWindow->SetAutoLayout( TRUE );

    parentSizer->Add(m_scrolledWindow, 1, wxGROW|wxALIGN_CENTER_VERTICAL|wxALL, 5 );

    // BEGIN PROPERTIES

    int i;
    for (i = 0; i < 10; i++)
    {
        wxBoxSizer *horizSizer = new wxBoxSizer(wxHORIZONTAL);
        scrolledParentSizer->Add(horizSizer, 0, wxGROW|wxALIGN_CENTER|wxALL, 5 );

        wxTextCtrl* textCtrl1 = new wxTextCtrl(m_scrolledWindow, -1, wxT(""));
        wxTextCtrl* textCtrl2 = new wxTextCtrl(m_scrolledWindow, -1, wxT(""));

        horizSizer->Add(textCtrl1, 1, wxALIGN_CENTER_VERTICAL|wxALL, 5 );
        horizSizer->Add(textCtrl2, 1, wxALIGN_CENTER_VERTICAL|wxALL, 5 );
    }


    // END PROPERTIES

    parent->SetAutoLayout( TRUE );
    parent->SetSizer( item0 );
    item0->Fit( parent );
}

bool ScrolledWindowContainer::TransferDataToWindow()
{
    if (!wxPanel::TransferDataToWindow())
        return FALSE;
    return m_scrolledWindow->TransferDataToWindow();
}

bool ScrolledWindowContainer::TransferDataFromWindow()
{
    if (!wxPanel::TransferDataFromWindow())
        return FALSE;
    return m_scrolledWindow->TransferDataFromWindow();
}

void ScrolledWindowContainer::AdjustPropertyScrollbars()
{
    wxSize sz = m_scrolledWindow->GetClientSize();

    // Give the layout as much vertical space as it wants
    m_scrolledWindow->SetScrollbars(0, 1, 0 , 10000);
    m_scrolledWindow->Layout();

    // Then set the real virtual size
    // Find the size we'll have to set the scrollbars to.
    wxPoint pt(0, 0);
    wxNode* node = m_scrolledWindow->GetChildren().First();
    while (node)
    {
        wxWindow* win = (wxWindow*) node->Data();
        wxRect rect = win->GetRect();
        if (rect.GetRight() > pt.x)
            pt.x = rect.GetRight();
        if (rect.GetBottom() > pt.y)
            pt.y = rect.GetBottom();
        node = node->Next();
    }

    // Add a bit for space at the bottom
    pt.y += 5;

    int unitSize = 10;
    int noUnits = (pt.y/unitSize) + 1;
    m_scrolledWindow->SetScrollbars(0, unitSize, 0, noUnits);
}

