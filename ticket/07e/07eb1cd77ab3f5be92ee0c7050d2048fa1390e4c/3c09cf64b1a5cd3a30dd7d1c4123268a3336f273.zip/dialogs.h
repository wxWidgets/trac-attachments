/////////////////////////////////////////////////////////////////////////////
// Name:        dialogs.h
// Purpose:     Common dialogs demo
// Author:      Julian Smart
// Modified by:
// Created:     04/01/98
// RCS-ID:      $Id: dialogs.h,v 1.23 2002/03/28 18:57:49 RR Exp $
// Copyright:   (c) Julian Smart and Markus Holzem
// Licence:     wxWindows license
/////////////////////////////////////////////////////////////////////////////

#ifndef __DIALOGSH__
#define __DIALOGSH__

// Define a new application type
class MyApp: public wxApp
{
public:
    bool OnInit();

};

// A custom modeless dialog
class MyModelessDialog : public wxDialog
{
public:
    MyModelessDialog(wxWindow *parent);

    void OnButton(wxCommandEvent& event);
    void OnClose(wxCloseEvent& event);

private:
    DECLARE_EVENT_TABLE()
};

// A custom modal dialog
class MyModalDialog : public wxDialog
{
public:
    MyModalDialog(wxWindow *parent);

    void OnButton(wxCommandEvent& event);

private:
    wxButton *m_btnFocused;
    wxButton *m_btnDelete;

    DECLARE_EVENT_TABLE()
};

// Define a new frame type
class MyFrame: public wxFrame
{
public:
    MyFrame(wxWindow *parent, const wxString& title,
            const wxPoint& pos, const wxSize& size);

    void ModalDlg(wxCommandEvent& event);
    void ModelessDlg(wxCommandEvent& event);
    void OnExit(wxCommandEvent& event);

private:
    MyModelessDialog *m_dialog;

    DECLARE_EVENT_TABLE()
};

class MyCanvas: public wxScrolledWindow
{
public:
    MyCanvas(wxWindow *parent) : 
       wxScrolledWindow(parent,-1,wxDefaultPosition,wxDefaultSize,wxNO_FULL_REPAINT_ON_RESIZE) { }

//    void OnPaint(wxPaintEvent& event);

    DECLARE_EVENT_TABLE()
};

/* Any panel with a scrolling sub-panel containing
 * properties
 */

class ScrolledWindowContainer: public wxPanel
{
DECLARE_CLASS(ScrolledWindowContainer)
public:
    ScrolledWindowContainer(wxWindow* parent);

    void AdjustPropertyScrollbars();

    virtual bool TransferDataToWindow();
    virtual bool TransferDataFromWindow();

    wxScrolledWindow*   m_scrolledWindow;
DECLARE_EVENT_TABLE()
};


// Menu IDs
enum
{
    DIALOGS_MODAL,
    DIALOGS_MODELESS,
    DIALOGS_MODELESS_BTN
};

#endif

