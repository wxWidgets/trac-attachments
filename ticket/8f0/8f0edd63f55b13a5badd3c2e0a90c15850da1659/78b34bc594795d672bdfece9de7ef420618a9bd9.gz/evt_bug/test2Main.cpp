/***************************************************************
 * Name:      test2Main.cpp
 * Purpose:   Code for Application Frame
 * Author:    basOS (basos@users.sf.net)
 * Created:   2008-07-05
 * Copyright: basOS ()
 * License:
 **************************************************************/

#ifdef WX_PRECOMP
#include "wx_pch.h"
#endif

#ifdef __BORLANDC__
#pragma hdrstop
#endif //__BORLANDC__

#include "test2Main.h"

//#include <wx/dir.h>
//#include <wx/filename.h>
#include <wx/debug.h>
#include <wx/config.h>

//#include <wx/filename.h>

//helper functions
enum wxbuildinfoformat {
    short_f, long_f
};

wxString wxbuildinfo(wxbuildinfoformat format)
{
    wxString wxbuild(wxVERSION_STRING);

    if (format == long_f )
    {
#if defined(__WXMSW__)
        wxbuild << _T("-Windows");
#elif defined(__WXMAC__)
        wxbuild << _T("-Mac");
#elif defined(__UNIX__)
        wxbuild << _T("-Linux");
#endif

#if wxUSE_UNICODE
        wxbuild << _T("-Unicode build");
#else
        wxbuild << _T("-ANSI build");
#endif // wxUSE_UNICODE
    }

    return wxbuild;
}


class OptionsPanel : public wxPanel
{
    public:
        OptionsPanel(wxWindow* parent, wxWindowID id = wxID_ANY, const wxPoint& pos = wxDefaultPosition,
                    const wxSize& size = wxDefaultSize, long style = wxTAB_TRAVERSAL, const wxString& name = _T("panel")) :
            wxPanel( parent, id, pos, size, style, name ), a_vars( wxConfigBase::Get() )
            {           }
    protected:
        wxConfigBase* a_vars ;
};

/***********************************8
 *** myPanel 
  *******************************/
class myPanel : public OptionsPanel
{
public:
	myPanel( wxWindow* par );
private:
	wxTextCtrl* m_text ;
	wxString m_str ;

	void OnAbout( wxCommandEvent& evt ) ;
};

myPanel::myPanel( wxWindow* par ) : OptionsPanel( par, wxID_ANY ) 
{
	wxBoxSizer* bxv1 = new wxBoxSizer( wxVERTICAL );

        //create widgets
		
		m_text = new wxTextCtrl(this, wxID_ANY, _T("Click on the Check Buttons. The first event is handled by the wxPanel Event Handler to a wxPanel handlter function ,\n while the second by the wxButton Event Handler to a wxPanel (parent) function **A FACT THAT SHOULD NOT BE ALLOWED***. Check the addresses that the event handler function thinks we have. Compare with ours.\n"),
				wxDefaultPosition, wxDefaultSize, wxTE_MULTILINE );

		wxString sst;
		sst.Printf(_T("Address of m_text (ptr) = 0x%x, \n Address of m_str = 0x%x \nAddress of this = 0x%x \n"), m_text, &m_str, this );
		m_text->AppendText( sst );
		m_text->SetMinSize( wxSize(400,200) );

		bxv1->Add( m_text, 1, wxEXPAND| wxALL, 10 ) ;

		wxButton* bt = new wxButton( this , 2222, _T("Check ( ok )") ) ;
		bxv1->Add( bt, 0, wxALL| wxALIGN_CENTER, 10 ) ;

		wxButton* bte = new wxButton( this , 6666, _T("Check ( bug )") ) ;
		bxv1->Add( bte, 0, wxALL| wxALIGN_CENTER, 10 ) ;
		

/*		
        this->SetSizer(bxv1);
        bxv1->SetSizeHints(this);
        bxv1->Fit(this) ;
*/
		this->SetSizerAndFit( bxv1 );


        //event handlers
		Connect ( 2222, wxEVT_COMMAND_BUTTON_CLICKED, wxCommandEventHandler( myPanel::OnAbout ))  ;
		/* THIS IS THE TRICKY POINT :: We can connect @ wxChoice's EventHandlter a 
			Method of ANOTHER class. Nasty things WILL happen. And nobody warns us
         */
		bte->Connect ( 6666, wxEVT_COMMAND_BUTTON_CLICKED, wxCommandEventHandler( myPanel::OnAbout )) ;
}

void myPanel::OnAbout( wxCommandEvent &evt )
{
#if 0
		f_main* f;
		f = ((f_main*)(((wxWindow*) event.GetEventObject())->GetParent())) ;
#endif

		wxString smsg ;
		smsg.Printf( _T("Now we take the addresses of our objects ASSUMING we are a member function\n"
						"Address of m_text (ptr) = 0x%x\n"
						"Address of m_str = 0x%x\n"
						"Address of this  = 0x%x\n"
#if 0
						"\n Also lets take them from the event object hierarcy (event->object(menu)->Parent(frame)->member)\n"
						" Evt Addr of m_text (ptr) = %x\n"
						" Evt Addr of m_str = %x\n"
#endif
						), m_text, &m_str, this
#if 0 
						,f->m_text, &(f->m_str) 
#endif
						);
		

        wxMessageDialog msg(this,smsg, _T("About Bug"), wxOK | (evt.GetId() == 6666 ? wxICON_ERROR : 0 ) );
        //wxIcon c_app_icon(wxICON(damage_smile));
        //msg.SetIcon(c_app_icon);

        msg.ShowModal();
}



/***************************
 *** mainFrame
 ***************************/

   f_main::f_main(const wxString& title, const wxPoint& pos, const wxSize& size)
    : wxFrame(0L, -1, title), m_str(_T("Member String"))
    {

        /*  add menu  */
        wxMenu *mnu = new wxMenu;

        mnu->Append(ID_ABOUT, _("&About me( Check Bug )"),_("Useless information"));
        mnu->Append(ID_QUIT, _("Qui&t da app"));

        wxMenuBar *mnuB = new wxMenuBar;
        mnuB->Append (mnu, _("&Gen") ) ;

        // Connect (wxEVT_PAINT,wxPaintEventHandler(f_main::OnPaint));

        SetMenuBar (mnuB);

        /* add status bar */
#if wxUSE_STATUSBAR
        CreateStatusBar(2);
        SetStatusText(wxbuildinfo(long_f), 1);
        SetStatusText ( _("Welcome to a wxwidgeted evt bug app"),0);
#endif


        //design form

		wxBoxSizer* bxv1 = new wxBoxSizer( wxVERTICAL );

   		bxv1->Add( new myPanel(this), 1, wxEXPAND );

/*		
        this->SetSizer(bxv1);
        bxv1->SetSizeHints(this);
        bxv1->Fit(this) ;
*/
		this->SetSizerAndFit( bxv1 );


        //event handlers
        Connect (ID_ABOUT, wxEVT_COMMAND_MENU_SELECTED,wxCommandEventHandler(f_main::OnAbout));
        Connect (ID_QUIT, wxEVT_COMMAND_MENU_SELECTED,wxCommandEventHandler(f_main::OnQuit));
    }

    //Event Handlers

    void f_main::OnQuit(wxCommandEvent& WXUNUSED(event))
    {
       // Close(TRUE);
        wxMessageBox (_T("Bye...."),_T("exiting"), wxOK | wxICON_HAND, this);
		Close() ;
    }

    void f_main::OnAbout(wxCommandEvent& event)
    {

    }

  
 


