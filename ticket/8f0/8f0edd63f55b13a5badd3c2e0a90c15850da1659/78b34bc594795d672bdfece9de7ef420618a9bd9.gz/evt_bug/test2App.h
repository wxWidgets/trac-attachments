/***************************************************************
 * Name:      test2App.h
 * Purpose:   Defines Application Class
 * Author:    basOS (basos@users.sf.net)
 * Created:   2008-07-05
 * Copyright: basOS ()
 * License:
 **************************************************************/

#ifndef TEST2APP_H
#define TEST2APP_H

#include <wx/app.h>



class appEvtBug : public wxApp
{
    virtual bool OnInit();

    protected:
};


#endif // TEST2APP_H
