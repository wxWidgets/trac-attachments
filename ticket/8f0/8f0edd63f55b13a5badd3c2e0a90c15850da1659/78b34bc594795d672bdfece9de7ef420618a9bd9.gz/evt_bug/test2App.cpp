/***************************************************************
 * Name:      test2App.cpp
 * Purpose:   Code for Application Class
 * Author:    basOS (basos@users.sf.net)
 * Created:   2008-07-05
 * Copyright: basOS ()
 * License:
 **************************************************************/

#ifdef WX_PRECOMP
#include "wx_pch.h"
#endif

#ifdef __BORLANDC__
#pragma hdrstop
#endif //__BORLANDC__

#include "test2App.h"
#include "test2Main.h"

IMPLEMENT_APP(appEvtBug)


bool appEvtBug::OnInit()
{
    f_main *frame  = new f_main( _T("Event bug App"), wxPoint(50,150),wxSize(450,390));
    frame->Show(TRUE);
    SetTopWindow(frame);

    return TRUE;
}

