/***************************************************************
 * Name:      test2Main.h
 * Purpose:   Defines Application Frame
 * Author:    basOS (basos@users.sf.net)
 * Created:   2008-07-05
 * Copyright: basOS ()
 * License:
 **************************************************************/

#ifndef TEST2MAIN_H
#define TEST2MAIN_H

#ifndef WX_PRECOMP
    #include <wx/wx.h>
#endif

#include "test2App.h"


class f_main : public wxFrame
{
    public:

    f_main(const wxString& title, const wxPoint& pos, const wxSize& size);

    private:
    enum {
        ID_QUIT ,
        ID_ABOUT,
    };

    //Event Handlers

    void OnQuit(wxCommandEvent& WXUNUSED(event));

    void OnAbout(wxCommandEvent& WXUNUSED(event));

	wxString m_str ;
	wxTextCtrl* m_text ;

};


#endif // TEST2MAIN_H
