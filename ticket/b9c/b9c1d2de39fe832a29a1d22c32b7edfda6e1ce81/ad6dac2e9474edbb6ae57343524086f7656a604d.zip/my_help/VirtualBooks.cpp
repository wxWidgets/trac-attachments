#ifdef __GNUG__
// #pragma implementation
#endif

// for (compilers that support precompilation, includes "wx/wx.h".
#include "wx/wxprec.h"

#ifdef __BORLANDC__
#pragma hdrstop
#endif

#ifndef WX_PRECOMP
#include "wx/wx.h"
#endif

#include "VirtualBooks.h"

static bool  m_fBooksLoaded = false;

//introduction/welcome book
static wxString m_sIntroHHP;        //book description
static wxString m_sIntroHHC;        //book content
static wxString m_sIntroHHK;        //book index
static wxString m_sIntroHTM;        //book pages



MyVirtualBooks::MyVirtualBooks() : wxFileSystemHandler()
{
    //initialize book content. It can not be static because then _() macro doesn't
    //work
    if (!m_fBooksLoaded) {
        LoadIntroBook();
        m_fBooksLoaded = true;
    }
}

MyVirtualBooks::~MyVirtualBooks()
{
}

bool MyVirtualBooks::CanOpen(const wxString& location)
{
    return (GetProtocol(location) == _T("MyVirtualBooks"));
}


wxFSFile* MyVirtualBooks::OpenFile(wxFileSystem& WXUNUSED(fs), const wxString& location)
{
    wxFSFile *f;
    wxInputStream *str;
    wxString* pBook;

    int iColon = location.Find(_T(':'));
    wxString sBookName = location.Mid(iColon+1, location.Length()-iColon-5);
    wxString sExt(location.Right(4).Lower());
    //wxLogMessage(_T("[MyVirtualBooks::OpenFile] Request to open virtual file '%s'. Book='%s', ext='%s'"),
    //    location, sBookName, sExt);

    if (sExt == _T("ched"))
        return (wxFSFile*) NULL;    //cached file

    if (sExt == _T(".jpg") || sExt == _T(".gif") || sExt == _T(".png") ) {
        return (wxFSFile*) NULL;    //ignore in this sample
    }

    wxString sNumPage;
    if (sBookName == _T("intro") || sBookName.StartsWith(_T("intro_")) ) {
        if (location == _T("MyVirtualBooks:intro.hhp")) {
            pBook = &m_sIntroHHP;
        }
        else if (location == _T("MyVirtualBooks:intro.hhc")) {
            pBook = &m_sIntroHHC;
        }
        else if (location == _T("MyVirtualBooks:intro.hhk")) {
            pBook = &m_sIntroHHK;
        }
        else if (location == _T("MyVirtualBooks:intro_0.htm")) {
            pBook = &m_sIntroHTM;
        }
        else {
            return (wxFSFile*) NULL;    //error
        }
    }
    else
        return (wxFSFile*) NULL;    //error

    //wxLogMessage(*pBook);

#ifndef _UNICODE
    str = new wxMemoryInputStream(pBook->c_str(), pBook->Length());
#else
    //by pass for bug in wxHtmlHelpController in Unicode build:
    //wxHtmlFilter::ReadFile() expects an ANSI string. So here I must
    //translate from unicode to ANSI.
    //  This method allocates memory but never is free --> Memory lekages
    size_t nLong = pBook->Length();
    char* sBookMB = new char[4*nLong];  //just in case...
    wxMBConvUTF8 oConv;
    size_t nSize = oConv.WC2MB(sBookMB, pBook->c_str(), nLong);
    str = new wxMemoryInputStream(sBookMB, nSize);

    //Better alternative method but doesn't work! Why?
    //wxMBConvUTF8 oConv;
    //wxCharBuffer sBookMB = pBook->mb_str(oConv);
    //str = new wxMemoryInputStream(sBookMB.data(), strlen(sBookMB.data()) );
#endif
    f = new wxFSFile(str, location, wxT("text/html"), wxEmptyString, wxDateTime::Today());
    
    return f;
}

void MyVirtualBooks::LoadIntroBook()
{
    wxString sNil = _T("");

    //book description
    //-----------------------------------------------------------------------------
    m_sIntroHHP = sNil +
        _T("[OPTIONS]\n")
        _T("Contents file=intro.hhc\n")
        _T("Charset=utf-8\n")
        _T("Index file=intro.hhk\n")
        _T("Title=") + _("Virtual book. Introducci�n") + _T("\n")    //<-- Note oacute to simulate gettext translation
        _T("Default topic=intro_0.htm\n");

    
    //Book content
    //-----------------------------------------------------------------------------
    m_sIntroHHC = sNil +
        _T("<html><head>")
        _T("<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\">")
        _T("</head><body><ul>")
        _T("<li><object type=\"text/sitemap\">")
        _T("<param name=\"Name\" value=\"") + _("Welc�me") + _T("\">")    //<-- Note oacute to simulate gettext translation
        _T("<param name=\"Local\" value=\"intro_0.htm\"></object></li>")
        _T("</ul></body></html>");
    
    //book index
    //-----------------------------------------------------------------------------
    m_sIntroHHK = sNil +
        _T("<!DOCTYPE HTML PUBLIC \"-//IETF//DTD HTML//EN\">")
        _T("<html><head>")
        _T("<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\">")
        _T("</head><body><ul>")
        _T("<li><object type=\"text/sitemap\">")
        _T("<param name=\"Name\" value=\"") + _("Welc�me") + _T("\">")    //<-- Note oacute to simulate gettext translation
        _T("<param name=\"Local\" value=\"intro_0.htm\"></object></li>")
        _T("</ul></body></html>");
    

    //book page
    //-----------------------------------------------------------------------------
    m_sIntroHTM = sNil +
      _T("<html><head>")
      _T("<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\">")
      _T("</head><body><h1>") +
      _("Welc�me to this test ") +     //<-- Note oacute to simulate gettext translation
      _T("</h1><p>") +
      _("Some text to fill this") +
      _T("</p><p>") +
      _("We hope that this is enough.") +
      _T("</p><p>") +
      _("The programming team.") +
      _T("</p>")
      _T("</body></html>");

}




//-------------------------------------------------------------------------------------
// global functions
//-------------------------------------------------------------------------------------
void LoadVirtualBooks(wxHtmlHelpController* pBookController)
{
    wxString sFilename;

    //load 'Introduction' book
    sFilename = _T("MyVirtualBooks:intro.hhp");
    if (!pBookController->AddBook(sFilename)) {
        wxMessageBox(wxString::Format(_("Failed adding virtual book %s"), sFilename ));
    }

}


