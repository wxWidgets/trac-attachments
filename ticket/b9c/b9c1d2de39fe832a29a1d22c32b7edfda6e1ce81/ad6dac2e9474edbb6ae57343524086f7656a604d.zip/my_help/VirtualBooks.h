#ifdef __GNUG__
// #pragma interface
#endif

#ifndef __VIRTUALBOOKS_H__        //to avoid nested includes
#define __VIRTUALBOOKS_H__

#include "wx/wfstream.h"
#include "wx/mstream.h"

#include "wx/html/helpctrl.h"

extern void LoadVirtualBooks(wxHtmlHelpController* pBookController);


class MyVirtualBooks : public wxFileSystemHandler
{
public:
    MyVirtualBooks();
    ~MyVirtualBooks();

    wxFSFile* OpenFile(wxFileSystem& fs, const wxString& location);
    bool CanOpen(const wxString& location);

private:
    void LoadIntroBook();
    void LoadSingleExercisesBook();






};


#endif    // __VIRTUALBOOKS_H__
