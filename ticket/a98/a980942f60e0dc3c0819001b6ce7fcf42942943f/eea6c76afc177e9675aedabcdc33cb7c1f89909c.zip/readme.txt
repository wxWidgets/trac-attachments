ktest sample
13-04-2002

This sample has been created to test a buggy behaviour in the library.
I hope this will remain a valid test application into wxWindows/samples tree.
This sample work perfectly with wxMSW-2.3.2 and wxGTK-2.3.2
But unfortunately not using wxMSW-2.3.3 and wxGTK-2.3.3

This sample is using the following classes:

wxDialog containing 
wxPanel containing
		wxScrolledWindow containing
			wxBoxSizer containing
				wxComboBox and
				wxTextCtrl and
				wxButton


The expected behavoiur on the screen should be...
A dialog containing a scrollable area (something like a Property Sheet) divided into
Decription and its control (a Text or a Combo)
Desc1 : TextCtrl
Desc2 : ComboCtrl


Marco Cavallini
www.koansoftware.com

