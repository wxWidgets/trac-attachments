/////////////////////////////////////////////////////////////////////////////
// Name:        ktest.cpp
// Purpose:     Koan's wxWindows test sample
// Author:      Marco Cavallini
// Modified by:
// Created:     13-04-2002
// Copyright:   (c) 2002 Koan software - www.koansoftware.com
// Licence:     wxWindows licence
/////////////////////////////////////////////////////////////////////////////

// ============================================================================
// declarations
// ============================================================================

// ----------------------------------------------------------------------------
// headers
// ----------------------------------------------------------------------------

// For compilers that support precompilation, includes "wx/wx.h".
#include "wx/wxprec.h"

#ifdef __BORLANDC__
    #pragma hdrstop
#endif

// for all others, include the necessary headers (this file is usually all you
// need because it includes almost all "standard" wxWindows headers)
#ifndef WX_PRECOMP
    #include "wx/wx.h"
#endif

#include <wx/notebook.h>
#include <wx/minifram.h>
#include <wx/imaglist.h>
#include <wx/listctrl.h>


// ----------------------------------------------------------------------------
// resources
// ----------------------------------------------------------------------------

// the application icon (under Windows and OS/2 it is in resources)
#if defined(__WXGTK__) || defined(__WXMOTIF__) || defined(__WXMAC__) || defined(__WXMGL__) || defined(__WXX11__)
    #include "mondrian.xpm"
#endif



///////////////////////////////////////////////////////////////////////////////

class CScrolledPanel: public wxPanel
{
public:
	CScrolledPanel(wxWindow *parent, wxWindowID id = -1, const wxPoint& pos = wxDefaultPosition,
            const wxSize& size = wxDefaultSize, long style = wxTAB_TRAVERSAL | wxSUNKEN_BORDER,
            const wxString& name = wxPanelNameStr);

	virtual ~CScrolledPanel();

	void SetScrollableArea(int Height);

	wxScrolledWindow *m_pFinestra;	// scrollable window containing...
	wxBoxSizer *m_pPanelSizer;		// resizable panel
	wxBoxSizer *m_pWindowSizer;		// resizable window

private:
	DECLARE_EVENT_TABLE()
};

BEGIN_EVENT_TABLE(CScrolledPanel, wxPanel)
END_EVENT_TABLE()

CScrolledPanel::CScrolledPanel(wxWindow *parent, wxWindowID id, const wxPoint& pos, const wxSize& size,
            long style, const wxString& name)
			: wxPanel(parent, id, pos, size, style, name)
{
	m_pFinestra = new wxScrolledWindow(this,-1,wxDefaultPosition,wxDefaultSize);
	m_pPanelSizer = new wxBoxSizer(wxVERTICAL);
	m_pWindowSizer = new wxBoxSizer(wxVERTICAL);

    this->SetAutoLayout(true);
    this->SetSizer(m_pPanelSizer);

    m_pFinestra->SetAutoLayout(true);
    m_pFinestra->SetSizer(m_pWindowSizer);

	m_pPanelSizer->Add(m_pFinestra, 1, wxEXPAND);
	m_pFinestra->SetBackgroundColour(wxSystemSettings::GetSystemColour(wxSYS_COLOUR_3DFACE));
	m_pFinestra->Show(true);
}

CScrolledPanel::~CScrolledPanel()
{
	delete m_pFinestra;
}

void CScrolledPanel::SetScrollableArea(int Height)
{
	if (Height == -1)
		m_pFinestra->SetScrollbars(-1, -1, -1, -1, -1, -1, false);
	else
		m_pFinestra->SetScrollbars(-1, 10, -1, Height, 0, 0, false);
}

////////////////////////////////////////////////////////////


class CDlgTagProperty: public wxDialog
{
public:
    CDlgTagProperty(wxWindow* parent, const wxWindowID id, const wxString& title,
        const wxPoint& pos = wxDefaultPosition, const wxSize& size = wxDefaultSize , 
		const long windowStyle = wxDIALOG_MODELESS | wxDEFAULT_DIALOG_STYLE | wxRESIZE_BORDER) ;
	
	virtual ~CDlgTagProperty();

private:
	wxNotebook *m_pNotebook;
	CScrolledPanel *m_pPanels;
	wxComboBox *m_pComboBox;
	wxTextCtrl *m_pTextCtrl;

	wxButton *m_pCmdCancel;	

	wxSize m_LabelSize;
	wxSize m_TextSize;
	wxSize m_ButtonSize;
	wxSize m_NullSize;
	wxBitmap m_BmpCerca;
	bool m_bNewItem;
	
    DECLARE_EVENT_TABLE()
	void OnKeyUp(wxKeyEvent &event);
};

BEGIN_EVENT_TABLE(CDlgTagProperty, wxDialog)
	EVT_CHAR_HOOK(CDlgTagProperty::OnKeyUp)
	EVT_CLOSE(CDlgTagProperty::OnCancel)
END_EVENT_TABLE()


CDlgTagProperty::CDlgTagProperty(wxWindow* parent, const wxWindowID id, const wxString& title,
		const wxPoint& pos, const wxSize& size, const long windowStyle)
		:wxDialog(parent, id, title, pos, size, windowStyle)
{
	m_pNotebook = new wxNotebook(this, 100);
	m_pCmdCancel = new wxButton(this, wxID_CANCEL, "&Cancel", wxDefaultPosition, wxSize(60, 25));
	wxNotebookSizer *nbs = new wxNotebookSizer(m_pNotebook);
	wxBoxSizer *pBoxSizer = new wxBoxSizer(wxVERTICAL);
	wxBoxSizer *pButtonBox = new wxBoxSizer(wxHORIZONTAL);

	this->SetBackgroundColour(wxSystemSettings::GetSystemColour(wxSYS_COLOUR_3DFACE));
	this->SetSizer(pBoxSizer);
	this->SetAutoLayout(true);

	pButtonBox->Add(m_pCmdCancel, wxSTRETCH_NOT, wxLEFT | wxTOP, 2);
	
	pBoxSizer->Add(nbs, 1,wxGROW);
	pBoxSizer->Add(pButtonBox, wxSTRETCH_NOT,wxALIGN_RIGHT |wxALIGN_BOTTOM);

	//Init default controls size 
    m_LabelSize = wxSize(120, 20);
	m_TextSize = wxSize(-1, 20);
	m_ButtonSize = wxSize(20 , 20);
	m_NullSize = wxSize(0,0);

    //////////////////////////////////////////////////////

	m_pPanels = new CScrolledPanel(m_pNotebook, 0);

    //////////////////////////////////////////////////////

	CScrolledPanel *pPannello = m_pPanels;
	wxScrolledWindow *pFinestra = pPannello->m_pFinestra;
	long FlagLabel = wxALIGN_LEFT | wxALIGN_CENTER_VERTICAL;
	long FlagCtrl = wxGROW | wxALIGN_LEFT | wxALIGN_CENTER_VERTICAL;

	//Create panel (TAB)
	m_pNotebook->AddPage(pPannello, "General", false, 0);

	//Select first tab
	m_pNotebook->SetSelection(0);

	//Define a container grid for the controls
	wxFlexGridSizer *pGriglia = new wxFlexGridSizer(11,3, 0, 0);
	pGriglia->AddGrowableCol(1);
	pPannello->m_pWindowSizer->Add(pGriglia, 0, wxGROW | wxALL, 2);

	//textbox
	m_pTextCtrl = new wxTextCtrl(pFinestra, 0, wxEmptyString, wxDefaultPosition, wxDefaultSize);

	//combo 
    m_pComboBox = new wxComboBox(pFinestra, 0, wxEmptyString,wxDefaultPosition,wxDefaultSize,0,NULL,wxCB_READONLY | wxCB_SORT);


    // BUG BUG BUG BUG BUG BUG BUG BUG
    // using wxMSW and wxGTK 2.3.1 this was ok, now using 2.3.3 not :-(
    // BUG BUG BUG BUG BUG BUG BUG BUG
    // Expected behavoiur on the screen should be...
    // Desc1 : TextCtrl
    // Desc2 : ComboCtrl
    // BUG BUG BUG BUG BUG BUG BUG BUG

	pGriglia->Add(new wxStaticText(pFinestra, -1, "Nome:", wxDefaultPosition, m_LabelSize), FlagLabel);
	pGriglia->Add(m_pTextCtrl, wxSTRETCH_NOT, FlagCtrl);
	pGriglia->Add(new wxStaticText(pFinestra, -1, wxEmptyString));

	pGriglia->Add(new wxStaticText(pFinestra, -1, "Gruppo:", wxDefaultPosition, m_LabelSize), FlagLabel); 
	pGriglia->Add(m_pComboBox, wxSTRETCH_NOT, FlagCtrl);
	pGriglia->Add(new wxStaticText(pFinestra, -1, wxEmptyString));


	pPannello->SetScrollableArea(24);

}

CDlgTagProperty::~CDlgTagProperty()
{
	delete m_pCmdCancel;
	delete m_pPanels;
	delete m_pNotebook;
}

void CDlgTagProperty::OnKeyUp(wxKeyEvent &event)
{
    // BUG BUG BUG BUG BUG BUG BUG BUG
    // Tab does not skip over controls inside the dialog...why ?
    // BUG BUG BUG BUG BUG BUG BUG BUG

	if (event.KeyCode() == WXK_ESCAPE)
		Hide();
	else
		event.Skip();
}

///////////////////////////////////////////////////////////////////////////////




// ----------------------------------------------------------------------------
// private classes
// ----------------------------------------------------------------------------

// Define a new application type, each program should derive a class from wxApp
class MyApp : public wxApp
{
public:
    // override base class virtuals
    // ----------------------------

    // this one is called on application startup and is a good place for the app
    // initialization (doing it here and not in the ctor allows to have an error
    // return: if OnInit() returns false, the application terminates)
    virtual bool OnInit();
};

// Define a new frame type: this is going to be our main frame
class MyFrame : public wxFrame
{
public:
    // ctor(s)
    MyFrame(const wxString& title, const wxPoint& pos, const wxSize& size,
            long style = wxDEFAULT_FRAME_STYLE);

    // event handlers (these functions should _not_ be virtual)
    void OnQuit(wxCommandEvent& event);
    void OnAbout(wxCommandEvent& event);
    void OnDialog(wxCommandEvent& event);


	CDlgTagProperty *m_pDlgTagProperty;

private:
    // any class wishing to process wxWindows events must use this macro
    DECLARE_EVENT_TABLE()
};

// ----------------------------------------------------------------------------
// constants
// ----------------------------------------------------------------------------

// IDs for the controls and the menu commands
enum
{
    // menu items
    ktest_Quit = 1,
    ktest_Dialog,


    // it is important for the id corresponding to the "About" command to have
    // this standard value as otherwise it won't be handled properly under Mac
    // (where it is special and put into the "Apple" menu)
    ktest_About = wxID_ABOUT
};

// ----------------------------------------------------------------------------
// event tables and other macros for wxWindows
// ----------------------------------------------------------------------------

// the event tables connect the wxWindows events with the functions (event
// handlers) which process them. It can be also done at run-time, but for the
// simple menu events like this the static method is much simpler.
BEGIN_EVENT_TABLE(MyFrame, wxFrame)
    EVT_MENU(ktest_Quit,  MyFrame::OnQuit)
    EVT_MENU(ktest_About, MyFrame::OnAbout)
    EVT_MENU(ktest_Dialog, MyFrame::OnDialog)
END_EVENT_TABLE()

// Create a new application object: this macro will allow wxWindows to create
// the application object during program execution (it's better than using a
// static object for many reasons) and also declares the accessor function
// wxGetApp() which will return the reference of the right type (i.e. MyApp and
// not wxApp)
IMPLEMENT_APP(MyApp)

// ============================================================================
// implementation
// ============================================================================

// ----------------------------------------------------------------------------
// the application class
// ----------------------------------------------------------------------------

// 'Main program' equivalent: the program execution "starts" here
bool MyApp::OnInit()
{
    // create the main application window
    MyFrame *frame = new MyFrame(_T("ktest wxWindows App"),
                                 wxPoint(50, 50), wxSize(450, 340));

    // and show it (the frames, unlike simple controls, are not shown when
    // created initially)
    frame->Show(TRUE);

    // success: wxApp::OnRun() will be called which will enter the main message
    // loop and the application will run. If we returned FALSE here, the
    // application would exit immediately.
    return TRUE;
}

// ----------------------------------------------------------------------------
// main frame
// ----------------------------------------------------------------------------

// frame constructor
MyFrame::MyFrame(const wxString& title, const wxPoint& pos, const wxSize& size, long style)
       : wxFrame(NULL, -1, title, pos, size, style)
{

#if wxUSE_MENUS

    wxMenu *menuFile = new wxMenu;
    menuFile->Append(ktest_Quit, _T("E&xit\tAlt-X"), _T("Quit this program"));

    wxMenu *helpMenu = new wxMenu;
    helpMenu->Append(ktest_About, _T("&About...\tF1"), _T("Show about dialog"));

    wxMenu *testsMenu = new wxMenu;
    testsMenu->Append(ktest_Dialog, _T("Tests"), _T("Tests..."));

    // now append the freshly created menu to the menu bar...
    wxMenuBar *menuBar = new wxMenuBar();
    menuBar->Append(menuFile, _T("&File"));
    menuBar->Append(testsMenu, _T("&Tests"));
    menuBar->Append(helpMenu, _T("&Help"));

    // ... and attach this menu bar to the frame
    SetMenuBar(menuBar);
#endif // wxUSE_MENUS

#if wxUSE_STATUSBAR
    // create a status bar just for fun (by default with 1 pane only)
    CreateStatusBar(2);
    SetStatusText(_T("simple wxWindows test application"));
#endif // wxUSE_STATUSBAR
}


// event handlers

void MyFrame::OnQuit(wxCommandEvent& WXUNUSED(event))
{
    // TRUE is to force the frame to close
    Close(TRUE);
}

void MyFrame::OnAbout(wxCommandEvent& WXUNUSED(event))
{
    wxString msg;
    msg.Printf( _T("KTest (C) 2002 Marco Cavallini\nwww.koansoftware.com\nTest application\n")
                _T("wxWindiws version :  %s"), wxVERSION_STRING);

    wxMessageBox(msg, _T("About ktest"), wxOK | wxICON_INFORMATION, this);
}


void MyFrame::OnDialog(wxCommandEvent& WXUNUSED(event))
{
	m_pDlgTagProperty = new CDlgTagProperty(this, -1, wxEmptyString);
	m_pDlgTagProperty->SetSize(wxSize(450, 300));
	m_pDlgTagProperty->Centre();
    m_pDlgTagProperty->Show() ;
}
