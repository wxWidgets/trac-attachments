///////////////////////////////////////////////////////////////////////////
//
// LecteurDlg.h : header file
//
///////////////////////////////////////////////////////////////////////////

//#include "Imprimante.h"	// Added by ClassView
//#include "InitDialog.h"
//#include "ColorStatic.h"
//#include "Fonts.h"


#if !defined(AFX_LECTEURDLG_H__3FCB0EA9_5DCD_4659_9DFB_1AF77D44A6F3__INCLUDED_)
#define AFX_LECTEURDLG_H__3FCB0EA9_5DCD_4659_9DFB_1AF77D44A6F3__INCLUDED_

#define BIT_LED_ROUGE	0x0200;
#define BIT_LED_JAUNE	0x0400;
#define BIT_LED_VERTE	0x0800;
#define BIT_BUZZER		0x0004;

#define VERSIONLENGTH	80		// length of version
#define SUCCESS			0x01	// function succeeds
#define FAILURE			0x00	// function fails

#define STATUS_OK			{0x00, 0x90, 0x00}	// reader returned status OK
#define FORG				0x01				// forget (or not) last serial number




/////////////////////////////////////////////////////////////////////////////
//
// CLecteurDlg dialog
//
////////////////////////////////////////////////////////////////////////////


class CBorneDlg : public wxDialog
{
// Construction
public:
	CBorneDlg();
	CBorneDlg(wxWindow* parent, wxWindowID id = XRCID("DLG_LECTEUR_DIALOG"), 
		const wxString& title = "Title", const wxPoint& pos = wxDefaultPosition, 
		const wxSize& size = wxDefaultSize, long style = wxDEFAULT_DIALOG_STYLE | wxWANTS_CHARS, 
		const wxString& name = "dialogBox");

	

	

	void OnPaint(wxPaintEvent& event);
	void OnMyButtonClicked( wxCommandEvent &event );
	void OnKeyDown(wxKeyEvent& event);

	

	DECLARE_DYNAMIC_CLASS(CBorneDlg)
    DECLARE_EVENT_TABLE()
};

#endif // !defined(AFX_LECTEURDLG_H__3FCB0EA9_5DCD_4659_9DFB_1AF77D44A6F3__INCLUDED_)
