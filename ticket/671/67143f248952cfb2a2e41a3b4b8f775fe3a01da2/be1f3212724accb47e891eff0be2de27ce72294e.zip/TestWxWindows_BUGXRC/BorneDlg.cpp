//////////////////////////////////////////////////////////////////////////
//
// BorneDlg.cpp : implementation file
//
//////////////////////////////////////////////////////////////////////////

#ifndef WX_PRECOMP
#include "wx/wx.h"
#endif
#include <wx/xrc/xmlres.h>          // XRC XML resouces

#include "stdafx.h"
#include "BorneDlg.h"


//-----------------------------------------------------------------------------
// Event table: connect the events to the handler functions to process them
//-----------------------------------------------------------------------------
BEGIN_EVENT_TABLE(CBorneDlg, wxDialog)
EVT_KEY_DOWN(OnKeyDown)
EVT_BUTTON( XRCID( "my_button" ), CBorneDlg::OnMyButtonClicked )
END_EVENT_TABLE()

/////////////////////////////////////////////////////////////////////////////
//
// CBorneDlg dialog
//
/////////////////////////////////////////////////////////////////////////////

IMPLEMENT_DYNAMIC_CLASS(CBorneDlg, wxDialog)
CBorneDlg::CBorneDlg()
{
	
	
}

CBorneDlg::CBorneDlg(wxWindow* parent, wxWindowID id , 
					 const wxString& title, const wxPoint& pos, 
					 const wxSize& size, long style, 
					 const wxString& name)
{
	wxXmlResource::Get()->LoadDialog(this, parent, "DLG_LECTEUR_DIALOG");
	

}

void CBorneDlg::OnMyButtonClicked( wxCommandEvent &WXUNUSED(event) )
{
    // Construct a message dialog.
    wxMessageDialog msgDlg(this, _("You clicked on My Button"));

    // Show it modally.
    msgDlg.ShowModal();
}



void CBorneDlg::OnKeyDown(wxKeyEvent& event){
	
	wxMessageBox("Quit program?", "Confirm",wxYES_NO | wxCANCEL, this);
	
	
	long keycode = event.GetKeyCode();
	switch ( keycode )
	{
	case 'Q' :
		//m_pImprimante.Free();
		//OnQuit();
		//CDialog::OnOK();
		
		break;
	}

}
