//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by Lecteur.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_LECTEUR_DIALOG              102
#define IDS_CONFERENCE                  102
#define IDS_RESTAURANT                  103
#define IDS_CADEAU                      105
#define IDS_MALLETTE                    106
#define IDR_MAINFRAME                   128
#define IDD_INIT_DIALOG                 135
#define IDB_LOGO_UITP                   154
#define IDB_UITP                        154
#define IDB_LOGO_Calypso                155
#define IDB_FLECHE_NB                   166
#define IDB_FLECHE_BN                   168
#define IDB_BITMAP1                     170
#define IDB_LOGO_GrRATP                 193
#define IDB_GrRATP                      193
#define IDB_LOGO_GLDS                   197
#define IDB_GLDS                        197
#define IDB_LOGO_ASK                    199
#define IDB_CALYPSO                     209
#define IDB_ASK                         210
#define IDD_BORNE_DIALOG                211
#define IDB_CARTES2003                  216
#define IDB_BITMAP2                     219
#define IDB_ITSECURITY                  219
#define IDB_EXPOSIUM                    227
#define IDB_OBERTHUR                    237
#define IDB_EVOLIS                      239
#define IDB_RATP                        241
#define IDB_OBERTHUR_V2                 263
#define IDB_EVOLIS_V2                   265
#define IDB_BITMAP3                     267
#define IDB_ITSECURITY2004              268
#define IDB_CARTES2004                  269
#define IDB_BITMAP6                     270
#define IDB_EVOLIS2004                  270
#define IDB_BITMAP4                     271
#define IDB_RATP2004                    271
#define IDB_BAG                         272
#define IDB_KEYBAG                      273
#define IDB_KEYVESTE                    274
#define IDC_BUTTON1                     1000
#define IDC_STATIC_LIB_INIT             1000
#define IDC_SELINIT                     1000
#define IDC_MYBUTTON                    1000
#define IDC_BREINIT                     1001
#define IDC_LOGO_RATP                   1002
#define IDC_BABANDON                    1002
#define IDC_NOM                         1003
#define IDC_LIB1                        1003
#define IDC_PRENOM                      1006
#define IDC_LIB2                        1006
#define IDC_SOCIETE                     1008
#define IDC_LIB3                        1008
#define IDC_LIBELLE_APPLICATION         1009
#define IDC_PAYS                        1011
#define IDC_LIB4                        1011
#define IDC_NUMPORTEUR                  1012
#define IDC_LIBSUP_CONF                 1012
#define IDC_LIB5                        1012
#define IDC_STATIC_CONFE                1013
#define IDC_CONFRERENCES                1014
#define IDC_RADIO_CONF_J1               1015
#define IDC_RADIO_CONF_J2               1016
#define IDC_RADIO_CONF_J3               1017
#define IDC_STATIC_NUMPORTEUR           1018
#define IDC_RESTAU                      1019
#define IDC_STATIC_RESTAU               1020
#define IDC_LIST1                       1021
#define IDC_STATIC_LIB_PRESENTCARDFR    1022
#define IDC_STATIC_LIB_PRESENTCARDGB    1024
#define IDC_PANEL_NOM                   1028
#define IDC_SCONF                       1031
#define IDC_TCONF                       1032
#define IDC_SRESTAU                     1033
#define IDC_TRESTAU                     1034
#define IDC_SMALLETTE                   1035
#define IDC_TMALLETTE                   1036
#define IDC_SCADEAU                     1037
#define IDC_TCADEAU                     1038
#define IDC_PANEL_CENTRAL               1041
#define IDC_STATIC_PANEL                1042
#define IDC_FLECHE_GBN                  1049
#define IDC_FLECHE_GNB                  1050
#define IDC_FLECHE_DBN                  1051
#define IDC_FLECHE_DNB                  1052
#define IDC_COMBO_TYPE_BORNE            1054
#define IDC_SClock                      1055
#define IDC_COMBO_NUM_SALLE             1055
#define IDC_STATIC_NUM_SALLE            1056
#define IDC_KEYBAG                      1060
#define IDC_KEYVESTE                    1061
#define IDC_SELPLANNING                 1062

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        275
#define _APS_NEXT_COMMAND_VALUE         32774
#define _APS_NEXT_CONTROL_VALUE         1064
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
