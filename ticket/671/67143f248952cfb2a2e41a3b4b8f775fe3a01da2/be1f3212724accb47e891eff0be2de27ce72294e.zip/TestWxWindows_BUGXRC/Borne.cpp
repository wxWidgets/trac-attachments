#include "Borne.h"
//#include "MyFrame.h"


#ifndef WX_PRECOMP
#include "wx/wx.h"
#endif
#include <wx/xrc/xmlres.h>          // XRC XML resouces
#include <wx/image.h>

#include "BorneDlg.h"

IMPLEMENT_APP(CBorneApp)
bool CBorneApp::OnInit()
{
	int nResponse = 0;

	// RESOURCE HANDLING
	wxXmlResource::Get()->InitAllHandlers();
    wxXmlResource::Get()->Load(wxT("res/resource.xrc"));

	// IMAGE HANDLING(PNG,JPEG,GIF)
	wxImage::AddHandler( new wxPNGHandler );
	wxImage::AddHandler( new wxJPEGHandler );
	wxImage::AddHandler( new wxGIFHandler );


	/*CBorneDlg Dlg;
	wxXmlResource::Get()->LoadDialog( &Dlg, NULL, "DLG_LECTEUR_DIALOG" );
	Dlg.ShowModal();*/

	/*wxDialog Dlg;
	wxXmlResource::Get()->LoadDialog( &Dlg, NULL, "DLG_LECTEUR_DIALOG" );
	Dlg.ShowModal();*/

	CBorneDlg dlg(NULL);
	nResponse = dlg.ShowModal();


    return FALSE;
}

