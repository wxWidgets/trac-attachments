// $Header$
////////////////////////////////////////////////////////////////////////////////
//
//   Main TestGetModuleHandle compilation module.
//
////////////////////////////////////////////////////////////////////////////////
//------------------------------------------------------------------------------
#pragma hdrstop
//------------------------------------------------------------------------------
#include <windows.h>
//------------------------------------------------------------------------------
namespace TestGetModuleHandle
{
//------------------------------------------------------------------------------

///////////////////////////////////////////////////////////////////////////////
//
// testGetModuleHandle()
// ---------------------
//
//   Tests the ::GetModuleHandle() Windows API.
//
//   Does not throw.
//
///////////////////////////////////////////////////////////////////////////////

extern "C" void __declspec(dllexport) __stdcall testGetModuleHandle()
{
    {
        HMODULE const hModule( ::GetModuleHandleA( "comctl32.dll" ) );
        if ( hModule )
            ::MessageBox( 0, "::GetModuleHandleA( \"comctl32.dll\" ) call succeeded.", "::GetModuleHandle() test", MB_OK );
        else
            ::MessageBox( 0, "::GetModuleHandleA( \"comctl32.dll\" ) call failed.", "::GetModuleHandle() test", MB_OK );
    }

    {
        HMODULE const hModule( ::GetModuleHandleW( L"comctl32.dll" ) );
        if ( hModule )
            ::MessageBox( 0, "::GetModuleHandleW( L\"comctl32.dll\" ) call succeeded.", "::GetModuleHandle() test", MB_OK );
        else
            ::MessageBox( 0, "::GetModuleHandleW( L\"comctl32.dll\" ) call failed.", "::GetModuleHandle() test", MB_OK );
    }
}


////////////////////////////////////////////////////////////////////////////////
//
// DllMain()
// ---------
//
//   Does not throw.
//
////////////////////////////////////////////////////////////////////////////////

extern "C"
BOOL WINAPI DllMain( HINSTANCE, DWORD, LPVOID )
{
    return TRUE;
}


//------------------------------------------------------------------------------
}  // namespace TestGetModuleHandle
//------------------------------------------------------------------------------
