﻿namespace TestGetModuleHandleDLLLoader
{
    ////////////////////////////////////////////////////////////////////////////
    //
    // -------
    // Program
    // -------
    //
    //   Main application class.
    //
    ////////////////////////////////////////////////////////////////////////////

    class Program
    {
        [System.Runtime.InteropServices.DllImport("testGetModuleHandle.dll")]
        private static extern void testGetModuleHandle();


        ////////////////////////////////////////////////////////////////////////
        //
        // Main()
        // ------
        //
        //   Main program function. Called on program startup. When it exits,
        // the program is done.
        //
        ////////////////////////////////////////////////////////////////////////

        static void Main(string[] commandLineArguments)
        {
            outputAndWait("Press any key to start (opportunity to attach a debugger).");
            testGetModuleHandle();
        }


        ////////////////////////////////////////////////////////////////////////
        //
        // outputAndWait()
        // ---------------
        //
        //   Writes a single line of text to the screen and waits for user to
        // press a key.
        //
        ////////////////////////////////////////////////////////////////////////

        static void outputAndWait(string message)
        {
            System.Console.WriteLine(message);
            System.Console.ReadKey(true);
        }
    }
}
