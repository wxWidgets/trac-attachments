// $Header$
////////////////////////////////////////////////////////////////////////////////
//
//   Main DummyCSP compilation module.
//
////////////////////////////////////////////////////////////////////////////////
//------------------------------------------------------------------------------
#pragma hdrstop
//------------------------------------------------------------------------------
#include <windows.h>
#include <wincrypt.h>
#include "cspdk.h"
//------------------------------------------------------------------------------
namespace DummyCSP
{
//------------------------------------------------------------------------------

////////////////////////////////////////////////////////////////////////////////
//
// Private implementation details for this compilation module.
//
////////////////////////////////////////////////////////////////////////////////

namespace
{
    ///////////////////////////////////////////////////////////////////////////
    //
    // testGetModuleHandle()
    // ---------------------
    //
    //   Tests the ::GetModuleHandle() Windows API.
    //
    //   Does not throw.
    //
    ///////////////////////////////////////////////////////////////////////////

    void testGetModuleHandle()
    {
        {
            HMODULE const hModule( ::GetModuleHandleA( "comctl32.dll" ) );
            if ( hModule )
                ::MessageBox( 0, "::GetModuleHandleA( \"comctl32.dll\" ) call succeeded.", "::GetModuleHandle() test", MB_OK );
            else
                ::MessageBox( 0, "::GetModuleHandleA( \"comctl32.dll\" ) call failed.", "::GetModuleHandle() test", MB_OK );
        }

        {
            HMODULE const hModule( ::GetModuleHandleW( L"comctl32.dll" ) );
            if ( hModule )
                ::MessageBox( 0, "::GetModuleHandleW( L\"comctl32.dll\" ) call succeeded.", "::GetModuleHandle() test", MB_OK );
            else
                ::MessageBox( 0, "::GetModuleHandleW( L\"comctl32.dll\" ) call failed.", "::GetModuleHandle() test", MB_OK );
        }
    }
}  // anonymous namespace


////////////////////////////////////////////////////////////////////////////////
//
// CSP interface functions.
// ------------------------
//
//   None of these functions may throw.
//
////////////////////////////////////////////////////////////////////////////////

BOOL WINAPI CPAcquireContext ( HCRYPTPROV *, LPCSTR, DWORD, PVTableProvStruc                          ) { testGetModuleHandle(); return FALSE; }
BOOL WINAPI CPReleaseContext ( HCRYPTPROV, DWORD                                                      ) {                        return FALSE; }
BOOL WINAPI CPGenKey         ( HCRYPTPROV, ALG_ID, DWORD, HCRYPTKEY *                                 ) {                        return FALSE; }
BOOL WINAPI CPDeriveKey      ( HCRYPTPROV, ALG_ID, HCRYPTHASH, DWORD, HCRYPTKEY *                     ) {                        return FALSE; }
BOOL WINAPI CPDestroyKey     ( HCRYPTPROV, HCRYPTKEY                                                  ) {                        return FALSE; }
BOOL WINAPI CPSetKeyParam    ( HCRYPTPROV, HCRYPTKEY, DWORD, BYTE CONST *, DWORD                      ) {                        return FALSE; }
BOOL WINAPI CPGetKeyParam    ( HCRYPTPROV, HCRYPTKEY, DWORD, LPBYTE, LPDWORD, DWORD                   ) {                        return FALSE; }
BOOL WINAPI CPSetProvParam   ( HCRYPTPROV, DWORD, BYTE CONST *, DWORD                                 ) {                        return FALSE; }
BOOL WINAPI CPGetProvParam   ( HCRYPTPROV, DWORD, LPBYTE, LPDWORD, DWORD                              ) {                        return FALSE; }
BOOL WINAPI CPSetHashParam   ( HCRYPTPROV, HCRYPTHASH, DWORD, BYTE CONST *, DWORD                     ) {                        return FALSE; }
BOOL WINAPI CPGetHashParam   ( HCRYPTPROV, HCRYPTHASH, DWORD, LPBYTE, LPDWORD, DWORD                  ) {                        return FALSE; }
BOOL WINAPI CPExportKey      ( HCRYPTPROV, HCRYPTKEY, HCRYPTKEY, DWORD, DWORD, LPBYTE, LPDWORD        ) {                        return FALSE; }
BOOL WINAPI CPImportKey      ( HCRYPTPROV, BYTE CONST *, DWORD, HCRYPTKEY, DWORD, HCRYPTKEY *         ) {                        return FALSE; }
BOOL WINAPI CPEncrypt        ( HCRYPTPROV, HCRYPTKEY, HCRYPTHASH, BOOL, DWORD, LPBYTE, LPDWORD, DWORD ) {                        return FALSE; }
BOOL WINAPI CPDecrypt        ( HCRYPTPROV, HCRYPTKEY, HCRYPTHASH, BOOL, DWORD, LPBYTE, LPDWORD        ) {                        return FALSE; }
BOOL WINAPI CPCreateHash     ( HCRYPTPROV, ALG_ID, HCRYPTKEY, DWORD, HCRYPTHASH *                     ) {                        return FALSE; }
BOOL WINAPI CPHashData       ( HCRYPTPROV, HCRYPTHASH, BYTE CONST *, DWORD, DWORD                     ) {                        return FALSE; }
BOOL WINAPI CPHashSessionKey ( HCRYPTPROV, HCRYPTHASH, HCRYPTKEY, DWORD                               ) {                        return FALSE; }
BOOL WINAPI CPSignHash       ( HCRYPTPROV, HCRYPTHASH, DWORD, LPCWSTR, DWORD, LPBYTE, LPDWORD         ) {                        return FALSE; }
BOOL WINAPI CPDestroyHash    ( HCRYPTPROV, HCRYPTHASH                                                 ) {                        return FALSE; }
BOOL WINAPI CPVerifySignature( HCRYPTPROV, HCRYPTHASH, BYTE CONST *, DWORD, HCRYPTKEY, LPCWSTR, DWORD ) {                        return FALSE; }
BOOL WINAPI CPGenRandom      ( HCRYPTPROV, DWORD, LPBYTE                                              ) {                        return FALSE; }
BOOL WINAPI CPGetUserKey     ( HCRYPTPROV, DWORD, HCRYPTKEY *                                         ) {                        return FALSE; }
BOOL WINAPI CPDuplicateHash  ( HCRYPTPROV, HCRYPTHASH, LPDWORD, DWORD, HCRYPTHASH *                   ) {                        return FALSE; }
BOOL WINAPI CPDuplicateKey   ( HCRYPTPROV, HCRYPTKEY, LPDWORD, DWORD, HCRYPTKEY *                     ) {                        return FALSE; }


////////////////////////////////////////////////////////////////////////////////
//
// DllMain()
// ---------
//
//   Does not throw.
//
////////////////////////////////////////////////////////////////////////////////

extern "C"
BOOL WINAPI DllMain( HINSTANCE, DWORD, LPVOID )
{
    return TRUE;
}


//------------------------------------------------------------------------------
}  // namespace DummyCSP
//------------------------------------------------------------------------------
