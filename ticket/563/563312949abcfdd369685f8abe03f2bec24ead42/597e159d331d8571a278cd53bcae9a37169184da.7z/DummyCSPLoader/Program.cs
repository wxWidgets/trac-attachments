﻿using CSPParameters = System.Security.Cryptography.CspParameters;
using CSPProviderFlags = System.Security.Cryptography.CspProviderFlags;
using RSACryptoServiceProvider = System.Security.Cryptography.RSACryptoServiceProvider;


namespace DummyCSPLoader
{
    ////////////////////////////////////////////////////////////////////////////
    //
    // -------
    // Program
    // -------
    //
    //   Main application class.
    //
    ////////////////////////////////////////////////////////////////////////////

    class Program
    {
        ////////////////////////////////////////////////////////////////////////
        //
        // Main()
        // ------
        //
        //   Main program function. Called on program startup. When it exits,
        // the program is done.
        //
        ////////////////////////////////////////////////////////////////////////

        static void Main(string[] commandLineArguments)
        {
            outputAndWait("Press any key to start (opportunity to attach a debugger).");

            try
            {
                CSPParameters cspParameters = new CSPParameters();
                cspParameters.ProviderType = 1;
                cspParameters.ProviderName = "DummyCSP";
                cspParameters.Flags = CSPProviderFlags.UseDefaultKeyContainer;
                RSACryptoServiceProvider key = new RSACryptoServiceProvider(cspParameters);
            }
            catch
            {
            }

            outputAndWait("Done. Press any key to terminate the program.");
        }


        ////////////////////////////////////////////////////////////////////////
        //
        // outputAndWait()
        // ---------------
        //
        //   Writes a single line of text to the screen and waits for user to
        // press a key.
        //
        ////////////////////////////////////////////////////////////////////////

        static void outputAndWait(string message)
        {
            System.Console.WriteLine(message);
            System.Console.ReadKey(true);
        }
    }
}
