import wx
from wx import xrc

class TestApp(wx.App):
	def OnInit(self):
		xrc.XmlResource.Get().InitAllHandlers()
		self.resources = xrc.XmlResource('bugtest.xrc', 0)
		self.dlg = self.resources.LoadDialog(None, 'ID_Dialog')
		self.dlg.Show()
		self.dlg.Bind(wx.EVT_BUTTON, self.on_button, id = xrc.XRCID('ID_But'))
		return True

	def on_button(self, evt = None):
		xrc.XRCCTRL(self.dlg, 'ID_Text').SetValue("New Text")
		xrc.XRCCTRL(self.dlg, 'ID_Html').SetPage("New Text")
		print "but pressed"

if __name__ == "__main__":
	app = TestApp(0)
	app.MainLoop()
