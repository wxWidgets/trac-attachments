#include <wx/app.h>
#include <wx/collpane.h>
#include <wx/frame.h>
#include <wx/panel.h>
#include <wx/scrolwin.h>
#include <wx/sizer.h>
#include <wx/stattext.h>
#include <wx/window.h>
#include <wx/wrapsizer.h>

class TextListCtrl : public wxWindow {
 public:
  TextListCtrl(wxWindow* parent, const wxColour& colour)
      : wxWindow{parent, wxID_ANY} {
    auto sizer = new wxWrapSizer{wxHORIZONTAL};
    SetSizer(sizer);
    for (int i = 0; i < 20; ++i) {
      wxString t;
      t.Printf("(hello world hello world %d)", i);
      auto stext = new wxStaticText{this, wxID_ANY, t};
      stext->SetForegroundColour(colour);
      sizer->Add(stext, wxSizerFlags{});
    }
  }
};

class Frame : public wxFrame {
 public:
  Frame()
      : wxFrame(nullptr, wxID_ANY, "test-wxwidgets", wxDefaultPosition,
                wxSize{800, 600}) {
    auto frame_sizer = new wxBoxSizer{wxVERTICAL};
    SetSizer(frame_sizer);

    // 1. Insert TextListCtrl directly in the wxFrame
    frame_sizer->Add(new TextListCtrl{this, *wxBLUE}, wxSizerFlags{}.Expand());

    auto scrollwin = new wxScrolledWindow{this, wxID_ANY, wxDefaultPosition,
                                          wxDefaultSize, wxVSCROLL};
    scrollwin->ShowScrollbars(wxSHOW_SB_NEVER, wxSHOW_SB_ALWAYS);
    auto scrollwin_sizer = new wxBoxSizer{wxVERTICAL};
    scrollwin->SetSizer(scrollwin_sizer);
    // 2. Insert TextListCtrl directly inside a wxScrolledWindow
    scrollwin_sizer->Add(new TextListCtrl{scrollwin, *wxRED},
                         wxSizerFlags{}.Expand());

    // 3. Insert TextListCtrl inside a wxCollapsiblePane
    for (int i = 0; i < 5; ++i) {
      auto colpane =
          new wxCollapsiblePane{scrollwin,
                                wxID_ANY,
                                wxString::Format("colpane %d", i),
                                wxDefaultPosition,
                                wxDefaultSize,
                                wxCP_DEFAULT_STYLE | wxCP_NO_TLW_RESIZE};
      /*
      colpane->Bind(
          wxEVT_COLLAPSIBLEPANE_CHANGED,
          [scrollwin](wxCollapsiblePaneEvent&) { scrollwin->FitInside(); });
          */
      auto pane = colpane->GetPane();
      auto vsizer = new wxBoxSizer{wxVERTICAL};
      pane->SetSizer(vsizer);
      vsizer->Add(new TextListCtrl{pane, *wxRED}, wxSizerFlags{}.Expand());
      vsizer->Add(new TextListCtrl{pane, *wxBLUE}, wxSizerFlags{}.Expand());
      colpane->Expand();

      scrollwin_sizer->Add(colpane, wxSizerFlags{1}.Expand());
    }

    frame_sizer->Add(scrollwin, wxSizerFlags{1}.Expand());
  }
};

class App : public wxApp {
 public:
  bool OnInit() override {
    auto frame = new Frame();
    frame->Show();
    return true;
  }
};

IMPLEMENT_APP(App)
