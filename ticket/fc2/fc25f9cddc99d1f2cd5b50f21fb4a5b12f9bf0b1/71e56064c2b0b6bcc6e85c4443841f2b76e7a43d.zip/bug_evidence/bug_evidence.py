# file: bug_evidence.py


import wx


class Frame(wx.Frame):
	
	def __init__(self):
		
		wx.Frame.__init__(self, None, -1, 'bug evidence')
		self.Bind(wx.EVT_PAINT, self.OnPaint)
		
	def OnPaint(self, event):
		
		dc = wx.PaintDC(self)

		# according to the manual, this should affect the bitmap colors
		dc.SetTextForeground(wx.Colour(255, 0, 0))
		dc.SetTextBackground(wx.Colour(0, 0, 0))

		# draw bitmap
		img = wx.Image('bitmap.bmp')
		#img.ConvertToMono(255, 255, 255)
		bmp = wx.BitmapFromImage(img, 1)
		dc.DrawBitmap(bmp, 0, 0)

		# draw text
		dc.SetBackgroundMode(wx.SOLID)
		dc.DrawText('Bitmap depth is %d' % bmp.GetDepth(), 0, 100)



app = wx.PySimpleApp()
frame = Frame()
frame.Show()
app.MainLoop()
