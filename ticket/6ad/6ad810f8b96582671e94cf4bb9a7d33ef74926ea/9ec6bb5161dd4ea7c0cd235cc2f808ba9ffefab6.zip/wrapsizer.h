#ifndef __WXWRAPSIZER__
#define __WXWRAPSIZER__

#include "wx/sizer.h"

//---------------------------------------------------------------------------
// wxWrapSizer - A box sizer that can wrap items on several lines when 
// widths exceed available width.
//---------------------------------------------------------------------------

// Borrow unused flag value
#define wxEXTEND_LAST_ON_EACH_LINE	wxFULL_REPAINT_ON_RESIZE



class wxWrapSizer: public wxBoxSizer
{
	DECLARE_DYNAMIC_CLASS(wxWrapSizer);
public:
    wxWrapSizer( int orient=wxHORIZONTAL, int flags=wxEXTEND_LAST_ON_EACH_LINE );
    virtual ~wxWrapSizer();

    virtual void RecalcSizes();
    virtual wxSize CalcMin();
    
    virtual bool InformFirstDirection( int direction, int size, int availableOtherDir );
    
protected:
    int m_prim_size_last;    // Size in primary direction last time
    int m_n_line;            // Number of lines
    wxBoxSizer m_rows;       // Rows of items
    int m_flags;

    void AdjustPropLastItem(wxSizer *psz, wxSizerItem *itemLast);    
private:
};

#endif // __WXWRAP_SIZER__

