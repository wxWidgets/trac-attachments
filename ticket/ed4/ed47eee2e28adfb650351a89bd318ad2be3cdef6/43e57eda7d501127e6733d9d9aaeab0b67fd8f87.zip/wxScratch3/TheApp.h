#include <wx/wx.h>

class CHelloWorld : public wxApp
{
	public:
		virtual bool OnInit();
};
