#include "TheApp.h"
#include <wx/frame.h>
#include <wx/panel.h>
#include <wx/sizer.h>
#include <wx/button.h>
#include <wx/grid.h>

namespace
{
   struct CGridWindow : public wxFrame
   {
      CGridWindow(wxWindow & rParent)
         : wxFrame(&rParent, wxID_ANY, "Grid Window")
      {
         wxGrid * pGrid = new wxGrid(this, wxID_ANY);
         pGrid->CreateGrid(10, 10);
         pGrid->SetCellValue(0, 0, "Please crash");
      }
   };

   struct CMainWindow : public wxFrame
   {
      CMainWindow()
         : wxFrame(0, wxID_ANY, "Main Window")
      {
         wxPanel * pMainPanel = new wxPanel(this);
         wxBoxSizer * pMainPanelSizer = new wxBoxSizer(wxVERTICAL);
         pMainPanel->SetSizer(pMainPanelSizer);

         wxButton * pLauncher =
            new wxButton(pMainPanel, wxID_ANY, "Launch window");
         Connect
         	(wxEVT_COMMAND_BUTTON_CLICKED,
         	 wxCommandEventHandler(CMainWindow::OnButtonClicked),
         	 0,
         	 this);
         //Connect
         //   (wxEVT_CLOSE_WINDOW,
         //    wxCloseEventHandler(CMainWindow::OnCloseEvent),
         //    0,
         //    this);
         pMainPanelSizer->Add(pLauncher);
      }

      void OnButtonClicked(wxCommandEvent &)
      {
         CGridWindow * pGridWindow = new CGridWindow(*this);
         pGridWindow->Show();
      }

      //void OnCloseEvent(wxCloseEvent &)
      //{
      //   DestroyChildren();
      //   Destroy();
      //}
   };
}

IMPLEMENT_APP(CHelloWorld)

bool CHelloWorld::OnInit()
{
   CMainWindow * pMainWindow = new CMainWindow;
   pMainWindow->Show();
   SetTopWindow(pMainWindow);
   return true;
}
