//
// mingw32-make -fmakefile.gcc MONOLITHIC=1 BUILD=release SHARED=1 RUNTIME_LIBS=dynamic UNICODE=1
//
#include "wx/wxprec.h"

#ifdef __BORLANDC__
    #pragma hdrstop
#endif

#ifndef WX_PRECOMP
    #include "wx/wx.h"
#endif


class MyApp : public wxApp
{
public:
    virtual bool OnInit();
};

class MyFrame : public wxFrame
{
public:
    MyFrame(const wxString& title, const wxPoint& pos, const wxSize& size);
private:
    DECLARE_EVENT_TABLE()
};

class MyCanvas: public wxPanel
{
public:
    MyCanvas( wxWindow* parent, wxWindowID id, const wxPoint& pos, const wxSize& size);
    void OnPaint(wxPaintEvent &event);
protected:
    void DrawTestLines( int x, int y, int width, wxDC &dc );
private:
    DECLARE_EVENT_TABLE()
};

IMPLEMENT_APP(MyApp)

bool MyApp::OnInit()
{
    MyFrame *frame = new MyFrame(_T("Scroll test"), wxPoint(50, 50), wxSize(550, 340));
    frame->Show(true);
    SetTopWindow(frame);
    return true;
}


BEGIN_EVENT_TABLE(MyCanvas, wxPanel)
    EVT_PAINT  (MyCanvas::OnPaint)
END_EVENT_TABLE()


MyCanvas::MyCanvas(wxWindow* parent, wxWindowID id, const wxPoint& pos, const wxSize& size)
    : wxPanel(parent, id, pos, size, wxTAB_TRAVERSAL | wxWANTS_CHARS)
{
}

void MyCanvas::DrawTestLines( int x, int y, int width, wxDC &dc )
{
    dc.SetPen( wxPen( wxT("black"), width, wxSOLID) );
    dc.SetBrush( *wxRED_BRUSH );
    dc.DrawText(wxString::Format(wxT("Testing lines of width %d"), width), x + 10, y - 10);
    dc.DrawRectangle( x+10, y+10, 100, 190 );

    dc.DrawText(_T("Solid/dot/short dash/long dash/dot dash"), x + 150, y + 10);
    dc.SetPen( wxPen( wxT("black"), width, wxSOLID) );
    dc.DrawLine( x+20, y+20, 100, y+20 );
    dc.SetPen( wxPen( wxT("black"), width, wxDOT) );
    dc.DrawLine( x+20, y+30, 100, y+30 );
    dc.SetPen( wxPen( wxT("black"), width, wxSHORT_DASH) );
    dc.DrawLine( x+20, y+40, 100, y+40 );
    dc.SetPen( wxPen( wxT("black"), width, wxLONG_DASH) );
    dc.DrawLine( x+20, y+50, 100, y+50 );
    dc.SetPen( wxPen( wxT("black"), width, wxDOT_DASH) );
    dc.DrawLine( x+20, y+60, 100, y+60 );
}


void MyCanvas::OnPaint(wxPaintEvent &WXUNUSED(event))
{
    wxPaintDC dc(this);
    PrepareDC(dc);

    DrawTestLines( 0, 100, 0, dc );
    DrawTestLines( 0, 320, 1, dc );
    DrawTestLines( 0, 540, 2, dc );
    DrawTestLines( 0, 760, 6, dc );
}


BEGIN_EVENT_TABLE(MyFrame, wxFrame)
END_EVENT_TABLE()

MyFrame::MyFrame(const wxString& title, const wxPoint& pos, const wxSize& size)
       : wxFrame((wxFrame *)NULL, wxID_ANY, title, pos, size,
                 wxDEFAULT_FRAME_STYLE | wxNO_FULL_REPAINT_ON_RESIZE)
{
    wxTextCtrl* txt = new wxTextCtrl(this, wxID_ANY, 
        wxT("To see unwanted scrolling:\n-Scroll panel\n-Click here\n-Click panel"),
        wxDefaultPosition, wxDefaultSize, wxTE_MULTILINE);
    wxScrolledWindow* sw = new wxScrolledWindow(this, wxID_ANY, wxDefaultPosition, wxDefaultSize,
                           wxHSCROLL | wxVSCROLL | wxNO_FULL_REPAINT_ON_RESIZE);

    wxSize sz = wxGetDisplaySize();
    MyCanvas* cv = new MyCanvas( sw, wxID_ANY, wxDefaultPosition, wxSize(sz.x, sz.y) );
    sw->SetScrollbars( 10, 10, sz.x, sz.y );
    
    wxBoxSizer* sizer = new wxBoxSizer(wxVERTICAL);
    SetSizer(sizer);
    sizer->Add(txt, 0, wxGROW | wxALL, 5);
    sizer->Add(sw, 1, wxGROW | wxALL, 5);
}


