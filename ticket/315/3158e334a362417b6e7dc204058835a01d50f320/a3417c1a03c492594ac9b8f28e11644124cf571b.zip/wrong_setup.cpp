/////////////////////////////////////////////////////////////////////////////
// Name:        wrong_setup.cpp
// Purpose:     Error message in case of wrong setup
// Author:      Wlodzimierz ABX Skiba
// Modified by:
// Created:     26/09/03
// RCS-ID:      $Id: wrong_setup.cpp,v 1.0 2003/09/26 12:00:00 ABX Exp $
// Copyright:   (c) Julian Smart
// Licence:     wxWindows licence
/////////////////////////////////////////////////////////////////////////////

#ifndef ERROR_MESSAGE
    #define ERROR_MESSAGE "Conflict between setup.h and expected settings"
#endif

#include "wx/msgdlg.h"

class MyApp : public wxApp
{
public:
    virtual bool OnInit();
};

IMPLEMENT_APP(MyApp)

bool MyApp::OnInit()
{
    wxMessageBox( _T(ERROR_MESSAGE), _T("Building error"), wxOK | wxICON_ERROR );
    return FALSE;
}

