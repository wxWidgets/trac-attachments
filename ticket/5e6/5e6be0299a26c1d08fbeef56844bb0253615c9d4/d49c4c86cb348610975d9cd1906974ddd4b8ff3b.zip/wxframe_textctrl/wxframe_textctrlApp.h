/***************************************************************
 * Name:      wxframe_textctrlApp.h
 * Purpose:   Defines Application Class
 * Author:    asd ()
 * Created:   2009-10-12
 * Copyright: asd ()
 * License:
 **************************************************************/

#ifndef WXFRAME_TEXTCTRLAPP_H
#define WXFRAME_TEXTCTRLAPP_H

#include <wx/app.h>

class wxframe_textctrlApp : public wxApp
{
    public:
        virtual bool OnInit();
};

#endif // WXFRAME_TEXTCTRLAPP_H
