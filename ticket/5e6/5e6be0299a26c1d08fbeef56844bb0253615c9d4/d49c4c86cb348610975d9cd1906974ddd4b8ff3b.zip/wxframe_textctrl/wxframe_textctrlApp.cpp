/***************************************************************
 * Name:      wxframe_textctrlApp.cpp
 * Purpose:   Code for Application Class
 * Author:    asd ()
 * Created:   2009-10-12
 * Copyright: asd ()
 * License:
 **************************************************************/

#include "wxframe_textctrlApp.h"

//(*AppHeaders
#include "wxframe_textctrlMain.h"
#include <wx/image.h>
//*)

IMPLEMENT_APP(wxframe_textctrlApp);

bool wxframe_textctrlApp::OnInit()
{
    //(*AppInitialize
    bool wxsOK = true;
    wxInitAllImageHandlers();
    if ( wxsOK )
    {
    	wxframe_textctrlFrame* Frame = new wxframe_textctrlFrame(0);
    	Frame->Show();
    	SetTopWindow(Frame);
    }
    //*)
    return wxsOK;

}
