/***************************************************************
 * Name:      wxframe_textctrlMain.cpp
 * Purpose:   Code for Application Frame
 * Author:    asd ()
 * Created:   2009-10-12
 * Copyright: asd ()
 * License:
 **************************************************************/

#include "wxframe_textctrlMain.h"
#include <wx/msgdlg.h>

//(*InternalHeaders(wxframe_textctrlFrame)
#include <wx/string.h>
#include <wx/intl.h>
//*)

//helper functions
enum wxbuildinfoformat {
    short_f, long_f };

wxString wxbuildinfo(wxbuildinfoformat format)
{
    wxString wxbuild(wxVERSION_STRING);

    if (format == long_f )
    {
#if defined(__WXMSW__)
        wxbuild << _T("-Windows");
#elif defined(__UNIX__)
        wxbuild << _T("-Linux");
#endif

#if wxUSE_UNICODE
        wxbuild << _T("-Unicode build");
#else
        wxbuild << _T("-ANSI build");
#endif // wxUSE_UNICODE
    }

    return wxbuild;
}

//(*IdInit(wxframe_textctrlFrame)
const long wxframe_textctrlFrame::ID_TEXTCTRL1 = wxNewId();
const long wxframe_textctrlFrame::ID_TEXTCTRL2 = wxNewId();
const long wxframe_textctrlFrame::idMenuQuit = wxNewId();
const long wxframe_textctrlFrame::ID_STATUSBAR1 = wxNewId();
//*)

BEGIN_EVENT_TABLE(wxframe_textctrlFrame,wxFrame)
    //(*EventTable(wxframe_textctrlFrame)
    //*)
END_EVENT_TABLE()

wxframe_textctrlFrame::wxframe_textctrlFrame(wxWindow* parent,wxWindowID id)
{
    //(*Initialize(wxframe_textctrlFrame)
    wxMenuItem* MenuItem1;
    wxMenu* Menu1;
    wxMenu* Menu3;
    wxBoxSizer* sizer;
    wxMenuBar* MenuBar1;

    Create(parent, id, wxEmptyString, wxDefaultPosition, wxDefaultSize, wxDEFAULT_FRAME_STYLE, _T("id"));
    sizer = new wxBoxSizer(wxVERTICAL);
    TextCtrl1 = new wxTextCtrl(this, ID_TEXTCTRL1, _("Text"), wxDefaultPosition, wxDefaultSize, 0, wxDefaultValidator, _T("ID_TEXTCTRL1"));
    sizer->Add(TextCtrl1, 1, wxALL|wxALIGN_LEFT|wxALIGN_BOTTOM, 5);
    ctrl2 = new wxTextCtrl(this, ID_TEXTCTRL2, _("Text"), wxDefaultPosition, wxDefaultSize, 0, wxDefaultValidator, _T("ID_TEXTCTRL2"));
    sizer->Add(ctrl2, 1, wxALL|wxALIGN_LEFT|wxALIGN_BOTTOM, 5);
    SetSizer(sizer);
    MenuBar1 = new wxMenuBar();
    Menu1 = new wxMenu();
    MenuItem1 = new wxMenuItem(Menu1, idMenuQuit, _("Quit\tAlt-F4"), _("Quit the application"), wxITEM_NORMAL);
    Menu1->Append(MenuItem1);
    MenuBar1->Append(Menu1, _("&File"));
    Menu3 = new wxMenu();
    MenuItem3 = new wxMenuItem(Menu3, wxID_COPY, _("Copy"), wxEmptyString, wxITEM_NORMAL);
    Menu3->Append(MenuItem3);
    MenuItem4 = new wxMenuItem(Menu3, wxID_PASTE, _("Paste"), wxEmptyString, wxITEM_NORMAL);
    Menu3->Append(MenuItem4);
    MenuBar1->Append(Menu3, _("Edit"));
    SetMenuBar(MenuBar1);
    StatusBar1 = new wxStatusBar(this, ID_STATUSBAR1, 0, _T("ID_STATUSBAR1"));
    int __wxStatusBarWidths_1[1] = { -1 };
    int __wxStatusBarStyles_1[1] = { wxSB_NORMAL };
    StatusBar1->SetFieldsCount(1,__wxStatusBarWidths_1);
    StatusBar1->SetStatusStyles(1,__wxStatusBarStyles_1);
    SetStatusBar(StatusBar1);
    sizer->Fit(this);
    sizer->SetSizeHints(this);

    Connect(idMenuQuit,wxEVT_COMMAND_MENU_SELECTED,(wxObjectEventFunction)&wxframe_textctrlFrame::OnQuit);
    //*)
}

wxframe_textctrlFrame::~wxframe_textctrlFrame()
{
    //(*Destroy(wxframe_textctrlFrame)
    //*)
}

void wxframe_textctrlFrame::OnQuit(wxCommandEvent& event)
{
    Close();
}

void wxframe_textctrlFrame::OnAbout(wxCommandEvent& event)
{
    wxString msg = wxbuildinfo(long_f);
    wxMessageBox(msg, _("Welcome to..."));
}
