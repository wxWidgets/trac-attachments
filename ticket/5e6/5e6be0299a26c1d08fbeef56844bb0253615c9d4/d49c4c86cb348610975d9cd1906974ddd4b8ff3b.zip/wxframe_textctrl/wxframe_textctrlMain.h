/***************************************************************
 * Name:      wxframe_textctrlMain.h
 * Purpose:   Defines Application Frame
 * Author:    asd ()
 * Created:   2009-10-12
 * Copyright: asd ()
 * License:
 **************************************************************/

#ifndef WXFRAME_TEXTCTRLMAIN_H
#define WXFRAME_TEXTCTRLMAIN_H

//(*Headers(wxframe_textctrlFrame)
#include <wx/sizer.h>
#include <wx/menu.h>
#include <wx/statusbr.h>
#include <wx/frame.h>
#include <wx/textctrl.h>
//*)

class wxframe_textctrlFrame: public wxFrame
{
    public:

        wxframe_textctrlFrame(wxWindow* parent,wxWindowID id = -1);
        virtual ~wxframe_textctrlFrame();

    private:

        //(*Handlers(wxframe_textctrlFrame)
        void OnQuit(wxCommandEvent& event);
        void OnAbout(wxCommandEvent& event);
        //*)

        //(*Identifiers(wxframe_textctrlFrame)
        static const long ID_TEXTCTRL1;
        static const long ID_TEXTCTRL2;
        static const long idMenuQuit;
        static const long ID_STATUSBAR1;
        //*)

        //(*Declarations(wxframe_textctrlFrame)
        wxStatusBar* StatusBar1;
        wxMenuItem* MenuItem3;
        wxTextCtrl* TextCtrl1;
        wxMenuItem* MenuItem4;
        wxTextCtrl* ctrl2;
        //*)

        DECLARE_EVENT_TABLE()
};

#endif // WXFRAME_TEXTCTRLMAIN_H
