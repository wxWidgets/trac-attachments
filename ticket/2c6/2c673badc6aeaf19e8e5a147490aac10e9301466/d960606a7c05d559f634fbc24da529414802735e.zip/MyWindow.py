'''
Created on 2012-7-5

@author: Administrator
'''

class Example(wx.Frame):
    def __init__(self,*args,**kw):
        super(Example,self).__init__(*args,**kw)
        self.InitUI()
    def InitUI(self):
        grid = wx.GridSizer(2,2,10,10)
        ctrl1 = wx.TextCtrl(self,-1)
        ctrl2 = wx.TextCtrl(self,-1)
        ctrl3 = wx.TextCtrl(self,-1)
        ctrl4 = wx.TextCtrl(self,-1)
        '''
        grid.AddMany([(MyWindow(self),0,wx.EXPAND|wx.TOP|wx.LEFT,9),
                       (MyWindow(self), 0, wx.EXPAND|wx.TOP|wx.RIGHT, 9), 
                       (MyWindow(self), 0, wx.EXPAND|wx.BOTTOM|wx.LEFT, 9), 
                       (MyWindow(self), 0, wx.EXPAND|wx.BOTTOM|wx.RIGHT, 9)])
        '''
        
        #EVT_SET_FOCUS(self.field, self.onFocusGained)
        #EVT_KILL_FOCUS(self.field, self.onFocusLost)
        ctrl1.Bind(wx.EVT_SET_FOCUS, self.onFocusGained)
        ctrl1.Bind(wx.EVT_KILL_FOCUS, self.onFocusLost)
        
        self.curFieldValue = None
        
        grid.AddMany([(ctrl1,0,wx.EXPAND|wx.TOP|wx.LEFT,9),
                       (ctrl2, 0, wx.EXPAND|wx.TOP|wx.RIGHT, 9), 
                       (ctrl3, 0, wx.EXPAND|wx.BOTTOM|wx.LEFT, 9), 
                       (ctrl4, 0, wx.EXPAND|wx.BOTTOM|wx.RIGHT, 9)])
        self.SetSizer(grid)

        self.SetSize((350, 250))
        self.SetTitle('Focus event')
        self.Centre()
        self.Show(True) 
    def onFocusGained(self, event):
        self.curFieldValue = event.GetEventObject().GetValue()
        print self.curFieldValue
    def onFocusLost(self, event):
        if event.GetEventObject().GetValue() != self.curFieldValue:
            print 'edit'
            # Field value changed -> respond appropriately.
  
def main():
    
    ex = wx.App()
    Example(None)
    ex.MainLoop()    


if __name__ == '__main__':
    main()  