#!/usr/bin/python

"""
__version__ = "$Revision: 1.1 $"
__date__ = "$Date: 2001/08/06 20:32:41 $"

Font Families:
wxDEFAULT  Chooses a default font.  
wxDECORATIVE  A decorative font.  
wxROMAN  A formal, serif font.  
wxSCRIPT  A handwriting font.  
wxSWISS  A sans-serif font.  
wxMODERN  A fixed pitch font. 

"""

import PythonCardPrototype
from PythonCardPrototype.config import configOptions
import os, sys
from wxPython.wx import *

class FontTests(PythonCardPrototype.model.Background):

    def __init__(self, aParent, aId, aStackRsrc, aBgRsrc):
        PythonCardPrototype.model.Background.__init__(self, aParent, aId, aStackRsrc, aBgRsrc)

        self.fontFaceName = ''
        self.fontFamily = wxDEFAULT
        self.fontStyle = wxNORMAL
        self.fontWeight = wxNORMAL
        self.fontPointSize = 8
        self.fontUnderline = 0
        
        self.enumerateFonts()
        self.listFontDetails()

    def enumerateFonts(self):
        e = wxFontEnumerator()
        e.EnumerateFacenames()
        list = [' None'] + e.GetFacenames()
        list.sort()
        self.components.listFaceNames.items = list


    def familyName(self, id):
        names = ['wxDEFAULT', 'wxDECORATIVE', 'wxROMAN', 'wxSCRIPT', 'wxSWISS', 'wxMODERN']
        return names[id - 70]

    def listFontDetails(self):
        fStr = ''
        f = self.components.fldTextField._delegate.GetFont()
        #fStr += 'Default encoding: %s' % str(wxFont.GetDefaultEncoding())
        fStr += 'Face name: %s\n' % str(f.GetFaceName())
        fStr += 'Family: %s\n' % self.familyName(f.GetFamily())
        
        # 2001-11-14 GetFontId() isn't in 2.3.2b6
        #fStr += 'Font id: %s\n' % str(f.GetFontId())
        
        fStr += 'Point size: %s\n' % str(f.GetPointSize())
        fStr += 'Style: %s\n' % str(f.GetStyle())
        fStr += 'Underline: %s\n' % str(f.GetUnderlined())
        fStr += 'Weight: %s\n' % str(f.GetWeight())
        self.components.fldFontDetails.text = fStr

    def newFont(self):
        #print "self.fontWeight", self.fontWeight
        f = wxFont(self.fontPointSize,
                      self.fontFamily,
                      self.fontStyle,
                      self.fontWeight,
                      self.fontUnderline,
                      self.fontFaceName)
        return f
            
    def changeFaceName(self, faceName):
        if faceName == ' None':
            self.fontFaceName = ''
            f = self.newFont()
        else:
            self.fontFaceName = faceName
            f = self.newFont()
        self.components.fldTextField._delegate.SetFont(f)
        self.components.fldTextArea._delegate.SetFont(f)

    def changeFamily(self, family):
        self.fontFaceName = ''
        self.fontFamily = eval(family)
        f = self.newFont()
        self.components.fldTextField._delegate.SetFont(f)
        self.components.fldTextArea._delegate.SetFont(f)
        
    def changeStyle(self, style):
        self.fontStyle = eval(style)
        f = self.newFont()
        self.components.fldTextField._delegate.SetFont(f)
        self.components.fldTextArea._delegate.SetFont(f)

    def changeWeight(self, weight):
        self.fontWeight = eval(weight)
        f = self.newFont()
        self.components.fldTextField._delegate.SetFont(f)
        self.components.fldTextArea._delegate.SetFont(f)

    def changeSize(self, size):
        self.fontPointSize = eval(size)
        f = self.newFont()
        self.components.fldTextField._delegate.SetFont(f)
        self.components.fldTextArea._delegate.SetFont(f)

    def toggleUnderline(self, underline):
        self.fontUnderline = underline
        f = self.newFont()
        self.components.fldTextField._delegate.SetFont(f)
        self.components.fldTextArea._delegate.SetFont(f)


    def on_listFaceNames_select(self, target, event):
        self.changeFaceName(target.getStringSelection())
        self.listFontDetails()

    def on_listFontFamilies_select(self, target, event):
        self.changeFamily(target.getStringSelection())
        self.listFontDetails()

    def on_listFontStyles_select(self, target, event):
        self.changeStyle(target.getStringSelection())
        self.listFontDetails()

    def on_listFontWeight_select(self, target, event):
        self.changeWeight(target.getStringSelection())
        self.listFontDetails()

    def on_listFontSize_select(self, target, event):
        self.changeSize(target.getStringSelection())
        self.listFontDetails()

    def on_chkUnderline_mouseClick(self, target, event):
        self.toggleUnderline(target.checked)
        self.listFontDetails()


    def on_btnFont_mouseClick(self, target, event):
        dlg = PythonCardPrototype.dialog.FontDialog(self, self.components.fldTextField.font)
        if dlg.accepted():
            self.components.fldTextField.font = dlg.getFont()

    
    def on_menuFileExit_select(self, menu, event):
        self.Close()


if __name__ == '__main__':
    base, ext = os.path.splitext(sys.argv[0])
    filename = base + ".rsrc.py"

    configOptions()

    app = PythonCardPrototype.model.PythonCardApp(filename)
    app.MainLoop()
