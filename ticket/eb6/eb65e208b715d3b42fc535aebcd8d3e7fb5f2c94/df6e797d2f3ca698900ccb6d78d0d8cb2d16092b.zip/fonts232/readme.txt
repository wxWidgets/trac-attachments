Program to test wxPython fonts

Created: 2001-08-25
Modified: 2001-11-14

Clicking on the various font attributes in the list will change the displayed
font of the two fields. The font info from the field is shown at the top
right.

Requires PythonCardPrototype 0.5 or higher, wxPython 2.3.x, Python 2.x
Pythoncard can be downloaded at http://sourceforge.net/projects/pythoncard/

The code is a mixture PythonCard and wxPython since it was written prior
to the addition of the Font class in PythonCard, so the delegate wxPython
controls are referenced directly along with the wxPython font info.

Kevin Altis
altis@semi-retired.com