{'stack':{'type':'Stack',
          'name':'Fonts',
          'title':'PythonCard Font Tests',
          'position':(5, 5),
          'size':(400, 550),

    'menubar': {'type':'MenuBar',
         'menus': [
            {'type':'Menu',
              'name':'menuFile',
              'label':'File',
              'items': [
                  {'type':'MenuItem',
                   'name':'menuFileExit',
                   'label':'E&xit\tAlt-X',
                  },
               ]
             },
         ]
     },
    'backgrounds': [
    {'type':'Background',
         'file':'fonts.py',
         'classname':'FontTests',
         'name':'bgFontTests',
         'components': [

{'type':'StaticText', 
    'name':'fldFontDetails', 
    'position':(179, 70), 
    'size':(150, 150), 
    },

{'type':'TextField', 
    'name':'fldTextField', 
    'position':(174, 278), 
    'size':(212, 45), 
    'text':'Hello PythonCard', 
    },

{'type':'TextArea', 
    'name':'fldTextArea', 
    'position':(174, 332), 
    'size':(214, 99), 
    'text':'The quick brown fox jumped over the lazy dog.', 
    },

{'type':'List', 
    'name':'listFaceNames', 
    'position':(0, 96), 
    'size':(169, 175), 
    'items':[], 
    },

{'type':'List', 
    'name':'listFontFamilies', 
    'position':(0, 4), 
    'size':(169, 90), 
    'items':['wxDEFAULT', 'wxDECORATIVE', 'wxROMAN', 'wxSCRIPT', 'wxSWISS', 'wxMODERN'], 
    'selected':'wxDEFAULT', 
    },

{'type':'List', 
    'name':'listFontStyles', 
    'position':(0, 278), 
    'size':(171, 46), 
    'items':['wxNORMAL', 'wxITALIC', 'wxSLANT'], 
    'selected':'wxNORMAL', 
    },

{'type':'List', 
    'name':'listFontWeight', 
    'position':(0, 330), 
    'size':(171, 46), 
    'items':['wxNORMAL', 'wxLIGHT', 'wxBOLD'], 
    'selected':'wxNORMAL', 
    },

{'type':'List', 
    'name':'listFontSize', 
    'position':(0, 380), 
    'size':(171, 86), 
    'items':['8', '9', '10', '11', '12', '14', '18', '24'], 
    'selected':'8', 
    },

{'type':'StaticLine', 
    'name':'stcMenuUnderline', 
    'position':(0, 0), 
    'size':(400, -1), 
    'backgroundColor':(255, 255, 255), 
    'layout':'horizontal', 
    },

{'type':'CheckBox', 
    'name':'chkUnderline', 
    'position':(0, 472), 
    'size':(73, 19), 
    'label':'underline', 
    },

#{'type':'Button', 
#    'name':'btnFont', 
#    'position':(178, 248), 
#    'label':'Font Dialog', 
#    },

] # end components
} # end background
] # end backgrounds
} }
