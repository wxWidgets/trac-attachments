#include "mainwin.h"

BEGIN_EVENT_TABLE(MainWin, wxFrame)

EVT_AUI_PANE_CLOSE(MainWin::OnAUIPaneClose)

END_EVENT_TABLE()

MainWin::MainWin(): wxFrame(NULL, ID_MAIN_FRAME, wxSTR("Main window"), wxDefaultPosition, wxSize(800, 600), wxCAPTION | wxCLOSE_BOX | wxMAXIMIZE_BOX | wxMINIMIZE_BOX | wxRESIZE_BORDER | wxSYSTEM_MENU | wxTAB_TRAVERSAL, wxFrameNameStr) {
   SetMinSize(wxSize(640, 480));
   m_Mgr.SetManagedWindow(this);
   m_Mgr.SetFlags(wxAUI_MGR_ALLOW_FLOATING | wxAUI_MGR_TRANSPARENT_HINT);

   m_pG = new Grid(this);
   m_Mgr.AddPane(m_pG, wxAuiPaneInfo().Caption(wxSTR("Grid")).PinButton(true).Row(1).Position(0).Layer(0).Left());

   m_Mgr.Update();
   Centre(wxBOTH);
}

MainWin::~MainWin() {
   m_Mgr.UnInit();
}

void MainWin::OnAUIPaneClose(wxAuiManagerEvent& event) {
   event.Skip();
}
