#ifndef __COMMON_H__
#define __COMMON_H__

#include <wx/wx.h>
#include <wx/aui/aui.h>
#include <wx/generic/statbmpg.h>
#include <wx/valnum.h>
#include <wx/propgrid/propgrid.h>
#include <wx/arrimpl.cpp>

#define wxSTR(s) wxString(wxT(s))

#endif
