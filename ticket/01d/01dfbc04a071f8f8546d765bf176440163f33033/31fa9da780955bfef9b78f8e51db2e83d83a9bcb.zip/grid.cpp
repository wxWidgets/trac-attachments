#include "grid.h"

BEGIN_EVENT_TABLE(Grid, wxPropertyGrid)

EVT_PG_CHANGED(ID_MF_PROPERTYGRID, Grid::OnPropertyGridChanged)

END_EVENT_TABLE()

Grid::Grid(wxWindow* parent): wxPropertyGrid(parent, ID_MF_PROPERTYGRID, wxDefaultPosition, wxDefaultSize, wxPG_SPLITTER_AUTO_CENTER, wxPropertyGridNameStr) {
   wxPGProperty* pProperty;
   wxPGChoices choices;

   SetValidationFailureBehavior(wxPG_VFB_MARK_CELL);

   choices.Add(wxSTR("flag 1"), 1);
   choices.Add(wxSTR("flag 2"), 2);
   choices.Add(wxSTR("flag 3"), 4);
   pProperty = Append(new myFlagsProperty(choices));
   pProperty->SetAttribute(wxPG_BOOL_USE_CHECKBOX, true);
}

Grid::~Grid() {
   Clear();
}

void Grid::OnPropertyGridChanged(wxPropertyGridEvent& event) {
   if(event.GetProperty() == NULL)
      event.Skip();
}
