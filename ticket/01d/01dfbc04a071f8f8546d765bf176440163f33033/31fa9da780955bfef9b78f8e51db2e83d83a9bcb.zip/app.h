#ifndef __APP_H__
#define __APP_H__

#include "common.h"
#include "mainwin.h"

class App: public wxApp {
private:
   virtual bool OnInit() {
      MainWin* pMW;

      pMW = new MainWin();
      pMW->Show(true);
      return true;
   }
   virtual int OnExit() {
      return 0;
   }
};

#endif
