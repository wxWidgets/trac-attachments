#ifndef __MAINWIN_H__
#define __MAINWIN_H__

#include "common.h"
#include "grid.h"

#define ID_MAIN_FRAME 1000

class MainWin: public wxFrame {
public:
   MainWin();
   ~MainWin();

private:
   wxAuiManager m_Mgr;
   Grid* m_pG;

   void OnAUIPaneClose(wxAuiManagerEvent& event);

   DECLARE_EVENT_TABLE()
};

#endif
