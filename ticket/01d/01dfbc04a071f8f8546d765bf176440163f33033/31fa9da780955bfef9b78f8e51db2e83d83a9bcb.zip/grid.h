#ifndef __GRID_H__
#define __GRID_H__

#include "common.h"

#define ID_MF_PROPERTYGRID 1000

class Grid: public wxPropertyGrid {
public:
   Grid(wxWindow* parent);
   ~Grid();

   void OnPropertyGridChanged(wxPropertyGridEvent& event);

   DECLARE_EVENT_TABLE()
};

class myFlagsProperty: public wxFlagsProperty {
public:
   myFlagsProperty(wxPGChoices& choices): wxFlagsProperty(wxSTR("my_flags"), wxPG_LABEL, choices, 0) {}

   virtual bool ValidateValue(wxVariant& value, wxPGValidationInfo& validationInfo) const {
      return false;
   }
};

#endif
