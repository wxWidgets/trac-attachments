/////////////////////////////////////////////////////////////////////////////
// Name:        wx/meta/convertible.h
// Purpose:     Test if types are convertible 
// Author:      Arne Steinarson
// Modified by:
// Created:     10 Jan 08
// RCS-ID:      
// Copyright:   (c) 2007 Arne Steinarson
// Licence:     wxWindows licence
/////////////////////////////////////////////////////////////////////////////

#ifndef _WX_CONVERTIBLE_H_
#define _WX_CONVERTIBLE_H_

// Helper to decide if an object has a base class or not
// (strictly speaking, this test succeeds if a type is convertible
//  to another type in some way.)
template<class T, class B>
struct wxConvertibleTo {
	static char Match( B* pb );	   
	static int Match( ... );       
	enum { value = (sizeof(Match((T*)NULL))==sizeof(char)) };
};

#endif // _WX_CONVERTIBLE_H_

