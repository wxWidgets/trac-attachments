/////////////////////////////////////////////////////////////////////////////
// Name:        wx/meta/defs.h
// Purpose:     Preprocessor defines relating to template programming 
// Author:      Arne Steinarson
// Modified by:
// Created:     10 Jan 08
// RCS-ID:      
// Copyright:   (c) 2007 Arne Steinarson
// Licence:     wxWindows licence
/////////////////////////////////////////////////////////////////////////////

#ifndef _WX_META_H_
#define _WX_META_H_

// VC++ before 7.1 does not have partial template specialization 
#ifdef __VISUALC__
    #if __VISUALC__ < 1310
        #define HAVE_NO_PARTIAL_SPECIALIZATION
    #endif
#endif 

#ifndef HAVE_NO_PARTIAL_SPECIALIZATION
    #define HAVE_PARTIAL_SPECIALIZATION 
#endif


#endif // _WX_META_H_

