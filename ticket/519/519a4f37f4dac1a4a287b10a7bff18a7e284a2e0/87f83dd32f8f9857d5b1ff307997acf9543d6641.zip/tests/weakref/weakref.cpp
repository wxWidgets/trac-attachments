///////////////////////////////////////////////////////////////////////////////
// Name:        tests/weakref/weakref.cpp
// Purpose:     wxWeakRef<T> unit test
// Author:      Arne Steinarson
// Created:     2008-01-10
// RCS-ID:      $Id: weakref.cpp 48299 2007-08-21 15:51:52Z VS $
// Copyright:   (c) 2007 Arne Steinarson
///////////////////////////////////////////////////////////////////////////////

// ----------------------------------------------------------------------------
// headers
// ----------------------------------------------------------------------------

#include "testprec.h"

#ifdef __BORLANDC__
    #pragma hdrstop
#endif

#ifndef WX_PRECOMP
    #include "wx/wx.h"
#endif // WX_PRECOMP


#include "wx/event.h"
#include "wx/weakref.h"


#ifdef __WXDEBUG__
    #define WR_INSTANCE_COUNT_ASSERT(N)   CPPUNIT_ASSERT( wxTrackerNode::tnGetInstanceCounter()==N )
#else
    #define WR_INSTANCE_COUNT_ASSERT(N)   
#endif


// A statically trackable derived wxObject 
class wxObjectTrackable : public wxObject, public wxTrackable {
public:
    // Test member access
    void TestFunc(){ }
    // Make sure this does not clash with wxTrackableBase method 
    int GetFirst(){ return 0; }
};



// --------------------------------------------------------------------------
// test class
// --------------------------------------------------------------------------

class WeakRefTestCase : public CppUnit::TestCase
{
public:
    WeakRefTestCase() {}

private:
    CPPUNIT_TEST_SUITE( WeakRefTestCase );
        CPPUNIT_TEST( DeclareTest );
        CPPUNIT_TEST( AssignTest );
        CPPUNIT_TEST( AssignWeakRefTest );
        CPPUNIT_TEST( MultiAssignTest );
        CPPUNIT_TEST( CleanupTest );
        CPPUNIT_TEST( DeleteTest );
#ifdef HAVE_DYNAMIC_CAST
        CPPUNIT_TEST( DynamicRefTest );
#endif        
    CPPUNIT_TEST_SUITE_END();

    void DeclareTest();
    void AssignTest();
    void AssignWeakRefTest();
    void MultiAssignTest();
    void CleanupTest();
    void DeleteTest();
#ifdef HAVE_DYNAMIC_CAST
    void DynamicRefTest();
#endif        

    DECLARE_NO_COPY_CLASS(WeakRefTestCase)
};

// register in the unnamed registry so that these tests are run by default
CPPUNIT_TEST_SUITE_REGISTRATION( WeakRefTestCase );

// also include in it's own registry so that these tests can be run alone
CPPUNIT_TEST_SUITE_NAMED_REGISTRATION( WeakRefTestCase, "WeakRefTestCase" );

void WeakRefTestCase::DeclareTest()
{
    {
        wxObject o; // Should not work
        wxEvtHandler eh;
        wxObjectTrackable ot;

        // Test declare when T is wxObject 
        // wxWeakRef<wxObject> wro(&o);    // Gives compile time failure
        wxWeakRef<wxObject> wro1;
        wxWeakRef<wxObject> wro2(&eh);
        wxWeakRef<wxObject> wro3(&ot);
        
        CPPUNIT_ASSERT( wro1.get()==NULL );
        CPPUNIT_ASSERT( wro2.get()==&eh );
        CPPUNIT_ASSERT( wro3.get()==&ot );
        
        // Test accessing wxObject members 
        CPPUNIT_ASSERT( !wro2->GetRefData() );
        CPPUNIT_ASSERT( !wro3->GetRefData() );
        
        
        wxWeakRef<wxEvtHandler> wreh(&eh);
        wxWeakRef<wxObjectTrackable> wrot(&ot);
        
        CPPUNIT_ASSERT( wreh.get()==&eh );
        CPPUNIT_ASSERT( wrot.get()==&ot );
        
        WR_INSTANCE_COUNT_ASSERT( 3+2 );
    }

    // Should be no tracker node instances now
    WR_INSTANCE_COUNT_ASSERT( 0 );
}

void WeakRefTestCase::AssignTest()
{
    // Test declare when T is wxObject 
    wxWeakRef<wxObject> wro1;
    wxWeakRef<wxObject> wro2;
    wxWeakRef<wxObject> wro3;
    wxWeakRef<wxObject> wro4;
    
    {   // Scope for object destruction
        wxEvtHandler eh;
        wxObjectTrackable ot;

        wro2 = &eh;
        wro3 = &ot;
        
        CPPUNIT_ASSERT( wro1.get()==NULL );
        CPPUNIT_ASSERT( wro2.get()==&eh );
        CPPUNIT_ASSERT( wro3.get()==&ot );
    }
    
    // Should be reset now
    CPPUNIT_ASSERT( !wro1.get() );
    CPPUNIT_ASSERT( !wro2.get() );
    CPPUNIT_ASSERT( !wro3.get() );
    CPPUNIT_ASSERT( !wro4.get() );
    
    WR_INSTANCE_COUNT_ASSERT( 4 );
}

void WeakRefTestCase::AssignWeakRefTest()
{
    // Test declare when T is wxObject 
    wxWeakRef<wxObject> wro1;
    wxWeakRef<wxObject> wro2;
    
    {   // Scope for object destruction
        wxEvtHandler eh;
        wxObjectTrackable ot;
        wxWeakRef<wxObject> wro3;
        wxWeakRef<wxObject> wro4;
        
        wro1 = &eh;
        wro2 = &ot;
        wro3 = wro1;
        wro4 = wro2;

        CPPUNIT_ASSERT( wro1.get()==&eh );
        CPPUNIT_ASSERT( wro2.get()==&ot );
        CPPUNIT_ASSERT( wro3.get()==&eh );
        CPPUNIT_ASSERT( wro4.get()==&ot );
        
        wro4.Release();
        CPPUNIT_ASSERT( !wro4.get() );
        
        WR_INSTANCE_COUNT_ASSERT( 4 );
    }
    
    // Should be reset now
    CPPUNIT_ASSERT( !wro1.get() );
    CPPUNIT_ASSERT( !wro2.get() );
    
    WR_INSTANCE_COUNT_ASSERT( 2 );
}

void WeakRefTestCase::MultiAssignTest()
{
    // Object is tracked by several refs
    wxEvtHandler *peh = new wxEvtHandler;
    
    // Test declare when T is wxObject 
    wxWeakRef<wxObject> wro1(peh);
    wxWeakRef<wxObject> wro2(peh);
    wxWeakRef<wxObject> wro3;
    wxWeakRef<wxObject> wro4;
    
    wxObjectTrackable *pot = new wxObjectTrackable;
    wro3 = pot; 
    wro4 = pot;
    
    CPPUNIT_ASSERT( wro1.get()==peh );
    CPPUNIT_ASSERT( wro2.get()==peh );
    CPPUNIT_ASSERT( wro3.get()==pot );
    CPPUNIT_ASSERT( wro4.get()==pot );
    
    delete peh; peh=NULL;
    delete pot; pot=NULL;
    
    // Should be reset now
    CPPUNIT_ASSERT( !wro1.get() );
    CPPUNIT_ASSERT( !wro2.get() );
    CPPUNIT_ASSERT( !wro3.get() );
    CPPUNIT_ASSERT( !wro4.get() );
}

void WeakRefTestCase::CleanupTest()
{
    // Make sure that trackable objects have no left over tracker nodes after use.
    // This time the references goes out of scope before the objects.
    wxEvtHandler eh;
    wxObjectTrackable ots;
    wxObjectTrackable otd;
    
    {   // Scope for object destruction
        wxWeakRef<wxObject> wro1;
        wxWeakRef<wxObject> wro2;
        wxWeakRef<wxObjectTrackable> wro3;
        wxWeakRef<wxObjectTrackable> wro4;

        wro1 = &eh;
        wro2 = &eh; // Has two tracker nodes now
        wro3 = &ots;
        wro4 = &otd;

        // Access members of reffed object 
        wro3->TestFunc();
        
        CPPUNIT_ASSERT( eh.GetFirst()==&wro2 );
        CPPUNIT_ASSERT( ots.wxTrackable::GetFirst()==&wro3 );
        CPPUNIT_ASSERT( otd.wxTrackable::GetFirst()==&wro4 );
    }
    
    // Should be reset now
    CPPUNIT_ASSERT( !eh.GetFirst() );
    CPPUNIT_ASSERT( !ots.wxTrackable::GetFirst() );
    CPPUNIT_ASSERT( !otd.wxTrackable::GetFirst() );
}

void WeakRefTestCase::DeleteTest()
{
    // Object is tracked by several refs
    wxEvtHandler *peh = new wxEvtHandler;
    
    // Declared derived type of object and test deleting it
    wxEvtHandlerRef wre(peh);
    wxWeakRef<wxObject> wro(peh);
    
    // Also test size of references (see that it has selected right base class)
#ifdef HAVE_PARTIAL_SPECIALIZATION
    CPPUNIT_ASSERT( sizeof(wre)==sizeof(void*)*3 );
    CPPUNIT_ASSERT( sizeof(wro)==sizeof(void*)*4 );
#else
    CPPUNIT_ASSERT( sizeof(wre)==sizeof(void*)*4 );
    CPPUNIT_ASSERT( sizeof(wro)==sizeof(void*)*4 );
#endif     
    
    CPPUNIT_ASSERT( wre.get()==peh );
    CPPUNIT_ASSERT( wro.get()==peh );
    
    delete wre.get();
    CPPUNIT_ASSERT( wre.get()==NULL );
    CPPUNIT_ASSERT( wro.get()==NULL );
    
    // And again (this time does nothing)
    delete wre.get();
}

#ifdef HAVE_DYNAMIC_CAST
void WeakRefTestCase::DynamicRefTest()
{
    // Test declare when T is wxObject 
    wxWeakRefDynamic<wxObject> wro1;
    wxWeakRefDynamic<wxObject> wro2;
    wxWeakRefDynamic<wxObject> wro3;
    
    {   // Scope for object destruction
        wxEvtHandler eh;
        wxObjectTrackable otd1;
        wxObjectTrackable otd2;
        wro1 = &eh;
        wro2 = &otd1;
        wro3 = &otd2;
        
        CPPUNIT_ASSERT( wro1.get()==NULL );
        CPPUNIT_ASSERT( wro2.get()==&otd1 );
        CPPUNIT_ASSERT( wro3.get()==&otd2 );
        
        WR_INSTANCE_COUNT_ASSERT( 3 );
        
        wro3 = wro2;
        CPPUNIT_ASSERT( wro2.get()==&otd1 );
        CPPUNIT_ASSERT( wro3.get()==&otd1 );
    }
    
    // Should be reset now
    CPPUNIT_ASSERT( !wro2.get() );
    CPPUNIT_ASSERT( !wro3.get() );
    
    WR_INSTANCE_COUNT_ASSERT( 3 );
}
#endif // HAVE_DYNAMIC_CAST 
