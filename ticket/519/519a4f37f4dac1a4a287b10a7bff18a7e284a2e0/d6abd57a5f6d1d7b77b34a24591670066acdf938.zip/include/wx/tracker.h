/////////////////////////////////////////////////////////////////////////////
// Name:        wx/tracker.h
// Purpose:     Support class for object lifetime tracking (wxWeakRef<T>) 
// Author:      Arne Steinarson
// Modified by:
// Created:     28 Dec 07
// RCS-ID:      
// Copyright:   (c) 2007 Arne Steinarson
// Licence:     wxWindows licence
/////////////////////////////////////////////////////////////////////////////

#ifndef _WX_TRACKER_H_
#define _WX_TRACKER_H_

// Forward declaration, to help differentiate wxEventConnectionRef
// from wxWeakRef at run-time.
struct wxEventConnectionRef;

#ifdef __WXDEBUG__
  // For debugging / performance check
  #define WXTN_INIT tnGetInstanceCounter()++;
  #define WXTN_EXIT tnGetInstanceCounter()--;
#else
  // Default case: do nothing
  #define WXTN_INIT
  #define WXTN_EXIT
#endif // __WXDEBUG__


// This structure represents an object tracker and is stored in a linked list
// in the tracked object. It is only used in one of its derived forms.
struct WXDLLIMPEXP_BASE wxTrackerNode {
    wxTrackerNode( ) : m_nxt(0) { WXTN_INIT }
    virtual ~wxTrackerNode() { WXTN_EXIT }
    
    virtual void OnObjectDestroy( ) = 0;
    
    virtual wxEventConnectionRef* ToEventConnection( ){ return NULL; }
    
#ifdef __WXDEBUG__
    // For debugging purposes, maintain a counter of number of tracker nodes
    static int& tnGetInstanceCounter();
#endif    

protected:
    wxTrackerNode *m_nxt;
    friend class wxTrackableBase;    // For list access
    friend class wxEvtHandler;       // For list access
};


// Add-on base class for a trackable object.
struct wxTrackableBase {
    wxTrackableBase() : m_first(0) { }
    ~wxTrackableBase()
    { 
        // Notify all registered refs
        
        wxTrackerNode *first;
        while( m_first )
        {
        	first = m_first;
            first->OnObjectDestroy( );
            RemoveNode(first);
        }
    }
    
    void AddNode( wxTrackerNode *prn )
    {
        prn->m_nxt = m_first;
        m_first = prn;
    }
    
    void RemoveNode( wxTrackerNode *prn )
    {
        for( wxTrackerNode **pprn=&m_first; *pprn; pprn=&(*pprn)->m_nxt )
        {
            if( *pprn==prn )
            {
                *pprn = prn->m_nxt;
                return;
            }
        }
        // Not found, an error.
        wxASSERT( false );
    }
    
    wxTrackerNode* GetFirst( ){ return m_first; }
    
#ifdef __WXDEBUG__    
    int tbGetCount() { 
        int cnt = 0;
        wxTrackerNode *ptn = GetFirst();
        while( ptn ) {
            cnt++;
            ptn = ptn->m_nxt;
        }
        return cnt;
    }
#endif

    // If trying to copy this object, then do not copy its ref list.
    wxTrackableBase& operator = (const wxTrackableBase& other) { return *this; }
    
protected:    
    wxTrackerNode *m_first;
};


// The difference to wxTrackableBase is that this class adds 
// a VTable to enable dynamic_cast query for wxTrackable.
struct wxTrackable : public wxTrackableBase 
{
    virtual ~wxTrackable(){ }
};


#endif // _WX_TRACKER_H_

