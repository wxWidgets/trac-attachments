
/////////////////////////////////////////////////////////////////////////////
// Name:        wx/meta/int2type.h
// Purpose:     Generate a unique type from a constant integer 
// Author:      Arne Steinarson
// Modified by:
// Created:     10 Jan 08
// RCS-ID:      
// Copyright:   (c) 2007 Arne Steinarson
// Licence:     wxWindows licence
/////////////////////////////////////////////////////////////////////////////

#ifndef _WX_INT2TYPE_H_
#define _WX_INT2TYPE_H_

template<int N>
struct wxInt2Type { enum { value=N }; };

#endif // _WX_INT2TYPE_H_
