/////////////////////////////////////////////////////////////////////////////
// Name:        wx/weakref.h
// Purpose:     wxWeakRef - Generic weak references for wxWidgets
// Author:      Arne Steinarson
// Modified by:
// Created:     27 Dec 07
// RCS-ID:      
// Copyright:   (c) 2007 Arne Steinarson
// Licence:     wxWindows licence
/////////////////////////////////////////////////////////////////////////////

#ifndef _WX_WEAKREF_H_
#define _WX_WEAKREF_H_

#include <wx/tracker.h>
#include <wx/log.h>
#include <wx/defs.h>

#include <wx/meta/defs.h> 
#include <wx/meta/convertible.h> 
#include <wx/meta/int2type.h> 


template<class T> 
struct IsStaticTrackable { 
    enum { value=wxConvertibleTo<T,wxTrackableBase>::value };
};


// Weak ref implementation when T has wxTrackableBase as a known base class
template<class T>
struct wxWeakRefStatic : public wxTrackerNode { 
    wxWeakRefStatic() : m_pobj(0) { } 
    
    void Release( ) 
    { 
        // Release old object if any 
        if( m_pobj )
        {
            // Remove ourselves from object tracker list
            wxTrackableBase *pt = static_cast<wxTrackableBase*>(m_pobj);
            pt->RemoveNode(this);
            m_pobj = NULL;
        }
    }
    
protected:

    void Assign( T* pobj ) {
        if( m_pobj==pobj ) return;
        Release( );
        
        // Now set new trackable object
        if( pobj )
        {
            // Add ourselves to object tracker list
            wxTrackableBase *pt = static_cast<wxTrackableBase*>(pobj);
            pt->AddNode( this );
            m_pobj = pobj;
        }
    }
    
    void AssignCopy( const wxWeakRefStatic& wr ){
        Assign( wr.m_pobj );
    }
    
    virtual void OnObjectDestroy( ) 
    {
        // Tracked object itself removes us from list of trackers
        wxASSERT( m_pobj!=NULL );
        m_pobj = NULL;
    }
    
    T *m_pobj;
};


#ifdef HAVE_PARTIAL_SPECIALIZATION 

template<class T,bool use_static>
struct wxWeakRefImpl;

// Intermediate class, to select the static case above.
template<class T>
struct wxWeakRefImpl<T,true> : public wxWeakRefStatic<T> { 
    enum { value=1 };
};

// Weak ref implementation when T does not have wxTrackableBase as known base class
template<class T>
struct wxWeakRefImpl<T,false> : public wxTrackerNode { 
    void Release( ) 
    { 
        // Release old object if any 
        if( m_pobj )
        {
            wxASSERT( m_ptbase );
            // Remove ourselves from object tracker list
            m_ptbase->RemoveNode(this);
            m_pobj = NULL;
            m_ptbase = NULL;
        }
    }
    
protected:
    wxWeakRefImpl() : m_pobj(0), m_ptbase(0) { } 
    
    // Assign receives most derived class here and can use that 
    template<class TDerived>
    void Assign( TDerived* pobj ) {
        AssignHelper( pobj, wxInt2Type<IsStaticTrackable<TDerived>::value>() );
    }

    template<class TDerived>
    void AssignHelper( TDerived* pobj, wxInt2Type<true> dummy ) {
        wxTrackableBase *ptbase = static_cast<wxTrackableBase*>(pobj);
        DoAssign( pobj, ptbase );
    }
    
#ifdef HAVE_DYNAMIC_CAST    
    void AssignHelper( T* pobj, wxInt2Type<false> dummy ) {
        // A last way to get a trackable pointer
        wxTrackableBase *ptbase = dynamic_cast<wxTrackableBase*>(pobj);
        if( ptbase )
            DoAssign( pobj, ptbase );
        else 
        {
            // If the object we want to track does not support wxTackable, then 
            // log a message and keep the NULL object pointer. 
            wxLogWarning( _T("wxWeakRefDynamic::Assign - Type does not provide wxTrackableBase - resetting tracked object") );
            Release( );
        }
    }
#endif    
    
    void AssignCopy( const wxWeakRefImpl& wr ){
        DoAssign( wr.m_pobj, wr.m_ptbase );
    }
    
    void DoAssign( T* pobj, wxTrackableBase *ptbase ) {
        if( m_pobj==pobj ) return;
        Release( );
        
        // Now set new trackable object
        if( pobj )
        {
            // Add ourselves to object tracker list
            wxASSERT( ptbase );
            ptbase->AddNode( this );
            m_pobj = pobj;
            m_ptbase = ptbase;
        }
    }
    
    virtual void OnObjectDestroy( ) 
    {
        // Tracked object itself removes us from list of trackers
        wxASSERT( m_pobj!=NULL );
        m_pobj = NULL;
        m_ptbase = NULL;
    }
    
    T *m_pobj;
    wxTrackableBase *m_ptbase;
}; 

// We have template specialization, so we can do this
#define wxWEAKREFIMPL wxWeakRefImpl<T,IsStaticTrackable<T>::value> 

#else

// Have no partial specialization, go for the simple case
#define wxWEAKREFIMPL wxWeakRefStatic<T>  

#endif // HAVE_PARTIAL_SPECIALIZATION


// A weak reference to an object of type T, where T has type wxTrackable 
// (usually statically but if not dynamic_cast<> is tried).
template<class T>
struct wxWeakRef : public wxWEAKREFIMPL { 

    // Default ctor
    wxWeakRef() { } 
    
    // When we have the full type here, static_cast<> will always work 
    // (or give a straight compiler error).
    template<class TDerived> 
    wxWeakRef( TDerived* pobj ) 
    { 
        this->Assign( pobj );
    }
   
    virtual ~wxWeakRef( ) { this->Release(); }
    
    // Smart pointer functions 
    T& operator * (){ wxASSERT(this->m_pobj); return *(this->m_pobj); }
    T* operator -> (){ wxASSERT(this->m_pobj); return this->m_pobj; }
    
    template<class TDerived> 
    T* operator = (TDerived* pobj)
    { 
        this->Assign(pobj); 
        return this->m_pobj; 
    }
    
    T* get(){ return this->m_pobj; }
    
    // operator T* (){ return this->m_pobj; }
    
    // test for pointer validity: defining conversion to unspecified_bool_type
    // and not more obvious bool to avoid implicit conversions to integer types
    typedef T *(wxWeakRef<T>::*unspecified_bool_type)() const;
    operator unspecified_bool_type() const
    {
        return this->m_pobj ? &wxWeakRef<T>::get : NULL;
    }    
    
    // Assign from another weak ref, point to same object
    T* operator = (const wxWeakRef<T> &wr)
    { 
        this->AssignCopy( wr ); 
        return this->m_pobj; 
    }
}; 
 

// Weak ref implementation assign objects are queried for wxTrackable 
// using dynamic_cast<>
template<class T>
struct wxWeakRefDynamic : public wxTrackerNode { 
    wxWeakRefDynamic() : m_pobj(0) { } 
    
    wxWeakRefDynamic( T* pobj ) : m_pobj(pobj) 
    { 
        Assign( pobj );
    }
    
    virtual ~wxWeakRefDynamic( ) { Release(); }
    
    // Smart pointer functions 
    T& operator * (){ wxASSERT(this->m_pobj); return *m_pobj; }
    T* operator -> (){ wxASSERT(this->m_pobj); return m_pobj; }
    T* operator = (T* pobj) { Assign(pobj); return m_pobj; }
    
    T* get(){ return this->m_pobj; }
    
    // operator T* (){ return this->m_pobj; }
    
    // test for pointer validity: defining conversion to unspecified_bool_type
    // and not more obvious bool to avoid implicit conversions to integer types
    typedef T *(wxWeakRef<T>::*unspecified_bool_type)() const;
    operator unspecified_bool_type() const
    {
        return m_pobj ? &wxWeakRef<T>::get : NULL;
    }    
    
    // Assign from another weak ref, point to same object
    T* operator = (const wxWeakRef<T> &wr) { Assign( wr.get() ); return this->m_pobj; }
    
    void Release( ) 
    { 
        // Release old object if any 
        if( m_pobj )
        {
            // Remove ourselves from object tracker list
            wxTrackableBase *pt = dynamic_cast<wxTrackableBase*>(m_pobj);
            wxASSERT(pt);
            pt->RemoveNode(this);
            m_pobj = NULL;
        }
    }
    
protected:

    void Assign( T* pobj ) {
        if( m_pobj==pobj ) return;
        Release( );
        
        // Now set new trackable object
        if( pobj )
        {
            // Add ourselves to object tracker list
            wxTrackableBase *pt = dynamic_cast<wxTrackableBase*>(pobj);
            if( pt )
            {
                pt->AddNode( this );
                m_pobj = pobj;
            }
            else
            {
                // If the object we want to track does not support wxTackable, then 
                // log a message and keep the NULL object pointer. 
                wxLogWarning( _T("wxWeakRefDynamic::Assign - Type does not provide wxTrackableBase - resetting tracked object") );
            }
        }
    }
    
    void AssignCopy( const wxWeakRefDynamic& wr ){
        Assign( wr.m_pobj );
    }
    
    virtual void OnObjectDestroy( ) 
    {
        // Tracked object itself removes us from list of trackers
        wxASSERT( m_pobj!=NULL );
        m_pobj = NULL;
    }
    
    T *m_pobj;
};

  

// Provide some basic types of weak references
class WXDLLIMPEXP_FWD_BASE wxEvtHandler;
class WXDLLIMPEXP_FWD_BASE wxWindow;

typedef wxWeakRef<wxEvtHandler>  wxEvtHandlerRef;
typedef wxWeakRef<wxWindow>      wxWindowRef;

#endif // _WX_WEAKREF_H_

