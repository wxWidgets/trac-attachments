///////////////////////////////////////////////////////////////////////////////
// Name:        tests/weakref/evtconnection.cpp
// Purpose:     wxWeakRef<T> unit test
// Author:      Arne Steinarson
// Created:     2008-01-10
// RCS-ID:      $Id: evtconnection.cpp 48299 2007-08-21 15:51:52Z VS $
// Copyright:   (c) 2007 Arne Steinarson
///////////////////////////////////////////////////////////////////////////////

// ----------------------------------------------------------------------------
// headers
// ----------------------------------------------------------------------------

#include "testprec.h"

#ifdef __BORLANDC__
    #pragma hdrstop
#endif

#ifndef WX_PRECOMP
    #include "wx/wx.h"
#endif // WX_PRECOMP


#include "wx/event.h"
#include "wx/weakref.h"

#ifdef __WXDEBUG__
    #define TB_CHECK_COUNT_ASSERT(OBJ,N)   CPPUNIT_ASSERT( OBJ.tbGetCount()==N )
#else
    #define TB_CHECK_COUNT_ASSERT(OBJ,N)   
#endif

#ifdef __WXDEBUG__
    #define EC_INSTANCE_COUNT_ASSERT(N)   CPPUNIT_ASSERT( wxTrackerNode::tnGetInstanceCounter()==N )
#else
    #define EC_INSTANCE_COUNT_ASSERT(N)   
#endif



// A statically trackable derived wxObject 

int g_value; // Increased by 1 by first object and 0x10000 by 2nd object

wxObject *g_psrc1;
wxObject *g_psrc2;

// We need some event types
DECLARE_LOCAL_EVENT_TYPE(wxEVT_TEST,0x3000)
DEFINE_LOCAL_EVENT_TYPE(wxEVT_TEST)

DECLARE_LOCAL_EVENT_TYPE(wxEVT_TEST1,0x3001)
DEFINE_LOCAL_EVENT_TYPE(wxEVT_TEST1)

DECLARE_LOCAL_EVENT_TYPE(wxEVT_TEST2,0x3002)
DEFINE_LOCAL_EVENT_TYPE(wxEVT_TEST2)

class wxTestEvent : public wxEvent {
public:
    wxTestEvent( ) : wxEvent(0,wxEVT_TEST) { }
    wxTestEvent( wxEventType type ) : wxEvent(0,type) { }
    virtual wxEvent* Clone() const { return NULL; } 
};


class wxTestSink : public wxEvtHandler {
public:
    void OnTestEvent( wxEvent& evt ) {
        if( evt.GetEventObject()==g_psrc1 )
            g_value += 1;
        else if( evt.GetEventObject()==g_psrc2 )
            g_value += 0x10000;
        /*else
            wxASSERT(0);*/
    }
    void OnTestEvent1( wxEvent& evt ) {
        g_value += 0x00100;
    }
    void OnTestEvent2( wxEvent& evt ) {
        g_value += 0x01000000;
    }
};



// --------------------------------------------------------------------------
// test class
// --------------------------------------------------------------------------

class EvtConnectionTestCase : public CppUnit::TestCase
{
public:
    EvtConnectionTestCase() {}

private:
    CPPUNIT_TEST_SUITE( EvtConnectionTestCase );
        CPPUNIT_TEST( SinkTest );
        CPPUNIT_TEST( SourceDestroyTest );
        CPPUNIT_TEST( MultiConnectionTest );
    CPPUNIT_TEST_SUITE_END();

    void SinkTest();
    void SourceDestroyTest();
    void MultiConnectionTest();
 
    DECLARE_NO_COPY_CLASS(EvtConnectionTestCase)
};

// register in the unnamed registry so that these tests are run by default
CPPUNIT_TEST_SUITE_REGISTRATION( EvtConnectionTestCase );

// also include in it's own registry so that these tests can be run alone
CPPUNIT_TEST_SUITE_NAMED_REGISTRATION( EvtConnectionTestCase, "EvtConnectionTestCase" );


// Helpers
void DoConnect( wxEvtHandler& eh1, wxEvtHandler& eh2, wxTestSink& ts ){
    eh1.Connect(wxEVT_TEST, (wxObjectEventFunction)&wxTestSink::OnTestEvent, 
                NULL, &ts);
    eh2.Connect(wxEVT_TEST, (wxObjectEventFunction) &wxTestSink::OnTestEvent, 
                NULL, &ts);
}

void DoDisconnect( wxEvtHandler& eh1, wxEvtHandler& eh2, wxTestSink& ts ){
    eh1.Disconnect(wxEVT_TEST, (wxObjectEventFunction) &wxTestSink::OnTestEvent, 
                NULL, &ts);
    eh2.Disconnect(wxEVT_TEST, (wxObjectEventFunction) &wxTestSink::OnTestEvent, 
                NULL, &ts);
}


void EvtConnectionTestCase::SinkTest()
{
    // Let the sink be destroyed before the sources

	// tnGetInstanceCounter does not work when mixing library and 
	// inlined function calls
    //CPPUNIT_ASSERT( wxTrackerNode::tnGetInstanceCounter()==0 );
    
    // An event used below
    wxTestEvent evt;
    
    // Connect two event handlers to one sink 
    wxEvtHandler eh1, eh2;
    g_psrc1 = &eh1;
    g_psrc2 = &eh2;
    
    {
        wxTestSink ts; 
        CPPUNIT_ASSERT( !ts.GetFirst() );
        DoConnect( eh1, eh2, ts );
        // Should have two trackers in the list now 
        TB_CHECK_COUNT_ASSERT(ts,2);
        
        DoDisconnect( eh1, eh2, ts );
        // Back to zero trackers now 
        TB_CHECK_COUNT_ASSERT(ts,0);
        
        DoConnect( eh1, eh2, ts );
        // And two again
        TB_CHECK_COUNT_ASSERT(ts,2);
        
        // Fire an event 
        evt.SetEventObject(&eh1);
        eh1.ProcessEvent( evt );
        evt.SetEventObject(&eh2);
        eh2.ProcessEvent( evt );
        // Make sure they were processed correctly
        CPPUNIT_ASSERT( g_value==0x00010001 );
    }

    // Fire events again, should be no sink connected now
    g_value = 0;
    evt.SetEventObject(&eh1);
    eh1.ProcessEvent( evt );
    evt.SetEventObject(&eh2);
    eh2.ProcessEvent( evt );
    // Make sure no processing happened 
    CPPUNIT_ASSERT( g_value==0 );
}

void EvtConnectionTestCase::SourceDestroyTest()
{
    // Let the sources be destroyed before the sink 
    wxTestSink ts; 
    wxTestEvent evt;
    {
        wxEvtHandler eh1;
        { 
            CPPUNIT_ASSERT( !ts.GetFirst() );
            
            // Connect two event handlers to one sink 
            wxEvtHandler eh2;
            g_psrc1 = &eh1;
            g_psrc2 = &eh2;
            DoConnect( eh1, eh2, ts );
            // Should have two trackers in the list now 
            TB_CHECK_COUNT_ASSERT(ts,2);
            
            // Fire events
            g_value = 0;
            evt.SetEventObject(&eh1);
            eh1.ProcessEvent( evt );
            evt.SetEventObject(&eh2);
            eh2.ProcessEvent( evt );
            // Make sure they were processed correctly
            CPPUNIT_ASSERT( g_value==0x00010001 );
        }
        // One source destroyed 
        TB_CHECK_COUNT_ASSERT(ts,1);
        
        g_value = 0;
        evt.SetEventObject(&eh1);
        eh1.ProcessEvent( evt );
        // Make sure still connected
        CPPUNIT_ASSERT( g_value==0x00000001 );
    }
    // And the second one destroyed 
    TB_CHECK_COUNT_ASSERT(ts,0);
    CPPUNIT_ASSERT( !ts.GetFirst() );
}

void EvtConnectionTestCase::MultiConnectionTest()
{
    EC_INSTANCE_COUNT_ASSERT(0);
        
    // events used below
    wxTestEvent evt;
    wxTestEvent evt1(wxEVT_TEST1);
    wxTestEvent evt2(wxEVT_TEST2);
    
    // One source 
    wxEvtHandler eh1;
    evt.SetEventObject(&eh1);
    g_psrc1 = NULL;
    g_psrc2 = &eh1;
    
    {
        // ...and one sink 
        wxTestSink ts; 
        
        TB_CHECK_COUNT_ASSERT(ts,0);
        
        eh1.Connect(wxEVT_TEST, (wxObjectEventFunction)&wxTestSink::OnTestEvent, 
                    NULL, &ts);
        eh1.Connect(wxEVT_TEST1, (wxObjectEventFunction)&wxTestSink::OnTestEvent1, 
                    NULL, &ts);
        eh1.Connect(wxEVT_TEST2, (wxObjectEventFunction)&wxTestSink::OnTestEvent2, 
                    NULL, &ts);
        
        // Three connections but should only be one rwxEventConnectionRef
        TB_CHECK_COUNT_ASSERT(ts,1);
        EC_INSTANCE_COUNT_ASSERT(1);
        
        // Generate events 
        g_value = 0;
        eh1.ProcessEvent(evt);
        eh1.ProcessEvent(evt1);
        eh1.ProcessEvent(evt2);
        CPPUNIT_ASSERT( g_value==0x01010100 );
        
        {
            // Declare weak references to the objects (using same list)
            wxEvtHandlerRef re(&eh1), rs(&ts);
            TB_CHECK_COUNT_ASSERT(ts,2);
            TB_CHECK_COUNT_ASSERT(eh1,1);
            EC_INSTANCE_COUNT_ASSERT(3);
        }
        // And now destroyed
        TB_CHECK_COUNT_ASSERT(ts,1);
        TB_CHECK_COUNT_ASSERT(eh1,0);
        EC_INSTANCE_COUNT_ASSERT(1);
        
        eh1.Disconnect(wxEVT_TEST, (wxObjectEventFunction)&wxTestSink::OnTestEvent, 
                       NULL, &ts);
        TB_CHECK_COUNT_ASSERT(ts,1);
        eh1.ProcessEvent(evt);
        eh1.ProcessEvent(evt1);
        eh1.ProcessEvent(evt2);
        CPPUNIT_ASSERT( g_value==0x02010200 );
    }
    
    // No connection should be left now 
    g_value = 0;
    eh1.ProcessEvent(evt);
    eh1.ProcessEvent(evt1);
    eh1.ProcessEvent(evt2);
    // Nothing should have been done
    CPPUNIT_ASSERT( g_value==0 );
    
    EC_INSTANCE_COUNT_ASSERT(0);
}

