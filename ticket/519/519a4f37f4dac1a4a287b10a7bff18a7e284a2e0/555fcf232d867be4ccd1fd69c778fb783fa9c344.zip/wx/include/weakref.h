/////////////////////////////////////////////////////////////////////////////
// Name:        wx/weakref.h
// Purpose:     wxWeakRef - Generic weak references for wxWidgets
// Author:      Arne Steinarson
// Modified by:
// Created:     27 Dec 07
// RCS-ID:      
// Copyright:   (c) 2007 Arne Steinarson
// Licence:     wxWindows licence
/////////////////////////////////////////////////////////////////////////////

#ifndef _WX_WEAKREF_H_
#define _WX_WEAKREF_H_

#include <wx/tracker.h>


// A weak reference to an object of type T, where T has type wxTrackable 
// as one of its base classes (in a static or dynamic sense).
template<class T>
struct wxWeakRef : public wxTrackerNode {

    wxWeakRef( T* pobj=NULL ) : m_pobj(NULL) { Assign(pobj); }
    
    virtual ~wxWeakRef( ) { Assign(NULL); }
    
    // Smart pointer functions 
    operator T*(){ return m_pobj; }
    T* operator ->(){ return m_pobj; }
    T* operator = (T* pobj){ 
        Assign(pobj); 
        return m_pobj; 
    }
    
    virtual void OnObjectDestroy( ) 
    {
        // Tracked object itself removes us from list of trackers
        wxASSERT( m_pobj!=NULL );
        m_pobj = NULL;
    }
    
    virtual wxTrackerNodeType GetType() { return WeakRef; }
    
protected:    
    void Assign( T* pobj ){
        if( m_pobj==pobj ) return;
        // First release old object if any 
        if( m_pobj )
        {
            // Remove ourselves from object tracker list
            // This does static_cast if available, otherwise it tries dynamic cast
            wxTrackableBase *pt = wxTrackableCaster<T,wxHasBase<T,wxTrackableBase>::value >::Cast(m_pobj);
            wxASSERT(pt);
            pt->RemoveNode(this);
            m_pobj = NULL;
        }
        // Now set new trackable object
        if( pobj )
        {
            wxTrackableBase *pt = wxTrackableCaster<T,wxHasBase<T,wxTrackableBase>::value >::Cast(pobj);
            if( pt )
            {
                pt->AddNode( this );
                m_pobj = pobj;
            }
            else
            {
                // It is OK to try to attempt to create a weak ref to an object even if object 
                // doesn't support wxTrackableBase. Log a message is enough.
                wxFAIL_COND_MSG("pt!=NULL",_T("wxWeakRef<T>::Assign - Type does not provide wxTrackableBase"));
            }
        }
    }
    
    T *m_pobj;
};

// Provide some basic types of weak references
class wxObject;
class wxEvtHandler;
class wxWindow;

typedef wxWeakRef<wxObject>      wxObjectRef;
typedef wxWeakRef<wxEvtHandler>  wxEvtHandlerRef;
typedef wxWeakRef<wxWindow>      wxWindowRef;

#endif // _WX_WEAKREF_H_

