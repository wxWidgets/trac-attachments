#include "app.h"
#include "main.h"

IMPLEMENT_APP(MyApp);

bool MyApp::OnInit()
{
	main* frame = new main(0L);
	frame->Show();
	return true;
}
