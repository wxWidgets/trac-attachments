#ifndef MAIN_H
#define MAIN_H

#include <wx/wxprec.h>

#ifdef __BORLANDC__
    #pragma hdrstop
#endif

//(*Headers(main)
#include <wx/button.h>
#include <wx/frame.h>
#include <wx/intl.h>
#include <wx/sizer.h>
#include <wx/textctrl.h>
//*)

class main: public wxFrame
{
	public:

		main(wxWindow* parent,wxWindowID id = -1);
		virtual ~main();

		//(*Identifiers(main)
		enum Identifiers
		{
			ID_BUTTON1 = 0x1000,
			ID_BUTTON2,
			ID_BUTTON3,
			ID_TEXTCTRL1
		};
		//*)

	protected:

		//(*Handlers(main)
		void onCreate(wxCommandEvent& event);
		void onChange(wxCommandEvent& event);
		void onwxFFileStream(wxCommandEvent& event);
		//*)

		//(*Declarations(main)
		wxBoxSizer* BoxSizer1;
		wxTextCtrl* TextCtrl1;
		wxButton* Button1;
		wxButton* Button2;
		wxButton* Button3;
		//*)

	private:

		DECLARE_EVENT_TABLE()
};

#endif
