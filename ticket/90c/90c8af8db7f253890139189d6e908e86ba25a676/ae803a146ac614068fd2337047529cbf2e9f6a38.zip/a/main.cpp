#include "main.h"
#include <wx/wfstream.h>

BEGIN_EVENT_TABLE(main,wxFrame)
	//(*EventTable(main)
	EVT_BUTTON(ID_BUTTON1,main::onCreate)
	EVT_BUTTON(ID_BUTTON2,main::onChange)
	EVT_BUTTON(ID_BUTTON3,main::onwxFFileStream)
	//*)
END_EVENT_TABLE()

main::main(wxWindow* parent,wxWindowID id)
{
	//(*Initialize(main)
	Create(parent,id,_T(""),wxDefaultPosition,wxDefaultSize,wxDEFAULT_FRAME_STYLE);
	BoxSizer1 = new wxBoxSizer(wxHORIZONTAL);
	TextCtrl1 = new wxTextCtrl(this,ID_TEXTCTRL1,_T(""),wxDefaultPosition,wxSize(206,135),wxTE_MULTILINE);
	if ( 0 ) TextCtrl1->SetMaxLength(0);
	Button1 = new wxButton(this,ID_BUTTON1,_("create"),wxDefaultPosition,wxDefaultSize,0);
	if (false) Button1->SetDefault();
	Button2 = new wxButton(this,ID_BUTTON2,_("change contents"),wxDefaultPosition,wxDefaultSize,0);
	if (false) Button2->SetDefault();
	Button3 = new wxButton(this,ID_BUTTON3,_("test wxFFileStream"),wxDefaultPosition,wxDefaultSize,0);
	if (false) Button3->SetDefault();
	BoxSizer1->Add(TextCtrl1,1,wxALL|wxALIGN_LEFT|wxALIGN_TOP|wxEXPAND,0);
	BoxSizer1->Add(20,-1,0);
	BoxSizer1->Add(Button1,0,wxALL|wxALIGN_CENTER,0);
	BoxSizer1->Add(5,-1,0);
	BoxSizer1->Add(Button2,0,wxALL|wxALIGN_CENTER,0);
	BoxSizer1->Add(5,-1,0);
	BoxSizer1->Add(Button3,0,wxALL|wxALIGN_CENTER,0);
	this->SetSizer(BoxSizer1);
	BoxSizer1->Fit(this);
	BoxSizer1->SetSizeHints(this);
	//*)
}

main::~main()
{
}


void main::onCreate(wxCommandEvent& event)
{
	char a = 0;
	*TextCtrl1 << _("creating files\n");
	for (int i=0; i<5; i++) {
		*TextCtrl1 << wxString::Format(_T("\tfile_%d\n"), i+1);
		wxFileOutputStream fout(wxString::Format(_T("./file_%d"), i+1));
		for (unsigned int n=0; n<65000; n++) {
			fout.Write(&a, 1);
		}
	}
	*TextCtrl1 << _("finished\n");
}

void main::onChange(wxCommandEvent& event)
{
	*TextCtrl1 << _("modifing files\n");
	for (int i=0; i<5; i++) {
		*TextCtrl1 << wxString::Format(_T("\tfile_%d\n"), i+1);
		wxFFileOutputStream fout(wxString::Format(_T("./file_%d"), i+1), _("r+"));
		fout.SeekO(0);
		i++;
		for (unsigned int n=0; n<100; n++) {
			fout.Write(&i, 1);
		}
		i--;
	}
	*TextCtrl1 << _("finished\n");
}

void main::onwxFFileStream(wxCommandEvent& event)
{
	*TextCtrl1 << _("testing wxFFileStream\n");
	for (int i=0, num=1; i<5; ++i, ++num) {
		*TextCtrl1 << wxString::Format(_T("\tfile_%d\n"), num);
		wxFFileStream fout(wxString::Format(_T("./file_%d"), num));

		if (fout.Ok()) *TextCtrl1 << _("stream ok");
            else *TextCtrl1 << _T("stream faild");
		fout.SeekO(0);
		for (unsigned int n=0; n<100; n++) {
			fout.Write(&i, 1);
		}
	}
	*TextCtrl1 << _("finished\n");
}
