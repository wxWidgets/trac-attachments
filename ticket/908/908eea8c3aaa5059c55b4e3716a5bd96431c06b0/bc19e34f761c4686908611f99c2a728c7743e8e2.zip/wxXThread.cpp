#include "wx/xthread.h"



//---------------------------------------------------------------------
//wxXTEvtHandler
//---------------------------------------------------------------------


wxXTEvtHandler::wxXTEvtHandler()
	: wxEvtHandler()
{
	m_xthread = NULL;
	StartXThread();
}



wxXTEvtHandler::~wxXTEvtHandler()
{
	DeleteXThread();
}



#if wxUSE_THREADS
bool wxXTEvtHandler::ProcessEvent(wxEvent& event)
{
	AddPendingXTEvent(event);
	return true;
}
#endif

void wxXTEvtHandler::AddPendingXTEvent(wxEvent &event)
{
	if(m_xthread != NULL)
		m_xthread->AddPendingXTEvent(event);
}

void wxXTEvtHandler::EmptyXTEventQueue()
{
	if(m_xthread != NULL)
		m_xthread->EmptyXTEventQueue();
}

void wxXTEvtHandler::DeleteXThread()
{
	if(m_xthread != NULL)
		m_xthread->DeleteXT();
	
	m_xthread = NULL;
}

void wxXTEvtHandler::StartXThread()
{
	if(m_xthread != NULL)
	{
		if(m_xthread->IsRunning()) return;
		if(m_xthread->IsAlive()) DeleteXThread();

		//Perhaps some kind of delete m_xthread should be called here
	}

	m_xthread = new wxXThread(this);
	if(m_xthread->Create() == wxTHREAD_NO_ERROR)
		m_xthread->Run();
}



//---------------------------------------------------------------------
//wxXThread
//---------------------------------------------------------------------

wxXThread::wxXThread(wxXTEvtHandler *parent)
{
	m_parent = parent;
	m_cond = NULL;
	m_is_deleting = false;
}

wxXThread::~wxXThread()
{
}

void wxXThread::AddPendingXTEvent(wxEvent &event)
{
	wxEvent *eventCopy = event.Clone();

	wxMutexLocker lock(m_eventsLocker);

	m_pendingEvents.Append(eventCopy);

	//If the eventhandling loop is conditional locked (ie waiting to be signaled)
	//we signal it here.
	if(m_pendingEvents.GetCount() == 1)
	{
		m_condLocker.Lock();
		if(m_cond != NULL)
			m_cond->Signal();
		m_condLocker.Unlock();
	}
}

void wxXThread::EmptyXTEventQueue()
{
	wxMutexLocker lock(m_eventsLocker);

	m_pendingEvents.Clear();
}

void wxXThread::DeleteXT()
{
	//If the eventloop is currently handling an event we can just call Delete()
	//because TestDestroy() will be called once it finnishes with the event
	if(m_cond == NULL) 
	{
		wxThread::Delete();
		return;
	}

	//Otherwise the thread is waiting to be signaled, and we set m_is_deleting so that
	//it knows that we are shuting down
	m_is_deleting = true;

	//Signal the thread
	m_condLocker.Lock();
	if(m_cond != NULL)
		m_cond->Signal();
	m_condLocker.Unlock();

	//Perhaps wxThread::Delete() should be called here, I don't know the precise nature of
	//that method so I leave it to someone who knows to decide
}


void *wxXThread::Entry()
{
	//The eventhandling loop
	while(!TestDestroy())
	{
		m_eventsLocker.Lock();
		bool events_waiting = m_pendingEvents.GetCount() > 0;

		//Check if there is no events waiting in the queue
		if(!events_waiting)
		{
			m_cond = new wxCondition(m_condLocker);
			
			m_eventsLocker.Unlock(); //Unlock the events queue so that AddPendingXTEvent() can access it
			m_condLocker.Lock(); //Lock the condition locker, because Wait() requires it
			
			//Unlock the condition locker and wait fo a signal, ie a new event has arrived or DeleteXT() was called
			m_cond->Wait();
			
			//Test weather we are asked to destroy
			if(TestDestroy() || m_is_deleting) return NULL;

			delete m_cond;
			m_cond = NULL;
			
			m_condLocker.Unlock(); //Unlock the condition locker so that we can issue it next time
			m_eventsLocker.Lock(); //Lock the eventqueue again, since we are going to work with it now
		}
		
		wxEvent *event = (wxEvent *) m_pendingEvents.GetFirst()->GetData(); // Copy the event so that we wont occupy the eventqueue too long
		m_pendingEvents.DeleteNode(m_pendingEvents.GetFirst()); // Delete the event we just copied, so that the next event will be first in line
		m_eventsLocker.Unlock(); // Unlock the eventqueue so that AddPendingXTEvent() can add more events while we process the event
		
		//And finaly, process the event
		ProcessXTEvent(*event);
		delete event;
	}

	return NULL;
}

void wxXThread::OnExit()
{
}

void wxXThread::ProcessXTEvent(wxEvent &event)
{
	m_parent->SearchDynamicEventTable(event);
}
