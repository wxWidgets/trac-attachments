#ifndef _WX_X_THREAD_H_
#define _WX_X_THREAD_H_


#include "wx/thread.h"
#include "wx/event.h"


//---------------------------------------------------------------------
//wxXTEvtHandler: class to pass events from event handler to xthread
//---------------------------------------------------------------------

//This class simply takes the events passed to it in ProcessEvent()
//and send them to the event queue in wxXThread. (The X stands for eXtended)

//I tried making wxXTEvtHandler inherit both wxEvtHandler and wxThread,
//so that it would be just one class. But for some reason the event table
//lookup with SearchDynamicEventTable wouldn't work then.

class WXDLLEXPORT wxXTEvtHandler : public wxEvtHandler
{
public:
	wxXTEvtHandler();
	~wxXTEvtHandler();

#if wxUSE_THREADS //If thread usage is of the class will still work
	virtual bool ProcessEvent(wxEvent& event);
#endif

	void AddPendingXTEvent(wxEvent &event);
	void EmptyXTEventQueue();
	
	void DeleteXThread();
	void StartXThread();	//If this method is called when the thread is already
							//running, the thread will be restarted

	class wxXThread *m_xthread;
};




//---------------------------------------------------------------------
//wxXThread: thread class that handles events passed to it from a wxXTEvent Handler
//---------------------------------------------------------------------

//This class is a simple event handling thread with a event queue.
//Should never be used without wxXTEvtHandler, becaus it uses
//its parents Event Table (the table where event types are linked to
//functions)

class WXDLLEXPORT wxXThread : public wxThread
{
public:
	wxXThread(wxXTEvtHandler *parent);
	~wxXThread();

	void AddPendingXTEvent(wxEvent &event);
	void EmptyXTEventQueue();
	void DeleteXT();

	bool m_is_deleting; // Variable to check wheather thread is shuting down or not
						// the reason for not just using TryDelete() is that DeleteXT
						// both wakes the thread up and shuts it down, but if it for
						// example calls wakeup first the thread will run another event
						// before quiting, and if it runs Delete() first it will wait for
						// the thread forever. (If you make wxThread::Delete() virtual this
						// function can simply be renamed to Delete() )

private:
	virtual void *Entry();
    virtual void OnExit();

	virtual void ProcessXTEvent(wxEvent &event);

	wxXTEvtHandler *m_parent;

	wxList m_pendingEvents; //The Events queue
	
	wxMutex m_eventsLocker; //Events queue mutex locker
	wxMutex m_condLocker; //Wake up condition locker
	wxCondition *m_cond; //Wake up condition
};  


#endif	/* _wxXTEvtHandler_H */
