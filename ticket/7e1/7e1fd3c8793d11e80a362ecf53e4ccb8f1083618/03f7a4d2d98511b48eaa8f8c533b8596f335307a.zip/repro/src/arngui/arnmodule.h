// module.h

#ifndef __ARNOLDMODULE_H__
#define __ARNOLDMODULE_H__

class WXDLLIMPEXP_FWD_ADV wxAboutDialogInfo;

/////////////////////////////////////////////////////////////////////////////
// ArnoldModule

class ArnoldModule : public wxModule
{
    typedef wxModule base;
    DECLARE_DYNAMIC_CLASS(ArnoldModule)
protected:
public:
    ArnoldModule(void);

    virtual bool OnInit();
    virtual void OnExit();

    static ArnoldModule* Get();

    static void GetVersionInfo(wxAboutDialogInfo*);
};

#endif // __ARNOLDMODULE_H__
