#ifndef __JOYSTICK_DIALOG_HEADER_INCLUDED__
#define __JOYSTICK_DIALOG_HEADER_INCLUDED__

#include <wx/dialog.h>

class JoystickDialog : public  wxDialog
{
public:
    JoystickDialog(wxWindow *pParent);
    ~JoystickDialog();
void RefreshRadio();

    virtual bool TransferDataFromWindow();
    virtual bool TransferDataToWindow();
void OnUseMouse(wxCommandEvent & WXUNUSED(event));
void OnUseController(wxCommandEvent & WXUNUSED(event));
void OnUseKeyboard(wxCommandEvent & WXUNUSED(event));
int m_nJoystickType;
private:

   DECLARE_EVENT_TABLE()
};

#endif
