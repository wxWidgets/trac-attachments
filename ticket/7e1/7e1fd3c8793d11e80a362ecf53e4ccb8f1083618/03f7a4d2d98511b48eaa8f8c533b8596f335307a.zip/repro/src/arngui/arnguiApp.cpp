
#include "arnguiApp.h"
#include "arnguiMain.h"
#include <wx/xrc/xmlres.h>
#include <wx/stdpaths.h>
#include <wx/choicdlg.h>
#include <wx/ipc.h>
#include <wx/listctrl.h>
#include <wx/wfstream.h>
#include <locale.h>
#include <wx/tarstrm.h>
#include <wx/filesys.h>
#include <wx/fs_zip.h>
#include <wx/fs_arc.h>
#include <wx/fs_filter.h>
#include <wx/splash.h>
#include <wx/dir.h>
#include <wx/fileconf.h>
#include <wx/msgout.h>
#include <wx/tokenzr.h>
#include <wx/sysopt.h>
#include <wx/image.h>

IMPLEMENT_APP(arnguiApp)


int arnguiApp::OnExit()
{
    return wxApp::OnExit();

}
// get the directory path of the app (with trailing separator)
// so we can easily add on another path or filename
wxString arnguiApp::GetAppPath()
{
    wxString sPath = wxStandardPaths::Get().GetExecutablePath();
    wxFileName Path(sPath);
    return Path.GetPath(wxPATH_GET_VOLUME|wxPATH_GET_SEPARATOR);
}


// get the location of the GUI that come with the app are read from
wxString arnguiApp::GetGUIFullPath()
{
//#ifndef __WXDEBUG__
//    // for release
//    wxFileName ExeData(GetAppPath(),  wxT("arngui.zip"));
//    wxString sGUIFullPath = ExeData.GetFullPath();
//    sGUIFullPath += wxT("#zip:GUIFrame.xrc");
//    return sGUIFullPath;
//#else
    // for debugging
    wxFileName GUIPath(GetAppPath(), wxT("GUIFrame.xrc"));
    return GUIPath.GetFullPath();
//#endif
}

arnguiApp::arnguiApp() : wxApp()
{
}


bool arnguiApp::OnInit()
{

  if (!wxApp::OnInit())
    return false;
	wxSystemOptions::SetOption(_T("filesys.no-mimetypesmanager"), 0);
	wxSystemOptions::SetOption(_T("window-default-variant"), _T(""));
#ifdef __WXMSW__
	wxSystemOptions::SetOption(_T("no-maskblt"), 0);
	wxSystemOptions::SetOption(_T("msw.window.no-clip-children"), 0);
	wxSystemOptions::SetOption(_T("msw.font.no-proof-quality"), 0);
#endif

	// stop all windows getting idle events
	wxIdleEvent::SetMode(wxIDLE_PROCESS_SPECIFIED);

	// stop all windows getting update events; update events
	// do not occur for the main menu if running under Ubunty with Unity
	// window manager.
	wxUpdateUIEvent::SetMode(wxUPDATE_UI_PROCESS_SPECIFIED);

#if (wxVERSION_NUMBER < 2900)
    wxSetlocale(LC_ALL, wxEmptyString);
#endif

    wxFileSystem::AddHandler(new wxArchiveFSHandler);
    wxFileSystem::AddHandler(new wxFilterFSHandler);
    wxFileSystem::AddHandler(new wxZipFSHandler);



    wxImage::AddHandler(new wxPNGHandler);

wxXmlResource::Get()->InitAllHandlers();
	wxXmlResource::Get()->Load(GetGUIFullPath());

    frame = new arnguiFrame(0L);
    SetTopWindow(frame);
   frame->Show();

    // start the main loop
    return true;
}
