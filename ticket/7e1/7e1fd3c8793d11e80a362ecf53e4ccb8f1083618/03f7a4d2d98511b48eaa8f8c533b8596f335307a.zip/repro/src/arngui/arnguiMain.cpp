
#include "arnguiMain.h"
#include "arnguiApp.h"
#include "JoystickDialog.h"
#include <wx/xrc/xmlres.h>

BEGIN_EVENT_TABLE(arnguiFrame, wxFrame)
  EVT_COMMAND(XRCID("menu_autostart"), wxEVT_COMMAND_MENU_SELECTED,arnguiFrame::OnShowBug)
END_EVENT_TABLE()
  
arnguiFrame::arnguiFrame( wxWindow* parent, wxWindowID id, const wxString& title, const wxPoint& pos, const wxSize& size, long style ) : wxFrame( parent, id, title, pos, size, style | wxCLIP_CHILDREN|wxNO_FULL_REPAINT_ON_RESIZE ),
 m_MenuBar(NULL)
{

	SetExtraStyle(GetExtraStyle()|wxWS_EX_PROCESS_IDLE);


	//this part causes resize events so better to use it before the screen setting, and less problem for OSD
  	m_MenuBar = wxXmlResource::Get()->LoadMenuBar(this, wxT("main_menu"));
	if (m_MenuBar==NULL)
	{
		printf("Failed to get menu bar\n");
	}
  else
  {


	this->SetMenuBar( m_MenuBar );

			// connect the idle event
			Connect( wxEVT_IDLE, wxIdleEventHandler( arnguiFrame::OnIdle ) );
}
}

void arnguiFrame::OnShowBug( wxCommandEvent& WXUNUSED(event) )
{
 JoystickDialog dlg(this);
  dlg.ShowModal();

}

arnguiFrame::~arnguiFrame()
{
}

