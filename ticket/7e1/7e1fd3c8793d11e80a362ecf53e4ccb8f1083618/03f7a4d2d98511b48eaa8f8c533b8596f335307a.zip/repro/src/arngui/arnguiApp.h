
#ifndef ARNGUIAPP_H
#define ARNGUIAPP_H

#include <wx/app.h>

class arnguiFrame;

class arnguiApp : public wxApp
{
    private:

        arnguiFrame* frame;
      virtual bool OnInit();
        virtual int OnExit();
wxString GetGUIFullPath();
    wxString GetAppPath();
    
    public:
      arnguiApp();
};

DECLARE_APP(arnguiApp)

#endif // ARNGUIAPP_H
