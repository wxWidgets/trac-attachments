
#ifndef ARNGUIMAIN_H
#define ARNGUIMAIN_H


#include "arnguiApp.h"
#include <wx/frame.h>
#include <wx/menu.h>

class arnguiFrame: public wxFrame
{
    public:
   
        arnguiFrame( wxWindow* parent, wxWindowID id = wxID_ANY, const wxString& title = wxT("Arnold"), const wxPoint& pos = wxDefaultPosition, const wxSize& size = wxSize( 481,466 ), long style = wxDEFAULT_FRAME_STYLE|wxTAB_TRAVERSAL );
        virtual ~arnguiFrame();

   		virtual void OnShowBug( wxCommandEvent& event );

    DECLARE_EVENT_TABLE()
wxMenuBar *m_MenuBar;
    
};


#endif // ARNGUIMAIN_H
