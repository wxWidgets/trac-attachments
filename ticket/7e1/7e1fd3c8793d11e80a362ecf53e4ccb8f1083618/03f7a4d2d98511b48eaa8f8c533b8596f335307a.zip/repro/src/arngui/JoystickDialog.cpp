#include "JoystickDialog.h"
#include <wx/xrc/xmlres.h>
#include "arnguiApp.h"
#include <wx/listbox.h>
#include <wx/choice.h>
#include <wx/checkbox.h>
#include <wx/slider.h>
#include <wx/button.h>
#include <wx/radiobut.h>
#include <wx/msgdlg.h>

enum
{
  JOYSTICK_TYPE_SIMULATED_BY_KEYBOARD,
  JOYSTICK_TYPE_SIMULATED_BY_MOUSE,
  JOYSTICK_TYPE_REAL
};

BEGIN_EVENT_TABLE(JoystickDialog, wxDialog)
	EVT_RADIOBUTTON(XRCID("IDC_RADIO_USE_CONTROLLER"), JoystickDialog::OnUseController)
	EVT_RADIOBUTTON(XRCID("IDC_RADIO_USE_KEYBOARD"), JoystickDialog::OnUseKeyboard)
	EVT_RADIOBUTTON(XRCID("IDC_RADIO_USE_MOUSE"), JoystickDialog::OnUseMouse)
END_EVENT_TABLE()


JoystickDialog::~JoystickDialog()
{

}



void JoystickDialog::RefreshRadio()
{
	wxRadioButton *pRadioButton;
	wxWindow *pWindow;

	// You can't have a radio with nothing set.
	pWindow = this->FindWindow(XRCID("IDC_RADIO_USE_KEYBOARD"));
	pRadioButton = static_cast<wxRadioButton *>(pWindow);
	pRadioButton->SetValue((m_nJoystickType==JOYSTICK_TYPE_SIMULATED_BY_KEYBOARD));

	pWindow = this->FindWindow(XRCID("IDC_RADIO_USE_MOUSE"));
	pRadioButton = static_cast<wxRadioButton *>(pWindow);
	pRadioButton->SetValue((m_nJoystickType==JOYSTICK_TYPE_SIMULATED_BY_MOUSE));

	pWindow = this->FindWindow(XRCID("IDC_RADIO_USE_CONTROLLER"));
	pRadioButton = static_cast<wxRadioButton *>(pWindow);
    pRadioButton->SetValue((m_nJoystickType==JOYSTICK_TYPE_REAL));

}


void JoystickDialog::OnUseController(wxCommandEvent & WXUNUSED(event))
{
    m_nJoystickType = JOYSTICK_TYPE_REAL;
    RefreshRadio();
}

void JoystickDialog::OnUseKeyboard(wxCommandEvent & WXUNUSED(event))
{
    m_nJoystickType = JOYSTICK_TYPE_SIMULATED_BY_KEYBOARD;
    RefreshRadio();
}


void JoystickDialog::OnUseMouse(wxCommandEvent & WXUNUSED(event))
{
    m_nJoystickType = JOYSTICK_TYPE_SIMULATED_BY_MOUSE;
    RefreshRadio();
}

bool JoystickDialog::TransferDataToWindow()
{
	wxCheckBox *pCheckBox;
	wxWindow *pWindow;
	wxSlider *pSlider;
	wxChoice *pChoice;
  

	RefreshRadio();
	
	return true;
}

bool JoystickDialog::TransferDataFromWindow()
{
	
	return true;

}


JoystickDialog::JoystickDialog(wxWindow *pParent) : m_nJoystickType(JOYSTICK_TYPE_REAL)
{
	// load the resource
	wxXmlResource::Get()->LoadDialog(this, pParent, wxT("DLG_DIALOG_JOYSTICK"));

}

