mkdir -p ../exe/Release/arnold/
cp arngui/GUIFrame.xrc ../exe/Release/arnold
cmake -DCMAKE_BUILD_TYPE:STRING=Release -G "Unix Makefiles" .
make
../exe/Release/arnold/arnold