#ifndef DLL_H
#define DLL_H

#ifdef BUILD
	// build dll
	#define API __declspec(dllexport)
	#define wxMSVC_VERSION_AUTO // used only when building this library
#else
	// use dll
	#define API __declspec(dllimport)
	#pragma comment(lib,"dll.lib")
#endif

void API test();

#endif
