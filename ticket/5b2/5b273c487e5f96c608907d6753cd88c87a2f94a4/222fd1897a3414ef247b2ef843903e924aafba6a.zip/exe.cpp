#include "dll.h"

int main(int argc, char **argv)
{
	test();
	return 0;
}
