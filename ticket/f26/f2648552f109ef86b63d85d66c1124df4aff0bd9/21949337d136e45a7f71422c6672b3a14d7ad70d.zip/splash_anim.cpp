
// For compilers that support precompilation, includes "wx/wx.h".
#include "wx/wxprec.h"

#ifdef __BORLANDC__
    #pragma hdrstop
#endif

#ifdef __WXGTK20__
    #include <gtk/gtk.h>
#endif

#include "splash_anim.h"

/*
 * wxSplashScreenAnim
 */

#define wxSPLASH_TIMER_ID 9999

IMPLEMENT_DYNAMIC_CLASS(wxSplashScreenAnim, wxFrame)

BEGIN_EVENT_TABLE(wxSplashScreenAnim, wxFrame)
    EVT_TIMER(wxSPLASH_TIMER_ID, wxSplashScreenAnim::OnNotify)
    EVT_CLOSE(wxSplashScreenAnim::OnCloseWindow)
END_EVENT_TABLE()

/* Note that unless we pass a non-default size to the frame, SetClientSize
 * won't work properly under Windows, and the splash screen frame is sized
 * slightly too small.
 */

wxSplashScreenAnim::wxSplashScreenAnim(const wxAnimation& anim, long splashStyle, int milliseconds, wxWindow* parent, wxWindowID id, const wxPoint& pos, const wxSize& size, long style):
    wxFrame(parent, id, wxEmptyString, wxPoint(0,0), wxSize(-1, -1), style)
{
    m_anim = NULL;
    m_splashStyle = splashStyle;
    m_milliseconds = milliseconds;

    m_anim = new wxAnimationCtrl(this, wxID_ANY, anim, pos, size, wxNO_BORDER);

    SetClientSize(anim.GetSize());

    if (m_splashStyle & wxSPLASH_CENTRE_ON_PARENT)
        CentreOnParent();
    else if (m_splashStyle & wxSPLASH_CENTRE_ON_SCREEN)
        CentreOnScreen();

    if (m_splashStyle & wxSPLASH_TIMEOUT)
    {
        m_timer.SetOwner(this, wxSPLASH_TIMER_ID);
        m_timer.Start(milliseconds, true);
    }
///    m_anim->Connect(wxEVT_LEFT_DOWN, wxMouseEventHandler(wxSplashScreenAnim::OnMouseEvent), 0, this);

    Show(true);
    m_anim->Play();
}

wxSplashScreenAnim::~wxSplashScreenAnim()
{
    m_timer.Stop();
}

void wxSplashScreenAnim::OnNotify(wxTimerEvent& WXUNUSED(event))
{
    Close(true);
}

void wxSplashScreenAnim::OnCloseWindow(wxCloseEvent& WXUNUSED(event))
{
    m_timer.Stop();
    this->Destroy();
}
/*
void wxSplashScreenAnim::OnMouseEvent(wxMouseEvent& event)
{
///    m_timer.Stop();
///    this->Destroy();
///    Close(true);
}
*/
