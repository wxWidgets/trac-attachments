
#ifndef _WX_SPLASH_ANIM_H_
#define _WX_SPLASH_ANIM_H_

#include <wx/splash.h>
#include <wx/animate.h>

/*
 * wxSplashScreenAnim
 */

class wxSplashScreenAnim: public wxFrame
{
public:
    // for RTTI macros only
    wxSplashScreenAnim() {}
    wxSplashScreenAnim(const wxAnimation& anim, long splashStyle, int milliseconds,
                   wxWindow* parent, wxWindowID id,
                   const wxPoint& pos = wxDefaultPosition,
                   const wxSize& size = wxDefaultSize,
                   long style = wxSIMPLE_BORDER|wxFRAME_NO_TASKBAR|wxSTAY_ON_TOP);
    virtual ~wxSplashScreenAnim();

    void OnCloseWindow(wxCloseEvent& event);
    void OnNotify(wxTimerEvent& event);

    long GetSplashStyle() const { return m_splashStyle; }
    wxAnimationCtrl* GetAnimationCtrl() const { return m_anim; }
    int GetTimeout() const { return m_milliseconds; }

protected:
///    void OnMouseEvent  (wxMouseEvent& e);

    wxAnimationCtrl*        m_anim;
    long                    m_splashStyle;
    int                     m_milliseconds;
    wxTimer                 m_timer;

    DECLARE_DYNAMIC_CLASS(wxSplashScreenAnim)
    DECLARE_EVENT_TABLE()
    DECLARE_NO_COPY_CLASS(wxSplashScreenAnim)
};


#endif
    // _WX_SPLASH_H_
