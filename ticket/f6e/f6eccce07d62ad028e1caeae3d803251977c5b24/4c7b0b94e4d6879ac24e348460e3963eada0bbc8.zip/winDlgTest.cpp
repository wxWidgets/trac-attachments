#include <windows.h>
#include "resource.h"

HINSTANCE hInst;

int CALLBACK DialogProc(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	switch (uMsg)
	{
		case WM_INITDIALOG:
		{
			SendDlgItemMessage(hwnd, IDC_RADIO1, BM_SETCHECK, BST_CHECKED, NULL);
			SendDlgItemMessage(hwnd, IDC_RADIO4, BM_SETCHECK, BST_CHECKED, NULL);
			return 1;
		}
		case WM_COMMAND:
		{
			switch(LOWORD(wParam))
			{
				case IDOK:
					EndDialog(hwnd, 0);
					return 1;
				case 2:
					EndDialog(hwnd, 0);
					return 1;
			}
		return 0;
		}
	}
	return FALSE;
}

LRESULT CALLBACK MainWindowFunc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	switch (message)
	{
	    case WM_COMMAND:
			switch(LOWORD(wParam))
			{
				case ID_START:
					DialogBoxParam(hInst, MAKEINTRESOURCE(IDD_DIALOG), hwnd, DialogProc, NULL);
					return 0;
			}
			break;
		case WM_DESTROY:
		{	
			PostQuitMessage(0);
			break;
		}
		default:
			return DefWindowProc(hwnd, message, wParam, lParam);
	}
	return 0;
}

int WINAPI WinMain (HINSTANCE hThisInst, HINSTANCE hPrevInst, LPSTR lpszArgs, int nWinMode)
{
    hInst = hThisInst;
	WNDCLASS wc;
	memset(& wc, 0, sizeof(wc));
	wc.hInstance = hThisInst;
	wc.lpszClassName = "winDlgTest";
	wc.lpfnWndProc = MainWindowFunc;
	wc.style = CS_HREDRAW | CS_VREDRAW;
    wc.hIcon = LoadIcon(NULL, IDI_APPLICATION); 
	wc.hCursor = LoadCursor(NULL, IDC_ARROW);
	wc.lpszMenuName = MAKEINTRESOURCE(IDR_MENU);
    wc.hbrBackground = (HBRUSH)GetStockObject(WHITE_BRUSH); 
	if(!RegisterClass(& wc))
		return 0;
	HWND hWnd = CreateWindow(wc.lpszClassName, wc.lpszClassName, WS_OVERLAPPEDWINDOW | WS_CLIPCHILDREN, 
							CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT, 
							HWND_DESKTOP, NULL, hThisInst, NULL);
	ShowWindow(hWnd, nWinMode);
	UpdateWindow(hWnd);
	MSG msg;
	while (GetMessage(& msg, NULL, 0, 0))
	{
        TranslateMessage(& msg);
        DispatchMessage(& msg);
	}
	return msg.wParam;
}



