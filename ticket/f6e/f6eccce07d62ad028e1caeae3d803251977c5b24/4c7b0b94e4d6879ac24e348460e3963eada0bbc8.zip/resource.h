//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by WinDlgTest.rc
//
#define IDR_MENU                        101
#define IDD_DIALOG                      102
#define IDC_RADIO1                      1000
#define IDC_RADIO2                      1001
#define IDC_RADIO3                      1002
#define IDC_RADIO4                      1003
#define IDC_RADIO5                      1004
#define IDC_RADIO6                      1005
#define IDC_CHECK1                      1006
#define IDC_CHECK2                      1007
#define ID_START                        40001
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        103
#define _APS_NEXT_COMMAND_VALUE         40002
#define _APS_NEXT_CONTROL_VALUE         1007
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
