
#include "Form.h"

const wxChar* Form::FormName = wxT("FormName");
const wxChar* Form::ClassName= wxT("Form");
const wxChar* RootNode = wxT("wxWindowsXTI");

Form::Form()
{
 
}
 
bool Form::Init()
{
   this->Create(NULL, FORM_ID, "form", wxPoint(160, 160), wxSize(160, 160), \
		 wxCLIP_CHILDREN|wxCAPTION|wxTHICK_FRAME|wxSYSTEM_MENU|wxRESIZE_BOX|wxCLOSE_BOX|wxMINIMIZE_BOX);
   m_MainPanel = new wxPanel(this, MAIN_PANEL_ID, wxPoint(0,0), wxSize(152, 133), wxDEFAULT_FRAME_STYLE, "MainPanel");
   m_Notebook = new wxNotebook(m_MainPanel, NOTEBOOK_ID, wxPoint(0,0), wxSize(150, 130)); 
   wxNotebookPage* page1 = new wxNotebookPage(m_Notebook, NOTEBOOK_ID + 1, wxPoint(0,0), wxSize(150, 130));
   wxNotebookPage* page2 = new wxNotebookPage(m_Notebook, NOTEBOOK_ID + 2, wxPoint(0,0), wxSize(150, 130));
   m_Notebook->AddPage(page1, "page one", true);
   m_Notebook->AddPage(page2, "page two", false);
   return true;
}

bool Form::Create( wxWindow * parent, wxWindowID id, const wxString & title, const wxPoint & pos, \
                                            const wxSize & size, long style)
{
    return wxFrame::Create( parent, id, title, pos, size, style );
}

Form::~Form()
{

}

