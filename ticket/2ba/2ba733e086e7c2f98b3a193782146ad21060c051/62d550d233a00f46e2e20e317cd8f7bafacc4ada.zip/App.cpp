/*
 * Override of OnInit and program entry point
 */
#include <wx/xml/xml.h>
#include <wx/xti.h>
#include <wx/xtixml.h>
#include <wx/xtistrm.h>
#include <wx/wxprec.h>
#include <wx/mstream.h>
#include "App.h"
#include "Form.h"

wxChar * FirstNewXrcFile  = "FormOut1.xml";

bool App::OnInit()
{
    // Create form 
    Form * form = new Form;
    form->Init();

    // Persist form 
    StreamOut(form, Form::FormName, FirstNewXrcFile);

    // Load second form from xml
    form = (Form*)LoadForm(Form::FormName, FirstNewXrcFile);
    form->Show(true);

    return true;
}

IMPLEMENT_APP(App)
