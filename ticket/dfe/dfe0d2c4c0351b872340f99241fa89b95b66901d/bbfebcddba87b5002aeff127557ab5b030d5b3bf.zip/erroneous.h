#ifndef __ERRONEOUS_CLASS_H__
#define __ERRONEOUS_CLASS_H__

#include <wx/wx.h>
#include <wx/string.h>
#include <wx/socket.h>


class CErroneousServer :public wxEvtHandler{
	public:
		CErroneousServer(int Port=80,char *rem_addr=NULL);
		~CErroneousServer();
		void Startup();
		void Shutdown();
		virtual bool ProcessEvent(wxEvent& event);
	private:
		wxSockAddress *m_hSA;
		wxSocketBase *m_hSocket;
		wxSocketServer *m_hSocketSrv;
		int m_iPort;
		void NotifyModules(int iNotification);
};

#endif