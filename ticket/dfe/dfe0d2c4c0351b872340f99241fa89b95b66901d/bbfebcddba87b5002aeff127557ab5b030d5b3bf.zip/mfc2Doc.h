// mfc2Doc.h : Schnittstelle der Klasse CMfc2Doc
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_MFC2DOC_H__8D1A97BB_7083_459A_AD6A_624A45DB28F9__INCLUDED_)
#define AFX_MFC2DOC_H__8D1A97BB_7083_459A_AD6A_624A45DB28F9__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


class CMfc2Doc : public COleDocument
{
protected: // Nur aus Serialisierung erzeugen
	CMfc2Doc();
	DECLARE_DYNCREATE(CMfc2Doc)

// Attribute
public:

// Operationen
public:

// �berladungen
	// Vom Klassenassistenten generierte �berladungen virtueller Funktionen
	//{{AFX_VIRTUAL(CMfc2Doc)
	public:
	virtual BOOL OnNewDocument();
	virtual void Serialize(CArchive& ar);
	//}}AFX_VIRTUAL

// Implementierung
public:
	virtual ~CMfc2Doc();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generierte Message-Map-Funktionen
protected:
	//{{AFX_MSG(CMfc2Doc)
		// HINWEIS - An dieser Stelle werden Member-Funktionen vom Klassen-Assistenten eingef�gt und entfernt.
		//    Innerhalb dieser generierten Quelltextabschnitte NICHTS VER�NDERN!
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ f�gt unmittelbar vor der vorhergehenden Zeile zus�tzliche Deklarationen ein.

#endif // !defined(AFX_MFC2DOC_H__8D1A97BB_7083_459A_AD6A_624A45DB28F9__INCLUDED_)
