// mfc2Doc.cpp : Implementierung der Klasse CMfc2Doc
//

#include "stdafx.h"
#include "mfc2.h"

#include "mfc2Doc.h"
#include "CntrItem.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMfc2Doc

IMPLEMENT_DYNCREATE(CMfc2Doc, COleDocument)

BEGIN_MESSAGE_MAP(CMfc2Doc, COleDocument)
	//{{AFX_MSG_MAP(CMfc2Doc)
		// HINWEIS - Hier werden Mapping-Makros vom Klassen-Assistenten eingef�gt und entfernt.
		//    Innerhalb dieser generierten Quelltextabschnitte NICHTS VER�NDERN!
	//}}AFX_MSG_MAP
	// Zulassen der Standardimplementierung f�r OLE-Container
	ON_UPDATE_COMMAND_UI(ID_EDIT_PASTE, COleDocument::OnUpdatePasteMenu)
	ON_UPDATE_COMMAND_UI(ID_EDIT_PASTE_LINK, COleDocument::OnUpdatePasteLinkMenu)
	ON_UPDATE_COMMAND_UI(ID_OLE_EDIT_CONVERT, COleDocument::OnUpdateObjectVerbMenu)
	ON_COMMAND(ID_OLE_EDIT_CONVERT, COleDocument::OnEditConvert)
	ON_UPDATE_COMMAND_UI(ID_OLE_EDIT_LINKS, COleDocument::OnUpdateEditLinksMenu)
	ON_COMMAND(ID_OLE_EDIT_LINKS, COleDocument::OnEditLinks)
	ON_UPDATE_COMMAND_UI_RANGE(ID_OLE_VERB_FIRST, ID_OLE_VERB_LAST, COleDocument::OnUpdateObjectVerbMenu)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMfc2Doc Konstruktion/Destruktion

CMfc2Doc::CMfc2Doc()
{
	// Verwenden Sie OLE-Compound-Dateien
	EnableCompoundFile();

	// ZU ERLEDIGEN: Hier Code f�r One-Time-Konstruktion einf�gen

}

CMfc2Doc::~CMfc2Doc()
{
}

BOOL CMfc2Doc::OnNewDocument()
{
	if (!COleDocument::OnNewDocument())
		return FALSE;

	// ZU ERLEDIGEN: Hier Code zur Reinitialisierung einf�gen
	// (SDI-Dokumente verwenden dieses Dokument)

	return TRUE;
}



/////////////////////////////////////////////////////////////////////////////
// CMfc2Doc Serialisierung

void CMfc2Doc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		// ZU ERLEDIGEN: Hier Code zum Speichern einf�gen
	}
	else
	{
		// ZU ERLEDIGEN: Hier Code zum Laden einf�gen
	}

	// Ein Aufruf der Basisklasse COleDocument erm�glicht die Serialisierung
	//  des Objekts COleClientItem des Container-Dokuments.
	COleDocument::Serialize(ar);
}

/////////////////////////////////////////////////////////////////////////////
// CMfc2Doc Diagnose

#ifdef _DEBUG
void CMfc2Doc::AssertValid() const
{
	COleDocument::AssertValid();
}

void CMfc2Doc::Dump(CDumpContext& dc) const
{
	COleDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CMfc2Doc Befehle
