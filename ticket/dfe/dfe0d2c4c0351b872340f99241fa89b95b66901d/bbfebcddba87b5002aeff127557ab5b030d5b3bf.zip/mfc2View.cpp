// mfc2View.cpp : Implementierung der Klasse CMfc2View
//

#include "stdafx.h"
#include "mfc2.h"

#include "mfc2Doc.h"
#include "CntrItem.h"
#include "mfc2View.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMfc2View

IMPLEMENT_DYNCREATE(CMfc2View, CView)

BEGIN_MESSAGE_MAP(CMfc2View, CView)
	//{{AFX_MSG_MAP(CMfc2View)
		// HINWEIS - Hier werden Mapping-Makros vom Klassen-Assistenten eingef�gt und entfernt.
		//    Innerhalb dieser generierten Quelltextabschnitte NICHTS VER�NDERN!
	ON_WM_DESTROY()
	ON_WM_SETFOCUS()
	ON_WM_SIZE()
	ON_COMMAND(ID_OLE_INSERT_NEW, OnInsertObject)
	ON_COMMAND(ID_CANCEL_EDIT_CNTR, OnCancelEditCntr)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMfc2View Konstruktion/Destruktion

CMfc2View::CMfc2View()
{
	m_pSelection = NULL;
	// ZU ERLEDIGEN: Hier Code zur Konstruktion einf�gen,

}

CMfc2View::~CMfc2View()
{
}

BOOL CMfc2View::PreCreateWindow(CREATESTRUCT& cs)
{
	// ZU ERLEDIGEN: �ndern Sie hier die Fensterklasse oder das Erscheinungsbild, indem Sie
	//  CREATESTRUCT cs modifizieren.

	return CView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CMfc2View Zeichnen

void CMfc2View::OnDraw(CDC* pDC)
{
	CMfc2Doc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	// ZU ERLEDIGEN: Hier Code zum Zeichnen der urspr�nglichen Daten hinzuf�gen
}

void CMfc2View::OnInitialUpdate()
{
	CView::OnInitialUpdate();


	// ZU ERLEDIGEN: Entfernen Sie diesen Code, sobald der endg�ltige Code f�r das Auswahlmodell geschrieben ist
	m_pSelection = NULL;    // Auswahl initialisieren

	//Active documents should always be activated
	COleDocument* pDoc = (COleDocument*) GetDocument();
	if (pDoc != NULL)
	{
		// activate the first one
		POSITION posItem = pDoc->GetStartPosition();
		if (posItem != NULL)
		{
			CDocItem* pItem = pDoc->GetNextItem(posItem);

			// only if it's an Active document
			COleDocObjectItem *pDocObjectItem =
				DYNAMIC_DOWNCAST(COleDocObjectItem, pItem);

			if (pDocObjectItem != NULL)
			{
				pDocObjectItem->DoVerb(OLEIVERB_SHOW, this);
			}
		}
	}
}

void CMfc2View::OnDestroy()
{
	// Das Element bei Destruktion deaktivieren; dies ist wichtig,
	// wenn eine Teilansicht (Splitter View) verwendet wird.
   CView::OnDestroy();
   COleClientItem* pActiveItem = GetDocument()->GetInPlaceActiveItem(this);
   if (pActiveItem != NULL && pActiveItem->GetActiveView() == this)
   {
      pActiveItem->Deactivate();
      ASSERT(GetDocument()->GetInPlaceActiveItem(this) == NULL);
   }
}


/////////////////////////////////////////////////////////////////////////////
// OLE-Client-Unterst�tzung und -Befehle

BOOL CMfc2View::IsSelected(const CObject* pDocItem) const
{
	// Die nachfolgende Implementierung ist angemessen, wenn sich Ihre Auswahl nur aus
	//  CMfc2CntrItem-Objekten zusammensetzt. Zur Bearbeitung unterschiedlicher 
	//  Auswahlmechanismen sollte die hier gegebene Implementierung ersetzt werden.

	// ZU ERLEDIGEN: Implementieren Sie diese Funktion, die auf ein ausgew�hltes OLE-Client-Element testet

	return pDocItem == m_pSelection;
}

void CMfc2View::OnInsertObject()
{
	// Standarddialogfeld zum Einf�gen von Objekten aufrufen, um Infos abzufragen
	//  f�r neues CMfc2CntrItem-Objekt.
	COleInsertDialog dlg;
	if (dlg.DoModal(COleInsertDialog::DocObjectsOnly) != IDOK)
		return;

	BeginWaitCursor();

	CMfc2CntrItem* pItem = NULL;
	TRY
	{
		// Neues, mit diesem Dokument verbundenes Element erzeugen.
		CMfc2Doc* pDoc = GetDocument();
		ASSERT_VALID(pDoc);
		pItem = new CMfc2CntrItem(pDoc);
		ASSERT_VALID(pItem);

		// Element mit Dialogfelddaten initialisieren.
		if (!dlg.CreateItem(pItem))
			AfxThrowMemoryException();  // Beliebige Ausnahme erzeugen
		ASSERT_VALID(pItem);

		pItem->DoVerb(OLEIVERB_SHOW, this);

		ASSERT_VALID(pItem);

		// Die Gr��e wird hier willk�rlich auf die Gr��e
		//  des zuletzt eingef�gten Elements gesetzt.

		// ZU ERLEDIGEN: Implementieren Sie die Auswahl erneut in einer f�r Ihre Anwendung geeigneten Weise

		m_pSelection = pItem;   // set selection to last inserted item
		pDoc->UpdateAllViews(NULL);
	}
	CATCH(CException, e)
	{
		if (pItem != NULL)
		{
			ASSERT_VALID(pItem);
			pItem->Delete();
		}
		AfxMessageBox(IDP_FAILED_TO_CREATE);
	}
	END_CATCH

	EndWaitCursor();
}

// Der folgende Befehls-Handler stellt die Standardtastatur als
//  Benutzerschnittstelle zum Abbruch der direkten Bearbeitungssitzung zur Verf�gung. Hier
//  verursacht der Container (nicht der Server) die Deaktivierung.
void CMfc2View::OnCancelEditCntr()
{
	// Schlie�en aller direkt aktiven Elemente dieser Ansicht.
	COleClientItem* pActiveItem = GetDocument()->GetInPlaceActiveItem(this);
	if (pActiveItem != NULL)
	{
		pActiveItem->Close();
	}
	ASSERT(GetDocument()->GetInPlaceActiveItem(this) == NULL);
}

// F�r einen Container m�ssen OnSetFocus und OnSize speziell gehandhabt werden,
//  wenn ein Objekt direkt bearbeitet wird.
void CMfc2View::OnSetFocus(CWnd* pOldWnd)
{
	COleClientItem* pActiveItem = GetDocument()->GetInPlaceActiveItem(this);
	if (pActiveItem != NULL &&
		pActiveItem->GetItemState() == COleClientItem::activeUIState)
	{
		// dieses Element muss den Fokus erhalten, wenn es sich in der gleichen Ansicht befindet
		CWnd* pWnd = pActiveItem->GetInPlaceWindow();
		if (pWnd != NULL)
		{
			pWnd->SetFocus();   // kein Aufruf der Basisklasse
			return;
		}
	}

	CView::OnSetFocus(pOldWnd);
}

void CMfc2View::OnSize(UINT nType, int cx, int cy)
{
	CView::OnSize(nType, cx, cy);
	COleClientItem* pActiveItem = GetDocument()->GetInPlaceActiveItem(this);
	if (pActiveItem != NULL)
		pActiveItem->SetItemRects();
}

/////////////////////////////////////////////////////////////////////////////
// CMfc2View Diagnose

#ifdef _DEBUG
void CMfc2View::AssertValid() const
{
	CView::AssertValid();
}

void CMfc2View::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CMfc2Doc* CMfc2View::GetDocument() // Die endg�ltige (nicht zur Fehlersuche kompilierte) Version ist Inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CMfc2Doc)));
	return (CMfc2Doc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CMfc2View Nachrichten-Handler
