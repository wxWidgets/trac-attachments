

#include "stdafx.h"
#include "erroneous.h"

#define RESPONSE_STRING "I hope to see this one day..."

CErroneousServer::CErroneousServer(int Port,char *rem_addr)
{
 wxIPV4address *hAddr = new wxIPV4address;
 m_hSA = hAddr;
 m_iPort = Port;
 //if(rem_addr)m_szRemoteAddr = (wxString)rem_addr;
 hAddr->Service(Port);
 //hAddr->LocalHost();
 hAddr->AnyAddress();
 m_hSocketSrv = new wxSocketServer(*m_hSA);
 m_hSocketSrv->SetEventHandler(*this);
 m_hSocketSrv->SetNotify(wxSOCKET_INPUT_FLAG|wxSOCKET_LOST_FLAG|wxSOCKET_CONNECTION_FLAG);
}


CErroneousServer::~CErroneousServer()
{

}


void CErroneousServer::Startup()
{
 m_hSocketSrv->Notify(TRUE);

}





void CErroneousServer::Shutdown()
{
	this->m_hSocketSrv->Close();
}


bool CErroneousServer::ProcessEvent(wxEvent& event)
{

	

	if(wxEVT_SOCKET!=event.GetEventType())return 0;
	//wxSocketEvent sck_evt;
	switch(((wxSocketEvent*)&event)->GetSocketEvent()){
		case wxSOCKET_INPUT : {
				return 1;
			}break;
		case wxSOCKET_LOST  : {
				return 1;
			}break;
		case wxSOCKET_CONNECTION : {
					this->m_hSocket = this->m_hSocketSrv->Accept(TRUE);
					this->m_hSocket->Write(RESPONSE_STRING,strlen(RESPONSE_STRING));
				return 1;
			}break;
		default:
			return 0;
	}
 return 0;
}

