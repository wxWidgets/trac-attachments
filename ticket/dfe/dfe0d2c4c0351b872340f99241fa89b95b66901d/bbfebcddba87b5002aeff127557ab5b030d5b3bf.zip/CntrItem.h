// CntrItem.h : Schnittstelle der Klasse CMfc2CntrItem
//

#if !defined(AFX_CNTRITEM_H__C761655E_6A42_4A9B_87C0_5F07B4E8929B__INCLUDED_)
#define AFX_CNTRITEM_H__C761655E_6A42_4A9B_87C0_5F07B4E8929B__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CMfc2Doc;
class CMfc2View;

class CMfc2CntrItem : public COleDocObjectItem
{
	DECLARE_SERIAL(CMfc2CntrItem)

// Konstruktoren
public:
	CMfc2CntrItem(CMfc2Doc* pContainer = NULL);
		// Hinweis: pContainer darf auch NULL sein, um IMPLEMENT_SERIALIZE zuzulassen.
		//  IMPLEMENT_SERIALIZE verlangt, dass die Klasse einen Konstruktor mit
		//  null Argumenten besitzt. Normalerweise werden OLE-Elemente mit einem 
		//  Dokumentzeiger konstruiert, der ungleich Null ist.

// Attribute
public:
	CMfc2Doc* GetDocument()
		{ return (CMfc2Doc*)COleDocObjectItem::GetDocument(); }
	CMfc2View* GetActiveView()
		{ return (CMfc2View*)COleDocObjectItem::GetActiveView(); }

	// Vom Klassenassistenten generierte �berladungen virtueller Funktionen
	//{{AFX_VIRTUAL(CMfc2CntrItem)
	public:
	virtual void OnChange(OLE_NOTIFICATION wNotification, DWORD dwParam);
	virtual void OnActivate();
	protected:
	virtual void OnDeactivateUI(BOOL bUndoable);
	virtual BOOL OnChangeItemPosition(const CRect& rectPos);
	//}}AFX_VIRTUAL

// Implementierung
public:
	~CMfc2CntrItem();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif
	virtual void Serialize(CArchive& ar);
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ f�gt unmittelbar vor der vorhergehenden Zeile zus�tzliche Deklarationen ein.

#endif // !defined(AFX_CNTRITEM_H__C761655E_6A42_4A9B_87C0_5F07B4E8929B__INCLUDED_)
