// mfc2View.h : Schnittstelle der Klasse CMfc2View
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_MFC2VIEW_H__D7575D96_1F46_4170_A989_1C7BA6A58ECF__INCLUDED_)
#define AFX_MFC2VIEW_H__D7575D96_1F46_4170_A989_1C7BA6A58ECF__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CMfc2CntrItem;

class CMfc2View : public CView
{
protected: // Nur aus Serialisierung erzeugen
	CMfc2View();
	DECLARE_DYNCREATE(CMfc2View)

// Attribute
public:
	CMfc2Doc* GetDocument();
	// m_pSelection enth�lt die Auswahl des aktuellen CMfc2CntrItem-Objekts.
	// F�r viele Anwendungen ist eine derartige Member-Variable nicht angemessen, um
	//  z.B. eine Mehrfachauswahl oder eine Auswahl von Objekten zu repr�sentieren,
	//  die keine CMfc2CntrItem-Objekte sind. Dieser Auswahlmechanismus
	//  dient nur dazu, Ihnen bei den ersten Schritten zu helfen.

	// ZU ERLEDIGEN: Ersetzen Sie diesen Auswahlmechanismus durch einen f�r Ihre Anwendung geeigneten.
	CMfc2CntrItem* m_pSelection;

// Operationen
public:

// �berladungen
	// Vom Klassenassistenten generierte �berladungen virtueller Funktionen
	//{{AFX_VIRTUAL(CMfc2View)
	public:
	virtual void OnDraw(CDC* pDC);  // �berladen zum Zeichnen dieser Ansicht
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	protected:
	virtual void OnInitialUpdate(); // das erste mal nach der Konstruktion aufgerufen
	virtual BOOL IsSelected(const CObject* pDocItem) const;// Container-Unterst�tzung
	//}}AFX_VIRTUAL

// Implementierung
public:
	virtual ~CMfc2View();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generierte Message-Map-Funktionen
protected:
	//{{AFX_MSG(CMfc2View)
		// HINWEIS - An dieser Stelle werden Member-Funktionen vom Klassen-Assistenten eingef�gt und entfernt.
		//    Innerhalb dieser generierten Quelltextabschnitte NICHTS VER�NDERN!
	afx_msg void OnDestroy();
	afx_msg void OnSetFocus(CWnd* pOldWnd);
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnInsertObject();
	afx_msg void OnCancelEditCntr();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // Testversion in mfc2View.cpp
inline CMfc2Doc* CMfc2View::GetDocument()
   { return (CMfc2Doc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ f�gt unmittelbar vor der vorhergehenden Zeile zus�tzliche Deklarationen ein.

#endif // !defined(AFX_MFC2VIEW_H__D7575D96_1F46_4170_A989_1C7BA6A58ECF__INCLUDED_)
