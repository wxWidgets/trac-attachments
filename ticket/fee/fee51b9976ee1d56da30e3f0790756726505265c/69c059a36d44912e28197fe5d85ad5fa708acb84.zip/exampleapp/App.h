#ifndef MYAPP_H_INCLUDED
#define MYAPP_H_INCLUDED

#if defined(_MSC_VER) && (_MSC_VER >= 1020)
#   pragma once
#endif

#include <wx/app.h>

namespace CM
{

class App : public wxApp
{
public:
   bool OnInit();
};

} // namespace

DECLARE_APP(CM::App);

#endif // MYAPP_H_INCLUDED
