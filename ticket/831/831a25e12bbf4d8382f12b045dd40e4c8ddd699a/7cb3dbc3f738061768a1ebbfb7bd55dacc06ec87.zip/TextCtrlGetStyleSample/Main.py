###########################
## Import
###########################
import sys, os
import wx, wx.xrc as xrc

###########################
## Application
###########################

class MainFrame(wx.Frame):
    def __init__(self, parent, title="Test", pos=(150,150),
                 size=(600,400), style=wx.DEFAULT_FRAME_STYLE):
        wx.Frame.__init__(self, parent, -1, title, pos, size, style)

        # Load Publish Section GUI from xml resource file
        res = xrc.XmlResource("Test.res")
        panel = res.LoadPanel(self, "Panel")
        panel.SetSize((400, 400))

        # Put panel in a sizer to have the notebook expanded in this panel
        sizer = wx.BoxSizer()
        sizer.Add(panel, 1, wx.EXPAND|wx.ALL)
        self.SetSizer(sizer)

        self.contentTextCtrl   = xrc.XRCCTRL(panel, "TextCtrl")
        self.contentTextCtrl.SetDefaultStyle(wx.TextAttr(wx.BLACK, wx.NullColour, self.GetFont()))
        wx.EVT_TOOL(self, xrc.XRCID("FontToolButton"), self.OnFontToolButtonClick)
        wx.EVT_TEXT(self, xrc.XRCID("TextCtrl"), self.OnTextChanged)

    def OnFontToolButtonClick(self, event):

        textCtrl = self.contentTextCtrl

        insertionPoint = textCtrl.GetInsertionPoint()
        lastPoint = textCtrl.GetLastPosition()

        data = wx.FontData()
        data.EnableEffects(True)
        textAttr = wx.TextAttr()
        if insertionPoint == lastPoint:
            textAttr = textCtrl.GetDefaultStyle()
        else:
            ##! Wrong size
            textCtrl.GetStyle(insertionPoint, textAttr)
            ##! BUG Must divide size by 15
            font = textAttr.GetFont()
            font.SetPointSize(textAttr.GetFont().GetPointSize() / 15)
            textAttr.SetFont(font)

        data.SetColour(textAttr.GetTextColour())
        data.SetInitialFont(textAttr.GetFont())
        fontDialog = wx.FontDialog(textCtrl, data)
        if fontDialog.ShowModal() == wx.ID_OK:
            data = fontDialog.GetFontData()
            textAttr.SetTextColour(data.GetColour())
            textAttr.SetFont(data.GetChosenFont())
            if insertionPoint == lastPoint:
                textCtrl.SetDefaultStyle(textAttr)
            else:
                (startSelection, endSelection) = textCtrl.GetSelection()
                textCtrl.SetStyle(startSelection, endSelection, textAttr)
        fontDialog.Destroy()

    def OnTextChanged(self, event):
        textAttr = wx.TextAttr()
        ##! BUG
        self.contentTextCtrl.GetStyle(0, textAttr)

class MainApplication(wx.App):
    def OnInit(self):
        frame = MainFrame(None, "Test")
        self.SetTopWindow(frame)
        frame.Show(True)
        return True

class Application:

    def __init__(self):
        pass

    ## Run the whole damn thing!
    def Run(self):
        app = MainApplication(redirect=False)
        app.MainLoop()

###########################
## Launch
###########################

instance = Application()
instance.Run()
