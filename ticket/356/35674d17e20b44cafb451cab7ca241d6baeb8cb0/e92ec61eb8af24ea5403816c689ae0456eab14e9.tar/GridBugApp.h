/***************************************************************
 * Name:      GridBugApp.h
 * Purpose:   Defines Application Class
 * Author:    Michael McCarty (service@technalysis.com)
 * Created:   2008-05-13
 * Copyright: Michael McCarty (www.technalysis.com)
 * License:
 **************************************************************/

#ifndef GRIDBUGAPP_H
#define GRIDBUGAPP_H

#include <wx/app.h>

class GridBugApp : public wxApp
{
    public:
        virtual bool OnInit();
};

#endif // GRIDBUGAPP_H
