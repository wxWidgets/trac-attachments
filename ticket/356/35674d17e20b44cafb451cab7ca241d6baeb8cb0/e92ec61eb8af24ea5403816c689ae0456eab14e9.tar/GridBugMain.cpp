/***************************************************************
 * Name:      GridBugMain.cpp
 * Purpose:   Code for Application Frame
 * Author:    Michael McCarty (service@technalysis.com)
 * Created:   2008-05-13
 * Copyright: Michael McCarty (www.technalysis.com)
 * License:
 **************************************************************/

#include "wx_pch.h"
#include "GridBugMain.h"
#include <wx/msgdlg.h>

//(*InternalHeaders(GridBugDialog)
#include <wx/intl.h>
#include <wx/string.h>
//*)

//helper functions
enum wxbuildinfoformat {
    short_f, long_f };

wxString wxbuildinfo(wxbuildinfoformat format)
{
    wxString wxbuild(wxVERSION_STRING);

    if (format == long_f )
    {
#if defined(__WXMSW__)
        wxbuild << _T("-Windows");
#elif defined(__UNIX__)
        wxbuild << _T("-Linux");
#endif

#if wxUSE_UNICODE
        wxbuild << _T("-Unicode build");
#else
        wxbuild << _T("-ANSI build");
#endif // wxUSE_UNICODE
    }

    return wxbuild;
}

//(*IdInit(GridBugDialog)
const long GridBugDialog::m_idLeftGrid = wxNewId();
const long GridBugDialog::m_idRightGrid = wxNewId();
//*)

BEGIN_EVENT_TABLE(GridBugDialog,wxDialog)
    //(*EventTable(GridBugDialog)
    //*)
END_EVENT_TABLE()

GridBugDialog::GridBugDialog(wxWindow* parent,wxWindowID id)
{
    //(*Initialize(GridBugDialog)
    Create(parent, id, _("wxWidgets app"), wxDefaultPosition, wxDefaultSize, wxDEFAULT_DIALOG_STYLE, _T("id"));
    m_TopSizerFGS = new wxFlexGridSizer(1, 2, 0, 0);
    m_LeftGrid = new wxGrid(this, m_idLeftGrid, wxDefaultPosition, wxDefaultSize, 0, _T("m_idLeftGrid"));
    m_LeftGrid->CreateGrid(5,1);
    m_LeftGrid->SetMargins(0,0);
    m_LeftGrid->AutoSize();
    for(int i = 0; i < 5; i++)
       m_LeftGrid->SetRowLabelValue(i, wxString::Format("Node %2d", i + 1));

    m_TopSizerFGS->Add(m_LeftGrid, 1, wxALL|wxALIGN_LEFT|wxALIGN_TOP, 5);
    m_RightGrid = new wxGrid(this, m_idRightGrid, wxDefaultPosition, wxDefaultSize, 0, _T("m_idRightGrid"));
    m_RightGrid->CreateGrid(8,4);
    m_RightGrid->SetRowLabelSize(0);

    m_RightGrid->SetColLabelValue(0, "Element");
    m_RightGrid->SetColLabelValue(1, "Value");
    m_RightGrid->SetColLabelValue(2, "Element");
    m_RightGrid->SetColLabelValue(3, "Value");

    m_RightGrid->SetMargins(0,0);

    wxGridCellAttr * m_GCARightGrid = new wxGridCellAttr();
    m_GCARightGrid->SetReadOnly(false);
    m_GCARightGrid->SetEditor(new wxGridCellFloatEditor);
    m_GCARightGrid->SetAlignment(wxALIGN_RIGHT, wxALIGN_CENTRE_VERTICAL);
    m_RightGrid->SetColAttr(1, m_GCARightGrid);
    m_RightGrid->SetColAttr(3, m_GCARightGrid);

    wxGridCellAttr * GCAReadOnly = new wxGridCellAttr();
    GCAReadOnly->SetReadOnly(true);
    GCAReadOnly->SetAlignment(wxALIGN_LEFT, wxALIGN_CENTER_VERTICAL);
    m_RightGrid->SetColAttr(0, GCAReadOnly);
    m_RightGrid->SetColAttr(2, GCAReadOnly);

    m_RightGrid->EnableDragGridSize(false);
    m_RightGrid->ShowCellEditControl();
    m_RightGrid->AutoSize();
    m_TopSizerFGS->Add(m_RightGrid, 1, wxALL|wxALIGN_LEFT|wxALIGN_TOP, 5);
    SetSizer(m_TopSizerFGS);
    m_TopSizerFGS->Fit(this);
    m_TopSizerFGS->SetSizeHints(this);

    Connect(m_idLeftGrid,wxEVT_GRID_CELL_CHANGE,(wxObjectEventFunction)&GridBugDialog::OnLeftGridCellChange);
    Connect(m_idRightGrid,wxEVT_GRID_CELL_CHANGE,(wxObjectEventFunction)&GridBugDialog::OnRightGridCellChange);
    Connect(wxID_ANY,wxEVT_PAINT,(wxObjectEventFunction)&GridBugDialog::OnPaint);
    //*)
}

GridBugDialog::~GridBugDialog()
{
    //(*Destroy(GridBugDialog)
    //*)
}

void GridBugDialog::OnQuit(wxCommandEvent& event)
{
    Close();
}

void GridBugDialog::OnAbout(wxCommandEvent& event)
{
    wxString msg = wxbuildinfo(long_f);
    wxMessageBox(msg, _("Welcome to..."));
}

void GridBugDialog::OnLeftGridCellChange(wxGridEvent& event)
{
	//this->GetEventHandler()->SetEvtHandlerEnabled(false);
	wxClientDC dc(this);
	wxSize size = dc.GetTextExtent(m_LeftGrid->GetCellValue(event.GetRow(), event.GetCol()));
	int col = event.GetCol();
	int colwidth = m_LeftGrid->GetColSize(col);
	if(size.GetWidth()+20 > colwidth)
	{
		m_LeftGrid->SetColSize(event.GetCol(), size.GetWidth()+20);
		m_LeftGrid->SetColMinimalWidth(event.GetCol(), size.GetWidth()+20);
		m_LeftGrid->AutoSize();
		m_LeftGrid->ForceRefresh();
		GetSizer()->SetItemMinSize( m_LeftGrid, -1, -1 );
		Layout();
		GetSizer()->Fit( this );
	}
	//this->GetEventHandler()->SetEvtHandlerEnabled(true);
}

void GridBugDialog::OnRightGridCellChange(wxGridEvent& event)
{
	//this->GetEventHandler()->SetEvtHandlerEnabled(false);
	wxClientDC dc(this);
	wxSize size = dc.GetTextExtent(m_RightGrid->GetCellValue(event.GetRow(), event.GetCol()));
	int col = event.GetCol();
	int colwidth = m_RightGrid->GetColSize(col);
	if(size.GetWidth()+20 > colwidth)
	{
		m_RightGrid->SetColSize(event.GetCol(), size.GetWidth()+20);
		m_RightGrid->SetColMinimalWidth(event.GetCol(), size.GetWidth()+20);
		m_RightGrid->AutoSize();
		m_RightGrid->ForceRefresh();
		GetSizer()->SetItemMinSize( m_RightGrid, -1, -1 );
		Layout();
		GetSizer()->Fit( this );
	}
	//this->GetEventHandler()->SetEvtHandlerEnabled(true);
}

void GridBugDialog::OnPaint(wxPaintEvent& event)
{
	wxPaintDC dc(this);
	SetSizer(m_TopSizerFGS);
	m_TopSizerFGS->Fit(this);
	m_TopSizerFGS->SetSizeHints(this);
}
