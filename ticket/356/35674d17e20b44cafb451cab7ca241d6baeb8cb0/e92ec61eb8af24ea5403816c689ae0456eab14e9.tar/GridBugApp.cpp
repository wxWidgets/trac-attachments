/***************************************************************
 * Name:      GridBugApp.cpp
 * Purpose:   Code for Application Class
 * Author:    Michael McCarty (service@technalysis.com)
 * Created:   2008-05-13
 * Copyright: Michael McCarty (www.technalysis.com)
 * License:
 **************************************************************/

#include "wx_pch.h"
#include "GridBugApp.h"

//(*AppHeaders
#include "GridBugMain.h"
#include <wx/image.h>
//*)

IMPLEMENT_APP(GridBugApp);

bool GridBugApp::OnInit()
{
    //(*AppInitialize
    bool wxsOK = true;
    wxInitAllImageHandlers();
    if ( wxsOK )
    {
    GridBugDialog Dlg(0);
    SetTopWindow(&Dlg);
    Dlg.ShowModal();
    wxsOK = false;
    }
    //*)
    return wxsOK;

}
