/***************************************************************
 * Name:      GridBugMain.h
 * Purpose:   Defines Application Frame
 * Author:    Michael McCarty (service@technalysis.com)
 * Created:   2008-05-13
 * Copyright: Michael McCarty (www.technalysis.com)
 * License:
 **************************************************************/

#ifndef GRIDBUGMAIN_H
#define GRIDBUGMAIN_H

//(*Headers(GridBugDialog)
#include <wx/sizer.h>
#include <wx/grid.h>
#include <wx/dialog.h>
//*)

class GridBugDialog: public wxDialog
{
    public:

        GridBugDialog(wxWindow* parent,wxWindowID id = -1);
        virtual ~GridBugDialog();

    private:

        //(*Handlers(GridBugDialog)
        void OnQuit(wxCommandEvent& event);
        void OnAbout(wxCommandEvent& event);
        void OnLeftGridCellChange(wxGridEvent& event);
        void OnRightGridCellChange(wxGridEvent& event);
        void OnPaint(wxPaintEvent& event);
        //*)

        //(*Identifiers(GridBugDialog)
        static const long m_idLeftGrid;
        static const long m_idRightGrid;
        //*)

        //(*Declarations(GridBugDialog)
        wxGrid* m_LeftGrid;
        wxFlexGridSizer* m_TopSizerFGS;
        wxGrid* m_RightGrid;
        //*)

        DECLARE_EVENT_TABLE()
};

#endif // GRIDBUGMAIN_H
