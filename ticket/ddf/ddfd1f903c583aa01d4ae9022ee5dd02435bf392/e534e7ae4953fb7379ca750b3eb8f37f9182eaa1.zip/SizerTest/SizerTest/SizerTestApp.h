#if !defined(H_SIZER_TEST_APP)
#define H_SIZER_TEST_APP

#include <wx/app.h>

class SizerTestApp : public wxApp
{
public:
	virtual bool OnInit();
};

DECLARE_APP(SizerTestApp);

#endif