#if !defined(H_SIZER_TEST)
#define H_SIZER_TEST

#include <wx/frame.h>

class SizerTestFrame : public wxFrame
{
public:
	SizerTestFrame();

private:
	void createChildControls( wxWindow *parent, 
							  size_t depth, 
							  wxWindow *&first,
							  wxWindow *&last );
};


#endif