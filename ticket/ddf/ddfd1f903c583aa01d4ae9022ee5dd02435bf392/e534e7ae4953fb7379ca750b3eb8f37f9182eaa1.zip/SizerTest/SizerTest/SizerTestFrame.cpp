#include "SizerTestFrame.h"

#include <wx/panel.h>
#include <wx/sizer.h>
#include <wx/xrc/xmlres.h>

#include "SizerTestPanel.h"

SizerTestFrame::SizerTestFrame() :
	wxFrame( NULL, wxID_ANY, wxEmptyString )
{
	wxWindow *topPanel;
	wxWindow *lastChild;
	createChildControls( this, 10, topPanel, lastChild );

	SizerTestPanel *sizerTest = new SizerTestPanel( lastChild );

	wxSizer *childSizer = new wxBoxSizer( wxVERTICAL );
	childSizer->Add( sizerTest, 1, wxEXPAND );
	lastChild->SetSizer( childSizer );

	wxSizer *frameSizer = new wxBoxSizer( wxVERTICAL );
	frameSizer->Add( topPanel, 1, wxEXPAND );
	SetSizerAndFit( frameSizer );

}

void SizerTestFrame::createChildControls( wxWindow *parent, 
										   size_t depth,
										   wxWindow *&first,
										   wxWindow *&last )
{
	first = NULL;
	last = NULL;

	for ( size_t i = 0; i != depth; ++i )
	{
		wxPanel *current = NULL;

		if ( first == NULL )
		{
			 current = new wxPanel( parent );
			 first = current;
		}
		else
		{
			current = new wxPanel( last );

			wxSizer *childSizer = new wxBoxSizer( wxVERTICAL );
			childSizer->Add( current, 1, wxEXPAND );
			last->SetSizer( childSizer );
		}

		last = current;
	}
}