#include "SizerTestPanel.h"

#include <wx/xrc/xmlres.h>
#include <wx/dataview.h>

namespace
{
	class TestModel : public wxDataViewListModel
	{
	public:
		virtual unsigned int GetNumberOfRows()
		{
			return 10;
		}

		virtual unsigned int GetNumberOfCols()
		{
			return 2;
		}

		// return type as reported by wxVariant
		virtual wxString GetColType( unsigned int col )
		{
			return ( col == 0 ? wxT("long") : wxT("string") );
		}

		// get value into a wxVariant
		void GetValue( wxVariant &variant, unsigned int col, unsigned int row )
		{
			if ( col == 0 )
			{
				variant = static_cast<long>( col );
			}
			else
			{
				variant = wxT("Test");
			}
		}

		bool SetValue( wxVariant &variant, unsigned int col, unsigned int row )
		{
			return false;
		}
	};
}

SizerTestPanel::SizerTestPanel( wxWindow *parent )
{
	wxXmlResource *xmlRes = wxXmlResource::Get();
	xmlRes->LoadPanel( this, parent, wxT("ID_SIZER_TEST_PANEL") );

	wxDataViewCtrl *dataViewCtrl = new wxDataViewCtrl( this, wxID_ANY );
	dataViewCtrl->AssociateModel( new TestModel );
	dataViewCtrl->AppendTextColumn( wxT("Column 1"), 0 );
	dataViewCtrl->AppendTextColumn( wxT("Column 2"), 1 );

	xmlRes->AttachUnknownControl( wxT("ID_DATA_VIEW"), dataViewCtrl );

	Layout();
}