#if !defined(H_SIZER_TEST_PANEL)
#define H_SIZER_TEST_PANEL

#include <wx/panel.h>


class SizerTestPanel : public wxPanel
{
public:
	SizerTestPanel( wxWindow *parent );
};


#endif