#include "SizerTestApp.h"
#include "SizerTestFrame.h"

#include <wx/xrc/xmlres.h>


void initXMLResources();

IMPLEMENT_APP(SizerTestApp)

bool SizerTestApp::OnInit()
{
	bool isOk = wxApp::OnInit();

	if ( isOk )
	{
		wxXmlResource *xmlRes = wxXmlResource::Get();
		xmlRes->InitAllHandlers();

		initXMLResources();

		SizerTestFrame *frame = new SizerTestFrame();
		frame->Show();
	}

	return isOk;
}