'''
+-------------------------------------------------------------------+
| A Python module           Created by Bruce vanNorman on 15.Aug.10 |
| purpose: to provide global data and process for LWA backup utility|
+-------------------------------------------------------------------+
'''
import logging, logging.handlers, sys, thread, traceback, time, wx
## log file setup
TheLock = thread.allocate_lock()
Logger = None
Debug = logging.DEBUG
Info =  logging.INFO
Warn =  logging.WARN
Error = logging.ERROR
# --- thread control info -------------------------------------------
GuiRunning = False
BackupRunning = False
BackupInfoOnly = False
BackupSw = False
StopBackupSw = False
GuiStopping = False
TheConfig = None
TheSection = ''
SourcePath = ''
TargetPath = ''
SourceFileCount = 0
SourceSizeKb = 0
Version = 'undefined'


def GuiMsgCallback(Msg):
  print 'call back not supplied'
  sys.exit()
  
def MsgToGui(Msg):
  global GuiRunning
  #print '>>>' + Msg
  if GuiRunning:
    wx.CallAfter(GuiMsgCallback, Msg)
  else:
    Log('Msg to gui & not running')
    Log(Msg)
    
def GuiWakeup():
  #wx.WakeUpIdle()
  #wx.Yield()
  time.sleep(0.001)
  
def LogSetup (LogFileName, Level):
  global Logger
  LOG_FILENAME = 'backup.log'
  Logger = logging.getLogger('TheLogger')
  Logger.setLevel(Level)
  hLogger = logging.handlers.RotatingFileHandler(
    LogFileName, maxBytes = 10000, backupCount = 2)
  Logger.addHandler(hLogger)

def LogException(Msg):
  global TheLock
  TheLock.acquire()
  Log(Msg)
  # --- clever code copied from web ----------------- BvN 29.Jun.09 -
  Cla, Exc, Trbk = sys.exc_info()
  ExcTb = []
  ExcName = Cla.__name__
  try:
    ExcArgs = Exc.__dict__["args"]
  except KeyError:
    ExcArgs = "<no args>"
    ExcTb = traceback.format_tb(Trbk, 5)
  Log('Error: ' + ExcName)
  Log('Arguments: ' + str(ExcArgs))
  Log('At:')
  #for Line in ExcTb:
  #  TokenList = Line.split('\n')
  #  for Token in TokenList:
  #    Log('  %s'%Token.strip())
  for Line in ExcTb:
    First, Trash, Last = Line.partition('\n')
    if len(First): Log('  %s'%First.strip())
    if len(Last):  Log('    %s'%Last.strip())
    
  for I in range(3):
    Log('  %s'%sys.exc_info()[I])
  # --- end of clever code ------------------------------------------
  TheLock.release()
  
def LogDebug(Msg):
  global logger, MsgQ, TheLock
  TheLock.acquire()
  Logger.debug('DBG: ' + Msg)
  TheLock.release()

def LogError(Msg):
  global logger, MsgQ, TheLock
  TheLock.acquire()
  Logger.error('ERR: ' + Msg)
  TheLock.release()

def LogWarn(Msg):
  global logger, MsgQ, TheLock
  TheLock.acquire()
  Logger.warn('WRN: ' + Msg)
  TheLock.release()

def LogInfo(Msg):
  global logger, MsgQ, TheLock
  TheLock.acquire()
  Logger.info('INF: ' + Msg)
  TheLock.release()

def Log(Msg):
  global logger, MsgQ
  Logger.critical('***: ' + Msg)
pass
