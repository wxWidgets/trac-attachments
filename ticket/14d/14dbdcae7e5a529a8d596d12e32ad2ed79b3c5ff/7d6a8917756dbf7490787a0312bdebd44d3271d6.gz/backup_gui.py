# ================================================================= #
# 24.Aug.2010 - brought into complience with wxPython               #
#               long running task standards                         #
# ================================================================= #
import wx, backup_wx, backup_worker, os, time, thread, traceback
import backup_global as gbl
import ConfigParser, sys, tarfile, fnmatch
import datetime, shutil, logging, logging.handlers

TheApp = None
TheFrame = None
TheChoice = None
#TheGauge = None
#TheText = None
StatusList = []
ToolbarVisible = False

## === toolbar events ===============================================
def StartBackup(Event):
  global TheChoice, TheFrame
  gbl.TheSection = TheChoice.GetStringSelection()
  Status('backup of [%s] started'%gbl.TheSection)
  gbl.SourcePath = gbl.TheConfig.get(gbl.TheSection, 'source')
  gbl.TargetPath = gbl.TheConfig.get(gbl.TheSection, 'target')
  if os.path.isdir(gbl.SourcePath):
    Status('Source %s exists'%gbl.SourcePath)
  if not os.access(gbl.SourcePath, os.R_OK):
    Status('Source %s not readable'%gbl.SourcePath)
  elif os.path.isdir(gbl.TargetPath):
    if os.access(gbl.TargetPath, os.W_OK):
      CurrDir = os.getcwd()
      os.chdir(gbl.SourcePath)
      gbl.BackupInfoOnly = False
      gbl.BackupSw = True
      time.sleep(1)
      '''
      while gbl.BackupSw:
        time.sleep(2)
      os.chdir(CurrDir)
      '''
    else:
      Status('Target %s is not writable'%gbl.TargetPath)
  else: Status('Target %s does not exist'%gbl.TargetPath)

def QueryBackup(Event):
  global TheChoice, TheFrame
  Status('---------')
  gbl.TheSection = TheChoice.GetStringSelection()
  gbl.SourcePath = gbl.TheConfig.get(gbl.TheSection, 'source')
  gbl.TargetPath = gbl.TheConfig.get(gbl.TheSection, 'target')
  if os.path.isdir(gbl.SourcePath):
    Status('Source %s exists'%gbl.SourcePath)
  if not os.access(gbl.SourcePath, os.R_OK):
    Status('Source %s not readable'%gbl.SourcePath)
  if os.path.isdir(gbl.TargetPath):
    if os.access(gbl.TargetPath, os.W_OK):
      TargetBackupList = os.listdir(gbl.TargetPath)
      TargetBackupList.sort()
      Status('backups:')
      for TargetBackup in TargetBackupList:
        if len(TargetBackup) == 15:
          if TargetBackup[8:15] == '.tar.gz':
            if TargetBackup[0:8].isdigit():
              Status('- %s %s %s %imB'%(
                TargetBackup[0:4], TargetBackup[4:6], TargetBackup[6:8],
                (os.path.getsize(os.path.join(gbl.TargetPath, TargetBackup)) / (1024 * 1024))
                ))
      os.chdir(gbl.SourcePath)
      gbl.BackupInfoOnly = True
      gbl.BackupSw = True
      time.sleep(1)
    else:
      Status('Target %s is not writable'%gbl.TargetPath)
  else: Status('Target %s does not exist'%gbl.TargetPath)

def Exit(Event):
  global TheFrame, TheApp
  gbl.GuiStopping = True
  backup_worker.Stop()
  if TheApp.Pending():
    gbl.Log('GUI events pending')
    wx.CallAfter(Exit, Event)
  else:
    TheFrame.Destroy()

def StopBackup(Event):
  if gbl.BackupSw:
    gbl.StopBackupSw = True
    Status('backup requested to stop')

def Status(Msg):
  global StatusList, TheFrame
  gbl.LogInfo(Msg)
  StatusList.append(Msg)
  while len(StatusList) > 29:
    StatusList.pop(0)
  String = ''
  for LclMsg in StatusList:
    String += LclMsg + '\n'
  TheFrame.text_ctrl_status.ChangeValue(String[:-1])

def CheckStatus(Event):
  global TheFrame, ToolbarVisible
  if gbl.BackupSw or gbl.GuiStopping:
    if ToolbarVisible:
      for I in range(1, 4):
        TheFrame.toolbar.EnableTool(I, False)
      ToolbarVisible = False
      TheFrame.toolbar.EnableTool(4, True)
  elif not ToolbarVisible:
    for I in range(1, 4):
      TheFrame.toolbar.EnableTool(I, True)
    ToolbarVisible = True
    TheFrame.toolbar.EnableTool(4, False)

def BackupSelect(Event):
  global TheChoice
  gbl.TheSection = TheChoice.GetStringSelection()
  OptionList = gbl.TheConfig.options(gbl.TheSection)
  Status('section %s ----------'%gbl.TheSection)
  for Option in OptionList:
    Status('  option %s ---'%Option)
    Value = gbl.TheConfig.get(gbl.TheSection, Option)
    Tokens = Value.split(',')
    Status('    =%s'%Value)
    for Name in Tokens:
      Status('      =%s'%Name.strip())
 
def RemoveFile(FileName):
  Logging.info('removing %s'%FileName)
  if os.path.isfile(FileName): os.remove(FileName)
  if os.path.isfile(FileName):
    status('cannot remove %s'%FileName)


def Run(Dummy):
  global TheApp, TheFrame, TheChoice
  # TheGauge, TheText, MediaDict, TheFileName
  # global TheTree, TheRoot
  gbl.Log('gui started')
  TheApp = wx.PySimpleApp(0)
  wx.InitAllImageHandlers()
  TheFrame = backup_wx.MyFrame(None, -1, gbl.Version)
  TheApp.SetTopWindow(TheFrame)
  TheApp.SetExitOnFrameDelete(True)
  ## ===
  TheChoice = TheFrame.choice_backup
  BackupList = gbl.TheConfig.sections()
  for BackupChoice in BackupList:
    TheChoice.Append(BackupChoice, 1)
  TheChoice.SetSelection(0)
  ## ===
  #TheFrame.Bind(wx.EVT_CHOICE, BackupSelect,    TheChoice)
  #TheFrame.toolbar.EnableTool(id, boolean)
  TheFrame.Bind(wx.EVT_IDLE, CheckStatus)
  TheFrame.Bind(wx.EVT_TOOL, StartBackup, id=1)
  TheFrame.Bind(wx.EVT_TOOL, QueryBackup, id=2)
  TheFrame.Bind(wx.EVT_TOOL, Exit,        id=3)
  TheFrame.Bind(wx.EVT_TOOL, StopBackup,  id=4)
  ## ===
  Status(gbl.Version)
  TheFrame.Show()
  gbl.GuiMsgCallback = Status
  gbl.GuiRunning = True
  TheApp.MainLoop()
  gbl.Log("gui ended")
  gbl.Log('-----------------------------')
  gbl.GuiRunning = False

def Start():
  try:
    gbl.GuiStopping = False
    thread.start_new_thread(Run, (0,))
    while not gbl.GuiRunning:
      time.sleep(1)
  except:
    gbl.LogException('gui thread failed to start')
    gbl.GuiRunning = False

def Stop():
  global TheApp, TheFrame
  if TheApp <> None:
    gbl.GuiStopping = True
    time.sleep(10)
    wx.CallAfter(Exit, None)
  while gbl.GuiRunning:
    time.sleep(2)

pass
