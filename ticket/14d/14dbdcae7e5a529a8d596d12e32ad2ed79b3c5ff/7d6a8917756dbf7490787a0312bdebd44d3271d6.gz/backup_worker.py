# ================================================================= #
# uses tar and gzip                                                 #
# 24.Aug.2010 - brought into complience with wxPython               #
#               long running task standards                         #
# ================================================================= #
import backup_global as gbl
import os, time, thread, traceback
import ConfigParser, sys, tarfile, fnmatch
import datetime, shutil

StopThread = False
SizeGuess = 0
FileGuess = 0
TimeMarker = 0
INTERVAL = 60

## === begin child threads ==========================================
def Run(Dummy):
  global StopThread, oTarFile, ExclusionList, SizeGuess, FileGuess
  global TimeMarker, INTERVAL
  gbl.BackupRunning = True
  gbl.Log('backup running')
  while True:
    if StopThread: break
    if gbl.BackupSw:
      try:
        gbl.LogInfo('starting backup')
        StartTime = time.time() + INTERVAL
        TimeMarker = StartTime
        Errors = 0
        gbl.SourceFileCount = 0
        gbl.SourceSizeKb = 0
        TempDir = ''
        if gbl.TheConfig.has_option(gbl.TheSection, 'workarea'):
          TempDir = os.path.normcase(gbl.TheConfig.get(gbl.TheSection, 'workarea'))
        SourcePath = os.path.normcase(gbl.SourcePath)
        TargetPath = os.path.normcase(gbl.TargetPath)
        
        ExclusionList = []
        if gbl.TheConfig.has_option(gbl.TheSection, 'exclude'):
          Tokens = gbl.TheConfig.get(gbl.TheSection, 'exclude').split(',')
          for Token in Tokens:
            ExclusionList.append(Token.strip())
        gbl.LogDebug('exclusion list= %s'%str(ExclusionList))

        InclusionList = ['./']
        if gbl.TheConfig.has_option(gbl.TheSection, 'include'):
          Tokens = gbl.TheConfig.get(gbl.TheSection, 'include').split(',')
          for Token in Tokens:
            InclusionList.append(Token.strip())
        gbl.LogDebug('inclusion list= %s'%str(InclusionList))

        if gbl.BackupInfoOnly:
          SizeGuess = 0; FileGuess = 0
          for Inclusion in InclusionList:
            Guess(Inclusion)
          gbl.MsgToGui('%i files, %0.1f mB to be backed up'%(
            FileGuess, float(SizeGuess) / 1024.0))
        else:
          Stamp = str(datetime.date.today())
          Tokens = Stamp.split('-')
          BackupName = Tokens[0] + Tokens[1] + Tokens[2]
          gbl.LogInfo('created backup name %s'%BackupName)
          
          FullBackupName = os.path.join(TargetPath, BackupName) + '.tar.gz'
          if os.path.isfile(FullBackupName):
            gbl.MsgToGui('Backup %s already exists, removing'%BackupName)
            os.remove(FullBackupName)
          gbl.MsgToGui('Building %s'%FullBackupName)
          oTarFile = tarfile.open(FullBackupName, 'w|gz')
          gbl.LogInfo('tar file opened')
          for Inclusion in InclusionList:
            AddToTar(Inclusion)
          oTarFile.close()

          TimeSpan = abs(time.time() - StartTime)
          gbl.MsgToGui('%i files, %0.1f mB backed up in %0.1f min'%(
            gbl.SourceFileCount,
            float(gbl.SourceSizeKb) / 1024.0,
            TimeSpan / 60.0))
          BackupList = os.listdir(TargetPath)
          TrialTargetBackupList = os.listdir(TargetPath)
          TargetBackupList = []
          for TargetBackup in TrialTargetBackupList:
            if len(TargetBackup) == 15:
              if TargetBackup[8:15] == '.tar.gz':
                if TargetBackup[0:8].isdigit():
                  TargetBackupList.append(TargetBackup)
          TargetBackupList.sort()
          while len(TargetBackupList) > 3:
            os.remove(os.path.join(TargetPath, TargetBackupList[0]))
            TargetBackupList.pop(0)
        ## ========================================
      except:
        print 'backup crashed'
        gbl.LogException(' - backup crashed')
      gbl.BackupSw = False
      gbl.StopBackupSw = False
      gbl.MsgToGui('backup task completed ----------')
    time.sleep(3.0)
  gbl.BackupRunning = False
  gbl.Log('backup ended')

def AddToTar(Directory):
  ## recursive routine to walk the source
  global oTarFile, ExclusionList, TimeMarker, INTERVAL
  NameList = os.listdir(Directory)
  NameSet= set(NameList)
  ExcludedSet = set([])
  for Exclusion in ExclusionList:
    if gbl.StopBackupSw: return
    DroppedNames = fnmatch.filter(NameSet, Exclusion)
    ExcludedSet = ExcludedSet.union(DroppedNames)
  AcceptedSet = NameSet.difference(ExcludedSet)
  gbl.LogDebug(str(AcceptedSet))
  for Name in AcceptedSet:
    if gbl.StopBackupSw: return
    Path = os.path.join(Directory, Name)
    if os.path.isdir(Path):
      #gbl.LogInfo('backing up %s'%Path)
      AddToTar(Path)
    elif os.path.isfile(Path):
      gbl.SourceFileCount += 1
      gbl.SourceSizeKb += (os.path.getsize(Path) + 1023) / 1024
      gbl.LogDebug('#%i: %ikB - %s'%(
        gbl.SourceFileCount, gbl.SourceSizeKb, Path))
      oTarFile.add(Path)
      if time.time() > TimeMarker:
        gbl.MsgToGui('%i files, %0.1f mB backed up so far'%(
          gbl.SourceFileCount, float(gbl.SourceSizeKb) / 1024.0))
        TimeMarker += INTERVAL
      gbl.GuiWakeup()
    else:
      gbl.LogWarn('%s is not a dir or file'%Path)
      
def Guess(Directory):
  global SizeGuess, FileGuess, ExclusionList
  NameList = os.listdir(Directory)
  NameSet= set(NameList)
  ExcludedSet = set([])
  for Exclusion in ExclusionList:
    if gbl.StopBackupSw: return
    DroppedNames = fnmatch.filter(NameSet, Exclusion)
    ExcludedSet = ExcludedSet.union(DroppedNames)
  AcceptedSet = NameSet.difference(ExcludedSet)
  gbl.LogDebug(str(AcceptedSet))
  for Name in AcceptedSet:
    if gbl.StopBackupSw: return
    Path = os.path.join(Directory, Name)
    if os.path.isdir(Path):
      #gbl.LogInfo('backing up %s'%Path)
      Guess(Path)
    elif os.path.isfile(Path):
      FileGuess += 1
      SizeGuess += (os.path.getsize(Path) + 1023) / 1024
      gbl.LogDebug('#%i: %ikB - %s'%(
        FileGuess, SizeGuess, Path))
      gbl.GuiWakeup()
    else:
      gbl.LogWarn('%s is not a dir or file'%Path)

def Start():
  try:
    thread.start_new_thread(Run, (0,))
    while not gbl.BackupRunning:
      time.sleep(1)
  except:
    gbl.LogException('backup thread failed to start')
    gbl.BackupRunning = False
    
def Stop():
  global StopThread
  gbl.StopBackupSw = True
  StopThread = True
  while gbl.BackupRunning:
    time.sleep(1)
    
pass
