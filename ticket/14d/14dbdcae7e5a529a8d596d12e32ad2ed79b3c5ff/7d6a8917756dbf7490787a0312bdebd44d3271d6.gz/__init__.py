""" doc string for the CRM_SDK
test docs\n
another doc string
"""
print __name__ + " is loaded"
