
#include <wx/sizer.h>
#include <wx/file.h>
#include <wx/radiobut.h>
#include <wx/print.h>
#include <wx/renderer.h>
#include <wx/clrpicker.h>
#include <wx/spinctrl.h>
#include <wx/checkbox.h>
#include <wx/stattext.h>
#include <wx/textctrl.h>
#include <wx/msgdlg.h>
#include <wx/choice.h>
#include <wx/valtext.h>
#include <wx/dcclient.h>
//#include <wx/listctrl.h>
#include <vector>

//#include "WaitWindow.h"

void doPrintOuter();

namespace AriaMaestosa
{
    
    /** after dialog is shown, and user clicked 'OK', this is called to launch the actual printing */
    void doPrint()
    {
        
        bool symbolPrinter = true;
        bool keyrollPrinter = false;
        
        bool keepGoingOn = true;
        
        if (symbolPrinter and keyrollPrinter)
        {
            wxMessageBox( _("Keyroll tracks and tablature/score tracks cannot be mixed in the same printout") );
            keepGoingOn = false;
        }
        else if (not symbolPrinter and not keyrollPrinter)
        {
            wxMessageBox( _("No printable track selected") );
            keepGoingOn = false;
        }
        
        //AriaMaestosa::WaitWindow::show(_("Calculating print layout...") );
        //wxMilliSleep(2000);
        //AriaMaestosa::WaitWindow::hide();
        doPrintOuter();
    }        
    
    class wxTempList : public wxPanel
    {
        wxFlexGridSizer* m_sizer;
        int m_col_count;
        
        std::vector< std::vector<wxWindow*> > m_rows;
        
    public:
        
        wxTempList(wxWindow* parent, const int columnCount, const wxString colNames[], const bool growable[]) :
        wxPanel(parent, wxID_ANY, wxDefaultPosition, wxDefaultSize, wxSIMPLE_BORDER)
        {
            SetBackgroundColour(*wxWHITE);
            m_sizer = new wxFlexGridSizer(columnCount);
            m_col_count = columnCount;
            
            for (int n=0; n<columnCount; n++)
            {
                if (growable[n]) m_sizer->AddGrowableCol(n);
                
                const int h = wxRendererNative::GetDefault().GetHeaderButtonHeight(this);
                
                wxStaticText* header = new wxStaticText(this, wxID_ANY, wxT(" ") + colNames[n] + wxT("  "));
                header->SetMinSize( wxSize(-1, h) );
                header->SetMaxSize( wxSize(999, h) );
                //header->SetBackgroundColour( wxColour(220, 220, 220) );
                m_sizer->Add(header, 1, wxEXPAND);
            }
        }
        
        void addRowWidgets(wxWindow** widgets)
        {
            std::vector<wxWindow*> row;
            for (int n=0; n<m_col_count; n++)
            {
                m_sizer->Add(widgets[n], 1, wxEXPAND | wxALL, 2);
                row.push_back(widgets[n]);
            }
            m_rows.push_back(row);
        }
        
        void done()
        {
            SetSizer(m_sizer);
            Layout();
        }
        
        std::vector<wxWindow*>& getRow(const int rowId)
        {
            return m_rows[rowId];
        }
        
        void onPaint(wxPaintEvent& evt)
        {
            wxPaintDC dc(this);
            //const int h = wxRendererNative::GetDefault().GetHeaderButtonHeight(this);
            
            wxSizerItemList& items = m_sizer->GetChildren();
            //#if wxCHECK_VERSION(2,9,2)
            wxSizerItemList::compatibility_iterator node = items.GetFirst();
            //#else
            //            wxwxSizerItemListNode *node = items.GetFirst();
            //#endif
            int count = 0;
            while (node)
            {
                wxSizerItem* win = node->GetData();
                wxPoint position = win->GetPosition();
                wxSize size = win->GetSize();
                wxRendererNative::GetDefault().DrawHeaderButton(this, dc, wxRect(position, size));
                
                node = node->GetNext();
                count++;
                if (count >= m_col_count) break;
            }
            
            
            //wxRendererNative::GetDefault().DrawHeaderButton(this, dc, wxRect(0, 0, GetSize().GetWidth(), h));
        }
        
        DECLARE_EVENT_TABLE()
    };
    BEGIN_EVENT_TABLE(wxTempList, wxPanel)
    EVT_PAINT(wxTempList::onPaint)
    END_EVENT_TABLE()
    
    /**
     * @ingroup dialogs
     * @brief the dialog to set-up printing of track(s) and page setup
     * @note this is a private class, it won't be instanciated directly
     * @see showPrintSetupDialog
     */
    class PrintSetupDialog : public wxFrame
    {
        //Sequence* m_current_sequence;
        
        //bool m_detect_repetitions;
        
        wxRadioButton* m_current_track_radiobtn;
        wxRadioButton* m_visible_tracks_radiobtn;
        
        //wxCheckBox* m_detect_repetitions_checkbox; 
        
        wxTempList* m_track_choice;
        //wxCheckListBox* m_track_choice;
        //wxListCtrl* m_track_choice;
        
        wxCheckBox*    m_hide_empty_tracks; 
        
        wxStaticText* m_page_setup_summary;
        
        //AriaPrintable*     m_printable;
        
    public:
                
        PrintSetupDialog(wxWindow *parent) : wxFrame(parent, wxID_ANY,
                                                     //I18N: - title of the notation-print dialog
                                                     _("Print musical notation"),
                                                     wxPoint(200,200), wxSize(500, 400), wxCAPTION | wxFRAME_FLOAT_ON_PARENT)
        {
            //m_detect_repetitions = false;
            
            bool success = true;
            
            if (not success)
            {                
                std::cerr << "error while performing page setup : " << __FILE__ << ":" << __LINE__ << std::endl;
                wxMessageBox( _("An error occurred while preparing to print.") );
                return;
            }
            
            // --- Setup dialog
            SetMinSize( wxSize(500, 400) );
            wxPanel* parent_panel = new wxPanel(this);
            
            wxBoxSizer* boxSizer = new wxBoxSizer(wxVERTICAL);
            
            //I18N: - in print setup dialog. 
            wxStaticBoxSizer* subsizer = new wxStaticBoxSizer(wxVERTICAL, parent_panel, _("Print..."));
            
            //I18N: - in print setup dialog. 
            m_current_track_radiobtn = new wxRadioButton(parent_panel, wxNewId(), _("Current track only") , wxDefaultPosition, wxDefaultSize, wxRB_GROUP);
            m_current_track_radiobtn->Connect( m_current_track_radiobtn->GetId(), wxEVT_COMMAND_RADIOBUTTON_SELECTED,
                                              wxCommandEventHandler(PrintSetupDialog::onSelectCurrentTrackOnly), NULL, this );
            
            //I18N: - in print setup dialog. 
            m_visible_tracks_radiobtn = new wxRadioButton(parent_panel, wxNewId(), _("This list of tracks"));
            m_visible_tracks_radiobtn->Connect( m_visible_tracks_radiobtn->GetId(), wxEVT_COMMAND_RADIOBUTTON_SELECTED,
                                               wxCommandEventHandler(PrintSetupDialog::onSelectTrackList), NULL, this );
            
            const int colCount = 3;
            const bool growable[colCount] = { false, true, true };
            const wxString colNames[] = { wxString( wxT("Print") ), wxString( wxT("Track Name") ), wxString( wxT("Type") ) };
            m_track_choice = new wxTempList(parent_panel, colCount, colNames, growable);
            
            const int track_amount = 5;
            for (int n=0; n<track_amount; n++)
            {
                //Track* track = m_current_sequence->getTrack(n);
                wxCheckBox* cb = new wxCheckBox(m_track_choice, wxID_ANY, wxT(""));
                cb->SetValue(true);
                
                wxStaticText* trackName = new wxStaticText(m_track_choice, wxID_ANY, "Baz" );
                
                wxArrayString choices;
                //I18N: printing notation type
                choices.Add( _("Score (staff)") );
                //I18N: printing notation type
                choices.Add( _("Tablature") );
                //I18N: printing notation type
                choices.Add( _("Keyroll") );
                
                wxChoice* editorType = new wxChoice(m_track_choice, wxID_ANY, wxDefaultPosition, wxDefaultSize,
                                                    choices );
                
                editorType->SetSelection(0);
                
                wxWindow* cells[3];
                cells[0] = cb;
                cells[1] = trackName;
                cells[2] = editorType;
                m_track_choice->addRowWidgets( cells );
            }
            m_track_choice->done();
            m_track_choice->Enable(false);
            
            subsizer->Add(m_current_track_radiobtn, 0, wxALL, 5); m_current_track_radiobtn->SetValue(true);
            subsizer->Add(m_visible_tracks_radiobtn, 0, wxALL, 5);
            subsizer->Add(m_track_choice, 1, wxALL | wxEXPAND, 5);
            
            boxSizer->Add(subsizer, 1, wxALL | wxEXPAND, 5);
            
            // hide empty tracks
            //I18N: in printing dialog
            m_hide_empty_tracks = new wxCheckBox(parent_panel, wxID_ANY,  _("Omit instruments that play nothing on the current line"));
            m_hide_empty_tracks->SetValue(false);
            m_hide_empty_tracks->SetToolTip( _("If some instrument plays nothing during a long part of the song, checking this option can make the printed score tighter by eliminating empty lines") );
            boxSizer->Add(m_hide_empty_tracks, 0, wxALL, 5);
            m_hide_empty_tracks->Enable(false);
            
            // Page setup summary
            {
                wxStaticBoxSizer* pageSetupSizer = new wxStaticBoxSizer(wxHORIZONTAL, parent_panel, _("Page Setup"));
                
                
                m_page_setup_summary = new wxStaticText(parent_panel, wxID_ANY, "Foo Bar");
                pageSetupSizer->Add( m_page_setup_summary, 1, wxEXPAND | wxTOP | wxBOTTOM, 5 );                
                
                {
                    wxPanel* buttonsPanel = new wxPanel(parent_panel);
                    wxBoxSizer* buttonsSizer = new wxBoxSizer(wxVERTICAL);
                    
                    
                    wxButton* pageSetupButton = new wxButton(buttonsPanel, wxNewId(), _("Edit Page Setup"));
                    buttonsSizer->Add(pageSetupButton, 0, wxEXPAND | wxTOP | wxBOTTOM, 5 );
                    pageSetupButton->Connect(pageSetupButton->GetId(), wxEVT_COMMAND_BUTTON_CLICKED,
                                             wxCommandEventHandler(PrintSetupDialog::onEditPageSetupClicked),
                                             NULL, this);
                    
#ifdef __WXMAC__ 
                    // the mac page setup dialog does not allow editing margins
                    wxButton* marginsButton = new wxButton(buttonsPanel, wxNewId(), _("Margins"));
                    buttonsSizer->Add(marginsButton, 0, wxEXPAND | wxTOP | wxBOTTOM, 5 );
                    marginsButton->Connect(marginsButton->GetId(), wxEVT_COMMAND_BUTTON_CLICKED,
                                           wxCommandEventHandler(PrintSetupDialog::onMacEditMargins),
                                           NULL, this);
#endif
                    
                    buttonsPanel->SetSizer( buttonsSizer );
                    pageSetupSizer->Add( buttonsPanel, 0, wxLEFT | wxRIGHT, 5 );   
                }
                
                boxSizer->Add(pageSetupSizer,  0, wxALL | wxEXPAND, 5);
            }
            
            // OK-Cancel buttons
            {
                wxPanel* buttonPanel = new wxPanel(parent_panel);
                boxSizer->Add(buttonPanel, 0, wxALL | wxEXPAND, 5);
                
                wxBoxSizer* buttonsSizer = new wxBoxSizer(wxHORIZONTAL);
                
                wxButton* okButton = new wxButton(buttonPanel, wxID_OK, _("OK"));
                okButton->SetDefault();
                
                wxButton* cancelButton = new wxButton(buttonPanel, wxID_CANCEL,  _("Cancel"));
                
                buttonsSizer->AddStretchSpacer();
                buttonsSizer->Add(cancelButton, 0, wxALL, 7);
                buttonsSizer->Add(okButton,     0, wxALL, 7);
                
                buttonPanel->SetSizer(buttonsSizer);
                buttonPanel->SetAutoLayout(true);
                buttonsSizer->Layout();
                
                Connect(wxID_OK, wxEVT_COMMAND_BUTTON_CLICKED,
                        wxCommandEventHandler(PrintSetupDialog::onOkClicked), NULL, this);
                Connect(wxID_CANCEL, wxEVT_COMMAND_BUTTON_CLICKED,
                        wxCommandEventHandler(PrintSetupDialog::onCancelClicked), NULL, this);
                
            }
            
            parent_panel->SetSizer(boxSizer);
            boxSizer->Layout();
            boxSizer->SetSizeHints(parent_panel);
            
            Fit();
            Center();
            Show();
            
        }
        
        void onEditPageSetupClicked(wxCommandEvent& evt)
        {
            //m_printable->showPageSetupDialog();
            m_page_setup_summary->SetLabel("Hello World");
        }
        
#ifdef __WXMAC__
        void onMacEditMargins(wxCommandEvent& evt)
        {
            Hide();
            //m_printable->macEditMargins(this);
            Show();
            m_page_setup_summary->SetLabel("Hello World");
        }
#endif
        
        void onSelectCurrentTrackOnly(wxCommandEvent& evt)
        {
            m_hide_empty_tracks->SetValue(false);
            m_hide_empty_tracks->Enable(false);
            m_track_choice->Enable(false);
            m_track_choice->Refresh();
        }
        
        void onSelectTrackList(wxCommandEvent& evt)
        {
            m_hide_empty_tracks->SetValue(true);
            m_hide_empty_tracks->Enable(true);
            m_track_choice->Enable(true);
            m_track_choice->Refresh();
        }
        
        /**  called when the 'cancel' button is clicked, or 'escape' is pressed */
        void onCancelClicked(wxCommandEvent& evt)
        {
            //delete m_printable;
            
            Hide();
            Destroy();
            //getMainFrame()->disableMenus(false);
        }
        
        /** when the 'ok' button is clicked */
        void onOkClicked(wxCommandEvent& evt)
        {
            const bool print_one_track = m_current_track_radiobtn->GetValue();
            
            // terminate the dialog
            Hide();
            
            // **** This destroy randomly crashes
            Destroy();
            
            doPrint();
        }
        
        
    };
    
    // ----------------------------------------------------------------------------------------------------
    // ------------------------------------- first function called ----------------------------------------
    // ----------------------------------------------------------------------------------------------------
    
    // user wants to export to notation - remember what is the sequence, then show set-up dialog
    void showPrintSetupDialog(wxWindow* parent)
    {
        new PrintSetupDialog(parent);
    }
    
}
