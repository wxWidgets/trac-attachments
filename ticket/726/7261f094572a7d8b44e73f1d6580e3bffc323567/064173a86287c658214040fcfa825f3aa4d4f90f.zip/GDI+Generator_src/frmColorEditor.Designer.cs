namespace GDI_Generator
{
    partial class frmColorEditor
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tpSolid = new System.Windows.Forms.TabPage();
            this.btnCancel = new System.Windows.Forms.Button();
            this.btnAccept = new System.Windows.Forms.Button();
            this.tpGradient = new System.Windows.Forms.TabPage();
            this.tabControl1.SuspendLayout();
            this.tpSolid.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tpSolid);
            this.tabControl1.Controls.Add(this.tpGradient);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.Location = new System.Drawing.Point(0, 0);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(360, 250);
            this.tabControl1.TabIndex = 0;
            // 
            // tpSolid
            // 
            this.tpSolid.Controls.Add(this.btnCancel);
            this.tpSolid.Controls.Add(this.btnAccept);
            this.tpSolid.Location = new System.Drawing.Point(4, 22);
            this.tpSolid.Name = "tpSolid";
            this.tpSolid.Padding = new System.Windows.Forms.Padding(3);
            this.tpSolid.Size = new System.Drawing.Size(352, 224);
            this.tpSolid.TabIndex = 0;
            this.tpSolid.Text = "Solid";
            this.tpSolid.UseVisualStyleBackColor = true;
            // 
            // btnCancel
            // 
            this.btnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnCancel.Location = new System.Drawing.Point(184, 193);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(75, 23);
            this.btnCancel.TabIndex = 6;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.UseVisualStyleBackColor = true;
            // 
            // btnAccept
            // 
            this.btnAccept.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.btnAccept.Location = new System.Drawing.Point(89, 193);
            this.btnAccept.Name = "btnAccept";
            this.btnAccept.Size = new System.Drawing.Size(75, 23);
            this.btnAccept.TabIndex = 5;
            this.btnAccept.Text = "Accept";
            this.btnAccept.UseVisualStyleBackColor = true;
            // 
            // tpGradient
            // 
            this.tpGradient.Location = new System.Drawing.Point(4, 22);
            this.tpGradient.Name = "tpGradient";
            this.tpGradient.Padding = new System.Windows.Forms.Padding(3);
            this.tpGradient.Size = new System.Drawing.Size(352, 224);
            this.tpGradient.TabIndex = 1;
            this.tpGradient.Text = "Gradient";
            this.tpGradient.UseVisualStyleBackColor = true;
            // 
            // frmColorEditor
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(360, 250);
            this.Controls.Add(this.tabControl1);
            this.Name = "frmColorEditor";
            this.Text = "Color Editor";
            this.tabControl1.ResumeLayout(false);
            this.tpSolid.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tpSolid;
        private System.Windows.Forms.TabPage tpGradient;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Button btnAccept;
    }
}