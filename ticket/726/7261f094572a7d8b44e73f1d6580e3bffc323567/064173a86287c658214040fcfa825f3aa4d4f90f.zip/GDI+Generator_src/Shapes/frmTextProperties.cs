using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Shapes;

namespace Shapes
{
    public partial class frmTextProperties : Form
    {
        ShapeText refShape;
        FontDialog fd = new FontDialog();
        public bool txtChanged;
        public bool fontChanged;
        public frmTextProperties(ShapeText shapeText)
        {
            InitializeComponent();
            txtContents.Text = shapeText.Text;
            refShape = shapeText;
            txtChanged = false;
            fontChanged = false;
            txtContents.Font = refShape.Font;
            fd.Font = refShape.Font;

            switch (refShape.Alignment)
            {
                case StringAlignment.Near:
                    txtContents.TextAlign = HorizontalAlignment.Left;
                    break;
                case StringAlignment.Center:
                    txtContents.TextAlign = HorizontalAlignment.Center;
                    break;
                case StringAlignment.Far:
                    txtContents.TextAlign = HorizontalAlignment.Right;
                    break;
            }
        }

        private void btnTextCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnTextAccept_Click(object sender, EventArgs e)
        {
            if (txtChanged && (refShape.Text != txtContents.Text))
                 refShape.Text = txtContents.Text;
            if (fontChanged)
                 refShape.Font = fd.Font;

            this.Close();
        }

        private void btnFont_Click(object sender, EventArgs e)
        {
            fd.ShowDialog();
            if (fd.Font.Name != refShape.Font.Name)
                fontChanged = true;
            if (fd.Font.Size != refShape.Font.Size)
                fontChanged = true;
            if (fd.Font.Style != refShape.Font.Style)
                fontChanged = true;
            if (fd.Font.Strikeout != refShape.Font.Strikeout)
                fontChanged = true;
            if (fd.Font.Underline != refShape.Font.Underline)
                fontChanged = true;

            if (fontChanged)
                txtContents.Font = fd.Font;
        }

        private void frmTextProperties_FormClosed(object sender, FormClosedEventArgs e)
        {
            fd.Dispose();
            fd = null;
        }

        private void txtContents_TextChanged(object sender, EventArgs e)
        {
            txtChanged = true;
        }

        private void btnAlignLeft_Click(object sender, EventArgs e)
        {
            txtContents.TextAlign = HorizontalAlignment.Left;
            if (refShape.Alignment != StringAlignment.Near)
                txtChanged = true;
            refShape.Alignment = StringAlignment.Near;
        }

        private void btnAlignMiddle_Click(object sender, EventArgs e)
        {
            txtContents.TextAlign = HorizontalAlignment.Center;
            if (refShape.Alignment != StringAlignment.Center)
                txtChanged = true;
            refShape.Alignment = StringAlignment.Center;
        }


        private void btnAlignRight_Click(object sender, EventArgs e)
        {
            txtContents.TextAlign = HorizontalAlignment.Right;
            if (refShape.Alignment != StringAlignment.Far)
                txtChanged = true;
            refShape.Alignment = StringAlignment.Far;
        }

    }
}