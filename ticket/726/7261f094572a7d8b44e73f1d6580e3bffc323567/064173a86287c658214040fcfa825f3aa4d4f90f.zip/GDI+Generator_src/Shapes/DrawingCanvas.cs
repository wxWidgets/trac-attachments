////////////////////////////////////////////////////////////////
//                Created By Richard Blythe 2008
//   There are no licenses or warranty attached to this object.
//   If you distribute the code as part of your application, please
//   be courteous enough to mention the assistance provided you.
////////////////////////////////////////////////////////////////

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Windows.Forms;
using System.Runtime.Serialization.Formatters.Binary;
using Painters;
using System.IO;

namespace Shapes
{
    [Serializable]
    public partial class DrawingCanvas : UserControl
    {
       public ShapeManager shapeManager;
        
        public DrawingCanvas()
        {
            InitializeComponent();
            shapeManager = new ShapeManager(this);

            this.SetStyle(ControlStyles.DoubleBuffer |
                          ControlStyles.UserPaint |
                          ControlStyles.AllPaintingInWmPaint,
                          true);
            this.UpdateStyles();
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            shapeManager.PaintShapes(e.Graphics);
        }

        public bool Save(bool blnSaveAs)
        {
            bool blnSuccess = false;
            string strFileName = shapeManager.FileName;
            try
            {
                if (blnSaveAs || shapeManager.FileName == "")
                {

                    using (SaveFileDialog sfd = new SaveFileDialog())
                    {
                        sfd.Filter = "GDI+ Generator Files (*.ggf)|*.ggf";
                        sfd.DefaultExt = ".dat";
                        sfd.Title = "Save Work";
                        sfd.ShowDialog();
                        shapeManager.FileName = sfd.FileName;
                    }
                }
                if (shapeManager.FileName != "")
                {

                    if (shapeManager.FileName == "" || shapeManager.FileName == null)
                        return false;
                    using (FileStream fs = new FileStream(shapeManager.FileName,
                    FileMode.Create, FileAccess.Write, FileShare.Write))
                    {
                        BinaryFormatter bf = new BinaryFormatter();
                        bf.Serialize(fs, shapeManager);
                        blnSuccess = true;
                    }
                }
                if (!blnSuccess)
                    shapeManager.FileName = strFileName;
                else if (blnSaveAs)
                    MessageBox.Show("File was saved", "Notice", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred while saving the file.\r\n"+
                                ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            if (blnSuccess)
                shapeManager.IsDirty = false;
            return blnSuccess;
        }

        public bool Open()
        {
            bool blnSuccess = false;
            using (OpenFileDialog ofd = new OpenFileDialog())
            {
                try
                {
                    ofd.Filter = "GDI+ Generator Files (*.ggf)|*.ggf";
                    ofd.DefaultExt = ".dat";
                    ofd.Title = "Open Saved Work";
                    ofd.ShowDialog();

                    if (ofd.FileName != "")
                    {
                        shapeManager.FileName = ofd.FileName;
                        using (FileStream fs = new FileStream(shapeManager.FileName,
                               FileMode.Open, FileAccess.Read, FileShare.Read))
                        {
                            BinaryFormatter bf = new BinaryFormatter();
                            ShapeManager tmp = (ShapeManager)bf.Deserialize(fs);
                            tmp.RestoreNonSerializable(this);
                            shapeManager.Dispose();
                            shapeManager = null;
                            shapeManager = tmp;
                        }

                        blnSuccess = true;
                        this.Invalidate();
                    }

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                
            }
            return blnSuccess;
        }

        public void ShowPropertyEditor()
        {
            frmShapeProperties frm = new frmShapeProperties(shapeManager);
            frm.ShowDialog();
            frm.Dispose();
        }

        public void ShowColorEditor()
        {
            if (shapeManager.SelectedIndex != -1 && !(shapeManager.GetSelectedShape() is ShapeClipRectangle))
            {
                frmColorEditor frm = new frmColorEditor(shapeManager.GetSelectedShape().painter);
                frm.ShowDialog();
                frm.Dispose();
            }
        }

        private void DrawingCanvas_KeyDown(object sender, KeyEventArgs e)
        {
            switch (e.KeyCode)
            {
                case Keys.Enter:
                    shapeManager.FinalizeShape();
                    break;
                case Keys.Delete:
                    shapeManager.Delete();
                    break;
            }

            if (e.KeyCode == Keys.C && Control.ModifierKeys == Keys.Control)
            {
                shapeManager.Copy();
            }
            else if (e.KeyCode == Keys.V && Control.ModifierKeys == Keys.Control)
            {
                shapeManager.Paste();
            }
        }

    }

    public class ShapeMenuItem
    {
        public string ShapeName;
        public byte ShapeType;
        public ShapeMenuItem(string name, byte type)
        {
            ShapeName = name;
            ShapeType = type;
        }
    }
}
