namespace GDI_Generator
{
    partial class frmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmMain));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.newToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.openToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveAsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.viewGDICodeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.showClippingToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.antiAliasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmBackgroundImage = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.exitToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmAddShape = new System.Windows.Forms.ToolStripMenuItem();
            this.addToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.deleteToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.propertiesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.paintToolsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tsPathEditor = new System.Windows.Forms.ToolStrip();
            this.tsbConvertToCurve = new System.Windows.Forms.ToolStripButton();
            this.tsbConvertToLine = new System.Windows.Forms.ToolStripButton();
            this.tsbDeleteNode = new System.Windows.Forms.ToolStripButton();
            this.tsSelectionTools = new System.Windows.Forms.ToolStrip();
            this.tsbSelectionTool = new System.Windows.Forms.ToolStripButton();
            this.tsbNodeTool = new System.Windows.Forms.ToolStripButton();
            this.tsbSentToBack = new System.Windows.Forms.ToolStripButton();
            this.tsbBringToFront = new System.Windows.Forms.ToolStripButton();
            this.tsslMousePos = new System.Windows.Forms.ToolStripStatusLabel();
            this.ssMouseLocation = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel2 = new System.Windows.Forms.ToolStripStatusLabel();
            this.tsContainer = new System.Windows.Forms.ToolStripContainer();
            this.menuStrip1.SuspendLayout();
            this.tsPathEditor.SuspendLayout();
            this.tsSelectionTools.SuspendLayout();
            this.ssMouseLocation.SuspendLayout();
            this.tsContainer.TopToolStripPanel.SuspendLayout();
            this.tsContainer.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.tsmAddShape,
            this.paintToolsToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(601, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.newToolStripMenuItem,
            this.openToolStripMenuItem,
            this.saveToolStripMenuItem,
            this.saveAsToolStripMenuItem,
            this.toolStripSeparator1,
            this.viewGDICodeToolStripMenuItem,
            this.showClippingToolStripMenuItem,
            this.antiAliasToolStripMenuItem,
            this.tsmBackgroundImage,
            this.toolStripSeparator2,
            this.exitToolStripMenuItem1});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(35, 20);
            this.fileToolStripMenuItem.Text = "File";
            // 
            // newToolStripMenuItem
            // 
            this.newToolStripMenuItem.Name = "newToolStripMenuItem";
            this.newToolStripMenuItem.Size = new System.Drawing.Size(193, 22);
            this.newToolStripMenuItem.Tag = "0";
            this.newToolStripMenuItem.Text = "New               Ctrl+N";
            this.newToolStripMenuItem.Click += new System.EventHandler(this.fileMenuItem_Click);
            // 
            // openToolStripMenuItem
            // 
            this.openToolStripMenuItem.Name = "openToolStripMenuItem";
            this.openToolStripMenuItem.Size = new System.Drawing.Size(193, 22);
            this.openToolStripMenuItem.Tag = "1";
            this.openToolStripMenuItem.Text = "Open             Ctrl+N";
            this.openToolStripMenuItem.Click += new System.EventHandler(this.fileMenuItem_Click);
            // 
            // saveToolStripMenuItem
            // 
            this.saveToolStripMenuItem.Name = "saveToolStripMenuItem";
            this.saveToolStripMenuItem.Size = new System.Drawing.Size(193, 22);
            this.saveToolStripMenuItem.Tag = "2";
            this.saveToolStripMenuItem.Text = "Save              Ctrl+S";
            this.saveToolStripMenuItem.TextDirection = System.Windows.Forms.ToolStripTextDirection.Horizontal;
            this.saveToolStripMenuItem.Click += new System.EventHandler(this.fileMenuItem_Click);
            // 
            // saveAsToolStripMenuItem
            // 
            this.saveAsToolStripMenuItem.Name = "saveAsToolStripMenuItem";
            this.saveAsToolStripMenuItem.Size = new System.Drawing.Size(193, 22);
            this.saveAsToolStripMenuItem.Tag = "3";
            this.saveAsToolStripMenuItem.Text = "Save As...";
            this.saveAsToolStripMenuItem.Click += new System.EventHandler(this.fileMenuItem_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(190, 6);
            // 
            // viewGDICodeToolStripMenuItem
            // 
            this.viewGDICodeToolStripMenuItem.Name = "viewGDICodeToolStripMenuItem";
            this.viewGDICodeToolStripMenuItem.Size = new System.Drawing.Size(193, 22);
            this.viewGDICodeToolStripMenuItem.Text = "View GDI+ Code";
            this.viewGDICodeToolStripMenuItem.Click += new System.EventHandler(this.viewGDICodeToolStripMenuItem_Click);
            // 
            // showClippingToolStripMenuItem
            // 
            this.showClippingToolStripMenuItem.Name = "showClippingToolStripMenuItem";
            this.showClippingToolStripMenuItem.Size = new System.Drawing.Size(193, 22);
            this.showClippingToolStripMenuItem.Text = "Show Clipping";
            this.showClippingToolStripMenuItem.Click += new System.EventHandler(this.showClippingToolStripMenuItem_Click);
            // 
            // antiAliasToolStripMenuItem
            // 
            this.antiAliasToolStripMenuItem.Name = "antiAliasToolStripMenuItem";
            this.antiAliasToolStripMenuItem.Size = new System.Drawing.Size(193, 22);
            this.antiAliasToolStripMenuItem.Text = "Anti-Alias: On";
            this.antiAliasToolStripMenuItem.Click += new System.EventHandler(this.antiAliasToolStripMenuItem_Click);
            // 
            // tsmBackgroundImage
            // 
            this.tsmBackgroundImage.Name = "tsmBackgroundImage";
            this.tsmBackgroundImage.Size = new System.Drawing.Size(193, 22);
            this.tsmBackgroundImage.Text = "Set Background Image";
            this.tsmBackgroundImage.Click += new System.EventHandler(this.tsmBackgroundImage_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(190, 6);
            // 
            // exitToolStripMenuItem1
            // 
            this.exitToolStripMenuItem1.Name = "exitToolStripMenuItem1";
            this.exitToolStripMenuItem1.Size = new System.Drawing.Size(193, 22);
            this.exitToolStripMenuItem1.Text = "Exit";
            this.exitToolStripMenuItem1.Click += new System.EventHandler(this.exitToolStripMenuItem1_Click);
            // 
            // tsmAddShape
            // 
            this.tsmAddShape.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.addToolStripMenuItem,
            this.deleteToolStripMenuItem,
            this.propertiesToolStripMenuItem});
            this.tsmAddShape.Name = "tsmAddShape";
            this.tsmAddShape.Size = new System.Drawing.Size(49, 20);
            this.tsmAddShape.Text = "Shape";
            // 
            // addToolStripMenuItem
            // 
            this.addToolStripMenuItem.Name = "addToolStripMenuItem";
            this.addToolStripMenuItem.Size = new System.Drawing.Size(134, 22);
            this.addToolStripMenuItem.Text = "Add";
            // 
            // deleteToolStripMenuItem
            // 
            this.deleteToolStripMenuItem.Name = "deleteToolStripMenuItem";
            this.deleteToolStripMenuItem.Size = new System.Drawing.Size(134, 22);
            this.deleteToolStripMenuItem.Text = "Delete";
            this.deleteToolStripMenuItem.Click += new System.EventHandler(this.deleteShape_Click);
            // 
            // propertiesToolStripMenuItem
            // 
            this.propertiesToolStripMenuItem.Name = "propertiesToolStripMenuItem";
            this.propertiesToolStripMenuItem.Size = new System.Drawing.Size(134, 22);
            this.propertiesToolStripMenuItem.Text = "Properties";
            this.propertiesToolStripMenuItem.Click += new System.EventHandler(this.propertiesToolStripMenuItem_Click);
            // 
            // paintToolsToolStripMenuItem
            // 
            this.paintToolsToolStripMenuItem.Name = "paintToolsToolStripMenuItem";
            this.paintToolsToolStripMenuItem.Size = new System.Drawing.Size(71, 20);
            this.paintToolsToolStripMenuItem.Text = "Paint Tools";
            this.paintToolsToolStripMenuItem.Click += new System.EventHandler(this.paintToolsToolStripMenuItem_Click);
            // 
            // tsPathEditor
            // 
            this.tsPathEditor.Dock = System.Windows.Forms.DockStyle.None;
            this.tsPathEditor.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden;
            this.tsPathEditor.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsbConvertToCurve,
            this.tsbConvertToLine,
            this.tsbDeleteNode});
            this.tsPathEditor.Location = new System.Drawing.Point(3, 0);
            this.tsPathEditor.Name = "tsPathEditor";
            this.tsPathEditor.Size = new System.Drawing.Size(72, 25);
            this.tsPathEditor.TabIndex = 1;
            // 
            // tsbConvertToCurve
            // 
            this.tsbConvertToCurve.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbConvertToCurve.Image = global::GDI_Generator.Properties.Resources.ConvertToCurve;
            this.tsbConvertToCurve.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbConvertToCurve.Name = "tsbConvertToCurve";
            this.tsbConvertToCurve.Size = new System.Drawing.Size(23, 22);
            this.tsbConvertToCurve.Text = "Convert To Curve";
            this.tsbConvertToCurve.Click += new System.EventHandler(this.tsbConvertToCurve_Click);
            // 
            // tsbConvertToLine
            // 
            this.tsbConvertToLine.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbConvertToLine.Image = global::GDI_Generator.Properties.Resources.ConvertToLine;
            this.tsbConvertToLine.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbConvertToLine.Name = "tsbConvertToLine";
            this.tsbConvertToLine.Size = new System.Drawing.Size(23, 22);
            this.tsbConvertToLine.Text = "Convert To Line";
            this.tsbConvertToLine.Click += new System.EventHandler(this.tsbConvertToLine_Click);
            // 
            // tsbDeleteNode
            // 
            this.tsbDeleteNode.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbDeleteNode.Image = global::GDI_Generator.Properties.Resources.DeleteNode;
            this.tsbDeleteNode.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbDeleteNode.Name = "tsbDeleteNode";
            this.tsbDeleteNode.Size = new System.Drawing.Size(23, 22);
            this.tsbDeleteNode.Text = "Convert To Line";
            this.tsbDeleteNode.ToolTipText = "Delete Node";
            this.tsbDeleteNode.Click += new System.EventHandler(this.tsbDeleteNode_Click);
            // 
            // tsSelectionTools
            // 
            this.tsSelectionTools.Dock = System.Windows.Forms.DockStyle.None;
            this.tsSelectionTools.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden;
            this.tsSelectionTools.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsbSelectionTool,
            this.tsbNodeTool,
            this.tsbSentToBack,
            this.tsbBringToFront});
            this.tsSelectionTools.Location = new System.Drawing.Point(75, 0);
            this.tsSelectionTools.Name = "tsSelectionTools";
            this.tsSelectionTools.Size = new System.Drawing.Size(281, 25);
            this.tsSelectionTools.TabIndex = 0;
            this.tsSelectionTools.Text = "toolStrip1";
            // 
            // tsbSelectionTool
            // 
            this.tsbSelectionTool.Checked = true;
            this.tsbSelectionTool.CheckState = System.Windows.Forms.CheckState.Checked;
            this.tsbSelectionTool.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbSelectionTool.Image = ((System.Drawing.Image)(resources.GetObject("tsbSelectionTool.Image")));
            this.tsbSelectionTool.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbSelectionTool.Name = "tsbSelectionTool";
            this.tsbSelectionTool.Size = new System.Drawing.Size(77, 22);
            this.tsbSelectionTool.Text = "Selection Tool";
            this.tsbSelectionTool.Click += new System.EventHandler(this.tsbSelectionTool_Click);
            // 
            // tsbNodeTool
            // 
            this.tsbNodeTool.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbNodeTool.Image = ((System.Drawing.Image)(resources.GetObject("tsbNodeTool.Image")));
            this.tsbNodeTool.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbNodeTool.Name = "tsbNodeTool";
            this.tsbNodeTool.Size = new System.Drawing.Size(59, 22);
            this.tsbNodeTool.Text = "Node Tool";
            this.tsbNodeTool.Click += new System.EventHandler(this.tsbNodeTool_Click);
            // 
            // tsbSentToBack
            // 
            this.tsbSentToBack.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbSentToBack.Image = ((System.Drawing.Image)(resources.GetObject("tsbSentToBack.Image")));
            this.tsbSentToBack.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbSentToBack.Name = "tsbSentToBack";
            this.tsbSentToBack.Size = new System.Drawing.Size(69, 22);
            this.tsbSentToBack.Text = "SendToBack";
            this.tsbSentToBack.Click += new System.EventHandler(this.tsbSentToBack_Click);
            // 
            // tsbBringToFront
            // 
            this.tsbBringToFront.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbBringToFront.Image = ((System.Drawing.Image)(resources.GetObject("tsbBringToFront.Image")));
            this.tsbBringToFront.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbBringToFront.Name = "tsbBringToFront";
            this.tsbBringToFront.Size = new System.Drawing.Size(73, 22);
            this.tsbBringToFront.Text = "BringToFront";
            this.tsbBringToFront.Click += new System.EventHandler(this.tsbBringToFront_Click);
            // 
            // tsslMousePos
            // 
            this.tsslMousePos.Name = "tsslMousePos";
            this.tsslMousePos.Size = new System.Drawing.Size(41, 17);
            this.tsslMousePos.Text = "120:50";
            // 
            // ssMouseLocation
            // 
            this.ssMouseLocation.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel2,
            this.tsslMousePos});
            this.ssMouseLocation.Location = new System.Drawing.Point(0, 346);
            this.ssMouseLocation.Name = "ssMouseLocation";
            this.ssMouseLocation.Size = new System.Drawing.Size(601, 22);
            this.ssMouseLocation.TabIndex = 2;
            this.ssMouseLocation.Text = "120:50";
            // 
            // toolStripStatusLabel2
            // 
            this.toolStripStatusLabel2.Name = "toolStripStatusLabel2";
            this.toolStripStatusLabel2.Size = new System.Drawing.Size(62, 17);
            this.toolStripStatusLabel2.Text = "Mouse Pos:";
            // 
            // tsContainer
            // 
            // 
            // tsContainer.ContentPanel
            // 
            this.tsContainer.ContentPanel.Size = new System.Drawing.Size(601, 297);
            this.tsContainer.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tsContainer.Location = new System.Drawing.Point(0, 24);
            this.tsContainer.Name = "tsContainer";
            this.tsContainer.Size = new System.Drawing.Size(601, 322);
            this.tsContainer.TabIndex = 4;
            this.tsContainer.Text = "toolStripContainer1";
            // 
            // tsContainer.TopToolStripPanel
            // 
            this.tsContainer.TopToolStripPanel.Controls.Add(this.tsPathEditor);
            this.tsContainer.TopToolStripPanel.Controls.Add(this.tsSelectionTools);
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(601, 368);
            this.Controls.Add(this.tsContainer);
            this.Controls.Add(this.ssMouseLocation);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "frmMain";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "GDI+ Generator - [Untitled]";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmMain_FormClosing);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.tsPathEditor.ResumeLayout(false);
            this.tsPathEditor.PerformLayout();
            this.tsSelectionTools.ResumeLayout(false);
            this.tsSelectionTools.PerformLayout();
            this.ssMouseLocation.ResumeLayout(false);
            this.ssMouseLocation.PerformLayout();
            this.tsContainer.TopToolStripPanel.ResumeLayout(false);
            this.tsContainer.TopToolStripPanel.PerformLayout();
            this.tsContainer.ResumeLayout(false);
            this.tsContainer.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem paintToolsToolStripMenuItem;
        private System.Windows.Forms.ToolStrip tsSelectionTools;
        private System.Windows.Forms.ToolStripButton tsbNodeTool;
        private System.Windows.Forms.ToolStripButton tsbSelectionTool;
        private System.Windows.Forms.ToolStripMenuItem tsmAddShape;
        private System.Windows.Forms.ToolStrip tsPathEditor;
        private System.Windows.Forms.ToolStripButton tsbConvertToCurve;
        private System.Windows.Forms.ToolStripButton tsbConvertToLine;
        private System.Windows.Forms.ToolStripStatusLabel tsslMousePos;
        private System.Windows.Forms.StatusStrip ssMouseLocation;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel2;
        private System.Windows.Forms.ToolStripButton tsbDeleteNode;
        private System.Windows.Forms.ToolStripButton tsbSentToBack;
        private System.Windows.Forms.ToolStripButton tsbBringToFront;
        private System.Windows.Forms.ToolStripMenuItem viewGDICodeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem addToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem deleteToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem propertiesToolStripMenuItem;
        private System.Windows.Forms.ToolStripContainer tsContainer;
        private System.Windows.Forms.ToolStripMenuItem showClippingToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem antiAliasToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem newToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem openToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saveToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saveAsToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem tsmBackgroundImage;
    }
}

