using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Shapes;

namespace GDI_Generator
{
    public partial class frmGDIViewer : Form
    {
       // public event EventHandler RefreshCode;
        private GDIGenerationTool generator;

        public frmGDIViewer(GDIGenerationTool gdiGenerator)
        {
            InitializeComponent();
            generator = gdiGenerator;
        }

        private void refreshCodeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LoadCode();
        }

        public void LoadCode()
        {
            txtCode.Clear();
            txtCode.Text = generator.GenerateCode();
        }

        private void usingTheCodeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmInstructions frm = new frmInstructions();
            frm.Show();
        }

        private void frmGDIViewer_FormClosed(object sender, FormClosedEventArgs e)
        {
            this.Dispose();
        }
    }
}