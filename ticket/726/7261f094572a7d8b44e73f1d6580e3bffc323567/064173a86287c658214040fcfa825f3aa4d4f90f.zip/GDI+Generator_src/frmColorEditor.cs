using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Painters;

namespace GDI_Generator
{
    public partial class frmColorEditor : Form
    {
           public Color back;
           public Color line;
        private Painter refPainter;

        public frmColorEditor(Painter painter)
        {
            InitializeComponent();
            //// refPainter = painter;

            ////if (painter.GetType() == typeof(PainterSolid))
            ////{ //do a temporary cast.
            ////    PainterSolid tmpPainter = (PainterSolid)painter;

            ////    lblBackColor.BackColor = tmpPainter.BackColor;
            ////    lblLineColor.BackColor = tmpPainter.LineColor;
            ////    chkPaintBack.Checked = tmpPainter.PaintBack;
            ////    chkPaintLine.Checked = tmpPainter.PaintLine;
            ////}



            ////line = lblLineColor.BackColor;
            ////back = lblBackColor.BackColor;
        }



        //////private void btnLineColor_Click(object sender, EventArgs e)
        //////{
        //////    colorDialog.Color = lblLineColor.BackColor;
        //////    colorDialog.ShowDialog();
        //////    lblLineColor.BackColor = colorDialog.Color;
        //////}

        //////private void btnBackColor_Click(object sender, EventArgs e)
        //////{
        //////    colorDialog.Color = lblBackColor.BackColor;
        //////    colorDialog.ShowDialog();
        //////    lblBackColor.BackColor = colorDialog.Color;
        //////}

        //////private void btnAccept_Click(object sender, EventArgs e)
        //////{
        //////    if (refPainter.GetType() == typeof(PainterSolid))
        //////    { //do a temporary cast.
        //////        PainterSolid tmpPainter = (PainterSolid)refPainter;
        //////        tmpPainter.BackColor = lblBackColor.BackColor;
        //////        tmpPainter.LineColor = lblLineColor.BackColor;
        //////        tmpPainter.PaintBack = chkPaintBack.Checked;
        //////        tmpPainter.PaintLine = chkPaintLine.Checked;
        //////        tmpPainter = null;
        //////    }
        //////    this.Close();
        //////}


        
    }
}