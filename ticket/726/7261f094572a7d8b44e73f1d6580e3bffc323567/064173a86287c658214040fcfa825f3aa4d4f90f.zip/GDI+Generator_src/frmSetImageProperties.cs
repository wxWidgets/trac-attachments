using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Shapes;

namespace GDI_Generator
{
    public partial class frmSetImageProperties : Form
    {
        DrawingCanvas refCanvas;
        bool blnSuccess = false;
        public frmSetImageProperties(DrawingCanvas canvas)
        {
            InitializeComponent();
            refCanvas = canvas; //get an object reference
            txtX.Text = refCanvas.shapeManager.BackBitmapBounds.X.ToString();
            txtY.Text = refCanvas.shapeManager.BackBitmapBounds.Y.ToString();
            txtWidth.Text = refCanvas.shapeManager.BackBitmapBounds.Width.ToString();
            txtHeight.Text = refCanvas.shapeManager.BackBitmapBounds.Height.ToString();
            lblFileName.Text = refCanvas.shapeManager.BackBmpFilePath;
        }

        private void btnBrowse_Click(object sender, EventArgs e)
        {
            using (OpenFileDialog ofd = new OpenFileDialog())
            {
                ofd.Filter = "All Files (*.*)|*.*|Bitmap Images (*.bmp|*.bmp|Jpeg Images (*.jpg)|*.jpg|" +
                             "Gif Images (*.gif)|*.gif|Png Images (*.png)|*.png";
                if (ofd.ShowDialog() == DialogResult.OK)
                {
                    try
                    {
                        Bitmap bmp = new Bitmap(ofd.FileName);
                        refCanvas.shapeManager.SetBackBitmap(bmp, ofd.FileName);
                        lblFileName.Text = ofd.FileName;
                        txtWidth.Text = bmp.Width.ToString();
                        txtHeight.Text = bmp.Height.ToString();
                        bmp = null;
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message);
                    }

                }
            }
        }

        private void btnOK_Click(object sender, EventArgs e)
        {
            try
            {
                refCanvas.shapeManager.BackBitmapBounds = new Rectangle(
                    int.Parse(txtX.Text), int.Parse(txtY.Text),
                    int.Parse(txtWidth.Text), int.Parse(txtHeight.Text));
                blnSuccess = true;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                blnSuccess = false;
            }
        }

        private void frmSetImageProperties_FormClosing(object sender, FormClosingEventArgs e)
        {
            e.Cancel = !blnSuccess;
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            refCanvas.shapeManager.SetBackBitmap(null, "");
            lblFileName.Text = "";
        }
    }
}