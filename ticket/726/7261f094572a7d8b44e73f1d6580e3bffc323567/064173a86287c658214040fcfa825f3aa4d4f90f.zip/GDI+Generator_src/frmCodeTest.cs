using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Drawing.Drawing2D;

namespace GDI_Generator
{
    public partial class frmCodeTest : Form
    {
        //MyCustomGraphics.Smiley smiley = new MyCustomGraphics.Smiley();
        public frmCodeTest()
        {
            InitializeComponent();
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            //e.Graphics.DrawImageUnscaled(smiley.Image, 20, 20);
        }

    }
}