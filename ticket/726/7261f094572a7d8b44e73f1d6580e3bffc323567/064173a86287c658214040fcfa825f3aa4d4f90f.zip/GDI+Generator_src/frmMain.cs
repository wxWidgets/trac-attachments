////////////////////////////////////////////////////////////////
//                Created By Richard Blythe 2008
//   There are no licenses or warranty attached to this object.
//   If you distribute the code as part of your application, please
//   be courteous enough to mention the assistance provided you.
////////////////////////////////////////////////////////////////

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Drawing.Drawing2D;
using Shapes;
using System.IO;

namespace GDI_Generator
{
    public partial class frmMain : Form
    {
        DrawingCanvas canvas;
        frmGDIViewer frmViewer = null;

        public frmMain()
        {
            InitializeComponent();

            canvas = new DrawingCanvas();
            canvas.Dock = DockStyle.Fill;
            tsContainer.ContentPanel.Controls.Add(canvas);

            ShapeMenuItem[] items = canvas.shapeManager.GetShapeList();
            short intCount = (short)items.Length;
            for (short i =0;i<intCount;i++)
            {
                ToolStripMenuItem menuItem = new ToolStripMenuItem();
                menuItem.Text = items[i].ShapeName;
                menuItem.Tag = items[i].ShapeType;
                menuItem.Click += new EventHandler(menuItem_Click);
                
                addToolStripMenuItem.DropDownItems.Add(menuItem);
            }

            canvas.MouseMove += new MouseEventHandler(canvas_MouseMove);
            canvas.MouseClick += new MouseEventHandler(canvas_MouseClick);
        }

        void canvas_MouseClick(object sender, MouseEventArgs e)
        {
            paintToolsToolStripMenuItem.Enabled = canvas.shapeManager.ShapeIsSelected();
        }

        void canvas_MouseMove(object sender, MouseEventArgs e)
        {
            tsslMousePos.Text = e.Location.X.ToString() + "," + e.Y.ToString();
        }

        void menuItem_Click(object sender, EventArgs e)
        {
            ToolStripMenuItem menuItem = (ToolStripMenuItem)sender;
            canvas.shapeManager.AddShape((byte)menuItem.Tag);
        }

        private void tsbNodeTool_Click(object sender, EventArgs e)
        {
            if (!tsbNodeTool.Checked)
            {
                tsbNodeTool.Checked = true;
                tsbSelectionTool.Checked = false;
                canvas.shapeManager.CurrentTool = Tools.eTool.Edit;             
            }

        }

        private void tsbSelectionTool_Click(object sender, EventArgs e)
        {
            if (!tsbSelectionTool.Checked)
            {
                tsbNodeTool.Checked = false;
                tsbSelectionTool.Checked = true;
                canvas.shapeManager.CurrentTool = Tools.eTool.Selection;
            }
        }


        private void tsbConvertToCurve_Click(object sender, EventArgs e)
        {
            canvas.shapeManager.DoOperation(eOperation.ConvertToCurve);
        }

        private void tsbConvertToLine_Click(object sender, EventArgs e)
        {
            canvas.shapeManager.DoOperation(eOperation.ConvertToLine);
        }

        private void tsbDeleteNode_Click(object sender, EventArgs e)
        {
            canvas.shapeManager.DoOperation(eOperation.Delete);
        }

        private void tsbSentToBack_Click(object sender, EventArgs e)
        {
            canvas.shapeManager.DoOperation(eOperation.SendToBack);
        }

        private void tsbBringToFront_Click(object sender, EventArgs e)
        {
            canvas.shapeManager.DoOperation(eOperation.BringToFront);
        }

        private void viewGDICodeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (canvas.shapeManager.FileName == "" ||
                canvas.shapeManager.FileName == null)
            {
                if (MessageBox.Show("The GDI+ code is generated as a class file.\r\n" +
                     "The class file name will be the same as the current project name.\r\n" +
                     "However, the current project does not have a name so you will be \r\n" +
                     "directed to the save dialog where you can specify a file name.",
                     "Notice", MessageBoxButtons.OKCancel, MessageBoxIcon.Information)
                    == DialogResult.OK)
                    canvas.Save(false);

            }
            //Make sure the user has specified a file name
            if (canvas.shapeManager.FileName != "")
            {
                if (frmViewer == null)
                {
                    frmViewer = new frmGDIViewer(new GDIGenerationTool(canvas.shapeManager));
                    frmViewer.FormClosed += new FormClosedEventHandler(frmViewer_FormClosed);
                }

                frmViewer.LoadCode();
                frmViewer.Show();
                frmViewer.BringToFront();
            }
        }

        void frmViewer_FormClosed(object sender, FormClosedEventArgs e)
        {
            frmViewer.Dispose();
            frmViewer = null;
        }

        private void propertiesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            canvas.ShowPropertyEditor();
        }

        private void paintToolsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            canvas.ShowColorEditor();
        }

        private void deleteShape_Click(object sender, EventArgs e)
        {
           canvas.shapeManager.DoOperation(eOperation.Delete);
        }

        private void showClippingToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (!canvas.shapeManager.ClipRectIsOn)
            {
                canvas.shapeManager.ClipRectIsOn = true;
                showClippingToolStripMenuItem.Text = "Hide Clipping";
            }
            else
            {
                canvas.shapeManager.ClipRectIsOn = false;
                showClippingToolStripMenuItem.Text = "Show Clipping";
            }
        }

        private void antiAliasToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (!canvas.shapeManager.AntiAlias)
            {
                canvas.shapeManager.AntiAlias = true;
                antiAliasToolStripMenuItem.Text = "Anti-Alias: Off";
            }
            else
            {
                canvas.shapeManager.AntiAlias = false;
                antiAliasToolStripMenuItem.Text = "Anti-Alias: On";
            }
        }

        private void fileMenuItem_Click(object sender, EventArgs e)
        {
            int intTag = Convert.ToInt32(((ToolStripDropDownItem)sender).Tag);

            switch (intTag)
            {
                case 0: //New
                    if (canvas.shapeManager.IsDirty)
                    {
                        if (MessageBox.Show("Would you like to save your work?", "Confirm",
                        MessageBoxButtons.YesNo, MessageBoxIcon.Question)
                         == DialogResult.Yes)
                            canvas.Save(false);
                    }
                    canvas.shapeManager.Dispose();
                    canvas.shapeManager = null;
                    canvas.shapeManager = new ShapeManager(canvas);
                    canvas.Invalidate();
                    if (frmViewer != null)
                    {
                        frmViewer.Close();
                        frmViewer = null;
                    }
                        break;
                case 1: //Open
                    canvas.Open();
                    if (frmViewer != null)
                    {
                        frmViewer.Close();
                        frmViewer = null;
                    }
                    break;
                case 2: //Save
                    canvas.Save(false);
                    break;
                case 3: //Save As...
                    canvas.Save(true);
                    break;
            }
            setMenuText();
            setMainText();
        }

        private void setMenuText()
        {
            if (canvas.shapeManager.ClipRectIsOn)
                showClippingToolStripMenuItem.Text = "Hide Clipping";
            else
                showClippingToolStripMenuItem.Text = "Show Clipping";

            if (canvas.shapeManager.AntiAlias)
                antiAliasToolStripMenuItem.Text = "Anti-Alias: Off";
            else
                antiAliasToolStripMenuItem.Text = "Anti-Alias: On";
        }


        private void setMainText()
        {
            if (canvas.shapeManager.FileName != "")
                this.Text = "GDI+ Generator  -  [" +
                    Path.GetFileNameWithoutExtension(canvas.shapeManager.FileName) + "]";
            else
                this.Text = "GDI+ Generator  -  [Untitled]";
        }

        private void exitToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void frmMain_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (canvas.shapeManager.IsDirty)
            {
                if (MessageBox.Show("Would you like to save your work?", "Confirm",
                    MessageBoxButtons.YesNo, MessageBoxIcon.Question)
                    == DialogResult.Yes)
                    canvas.Save(false);
            }
            if (MessageBox.Show("Are you sure you want to exit?", "Exiting Notice",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question)
                == DialogResult.No)
                e.Cancel = true;
        }

        private void showCodeTestFormToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmInstructions frm = new frmInstructions();
            frm.ShowDialog();
            frm.Dispose();
        }

        private void tsmBackgroundImage_Click(object sender, EventArgs e)
        {
            frmSetImageProperties frm = new frmSetImageProperties(canvas);
            frm.ShowDialog();
            frm.Dispose();
            canvas.Invalidate();
        }
   }
}