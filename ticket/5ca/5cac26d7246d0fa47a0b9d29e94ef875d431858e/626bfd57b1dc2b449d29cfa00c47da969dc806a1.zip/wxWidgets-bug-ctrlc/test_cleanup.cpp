#include <iostream>
#include <windows.h>
#include <string>

class WithStaticInitializers
{
public:
	WithStaticInitializers()
	{
		std::cout << "Static initialization occurs in thread " << ::GetCurrentThreadId() << std::endl;
	}
	
	virtual ~WithStaticInitializers()
	{
		std::cout << "Static cleanup occurs in thread " << ::GetCurrentThreadId() << std::endl;
	}
};
static WithStaticInitializers test;


int main(int argc, char* argv[])
{
	std::cout << "Main thread ID=" << ::GetCurrentThreadId() << std::endl;
	std::cout << "Please hit ENTER to terminate normally, or Ctrl^C to interrupt" << std::endl;
	std::string str;
	std::cin >> str;
	return 0;
}
