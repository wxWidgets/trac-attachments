/////////////////////////////////////////////////////////////////////////////
// Name:        wx/shared_ptr.h
// Purpose:     Shared pointer class.
// Author:      Marius Luca
// Created:     26 June 11
// RCS-ID:      $Id$
// Copyright:   (c) 2011 Marius Luca
// Licence:     wxWindows licence
/////////////////////////////////////////////////////////////////////////////

#ifndef _WX_SHARED_PTR_H_
#define _WX_SHARED_PTR_H_

#include "wx/tracked.h"

// ----------------------------------------------------------------------------
// wxSharedPtr: A smart pointer with non-intrusive reference counting.
// ----------------------------------------------------------------------------
template <class T>
class wxSharedPtr
{
public:
	wxSharedPtr() :
		data(NULL), counter(NULL)
	{
	}

	wxSharedPtr(const wxSharedPtr<T>& r) :
		data(r.get_data()), counter(r.get_counter())
	{
		if (counter != NULL)
			counter->IncRef();
	}

	template <class T2>
	wxSharedPtr(const wxSharedPtr<T2>& r) :
		data(NULL), counter(NULL)
	{
		data = dynamic_cast<T*>(r.get_data());
		if (data != NULL)
			counter = r.get_counter();
		if (counter != NULL)
			counter->IncRef();
	}

	wxSharedPtr(T* newData, wxShareCounter* newCounter) :
		data(newData), counter(newCounter)
	{
		if (counter != NULL)
		{
			if (!counter->IncRefLock())
			{
				counter = NULL;
				data = NULL;
			}
		}
	}

	wxSharedPtr(T* newData) :
		data(NULL), counter(NULL)
	{
		Reset(newData);
	}

	~wxSharedPtr()
	{
		if (counter != NULL)
		{
			if (counter->DecRef())
				FreeData();
			counter = NULL;
		}
		data = NULL;
	}

	wxSharedPtr<T>& operator = (const wxSharedPtr<T>& r)
	{
		if (counter != NULL)
		{
			if (counter->DecRef())
				FreeData();
			counter = NULL;
		}

		data = r.get_data();
		counter = r.get_counter();
		if (counter != NULL)
			counter->IncRef();

		return *this;
	}

	template <class T2>
	wxSharedPtr<T>& operator = (const wxSharedPtr<T2>& r)
	{
		if (counter != NULL)
		{
			if (counter->DecRef())
				FreeData();
			counter = NULL;
		}

		data = dynamic_cast<T*>(r.get_data());
		if (data != NULL)
			counter = r.get_counter();
		if (counter != NULL)
			counter->IncRef();

		return *this;
	}

	wxInt32 GetRefCount() const
	{
		if (counter == NULL)
			return 0;
		return counter->GetRefCount();
	}

	void Reset()
	{
		if (counter != NULL)
		{
			if (counter->DecRef())
				FreeData();
			counter = NULL;
		}
		data = NULL;
	}

protected:
	void ResetTracker(T*, ...)
	{
	}

	template<class T2>
	void ResetTracker(T*, wxTracked<T2>* tracker)
	{
		tracker->_internal_set_weak_ref(get_weak_ref());
	}
public:
	void Reset(T* newData)
	{
		Reset();
		if (newData != NULL)
		{
			counter = new wxShareCounter();
			data = newData;
			ResetTracker(data, data);
		}
	}

	T * operator-> () const
	{
		if (counter == NULL)
			return NULL;
		return data;
	}

	T * get() const
	{
		if (counter == NULL)
			return NULL;
		return data;
	}

	T* get_data() const
	{
		return data;
	}

	wxShareCounter* get_counter() const
	{
		return counter;
	}

	operator bool () const
	{
		if (counter == NULL)
			return false;
		return data != NULL;
	}

	bool operator !() const
	{
		if (counter == NULL)
			return true;
		return data == NULL;
	}

	bool operator == (const wxSharedPtr<T>& r) const
	{
		return counter == r.get_counter();
	}

	bool operator == (const wxWeakPtr<T>& r) const
	{
		return counter == r.get_counter();
	}

	bool operator != (const wxSharedPtr<T>& r) const
	{
		return counter != r.get_counter();
	}

	bool operator != (const wxWeakPtr<T>& r) const
	{
		return counter != r.get_counter();
	}

	bool operator < (const wxSharedPtr<T>& r) const
	{
		return counter < r.get_counter();
	}

	bool operator < (const wxWeakPtr<T>& r) const
	{
		return counter < r.get_counter();
	}

	bool operator <= (const wxSharedPtr<T>& r) const
	{
		return counter <= r.get_counter();
	}

	bool operator <= (const wxWeakPtr<T>& r) const
	{
		return counter <= r.get_counter();
	}

	bool operator > (const wxSharedPtr<T>& r) const
	{
		return counter > r.get_counter();
	}

	bool operator > (const wxWeakPtr<T>& r) const
	{
		return counter > r.get_counter();
	}

	bool operator >= (const wxSharedPtr<T>& r) const
	{
		return counter >= r.get_counter();
	}

	bool operator >= (const wxWeakPtr<T>& r) const
	{
		return counter >= r.get_counter();
	}

	wxWeakPtr<T> get_weak_ref()
	{
		return wxWeakPtr<T>(*this);
	}

private:
	void FreeData()
	{
		if (data != NULL)
		{
			delete data;
			data = NULL;
		}
	}

	T*				data;
	wxShareCounter*	counter;
};

#endif // _WX_SHARED_PTR_H_
