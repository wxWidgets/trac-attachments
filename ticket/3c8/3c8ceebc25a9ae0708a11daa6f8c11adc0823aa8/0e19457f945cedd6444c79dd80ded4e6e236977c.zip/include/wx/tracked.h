/////////////////////////////////////////////////////////////////////////////
// Name:        wx/tracked.h
// Purpose:     Support class for object lifetime tracking (wxSharedPtr<T>/wxWeakPtr<T>)
// Author:      Marius Luca
// Created:     26 June 11
// RCS-ID:      $Id$
// Copyright:   (c) 2011 Marius Luca
// Licence:     wxWindows licence
/////////////////////////////////////////////////////////////////////////////

#ifndef _WX_TRACKED_H_
#define _WX_TRACKED_H_

#include "wx/shared_ctr.h"

template <class T> class wxSharedPtr;
template <class T> class wxWeakPtr;

template <class T>
class wxTracked
{
protected:
	friend class wxSharedPtr<T>;
	friend class wxWeakPtr<T>;
	wxTracked(){}
public:

	void _internal_set_weak_ref(wxWeakPtr<T> wr)
	{
		_internal_weak_ref = wr;
	}

	wxWeakPtr<T> weakshare() const
	{
		return _internal_weak_ref;
	}

	wxSharedPtr<T> share() const
	{
		return _internal_weak_ref.lock();
	}

protected:
	wxWeakPtr<T> mutable _internal_weak_ref;
};

#endif // _WX_TRACKED_H_

