/////////////////////////////////////////////////////////////////////////////
// Name:        wx/shared_ctr.h
// Purpose:     Counter class used to keep track of weak/strong reference
// Author:      Marius Luca
// Created:     26 June 11
// RCS-ID:      $Id$
// Copyright:   (c) 2011 Marius Luca
// Licence:     wxWindows licence
/////////////////////////////////////////////////////////////////////////////

#ifndef _WX_SHARED_CTR_H_
#define _WX_SHARED_CTR_H_

#include "wx/defs.h"
#include "wx/atomic.h"

class WXDLLIMPEXP_BASE wxShareCounter
{
public:
    explicit wxShareCounter();

	wxInt32 GetRefCount() const;
	bool IsRef() const;
	void IncRef();
	bool IncRefLock();
	bool DecRef();
	
	wxInt32 GetWeakRefCount() const;
	bool IsWeakRef() const;
	void IncWeakRef();
	bool DecWeakRef();

private:
	wxAtomicInt m_count;
	wxAtomicInt m_weak_count;
};

#endif // _WX_SHARED_CTR_H_
