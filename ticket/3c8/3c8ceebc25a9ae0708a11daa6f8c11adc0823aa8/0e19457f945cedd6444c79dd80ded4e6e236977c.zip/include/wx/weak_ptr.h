/////////////////////////////////////////////////////////////////////////////
// Name:        wx/weak_ptr.h
// Purpose:     Weak pointer class.
// Author:      Marius Luca
// Created:     26 June 11
// RCS-ID:      $Id$
// Copyright:   (c) 2011 Marius Luca
// Licence:     wxWindows licence
/////////////////////////////////////////////////////////////////////////////

#ifndef _WX_WEAK_PTR_H_
#define _WX_WEAK_PTR_H_

#include "wx/tracked.h"

template <class T>
class wxWeakPtr
{
public:
	wxWeakPtr() :
		data(NULL), counter(NULL)
	{
	}

	wxWeakPtr(const wxSharedPtr<T>& r) :
		data(r.get_data()), counter(r.get_counter())
	{
		if (counter != NULL)
			counter->IncWeakRef();
	}

	template <class T2>
	wxWeakPtr(const wxSharedPtr<T2>& r) :
		data(NULL), counter(NULL)
	{
		data = dynamic_cast<T*>(r.get_data());
		if (data != NULL)
			counter = r.get_counter();
		if (counter != NULL)
			counter->IncWeakRef();
	}

	wxWeakPtr(const wxWeakPtr<T>& r) :
		data(r.get_data()), counter(r.get_counter())
	{
		if (counter != NULL)
			counter->IncWeakRef();
	}

	template <class T2>
	wxWeakPtr(const wxWeakPtr<T2>& r) :
		data(NULL), counter(NULL)
	{
		data = dynamic_cast<T*>(r.get_data());
		if (data != NULL)
			counter = r.get_counter();
		if (counter != NULL)
			counter->IncWeakRef();
	}

	~wxWeakPtr()
	{
		if (counter != NULL)
		{
			counter->DecWeakRef();
			counter = NULL;
		}
		data = NULL;
	}

	wxWeakPtr<T>& operator = (const wxSharedPtr<T>& r)
	{
		if (counter != NULL)
		{
			counter->DecWeakRef();
			counter = NULL;
		}

		data = r.get_data();
		counter = r.get_counter();
		if (counter != NULL)
			counter->IncWeakRef();

		return *this;
	}

	template <class T2>
	wxWeakPtr<T>& operator = (const wxSharedPtr<T2>& r)
	{
		if (counter != NULL)
		{
			counter->DecWeakRef();
			counter = NULL;
		}

		data = dynamic_cast<T*>(r.get_data());
		if (data != NULL)
			counter = r.get_counter();
		if (counter != NULL)
			counter->IncWeakRef();

		return *this;
	}

	wxWeakPtr<T>& operator = (const wxWeakPtr<T>& r)
	{
		if (counter != NULL)
		{
			counter->DecWeakRef();
			counter = NULL;
		}

		data = r.get_data();
		counter = r.get_counter();
		if (counter != NULL)
			counter->IncWeakRef();

		return *this;
	}

	template <class T2>
	wxWeakPtr<T>& operator = (const wxWeakPtr<T2>& r)
	{
		if (counter != NULL)
		{
			counter->DecWeakRef();
			counter = NULL;
		}

		data = dynamic_cast<T*>(r.get_data());
		if (data != NULL)
			counter = r.get_counter();
		if (counter != NULL)
			counter->IncWeakRef();

		return *this;
	}

	wxInt32 GetRefCount() const
	{
		if (counter == NULL)
			return 0;
		return counter->GetRefCount();
	}

	void Reset()
	{
		if (counter != NULL)
		{
			counter->DecWeakRef();
			counter = NULL;
		}
		data = NULL;
	}

	void Reset(const wxSharedPtr<T>* r)
	{
		Reset();
		if (r != NULL)
		{
			counter = r->get_counter();
			data = r->data;
		}
		if (counter != NULL)
			counter->IncWeakRef();
	}

	bool expired() const
	{
		return counter == NULL || !counter->IsRef();
	}

	T* get_data() const
	{
		return data;
	}

	wxShareCounter* get_counter() const
	{
		return counter;
	}

	operator bool () const
	{
		if (counter == NULL || !counter->IsRef())
			return false;
		return data != NULL;
	}

	bool operator !() const
	{
		if (counter == NULL || !counter->IsRef())
			return true;
		return data == NULL;
	}

	bool operator == (const wxWeakPtr<T>& r) const
	{
		return counter == r.get_counter();
	}

	bool operator == (const wxSharedPtr<T>& r) const
	{
		return counter == r.get_counter();
	}

	bool operator != (const wxWeakPtr<T>& r) const
	{
		return counter != r.get_counter();
	}

	bool operator != (const wxSharedPtr<T>& r) const
	{
		return counter != r.get_counter();
	}

	bool operator < (const wxSharedPtr<T>& r) const
	{
		return counter < r.get_counter();
	}

	bool operator < (const wxWeakPtr<T>& r) const
	{
		return counter < r.get_counter();
	}

	bool operator <= (const wxSharedPtr<T>& r) const
	{
		return counter <= r.get_counter();
	}

	bool operator <= (const wxWeakPtr<T>& r) const
	{
		return counter <= r.get_counter();
	}

	bool operator > (const wxSharedPtr<T>& r) const
	{
		return counter > r.get_counter();
	}

	bool operator > (const wxWeakPtr<T>& r) const
	{
		return counter > r.get_counter();
	}

	bool operator >= (const wxSharedPtr<T>& r) const
	{
		return counter >= r.get_counter();
	}

	bool operator >= (const wxWeakPtr<T>& r) const
	{
		return counter >= r.get_counter();
	}

	wxSharedPtr<T> lock() const
	{
		return wxSharedPtr<T>(data, counter);
	}

private:
	T*				data;
	wxShareCounter*	counter;
};

#endif // _WX_WEAK_PTR_H_

