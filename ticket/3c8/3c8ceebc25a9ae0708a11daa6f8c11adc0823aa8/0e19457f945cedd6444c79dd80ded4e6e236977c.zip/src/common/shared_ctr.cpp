/////////////////////////////////////////////////////////////////////////////
// Name:        src/common/shared_ctr.cpp
// Purpose:     Counter class used to keep track of weak/strong reference
// Author:      Marius Luca
// Created:     26 June 11
// RCS-ID:      $Id$
// Copyright:   (c) 2011 Marius Luca
// Licence:     wxWindows licence
/////////////////////////////////////////////////////////////////////////////

// For compilers that support precompilation, includes "wx.h".
#include "wx/wxprec.h"

#ifdef __BORLANDC__
    #pragma hdrstop
#endif

#ifndef WX_PRECOMP
    #include "wx/shared_ctr.h"
#endif

wxShareCounter::wxShareCounter()
	: m_count(1), m_weak_count(1)
{
}

wxInt32 wxShareCounter::GetRefCount() const
{
	return m_count;
}

bool wxShareCounter::IsRef() const
{
	return m_count > 0;
}

void wxShareCounter::IncRef()
{
	wxAtomicInc(m_count);
}

bool wxShareCounter::IncRefLock()
{
	for( ;; )
	{
		wxInt32 tmp = static_cast< wxInt32 const volatile& >(m_count);
		if( tmp == 0 )
			return false;
		if(wxAtomicCompAndSwap(m_count, tmp, tmp + 1))
			return true;
	}
}

bool wxShareCounter::DecRef()
{
	wxAtomicDec(m_count);
	if (m_count == 0)
	{
		wxAtomicDec(m_weak_count);
		if (m_weak_count == 0)
			delete this;
		return true;
	}
	return false;
}

wxInt32 wxShareCounter::GetWeakRefCount() const
{
	return m_weak_count;
}

bool wxShareCounter::IsWeakRef() const
{
	return m_weak_count > 0;
}

void wxShareCounter::IncWeakRef()
{
	wxAtomicInc(m_weak_count);
}

bool wxShareCounter::DecWeakRef()
{
	wxAtomicInc(m_weak_count);
	if (m_weak_count == 0)
	{
		delete this;
		return true;
	}
	return false;
}
