#include "TP1_2.h"

#define wxID_rBOX wxID_HIGHEST+1

BEGIN_EVENT_TABLE(TP1_2, wxFrame)
	//EVT_CLOSE(TP1_2::OnClose)
	EVT_RADIOBOX(wxID_rBOX, TP1_2::repRadioBox)
END_EVENT_TABLE()

TP1_2::TP1_2(const wxString &title) : wxFrame(NULL, wxID_ANY, title)
{
	dlg = new wxMessageDialog(this, "Voulez-vous vraiment quitter ?", "Confirmation");

	wxString choix[] = {"Sourit", "Pleure", "Chante"};
	radioBox = new wxRadioBox(this, wxID_rBOX, "Toto", wxDefaultPosition, wxDefaultSize, 3, choix, 0, wxVERTICAL);

	pleure = wxBitmap("pleure.bmp", wxBITMAP_TYPE_BMP);
	sourit = wxBitmap("sourit.bmp", wxBITMAP_TYPE_BMP);
	chante = wxBitmap("chante.bmp", wxBITMAP_TYPE_BMP);
	image = new wxStaticBitmap(this, wxID_ANY, sourit);

	box = new wxBoxSizer(wxHORIZONTAL);

	box->Add(radioBox);
	box->Add(image);
	
	SetSizer(box);
}

void TP1_2::repRadioBox(wxCommandEvent &WXUNUSED(evt))
{
	switch(radioBox->GetSelection())
	{
		case 0: image->SetBitmap(sourit); image->Update(); break;
		case 1: image->SetBitmap(pleure); image->Update(); break;
		case 2: image->SetBitmap(chante); image->Update(); break;
	}
	Refresh();
}

void TP1_2::OnClose(wxCloseEvent &evt)
{
	dlg->ShowModal();
	this-Close();
}
