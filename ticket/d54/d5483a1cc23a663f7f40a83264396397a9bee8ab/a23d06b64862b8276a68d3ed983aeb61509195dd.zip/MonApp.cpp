#include "MonApp.h"
//#include "MaFenetre.h"
//#include "TP1_1_2.h"
#include "TP1_2.h"

IMPLEMENT_APP(MonApp);

bool MonApp::OnInit()
{
	//MaFenetre *fen = new MaFenetre(wxT("Ma premi�re application"));
	//TP1_2 *fen = new TP1_1_2(wxT("Une calculatrice simple"));
	TP1_2 *fen = new TP1_2(wxT("Un peu de dessin"));

	fen->Show(true);
	return true;
}

int MonApp::OnExit()
{
	return 0;
}
