#ifndef __TP1_2_H
#define __TP1_2_H

#include <wx/wxprec.h>

#ifndef WX_PRECOMP
#include <wx/wx.h>
#endif


class TP1_2 : public wxFrame
{
public:
	TP1_2(const wxString& title);
	void repRadioBox(wxCommandEvent& evt);
	void OnClose(wxCloseEvent& evt);

private:
	wxBitmap pleure, sourit, chante;
	wxStaticBitmap *image;
	wxRadioBox *radioBox;
	wxBoxSizer *box;
	wxMessageDialog *dlg;

	//void repRadioBox(wxCommandEvent& evt);

	DECLARE_EVENT_TABLE()
};

#endif
