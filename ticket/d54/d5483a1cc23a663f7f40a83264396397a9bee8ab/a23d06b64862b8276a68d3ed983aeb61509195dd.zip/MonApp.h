#ifndef __MONAPP_H
#define __MONAPP_H

#include <wx/wxprec.h>

#ifndef WX_PRECOMP
#include <wx/wx.h>
#endif


class MonApp : public wxApp
{
public:
	//wxCHMHelperController *m_help;

	virtual bool OnInit();
	virtual int OnExit();

};

#endif
