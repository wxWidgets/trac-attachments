
/*
    If you use precompiled headers, you won't be able to 
    walk into certain inline code using the debugger.  This in 
    particular affects inline functions defined in the 
    ANSI C++ headers, along with some (but not all) of the 
    inlines in the wxWindows headers. 
    
    If you don't use precompiled headers, your compiles can be 
    VERY long.  But then you will be able to walk into ALL the 
    inline functions, regardless of where they are defined.
    
    Use the #define below to select between the two options
*/


// #define DO_NOT_USE_PRECOMPILED_HDRS_FOR_WX        1



#ifdef DO_NOT_USE_PRECOMPILED_HDRS_FOR_WX
    #include <wx/wx_cw_d_no_mch.h>
#else
    #include <wx/wx_cw_d.h>
#endif
    