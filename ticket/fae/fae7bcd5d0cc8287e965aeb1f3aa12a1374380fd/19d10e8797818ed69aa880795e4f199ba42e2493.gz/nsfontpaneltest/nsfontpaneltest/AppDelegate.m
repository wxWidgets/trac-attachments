//
//  AppDelegate.m
//  nsfontpaneltest
//
//  Created by MessageNet on 6/1/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "AppDelegate.h"

@interface MacFontPanelAccView : NSView
{
BOOL m_okPressed ;
BOOL m_shouldClose ;
NSButton* m_cancelButton ;
NSButton* m_okButton ;
}

- (IBAction)cancelPressed:(id)sender;
- (IBAction)okPressed:(id)sender;
- (void)resetFlags;
- (BOOL)closedWithOk;
- (BOOL)shouldCloseCarbon;
- (NSButton*)okButton;
@end

@implementation MacFontPanelAccView : NSView
- (id)initWithFrame:(NSRect)rectBox
{
self = [super initWithFrame:rectBox];

CFStringRef cfOkString = CFSTR( "OK" );
CFStringRef cfCancelString = CFSTR( "Cancel" );

NSRect rectCancel = NSMakeRect( (CGFloat) 10.0 , (CGFloat)10.0 , (CGFloat)82  , (CGFloat)24 );
NSRect rectOK = NSMakeRect( (CGFloat)100.0 , (CGFloat)10.0 , (CGFloat)82  , (CGFloat)24 );

NSButton* cancelButton = [[NSButton alloc] initWithFrame:rectCancel];
[cancelButton setTitle:(__bridge NSString*)((CFStringRef)cfCancelString)];
[cancelButton setBezelStyle:NSRoundedBezelStyle];
[cancelButton setButtonType:NSMomentaryPushInButton];
[cancelButton setAction:@selector(cancelPressed:)];
[cancelButton setTarget:self];
m_cancelButton = cancelButton ;

NSButton* okButton = [[NSButton alloc] initWithFrame:rectOK];
[okButton setTitle:(__bridge NSString*)((CFStringRef)cfOkString)];
[okButton setBezelStyle:NSRoundedBezelStyle];
[okButton setButtonType:NSMomentaryPushInButton];
[okButton setAction:@selector(okPressed:)];
[okButton setTarget:self];
// doesn't help either, the button is not highlighted after a color dialog has been used
// [okButton setKeyEquivalent:@"\r"];
m_okButton = okButton ;


[self addSubview:cancelButton];
[self addSubview:okButton];

[self resetFlags];
return self;
}

- (void)resetFlags
{
    m_okPressed = NO ;
    m_shouldClose = NO ;
}

- (IBAction)cancelPressed:(id)sender
{
    m_shouldClose = YES ;
    [NSApp stopModal];
}

- (IBAction)okPressed:(id)sender
{
    m_okPressed = YES ;
    m_shouldClose = YES ;
    [NSApp stopModal];
}

-(BOOL)closedWithOk
{
    return m_okPressed ;
}

-(BOOL)shouldCloseCarbon
{
    return m_shouldClose ;
}

-(NSButton*)okButton
{
    return m_okButton ;
}
@end

@implementation AppDelegate

@synthesize window = _window;

- (void)applicationDidFinishLaunching:(NSNotification *)aNotification
{
    // Insert code here to initialize your application
    do {
        {
        NSFontPanel *fontPanel = [[NSFontManager sharedFontManager] fontPanel:YES];
        
        [fontPanel setFloatingPanel:NO] ;

        [[fontPanel standardWindowButton:NSWindowCloseButton] setEnabled:NO] ;        
        MacFontPanelAccView* accessoryView = (MacFontPanelAccView*) [fontPanel accessoryView] ;
        if ( accessoryView == nil)
        {
            NSRect rectBox = NSMakeRect( 0 , 0 , 192 , 40 );
            accessoryView = [[MacFontPanelAccView alloc] initWithFrame:rectBox];
            [fontPanel setAccessoryView:accessoryView];
            
            [fontPanel setDefaultButtonCell:[[accessoryView okButton] cell]] ;
        }
        
        [accessoryView resetFlags];
        
        [NSApp runModalForWindow:fontPanel];
        
        [[fontPanel standardWindowButton:NSWindowCloseButton] setEnabled:YES] ;
        [fontPanel close];
        
        if ( [accessoryView closedWithOk])
        {
            //NSFont* theFont = [fontPanel panelConvertFont:[NSFont userFontOfSize:0]];;

            
            //Get the shared color panel along with the chosen color and set the chosen color
            //NSColor* theColor = [[[NSColorPanel sharedColorPanel] color] colorUsingColorSpaceName:NSCalibratedRGBColorSpace];
            
        }
        [fontPanel setAccessoryView:nil];
            
        sleep(2);
        }

    } while (1);
}
@end
