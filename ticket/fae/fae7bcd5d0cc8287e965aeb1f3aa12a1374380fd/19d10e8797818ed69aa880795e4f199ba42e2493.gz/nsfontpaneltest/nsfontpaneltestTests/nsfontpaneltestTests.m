//
//  nsfontpaneltestTests.m
//  nsfontpaneltestTests
//
//  Created by MessageNet on 6/1/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "nsfontpaneltestTests.h"

@implementation nsfontpaneltestTests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testExample
{
    STFail(@"Unit tests are not implemented yet in nsfontpaneltestTests");
}

@end
