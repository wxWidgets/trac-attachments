//
//  nsfontpaneltestTests.h
//  nsfontpaneltestTests
//
//  Created by MessageNet on 6/1/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface nsfontpaneltestTests : SenTestCase

@end
