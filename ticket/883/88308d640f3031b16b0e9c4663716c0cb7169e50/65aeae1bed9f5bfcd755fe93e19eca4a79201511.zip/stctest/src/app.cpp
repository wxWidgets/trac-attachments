// For compilers that support precompilation, includes <wx/wx.h>.
#include <wx/wxprec.h>

#ifdef __BORLANDC__
    #pragma hdrstop
#endif

// for all others, include the necessary headers (this file is usually all you
// need because it includes almost all 'standard' wxWindows headers)
#ifndef WX_PRECOMP
    #include <wx/wx.h>
#endif

//! wxWindows headers
#include <wx/notebook.h> // notebook support

//! wxWindows/contrib headers
#include <wx/stc/stc.h>  // styled text control

// the application icon (under Windows and OS/2 it is in resources)
#if defined(__WXGTK__) || defined(__WXMOTIF__) || defined(__WXMAC__) || defined(__WXMGL__) || defined(__WXX11__)
    #include "mondrian.xpm"
#endif

//============================================================================
// declarations
//============================================================================

class Editor;

//----------------------------------------------------------------------------
//! application APP_VENDOR-APP_NAME.
class App: public wxApp {
    friend class AppFrame;

public:
    //! the main function called durning application start
    virtual bool OnInit ();

    //! application exit function
    virtual int OnExit ();

private:
    //! frame window
    AppFrame* m_frame;

};

// created dynamically by wxWindows
DECLARE_APP (App);

//----------------------------------------------------------------------------
//! frame of the application APP_VENDOR-APP_NAME.
class AppFrame: public wxFrame {
    friend class App;

public:
    //! constructor
    AppFrame (const wxString &title);

    //! destructor
    ~AppFrame ();

    //! event handlers
    void OnClose (wxCloseEvent &event);

private:
    // edit object
    Editor *m_edit;

    //! notebook page
    wxNotebook *m_book;

    DECLARE_EVENT_TABLE()
};

//----------------------------------------------------------------------------
//! Editor
class Editor: public wxStyledTextCtrl {

public:
    //! constructor
    Editor (wxWindow *parent, wxWindowID id = -1,
            const wxPoint &pos = wxDefaultPosition,
            const wxSize &size = wxDefaultSize,
            long style = wxSUNKEN_BORDER|wxVSCROLL
           );

    //! destructor
    ~Editor ();

private:
};


//============================================================================
// implementation
//============================================================================

IMPLEMENT_APP (App)

//----------------------------------------------------------------------------
// App
//----------------------------------------------------------------------------

bool App::OnInit () {

    // set application and vendor name
    SetAppName (_T("STC-Test"));
    SetVendorName (_T("wxWindows"));

    // create application frame
    m_frame = new AppFrame (_T("STC-Test"));

    // open application frame
    m_frame->Layout ();
    m_frame->Show (true);
    SetTopWindow (m_frame);

    return true;
}

int App::OnExit () {

    return 0;
}

//----------------------------------------------------------------------------
// AppFrame
//----------------------------------------------------------------------------

BEGIN_EVENT_TABLE (AppFrame, wxFrame)
    // common
    EVT_CLOSE (                      AppFrame::OnClose)
END_EVENT_TABLE ()

AppFrame::AppFrame (const wxString &title)
        : wxFrame ((wxFrame *)NULL, -1, title, wxDefaultPosition, wxSize(600,400),
                    wxDEFAULT_FRAME_STYLE | wxNO_FULL_REPAINT_ON_RESIZE) {

    // intitialize important variables
    m_edit = NULL;

    // initialize notebook
    m_book = new wxNotebook (this, -1, wxDefaultPosition, wxDefaultSize,
                             wxNB_FIXEDWIDTH);

    // open first page
    m_edit = new Editor (m_book, -1);
    m_book->AddPage (m_edit, _T("<untitled>"), true);

}

AppFrame::~AppFrame () {
    delete m_book;
}

// common event handlers
void AppFrame::OnClose (wxCloseEvent &event) {
    Destroy();
}

//----------------------------------------------------------------------------
// Editor
//----------------------------------------------------------------------------

Editor::Editor (wxWindow *parent, wxWindowID id,
                const wxPoint &pos,
                const wxSize &size,
                long style)
      : wxStyledTextCtrl (parent, id, pos, size, style) {

}

Editor::~Editor () {}
