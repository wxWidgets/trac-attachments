This "ja.po" file is the update version of wxstd.po with Japanese.
Please replace (the root of wxWidgets)/locale/ja.po by this file.

Suzumizaki-Kimitaka
suzumizaki@free.japandesign.ne.jp

July 14, 2006