//---------------------------------------------------------------------------
//
// Name:        PersoneApp.h
// Author:      Stefano Guardigli
// Created:     05/12/2010 16.06.01
// Description: 
//
//---------------------------------------------------------------------------

#ifndef __PERSONEFRMApp_h__
#define __PERSONEFRMApp_h__

#ifdef __BORLANDC__
	#pragma hdrstop
#endif

#ifndef WX_PRECOMP
	#include <wx/wx.h>
#else
	#include <wx/wxprec.h>
#endif

class PersoneFrmApp : public wxApp
{
	public:
		bool OnInit();
		int OnExit();
};

#endif
