//---------------------------------------------------------------------------
//
// Name:        PersoneApp.cpp
// Author:      Stefano Guardigli
// Created:     05/12/2010 16.06.01
// Description: 
//
//---------------------------------------------------------------------------

#include "PersoneApp.h"
#include "PersoneFrm.h"

IMPLEMENT_APP(PersoneFrmApp)

bool PersoneFrmApp::OnInit()
{
    PersoneFrm* frame = new PersoneFrm(NULL);
    SetTopWindow(frame);
    frame->Show();
    return true;
}
 
int PersoneFrmApp::OnExit()
{
	return 0;
}
