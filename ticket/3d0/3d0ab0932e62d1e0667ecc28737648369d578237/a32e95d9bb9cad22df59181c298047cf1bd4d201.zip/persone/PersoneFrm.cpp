///-----------------------------------------------------------------
///
/// @file      PersoneFrm.cpp
/// @author    Stefano Guardigli
/// Created:   05/12/2010 16.06.02
/// @section   DESCRIPTION
///            PersoneFrm class implementation
///
///------------------------------------------------------------------

#include "PersoneFrm.h"

//Do not add custom headers between
//Header Include Start and Header Include End
//wxDev-C++ designer will remove them
////Header Include Start
////Header Include End

//----------------------------------------------------------------------------
// PersoneFrm
//----------------------------------------------------------------------------
//Add Custom Events only in the appropriate block.
//Code added in other places will be removed by wxDev-C++
////Event Table Start
BEGIN_EVENT_TABLE(PersoneFrm,wxFrame)
	////Manual Code Start
	////Manual Code End
	
	EVT_CLOSE(PersoneFrm::OnClose)
END_EVENT_TABLE()
////Event Table End

PersoneFrm::PersoneFrm(wxWindow *parent, wxWindowID id, const wxString &title, const wxPoint &position, const wxSize& size, long style)
: wxFrame(parent, id, title, position, size, style)
{

	m_DbConnectInf.SetDsn("persone");
	if (!m_DbConnectInf.AllocHenv())
    {
        wxMessageBox("Unable to allocate an ODBC environment handle",
                     "DB CONNECTION ERROR", wxOK | wxICON_EXCLAMATION);
    }
    m_Db = new wxDb(m_DbConnectInf.GetHenv());
    
    bool opened = m_Db->Open(&m_DbConnectInf);
    if (opened) 
    {
         //wxMessageBox("Hooray! database is open!");
        // First step, let's define wxDbTable
    	int numColumns = 4;
	    m_table = new wxDbTable (m_Db, "Persone", numColumns);
    	int int_var;
	    wxChar string_cognome[30];
	    wxChar string_nome[30];
	    wxChar string_sesso[2];
	    m_table->SetColDefs (0, "Id", DB_DATA_TYPE_INTEGER, &int_var,SQL_C_LONG, sizeof(int_var), true);
	    m_table->SetColDefs(1, "Cognome", DB_DATA_TYPE_VARCHAR, &string_cognome, SQL_C_CHAR, sizeof(string_cognome), false);
	    m_table->SetColDefs(2, "Nome", DB_DATA_TYPE_VARCHAR, &string_nome, SQL_C_CHAR, sizeof(string_nome), false);
	    m_table->SetColDefs(3, "Sesso", DB_DATA_TYPE_VARCHAR, &string_sesso, SQL_C_CHAR, sizeof(string_sesso), false);
	    m_columns = new wxDbGridColInfo(0, wxGRID_VALUE_LONG, "Id",
                        new wxDbGridColInfo(1, wxGRID_VALUE_STRING, "Cognome",
                        new wxDbGridColInfo(2, wxGRID_VALUE_STRING, "Nome",
                        new wxDbGridColInfo(3, wxGRID_VALUE_STRING, "Sesso",NULL))));
        m_table->Open();
        m_table->SetRowMode (wxDbTable::WX_ROW_MODE_QUERY);
        m_table->Query();
        m_dbgrid = new wxDbGridTableBase(m_table, m_columns, wxUSE_QUERY, true);
        delete m_columns;  // not needed anymore
        m_grid = new wxGrid( this,
                       -1,
                       wxPoint( 0, 0 ),
                       wxSize( 140, 200 ) );


        m_grid->SetTable(m_dbgrid, true);
        m_grid->Fit();
    }
    	CreateGUIControls();
}

PersoneFrm::~PersoneFrm()
{
}

void PersoneFrm::CreateGUIControls()
{
	//Do not add custom code between
	//GUI Items Creation Start and GUI Items Creation End
	//wxDev-C++ designer will remove them.
	//Add the custom code before or after the blocks
	////GUI Items Creation Start

	SetTitle(wxT("Persone"));
	SetIcon(wxNullIcon);
	SetSize(8,8,534,334);
	Center();
	
	////GUI Items Creation End
}

void PersoneFrm::OnClose(wxCloseEvent& event)
{
	Destroy();
}
