// For compilers that support precompilation, includes "wx/wx.h".
#include "wx/wxprec.h"
#include <wx/settings.h>
#include <wx/xrc/xmlres.h>
#include <wx/xrc/xh_bmp.h>
#include <wx/frame.h>
#include <wx/iconbndl.h>
#include <wx/artprov.h>
#include <wx/sizer.h>
#include <wx/aui/framemanager.h>
#include <wx/aui/dockart.h>
#include <wx/panel.h>
#include <wx/notebook.h>
#include <wx/imaglist.h>
#include <wx/richtext/richtextctrl.h>

#include <wx/statbox.h>
#include <wx/stattext.h>
#include <wx/textctrl.h>
#include <wx/choice.h>
#include <wx/arrstr.h>
#include <wx/listctrl.h>
#include <wx/scrolwin.h>

#include <wx/pen.h>
#include <wx/aui/auibar.h>
#include <map>
#include <wx/menu.h>
#include <wx/toolbar.h>
#include <wx/combobox.h>
#include <wx/spinctrl.h>
#include <wx/statusbr.h>
#if wxVERSION_NUMBER >= 2900
#include <wx/persist.h>
#include <wx/persist/toplevel.h>
#include <wx/persist/bookctrl.h>
#include <wx/persist/treebook.h>
#endif

#ifdef WXC_FROM_DIP
#undef WXC_FROM_DIP
#endif
#if wxVERSION_NUMBER >= 3100
#define WXC_FROM_DIP(x) wxWindow::FromDIP(x, NULL)
#else
#define WXC_FROM_DIP(x) x
#endif
#ifdef __BORLANDC__
    #pragma hdrstop
#endif
#if !defined( wxUSE_UNICODE )
#define wxUSE_UNICODE 1
#endif
#if !defined( wxUNICODE )
#define wxUNICODE
#endif
// for all others, include the necessary headers (this file is usually all you
// need because it includes almost all "standard" wxWidgets headers)
#ifndef WX_PRECOMP
    #include "wx/wx.h"
#endif

#include <wx/aui/aui.h>
#include <wx/aui/framemanager.h>

class MyFrame : public wxFrame
{
    public:
        MyFrame( wxWindow* parent, int id = wxID_ANY, wxString title = "Demo"
                , wxPoint pos = wxDefaultPosition, wxSize size = wxDefaultSize
                , int style = wxDEFAULT_FRAME_STYLE|wxTAB_TRAVERSAL );
        ~MyFrame();
         wxString        m_wsLogPaneInfo;
    private:
        void OnCheck( wxCommandEvent& event );
        wxAuiManager m_mgr;
};


MyFrame::MyFrame( wxWindow* parent, int id, wxString title, wxPoint pos
                 , wxSize size, int style )
        :wxFrame( parent, id, title, pos, size, style )
{
    m_mgr.SetManagedWindow(this);
    m_mgr.SetFlags(wxAUI_MGR_DEFAULT|wxAUI_MGR_LIVE_RESIZE);

    wxPanel* pan = new wxPanel(this);
    wxCheckBox* check = new wxCheckBox(pan, wxID_ANY, "Show Log");
    check->SetValue(true);
    wxBoxSizer* bSizer1 = new wxBoxSizer(wxVERTICAL);
    bSizer1->Add(check, wxSizerFlags(0).Border());
    pan->SetSizer(bSizer1);
    m_mgr.AddPane(pan, wxAuiPaneInfo().CentrePane());

    wxTextCtrl* text = new wxTextCtrl(this, wxID_ANY, wxEmptyString,
                                      wxDefaultPosition, wxDefaultSize,
                                      wxTE_DONTWRAP|wxTE_MULTILINE );
    m_mgr.AddPane(text, wxAuiPaneInfo().Name("logwin").Caption("log").Bottom());

    m_mgr.Update();

    check->Bind(wxEVT_CHECKBOX, &MyFrame::OnCheck, this);
    m_wsLogPaneInfo = wxEmptyString;
}

MyFrame::~MyFrame()
{
    m_mgr.UnInit();
}


void MyFrame::OnCheck( wxCommandEvent& event )
{
  wxAuiPaneInfo& info = m_mgr.GetPane("logwin");

  if ( info.IsShown() )
  {
    if ( !event.IsChecked() )
    {
      m_wsLogPaneInfo =  m_mgr.SavePaneInfo( info );
      info.Show(false);
      m_mgr.Update();
    }
  }
  else
  {
    if ( event.IsChecked() )
    {
      m_mgr.LoadPaneInfo( m_wsLogPaneInfo, info );
      info.Show(true);
      m_mgr.Update();
    }
  }
}

class MyApp : public wxApp
{
    public:
        virtual bool OnInit()
        {
            MyFrame* frame = new MyFrame(NULL);
            frame->Show();
            return true;
        }
};

wxIMPLEMENT_APP(MyApp);

// ------------------------------- eof ------------------------------
