#include <iostream>
#include "wx/wx.h"
#include <wx/dynlib.h>

class MyFrame : public wxFrame
{
public:
	MyFrame(wxWindow* ptr, int id, wxString name, wxPoint pos, wxSize size) : wxFrame(ptr,id,name,pos,size)
{
		Center();
		Show();
}
};

class MyApp: public wxApp
{
    virtual bool OnInit();
};


IMPLEMENT_APP(MyApp)


bool MyApp::OnInit()
{
    MyFrame* frame = new MyFrame(NULL, wxID_ANY,  wxT("Hello World"), wxDefaultPosition, wxSize(640,480));
	
#ifdef __WXMAC__
	wxString path = wxT("./libhello.dylib");
#elif defined(__WXGTK__)
	wxString path = wxT("./libhello.so");
#endif
	wxDynamicLibrary* lib = new wxDynamicLibrary( path );
	if ( !lib->IsLoaded() )
	{
		std::cout << "Error loading library" << std::endl;
		exit(1);
	} 
	
	typedef void (*SayHello)(void); 

	SayHello sayHello = (SayHello)lib->GetSymbol(wxT("sayHello"));
	if(sayHello == NULL) std::cout << "no such symbol" << std::endl;
	else sayHello();

    return true;
}
