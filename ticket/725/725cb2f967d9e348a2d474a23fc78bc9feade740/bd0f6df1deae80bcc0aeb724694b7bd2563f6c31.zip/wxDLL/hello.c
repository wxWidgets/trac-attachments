
#include <stdio.h>
extern "C" void sayHello()
{
	printf("Hello World!\n");	
}
