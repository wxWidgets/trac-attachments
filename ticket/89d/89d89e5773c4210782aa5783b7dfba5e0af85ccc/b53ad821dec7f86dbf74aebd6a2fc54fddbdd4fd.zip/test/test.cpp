#include <wx/wx.h>
#include <wx/html/htmlwin.h>
int __stdcall WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow)
{
	wxFrame *frame = new wxFrame();
	wxHtmlWindow* html = new wxHtmlWindow(frame);
	wchar_t *buffer = (wchar_t*)calloc(2048,sizeof(wchar_t));
	FILE* input = wxFopen(wxT("test.html"),wxT("r"));
	wxString buf;
	fread(buffer,1404,1,input);
	buf = buffer;
	html->SetPage(buf);
	return 0;
}
