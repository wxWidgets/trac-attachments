#! /usr/bin/env python
# -*- coding: ascii -*-

from __future__ import division

import sys
import os

import wx
import wx.xrc as xrc


class frmMain(wx.Frame):
	def __init__(self, parent=None):
		# Load the frame from the XRC file
		res = xrc.XmlResource('TestWxCalendar.xrc')
		w = res.LoadFrame(parent, 'frmMain')
		self.PostCreate(w)
		self.Centre()

		# Get the control objects
		self.btnTest = xrc.XRCCTRL(self, 'btnTest')
		self.calTest = xrc.XRCCTRL(self, 'calTest')
		self.chkTest = xrc.XRCCTRL(self, 'chkTest')
		self.txtTest = xrc.XRCCTRL(self, 'txtTest')
		self.lstTest = xrc.XRCCTRL(self, 'lstTest')

		# The list shows the type of each control
		# The strange part here is that on wxPython 3 (Fedora 22), self.calTest is a generic Control instead of a CalendarCtrl
		self.lstTest.InsertItems([
			repr(self.btnTest),
			repr(self.calTest),
			repr(self.chkTest),
			repr(self.txtTest),
			repr(self.lstTest)
		], 0)

		# Because self.calTest is a generic Control, the CalendarCtrl methods cannot be used,
		# for example, if the line below gets uncommented, it will fail with the error:
		# AttributeError: 'Control' object has no attribute 'GetDate'
		#calendar_date = self.calTest.GetDate()
		#self.txtTest.ChangeValue(repr(calendar_date))


class MyApp(wx.App):
	def OnInit(self):
		frame = frmMain(None)

		self.SetTopWindow(frame)

		frame.Show()

		return True


if __name__ == '__main__':
	try:
		app = MyApp(redirect=False)
		app.MainLoop()
	except SystemExit:
		sys.exit(0)

