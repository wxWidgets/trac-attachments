#! /usr/bin/env python

import sys

import wx
import wx.xrc as xrc



objectList = []


def debugListChildWindows(win):

    def _recurs(win, deep):
        objectList.append(win)
        
        if win.__class__.__name__ != "TestDialog" and \
                "wx" + win.__class__.__name__ != win.GetClassName():
            warn="!!!"
        else:
            warn = ""

        print(" " * deep + warn + win.__class__.__name__, "id=" + str(win.GetId()),
                "name=" + win.GetName(), "RTTI=" + win.GetClassName(),
                flush=True)
        for c in win.GetChildren():
            _recurs(c, deep+2)
    
    _recurs(win, 0)




class MainFrame(wx.Frame):
    def __init__(self):
        wx.Frame.__init__(self)
        self.Create(None)
        
        
        
class TestDialog(wx.Dialog):
    def __init__(self, parent):
        wx.Dialog.__init__(self)
        
        res = xrc.XmlResource('TestBadConvert.xrc')
        res.LoadDialog(self, parent, 'SearchWikiDialog')

        print("--List of child windows")
        debugListChildWindows(self)
        print("--End of list, collected items in objectList:", len(objectList))



class MyApp(wx.App):
    def OnInit(self):

        topframe = MainFrame()

        self.SetTopWindow(topframe)

        topframe.Show()
        
        for i in range(10):
            with TestDialog(topframe) as dlg:

                dlg.ShowModal()


        return True


if __name__ == '__main__':
    try:
        app = MyApp(redirect=False)
        app.MainLoop()
    except SystemExit:
        sys.exit(0)

