#!/usr/bin/env python

# ******** I cannot get FlatImageBook to work as expected since the re-structuring of the style flags.
# I'm using python version 2.7, wx Version 2.8.11.0 on a Windows install
#*****  All possible values from the labelbook.py source for FlatImageBook..........
'''
         =========================== =========== ==================================================
         Window Styles               Hex Value   Description
         =========================== =========== ==================================================
         ``INB_BOTTOM``                      0x1 Place labels below the page area. Available only for `FlatImageBook`.
         ``INB_LEFT``                        0x2 Place labels on the left side. Available only for `FlatImageBook`.
         ``INB_RIGHT``                       0x4 Place labels on the right side.
         ``INB_TOP``                         0x8 Place labels above the page area.
         ``INB_BORDER``                     0x10 Draws a border around `LabelBook` or `FlatImageBook`.
         ``INB_SHOW_ONLY_TEXT``             0x20 Shows only text labels and no images. Available only for `LabelBook`.
         ``INB_SHOW_ONLY_IMAGES``           0x40 Shows only tab images and no label texts. Available only for `LabelBook`.
         ``INB_FIT_BUTTON``                 0x80 Displays a pin button to show/hide the book control.
         ``INB_DRAW_SHADOW``               0x100 Draw shadows below the book tabs. Available only for `LabelBook`.
         ``INB_USE_PIN_BUTTON``            0x200 Displays a pin button to show/hide the book control.
         ``INB_GRADIENT_BACKGROUND``       0x400 Draws a gradient shading on the tabs background. Available only for `LabelBook`.
         ``INB_WEB_HILITE``                0x800 On mouse hovering, tabs behave like html hyperlinks. Available only for `LabelBook`.
         ``INB_NO_RESIZE``                0x1000 Don't allow resizing of the tab area.
         ``INB_FIT_LABELTEXT``            0x2000 Will fit the tab area to the longest text (or text+image if you have images) in all the tabs.
         =========================== =========== ==================================================
'''

import wx
import wx.lib.agw.labelbook as LB
print "wx Version Number: "+str(wx.version())

class MyFrame(wx.Frame):
    def __init__(self, *args, **kwds):
        kwds["style"] = wx.DEFAULT_FRAME_STYLE
        wx.Frame.__init__(self, *args, **kwds)
        
        #----------- Possible values for Tab placement are INB_TOP, INB_BOTTOM, INB_RIGHT, INB_LEFT ------------#
        self.notebook_1=LB.FlatImageBook(self,-1,agwStyle=LB.INB_TOP|LB.INB_USE_PIN_BUTTON)
        
        #---- Alternatives for the tab control; these work as expected ----------#
        #self.notebook_1=LB.LabelBook(self,-1,agwStyle=LB.INB_FIT_LABELTEXT|LB.INB_LEFT|LB.INB_DRAW_SHADOW|LB.INB_GRADIENT_BACKGROUND|LB.INB_BORDER)
        #self.notebook_1 = wx.Notebook(self, -1, style=wx.NB_BOTTOM)

        self.notebook_1_pane_1 = wx.Panel(self.notebook_1, -1)
        self.notebook_1_pane_2 = wx.Panel(self.notebook_1, -1)

        self.__set_properties()
        self.__do_layout()



    def __set_properties(self):
        self.SetTitle("Test for FlatImageBook")
        self.imagelist=wx.ImageList(43, 52)
        self.imagelist.Add(wx.Bitmap("Paper43x52.png",wx.BITMAP_TYPE_PNG))
        self.notebook_1.AssignImageList(self.imagelist)

    def __do_layout(self):
        sizer_1 = wx.BoxSizer(wx.VERTICAL)
        self.notebook_1.AddPage(self.notebook_1_pane_1, "tab1",1,0)
        self.notebook_1.AddPage(self.notebook_1_pane_2, "tab2",0,0)
        sizer_1.Add(self.notebook_1, 1, wx.EXPAND, 0)
        self.SetSizer(sizer_1)
        sizer_1.Fit(self)
        self.Layout()

if __name__ == "__main__":
    app = wx.PySimpleApp(0)
    wx.InitAllImageHandlers()
    frame_1 = MyFrame(None, -1, "")
    app.SetTopWindow(frame_1)
    frame_1.Show()
    import wx.lib.inspection
    wx.lib.inspection.InspectionTool().Show() 
    app.MainLoop()
