/********************
 *  Implementation
 ********************/

#include <wx/wx.h>
#include "main.h"
#include "UNADAdmin.h"


// program execution "starts" here
bool
MainApp::OnInit()
{
//    AppFrame *frame;
//
//    frame = new AppFrame("Application",
//                         wxPoint(50, 50), wxSize(450, 340));
//    frame->Show(TRUE);
    
    UNADAdmin *mainFrame = new UNADAdmin((wxWindow*)NULL, wxID_ANY);
    
    mainFrame->Show(TRUE);

   /* success: wxApp::OnRun() will be called which will enter the main
    * message loop and the application will run. If we returned FALSE
    * here, the application would exit immediately.
    */
    return TRUE;
}


//// frame constructor
//AppFrame::AppFrame(const wxString &title, const wxPoint &pos,
//  const wxSize& size)
//  : wxFrame ((wxFrame *) NULL, -1, title, pos, size)
//{
//    wxMenuBar *menuBar;
//    wxMenu *fileMenu;
//    wxMenu *helpMenu;
//
//    /* "A" is the name of the application's main icon,
//     * as set by Dev-C++
//     */
//    SetIcon(wxICON(A));
//
//    // create menus
//    fileMenu = new wxMenu("", wxMENU_TEAROFF);
//    fileMenu->Append(MainApp_Quit, "E&xit\tCtrl-Q", "Quit this program");
//    helpMenu = new wxMenu;
//    helpMenu->Append(MainApp_About, "&About...\tCtrl-A", "Show about dialog");
//
//    menuBar = new wxMenuBar();
//    menuBar->Append(fileMenu, "&File");
//    menuBar->Append(helpMenu, "&Help");
//
//    SetMenuBar(menuBar);
//
//    // create a statusbar
//    CreateStatusBar(2);
//    SetStatusText("Ready.");
//}
//
//
///*****************
// * event handlers
// *****************/
//
//void
//AppFrame::OnQuit(wxCommandEvent &WXUNUSED(event))
//{
//    // TRUE is to force the frame to close
//    Close(TRUE);
//}
//
//
//void
//AppFrame::OnAbout(wxCommandEvent &WXUNUSED(event))
//{
//    wxString msg;
//
//    msg.Printf("Application version 0.1");
//    wxMessageBox(msg, "About", wxOK | wxICON_INFORMATION, this);
//}

