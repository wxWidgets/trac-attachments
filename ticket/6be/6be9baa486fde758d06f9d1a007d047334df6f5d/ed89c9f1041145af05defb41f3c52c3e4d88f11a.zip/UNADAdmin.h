/////////////////////////////////////////////////////////////////////////////
// Name:        UNADAdmin.h
// Purpose:     
// Author:      
// Modified by: 
// Created:     09/07/04 19:52:57
// RCS-ID:      
// Copyright:   
// Licence:     
/////////////////////////////////////////////////////////////////////////////

#ifndef _UNADADMIN_H_
#define _UNADADMIN_H_

#if defined(__GNUG__) && !defined(__APPLE__)
#pragma interface "UNADAdmin.cpp"
#endif

/*!
 * Includes
 */

////@begin includes
#include "UNADAdmin_symbols.h"
#include "wx/frame.h"
#include "wx/statusbr.h"
#include "wx/toolbar.h"
////@end includes

/*!
 * Forward declarations
 */

////@begin forward declarations
class wxBoxSizer;
////@end forward declarations

/*!
 * Control identifiers
 */

////@begin control identifiers
#define ID_FRAME 10002
#define SYMBOL_UNADADMIN_STYLE wxCAPTION|wxRESIZE_BORDER|wxSYSTEM_MENU|wxMINIMIZE_BOX|wxMAXIMIZE_BOX|wxCLOSE_BOX
#define SYMBOL_UNADADMIN_TITLE _("NAD Admin")
#define SYMBOL_UNADADMIN_IDNAME ID_FRAME
#define SYMBOL_UNADADMIN_SIZE wxSize(400, 300)
#define SYMBOL_UNADADMIN_POSITION wxDefaultPosition
#define ID_MENU_QUIT 10006
#define ID_MENU_COUNTRIES_LIST 10007
#define ID_MENU_ABOUT 10008
#define ID_STATUSBAR 10004
#define ID_TOOLBAR 10005
////@end control identifiers

/*!
 * Compatibility
 */

#ifndef wxCLOSE_BOX
#define wxCLOSE_BOX 0x1000
#endif
#ifndef wxFIXED_MINSIZE
#define wxFIXED_MINSIZE 0
#endif

/*!
 * UNADAdmin class declaration
 */

class UNADAdmin: public wxFrame
{    
    DECLARE_DYNAMIC_CLASS( UNADAdmin )
    DECLARE_EVENT_TABLE()

public:
    /// Constructors
    UNADAdmin( );
    UNADAdmin( wxWindow* parent, wxWindowID id = SYMBOL_UNADADMIN_IDNAME, const wxString& caption = SYMBOL_UNADADMIN_TITLE, const wxPoint& pos = SYMBOL_UNADADMIN_POSITION, const wxSize& size = SYMBOL_UNADADMIN_SIZE, long style = SYMBOL_UNADADMIN_STYLE );

    bool Create( wxWindow* parent, wxWindowID id = SYMBOL_UNADADMIN_IDNAME, const wxString& caption = SYMBOL_UNADADMIN_TITLE, const wxPoint& pos = SYMBOL_UNADADMIN_POSITION, const wxSize& size = SYMBOL_UNADADMIN_SIZE, long style = SYMBOL_UNADADMIN_STYLE );

    /// Creates the controls and sizers
    void CreateControls();

////@begin UNADAdmin event handler declarations

    /// wxEVT_COMMAND_MENU_SELECTED event handler for ID_MENU_QUIT
    void OnMenuQuitClick( wxCommandEvent& event );

    /// wxEVT_COMMAND_MENU_SELECTED event handler for ID_MENU_COUNTRIES_LIST
    void OnMenuCountriesListClick( wxCommandEvent& event );

    /// wxEVT_COMMAND_MENU_SELECTED event handler for ID_MENU_ABOUT
    void OnMenuAboutClick( wxCommandEvent& event );

////@end UNADAdmin event handler declarations

////@begin UNADAdmin member function declarations


    /// Retrieves bitmap resources
    wxBitmap GetBitmapResource( const wxString& name );

    /// Retrieves icon resources
    wxIcon GetIconResource( const wxString& name );
////@end UNADAdmin member function declarations

    /// Should we show tooltips?
    static bool ShowToolTips();

////@begin UNADAdmin member variables
    wxBoxSizer* itemMainBoxSizer;
////@end UNADAdmin member variables
};

#endif
    // _UNADADMIN_H_
