/////////////////////////////////////////////////////////////////////////////
// Name:        UCountriesList.cpp
// Purpose:     
// Author:      
// Modified by: 
// Created:     09/07/04 19:51:12
// RCS-ID:      
// Copyright:   
// Licence:     
/////////////////////////////////////////////////////////////////////////////

#if defined(__GNUG__) && !defined(__APPLE__)
#pragma implementation "UCountriesList.h"
#endif

// For compilers that support precompilation, includes "wx/wx.h".
#include "wx/wxprec.h"

#ifdef __BORLANDC__
#pragma hdrstop
#endif

#ifndef WX_PRECOMP
#include "wx/wx.h"
#endif

////@begin includes
////@end includes

#include "UCountriesList.h"

////@begin XPM images
////@end XPM images

/*!
 * UCountriesList type definition
 */

IMPLEMENT_DYNAMIC_CLASS( UCountriesList, wxPanel )

/*!
 * UCountriesList event table definition
 */

BEGIN_EVENT_TABLE( UCountriesList, wxPanel )

////@begin UCountriesList event table entries
////@end UCountriesList event table entries

END_EVENT_TABLE()

/*!
 * UCountriesList constructors
 */

UCountriesList::UCountriesList( )
{
}

UCountriesList::UCountriesList( wxWindow* parent, wxWindowID id, const wxPoint& pos, const wxSize& size, long style )
{
    Create(parent, id, pos, size, style);
}

/*!
 * UCountriesList creator
 */

bool UCountriesList::Create( wxWindow* parent, wxWindowID id, const wxPoint& pos, const wxSize& size, long style )
{
////@begin UCountriesList member initialisation
////@end UCountriesList member initialisation

////@begin UCountriesList creation
    SetExtraStyle(GetExtraStyle()|wxWS_EX_BLOCK_EVENTS);
    wxPanel::Create( parent, id, pos, size, style );

    CreateControls();
    Centre();
////@end UCountriesList creation
    return TRUE;
}

/*!
 * Control creation for UCountriesList
 */

void UCountriesList::CreateControls()
{    
////@begin UCountriesList content construction

    UCountriesList* itemPanel1 = this;

    wxFlexGridSizer* itemFlexGridSizer2 = new wxFlexGridSizer(1, 1, 0, 0);
    itemFlexGridSizer2->AddGrowableRow(0);
    itemFlexGridSizer2->AddGrowableCol(0);
    itemPanel1->SetSizer(itemFlexGridSizer2);
    itemPanel1->SetAutoLayout(TRUE);
    wxGrid* itemGrid3 = new wxGrid( itemPanel1, ID_GRID, wxDefaultPosition, wxSize(200, 150), wxSUNKEN_BORDER|wxHSCROLL|wxVSCROLL );
    itemGrid3->SetDefaultColSize(50);
    itemGrid3->SetDefaultRowSize(25);
    itemGrid3->SetColLabelSize(25);
    itemGrid3->SetRowLabelSize(50);
    itemGrid3->CreateGrid(5, 5, wxGrid::wxGridSelectCells);
    itemFlexGridSizer2->Add(itemGrid3, 1, wxGROW|wxGROW|wxALL, 5);

////@end UCountriesList content construction
}

/*!
 * Should we show tooltips?
 */

bool UCountriesList::ShowToolTips()
{
    return TRUE;
}

/*!
 * Get bitmap resources
 */

wxBitmap UCountriesList::GetBitmapResource( const wxString& name )
{
    // Bitmap retrieval
////@begin UCountriesList bitmap retrieval
    return wxNullBitmap;
////@end UCountriesList bitmap retrieval
}

/*!
 * Get icon resources
 */

wxIcon UCountriesList::GetIconResource( const wxString& name )
{
    // Icon retrieval
////@begin UCountriesList icon retrieval
    return wxNullIcon;
////@end UCountriesList icon retrieval
}
