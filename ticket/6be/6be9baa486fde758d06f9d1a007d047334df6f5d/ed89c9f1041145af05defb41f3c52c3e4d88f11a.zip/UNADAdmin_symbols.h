/////////////////////////////////////////////////////////////////////////////
// Name:        UNADAdmin_symbols.h
// Purpose:     Symbols file
// Author:      
// Modified by: 
// Created:     09/08/04 16:18:47
// RCS-ID:      
// Copyright:   
// Licence:     
/////////////////////////////////////////////////////////////////////////////

#define ID_FRAME_SYMBOL_0 _("&Quit\tCtrl-Q")
#define ID_FRAME_SYMBOL_1 _("Quit this program")
#define ID_FRAME_SYMBOL_2 _("&File")
#define ID_FRAME_SYMBOL_3 _("Countries &List")
#define ID_FRAME_SYMBOL_4 _("&Operations")
#define ID_FRAME_SYMBOL_5 _("&About...\tCtrl-A")
#define ID_FRAME_SYMBOL_6 _("Show about dialog")
#define ID_FRAME_SYMBOL_7 _("&Help")
#define ID_FRAME_SYMBOL_8 _("NAD Admin")
