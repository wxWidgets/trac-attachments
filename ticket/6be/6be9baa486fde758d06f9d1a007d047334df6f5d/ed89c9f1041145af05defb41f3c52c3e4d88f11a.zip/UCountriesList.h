/////////////////////////////////////////////////////////////////////////////
// Name:        UCountriesList.h
// Purpose:     
// Author:      
// Modified by: 
// Created:     09/07/04 19:51:12
// RCS-ID:      
// Copyright:   
// Licence:     
/////////////////////////////////////////////////////////////////////////////

#ifndef _UCOUNTRIESLIST_H_
#define _UCOUNTRIESLIST_H_

#if defined(__GNUG__) && !defined(__APPLE__)
#pragma interface "UCountriesList.cpp"
#endif

/*!
 * Includes
 */

////@begin includes
#include "UCountriesList_symbols.h"
#include "wx/grid.h"
////@end includes

/*!
 * Forward declarations
 */

////@begin forward declarations
////@end forward declarations

/*!
 * Control identifiers
 */

////@begin control identifiers
#define ID_DIALOG 10000
#define SYMBOL_UCOUNTRIESLIST_STYLE wxCAPTION|wxSYSTEM_MENU|wxCLOSE_BOX|wxNO_BORDER
#define SYMBOL_UCOUNTRIESLIST_TITLE _("Countries List")
#define SYMBOL_UCOUNTRIESLIST_IDNAME ID_DIALOG
#define SYMBOL_UCOUNTRIESLIST_SIZE wxSize(400, 300)
#define SYMBOL_UCOUNTRIESLIST_POSITION wxDefaultPosition
#define ID_GRID 10001
////@end control identifiers

/*!
 * Compatibility
 */

#ifndef wxCLOSE_BOX
#define wxCLOSE_BOX 0x1000
#endif
#ifndef wxFIXED_MINSIZE
#define wxFIXED_MINSIZE 0
#endif

/*!
 * UCountriesList class declaration
 */

class UCountriesList: public wxPanel
{    
    DECLARE_DYNAMIC_CLASS( UCountriesList )
    DECLARE_EVENT_TABLE()

public:
    /// Constructors
    UCountriesList( );
    UCountriesList( wxWindow* parent, wxWindowID id = SYMBOL_UCOUNTRIESLIST_IDNAME, const wxPoint& pos = SYMBOL_UCOUNTRIESLIST_POSITION, const wxSize& size = SYMBOL_UCOUNTRIESLIST_SIZE, long style = SYMBOL_UCOUNTRIESLIST_STYLE );

    /// Creation
    bool Create( wxWindow* parent, wxWindowID id = SYMBOL_UCOUNTRIESLIST_IDNAME, const wxPoint& pos = SYMBOL_UCOUNTRIESLIST_POSITION, const wxSize& size = SYMBOL_UCOUNTRIESLIST_SIZE, long style = SYMBOL_UCOUNTRIESLIST_STYLE );

    /// Creates the controls and sizers
    void CreateControls();

////@begin UCountriesList event handler declarations

////@end UCountriesList event handler declarations

////@begin UCountriesList member function declarations


    /// Retrieves bitmap resources
    wxBitmap GetBitmapResource( const wxString& name );

    /// Retrieves icon resources
    wxIcon GetIconResource( const wxString& name );
////@end UCountriesList member function declarations

    /// Should we show tooltips?
    static bool ShowToolTips();

////@begin UCountriesList member variables
////@end UCountriesList member variables
};

#endif
    // _UCOUNTRIESLIST_H_
