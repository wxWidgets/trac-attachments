/////////////////////////////////////////////////////////////////////////////
// Name:        UNADAdmin.cpp
// Purpose:     
// Author:      
// Modified by: 
// Created:     09/07/04 19:52:57
// RCS-ID:      
// Copyright:   
// Licence:     
/////////////////////////////////////////////////////////////////////////////

#if defined(__GNUG__) && !defined(__APPLE__)
#pragma implementation "UNADAdmin.h"
#endif

// For compilers that support precompilation, includes "wx/wx.h".
#include "wx/wxprec.h"

#ifdef __BORLANDC__
#pragma hdrstop
#endif

#ifndef WX_PRECOMP
#include "wx/wx.h"
#endif

////@begin includes
////@end includes

#include "UNADAdmin.h"
#include "UCountriesList.h"

////@begin XPM images
////@end XPM images

/*!
 * UNADAdmin type definition
 */

IMPLEMENT_DYNAMIC_CLASS( UNADAdmin, wxFrame )

/*!
 * UNADAdmin event table definition
 */

BEGIN_EVENT_TABLE( UNADAdmin, wxFrame )

////@begin UNADAdmin event table entries
    EVT_MENU( ID_MENU_QUIT, UNADAdmin::OnMenuQuitClick )

    EVT_MENU( ID_MENU_COUNTRIES_LIST, UNADAdmin::OnMenuCountriesListClick )

    EVT_MENU( ID_MENU_ABOUT, UNADAdmin::OnMenuAboutClick )

////@end UNADAdmin event table entries

END_EVENT_TABLE()

/*!
 * UNADAdmin constructors
 */

UNADAdmin::UNADAdmin( )
{
}

UNADAdmin::UNADAdmin( wxWindow* parent, wxWindowID id, const wxString& caption, const wxPoint& pos, const wxSize& size, long style )
{
    Create( parent, id, caption, pos, size, style );
}

/*!
 * UNADAdmin creator
 */

bool UNADAdmin::Create( wxWindow* parent, wxWindowID id, const wxString& caption, const wxPoint& pos, const wxSize& size, long style )
{
////@begin UNADAdmin member initialisation
    itemMainBoxSizer = NULL;
////@end UNADAdmin member initialisation

////@begin UNADAdmin creation
    wxFrame::Create( parent, id, caption, pos, size, style );

    CreateControls();
    Centre();
////@end UNADAdmin creation
    return TRUE;
}

/*!
 * Control creation for UNADAdmin
 */

void UNADAdmin::CreateControls()
{    
////@begin UNADAdmin content construction

    UNADAdmin* itemFrame1 = this;

    wxStatusBar* itemStatusBar9 = new wxStatusBar( itemFrame1, ID_STATUSBAR, wxST_SIZEGRIP|wxNO_BORDER );
    itemStatusBar9->SetFieldsCount(2);
    itemFrame1->SetStatusBar(itemStatusBar9);

    wxToolBar* itemToolBar10 = new wxToolBar( itemFrame1, ID_TOOLBAR, wxDefaultPosition, wxDefaultSize, wxTB_FLAT|wxTB_HORIZONTAL );
    itemToolBar10->Realize();
    itemFrame1->SetToolBar(itemToolBar10);

    wxBoxSizer* itemBoxSizer11 = new wxBoxSizer(wxHORIZONTAL);
    itemMainBoxSizer = itemBoxSizer11;
    itemFrame1->SetSizer(itemBoxSizer11);
    itemFrame1->SetAutoLayout(TRUE);

    wxMenuBar* menuBar = new wxMenuBar;
    wxMenu* itemMenu3 = new wxMenu;
    itemMenu3->Append(ID_MENU_QUIT, _("&Quit\tCtrl-Q"), _("Quit this program"), wxITEM_NORMAL);
    menuBar->Append(itemMenu3, _("&File"));
    wxMenu* itemMenu5 = new wxMenu;
    itemMenu5->Append(ID_MENU_COUNTRIES_LIST, _("Countries &List"), _T(""), wxITEM_NORMAL);
    menuBar->Append(itemMenu5, _("&Operations"));
    wxMenu* itemMenu7 = new wxMenu;
    itemMenu7->Append(ID_MENU_ABOUT, _("&About...\tCtrl-A"), _("Show about dialog"), wxITEM_NORMAL);
    menuBar->Append(itemMenu7, _("&Help"));
    itemFrame1->SetMenuBar(menuBar);

////@end UNADAdmin content construction
}

/*!
 * Should we show tooltips?
 */

bool UNADAdmin::ShowToolTips()
{
    return TRUE;
}

/*!
 * Get bitmap resources
 */

wxBitmap UNADAdmin::GetBitmapResource( const wxString& name )
{
    // Bitmap retrieval
////@begin UNADAdmin bitmap retrieval
    return wxNullBitmap;
////@end UNADAdmin bitmap retrieval
}

/*!
 * Get icon resources
 */

wxIcon UNADAdmin::GetIconResource( const wxString& name )
{
    // Icon retrieval
////@begin UNADAdmin icon retrieval
    return wxNullIcon;
////@end UNADAdmin icon retrieval
}
/*!
 * wxEVT_COMMAND_MENU_SELECTED event handler for ID_MENU_QUIT
 */

void UNADAdmin::OnMenuQuitClick( wxCommandEvent& event )
{
    // Insert custom code here
    Close(TRUE);

    event.Skip();
}


/*!
 * wxEVT_COMMAND_MENU_SELECTED event handler for ID_MENU_COUNTRIES_LIST]
 */

void UNADAdmin::OnMenuCountriesListClick( wxCommandEvent& event )
{
    // Insert custom code here
    UCountriesList* itemPanel = new UCountriesList(this, wxID_ANY, wxDefaultPosition, wxSize(100, 80), wxTAB_TRAVERSAL);
    itemMainBoxSizer->Add(itemPanel, 1, wxGROW, 5);
    
    event.Skip();
}


/*!
 * wxEVT_COMMAND_MENU_SELECTED event handler for ID_MENU_ABOUT
 */

void UNADAdmin::OnMenuAboutClick( wxCommandEvent& event )
{
    // Insert custom code here
    wxString msg;

    msg.Printf("Application version 0.1");
    wxMessageBox(msg, "About", wxOK | wxICON_INFORMATION, this);

    event.Skip();
}




