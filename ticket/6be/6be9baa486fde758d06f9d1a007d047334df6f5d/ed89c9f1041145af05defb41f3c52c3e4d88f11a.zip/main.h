#ifndef _MAIN_H_
#define _MAIN_H_

#include <wx/wx.h>


class MainApp : public wxApp
{
  public:
    virtual bool OnInit(void);
};

//class AppFrame : public wxFrame
//{
//  public:
//    AppFrame(const wxString &title, const wxPoint &pos, const wxSize &size);
//
//    // event handlers
//    void OnQuit(wxCommandEvent &event);
//    void OnAbout(wxCommandEvent &event);
//  private:
//    // any class wishing to process wxWindows events must use this macro
//    DECLARE_EVENT_TABLE()
//};
//
//enum
//{
//    // menu items
//    MainApp_Quit = 1,
//    MainApp_About
//};


/**********************************************************
 * Event tables and other macros for wxWindows
 **********************************************************
 * The event tables connect the wxWindows events with the
 * functions (event handlers) which process them. It can
 * be also done at run-time, but for the simple menu
 * events like this the static method is much simpler.
 *
 **********************************************************/

//BEGIN_EVENT_TABLE(AppFrame, wxFrame)
//    EVT_MENU(MainApp_Quit,  AppFrame::OnQuit)
//    EVT_MENU(MainApp_About, AppFrame::OnAbout)
//END_EVENT_TABLE()


/*****************************************************************
 * Create a new application object: this macro will allow
 * wxWindows to create the application object during program
 * execution (it's better than using a static object for many
 * reasons) and also declares the accessor function wxGetApp()
 * which will return the reference of the right type (i.e. MyApp
 * and not wxApp)
 *
 *****************************************************************/

IMPLEMENT_APP(MainApp)


#endif _MAIN_H__

