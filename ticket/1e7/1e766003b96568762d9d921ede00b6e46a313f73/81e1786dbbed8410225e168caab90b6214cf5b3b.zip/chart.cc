/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*- */
/*
 * wxwin-foobar
 * Copyright (C) Frans Schreuder 2012 <frans@frans-F3Ke>
 * 
wxwin-foobar is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * wxwin-foobar is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include "chart.h"

void Chart::mouseWheelMoved(wxMouseEvent& event)
{
	wxLogMessage("Moved");
}

Chart::Chart(wxFrame* parent) :
wxPanel(parent)
{
    this->Connect(wxEVT_MOUSEWHEEL, wxMouseEventHandler(Chart::mouseWheelMoved));
    this->Connect(wxEVT_PAINT, wxPaintEventHandler(Chart::paintEvent));
}

void Chart::paintNow()
{
    wxAutoBufferedPaintDC dc(this);
    render(dc);
}

void Chart::paintEvent(wxPaintEvent & evt)
{
    wxAutoBufferedPaintDC dc(this);
    render(dc);
}
 

void Chart::render(wxAutoBufferedPaintDC &  dc)
{
    dc.SetBackgroundMode(wxTRANSPARENT);
    dc.SetPen( wxPen( wxColor(0,0,0), 1 ) ); // 1 pixel, black
    dc.SetBrush(wxBrush(wxColor(0,0,0), wxBRUSHSTYLE_TRANSPARENT));
    dc.DrawCircle(wxPoint(100,100),5);
}
