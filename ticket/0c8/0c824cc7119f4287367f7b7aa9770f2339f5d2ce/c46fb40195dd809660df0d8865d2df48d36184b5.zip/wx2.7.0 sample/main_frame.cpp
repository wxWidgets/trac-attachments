#include "main_frame.h"
#include "view_panel.h"


BEGIN_EVENT_TABLE(MainFrame,wxFrame)
    EVT_RIGHT_UP(MainFrame::onRightButtonUp)
    EVT_TIMER(ID_CLOCKTIMER,MainFrame::onUpdateClock)
    EVT_TIMER(ID_STARTUPTIMER,MainFrame::onStartup)
    EVT_MENU(ID_MNU_EXIT,MainFrame::onMainMenu)
    EVT_CLOSE(MainFrame::onClose)
	//(*EventTable(MainFrame)
	EVT_BUTTON(ID_MENUBUTTON,MainFrame::onMenuButton)
	//*)
END_EVENT_TABLE()

MainFrame::MainFrame(wxWindow* parent,wxWindowID id)
{
    m_close = false;
	//(*Initialize(MainFrame)
	Create(parent,id,_("evs"),wxDefaultPosition,wxDefaultSize,wxRESIZE_BORDER,_T(""));
	BoxSizer1 = new wxBoxSizer(wxVERTICAL);
	BoxSizer2 = new wxBoxSizer(wxHORIZONTAL);
	Panel2 = new wxPanel(this,ID_PANEL2,wxDefaultPosition,wxDefaultSize,0,_("ID_PANEL2"));
	BoxSizer4 = new wxBoxSizer(wxHORIZONTAL);
	MenuButton = new wxButton(Panel2,ID_MENUBUTTON,_("Menu"),wxDefaultPosition,wxSize(-1,20),0,wxDefaultValidator,_("ID_MENUBUTTON"));
	if (false) MenuButton->SetDefault();
	CurrentTime = new wxStaticText(Panel2,ID_CURRENTTIME,_("00:00:00 00/00/0000"),wxDefaultPosition,wxDefaultSize,wxALIGN_RIGHT,_("ID_CURRENTTIME"));
	BoxSizer4->Add(MenuButton,0,wxLEFT|wxRIGHT|wxALIGN_CENTER,3);
	BoxSizer4->Add(-1,-1,1);
	BoxSizer4->Add(CurrentTime,0,wxLEFT|wxRIGHT|wxALIGN_CENTER,3);
	Panel2->SetSizer(BoxSizer4);
	BoxSizer4->Fit(Panel2);
	BoxSizer4->SetSizeHints(Panel2);
	BoxSizer2->Add(Panel2,1,wxALL|wxALIGN_LEFT|wxALIGN_TOP|wxEXPAND,0);
	BoxSizer3 = new wxBoxSizer(wxHORIZONTAL);
	view = new ViewPanel(this);
	Panel1 = new wxPanel(this,ID_PANEL1,wxDefaultPosition,wxDefaultSize,0,_("ID_PANEL1"));
	BoxSizer5 = new wxBoxSizer(wxVERTICAL);
	StaticText2 = new wxStaticText(Panel1,ID_STATICTEXT2,_("i\nc\no\nn\ns"),wxDefaultPosition,wxDefaultSize,wxALIGN_CENTRE,_("ID_STATICTEXT2"));
	BoxSizer5->Add(-1,-1,1);
	BoxSizer5->Add(StaticText2,0,wxALL|wxALIGN_LEFT|wxALIGN_TOP|wxEXPAND,0);
	BoxSizer5->Add(-1,-1,1);
	Panel1->SetSizer(BoxSizer5);
	BoxSizer5->Fit(Panel1);
	BoxSizer5->SetSizeHints(Panel1);
	BoxSizer3->Add(view,0,wxALL|wxALIGN_LEFT|wxALIGN_TOP,0);
	BoxSizer3->Add(Panel1,1,wxALL|wxALIGN_LEFT|wxALIGN_TOP|wxEXPAND,0);
	BoxSizer1->Add(BoxSizer2,1,wxALL|wxALIGN_LEFT|wxALIGN_TOP|wxEXPAND,0);
	BoxSizer1->Add(BoxSizer3,0,wxALL|wxALIGN_LEFT|wxALIGN_TOP|wxEXPAND,0);
	this->SetSizer(BoxSizer1);
	BoxSizer1->Fit(this);
	BoxSizer1->SetSizeHints(this);
	//*)

    //*  Activate current time  *//
    wxDateTime now = wxDateTime::Now();
    CurrentTime->SetLabel(now.Format(_T("%X %x")));
	wxTimer *t = new wxTimer(this,ID_CLOCKTIMER);
	t->Start(1000);
	BoxSizer1->Fit(this);

    //  This should put window into fullscreen mode (toplevel,no caption,no resize). For beta version
    //  it is just maximized.
    //Show();      /******  Unmark this line to to fix display  ******/
	Maximize(true);
    //Hide();      /******  Unmark this line to to fix display  ******/

    //  This timer runs login dialog. It is important because main flow must go to the main event
    //  loop before we will lock access to any other futures. In other words wait until all threads
    //  and events will startup and then display login dialog.

	CreateMenus();
	Sleep(5000); // Just to delay start for this sample
}

MainFrame::~MainFrame()
{
}

void MainFrame::onUpdateClock(wxTimerEvent &event)
{
    //  Simple platform and localized clock. In the future it will be configurable.
    wxDateTime now = wxDateTime::Now();
    CurrentTime->SetLabel(now.Format(_T("%X %x")));
}

void MainFrame::onStartup(wxTimerEvent &event)
{
}

void MainFrame::onMainMenu(wxCommandEvent &event)
{
    //  Process all main menu events. Search is done by ID.
    switch (event.GetId())
    {
        case ID_MNU_EXIT:
        {
            m_close = true;
            Close();
            break;
        }
    }
}

void MainFrame::onClose(wxCloseEvent &event)
{
    //  Check if application is closed from correct place. It will eliminate forced close by ALT+F4
//    if (m_close)
//    {
        int rs = wxMessageBox(_("Do you want to exit"),_("evs"),wxYES_NO|wxYES_DEFAULT);
        if (rs==wxYES)
        {
            Hide();
            wxBusyInfo infoMsg(_("Shutting down"));
            Sleep(3000); // Just to delay this sample
            Destroy();
        }
//    }
}

void MainFrame::onRightButtonUp(wxMouseEvent &event)
{
    PopupMenu(m_popup_menu);
}

void MainFrame::CreateMenus()
{
    //  Temporary help objects used to create full menu structure. There is no point in storing all
    //  entries if it can be accessed from main menu object. It is important to create ids for each
    //  entrie. If there is no id then it will not be possible to find object in the future.
    wxMenu *submenu;
    wxMenuItem *item;

    //*  Create main menu  *//
    m_main_menu = new wxMenu();
    item = new wxMenuItem(m_main_menu,ID_MNU_EXIT,_("Shutdown"));
    m_main_menu->Append(item);

}

void MainFrame::onPopupMenu(wxCommandEvent &event)
{
}

void MainFrame::onMenuButton(wxCommandEvent& event)
{
    //  Main menu is called as popup. In order to prevent random placement force it to be displayed
    //  below main menu bar.
    wxSize size = Panel2->GetSize();
    PopupMenu(m_main_menu,0,size.GetHeight());
}
