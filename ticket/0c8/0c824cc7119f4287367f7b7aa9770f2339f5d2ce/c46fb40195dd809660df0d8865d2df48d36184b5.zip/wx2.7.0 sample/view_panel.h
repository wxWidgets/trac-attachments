#ifndef VIEWPANEL_H
#define VIEWPANEL_H

#include <wx/wxprec.h>

#ifdef __BORLANDC__
    #pragma hdrstop
#endif

#ifndef WX_PRECOMP
    #include <wx/wx.h>
#endif

#include <wx/menu.h>
#include <wx/image.h>
#include <wx/dcclient.h>


class ViewPanel:public wxPanel
{
        //{* events
        void onMRightUp(wxMouseEvent&);
        //*}

        DECLARE_EVENT_TABLE()

    public:

        ViewPanel(wxWindow*);
        virtual ~ViewPanel();

        void Clear();

        HWND hwnd;                   //  Needed for GDI+
};

#endif
