#include "m_app.h"
#include "main_frame.h"


IMPLEMENT_APP(EVApp);


bool EVApp::OnInit()
{
    //  Initialize all standard image handlers. Display startup wait message. Initilize 800x600x32
    //  fullscreen mode with OpenGL. Unfortunately sometimes it is initializing fullscreen with
    //  locked down GUI. I will have to fix it in the future.
    InitFullscreenMode();
    wxInitAllImageHandlers();
    wxBusyInfo infoMsg(_("Starting..."));


    //  Start main application
	MainFrame* frame = new MainFrame(NULL);

    frame->Show();
    //  Allow main loop flow
	return true;
}

void EVApp::InitFullscreenMode()
{
    HGLRC   hRC=NULL;
    GLuint  PixelFormat;

	MGLCanvas *win = new MGLCanvas();
	win->SetCurrent();

    DEVMODE dmScreenSettings;					// Device Mode
    memset(&dmScreenSettings,0,sizeof(dmScreenSettings));		// Makes Sure Memory's Cleared
    dmScreenSettings.dmSize=sizeof(dmScreenSettings);		// Size Of The Devmode Structure
    dmScreenSettings.dmPelsWidth	= 800;			// Selected Screen Width
    dmScreenSettings.dmPelsHeight	= 600;			// Selected Screen Height
    dmScreenSettings.dmBitsPerPel	= 32;				// Selected Bits Per Pixel
    dmScreenSettings.dmFields=DM_BITSPERPEL|DM_PELSWIDTH|DM_PELSHEIGHT;

    if (ChangeDisplaySettings(&dmScreenSettings,CDS_FULLSCREEN)!=DISP_CHANGE_SUCCESSFUL)
    {
    }

	static	PIXELFORMATDESCRIPTOR pfd=					// pfd Tells Windows How We Want Things To Be
	{
		sizeof(PIXELFORMATDESCRIPTOR),					// Size Of This Pixel Format Descriptor
		1,								// Version Number
		PFD_DRAW_TO_WINDOW |						// Format Must Support Window
		PFD_SUPPORT_OPENGL |						// Format Must Support OpenGL
		PFD_DOUBLEBUFFER,						// Must Support Double Buffering
		PFD_TYPE_RGBA,							// Request An RGBA Format
		32,								// Select Our Color Depth
		0, 0, 0, 0, 0, 0,						// Color Bits Ignored
		0,								// No Alpha Buffer
		0,								// Shift Bit Ignored
		0,								// No Accumulation Buffer
		0, 0, 0, 0,							// Accumulation Bits Ignored
		16,								// 16Bit Z-Buffer (Depth Buffer)
		0,								// No Stencil Buffer
		0,								// No Auxiliary Buffer
		PFD_MAIN_PLANE,							// Main Drawing Layer
		0,								// Reserved
		0, 0, 0								// Layer Masks Ignored
	};

    if (!(PixelFormat=ChoosePixelFormat(GetDC(win->hwnd),&pfd)))				// Did Windows Find A Matching Pixel Format?
    {
        wxMessageBox( _("Can't Find A Suitable PixelFormat.") );
    }

    if(!SetPixelFormat(GetDC(win->hwnd),PixelFormat,&pfd))				// Are We Able To Set The Pixel Format?
	{
		wxMessageBox( _("Can't Set The PixelFormat.") );
	}

	if (!(hRC=wglCreateContext(GetDC(win->hwnd))))					// Are We Able To Get A Rendering Context?
	{
	    wxMessageBox( _("Can't Create A GL Rendering Context.") );
	}

	if(!wglMakeCurrent(GetDC(win->hwnd),hRC))						// Try To Activate The Rendering Context
	{
        wxMessageBox( _("Can't Activate The GL Rendering Context.") );
	}

    glFlush();
    win->SwapBuffers();
    win->Hide();
}

MGLCanvas::MGLCanvas(): wxGLCanvas(NULL)
{
    hwnd = GetHwnd();
}
