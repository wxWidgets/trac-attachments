#ifndef MAIN_FRAME_H
#define MAIN_FRAME_H

#include <wx/wxprec.h>

#ifdef __BORLANDC__
    #pragma hdrstop
#endif

//(*Headers(MainFrame)
#include <wx/button.h>
#include <wx/frame.h>
#include <wx/intl.h>
#include <wx/panel.h>
#include <wx/settings.h>
#include <wx/sizer.h>
#include <wx/stattext.h>
//*)
#include <wx/timer.h>
#include <wx/datetime.h>
#include <wx/busyinfo.h>
#include <wx/menu.h>
#include <wx/image.h>

class ViewPanel;
class Cap3;

class MainFrame: public wxFrame
{
        void onUpdateClock(wxTimerEvent&);
        void onStartup(wxTimerEvent&);
        void onMainMenu(wxCommandEvent&);
        void onClose(wxCloseEvent&);
        void onRightButtonUp(wxMouseEvent&);
        void onPopupMenu(wxCommandEvent&);

        void CreateMenus();

        wxMenu *m_popup_menu,*m_main_menu;
        bool m_close;

	public:

		MainFrame(wxWindow* parent,wxWindowID id = -1);
		virtual ~MainFrame();

		//(*Identifiers(MainFrame)
		enum Identifiers
		{
		    ID_PANEL2 = 0x1000,
		    ID_MENUBUTTON,
		    ID_CURRENTTIME,
		    ID_VIEW,
		    ID_PANEL1,
		    ID_STATICTEXT2
		};
		//*)
		enum
		{
		    ID_CLOCKTIMER,
		    ID_STARTUPTIMER,

            //  main menu
		    ID_MNU_EXIT,

		};

	protected:

		//(*Handlers(MainFrame)
		void onMenuButton(wxCommandEvent& event);
		//*)

		//(*Declarations(MainFrame)
		wxBoxSizer* BoxSizer1;
		wxBoxSizer* BoxSizer2;
		wxPanel* Panel2;
		wxBoxSizer* BoxSizer4;
		wxButton* MenuButton;
		wxStaticText* CurrentTime;
		wxBoxSizer* BoxSizer3;
		ViewPanel* view;
		wxPanel* Panel1;
		wxBoxSizer* BoxSizer5;
		wxStaticText* StaticText2;
		//*)

	private:

		DECLARE_EVENT_TABLE()
};

#endif
