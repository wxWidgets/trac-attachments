#ifndef APP_H
#define APP_H

#include <wx/wxprec.h>

#ifdef __BORLANDC__
    #pragma hdrstop
#endif

#ifndef WX_PRECOMP
    #include <wx/wx.h>
#endif

#include <wx/glcanvas.h>
#include <wx/image.h>
#include <wx/busyinfo.h>


class MGLCanvas:public wxGLCanvas
{
    public:

        MGLCanvas();

        HWND hwnd;
};

class EVApp : public wxApp
{
        void InitFullscreenMode();

	public:

		virtual bool OnInit();
};

#endif // APP_H
