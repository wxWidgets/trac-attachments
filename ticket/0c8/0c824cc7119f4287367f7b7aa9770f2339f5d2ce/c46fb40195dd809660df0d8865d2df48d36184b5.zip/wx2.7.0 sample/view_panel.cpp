#include "view_panel.h"


BEGIN_EVENT_TABLE(ViewPanel,wxPanel)
    EVT_RIGHT_UP(ViewPanel::onMRightUp)
END_EVENT_TABLE()


ViewPanel::ViewPanel(wxWindow *parent)
{
    //  Create empty panel with black background. Also get HWND for GDI+.
    Create(parent,-1,wxPoint(-1,-1),wxSize(768,576));
    SetBackgroundColour(wxColour(0x00,0x00,0x00));

    hwnd = GetHwnd();
}

ViewPanel::~ViewPanel()
{
}

void ViewPanel::onMRightUp(wxMouseEvent &event)
{
    //  Send right_mouse_button_up event to parent control. We do not process anything here.
    wxWindow *parent = GetParent();
    parent->ProcessEvent(event);
}

void ViewPanel::Clear()
{
    //  This is simple clear command. It is not nice to do it this way, but currently it is working.
    //  Still it has a little flickering from time to time and on main layout change. This is for
    //  future development.
    wxImage img(768,576);
    wxBitmap bmp(img);

    wxClientDC dc(this);
    dc.DrawBitmap(bmp,0,0,false);
}
