import wx


class MyFrame(wx.Frame):
    def __init__(self):
        wx.Frame.__init__(self, None, -1, 'My app')
        self.icon = wx.Icon('icon.ico', wx.BITMAP_TYPE_ICO)
        self.tbicon = wx.TaskBarIcon()
        self.tbicon.SetIcon(self.icon, '')

		
class MyApp(wx.App):
    def __init__(self):
        wx.App.__init__(self)

    def OnInit(self):
        self.frame = MyFrame()
        self.frame.Show()
        return True

		
app = MyApp()
app.MainLoop()
