#include <gtk/gtk.h>


void
on_button_packdir_fs_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_tempdir_fs_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_ok_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_fs_ok_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_fs_cancel_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_quit_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_countrydir_fs_clicked        (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_version_clicked              (GtkButton       *button,
                                        gpointer         user_data);
