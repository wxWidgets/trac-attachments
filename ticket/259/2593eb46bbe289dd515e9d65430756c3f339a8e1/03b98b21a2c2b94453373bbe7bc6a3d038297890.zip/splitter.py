#!/usr/bin/env python
# -*- coding: latin-1 -*-
"""
splitter.py

Created by Ivan Savov on 2008-02-28.
Copyright (c) 2008 __MyCompanyName__. All rights reserved.

split
Goes through the original Secondaire 5 text file and spits out many HTML files

"""

import sys
import os
import urllib2
import re
import string




def cleanup():
	os.remove("Secondaire5split/index.html")
	for i in range(1,101):
	    os.remove("Secondaire5split/"+str(i)+".html")


def main():

	global a
	print "Spliting Secondai.TXT ................................"


	########################################	
	# read everything and split into a list of lists
	source = open('SECONDAI.TXT')
	contenu = source.read()
	chap_patt = re.compile(r'\r\n[\t| ]*\r\n(\d{1,3})\. (.*)\r\n') #digit x3, space, newline

	index = 0	#index into the book
	start = 0	#offser into contenu
	a = []		# the books structure list of chapters, chapter=number,title,text

	ans2 = chap_patt.search(contenu, start)
	a.append(["index","Secondaire 5",""])

	while ans2!=None:
		a[index][2]=contenu[start:ans2.start(1)-1]
		index=index+1
		a.append( [ans2.group(1), ans2.group(2), ""] )
		start=ans2.end(0)+1
		ans2= chap_patt.search(contenu, start)


	a[index][2]=contenu[start:]		#write the last  

	source.close()


	#great ! we have what we want now :)
	
	
	
	
	
	########################################
	# adding links section
	#chapitre
	#au
	#:
	#num/ero
	
	
	
	
	########################################
	#formatting 
	# <BR/>
	# tabs
	
	
	########################################
	#output the files

	pre_title = '''<HTML xmlns:dc="http://purl.org/dc/elements/1.1/">
	<HEAD>
	<META property="dc:creator" value="Ivan Savov" />	
	<TITLE>'''

	post_head = '''</TITLE>
	</HEAD>
	<BODY>
	'''

	post_body = '''
	</BODY>\n</HTML>
	
	'''


	for x in a:
		cur_file = open("Secondaire5split/"+x[0]+".html",'w')
		cur_file.write(pre_title)
		cur_file.write(x[0]+". " +x[1])
		cur_file.write(post_head)
		cur_file.write("<H2>"+x[0]+". "+x[1]+"</H2><BR/>")
		cur_file.write(x[2])
		cur_file.write(post_body)
		cur_file.close()





if __name__ == '__main__':
	
	if len(sys.argv) > 1 and sys.argv[1] == "clean":
		cleanup()
		sys.exit()
	
	main()