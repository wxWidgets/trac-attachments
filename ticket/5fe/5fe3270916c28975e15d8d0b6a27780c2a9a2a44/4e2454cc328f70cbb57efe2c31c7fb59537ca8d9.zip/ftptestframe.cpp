/////////////////////////////////////////////////////////////////////////////
// Name:        ftptestframe.cpp
// Purpose:     
// Author:      Ralph Pass
// Modified by: 
// Created:     Sat 17 Sep 07:37:29 2011
// RCS-ID:      
// Copyright:   Copyright (c) 2011 Ralph P. Pass III
// Licence:     
/////////////////////////////////////////////////////////////////////////////

// For compilers that support precompilation, includes "wx/wx.h".
#include "wx/wxprec.h"

#ifdef __BORLANDC__
#pragma hdrstop
#endif

#ifndef WX_PRECOMP
#include "wx/wx.h"
#endif

////@begin includes
////@end includes

#include "ftptestframe.h"
#include "wx/protocol/ftp.h"
#include <fstream>
using namespace std;
extern ofstream ftpout;

////@begin XPM images
////@end XPM images


/*
 * FTPTest type definition
 */

IMPLEMENT_CLASS( FTPTest, wxFrame )


/*
 * FTPTest event table definition
 */

BEGIN_EVENT_TABLE( FTPTest, wxFrame )

////@begin FTPTest event table entries
    EVT_PAINT( FTPTest::OnPaint )
    EVT_MOTION( FTPTest::OnMotion )

    EVT_MENU( ID_MENUITEM, FTPTest::OnMenuitemClick )

////@end FTPTest event table entries
    EVT_TIMER(0x3200, FTPTest::OnTimer)
    
END_EVENT_TABLE()


/*
 * FTPTest constructors
 */

FTPTest::FTPTest()
: mTimer(this, 0x3200)
{
    Init();
}

FTPTest::FTPTest( wxWindow* parent, wxWindowID id, const wxString& caption, const wxPoint& pos, const wxSize& size, long style )
: mTimer(this, 0x3200)
{
    Init();
    Create( parent, id, caption, pos, size, style );
}


/*
 * FTPTest creator
 */

bool FTPTest::Create( wxWindow* parent, wxWindowID id, const wxString& caption, const wxPoint& pos, const wxSize& size, long style )
{
////@begin FTPTest creation
    wxFrame::Create( parent, id, caption, pos, size, style );

    CreateControls();
    Centre();
////@end FTPTest creation
    return true;
}


/*
 * FTPTest destructor
 */

FTPTest::~FTPTest()
{
////@begin FTPTest destruction
////@end FTPTest destruction
}


/*
 * Member initialisation
 */

void FTPTest::Init()
{
////@begin FTPTest member initialisation
////@end FTPTest member initialisation
    mMessage = "FTP Test Program";
}


/*
 * Control creation for FTPTest
 */

void FTPTest::CreateControls()
{    
////@begin FTPTest content construction
    FTPTest* itemFrame1 = this;

    wxMenuBar* menuBar = new wxMenuBar;
    wxMenu* itemMenu3 = new wxMenu;
    itemMenu3->Append(ID_MENUITEM, _("&Test"), wxEmptyString, wxITEM_NORMAL);
    menuBar->Append(itemMenu3, _("Menu"));
    itemFrame1->SetMenuBar(menuBar);

////@end FTPTest content construction
}


/*
 * Should we show tooltips?
 */

bool FTPTest::ShowToolTips()
{
    return true;
}

/*
 * Get bitmap resources
 */

wxBitmap FTPTest::GetBitmapResource( const wxString& name )
{
    // Bitmap retrieval
////@begin FTPTest bitmap retrieval
    wxUnusedVar(name);
    return wxNullBitmap;
////@end FTPTest bitmap retrieval
}

/*
 * Get icon resources
 */

wxIcon FTPTest::GetIconResource( const wxString& name )
{
    // Icon retrieval
////@begin FTPTest icon retrieval
    wxUnusedVar(name);
    return wxNullIcon;
////@end FTPTest icon retrieval
}


/*
 * wxEVT_COMMAND_MENU_SELECTED event handler for ID_MENUITEM
 */

void FTPTest::OnMenuitemClick( wxCommandEvent& event )
{
    mMessage = "Start of test";
    Refresh();
    wxTheApp->Dispatch();
    wxString host = "www.rppass.com";
    wxString user = "rppass";
    wxString password = "j.morris";
    wxArrayString files;
    //files.Add("testimage1.jpg");
    //files.Add("testimage2.jpg");
    
    mTimer.Start(1);
    wxFTP ftp;
    ftp.SetUser(user);
	ftp.SetPassword(password);
    mMessage = "ready to connect";
    Refresh();
    wxTheApp->Dispatch();
    if ( !ftp.Connect(host))
    {
        mMessage = "Did not connect";
        Refresh();
        wxTheApp->Dispatch();
        return;
    }
    ftpout << "After ftp connect" << endl;
    mMessage = "Start of connect, two mode changes";
    Refresh();
    wxTheApp->Dispatch();
    ftp.SetAscii();
    ftp.SetBinary();
    mMessage = "Start of looking for files";
    Refresh();
    wxTheApp->Dispatch();
    
    for (unsigned int idx = 0; idx < files.Count(); idx++)
    {
         wxOutputStream *out = ftp.GetOutputStream(files[idx]);
        if ( out )
        {
                ifstream in(files[idx], ios::binary);
                in.seekg(0, ios::end);
                size_t size = in.tellg();
                in.seekg(0, ios::beg);
                int bufferSize = 1000;
                char *bufferPtr = new char[bufferSize];
                int cnt = 0;
                mMessage = "Sending " + files[idx];
                Refresh();
                wxTheApp->Dispatch();
                while (cnt < int(size) && bufferSize > 0)
                {
                    bufferSize = min(bufferSize, int(size) - cnt);
                    in.read(bufferPtr, bufferSize);
                    bufferSize = in.gcount();
                    cnt += bufferSize;
                    out->Write(bufferPtr, bufferSize); // your data         
                    if (int(out->LastWrite()) != bufferSize)
                    {
                    }
                    mMessage = wxString::Format("%s   %d of %d", files[idx], cnt, (int)size);
                    Refresh();
                    wxTheApp->Dispatch();
                }
                in.close();
                delete [] bufferPtr;
                bufferPtr = 0;
                mMessage = wxString::Format("Done with %s", files[idx]);
                Refresh();
                wxTheApp->Dispatch();
       }
       delete out;
    }
    mTimer.Stop();
    mMessage = "Completed";
    Refresh();
    wxTheApp->Dispatch();
 }


/*
 * wxEVT_PAINT event handler for ID_FTPTEST
 */

void FTPTest::OnPaint( wxPaintEvent& event )
{
////@begin wxEVT_PAINT event handler for ID_FTPTEST in FTPTest.
    // Before editing this code, remove the block markers.
    wxPaintDC dc(this);
////@end wxEVT_PAINT event handler for ID_FTPTEST in FTPTest. 
    dc.DrawText(mMessage, 10, 10);
}

int cnt = 0;
int mouseCnt = 0;
void FTPTest::OnTimer(wxTimerEvent &)
{
    ++cnt;
    if ((cnt % 1000) == 0)
    {
        wxMilliSleep(10);
    ftpout << cnt << "   " << mouseCnt << endl;
        wxMouseEvent event(wxEVT_MOTION);
        this->AddPendingEvent(event);
        wxTheApp->Dispatch();
    }
}


/*
 * wxEVT_MOTION event handler for ID_FTPTEST
 */

void FTPTest::OnMotion( wxMouseEvent& event )
{
    ++mouseCnt;
////@begin wxEVT_MOTION event handler for ID_FTPTEST in FTPTest.
    // Before editing this code, remove the block markers.
    event.Skip();
////@end wxEVT_MOTION event handler for ID_FTPTEST in FTPTest. 
}

