/////////////////////////////////////////////////////////////////////////////
// Name:        ftptestframe.h
// Purpose:     
// Author:      Ralph Pass
// Modified by: 
// Created:     Sat 17 Sep 07:37:29 2011
// RCS-ID:      
// Copyright:   Copyright (c) 2011 Ralph P. Pass III
// Licence:     
/////////////////////////////////////////////////////////////////////////////

#ifndef _FTPTESTFRAME_H_
#define _FTPTESTFRAME_H_


/*!
 * Includes
 */

////@begin includes
#include "wx/frame.h"
////@end includes

/*!
 * Forward declarations
 */

////@begin forward declarations
////@end forward declarations

/*!
 * Control identifiers
 */

////@begin control identifiers
#define ID_FTPTEST 10000
#define ID_MENUITEM 10002
#define SYMBOL_FTPTEST_STYLE wxCAPTION|wxRESIZE_BORDER|wxSYSTEM_MENU|wxCLOSE_BOX
#define SYMBOL_FTPTEST_TITLE _("FTP Test")
#define SYMBOL_FTPTEST_IDNAME ID_FTPTEST
#define SYMBOL_FTPTEST_SIZE wxSize(400, 300)
#define SYMBOL_FTPTEST_POSITION wxDefaultPosition
////@end control identifiers


/*!
 * FTPTest class declaration
 */

class FTPTest: public wxFrame
{    
    DECLARE_CLASS( FTPTest )
    DECLARE_EVENT_TABLE()

public:
    /// Constructors
    FTPTest();
    FTPTest( wxWindow* parent, wxWindowID id = SYMBOL_FTPTEST_IDNAME, const wxString& caption = SYMBOL_FTPTEST_TITLE, const wxPoint& pos = SYMBOL_FTPTEST_POSITION, const wxSize& size = SYMBOL_FTPTEST_SIZE, long style = SYMBOL_FTPTEST_STYLE );

    bool Create( wxWindow* parent, wxWindowID id = SYMBOL_FTPTEST_IDNAME, const wxString& caption = SYMBOL_FTPTEST_TITLE, const wxPoint& pos = SYMBOL_FTPTEST_POSITION, const wxSize& size = SYMBOL_FTPTEST_SIZE, long style = SYMBOL_FTPTEST_STYLE );

    /// Destructor
    ~FTPTest();

    /// Initialises member variables
    void Init();

    /// Creates the controls and sizers
    void CreateControls();

////@begin FTPTest event handler declarations

    /// wxEVT_PAINT event handler for ID_FTPTEST
    void OnPaint( wxPaintEvent& event );

    /// wxEVT_MOTION event handler for ID_FTPTEST
    void OnMotion( wxMouseEvent& event );

    /// wxEVT_COMMAND_MENU_SELECTED event handler for ID_MENUITEM
    void OnMenuitemClick( wxCommandEvent& event );

////@end FTPTest event handler declarations

////@begin FTPTest member function declarations

    /// Retrieves bitmap resources
    wxBitmap GetBitmapResource( const wxString& name );

    /// Retrieves icon resources
    wxIcon GetIconResource( const wxString& name );
////@end FTPTest member function declarations

    /// Should we show tooltips?
    static bool ShowToolTips();
    void OnTimer(wxTimerEvent &event);

////@begin FTPTest member variables
private:
    wxString mMessage;
////@end FTPTest member variables
    wxTimer mTimer;
};

#endif
    // _FTPTESTFRAME_H_
