/////////////////////////////////////////////////////////////////////////////
// Name:        ftptestapp.h
// Purpose:     
// Author:      Ralph Pass
// Modified by: 
// Created:     Sat 17 Sep 07:36:51 2011
// RCS-ID:      
// Copyright:   Copyright (c) 2011 Ralph P. Pass III
// Licence:     
/////////////////////////////////////////////////////////////////////////////

#ifndef _FTPTESTAPP_H_
#define _FTPTESTAPP_H_


/*!
 * Includes
 */

////@begin includes
#include "wx/image.h"
#include "ftptestframe.h"
////@end includes

/*!
 * Forward declarations
 */

////@begin forward declarations
////@end forward declarations

/*!
 * Control identifiers
 */

////@begin control identifiers
////@end control identifiers

/*!
 * FtptestApp class declaration
 */

class FtptestApp: public wxApp
{    
    DECLARE_CLASS( FtptestApp )
    DECLARE_EVENT_TABLE()

public:
    /// Constructor
    FtptestApp();

    void Init();

    /// Initialises the application
    virtual bool OnInit();

    /// Called on exit
    virtual int OnExit();

////@begin FtptestApp event handler declarations

////@end FtptestApp event handler declarations

////@begin FtptestApp member function declarations

////@end FtptestApp member function declarations

////@begin FtptestApp member variables
////@end FtptestApp member variables
};

/*!
 * Application instance declaration 
 */

////@begin declare app
DECLARE_APP(FtptestApp)
////@end declare app

#endif
    // _FTPTESTAPP_H_
