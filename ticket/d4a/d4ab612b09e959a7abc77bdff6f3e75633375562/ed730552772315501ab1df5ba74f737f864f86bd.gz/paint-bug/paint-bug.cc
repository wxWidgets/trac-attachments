#include "wx/xrc/xmlres.h"
#include "wx/panel.h"
#include "wx/radiobut.h"
#include "wx/spinctrl.h"
#include "wx/radiobox.h"
#include "wx/sizer.h"
#include "wx/app.h"



class MyApp : public wxApp
{
public:
    virtual bool OnInit();
};



class MyFrame : public wxFrame
{
public:
  MyFrame(const wxString& title,
          const wxPoint& pos = wxDefaultPosition,
          const wxSize& size = wxDefaultSize);

  void OnShowHidePanel(wxCommandEvent& event);

private:
  wxBoxSizer* m_top_sizer;

  wxPanel* m_panel_sh;
  wxRadioButton* m_radiobut_00;
  wxSpinCtrl* m_spin_00;
  wxRadioBox* m_radiobox_00;
  wxRadioBox* m_radiobox_sh;

  DECLARE_EVENT_TABLE()
};



BEGIN_EVENT_TABLE(MyFrame, wxFrame)
  EVT_RADIOBOX(XRCID("radiobox_sh"),  MyFrame::OnShowHidePanel)
END_EVENT_TABLE()

IMPLEMENT_APP(MyApp)



bool MyApp::OnInit()
{
  wxXmlResource::Get()->InitAllHandlers();
  wxXmlResource::Get()->Load("resource.xrc");

  MyFrame* frame = new MyFrame("app frame");
  frame->Show(true);

  return true;
}



MyFrame::MyFrame(const wxString& title, const wxPoint& pos, const wxSize& size) :
  wxFrame((wxFrame *)NULL, wxID_ANY, title, pos, size)
{
  wxXmlResource* myxrc = wxXmlResource::Get();

  m_top_sizer = new wxBoxSizer(wxVERTICAL);

  wxPanel* pnl = myxrc->LoadPanel(this, wxT("panel_00"));
  m_top_sizer->Add(pnl);

  m_radiobox_sh = XRCCTRL(*this, "radiobox_sh", wxRadioBox);
  
  m_panel_sh = XRCCTRL(*this, "panel_sh", wxPanel);
  m_panel_sh->Hide();
  wxSizer* sizer = m_panel_sh->GetContainingSizer();
  sizer->Show(m_panel_sh, false, true);

  m_radiobut_00 = XRCCTRL(*this, "radiobut_00", wxRadioButton);
  m_spin_00 = XRCCTRL(*this, "spin_00", wxSpinCtrl);
  
  m_radiobox_00 = XRCCTRL(*this, "radiobox_00", wxRadioBox);
  
  SetSizer(m_top_sizer);
  m_top_sizer->Layout();
  m_top_sizer->SetSizeHints(this);

  SetBackgroundColour(wxNullColour);
  Refresh();
}



void
MyFrame::OnShowHidePanel(wxCommandEvent& event)
{
  int sel = event.GetInt();
//   cout << "OnEnsModeChange sel = " << sel << endl;
  wxSizer* sizer = m_panel_sh->GetContainingSizer();
  if (sel == 0)
    {
//       m_panel_sh->Show(true);
      sizer->Show(m_panel_sh, true, true);
    }
  else
    {
//       m_panel_hs->ClearBackground();
//       m_panel_sh->Show(false);
      sizer->Show(m_panel_sh, false, true);
    }
//   Freeze();
  sizer->Layout();
  m_top_sizer->Layout();
  m_top_sizer->SetSizeHints(this);
  this->Fit();
//   Refresh();
//   Thaw();
}



