#include <wx/wxprec.h>
#ifndef WX_PRECOMP
	#include <wx/wx.h>
#endif
#include "wx/xrc/xmlres.h"


class MyApp : public wxApp
{
public:
	bool OnInit();
};

class MyFrame : public wxFrame
{
public:
	MyFrame();
	void OnAnyButton(wxCommandEvent &event);
	
private:
	wxDECLARE_EVENT_TABLE();
};


bool MyApp::OnInit()
{
	wxXmlResource::Get()->InitAllHandlers();


	if ( !wxXmlResource::Get()->LoadAllFiles(".") ) return false;

	MyFrame *frame = new MyFrame();
	frame->Show(true);
	return true;
}

wxIMPLEMENT_APP(MyApp);


wxBEGIN_EVENT_TABLE(MyFrame, wxFrame)
	EVT_BUTTON(wxID_ANY, MyFrame::OnAnyButton)
wxEND_EVENT_TABLE()

MyFrame::MyFrame()
{
	wxXmlResource::Get()->LoadFrame(this, NULL, "hello");
}

void MyFrame::OnAnyButton(wxCommandEvent &event)
{
	int id = event.GetId();

	if(id == XRCID("m_buttonMy"))
	{
		wxLogMessage("you clicked my button");
	}
	else if(id == XRCID("m_buttonYour"))
	{
		wxLogMessage("you clicked your button");
	}
}
