// For compilers that support precompilation, includes "wx.h".
#include "wx/wxprec.h"

#ifdef __BORLANDC__
#pragma hdrstop
#endif

#ifndef WX_PRECOMP
#include "wx/wx.h"
#endif

class MyCanvas;

#include "canvas.h"
#include "Minimal.h"
#include "sprite.h"

BEGIN_EVENT_TABLE(MyCanvas, wxPanel)
    EVT_PAINT(MyCanvas::OnPaint)
    EVT_ERASE_BACKGROUND(MyCanvas::OnEraseBackground)
END_EVENT_TABLE()

MyCanvas::MyCanvas(MyFrame* parent, const wxSize& size)
    : wxPanel((wxWindow*) parent, -1, wxDefaultPosition, size, wxNO_BORDER | wxWANTS_CHARS )
{
    pFrame = parent ;
    
    
    //Bitmap in memory
    canvasBMP = new wxBitmap(640, 480, -1);   
    memDC = new wxMemoryDC(*canvasBMP);

    //Load Background (no mask)
    backgroundBMP = new wxBitmap(wxT("background.bmp"), wxBITMAP_TYPE_BMP);
    
    //Load and mask enemy bitmap
    enemyBMP = new wxBitmap(wxT("enemy.bmp"), wxBITMAP_TYPE_BMP);
   	mask = new wxMask(*enemyBMP, *wxBLACK);
    enemyBMP -> SetMask(mask);    
    
    //Load, position and mask enemy sprite
    enemy = new Sprite(this, 500, 350, wxT("enemy.bmp"));
    enemy -> SetMask (*wxBLACK);
}


MyCanvas::~MyCanvas ()
{
    delete memDC;
    delete enemyBMP;
    delete canvasBMP;
    delete backgroundBMP;
    
    //delete sprite
    delete enemy;
}


//Empty implementation, to prevent flicker
void MyCanvas::OnEraseBackground (wxEraseEvent & event)
{

} 


void MyCanvas::OnPaint (wxPaintEvent & event)
{
   wxPaintDC PaintDC(this);
   DrawAll();
   PaintDC.Blit( 0, 0, 640, 480, memDC, 0, 0 );
}
 

//Note: Declared but not used in this minimal example
void MyCanvas::Paint ()
{
    wxClientDC ClientDC(this);
    DrawAll();
    ClientDC.Blit( 0, 0, 640, 480, memDC, 0, 0 );
}

 
void MyCanvas::DrawAll ()
{
    //Draw background
    memDC -> DrawBitmap(*backgroundBMP, 0, 0, false);
    //Draw enemy bitmap
    memDC -> DrawBitmap(*enemyBMP, 100, 100, true);
    //Draw enemy sprite
    enemy -> Render();
}
