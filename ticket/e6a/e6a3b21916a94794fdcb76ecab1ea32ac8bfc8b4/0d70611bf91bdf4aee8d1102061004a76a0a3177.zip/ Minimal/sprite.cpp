#include "wx/wxprec.h" 

#ifdef __BORLANDC__ 
#pragma hdrstop 
#endif 


#ifndef WX_PRECOMP 
#include "wx/wx.h" 
#endif 

class Sprite;

#include "sprite.h"
#include "canvas.h"

Sprite::Sprite(MyCanvas *parent, int xpos, int ypos, const wxString& filepath, int filetype)
{
   pCanvas = parent;
   x = xpos;
   y = ypos;
   bitmap = new wxBitmap(filepath,filetype);
   bUseMask = false;
}
    
Sprite::~Sprite()
{
   if (bUseMask)    {delete mask;} 
   delete bitmap;
}
     
void Sprite::Render()
{
    pCanvas -> memDC -> DrawBitmap(*bitmap, x, y, bUseMask);
}

void Sprite::SetMask(const wxColour& colour)
{
    mask = new wxMask(*bitmap, colour);
    bitmap -> SetMask(mask);
    bUseMask = true;
}
