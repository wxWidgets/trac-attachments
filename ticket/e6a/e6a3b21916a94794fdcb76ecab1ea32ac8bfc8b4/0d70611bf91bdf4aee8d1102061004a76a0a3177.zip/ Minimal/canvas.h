#ifndef _canvas_h 
#define _canvas_h

class MyFrame;
class Sprite;

class MyCanvas: public wxPanel
{
public: 
    MyCanvas(MyFrame* parent, const wxSize& size);   
    
    ~MyCanvas ();
    
    void OnEraseBackground (wxEraseEvent & event);
    void OnPaint (wxPaintEvent & event);
   
    wxMemoryDC* memDC;

private:

    void Paint () ;
    void DrawAll () ;   
    
    //Flag for quitting
    
    MyFrame *pFrame ;
    wxBitmap *canvasBMP ;
    wxBitmap *backgroundBMP ;
    wxBitmap *enemyBMP ;
    wxMask *mask ;
   
    //Sprite
    Sprite* enemy;
 
    DECLARE_EVENT_TABLE()
};

#endif


