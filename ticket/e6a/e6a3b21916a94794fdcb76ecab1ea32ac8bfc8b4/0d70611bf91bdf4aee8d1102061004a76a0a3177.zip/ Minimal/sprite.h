#ifndef _sprite_h
#define _sprite_h

class MyCanvas;

class Sprite
{
public:
    Sprite(MyCanvas *parent, int xpos, int ypos, const wxString& filepath, int filetype = wxBITMAP_TYPE_BMP);
    
    ~Sprite();
    
    void Render();
    
    void SetMask(const wxColour& colour);

protected:
    int x;
    int y;
    bool bUseMask;
    MyCanvas *pCanvas;
    wxBitmap *bitmap;
    wxMask *mask;
};

#endif
