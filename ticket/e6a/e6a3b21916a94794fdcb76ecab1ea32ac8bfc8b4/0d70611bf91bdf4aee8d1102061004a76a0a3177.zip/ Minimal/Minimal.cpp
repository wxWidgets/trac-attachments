// For compilers that support precompilation, includes "wx.h".
#include "wx/wxprec.h"

#ifdef __BORLANDC__
#pragma hdrstop
#endif

#ifndef WX_PRECOMP
#include "wx/wx.h"
#endif

#include <wx/image.h>
#include <wx/filename.h>

#if wxCHECK_VERSION(2, 6, 0)
#include <wx/stdpaths.h> 
#endif

class MyFrame ;

#include "Minimal.h"
#include "canvas.h" 

BEGIN_EVENT_TABLE(MyFrame, wxFrame)
    EVT_CLOSE(MyFrame::OnClose)
END_EVENT_TABLE()

IMPLEMENT_APP(MyApp)

bool MyApp::OnInit()
{
   
    MyFrame *frame = new MyFrame (wxT("Minimal"),
                                  wxPoint(300, 10), wxSize(-1, -1));
    frame -> SetClientSize (frame -> canvas -> GetSize());
    frame-> Show (true);
    frame -> canvas -> SetFocus();
    
   ::wxInitAllImageHandlers();

    return TRUE;
}

MyFrame::MyFrame(const wxString& title, const wxPoint& pos, const wxSize& size)
   : wxFrame((wxFrame *)NULL, -1, title, pos, size, wxCAPTION | wxMINIMIZE_BOX | wxCLOSE_BOX)
 
{
// create a child control
    canvas = new MyCanvas(this, wxSize( 640, 480 ));   
}


MyFrame::~MyFrame ()
{

}


void MyFrame::OnClose (wxCloseEvent& event)
{
    event.Skip();
}



 
