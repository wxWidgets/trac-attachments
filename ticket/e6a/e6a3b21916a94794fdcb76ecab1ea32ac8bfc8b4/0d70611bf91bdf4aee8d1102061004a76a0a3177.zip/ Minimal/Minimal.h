#ifndef _minimal_h
#define _minimal_h

class MyApp: public wxApp
{
public:
    virtual bool OnInit();
};

class MyCanvas;

class MyFrame: public wxFrame
{
public:
    MyFrame(const wxString& title, const wxPoint& pos, const wxSize& size);
    
    ~MyFrame ();
     
    MyCanvas * canvas ;
       
    void OnClose (wxCloseEvent& event);
 
private:

    DECLARE_EVENT_TABLE()
};

#endif
