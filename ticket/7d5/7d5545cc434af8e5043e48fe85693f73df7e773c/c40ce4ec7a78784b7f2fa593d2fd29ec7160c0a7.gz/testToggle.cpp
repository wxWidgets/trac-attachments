#include "testToggle.h"

enum
{
	ID_CHECK_SPLIT=wxID_ANY+1,
	ID_FULLSCREEN_TOGGLE,
};

MyFrame::MyFrame(wxWindow* parent, int id, const wxString& title, const wxPoint& pos, const wxSize& size, long style):
    wxFrame(parent, id, title, pos, size, wxDEFAULT_FRAME_STYLE)
{
    window_1 = new wxSplitterWindow(this, wxID_ANY, wxDefaultPosition, wxDefaultSize, wxSP_3D|wxSP_BORDER);
    window_1_pane_2 = new wxPanel(window_1, wxID_ANY);
    window_1_pane_1 = new wxPanel(window_1, wxID_ANY);
    label_1 = new wxStaticText(window_1_pane_1, wxID_ANY, _("Left"));
    label_2 = new wxStaticText(window_1_pane_2, wxID_ANY, _("Right"));
    myMenubar = new wxMenuBar();
    wxMenu* main = new wxMenu();
    main->Append(ID_CHECK_SPLIT, _("Toggle Split\tCtrl+S"), wxEmptyString, wxITEM_CHECK);
    main->Append(ID_FULLSCREEN_TOGGLE, _("Fullscreen\tF11"), wxEmptyString, wxITEM_NORMAL);
    myMenubar->Append(main, _("main"));
    SetMenuBar(myMenubar);

    set_properties();
    do_layout();
}


void MyFrame::set_properties()
{
    SetTitle(_("frame_1"));
}


void MyFrame::do_layout()
{
    wxBoxSizer* sizer_1 = new wxBoxSizer(wxVERTICAL);
    wxBoxSizer* sizer_3 = new wxBoxSizer(wxHORIZONTAL);
    wxBoxSizer* sizer_2 = new wxBoxSizer(wxHORIZONTAL);
    sizer_2->Add(label_1, 0, 0, 0);
    window_1_pane_1->SetSizer(sizer_2);
    sizer_3->Add(label_2, 0, 0, 0);
    window_1_pane_2->SetSizer(sizer_3);
    window_1->SplitVertically(window_1_pane_1, window_1_pane_2);
    sizer_1->Add(window_1, 1, wxEXPAND, 0);
    SetSizer(sizer_1);
    sizer_1->Fit(this);
    Layout();
}


BEGIN_EVENT_TABLE(MyFrame, wxFrame)
    EVT_MENU(ID_CHECK_SPLIT, MyFrame::OnMenuSplitToggle)
    EVT_MENU(ID_FULLSCREEN_TOGGLE, MyFrame::OnMenuFullscreen)
END_EVENT_TABLE();


void MyFrame::OnMenuSplitToggle(wxCommandEvent &event)
{
        if(!window_1->IsSplit())
        {
                const float SPLIT_FACTOR=0.3;
                int x,y; 
                GetClientSize(&x,&y);
                window_1->SplitVertically(window_1_pane_1,
                                        window_1_pane_2,(int)(SPLIT_FACTOR*x));

        }
        else 
        {
                window_1->Unsplit();
        }
        event.Skip();

}

void MyFrame::OnMenuFullscreen(wxCommandEvent &event)
{
	static bool fullscreenState=false;

	ShowFullScreen(!fullscreenState);
	fullscreenState=!fullscreenState;
}


class MyApp: public wxApp {
public:
    bool OnInit();
protected:
    wxLocale m_locale;  // locale we'll be using
};

IMPLEMENT_APP(MyApp)

bool MyApp::OnInit()
{
    m_locale.Init();
#ifdef APP_LOCALE_DIR
    m_locale.AddCatalogLookupPathPrefix(wxT(APP_LOCALE_DIR));
#endif
    m_locale.AddCatalog(wxT(APP_CATALOG));

    wxInitAllImageHandlers();
    MyFrame* frame_1 = new MyFrame(NULL, wxID_ANY, wxEmptyString);
    SetTopWindow(frame_1);
    frame_1->Show();
    return true;
}
