import os
import os.path
import sys

import wx
from wx.webview import WebView

class WebViewFrame(wx.Frame):
    def __init__(self, app, *args, **kwargs):
        wx.Frame.__init__(self, None, title='WebKit Wrapper')

        # current data file
        self.data_path = None

        # pull down menus
        file_menu = wx.Menu()
        load_app = file_menu.Append(wx.ID_ANY, '&Load File...\tCtrl-L')
        exit = file_menu.Append(wx.ID_EXIT)

        menu_bar = wx.MenuBar()
        menu_bar.Append(file_menu, '&File')
        self.SetMenuBar(menu_bar)

        self.Bind(wx.EVT_MENU, self.LoadApplication, load_app)
        self.Bind(wx.EVT_MENU, lambda e: self.Close(), exit)

        # webview
        self.wv = WebView(self)

    def LoadApplication(self, event):
        with wx.FileDialog(self,  
                           wildcard='(*.htm)|*.htm*',
                           style=wx.FD_OPEN | wx.FD_CHANGE_DIR) as dlg:
            if dlg.ShowModal() == wx.ID_OK:
                f='C:\Files\NSBX1\nsbx\gist-f7d66d86\wxWebKitFontBug.html'
                self.wv.LoadURL('file://' + os.path.abspath(dlg.Path))

if __name__ == '__main__':
    app = wx.PySimpleApp()
    frame = WebViewFrame(''.join(sys.argv[1:]))
    frame.Show()
    app.MainLoop()
