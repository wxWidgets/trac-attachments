
// Don't modify comment 
#include "MyDlg.h"
//[inc]add your include files here


//[inc]end your include
 

MyDlg::MyDlg(wxWindow* parent,wxWindowID id,const wxString& title,const wxPoint& pos,const wxSize& size,long style,const wxString& name)
  VwX_INIT_OBJECTS_MyDlg
{
 OnPreCreate();
 Create(parent,id,title,pos,size,style,name);

 if((pos==wxDefaultPosition)&&(size==wxDefaultSize)){
     SetSize(0,0,405,330);
 }

 if((pos!=wxDefaultPosition)&&(size==wxDefaultSize)){
     SetSize(405,330);
 }
 initBefore();
 VwXinit();initAfter();
}
MyDlg::~MyDlg()
{
  st3->PopEventHandler(true);
  delete Menu3;
  DMyDlg();
}
void MyDlg::VwXinit()
{
 wxMenuItem *itemmenu;
 Menu3=new wxMenu();
 itemmenu = new wxMenuItem(Menu3,ID_MENU_4,wxT("static menu clik"),wxT(""),0);
   Menu3->Append(itemmenu);
 st3=new wxStaticText(this,-1,wxT(""),wxPoint(80,25),wxSize(220,27),wxST_NO_AUTORESIZE);
   st3->SetLabel(wxT("press right button"));
   st3->SetFont(wxFont(12,74,90,90,0,wxT("Microsoft Sans Serif")));
   st3->PushEventHandler(new MyDlgEvt(this));
 Refresh();
}
 
BEGIN_EVENT_TABLE(MyDlgEvt,wxEvtHandler)
  EVT_RIGHT_UP(MyDlgEvt::VwXEvOnRightUP)
//[evtEvt]add your code here


//[evtEvt]end your code
END_EVENT_TABLE()
void MyDlgEvt::VwXEvOnRightUP(wxMouseEvent& event){
 ptr_winPan->VwXVwXEvOnRightUP(event);
}
 
BEGIN_EVENT_TABLE( MyDlg,wxDialog)
  EVT_RIGHT_UP(MyDlg::VwXVwXEvOnRightUP)
  EVT_MENU(ID_MENU_4,MyDlg::click)
//[evtwin]add your code here


//[evtwin]end your code
END_EVENT_TABLE()
void MyDlg::VwXVwXEvOnRightUP(wxMouseEvent& event){
 wxObject *m_wxWin = event.GetEventObject();
 if(m_wxWin==st3){event.Skip(true);r_click(event,-1);return;}
 event.Skip(true);
}

//[evtFunc]add your code here

void MyDlg::r_click(wxMouseEvent& event,int index){ //init function
 //[440]Code event VwX...Don't modify[440]//
 //add your code here
 PopupMenu(Menu3);
} //end function

void MyDlg::click(wxCommandEvent& event){ //init function
 //[787]Code menu VwX...Don't modify[787]//
 //add your code here
 st3->SetLabel(Menu3->GetLabel(event.GetId()));
 if (Menu3->GetLabel(event.GetId())=="static menu clik") wxMessageBox(wxT("no bug? huh... try dynamic clik!"));
} //end function

void MyDlg::initBefore(){
 //add your code here

}

void MyDlg::initAfter(){
 //add your code here
 Centre();
 Menu3->Append(new wxMenuItem (Menu3, 12345, wxT("dynamic menu clik"), wxT(""), 0));
 Menu3->Connect(12345, wxEVT_COMMAND_MENU_SELECTED, (wxObjectEventFunction)(wxEventFunction)(wxCommandEventFunction)&MyDlg::click);
}

void MyDlg::OnPreCreate(){
 //add your code here

}

void MyDlg::DMyDlg(){
 //add your code here

}

//[evtFunc]end your code
