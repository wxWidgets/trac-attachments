
// Don't modify comment 
#ifndef __VwX_MyDlg_H__
#define __VwX_MyDlg_H__

 #include <wx/wxprec.h>

#ifdef __BORLANDC__
    #pragma hdrstop
#endif

#ifndef WX_PRECOMP
    #include <wx/wx.h>
#endif
#include <wx/wx.h>
 
//[inc]add your include files here



//[inc]end your include
 
#define ID_MENU_4 4
class MyDlg;
class MyDlgEvt:public wxEvtHandler
{
public:
 MyDlgEvt(MyDlg *parent){ptr_winPan=parent;}
protected:  
 MyDlg *ptr_winPan;
 DECLARE_EVENT_TABLE()     
 void VwXEvOnRightUP(wxMouseEvent& event);
//[evt]add your code here



//[evt]end your code
};

class MyDlg:public wxDialog
{
 friend class MyDlgEvt;
public:
 MyDlg(wxWindow* parent, wxWindowID id = -1, const wxString& title = wxT(""), const wxPoint& pos = wxDefaultPosition, const wxSize& size = wxDefaultSize, long style = wxCAPTION|wxRESIZE_BORDER|wxSYSTEM_MENU|wxCLOSE_BOX|wxDIALOG_NO_PARENT|wxDEFAULT_DIALOG_STYLE|wxMINIMIZE_BOX|wxMAXIMIZE_BOX, const wxString& name = wxT("dialogBox"));
// Pointer control
 wxMenu *Menu3;
 wxStaticText *st3;
 virtual ~MyDlg();
 void DMyDlg();
 void initBefore();
 void OnPreCreate();
 void VwXinit();
 void initAfter();
protected:
 void VwXVwXEvOnRightUP(wxMouseEvent& event);
 void r_click(wxMouseEvent& event,int index=-1);
 void click(wxCommandEvent& event);
 DECLARE_EVENT_TABLE()  
//[win]add your code here



 #define VwX_INIT_OBJECTS_MyDlg
//[win]end your code 
};
// end MyDlg

#endif
