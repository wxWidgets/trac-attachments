#ifndef __MyApp_H__
#define __MyApp_H__

#include <wx/app.h>

class MyApp : public wxApp
{
public:
    bool VwXinitApp();
    virtual bool OnInit();
};

DECLARE_APP(MyApp)

#endif

