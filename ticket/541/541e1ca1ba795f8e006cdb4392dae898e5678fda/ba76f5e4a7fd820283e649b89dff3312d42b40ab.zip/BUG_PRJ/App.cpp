#include "app.h"
#include "MyDlg.h"

IMPLEMENT_APP(MyApp)


bool MyApp::OnInit()
{
    VwXinitApp();
    MyDlg *dlg = new MyDlg(NULL,-1,"");
    dlg->ShowModal();
    return FALSE;
}
