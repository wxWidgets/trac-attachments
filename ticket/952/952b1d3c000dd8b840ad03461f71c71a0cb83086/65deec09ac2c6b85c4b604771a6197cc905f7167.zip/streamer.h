#include <wx\wx.h>
#include <wx\xml\xml.h>
#include <wx\txtstrm.h>
#include <wx\wfstream.h>
#include <wx\xtistrm.h>
#include <wx\xtixml.h>
#pragma hdrstop

template <class T>
void StreamOut(const T* frame, wxString& filename)
{
  wxXmlDocument xml;
  wxXmlNode *root;
  const wxChar* rootNodeName = "wxWindowsXTI";
  root = new wxXmlNode(wxXML_ELEMENT_NODE, rootNodeName, "This is the content");
  xml.SetRoot(root);
  wxXmlWriter writer(root) ;
  wxPersister* persister = new wxPersister();
  wxxVariantArray metadata ;
  const wxClassInfo* classinfo = frame->GetClassInfo();
  const wxString name = wxT("form");

  writer.WriteObject((const wxObject*) frame , classinfo , persister , name, metadata ) ;

  xml.Save(filename);
}

template <class T>
void StreamOut(const T* frame, const wxString& framename, const wxString& filename)
{
  printf("Streaming out %s to file %s\n", framename.c_str(), filename.c_str());
  wxXmlDocument xml;
  wxXmlNode *root;
  const wxChar* rootNodeName = "wxWindowsXTI";
  root = new wxXmlNode(wxXML_ELEMENT_NODE, rootNodeName, "This is the content");
  xml.SetRoot(root);
  wxXmlWriter writer(root) ;
  wxPersister* persister = new wxPersister();
  wxxVariantArray metadata ;
  const wxClassInfo* classinfo = frame->GetClassInfo();

  writer.WriteObject((const wxObject*) frame , classinfo , persister , framename, metadata ) ;

  xml.Save(filename);
}

wxObject* LoadForm(wxString& objname, wxString& filename) 
{ 
    printf("Loading %s from file %s\n", objname.c_str(), filename.c_str());
    wxXmlDocument xml; 
    wxXmlNode *root; 
    int obj; 
    wxRuntimeDepersister Callbacks; 
    xml.Load(filename); 
    root = xml.GetRoot(); 
    if (root->GetName() != "wxWindowsXTI") 
    { 
        assert(!"Bad XML file"); 
    } 
    wxXmlReader Reader( root ); 
    obj = Reader.ReadObject( objname , &Callbacks ); 
    return dynamic_cast<wxObject*>(Callbacks.GetObject( obj ));
}


bool MustShutdown;

class streaming_exception 
{
    const char* message;
public:
    streaming_exception(const char* msg):message(msg){}
    const char* what(){return message;}
};

void wxLogError(const char* FormatString)
{
    printf("Runtime Error: %s\n", FormatString);
    exit(1);
}

void wxLogFatalError(const char* FormatString)
{
    printf("Fatal Runtime Error: *s\n");
    exit(1);
}

void wxAssert(int cond,
              const wxChar *szFile,
              int nLine,
              const wxChar *szCond,
              const wxChar *szMsg)
{
    if ( !cond )
    {
        MustShutdown = true;
        streaming_exception x("wxWindows API failed");
        throw x;
    }
}

