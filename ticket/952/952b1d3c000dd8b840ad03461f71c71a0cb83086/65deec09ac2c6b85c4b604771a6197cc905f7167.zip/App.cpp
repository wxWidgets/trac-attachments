/*
 * Override of OnInit and program entry point
 */
#include <wx/xml/xml.h>
#include <wx/xti.h>
#include <wx/xtixml.h>
#include <wx/xtistrm.h>
#include <wx/wxprec.h>
#include <wx/mstream.h>
#include "App.h"
#include "Form.h"

wxChar * XrcFile  = "Form.xrc";

wxObject* LoadForm(wxString& objname, wxString& filename) 
{ 
    printf("Loading %s from file %s\n", objname.c_str(), filename.c_str());
    wxXmlDocument xml; 
    wxXmlNode *root; 
    int obj; 
    wxRuntimeDepersister Callbacks; 
    xml.Load(filename); 
    root = xml.GetRoot(); 
    if (root->GetName() != "wxWindowsXTI") 
    { 
        assert(!"Bad XML file"); 
    } 
    wxXmlReader Reader( root ); 
    obj = Reader.ReadObject( objname , &Callbacks ); 
    return dynamic_cast<wxObject*>(Callbacks.GetObject( obj ));
}


bool MustShutdown;

class streaming_exception 
{
    const char* message;
public:
    streaming_exception(const char* msg):message(msg){}
    const char* what(){return message;}
};

void wxLogError(const char* FormatString)
{
    printf("Runtime Error: %s\n", FormatString);
    exit(1);
}

void wxLogFatalError(const char* FormatString)
{
    printf("Fatal Runtime Error: *s\n");
    exit(1);
}

void wxAssert(int cond,
              const wxChar *szFile,
              int nLine,
              const wxChar *szCond,
              const wxChar *szMsg)
{
    if ( !cond )
    {
        MustShutdown = true;
        streaming_exception x("wxWindows API failed");
        throw x;
    }
}


bool App::OnInit()
{
    Form* form;

    // Load form from xml
    try
    {
        form = (Form*)LoadForm(Form::FormName, XrcFile);
    }
    catch(streaming_exception& e)
    {
	printf("Error loading XML\n" );
	exit(1);
    }
    form->Show(true);
    return true;
}

IMPLEMENT_APP(App)
