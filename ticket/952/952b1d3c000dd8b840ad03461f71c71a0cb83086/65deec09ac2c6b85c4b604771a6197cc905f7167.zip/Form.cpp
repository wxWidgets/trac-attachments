
#include "Form.h"

//IMPLEMENT_DYNAMIC_CLASS_XTI(Form, wxFrame, wxT("Form.h"))

const wxChar* Form::FormName = wxT("FormName");
const wxChar* Form::ClassName= wxT("Form");
const wxChar* RootNode = wxT("wxWindowsXTI");

/*
wxBEGIN_PROPERTIES_TABLE(Form)
  wxPROPERTY(MainPanel, wxPanel *, SetMainPanel, GetMainPanel,, -1, wxT(""), wxT(""))
  wxPROPERTY(RadioBox, wxRadioBox *, SetRadioBox, GetRadioBox,, -1, wxT(""), wxT(""))
wxEND_PROPERTIES_TABLE()

wxBEGIN_HANDLERS_TABLE(Form)
wxEND_HANDLERS_TABLE()

wxCONSTRUCTOR_6(Form, wxWindow*, Parent, wxWindowID, Id, wxString, Title, wxPoint, Position, wxSize, Size, long, WindowStyle )
*/

BEGIN_EVENT_TABLE(Form, wxFrame)
END_EVENT_TABLE()


Form::Form()
{
 
}
 
bool Form::Init()
{
   this->Create(NULL, FORM_ID, "form", wxPoint(160, 160), wxSize(350, 160), \
		 wxCLIP_CHILDREN|wxCAPTION|wxTHICK_FRAME|wxSYSTEM_MENU|wxRESIZE_BOX|wxCLOSE_BOX|wxMINIMIZE_BOX);
   m_MainPanel = new wxPanel(this, MAIN_PANEL_ID, wxPoint(0,0), wxSize(152, 133), wxDEFAULT_FRAME_STYLE, "MainPanel");
   wxString choices1[] = {"one", "two", "three"};
   wxString choices2[] = {"four", "five", "six"};
   m_RadioBox1 = new wxRadioBox(m_MainPanel, RADIOBOX1_ID, wxString("group 1"), wxPoint(0,0), wxSize(150,60),3, choices1); 
   m_RadioBox2 = new wxRadioBox(m_MainPanel, RADIOBOX2_ID, wxString("group 2"), wxPoint(175,0), wxSize(150,60),3, choices2); 
   return true;
}

bool Form::Create( wxWindow * parent, wxWindowID id, const wxString & title, const wxPoint & pos, \
                                            const wxSize & size, long style)
{
    return wxFrame::Create( parent, id, title, pos, size, style );
}

Form::~Form()
{

}

