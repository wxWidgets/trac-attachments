#Boa:Frame:Frame1

import wx

def create(parent):
    return Frame1(parent)

[wxID_FRAME1, wxID_FRAME1PANEL1, wxID_FRAME1PNLONE, wxID_FRAME1PNLTHREE, 
 wxID_FRAME1PNLTWO, wxID_FRAME1RADBUTTONONE, wxID_FRAME1RADBUTTONTHREE, 
 wxID_FRAME1RADBUTTONTWO, wxID_FRAME1STATICTEXT1, wxID_FRAME1STATICTEXT2, 
 wxID_FRAME1STATICTEXT3, 
] = [wx.NewId() for _init_ctrls in range(11)]

class Frame1(wx.Frame):
    def _init_ctrls(self, prnt):
        # generated method, don't edit
        wx.Frame.__init__(self, id=wxID_FRAME1, name='', parent=prnt,
              pos=wx.Point(321, 246), size=wx.Size(575, 358),
              style=wx.DEFAULT_FRAME_STYLE, title='Frame1')
        self.SetClientSize(wx.Size(567, 324))

        self.panel1 = wx.Panel(id=wxID_FRAME1PANEL1, name='panel1', parent=self,
              pos=wx.Point(0, 0), size=wx.Size(567, 324),
              style=wx.TAB_TRAVERSAL)

        self.radButtonTwo = wx.RadioButton(id=wxID_FRAME1RADBUTTONTWO,
              label=u'Button 2', name=u'radButtonTwo', parent=self.panel1,
              pos=wx.Point(40, 80), size=wx.Size(81, 13), style=0)
        self.radButtonTwo.SetValue(False)
        self.radButtonTwo.Bind(wx.EVT_RADIOBUTTON,
              self.OnRadButtonTwoRadiobutton, id=wxID_FRAME1RADBUTTONTWO)

        self.radButtonThree = wx.RadioButton(id=wxID_FRAME1RADBUTTONTHREE,
              label=u'Button 3', name=u'radButtonThree', parent=self.panel1,
              pos=wx.Point(40, 104), size=wx.Size(81, 13), style=0)
        self.radButtonThree.SetValue(False)
        self.radButtonThree.Bind(wx.EVT_RADIOBUTTON,
              self.OnRadButtonThreeRadiobutton, id=wxID_FRAME1RADBUTTONTHREE)

        self.radButtonOne = wx.RadioButton(id=wxID_FRAME1RADBUTTONONE,
              label=u'Button 1', name=u'radButtonOne', parent=self.panel1,
              pos=wx.Point(40, 56), size=wx.Size(81, 13), style=0)
        self.radButtonOne.SetValue(False)
        self.radButtonOne.Bind(wx.EVT_RADIOBUTTON,
              self.OnRadButtonOneRadiobutton, id=wxID_FRAME1RADBUTTONONE)

        self.pnlTwo = wx.Panel(id=wxID_FRAME1PNLTWO, name=u'pnlTwo',
              parent=self.panel1, pos=wx.Point(176, 128), size=wx.Size(200, 64),
              style=wx.SUNKEN_BORDER | wx.TAB_TRAVERSAL)

        self.staticText1 = wx.StaticText(id=wxID_FRAME1STATICTEXT1,
              label=u'HELLO 2', name='staticText1', parent=self.pnlTwo,
              pos=wx.Point(8, 8), size=wx.Size(40, 13), style=0)

        self.pnlThree = wx.Panel(id=wxID_FRAME1PNLTHREE, name=u'pnlThree',
              parent=self.panel1, pos=wx.Point(176, 200), size=wx.Size(200, 64),
              style=wx.SUNKEN_BORDER | wx.TAB_TRAVERSAL)

        self.staticText2 = wx.StaticText(id=wxID_FRAME1STATICTEXT2,
              label=u'HELLO 3', name='staticText2', parent=self.pnlThree,
              pos=wx.Point(8, 8), size=wx.Size(40, 13), style=0)

        self.pnlOne = wx.Panel(id=wxID_FRAME1PNLONE, name=u'pnlOne',
              parent=self.panel1, pos=wx.Point(176, 56), size=wx.Size(200, 64),
              style=wx.SUNKEN_BORDER | wx.TAB_TRAVERSAL)

        self.staticText3 = wx.StaticText(id=wxID_FRAME1STATICTEXT3,
              label=u'HELLO 1', name='staticText3', parent=self.pnlOne,
              pos=wx.Point(8, 8), size=wx.Size(40, 13), style=0)

    def __init__(self, parent):
        self._init_ctrls(parent)

    def ChangePanels(self, index):
        self.pnlOne.Show(index == 1)
        self.pnlTwo.Show(index == 2)
        self.pnlThree.Show(index == 3)

    def OnRadButtonOneRadiobutton(self, event):
        self.ChangePanels(1)
        event.Skip()

    def OnRadButtonTwoRadiobutton(self, event):
        self.ChangePanels(2)
        event.Skip()

    def OnRadButtonThreeRadiobutton(self, event):
        self.ChangePanels(3)
        event.Skip()
