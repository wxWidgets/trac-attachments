from distutils.core import setup
import py2exe

setup(
        name="ReVision",
        author="Craig Sacco",
        author_email="craig.sacco@vision-bio.com",
        url="http://svn.vision-bio.com/svn/general/products/revision",
        console=["App.py"]
)