This program demostrates a bug in wxPluginManager that causes registered wxModule objects to be deleted twice. On the second delete, an exception is thrown.

Compile both the PluginDriver program and the PluginDLL library. Run PluginDriver.exe. Select Plugin... from the File menu. Using the file location dialog, select the PluginDLL library.

In the event handler OnLoadPlugin a wxPluginManager is created and used to load the dll. When the wxPluginManager object goes out of scope an exception will be thrown.

I've traced the source of the exception to "delete *it" found in the WX_CLEAR_LIST macro used on line 225 of dynload.cpp. Just prior to calling/using WX_CLEAR_LIST, wxModule::UnregisterModule(*it) is called. UnregisterModule deletes the supplied module. WX_CLEAR_LIST then deletes the module again causing an exception to be thrown.

