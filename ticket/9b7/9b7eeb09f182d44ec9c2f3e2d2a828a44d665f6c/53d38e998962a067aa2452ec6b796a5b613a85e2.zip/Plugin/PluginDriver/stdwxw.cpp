// stdwxw.cpp : source file that includes just the standard includes
// For Microsoft Visual Studio...
//	stdwxw.pch will be the pre-compiled header
//	stdwxw.obj will contain the pre-compiled type information

#include "stdwxw.h"
