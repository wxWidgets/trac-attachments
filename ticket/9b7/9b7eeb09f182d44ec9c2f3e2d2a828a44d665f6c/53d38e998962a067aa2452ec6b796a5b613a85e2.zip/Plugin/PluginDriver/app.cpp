#include "stdwxw.h"
#include "app.h"
#include "frame.h"

// Create a new application object: this macro will allow wxWidgets to create
// the application object during program execution (it's better than using a
// static object for many reasons) and also declares the accessor function
// wxGetApp() which will return the reference of the right type (i.e. PluginDriverApp and
// not wxApp)
IMPLEMENT_APP(PluginDriverApp)

// ============================================================================
// implementation
// ============================================================================

// ----------------------------------------------------------------------------
// the application class
// ----------------------------------------------------------------------------
PluginDriverApp::PluginDriverApp()
{
}

// 'Main program' equivalent: the program execution "starts" here
bool PluginDriverApp::OnInit()
{
   // Setup the resources
   wxXmlResource::Get()->InitAllHandlers();
   wxXmlResource::Get()->Load("mainmenu.xrc");
   wxXmlResource::Get()->Load("toolbar.xrc");

    // create the main application window
    wxMainFrame *frame = new wxMainFrame(NULL,-1,"PluginDriver");

    // and show it (the frames, unlike simple controls, are not shown when
    // created initially)
    frame->Show(TRUE);

    SetTopWindow(frame);


    // success: wxApp::OnRun() will be called which will enter the main message
    // loop and the application will run. If we returned FALSE here, the
    // application would exit immediately.
    return TRUE;
}

