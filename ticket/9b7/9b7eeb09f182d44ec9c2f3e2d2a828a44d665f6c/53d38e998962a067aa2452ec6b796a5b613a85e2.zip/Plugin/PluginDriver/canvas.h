#ifndef INCLUDED_CANVAS_H_
#define INCLUDED_CANVAS_H_

// Define a new window type
class wxCanvas : public wxWindow
{
public:
    // ctor(s)
    wxCanvas(wxWindow* parent, wxWindowID id, const wxPoint& pos = wxDefaultPosition, const wxSize& size = wxDefaultSize, long style = 0, const wxString& name = wxPanelNameStr);


private:
   // any class wishing to process wxWindows events must use this macro
   DECLARE_EVENT_TABLE()
};

#endif // INCLUDED_CANVAS_H_
