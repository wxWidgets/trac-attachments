#ifndef INCLUDED_FRAME_H_
#define INCLUDED_FRAME_H_

// Define a new frame type: this is going to be our main frame
#include "canvas.h"

class wxMainFrame : public wxFrame
{
    DECLARE_CLASS(wxMainFrame)
public:
    // ctor(s)
    wxMainFrame(wxFrame* parent,wxWindowID id,const wxString& title, const wxPoint& pos=wxDefaultPosition, const wxSize& size=wxDefaultSize);
   ~wxMainFrame();

    void OnLoadPlugin(wxCommandEvent& event);

private:
   wxCanvas* m_pCanvas;

   // any class wishing to process wxWindows events must use this macro
    DECLARE_EVENT_TABLE()
};


#endif // INCLUDED_FRAME_H_
