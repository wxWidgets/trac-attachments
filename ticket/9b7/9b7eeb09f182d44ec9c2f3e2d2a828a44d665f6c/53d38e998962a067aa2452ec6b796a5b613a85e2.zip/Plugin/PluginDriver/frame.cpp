#include "stdwxw.h"
#include "app.h"
#include "frame.h"
#include "canvas.h"

#include <wx\dynload.h>

#if defined(__WXGTK__) || defined(__WXMOTIF__)
#include "PluginDriver.xpm"
#endif

// ----------------------------------------------------------------------------
// event tables and other macros for wxWindows
// ----------------------------------------------------------------------------
IMPLEMENT_CLASS(wxMainFrame, wxFrame)

// the event tables connect the wxWindows events with the functions (event
// handlers) which process them. It can be also done at run-time, but for the
// simple menu events like this the static method is much simpler.
BEGIN_EVENT_TABLE(wxMainFrame, wxFrame)
   EVT_MENU(XRCID("load_plugin"),wxMainFrame::OnLoadPlugin)
END_EVENT_TABLE()

// ----------------------------------------------------------------------------
// main frame
// ----------------------------------------------------------------------------

// frame constructor
wxMainFrame::wxMainFrame(wxFrame* parent,wxWindowID id,const wxString& title, const wxPoint& pos, const wxSize& size) :
   wxFrame(parent,id,title,pos,size)
{
    // set the frame icon
    SetIcon(wxICON(PluginDriver));

    SetMenuBar(wxXmlResource::Get()->LoadMenuBar("mainmenu"));
    

    // create a status bar just for fun (by default with 1 pane only)
    CreateStatusBar(2);
    SetStatusText("Ready");

    m_pCanvas = new wxCanvas(this,-1,GetClientAreaOrigin(),GetClientSize(),wxSUNKEN_BORDER);
}

wxMainFrame::~wxMainFrame()
{
   m_pCanvas->Destroy();
}


// event handlers
   
void wxMainFrame::OnLoadPlugin(wxCommandEvent& event)
{
   wxString strPlugin = wxFileSelector("Select DLL to load","","","dll","DLL files (*.dll)|*.dll",wxOPEN);
   wxPluginManager pluginMgr;
   pluginMgr.Load(strPlugin);
}
