#ifndef INCLUDED_STDWXW_H_
#define INCLUDED_STDWXW_H_

#include <wx/wxprec.h>
#ifndef WX_PRECOMP
   #include <wx/wx.h>
#endif

#include <wx/xrc/xmlres.h>



#endif // INCLUDED_STDWXW_H_
