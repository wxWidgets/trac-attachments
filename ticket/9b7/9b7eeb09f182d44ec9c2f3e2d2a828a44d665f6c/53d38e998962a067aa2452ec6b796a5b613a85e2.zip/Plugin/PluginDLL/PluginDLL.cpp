// PluginDLL.cpp : Defines the entry point for the DLL application.
//

#include "stdafx.h"
#include <wx/wx.h>
#include <wx/module.h>

class MyDLL : public wxModule
{
DECLARE_DYNAMIC_CLASS(MyDLL)
public:
   MyDLL();
   virtual ~MyDLL();
   bool OnInit();
   void OnExit();
};

IMPLEMENT_DYNAMIC_CLASS(MyDLL,wxModule)

MyDLL::MyDLL()
{
   wxMessageBox("MyDLL c'tor");
}

MyDLL::~MyDLL()
{
   wxMessageBox("MyDLL d'tor");
}

bool MyDLL::OnInit()
{
   wxMessageBox("MyDLL::OnInit");
   return true;
}

void MyDLL::OnExit()
{
   wxMessageBox("MyDLL::OnExit");
}

BOOL APIENTRY DllMain( HANDLE hModule, 
                       DWORD  ul_reason_for_call, 
                       LPVOID lpReserved
					 )
{
    return TRUE;
}

