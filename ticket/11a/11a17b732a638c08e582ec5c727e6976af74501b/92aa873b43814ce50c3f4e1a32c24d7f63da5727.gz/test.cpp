#include <wx/app.h>
#include "GUIDialog.h"

class lang_testDialog: public GUIDialog
{
public:
    lang_testDialog(wxDialog *dlg)
            : GUIDialog(dlg) {}

private:
    virtual void OnClose(wxCloseEvent& event)
    {
        Destroy();
    }
};


class lang_testApp : public wxApp
{
public:
    virtual bool OnInit()
    {
        lang_testDialog* dlg = new lang_testDialog(0L);
        dlg->Show();
        return true;
    }
};

IMPLEMENT_APP(lang_testApp);
