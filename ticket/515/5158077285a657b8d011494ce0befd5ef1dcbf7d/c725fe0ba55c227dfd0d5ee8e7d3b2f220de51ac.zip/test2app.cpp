/////////////////////////////////////////////////////////////////////////////
// Name:        test2app.cpp
// Purpose:     
// Author:      Patrick M Grace
// Modified by: 
// Created:     15/11/2010 10:55:55
// RCS-ID:      
// Copyright:   (c) University College Dublin
// Licence:     
/////////////////////////////////////////////////////////////////////////////

// For compilers that support precompilation, includes "wx/wx.h".
#include "wx/wxprec.h"

#ifdef __BORLANDC__
#pragma hdrstop
#endif

#ifndef WX_PRECOMP
#include "wx/wx.h"
#endif

////@begin includes
////@end includes

#include "test2app.h"

////@begin XPM images
////@end XPM images


/*
 * Application instance implementation
 */

////@begin implement app
IMPLEMENT_APP( Test2App )
////@end implement app


/*
 * Test2App type definition
 */

IMPLEMENT_CLASS( Test2App, wxApp )


/*
 * Test2App event table definition
 */

BEGIN_EVENT_TABLE( Test2App, wxApp )

////@begin Test2App event table entries
////@end Test2App event table entries

END_EVENT_TABLE()


/*
 * Constructor for Test2App
 */

Test2App::Test2App()
{
    Init();
}


/*
 * Member initialisation
 */

void Test2App::Init()
{
////@begin Test2App member initialisation
////@end Test2App member initialisation
}

/*
 * Initialisation for Test2App
 */

bool Test2App::OnInit()
{    
////@begin Test2App initialisation
	// Remove the comment markers above and below this block
	// to make permanent changes to the code.

#if wxUSE_XPM
	wxImage::AddHandler(new wxXPMHandler);
#endif
#if wxUSE_LIBPNG
	wxImage::AddHandler(new wxPNGHandler);
#endif
#if wxUSE_LIBJPEG
	wxImage::AddHandler(new wxJPEGHandler);
#endif
#if wxUSE_GIF
	wxImage::AddHandler(new wxGIFHandler);
#endif
	MyFrame* mainWindow = new MyFrame( NULL );
	mainWindow->Show(true);
////@end Test2App initialisation

    return true;
}


/*
 * Cleanup for Test2App
 */

int Test2App::OnExit()
{    
////@begin Test2App cleanup
	return wxApp::OnExit();
////@end Test2App cleanup
}

