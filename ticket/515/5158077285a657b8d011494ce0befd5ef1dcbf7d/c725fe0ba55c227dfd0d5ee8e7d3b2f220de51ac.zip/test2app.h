/////////////////////////////////////////////////////////////////////////////
// Name:        test2app.h
// Purpose:     
// Author:      Patrick M Grace
// Modified by: 
// Created:     15/11/2010 10:55:55
// RCS-ID:      
// Copyright:   (c) University College Dublin
// Licence:     
/////////////////////////////////////////////////////////////////////////////

#ifndef _TEST2APP_H_
#define _TEST2APP_H_


/*!
 * Includes
 */

////@begin includes
#include "wx/image.h"
#include "myframe.h"
////@end includes

/*!
 * Forward declarations
 */

////@begin forward declarations
////@end forward declarations

/*!
 * Control identifiers
 */

////@begin control identifiers
////@end control identifiers

/*!
 * Test2App class declaration
 */

class Test2App: public wxApp
{    
    DECLARE_CLASS( Test2App )
    DECLARE_EVENT_TABLE()

public:
    /// Constructor
    Test2App();

    void Init();

    /// Initialises the application
    virtual bool OnInit();

    /// Called on exit
    virtual int OnExit();

////@begin Test2App event handler declarations

////@end Test2App event handler declarations

////@begin Test2App member function declarations

////@end Test2App member function declarations

////@begin Test2App member variables
////@end Test2App member variables
};

/*!
 * Application instance declaration 
 */

////@begin declare app
DECLARE_APP(Test2App)
////@end declare app

#endif
    // _TEST2APP_H_
