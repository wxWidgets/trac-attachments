#!/usr/bin/perl -w

use strict;
use warnings;

while (1) {
	print STDERR "this is one line\n";
	for (my $foo = 0; $foo < 40.; $foo++) {
		print STDERR "this is alot of text.";
	}
	print STDERR "\n";
	sleep(rand(5));
}
