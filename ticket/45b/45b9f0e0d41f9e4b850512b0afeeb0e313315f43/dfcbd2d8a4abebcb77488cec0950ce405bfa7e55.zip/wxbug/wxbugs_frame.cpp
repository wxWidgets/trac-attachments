/////////////////////////////////////////////////////////////////////////////
// Name:        wxbugs_frame.cpp
// Purpose:     
// Author:      Greg Hazel
// Modified by: 
// Created:     04/10/05 13:25:03
// RCS-ID:      
// Copyright:   
// Licence:     
/////////////////////////////////////////////////////////////////////////////

#if defined(__GNUG__) && !defined(__APPLE__)
#pragma implementation "wxbugs_frame.h"
#endif

// For compilers that support precompilation, includes "wx/wx.h".
#include "wx/wxprec.h"

#ifdef __BORLANDC__
#pragma hdrstop
#endif

#ifndef WX_PRECOMP
#include "wx/wx.h"
#endif

////@begin includes
////@end includes

#include "wxbugs_frame.h"

#define USE_LOG_TEXT

////@begin XPM images
////@end XPM images

/*!
 * wxbugs_frame type definition
 */

IMPLEMENT_DYNAMIC_CLASS( wxbugs_frame, wxFrame )

/*!
 * wxbugs_frame event table definition
 */
DEFINE_EVENT_TYPE(ID_LOGPLS)

BEGIN_EVENT_TABLE( wxbugs_frame, wxFrame )

////@begin wxbugs_frame event table entries
    EVT_CLOSE( wxbugs_frame::OnCloseWindow )

////@end wxbugs_frame event table entries
    EVT_IDLE(wxbugs_frame::OnIdle)
    EVT_TIMER(ID_IDLE_TIMER, wxbugs_frame::OnTimer)
    EVT_COMMAND(wxID_ANY, ID_LOGPLS, wxbugs_frame::OnLogPls)

END_EVENT_TABLE()

/*!
 * wxbugs_frame constructors
 */

wxbugs_frame::wxbugs_frame( )
{
    Create(NULL,
           SYMBOL_WXBUGS_FRAME_IDNAME, SYMBOL_WXBUGS_FRAME_TITLE,
           SYMBOL_WXBUGS_FRAME_POSITION, SYMBOL_WXBUGS_FRAME_SIZE,
           SYMBOL_WXBUGS_FRAME_STYLE );
}

wxbugs_frame::~wxbugs_frame()
{
#ifdef USE_LOG_TEXT
  wxLog* old = wxLog::SetActiveTarget((wxLog*)NULL);

  if (old)
  {
    delete old;
  }
#endif
}

wxbugs_frame::wxbugs_frame( wxWindow* parent, wxWindowID id, const wxString& caption, const wxPoint& pos, const wxSize& size, long style )
{
    Create(parent, id, caption, pos, size, style);
}

/*!
 * wxbugs_frame creator
 */

bool wxbugs_frame::Create( wxWindow* parent, wxWindowID id, const wxString& caption, const wxPoint& pos, const wxSize& size, long style )
{
////@begin wxbugs_frame member initialisation
    m_sizer = NULL;
    m_logwindow = NULL;
////@end wxbugs_frame member initialisation

////@begin wxbugs_frame creation
    wxFrame::Create( parent, id, caption, pos, size, style );

    CreateControls();
    Centre();
////@end wxbugs_frame creation
    return TRUE;
}

/*!
 * Control creation for wxbugs_frame
 */

void wxbugs_frame::CreateControls()
{    
////@begin wxbugs_frame content construction

    wxbugs_frame* itemFrame1 = this;

    wxGridSizer* itemGridSizer2 = new wxGridSizer(1, 1, 0, 0);
    itemFrame1->SetSizer(itemGridSizer2);

    wxPanel* itemPanel3 = new wxPanel( itemFrame1, ID_PANEL, wxDefaultPosition, wxDefaultSize, wxTAB_TRAVERSAL );
    itemGridSizer2->Add(itemPanel3, 0, wxGROW|wxGROW, 5);

    m_sizer = new wxFlexGridSizer(1, 1, 0, 0);
    m_sizer->AddGrowableRow(0);
    m_sizer->AddGrowableCol(0);
    itemPanel3->SetSizer(m_sizer);

    m_logwindow = new wxTextCtrl( itemPanel3, ID_TEXTCTRL, _T(""), wxDefaultPosition, wxSize(400, 200), wxTE_MULTILINE|wxTE_READONLY|wxTE_RICH2|wxTE_AUTO_URL );
    m_sizer->Add(m_logwindow, 0, wxGROW|wxGROW, 5);

////@end wxbugs_frame content construction


#ifdef USE_LOG_TEXT
    m_logtarget = new wxLogTextCtrl(m_logwindow);

    wxLog* old = wxLog::SetActiveTarget(m_logtarget);

    if (old)
    {
      delete old;
    }
#endif

    m_timerIdleWakeUp.SetOwner(this, ID_IDLE_TIMER);

    
    //Launch("dirs.bat");
    Launch("perl dirs.pl");
}

wxbugs_process *wxbugs_frame::Launch(wxString cmd)
{
  wxbugs_process *process = new wxbugs_process(this, cmd);
  process->m_pid = wxExecute(cmd, wxEXEC_ASYNC, process);

  if ( !process->m_pid )
  {
      wxLogError(_T("Execution of '%s' failed."), cmd.c_str());

      delete process;

      process = NULL;
  }
  else
  {
      AddAsyncProcess(process);
  }

  return process;
}


void wxbugs_frame::OnTimer(wxTimerEvent& WXUNUSED(event))
{
    wxWakeUpIdle();
}

void wxbugs_frame::OnIdle(wxIdleEvent& event)
{
    size_t count = m_running.GetCount();
    for ( size_t n = 0; n < count; n++ )
    {
        if ( m_running[n]->HasInput() )
        {
            event.RequestMore();
        }
    }
}

void wxbugs_frame::OnLogPls(wxCommandEvent &event)
{
  wxString msg = event.GetString();

  while ((!msg.IsEmpty()) && 
         ((msg[0] == '\n') || (msg[0] == '\r')))
  {
    msg = msg.Mid(1);
  }

  while ((!msg.IsEmpty()) && 
         ((msg.Last() == '\n') || (msg.Last() == '\r')))
  {
    msg = msg.Mid(0,msg.Length()-1);
  }

  switch (event.GetInt()) {
    default:
    case 0:
      {
#ifdef USE_LOG_TEXT
        wxLogMessage(msg);
#else
        msg += "\n";
        m_logwindow->AppendText(msg);
#endif
      }
      break;
    case 1:
      {
#ifdef USE_LOG_TEXT
        wxLogMessage(msg);
#else
        msg += "\n";
        m_logwindow->AppendText(msg);
#endif
      }
      break;
  }
}
void wxbugs_frame::AddAsyncProcess(wxbugs_process *process)
{
    if ( m_running.IsEmpty() )
    {
        // we want to start getting the timer events to ensure that a
        // steady stream of idle events comes in -- otherwise we
        // wouldn't be able to poll the child process input
        m_timerIdleWakeUp.Start(100);
    }
    //else: the timer is already running

    m_running.Add(process);
}

void wxbugs_frame::RemoveAsyncProcess(wxbugs_process *process)
{
    m_running.Remove(process);

    if ( m_running.IsEmpty() )
    {
        // we don't need to get idle events all the time any more
        m_timerIdleWakeUp.Stop();
    }
}



/*!
 * wxEVT_CLOSE_WINDOW event handler for ID_WXBUGS_FRAME
 */

void wxbugs_frame::OnCloseWindow( wxCloseEvent& event )
{
////@begin wxEVT_CLOSE_WINDOW event handler for ID_WXBUGS_FRAME in wxbugs_frame.
    // Before editing this code, remove the block markers.
    event.Skip();
////@end wxEVT_CLOSE_WINDOW event handler for ID_WXBUGS_FRAME in wxbugs_frame. 
}

/*!
 * Should we show tooltips?
 */

bool wxbugs_frame::ShowToolTips()
{
    return TRUE;
}

/*!
 * Get bitmap resources
 */

wxBitmap wxbugs_frame::GetBitmapResource( const wxString& name )
{
    // Bitmap retrieval
////@begin wxbugs_frame bitmap retrieval
    return wxNullBitmap;
////@end wxbugs_frame bitmap retrieval
}

/*!
 * Get icon resources
 */

wxIcon wxbugs_frame::GetIconResource( const wxString& name )
{
    // Icon retrieval
////@begin wxbugs_frame icon retrieval
    return wxNullIcon;
////@end wxbugs_frame icon retrieval
}
