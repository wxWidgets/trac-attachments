#include "wxbugs_process.h"
#include <wx/txtstrm.h>

bool wxbugs_process::HasInput()
{
    bool hasInput = false;

    if ( IsInputAvailable() )
    {
        wxTextInputStream tis(*GetInputStream());

        // this assumes that the output is always line buffered
        wxString msg;
        msg << tis.ReadLine();

        /*
        wxCommandEvent event(ID_LOGPLS, m_parent->GetId());
        event.SetString(msg);
        wxPostEvent(m_parent, event);
        */
        wxLogMessage(msg);

        hasInput = true;
    }

    if ( IsErrorAvailable() )
    {
        wxTextInputStream tis(*GetErrorStream());

        // this assumes that the output is always line buffered
        wxString msg;
        msg << tis.ReadLine();

        /*
        wxCommandEvent event(ID_LOGPLS, m_parent->GetId());
        event.SetString(msg);
        wxPostEvent(m_parent, event);
        */
        wxLogMessage(msg);

        hasInput = true;
    }

    return hasInput;
}

void wxbugs_process::OnTerminate(int pid, int status)
{
    // show the rest of the output
    while ( HasInput() )
        ;

    m_parent->RemoveAsyncProcess(this);

    wxString msg;
    msg.Format(_T("Process %u ('%s') terminated with exit code %d."),
                 pid, m_cmd.c_str(), status);

    wxCommandEvent event(ID_LOGPLS, m_parent->GetId());
    event.SetString(msg);
    wxPostEvent(m_parent, event);
  
    delete this;
}
