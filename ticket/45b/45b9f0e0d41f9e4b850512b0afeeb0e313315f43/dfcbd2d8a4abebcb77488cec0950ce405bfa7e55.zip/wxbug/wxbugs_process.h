/////////////////////////////////////////////////////////////////////////////
// Name:        wxbugs_process.h
// Purpose:     
// Author:      Greg Hazel
// Modified by: 
// Created:     04/03/05 20:15:06
// RCS-ID:      
// Copyright:   
// Licence:     
/////////////////////////////////////////////////////////////////////////////

#ifndef _WXBUGS_PROCESS_H_
#define _WXBUGS_PROCESS_H_

#include "wxbugs.h"
class wxbugs_frame;
#include "wxbugs_frame.h"
#include <wx/process.h>

// A specialization of wxProcess for redirecting the output
class wxbugs_process : public wxProcess
{
public:
    wxbugs_process(wxbugs_frame *parent, const wxString& cmd)
        : wxProcess((wxFrame*)parent), m_cmd(cmd)
        {
            m_pid = 0;
            m_parent = parent;
            Redirect();
        }

    virtual void OnTerminate(int pid, int status);

    virtual bool HasInput();

  int m_pid;
private:
  wxbugs_frame* m_parent;
  wxString m_cmd;

};

#endif
    // _WXBUGS_PROCESS_H_
