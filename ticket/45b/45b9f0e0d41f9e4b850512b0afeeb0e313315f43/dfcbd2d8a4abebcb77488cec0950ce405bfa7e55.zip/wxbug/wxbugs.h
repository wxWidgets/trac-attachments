/////////////////////////////////////////////////////////////////////////////
// Name:        wxbugs.h
// Purpose:     
// Author:      Greg Hazel
// Modified by: 
// Created:     04/10/05 13:25:10
// RCS-ID:      
// Copyright:   
// Licence:     
/////////////////////////////////////////////////////////////////////////////

#ifndef _WXBUGS_H_
#define _WXBUGS_H_

#if defined(__GNUG__) && !defined(__APPLE__)
#pragma interface "wxbugs.cpp"
#endif

/*!
 * Includes
 */
#include "wx/wx.h"

////@begin includes
#include "wx/image.h"
////@end includes
#include "wxbugs_frame.h"

/*!
 * Forward declarations
 */

////@begin forward declarations
////@end forward declarations

/*!
 * Control identifiers
 */

////@begin control identifiers
////@end control identifiers

/*!
 * wxBugs class declaration
 */

class wxBugs: public wxApp
{    
    DECLARE_CLASS( wxBugs )
    DECLARE_EVENT_TABLE()

public:
    /// Constructor
    wxBugs();

    /// Initialises the application
    virtual bool OnInit();

    /// Called on exit
    virtual int OnExit();

////@begin wxBugs event handler declarations

////@end wxBugs event handler declarations

////@begin wxBugs member function declarations

////@end wxBugs member function declarations

////@begin wxBugs member variables
////@end wxBugs member variables
};

/*!
 * Application instance declaration 
 */

////@begin declare app
DECLARE_APP(wxBugs)
////@end declare app

#endif
    // _WXBUGS_H_
