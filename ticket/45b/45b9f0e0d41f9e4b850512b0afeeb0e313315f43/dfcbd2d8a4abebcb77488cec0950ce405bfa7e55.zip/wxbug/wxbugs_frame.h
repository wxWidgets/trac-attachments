/////////////////////////////////////////////////////////////////////////////
// Name:        wxbugs_frame.h
// Purpose:     
// Author:      Greg Hazel
// Modified by: 
// Created:     04/10/05 13:25:03
// RCS-ID:      
// Copyright:   
// Licence:     
/////////////////////////////////////////////////////////////////////////////

#ifndef _WXBUGS_FRAME_H_
#define _WXBUGS_FRAME_H_

#if defined(__GNUG__) && !defined(__APPLE__)
#pragma interface "wxbugs_frame.cpp"
#endif

/*!
 * Includes
 */

////@begin includes
////@end includes
#include "wxbugs.h"
class wxbugs_process;
#include "wxbugs_process.h"

/*!
 * Forward declarations
 */

////@begin forward declarations
class wxFlexGridSizer;
////@end forward declarations

/*!
 * Control identifiers
 */

////@begin control identifiers
#define ID_WXBUGS_FRAME 10000
#define SYMBOL_WXBUGS_FRAME_STYLE wxCAPTION|wxRESIZE_BORDER|wxSYSTEM_MENU|wxCLOSE_BOX|wxMAXIMIZE_BOX|wxMINIMIZE_BOX
#define SYMBOL_WXBUGS_FRAME_TITLE _("wxBugs Demonstration")
#define SYMBOL_WXBUGS_FRAME_IDNAME ID_WXBUGS_FRAME
#define SYMBOL_WXBUGS_FRAME_SIZE wxSize(640, 300)
#define SYMBOL_WXBUGS_FRAME_POSITION wxDefaultPosition
#define ID_PANEL 10002
#define ID_TEXTCTRL 10001
////@end control identifiers

enum{
  ID_IDLE_TIMER,
};

BEGIN_DECLARE_EVENT_TYPES()
    DECLARE_EVENT_TYPE(ID_LOGPLS, 10000)
END_DECLARE_EVENT_TYPES()

/*!
 * Compatibility
 */

#ifndef wxCLOSE_BOX
#define wxCLOSE_BOX 0x1000
#endif
#ifndef wxFIXED_MINSIZE
#define wxFIXED_MINSIZE 0
#endif

WX_DEFINE_ARRAY_PTR(wxbugs_process *, wxbugs_process_array);

/*!
 * wxbugs_frame class declaration
 */

class wxbugs_frame: public wxFrame
{    
    DECLARE_DYNAMIC_CLASS( wxbugs_frame )
    DECLARE_EVENT_TABLE()

public:
    /// Constructors
    wxbugs_frame( );
    ~wxbugs_frame( );
    wxbugs_frame( wxWindow* parent, wxWindowID id = SYMBOL_WXBUGS_FRAME_IDNAME, const wxString& caption = SYMBOL_WXBUGS_FRAME_TITLE, const wxPoint& pos = SYMBOL_WXBUGS_FRAME_POSITION, const wxSize& size = SYMBOL_WXBUGS_FRAME_SIZE, long style = SYMBOL_WXBUGS_FRAME_STYLE );

    /// Creation
    bool Create( wxWindow* parent, wxWindowID id = SYMBOL_WXBUGS_FRAME_IDNAME, const wxString& caption = SYMBOL_WXBUGS_FRAME_TITLE, const wxPoint& pos = SYMBOL_WXBUGS_FRAME_POSITION, const wxSize& size = SYMBOL_WXBUGS_FRAME_SIZE, long style = SYMBOL_WXBUGS_FRAME_STYLE );

    /// Creates the controls and sizers
    void CreateControls();

////@begin wxbugs_frame event handler declarations

    /// wxEVT_CLOSE_WINDOW event handler for ID_WXBUGS_FRAME
    void OnCloseWindow( wxCloseEvent& event );

////@end wxbugs_frame event handler declarations
    void OnLogPls( wxCommandEvent &event );
    wxbugs_process *wxbugs_frame::Launch(wxString cmd);
    void OnTimer(wxTimerEvent& WXUNUSED(event));
    void OnIdle(wxIdleEvent &event);
    void AddAsyncProcess(wxbugs_process *process);
    void RemoveAsyncProcess(wxbugs_process *process);


////@begin wxbugs_frame member function declarations

    /// Retrieves bitmap resources
    wxBitmap GetBitmapResource( const wxString& name );

    /// Retrieves icon resources
    wxIcon GetIconResource( const wxString& name );
////@end wxbugs_frame member function declarations

    /// Should we show tooltips?
    static bool ShowToolTips();

////@begin wxbugs_frame member variables
    wxFlexGridSizer* m_sizer;
    wxTextCtrl* m_logwindow;
////@end wxbugs_frame member variables
    // the idle event wake up timer
    wxTimer m_timerIdleWakeUp;
    wxLog* m_logtarget;
    wxbugs_process_array m_running;
};

#endif
    // _WXBUGS_FRAME_H_
