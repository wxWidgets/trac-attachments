﻿#include "pch.h"
#include <UI/MainFrame/MainFrame.h>
#include "ShowBugApp.h"

IMPLEMENT_APP(ShowBugApp)

ShowBugApp::ShowBugApp()
{
}

ShowBugApp::~ShowBugApp()
{
}

bool ShowBugApp::OnInit()
{
    MainFrame * pMainFrame = new MainFrame(nullptr, wxID_ANY, L"ShowBugApp", wxDefaultPosition, wxDefaultSize, wxDEFAULT_FRAME_STYLE | wxMAXIMIZE);
    pMainFrame->Show();

    return true;
}
