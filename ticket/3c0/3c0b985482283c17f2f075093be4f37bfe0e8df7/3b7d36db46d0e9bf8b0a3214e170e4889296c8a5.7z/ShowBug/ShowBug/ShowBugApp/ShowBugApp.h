#pragma once

class ShowBugApp : public wxApp
{
public:
    ShowBugApp();
    ~ShowBugApp();
public:
    virtual bool OnInit();
};

DECLARE_APP(ShowBugApp)
