﻿#include "pch.h"
#include <UI/BuggyPropGrid/BuggyPropGrid.h>
#include "MainFrame.h"

BEGIN_EVENT_TABLE(MainFrame, wxFrame)
END_EVENT_TABLE()

MainFrame::MainFrame(wxWindow * parent,
                     wxWindowID id,
                     const wxString & title,
                     const wxPoint & pos,
                     const wxSize & size,
                     long style) : wxFrame(parent, id, title, pos, size, style)
{
    wxBoxSizer * pSizer_Top;
    pSizer_Top = new wxBoxSizer(wxVERTICAL);

    wxString help =
        L"1. Double click label for the 1st property\r\n"
        L"2. In the event handler for the event above, the value of the 2nd property is changed\r\n"
        L"3. In the event handler for the event above, the value of the 3rd property should be changed, but it doesn't change, it looks like a bug.";

    wxTextCtrl * pStaticText = new wxTextCtrl(this, wxID_ANY, help, wxDefaultPosition, wxDefaultSize, wxTE_READONLY | wxTE_MULTILINE);
    pSizer_Top->Add(pStaticText, 0, wxEXPAND);

    BuggyPropGrid * pBuggyPropGrid = new BuggyPropGrid(this);
    pSizer_Top->Add(pBuggyPropGrid, 0, wxEXPAND);    

    SetSizer(pSizer_Top);
    Layout();
}

MainFrame::~MainFrame()
{
}