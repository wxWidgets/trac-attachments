#include "pch.h"
#include "BuggyPropGrid.h"

BEGIN_EVENT_TABLE(BuggyPropGrid, wxPropertyGrid)
EVT_PG_CHANGED(wxID_ANY, BuggyPropGrid::OnPropChanged)
EVT_PG_DOUBLE_CLICK(wxID_ANY, BuggyPropGrid::OnPGDClick)
END_EVENT_TABLE()

BuggyPropGrid::BuggyPropGrid(wxWindow * parent,
                                   wxWindowID id,
                                   const wxPoint & pos,
                                   const wxSize & size,
                                   long style,
                                   const wxString & name) :
    wxPropertyGrid(parent, id, pos, size, style, name)
{
    Init();
}

void BuggyPropGrid::Init()
{
    _pProp_0 = new wxStringProperty(L"Prop_0");
    _pProp_0->SetValue(5);
    Append(_pProp_0);

    _pProp_1 = new wxStringProperty(L"Prop_1");
    Append(_pProp_1);

    _pProp_2 = new wxStringProperty(L"Prop_2");
    Append(_pProp_2);

    FitColumns();
    
    SetSize(250, 200);
}

void BuggyPropGrid::OnPropChanged(wxPropertyGridEvent & event)
{
    wxPGProperty * pProp = event.GetProperty();
    if (pProp == _pProp_1)
    {
        wxString s = _pProp_1->GetValueAsString();
        double n;
        if (s.ToDouble(&n))
        {
            n *= 2;
            bool ok = ChangePropertyValue(_pProp_2, n); // This line will be executed and return true, but UI doesn't change.
                                                        // wxPropertyGrid::SetPropertyValue works
                                                        // wxPGProperty::SetValue  works
                                                        // But these two doesn't emit change event
            wxASSERT(ok);
        }
    }
}

void BuggyPropGrid::OnPGDClick(wxPropertyGridEvent & event)
{
    unsigned int col = event.GetColumn();
    if (col == 1)
    {
        wxPGProperty * pProp = event.GetProperty();
        if (pProp == _pProp_0)
        {
            ChangePropertyValue(_pProp_1, _pProp_0->GetValue());
        }
    }
}