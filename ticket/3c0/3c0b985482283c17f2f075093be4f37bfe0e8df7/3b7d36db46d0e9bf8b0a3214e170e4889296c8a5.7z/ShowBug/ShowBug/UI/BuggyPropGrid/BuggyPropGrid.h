#pragma once

class BuggyPropGrid : public wxPropertyGrid
{
    DECLARE_EVENT_TABLE()
public:
    BuggyPropGrid(wxWindow * parent,
                     wxWindowID id = wxID_ANY,
                     const wxPoint & pos = wxDefaultPosition,
                     const wxSize & size = wxDefaultSize,
                     long style = wxPG_HIDE_MARGIN,
                     const wxString & name = wxPropertyGridNameStr);
public:
    void Init();
private: // event handlers
    void OnPropChanged(wxPropertyGridEvent & event);
    void OnPGDClick(wxPropertyGridEvent & event);
private:
    wxStringProperty * _pProp_0;
    wxStringProperty * _pProp_1;
    wxStringProperty * _pProp_2;
};
