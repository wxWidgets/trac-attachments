#ifndef MAIN_H
#define MAIN_H

#include <wx/wxprec.h>

#ifdef __BORLANDC__
    #pragma hdrstop
#endif

//(*Headers(MyFrame)
#include <wx/button.h>
#include <wx/frame.h>
#include <wx/intl.h>
#include <wx/sizer.h>
//*)

class MyFrame: public wxFrame
{
	public:

		MyFrame(wxWindow* parent,wxWindowID id = -1);
		virtual ~MyFrame();

		//(*Identifiers(MyFrame)
		enum Identifiers
		{
			ID_BUTTON1 = 0x1000,
			ID_BUTTON2,
			ID_BUTTON3
		};
		//*)

	protected:

		//(*Handlers(MyFrame)
		void onFullScreen(wxCommandEvent& event);
		void onWindow(wxCommandEvent& event);
		void onClose(wxCommandEvent& event);
		//*)

		//(*Declarations(MyFrame)
		wxBoxSizer* BoxSizer1;
		wxButton* Button1;
		wxButton* Button2;
		wxButton* Button3;
		//*)

	private:

		DECLARE_EVENT_TABLE()
};

#endif
