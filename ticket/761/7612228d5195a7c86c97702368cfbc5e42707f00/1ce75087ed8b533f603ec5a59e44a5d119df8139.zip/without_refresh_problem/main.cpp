#include "main.h"

BEGIN_EVENT_TABLE(MyFrame,wxFrame)
	//(*EventTable(MyFrame)
	EVT_BUTTON(ID_BUTTON1,MyFrame::onFullScreen)
	EVT_BUTTON(ID_BUTTON2,MyFrame::onWindow)
	EVT_BUTTON(ID_BUTTON3,MyFrame::onClose)
	//*)
END_EVENT_TABLE()

MyFrame::MyFrame(wxWindow* parent,wxWindowID id)
{
	//(*Initialize(MyFrame)
	Create(parent,id,_T(""),wxDefaultPosition,wxDefaultSize,wxSTAY_ON_TOP|wxDEFAULT_FRAME_STYLE|wxSTAY_ON_TOP);
	BoxSizer1 = new wxBoxSizer(wxHORIZONTAL);
	Button1 = new wxButton(this,ID_BUTTON1,_("Full screen"),wxDefaultPosition,wxDefaultSize,0);
	if (false) Button1->SetDefault();
	Button2 = new wxButton(this,ID_BUTTON2,_("Window"),wxDefaultPosition,wxDefaultSize,0);
	if (false) Button2->SetDefault();
	Button3 = new wxButton(this,ID_BUTTON3,_("Close"),wxDefaultPosition,wxDefaultSize,0);
	if (false) Button3->SetDefault();
	BoxSizer1->Add(Button1,0,wxALL|wxALIGN_LEFT|wxALIGN_TOP,5);
	BoxSizer1->Add(Button2,0,wxALL|wxALIGN_LEFT|wxALIGN_TOP,5);
	BoxSizer1->Add(Button3,0,wxALL|wxALIGN_LEFT|wxALIGN_TOP,5);
	this->SetSizer(BoxSizer1);
	BoxSizer1->Fit(this);
	BoxSizer1->SetSizeHints(this);
	//*)
	Show();   // this eliminates screen refresh problem
	ShowFullScreen(true, wxFULLSCREEN_NOCAPTION | wxFULLSCREEN_NOBORDER);
}

MyFrame::~MyFrame()
{
}

void MyFrame::onFullScreen(wxCommandEvent& event)
{
	ShowFullScreen(true, wxFULLSCREEN_NOCAPTION | wxFULLSCREEN_NOBORDER);
}

void MyFrame::onWindow(wxCommandEvent& event)
{
	ShowFullScreen(false);
}

void MyFrame::onClose(wxCommandEvent& event)
{
	Destroy();
}
