#include <wx/wx.h>
#include <wx/image.h>
#include <wx/xrc/xmlres.h>
#include <wx/fs_zip.h>

struct View : public wxWindow
{
	View(wxWindow* parent) : wxWindow(parent, -1) {}

	void OnPaint(wxPaintEvent& event);
	wxBitmap m_bmp;

	DECLARE_EVENT_TABLE()
};

BEGIN_EVENT_TABLE(View, wxWindow)
	EVT_PAINT(View::OnPaint)
END_EVENT_TABLE()


void View::OnPaint(wxPaintEvent& event)
{
	wxPaintDC dc(this);
	dc.DrawBitmap(m_bmp, 0, 0, true);
}

struct Frame : public wxFrame
{
	Frame(wxWindow* parent = NULL, wxWindowID id = -1, const wxString& title = _T("AlphaImage"));
};

Frame::Frame(wxWindow* parent, wxWindowID id, const wxString& title) : wxFrame(parent, id, title)
{
	View* view = new View(this);
	
	SetToolBar(wxXmlResource::Get()->LoadToolBar(this, "TOOLBAR"));
	wxToolBarToolBase* tool = GetToolBar()->FindById(XRCID("TOOL_PNG"));
	view->m_bmp = tool->GetNormalBitmap();
	
	view->Show();
}

struct AlphaBlendApp : public wxApp { bool OnInit(); };
DECLARE_APP(AlphaBlendApp)
IMPLEMENT_APP(AlphaBlendApp)

bool AlphaBlendApp::OnInit()
{
	wxImage::AddHandler(new wxPNGHandler);
	wxFileSystem::AddHandler(new wxZipFSHandler);
	wxXmlResource::Get()->InitAllHandlers();
	if (!wxXmlResource::Get()->Load(_T("resources.xrs")))
		return false;

	SetTopWindow(new Frame());
	GetTopWindow()->Show();
	return true;
}


