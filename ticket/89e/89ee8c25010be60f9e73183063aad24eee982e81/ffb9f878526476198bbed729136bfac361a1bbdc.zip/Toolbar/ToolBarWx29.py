import cStringIO, os.path, sys

# this is for 2.8.11.0
#PATH_WX = r'C:\Python26\Lib\site-packages\wx-2.8-msw-unicode'

# this is for 2.9.1.1.b20101001
PATH_WX = r'C:\Python26\Lib\site-packages\wx-2.9.1-msw'

sys.path.insert(0, PATH_WX)
import wx
        
class TestFrame(wx.Frame):
    def __init__(self,parent, id,title,position,size):
        wx.Frame.__init__(self,parent, id,title,position, size)

        self.CreateToolBar()
        self.toolbar = self.GetToolBar()
        self.toolbar.ClearTools()

        for ico_name in ['edit copy.gif', 'edit cut.gif', 'edit paste.gif', 'undo.gif', 'redo.gif']:
            self.add_button(ico_name)

        self.toolbar.Realize()
        self.Show(True)
        
    def add_button(self, label):
        '''
        Add button in toolbar
        '''
        bmp = wx.Image(label, wx.BITMAP_TYPE_ANY).ConvertToBitmap() 
        btn = wx.BitmapButton(self.toolbar, -1, bmp)

        btn.SetLabel(label[:-4])
        self.toolbar.AddControl(btn)

        maxw = bmp.GetWidth()
        maxh = bmp.GetHeight()            
        self.toolbar.SetToolBitmapSize((maxw+4, maxh+4))
        
        
class App(wx.App):
    def OnInit(self):
        frame = TestFrame(None, -1, "Toolbar Wx " + PATH_WX,wx.DefaultPosition,(550,200))
        self.SetTopWindow(frame)
        return True
    
if __name__ == "__main__":
    app = App(0)
    app.MainLoop()
