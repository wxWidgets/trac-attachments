These are Japanese version "internat.po" and "internat.mo".
With them, please replace the files in "(Root of wxWidgets)/
samples/internat/ja/"

These are translation works, so I don't use diff.
Thanks.
 
July 14, 2006
Suzumizaki-Kimitaka
suzumizaki@free.japandesign.ne.jp