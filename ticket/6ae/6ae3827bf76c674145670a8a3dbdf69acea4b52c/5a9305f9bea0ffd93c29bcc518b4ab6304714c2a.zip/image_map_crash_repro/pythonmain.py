import wx
import wx.html

class Frame(wx.Frame):
    def __init__(self):
        wx.Frame.__init__(self, None, -1, "Image map repro (Python)")
        htmlWin = wx.html.HtmlWindow(self)
        htmlWin.LoadFile("data/bad_image_map.html")

class TestApp(wx.App):
    def OnInit(self):
        frame = Frame()
        frame.Show(True)
        self.SetTopWindow(frame)
        return True

def main():
    app = TestApp(0)
    app.MainLoop()

if __name__ == "__main__":
    main()
