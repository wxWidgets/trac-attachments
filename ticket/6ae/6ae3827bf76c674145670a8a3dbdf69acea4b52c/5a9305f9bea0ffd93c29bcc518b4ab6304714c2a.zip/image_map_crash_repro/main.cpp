#include "wx/wx.h"
#include "wx/html/htmlwin.h"

class Frame: public wxFrame{
public:
  Frame()
    : wxFrame(NULL, -1, "Image map repro")
  {
    wxInitAllImageHandlers();
    wxHtmlWindow* window = new wxHtmlWindow(this);
    window->LoadFile(wxFileName("data/bad_image_map.html"));
  }
};

class App : public wxApp{
  virtual bool OnInit(){
    Frame* frame = new Frame();
    frame->Show(true);
    SetTopWindow(frame);
    return true;
  }
};

IMPLEMENT_APP(App)
