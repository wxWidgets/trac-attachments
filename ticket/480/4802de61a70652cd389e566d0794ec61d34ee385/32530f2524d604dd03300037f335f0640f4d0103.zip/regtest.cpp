/////////////////////////////////////////////////////////////////////////////
// Name:        regtest
// Purpose:     Called by the test script produced by 'make_regex_tester' to
//              test wxRegEx
// Author:      Mike Wetherell
// RCS-ID:      $Id$
// Copyright:   (c) Mike Wetherell
// Licence:     wxWindows licence
/////////////////////////////////////////////////////////////////////////////

#if defined(__GNUG__) && !defined(__APPLE__)
    #pragma implementation
    #pragma interface
#endif

// For compilers that support precompilation, includes "wx/wx.h".
#include "wx/wxprec.h"

#ifdef __BORLANDC__
    #pragma hdrstop
#endif

// for all others, include the necessary headers
#ifndef WX_PRECOMP
    #include "wx/app.h"
#endif

#include <wx/regex.h>
#include <wx/wfstream.h>
#include <wx/txtstrm.h>
#include <locale.h>


// The application class
//
class RegApp : public wxAppConsole
{
public:
    RegApp();
    bool OnInit();
    int OnRun();

private:
    enum Status { Success, Skipped, Fail };

    Status DoTest(int flavor);
    void PrintStatus(Status status);
    bool ParseFlags(wxString flags);
    static int MatchCount(wxString expr, int flags);
    
    int m_mode;
    int m_compileFlags;
    int m_matchFlags;
    wxString m_pattern;
    wxString m_data;
    wxChar **m_expected;
    int m_count;

    bool m_basic;
    bool m_extended;
    bool m_advanced;

    wxFFileOutputStream m_outfile;
    wxTextOutputStream m_out;
};

IMPLEMENT_APP_CONSOLE(RegApp)

RegApp::RegApp()
 :  m_mode(0),
    m_compileFlags(0),
    m_matchFlags(0),
    m_count(0),
    m_basic(false),
    m_extended(false),
    m_advanced(false),
    m_outfile(stdout),
    m_out(m_outfile)
{
}

// Parse the command line
//
bool RegApp::OnInit()
{
    setlocale(LC_ALL, "");

    if (argc < 6 || wxStrlen(argv[1]) != 1) {
        PrintStatus(Skipped);
        return false;
    }

    m_mode = argv[1][0];
    wxString flags = argv[3];
    m_pattern = argv[4];
    m_data = argv[5];
    m_expected = argv + 6;
    m_count = argc - 6;

    if (wxStrchr(_T("efmip"), m_mode) == NULL || !ParseFlags(flags)) {
        PrintStatus(Skipped);
        return false;
    }

    return true;
}

// Display results
//
void RegApp::PrintStatus(Status status)
{
    switch (status) {
        case Success:   m_out << _T("Success: "); break;
        case Skipped:   m_out << _T("Skipped: "); break;
        case Fail:      m_out << _T("**FAIL**:"); break;
    }

    for (int i = 1; i < argc; i++) {
        wxString arg = argv[i];
        int needsquote = 0;

        for (size_t j = 0; j < arg.length(); j++)
            if (wxIsspace(arg[j]) || !wxIsprint(arg[j]))
                needsquote = arg[j] = ' ';

        if (!arg || needsquote)
            m_out << _T(" '") << arg << _T("'");
        else
            m_out << _T(" ") << arg;
    }

    m_out << _T("\n");
}

// Parse flags
//
bool RegApp::ParseFlags(wxString flags)
{
    for (const wxChar *p = flags; *p; p++) {
        switch (*p) {
            // noop
            case '-': break;

            // match options
            case '^': m_matchFlags |= wxRE_NOTBOL; break;
            case '$': m_matchFlags |= wxRE_NOTEOL; break;
#if wxUSE_UNICODE
            case '*': break;
#endif
            // compile options
            case '&': m_advanced = m_basic = true; break;
            case 'b': m_basic = true; break;
            case 'e': m_extended = true; break;
            case 'i': m_compileFlags |= wxRE_ICASE; break;
            case 'o': m_compileFlags |= wxRE_NOSUB; break;
            case 'n': m_compileFlags |= wxRE_NEWLINE; break;

            // we don't fully support these flags, but they don't stop us
            // checking for success of failure of the match, so treat as noop
            case 'A': case 'B': case 'E': case 'H':
            case 'I': case 'L': case 'M': case 'N':
            case 'P': case 'Q': case 'R': case 'S':
            case 'T': case 'U': case '%':
                break;

            // anything else we must skip the test
            default:
                return false;
        }
    }

    return true;
}

// Try test for all flavours of expression specified
//
int RegApp::OnRun()
{
    Status status = Skipped;

    if (m_basic)
        status = DoTest(wxRE_BASIC);
    if (status != Fail && m_extended)
        status = DoTest(wxRE_EXTENDED);
#ifdef HAVE_REGEX_ADVANCED
    if (status != Fail && (m_advanced || (!m_basic && !m_extended)))
        status = DoTest(wxRE_ADVANCED);
#endif

    PrintStatus(status);
    return status;
}
    
// Try the test for a single flavour of expression
//
RegApp::Status RegApp::DoTest(int flavor)
{
    wxRegEx re(m_pattern, m_compileFlags | flavor);

    // 'e' - test that the pattern fails to compile
    if (m_mode == 'e')
        return re.IsValid() ? Fail : Success;

    bool matches = re.Matches(m_data, m_matchFlags);

    // 'f' or 'p' - test that the pattern does not match
    if (m_mode == 'f' || m_mode == 'p')
        return matches ? Fail : Success;

    // otherwise 'm' or 'i' - test the pattern does match
    if (!matches)
        return Fail;

    // Check that wxRegEx is going to allocate a large enough array for the
    // results we are suppose to get
    if (m_count > MatchCount(m_pattern, m_compileFlags | flavor))
        return Fail;

    wxString result;
    size_t start, len;

    for (int i = 0; i < m_count; i++) {
        if (!re.GetMatch(&start, &len, i))
            return Fail;

        // m - check the match returns the strings given
        if (m_mode == 'm')
            if (start < INT_MAX)
                result = m_data.Mid(start, len);
            else
                result = _T("");

        // i - check the match returns the offsets given
        else if (m_mode == 'i')
            if (start < INT_MAX)
                result = wxString::Format(_T("%d %d"), start, start + len - 1);
            else
                result = _T("-1 -1");
        else
            return Skipped;

        if (result != m_expected[i])
            return Fail;
    }

    return Success;
}

// Count the number of subexpressions
// (Taken from wxRegExImpl::Compile)
//
int RegApp::MatchCount(wxString expr, int flags)
{
    // there is always one for the whole expression
    int nMatches = 1;

    // and some more for bracketed subexperessions
    for ( const wxChar *cptr = expr; *cptr; cptr++ )
    {
        if ( *cptr == _T('\\') )
        {
            // in basic RE syntax groups are inside \(...\)
            if ( *++cptr == _T('(') && (flags & wxRE_BASIC) )
            {
                nMatches++;
            }
        }
        else if ( *cptr == _T('(') && !(flags & wxRE_BASIC) )
        {
            // we know that the previous character is not an unquoted
            // backslash because it would have been eaten above, so we
            // have a bar '(' and this indicates a group start for the
            // extended syntax
            nMatches++;
        }
    }

    return nMatches;
}

