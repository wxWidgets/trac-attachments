#ifndef TESTLISTCTRL_H_INCLUDED
#define TESTLISTCTRL_H_INCLUDED


#include <wx/listctrl.h>
#include <wx/imaglist.h>

class TestList : public wxListCtrl {

  public:
    TestList(wxWindow *pWnd);
  protected:
    wxString OnGetItemText(long item, long column) const;
    int OnGetItemImage(long item) const;
    wxImageList* mImageList;


}; 




#endif //TESTLISTCTRL_H_INCLUDED