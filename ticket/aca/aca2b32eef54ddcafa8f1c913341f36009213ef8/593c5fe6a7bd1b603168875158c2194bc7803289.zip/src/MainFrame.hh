#ifndef MAINFRAME_H
#define MAINFRAME_H

#include <wx/wx.h>
#include <wx/webview.h>

class MainFrame : public wxFrame
{
public:
    wxPanel *panel;
    wxBoxSizer *topsizer;
    wxMenuBar *menubar;
    wxMenu *file;
    wxWebView *webView;
    wxString editorURL;

    MainFrame(const wxString& title);
    void initMenu();
    void initEditor();
};
#endif