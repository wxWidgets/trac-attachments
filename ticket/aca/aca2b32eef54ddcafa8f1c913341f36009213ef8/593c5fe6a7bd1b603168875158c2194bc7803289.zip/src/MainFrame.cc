#include "MainFrame.hh"

MainFrame::MainFrame(const wxString& title)
    : wxFrame(NULL, wxID_ANY, title, wxDefaultPosition, wxSize(800,600))
{
    panel = new wxPanel(this, -1);
    topsizer = new wxBoxSizer(wxVERTICAL);
    panel->SetSizer(topsizer);

    initMenu();
    initEditor();
}

void MainFrame::initMenu()
{
    menubar = new wxMenuBar;

    file = new wxMenu;
    //file->Append(wxID_EXIT, wxT("Quit"));
    menubar->Append(file, wxT("File"));

    SetMenuBar(menubar);
}

void MainFrame::initEditor()
{
    editorURL = "http://google.com";
    webView = wxWebView::New(panel, wxID_ANY);
    topsizer->Add(webView, 1, wxEXPAND | wxALL, 0);
}