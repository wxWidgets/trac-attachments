#include "MainApp.hh"
#include "MainFrame.hh"

IMPLEMENT_APP(MyApp)

bool MyApp::OnInit()
{
    MainFrame *mainFrame = new MainFrame(wxT("Content Creator"));
    mainFrame->Show(true);

    return true;
}