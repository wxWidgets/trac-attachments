#include <wx/app.h>
#include <wx/frame.h>

class Hang : public wxApp
{
	bool OnInit();
};


IMPLEMENT_APP( Hang )

bool Hang::OnInit()
{	
	wxFrame* frame = new wxFrame( nullptr, wxID_ANY, "A Frame", wxDefaultPosition, wxSize( 800, 600 ) );
	frame->Show();
	return true;
}

