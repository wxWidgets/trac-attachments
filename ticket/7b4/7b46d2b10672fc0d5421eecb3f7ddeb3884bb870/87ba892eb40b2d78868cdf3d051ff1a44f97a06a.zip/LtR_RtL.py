""" This file is designed to explore anomolies that came up when converting to Arabic. """

__author__ = 'David K. Woods <dwoods@wcer.wisc.edu>'

# import wxPython 
import wx
import wx.media
import gettext
import os
import sys

# Define the "_" method, pointing it to wxPython's GetTranslation method
# __builtins__._ = gettext  # wx.GetTranslation

MENU_FILE_EXIT = wx.NewId()

class MainWindow(wx.Frame):
    """ This window displays a variety of GUI Widgets. """
    def __init__(self,parent, title):

        wx.SetDefaultPyEncoding('utf_8')

        self.presLan_en = gettext.translation('LtR_RtL', 'locale', languages=['en']) # English
        self.presLan_ar = gettext.translation('LtR_RtL', 'locale', languages=['ar']) # Arabic
        
        if (len(sys.argv) == 2) and (sys.argv[1] in ['1', '2']):
            if sys.argv[1] == '1':

                self.lang = wx.LANGUAGE_ENGLISH
                self.presLan_en.install(unicode=1)

            elif sys.argv[1] == '2':

                self.lang = wx.LANGUAGE_ARABIC
                self.presLan_ar.install(unicode=1)

            else:
                print "Unknown parameter."
                exit(1)
                
        else:

            print
            print "Usage:  python LtR_RtL.py [1 | 2]"
            print "        1 = Left to Right language (English)"
            print "        2 = Right to Left language (Arabic)"
            print
            exit(1)

        print wx.version()

        # This provides localization for wxPython
        self.locale = wx.Locale(self.lang)
        self.locale.AddCatalog("LtR_RtL")
        
        wx.Frame.__init__(self,parent,-1, title, size = (800,800), style=wx.DEFAULT_FRAME_STYLE|wx.NO_FULL_REPAINT_ON_RESIZE)
        self.SetBackgroundColour(wx.WHITE)

        # Menu Bar
        # Create a MenuBar
        menuBar = wx.MenuBar()
        # Build a Menu Object to go into the Menu Bar
        menu1 = wx.Menu()
        menu1.Append(MENU_FILE_EXIT, _("E&xit"))
        #Place the Menu Item in the Menu Bar
        menuBar.Append(menu1, _("&File"))

        self.SetMenuBar(menuBar)
        #Define Events for the Menu Items
        wx.EVT_MENU(self, MENU_FILE_EXIT, self.CloseWindow)

        mainSizer = wx.BoxSizer(wx.VERTICAL)

        if self.lang == wx.LANGUAGE_ENGLISH:
            title = wx.StaticText(self, -1, _("English"))
            style = wx.TE_LEFT
        else:
            title = wx.StaticText(self, -1, _("Arabic"))
            style = wx.TE_RIGHT
        mainSizer.Add(title, 0, wx.EXPAND | wx.TOP | wx.LEFT | wx.RIGHT | wx.ALIGN_CENTER_HORIZONTAL, 5)
        mainSizer.Add((0, 10))

        value = title.GetLabel()

#        value2 = u'\u1575\u1604\u1593\u1585\u1576\u1610\u1577'
        value2 = unichr(1575) + unichr(1604) + unichr(1593) + unichr(1585) + unichr(1576) + unichr(1610) + unichr(1577)

        print len(value), type(value), len(value2), type(value2)
        for x in range(len(value)):
            print x, ord(value[x])
        print
        for x in range(len(value2)):
            print x, ord(value2[x])
        print
        
        print 'Equal?', value == value2

        st = '%s - %s' % (value, value2)
        title.SetLabel(st)

        txtCtrl = wx.TextCtrl(self, -1, "Notes:  (In English, in a left-to-right text box and TE_LEFT alignment, regardless of language selection.)\n\n",
                              style=wx.ALIGN_LEFT | wx.TE_LEFT | wx.TE_MULTILINE)
        txtCtrl.SetLayoutDirection(wx.Layout_LeftToRight)
        mainSizer.Add(txtCtrl, 1, wx.EXPAND | wx.ALL, 5)

        txtCtrl.AppendText("This program is designed to explore anomolies I found when trying to add Arabic to my application.\n\n")
        txtCtrl.AppendText("Although this TextCtrl has been set to wx.Layout_LeftToRight using the SetLayoutDirection() method and ")
        txtCtrl.AppendText("has the wx.TE_LEFT style, it still shows up as right-justified in the Arabic version.  (I need to mix ")
        txtCtrl.AppendText("languages in my application, showing both Arabic and English or French texts at the same time.)  ")
        txtCtrl.AppendText("Furthermore, punctuation gets adjusted even when I don't want it to.  Finally, cursor right moves ")
        txtCtrl.AppendText("you left and cursor left moves you right.  That's counter-intuitive.\n\n")
        txtCtrl.AppendText('Notice the choices in the "Video Size" combo box.  They should be in "640 x 480" form.  The selected ')
        txtCtrl.AppendText('entry gets formatted okay since I added the SetLayoutDirection(wx.Layout_LeftToRight) call, but the ')
        txtCtrl.AppendText('list items in the dropdown part of the control are mangled.  You can also see the string the control ')
        txtCtrl.AppendText('returns next to the control.\n\n')
        txtCtrl.AppendText('If you have set the MediaFilename in the code, you can press the "Play" button to play the ')
        txtCtrl.AppendText("media file.  The QuickTime back end doesn't display video when Arabic is used, although it does play ")
        txtCtrl.AppendText("audio, while the WMP10 back end with an MPEG-1 file works fine in both languages.\n\n")
        txtCtrl.AppendText("When combining translated and untranslated strings, such as in file names, string concatenation ")
        txtCtrl.AppendText("doesn't occur in an order that makes sense to me.  Put your cursor in the Filename textbox and ")
        txtCtrl.AppendText('move the cursor right and left.  The string mixes LtR and RtL somehow.\n\n')

        hSizer1 = wx.BoxSizer(wx.HORIZONTAL)
        vSizer1 = wx.BoxSizer(wx.VERTICAL)
        
        title = wx.StaticText(self, -1, _("Video Size"))
        vSizer1.Add(title, 0, wx.LEFT | wx.RIGHT, 5)
        hSizer2 = wx.BoxSizer(wx.HORIZONTAL)
        choiceList = ['640 x 480', '800 x 600', '1024 x 768']
        self.cbCtrl = wx.ComboBox(self, -1, choices=choiceList, style=wx.CB_DROPDOWN)
        self.cbCtrl.SetLayoutDirection(wx.Layout_LeftToRight)
        self.cbCtrl.SetSelection(0)
        self.cbCtrl.Bind(wx.EVT_COMBOBOX, self.OnVideoSize)
        hSizer2.Add(self.cbCtrl, 0, wx.LEFT | wx.RIGHT | wx.BOTTOM, 5)
        self.videoSize = wx.StaticText(self, -1, self.cbCtrl.GetStringSelection())
        hSizer2.Add(self.videoSize, 0, wx.LEFT | wx.RIGHT, 5)
        vSizer1.Add(hSizer2, 0)

        title = wx.StaticText(self, -1, "Play the video with this button!")
        vSizer1.Add(title, 0, wx.LEFT | wx.RIGHT, 5)
        # Get the initial image for the Play / Pause button
        img = imgPlay.GetBitmap()
        # Create the Play / Pause button
        btnPlayPause = wx.BitmapButton(self, -1, img, size=(48, 24))
        # Set the Help String
        btnPlayPause.SetToolTipString(_("Play"))
        btnPlayPause.Bind(wx.EVT_BUTTON, self.OnPlayButton)
        vSizer1.Add(btnPlayPause, 0, wx.LEFT | wx.RIGHT | wx.BOTTOM, 5)

        st1 = unicode('C:', 'utf8')
        st2 = unicode('Directory 1', 'utf8')
        st3 = unicode('Directory 2', 'utf8')
        st4 = unicode('Filename', 'utf8')
        if self.lang == wx.LANGUAGE_ENGLISH:
            st5 = _('-Analysis')
        else:
            st5 = unicode('-Analysis', 'utf8')
        st6 = unicode('.ext', 'utf8')

        print "types 1:", type(st5), type(st6)

        result1 = st1 + os.sep + st2 + os.sep + st3 + os.sep + st4 + st5 + st6
        result2 = st1 + os.sep + os.path.join(st2, st3, st4) + st5 + st6
        result3 = u"%s\\%s\\%s\\%s%s%s" % (st1, st2, st3, st4, st5, st6)

        title = wx.StaticText(self, -1, "Concatenated File Names all in English")
        vSizer1.Add(title, 0, wx.LEFT | wx.RIGHT, 5)
        string1 = wx.StaticText(self, -1, result1)
        vSizer1.Add(string1, 0, wx.LEFT | wx.RIGHT | wx.BOTTOM, 5)
        string2 = wx.StaticText(self, -1, result2)
        vSizer1.Add(string2, 0, wx.LEFT | wx.RIGHT | wx.BOTTOM, 5)
        string3 = wx.StaticText(self, -1, result3)
        vSizer1.Add(string3, 0, wx.LEFT | wx.RIGHT | wx.BOTTOM, 5)

        txt = wx.TextCtrl(self, -1, style=style)
        txt.SetValue(result2)
        vSizer1.Add(txt, 0, wx.EXPAND | wx.LEFT | wx.RIGHT | wx.BOTTOM, 5)

        print 'Equal?', result2 == txt.GetValue()

        st5 = _('-Analysis')

        print "types 2:", type(st5), type(st6)

        try:
            result1 = st1 + os.sep + st2 + os.sep + st3 + os.sep + st4 + st5 + st6
        except UnicodeDecodeError:
            result1 = 'UnicodeDecodeError 1'
        try:
            result2 = st1 + os.sep + os.path.join(st2, st3, st4) + st5 + st6
        except UnicodeDecodeError:
            result1 = 'UnicodeDecodeError 2'
        try:
            result3 = u"%s\\%s\\%s\\%s%s%s" % (st1, st2, st3, st4, st5, st6)
        except UnicodeDecodeError:
            result1 = 'UnicodeDecodeError 3'

        title = wx.StaticText(self, -1, "Concatenated File Names all in Mixed Languages")
        vSizer1.Add(title, 0, wx.LEFT | wx.RIGHT, 5)
        string1 = wx.StaticText(self, -1, result1)
        vSizer1.Add(string1, 0, wx.LEFT | wx.RIGHT | wx.BOTTOM, 5)
        string2 = wx.StaticText(self, -1, result2)
        vSizer1.Add(string2, 0, wx.LEFT | wx.RIGHT | wx.BOTTOM, 5)
        string3 = wx.StaticText(self, -1, result3)
        vSizer1.Add(string3, 0, wx.LEFT | wx.RIGHT | wx.BOTTOM, 5)

        txt = wx.TextCtrl(self, -1, style=style)
        txt.SetLayoutDirection(wx.Layout_LeftToRight)
        txt.SetValue(result2)
        vSizer1.Add(txt, 0, wx.EXPAND | wx.LEFT | wx.RIGHT | wx.BOTTOM, 5)
        hSizer1.Add(vSizer1, 1, wx.EXPAND)

        print 'Equal?', type(result2), type(txt.GetValue())
        print result2 == txt.GetValue()

        vSizer2 = wx.BoxSizer(wx.VERTICAL)

        # Comment out one or the other of these pairs of lines to switch between media file types and the
        # appropriate back ends
        
        # This needs to be a file that uses the QuickTime Player (*.mov, *.mp4, *.m4v for example)
        videoFile = 'C:\\Users\\DavidWoods\\Videos\\Mac Switch\\Ellen Feiss.mov'
        backend = wx.media.MEDIABACKEND_QUICKTIME

        # The Windows Media Player back end with MPEG-1 video works fine in both language directions.
        # videoFile = 'C:\\Users\\DavidWoods\\Videos\\Demo\\Demo.mpg'
        # backend = wx.media.MEDIABACKEND_WMP10
        
        title = wx.StaticText(self, -1, videoFile)
        vSizer2.Add(title, 0, wx.LEFT | wx.RIGHT, 5)

        self.mediaCtrl = wx.media.MediaCtrl(self, szBackend=backend)
        if os.path.exists(videoFile):
            self.mediaCtrl.Load(videoFile)
        else:
            msg = _('File \"%s\" not found.') 
            title.SetLabel(msg % videoFile)

        vSizer2.Add(self.mediaCtrl, 0, wx.ALL, 5)        
        hSizer1.Add(vSizer2, 0)
        mainSizer.Add(hSizer1, 0, wx.EXPAND)

        self.SetSizer(mainSizer)
        self.SetAutoLayout(True)
        self.Layout()
        self.CentreOnScreen()

        self.Show(True)

    def OnVideoSize(self, event):
        self.videoSize.SetLabel(self.cbCtrl.GetStringSelection())

    def OnPlayButton(self, event):
        if self.mediaCtrl.GetState() == wx.media.MEDIASTATE_PLAYING:
            self.mediaCtrl.Pause()
        else:
            self.mediaCtrl.Play()

    def CloseWindow(self, event):
        self.Close()

    def GetImage(self, imagename):
        """ Images automatically get reversed with using a RightToLeft language.  This method undoes that! """
        if self.locale.GetLanguageInfo(self.lang).LayoutDirection == wx.Layout_RightToLeft:
            img = imagename.GetImage().Mirror()
            return img.ConvertToBitmap()
        else:
            return imagename.GetBitmap()

from wx.lib.embeddedimage import PyEmbeddedImage

imgPlay = PyEmbeddedImage(
    "iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAABHNCSVQICAgIfAhkiAAAAG9J"
    "REFUOI1jZGRiZqAEMFGkm4GBgQXG+P/v739kCUYmZkaSXSD0A4JhBqIbStAAcgzCGwbEGERU"
    "IOIziKRYQDeIZAOQDSLLBTDwjgPBZsGtDL9GWDohygBsGolyAT6NeA0gRiNcHpYbyc0LjJRm"
    "ZwB2TTxTHwZpwQAAAABJRU5ErkJggg==")

class MyApp(wx.App):
    def OnInit(self):
        frame = MainWindow(None, "Left to Right - Right to Left")
        self.SetTopWindow(frame)
        return True

app = MyApp(0)
app.MainLoop()
