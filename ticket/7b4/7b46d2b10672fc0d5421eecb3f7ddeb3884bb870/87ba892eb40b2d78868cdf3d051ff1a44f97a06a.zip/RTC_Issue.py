""" This file is designed to explore anomolies that came up when converting to Arabic. """

__author__ = 'David K. Woods <dwoods@wcer.wisc.edu>'

# import wxPython 
import wx
import wx.media
import wx.richtext as richtext
import gettext
import os
import sys
import time

# Define the "_" method, pointing it to wxPython's GetTranslation method
__builtins__._ = wx.GetTranslation

MENU_FILE_EXIT = wx.NewId()
MENU_FILE_PRINT_PREVIEW = wx.NewId()
MENU_FILE_PRINT = wx.NewId()

class MainWindow(wx.Frame):
    """ This window displays a variety of GUI Widgets. """
    def __init__(self,parent, title):

        wx.SetDefaultPyEncoding('utf_8')

        # This is the catalog for a different program.  Doesn't matter here.
        self.presLan_ar = gettext.translation('LtR_RtL', 'locale', languages=['ar']) # Arabic
        
        self.lang = wx.LANGUAGE_ARABIC
        self.presLan_ar.install()

        # This provides localization for wxPython
        self.locale = wx.Locale(self.lang)
        # This is the catalog for a different program.  Doesn't matter here.
        self.locale.AddCatalog("LtR_RtL")
        
        self.printData = wx.PrintData()
        self.printData.SetPaperId(wx.PAPER_LETTER)

        wx.Frame.__init__(self,parent,-1, title, size = (800,800), style=wx.DEFAULT_FRAME_STYLE|wx.NO_FULL_REPAINT_ON_RESIZE)
        self.SetBackgroundColour(wx.WHITE)

        # Menu Bar
        # Create a MenuBar
        menuBar = wx.MenuBar()
        # Build a Menu Object to go into the Menu Bar
        menu1 = wx.Menu()
        menu1.Append(MENU_FILE_PRINT_PREVIEW, _("Print Preview"))
        menu1.Append(MENU_FILE_PRINT, _("&Print"))
        menu1.Append(MENU_FILE_EXIT, _("E&xit"))
        #Place the Menu Item in the Menu Bar
        menuBar.Append(menu1, _("&File"))

        self.SetMenuBar(menuBar)
        #Define Events for the Menu Items
        wx.EVT_MENU(self, MENU_FILE_PRINT_PREVIEW, self.OnPrintPreview)
        wx.EVT_MENU(self, MENU_FILE_PRINT, self.OnPrint)
        wx.EVT_MENU(self, MENU_FILE_EXIT, self.CloseWindow)

        mainSizer = wx.BoxSizer(wx.VERTICAL)

        if self.lang == wx.LANGUAGE_ENGLISH:
            title = wx.StaticText(self, -1, _("English"))
            style = wx.TE_LEFT
        else:
            title = wx.StaticText(self, -1, _("Arabic"))
            style = wx.TE_RIGHT
        mainSizer.Add(title, 0, wx.EXPAND | wx.TOP | wx.LEFT | wx.RIGHT | wx.ALIGN_CENTER_HORIZONTAL, 5)
        mainSizer.Add((0, 10))

        txtCtrl = wx.TextCtrl(self, -1, "Notes:  (In English, in a left-to-right text box and TE_LEFT alignment.)\n\n",
                              style=wx.ALIGN_LEFT | wx.TE_LEFT | wx.TE_MULTILINE)
        txtCtrl.SetLayoutDirection(wx.Layout_LeftToRight)
        mainSizer.Add(txtCtrl, 1, wx.EXPAND | wx.ALL, 5)

        txtCtrl.AppendText("This program is designed to explore anomolies I found when trying to add Arabic to my application.\n\n")
        txtCtrl.AppendText("Below is a wx.RichTextCtrl containing some Arabic text.  There are some markers in the text in red, which")
        txtCtrl.AppendText("I use in my program to hold critical information.\n\n")
        txtCtrl.AppendText("Click in the middle of a line.  Notice that cursor LEFT moves you RIGHT and cursor RIGHT moves you LEFT.\n\n")

        txtCtrl.AppendText("Now select Print from the File Menu.  (There's only one menu, which is Arabic for File, and which contains ")
        txtCtrl.AppendText("entries for Print Preview, Print, and Exit.)  You will notice several things about the printout.  \n\n")
        txtCtrl.AppendText("First, the printout is left justified.  It should be right justified.\n\n")
        txtCtrl.AppendText("Second, the red codes are not in the correct places in their lines.\n\n")
        txtCtrl.AppendText("Third, word order seems to get changed around these red codes.  The word order is not correct.\n\n")

        txtCtrl.AppendText("Now select Print Preview from the File Menu.  (There's only one menu, which is Arabic for File, and which contains ")
        txtCtrl.AppendText("entries for Print Preview, Print, and Exit.)  The Print Preview shows all the characters andwords BACKWARDS, ")
        txtCtrl.AppendText("a mirror image of how the text is supposed to look.  But when you reverse the image in your mind, you can ")
        txtCtrl.AppendText("see that it has all the same problems as the printout above.  It's left justified, the red codes are placed ")
        txtCtrl.AppendText("wrong, and the word order isn't correct.")

        self.richtxtCtrl = richtext.RichTextCtrl(self, -1, style=wx.VSCROLL | wx.HSCROLL | wx.WANTS_CHARS)
        mainSizer.Add(self.richtxtCtrl, 1, wx.EXPAND | wx.ALL, 5)

        try:
            # Create an XML Handler
            handler = richtext.RichTextXMLHandler()
            # Load the XML text via the XML Handler.
            # Note that for XML, the BUFFER is passed.
            handler.LoadFile(self.richtxtCtrl.GetBuffer(), 'Arabic Transcript.xml')
        # exception handling
        except:
            print "XML Handler Load failed"
            print
            print sys.exc_info()[0], sys.exc_info()[1]
            import traceback
            print traceback.print_exc()
            print

        self.SetSizer(mainSizer)
        self.SetAutoLayout(True)
        self.Layout()
        self.CentreOnScreen()

        self.Show(True)

    def OnPrintPreview(self, event):

        # Create the first Printout object using a RichTextPrintout object
        printout1 = richtext.RichTextPrintout()
        # Put the RichTextCtrl's Buffer into the RichTextPrintout object
        printout1.SetRichTextBuffer(self.richtxtCtrl.GetBuffer())
        # Create the second Printout object using a RichTextPrintout object
        printout2 = richtext.RichTextPrintout()
        # Put the RichTextCtrl's Buffer into the RichTextPrintout object
        printout2.SetRichTextBuffer(self.richtxtCtrl.GetBuffer())

        # Get a PrintDialogData object
        data = wx.PrintDialogData()
        # Populate the PrintDialogData Object with print data from Transana's configuration info
        data.SetPrintData(self.printData)

        # Create a PrintPreview Object using the printout objects and print data created above
        preview = wx.PrintPreview(printout1, printout2, data)

        # If this didn't work ...
        if not preview.Ok():

            print "NEED ERROR MESSAGE HERE!!!!  PREVIEW FAILURE !!!!"

            # ... just exit here.
            return

        # Now create a Print Preview WINDOW using the Print Preview Object created above
        previewFrame = wx.PreviewFrame(preview, self, "Arabic Print Test")
        # Initialize the Print Preview Window
        previewFrame.Initialize()

        # Okay, here's another wrinkle.  If you choose Print from the Print Preview, THAT messes up the
        # RTC formatting too.  Here's a workaround for that.

        # First, identify the "Print" button using its label
#        printButton = previewFrame.FindWindowByLabel("&Print...")
        # If that failed ...
#        if printButton == None:
            # ... try again using its ID, which appears to be 4 pretty consistently for me.
#            printButton = previewFrame.FindWindowById(4)

        # If the Print button is found
#        if printButton != None:
            # hijack the button press, pointing it to the local OnPrint method
#            printButton.Bind(wx.EVT_BUTTON, self.OnPrint)
        # If the Print Button is NOT found ... (It's almost certainly due to i18n issues.  Is there another way??)
#        else:

#            print "NEED ERROR MESSAGE HERE!!!!  DO NOT USE PRINT BUTTON!!!!"

        # Position the Print Preview Frame on top of the TextReport frame
        previewFrame.SetPosition(self.GetPosition())
        # Size the Print Preview Frame to match the TextReport Frame
        previewFrame.SetSize(self.GetSize())
        # Finally, we can show the Print Preview Frame
        previewFrame.Show(True)

    def OnPrint(self, event):
        """ Implements Transcript Printing from the File and Transcript menus """
        # Define the FONT for the Header and Footer text
        headerFooterFont = wx.Font(10, wx.FONTFAMILY_ROMAN, wx.FONTSTYLE_NORMAL, wx.FONTWEIGHT_NORMAL, False, "Times New Roman")
        # Get the current date and time
        t = time.localtime()
        # Format the Footer Date as M/D/Y
        footerDate = "%d/%d/%d" % (t.tm_mon, t.tm_mday, t.tm_year)
        # Format the Footer Page Number
        footerPage = _("Page") + " @PAGENUM@ " + _("of") + " @PAGESCNT@"
        # Create a RichTextPrinting Object
        printout = richtext.RichTextPrinting("Arabic Print Test", self)
        # Let the printout know about the default printer settings
        printout.SetPrintData(self.printData)
        # Specify the Header / Footer Font
        printout.SetHeaderFooterFont(headerFooterFont)
        # Add the Report Title to the top right
        printout.SetHeaderText('This is a Header', location=richtext.RICHTEXT_PAGE_RIGHT)
        # Add the date to the bottom left
        printout.SetFooterText(footerDate, location=richtext.RICHTEXT_PAGE_LEFT)
        # Add the page number to the bottom right
        printout.SetFooterText(footerPage, location=richtext.RICHTEXT_PAGE_RIGHT)
        # Do NOT show Header and Footer on the First Page
        printout.SetShowOnFirstPage(False)
        # print the RTC Buffer Contents
        # Get the Rich Text Buffer object
        buf = self.richtxtCtrl.GetBuffer()
        # Define the RichTextPrintout Object's Print Buffer
        printout.PrintBuffer(buf)
        # Destroy the RichTextPrinting Object
        printout.Destroy()

    def CloseWindow(self, event):
        self.Close()

class MyApp(wx.App):
    def OnInit(self):
        frame = MainWindow(None, "RichTextCtrl issues with Arabic")
        self.SetTopWindow(frame)
        return True

app = MyApp(0)
app.MainLoop()
