#pragma once

#pragma comment(lib,"Rpcrt4.lib")
#pragma comment(lib,"comctl32.lib")
#pragma comment(lib,"Ws2_32.lib")

#if defined(_DLL)
#	if defined(WXUSINGDLL)
#		if defined(_DEBUG)
#			pragma include_alias("wx/setup.h", "../lib/mswdlld/wx/setup.h")
#			pragma comment(lib,"wxmsw24d.lib")
#			pragma message("Including wxmsw24d.lib...")
#		else
#			pragma include_alias("wx/setup.h", "../lib/mswdll/wx/setup.h")
#			pragma comment(lib,"wxmsw24.lib")
#			pragma message("Including wxmsw24.lib...")
#		endif
#	else
#		if defined(_DEBUG)
#			pragma include_alias("wx/setup.h", "../lib/mswd/wx/setup.h")
#			pragma comment(lib,"wxmswd.lib")
#			pragma message("Including wxmswd.lib...")
#		else
#			pragma include_alias("wx/setup.h", "../lib/msw/wx/setup.h")
#			pragma comment(lib,"wxmsw.lib")
#			pragma message("Including wxmsw.lib...")
#		endif
#	endif
#else // !defined(_DLL)
#	if defined(_MT)
#		if defined(_DEBUG)
#			pragma include_alias("wx/setup.h", "../lib/mswstd/wx/setup.h")
#			pragma comment(lib,"wxmswstd.lib")
#			pragma message("Including wxmswstd.lib...")
#		else
#			pragma include_alias("wx/setup.h", "../lib/mswst/wx/setup.h")
#			pragma comment(lib,"wxmswst.lib")
#			pragma message("Including wxmswst.lib...")
#		endif
#	else
#		if defined(_DEBUG)
#			pragma include_alias("wx/setup.h", "../lib/mswsstd/wx/setup.h")
#			pragma comment(lib,"wxmswsstd.lib")
#			pragma message("Including wxmswsstd.lib...")
#		else
#			pragma include_alias("wx/setup.h", "../lib/mswsst/wx/setup.h")
#			pragma comment(lib,"wxmswsst.lib")
#			pragma message("Including wxmswsst.lib...")
#		endif
#	endif
#endif

#include <wx/wx.h>