/***************************************************************
 * Name:      TestWXMain.h
 * Purpose:   Defines Application Frame
 * Author:    Biplab Kumar Modak (bkmodak@gmail.com)
 * Created:   2007-10-20
 * Copyright: Biplab Kumar Modak (http://biplab.in)
 * License:
 **************************************************************/

#ifndef TESTWXMAIN_H
#define TESTWXMAIN_H

//(*Headers(TestWXDialog)
#include <wx/sizer.h>
#include <wx/stattext.h>
#include <wx/listbox.h>
#include <wx/statline.h>
#include <wx/button.h>
#include <wx/dialog.h>
//*)

class TestWXDialog: public wxDialog
{
    public:

        TestWXDialog(wxWindow* parent,wxWindowID id = -1);
        virtual ~TestWXDialog();

    private:

        //(*Handlers(TestWXDialog)
        void OnQuit(wxCommandEvent& event);
        void OnAbout(wxCommandEvent& event);
        //*)

        //(*Identifiers(TestWXDialog)
        static const long ID_STATICTEXT1;
        static const long ID_LISTBOX1;
        static const long ID_BUTTON1;
        static const long ID_STATICLINE1;
        static const long ID_BUTTON2;
        //*)

        //(*Declarations(TestWXDialog)
        wxButton* Button1;
        wxStaticText* StaticText1;
        wxBoxSizer* BoxSizer2;
        wxButton* Button2;
        wxStaticLine* StaticLine1;
        wxBoxSizer* BoxSizer1;
        wxListBox* ListBox1;
        //*)

        DECLARE_EVENT_TABLE()
};

#endif // TESTWXMAIN_H
