/***************************************************************
 * Name:      TestWXApp.cpp
 * Purpose:   Code for Application Class
 * Author:    Biplab Kumar Modak (bkmodak@gmail.com)
 * Created:   2007-10-20
 * Copyright: Biplab Kumar Modak (http://biplab.in)
 * License:
 **************************************************************/

#include "TestWXApp.h"

//(*AppHeaders
#include "TestWXMain.h"
#include <wx/image.h>
//*)

IMPLEMENT_APP(TestWXApp);

bool TestWXApp::OnInit()
{
    //(*AppInitialize
    bool wxsOK = true;
    wxInitAllImageHandlers();
    if ( wxsOK )
    {
    	TestWXDialog Dlg(0);
    	SetTopWindow(&Dlg);
    	Dlg.ShowModal();
    	wxsOK = false;
    }
    //*)
    return wxsOK;

}
