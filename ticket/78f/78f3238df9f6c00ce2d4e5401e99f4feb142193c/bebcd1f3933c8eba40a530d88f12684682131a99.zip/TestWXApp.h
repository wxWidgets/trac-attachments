/***************************************************************
 * Name:      TestWXApp.h
 * Purpose:   Defines Application Class
 * Author:    Biplab Kumar Modak (bkmodak@gmail.com)
 * Created:   2007-10-20
 * Copyright: Biplab Kumar Modak (http://biplab.in)
 * License:
 **************************************************************/

#ifndef TESTWXAPP_H
#define TESTWXAPP_H

#include <wx/app.h>

class TestWXApp : public wxApp
{
    public:
        virtual bool OnInit();
};

#endif // TESTWXAPP_H
