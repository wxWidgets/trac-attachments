//Default frame.h for wxHatch

#ifndef _frame_h
#define _frame_h



class MyApp: public wxApp
{
public:
    virtual bool OnInit();
};



class MyFrame: public wxFrame
{
public:
    MyFrame(const wxString& title, const wxPoint& pos, const wxSize& size);


    void OnLClick(wxMouseEvent& event);

    ~MyFrame ();
    
    DECLARE_EVENT_TABLE()
};

#endif
