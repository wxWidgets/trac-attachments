//Default frame.cpp for wxHatch

#ifdef __BIDE__
#define _NO_VCL
#include "condefs.h" 
USEUNIT("jeffress.cpp");
//---------------------------------------------------------------------------
#define WinMain WinMain
#endif

// For compilers that support precompilation, includes "wx.h".
#include "wx/wxprec.h"


#ifdef __BORLANDC__
#pragma hdrstop
#endif

#ifndef WX_PRECOMP
#include "wx/wx.h"
#endif



class MyFrame ;


#include "jeffress.h"
#define space "  "

BEGIN_EVENT_TABLE(MyFrame, wxFrame)
//works with EVT_LEFT_DOWN !!
    EVT_LEFT_UP(MyFrame::OnLClick)
END_EVENT_TABLE()

IMPLEMENT_APP(MyApp)

bool MyApp::OnInit()
{
    MyFrame *frame = new MyFrame (wxT("jeffress: coincidence detector ??"),
                                  wxPoint(20,20), wxSize(600,450));

    frame->Show (TRUE);

    return TRUE;
}

MyFrame::MyFrame(const wxString& title, const wxPoint& pos, const wxSize& size)
    : wxFrame((wxFrame *)NULL, -1, title, pos, size)
    {

        SetBackgroundColour(*wxWHITE);
    }
    




MyFrame::~MyFrame ()
{

}



void MyFrame::OnLClick(wxMouseEvent& event)
{       
  wxClientDC dc(this) ;

    int i ;
    int xBmp = 200;
    int yBmp = 200;
    for (i = xBmp + 80 ; i < xBmp + 200; i = i + 10) dc.DrawCircle(i, yBmp + 172, 5);
}

