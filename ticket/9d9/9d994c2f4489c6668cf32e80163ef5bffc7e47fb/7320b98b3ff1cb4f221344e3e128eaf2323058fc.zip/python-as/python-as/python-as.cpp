#include "stdafx.h"

#include <afxdlgs.h>

#include <activscp.h>
#include <comdef.h>
#include <comdefsp.h>
#include <string.h>
#include <cassert>

class MyActiveScriptSite : public IActiveScriptSite {
  ULONG mRef; // Reference count

private:
  // IUnknown methods...
  virtual HRESULT _stdcall QueryInterface(REFIID riid, void **ppvObject) {
    if (riid == IID_IActiveScriptSite) {
      AddRef();
      IActiveScriptSite* ptr = this;
      *ppvObject = ptr;
      return S_OK;
    }
    *ppvObject = NULL;
    return E_NOTIMPL;
  }

  virtual ULONG _stdcall AddRef(void) {
    return ++mRef;
  }

  virtual ULONG _stdcall Release(void) {
    return --mRef;
  }

  // IActiveScriptSite methods...
  virtual HRESULT _stdcall GetLCID(LCID *plcid) {
    *plcid = 0; // must set valid value for python
    return S_OK;
  }

  virtual HRESULT _stdcall GetItemInfo(LPCOLESTR pstrName, DWORD dwReturnMask, IUnknown **ppunkItem, ITypeInfo **ppti) {
    return E_NOTIMPL;
  }

  virtual HRESULT __stdcall GetDocVersionString(BSTR *pbstrVersion) {
    return S_OK;
  }

  virtual HRESULT __stdcall OnScriptTerminate(const VARIANT *pvarResult, const EXCEPINFO *pexcepInfo) {
    return S_OK;
  }

  virtual HRESULT __stdcall OnStateChange(SCRIPTSTATE ssScriptState) {
    return S_OK;
  }

  virtual HRESULT __stdcall OnScriptError(IActiveScriptError *pscriptError) {
    return S_OK;
  }

  virtual HRESULT __stdcall OnEnterScript(void) {
    return S_OK;
  }

  virtual HRESULT __stdcall OnLeaveScript(void) {
    return S_OK;
  }

public:
  MyActiveScriptSite::MyActiveScriptSite() : mRef(1)
  {
  }

  MyActiveScriptSite::~MyActiveScriptSite()
  {
    assert(mRef == 1);
  }
};

int WINAPI _tWinMain(HINSTANCE hInstance,
                     HINSTANCE hPrevInstance,
                     LPTSTR lpCmdLine,
                     int nCmdShow)
{
  afxCurrentResourceHandle = hInstance;
  OleInitialize(NULL);

  IActiveScript* tmp = 0;
  CLSID CLSID_ScriptEngine;
  HRESULT hr = CLSIDFromString(_bstr_t(L"{DF630910-1C1D-11d0-AE36-8C0F5E000000}"), &CLSID_ScriptEngine);
  if (hr != S_OK) return 1;
  hr = CoCreateInstance(CLSID_ScriptEngine, NULL, CLSCTX_ALL, IID_IActiveScript, (void **)&tmp);
  if (hr != S_OK) return 1;
  IActiveScriptPtr as(tmp, false);
  MyActiveScriptSite mySite;
  as->SetScriptSite(&mySite);
  IActiveScriptParse* asp = 0;
  hr = as->QueryInterface(IID_IActiveScriptParse, (void**)&asp);
  if (hr != S_OK) return 1;
  hr = asp->InitNew();
  if (hr != S_OK) { asp->Release(); return 1; }
  EXCEPINFO ei;
  memset(&ei, 0, sizeof(ei));
  hr = asp->ParseScriptText(_bstr_t(L"import wx\napp = wx.App()"), 0, NULL, NULL, 0, 0, 0, NULL, &ei);
  if (hr != S_OK) { asp->Release(); return 1; }
  asp->Release();
  hr = as->SetScriptState(SCRIPTSTATE_CONNECTED);
  if (hr != S_OK) return 1;
  hr = as->Close();
  if (hr != S_OK) return 1;

  CFileDialog fileDlg(TRUE);
  fileDlg.DoModal();

  return 0;
}
