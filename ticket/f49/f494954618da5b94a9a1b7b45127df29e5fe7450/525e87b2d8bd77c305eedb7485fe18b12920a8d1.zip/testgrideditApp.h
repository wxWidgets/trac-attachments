#ifndef TESTGRIDEDITAPP_H
#define TESTGRIDEDITAPP_H

#include <wx/app.h>

class testgrideditApp : public wxApp
{
    public:
        virtual bool OnInit();
};

#endif // TESTGRIDEDITAPP_H
