#include "testgrideditMain.h"
#include <wx/msgdlg.h>

//(*InternalHeaders(testgrideditDialog)
#include <wx/intl.h>
#include <wx/string.h>
//*)

//(*IdInit(testgrideditDialog)
const long testgrideditDialog::ID_GRID1 = wxNewId();
const long testgrideditDialog::ID_TEXTCTRL1 = wxNewId();
const long testgrideditDialog::ID_BUTTON1 = wxNewId();
const long testgrideditDialog::ID_BUTTON2 = wxNewId();
//*)

BEGIN_EVENT_TABLE(testgrideditDialog,wxDialog)
    //(*EventTable(testgrideditDialog)
    //*)
END_EVENT_TABLE()

testgrideditDialog::testgrideditDialog(wxWindow* parent,wxWindowID id)
{
    //(*Initialize(testgrideditDialog)
    wxFlexGridSizer* FlexGridSizer2;
    wxBoxSizer* BoxSizer1;
    wxFlexGridSizer* FlexGridSizer1;

    Create(parent, id, _("wxWidgets app"), wxDefaultPosition, wxDefaultSize, wxDEFAULT_DIALOG_STYLE, _T("id"));
    FlexGridSizer1 = new wxFlexGridSizer(1, 2, 0, 0);
    Grid1 = new wxGrid(this, ID_GRID1, wxDefaultPosition, wxSize(173,290), 0, _T("ID_GRID1"));
    Grid1->CreateGrid(10,1);
    Grid1->EnableEditing(true);
    Grid1->EnableGridLines(true);
    Grid1->SetDefaultCellFont( Grid1->GetFont() );
    Grid1->SetDefaultCellTextColour( Grid1->GetForegroundColour() );
    FlexGridSizer1->Add(Grid1, 1, wxALL|wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL, 5);
    FlexGridSizer2 = new wxFlexGridSizer(2, 1, 0, 0);
    TextCtrl1 = new wxTextCtrl(this, ID_TEXTCTRL1, wxEmptyString, wxDefaultPosition, wxSize(80,174), wxTE_MULTILINE, wxDefaultValidator, _T("ID_TEXTCTRL1"));
    FlexGridSizer2->Add(TextCtrl1, 1, wxALL|wxEXPAND|wxALIGN_TOP|wxALIGN_CENTER_HORIZONTAL, 5);
    BoxSizer1 = new wxBoxSizer(wxVERTICAL);
    Button1 = new wxButton(this, ID_BUTTON1, _("Test"), wxDefaultPosition, wxDefaultSize, 0, wxDefaultValidator, _T("ID_BUTTON1"));
    BoxSizer1->Add(Button1, 1, wxALL|wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL, 5);
    Button2 = new wxButton(this, ID_BUTTON2, _("Quit"), wxDefaultPosition, wxDefaultSize, 0, wxDefaultValidator, _T("ID_BUTTON2"));
    BoxSizer1->Add(Button2, 1, wxALL|wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL, 5);
    FlexGridSizer2->Add(BoxSizer1, 1, wxALL|wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL, 5);
    FlexGridSizer1->Add(FlexGridSizer2, 1, wxALL|wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL, 5);
    SetSizer(FlexGridSizer1);
    FlexGridSizer1->Fit(this);
    FlexGridSizer1->SetSizeHints(this);

    Connect(ID_BUTTON1,wxEVT_COMMAND_BUTTON_CLICKED,(wxObjectEventFunction)&testgrideditDialog::OnButton1Click);
    Connect(ID_BUTTON2,wxEVT_COMMAND_BUTTON_CLICKED,(wxObjectEventFunction)&testgrideditDialog::OnQuit);
    //*)

    wxGridCellAttr *myAttr = new wxGridCellAttr();
    fldedit = new wxGridCellChoiceEditor();
    myAttr->SetEditor(fldedit);
    Grid1->SetColAttr(0, myAttr);
    fldedit->SetParameters(_T("Fe,Fi,Fo,Fum"));
}

testgrideditDialog::~testgrideditDialog()
{
    //(*Destroy(testgrideditDialog)
    //*)
}

void testgrideditDialog::OnQuit(wxCommandEvent& event)
{
    Close();
}

void testgrideditDialog::OnButton1Click(wxCommandEvent& event)
{
    int nlines = TextCtrl1->GetNumberOfLines();
    wxString listoffields = TextCtrl1->GetLineText(0);
    for (int i = 1; i < nlines; i++)
        listoffields = listoffields + _T(",") + TextCtrl1->GetLineText(i);
    fldedit->SetParameters(listoffields);
}
