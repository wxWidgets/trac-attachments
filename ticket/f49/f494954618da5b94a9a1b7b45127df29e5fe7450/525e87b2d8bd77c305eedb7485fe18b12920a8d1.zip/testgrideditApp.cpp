#include "testgrideditApp.h"

//(*AppHeaders
#include "testgrideditMain.h"
#include <wx/image.h>
//*)

IMPLEMENT_APP(testgrideditApp);

bool testgrideditApp::OnInit()
{
    //(*AppInitialize
    bool wxsOK = true;
    wxInitAllImageHandlers();
    if ( wxsOK )
    {
    	testgrideditDialog Dlg(0);
    	SetTopWindow(&Dlg);
    	Dlg.ShowModal();
    	wxsOK = false;
    }
    //*)
    return wxsOK;

}
