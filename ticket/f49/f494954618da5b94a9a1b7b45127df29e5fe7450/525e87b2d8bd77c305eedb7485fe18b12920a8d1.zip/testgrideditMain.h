#ifndef TESTGRIDEDITMAIN_H
#define TESTGRIDEDITMAIN_H

//(*Headers(testgrideditDialog)
#include <wx/sizer.h>
#include <wx/textctrl.h>
#include <wx/grid.h>
#include <wx/button.h>
#include <wx/dialog.h>
//*)

class testgrideditDialog: public wxDialog
{
    public:

        testgrideditDialog(wxWindow* parent,wxWindowID id = -1);
        virtual ~testgrideditDialog();

        wxGridCellChoiceEditor *fldedit;

    private:

        //(*Handlers(testgrideditDialog)
        void OnQuit(wxCommandEvent& event);
        void OnButton1Click(wxCommandEvent& event);
        //*)

        //(*Identifiers(testgrideditDialog)
        static const long ID_GRID1;
        static const long ID_TEXTCTRL1;
        static const long ID_BUTTON1;
        static const long ID_BUTTON2;
        //*)

        //(*Declarations(testgrideditDialog)
        wxButton* Button1;
        wxGrid* Grid1;
        wxButton* Button2;
        wxTextCtrl* TextCtrl1;
        //*)

        DECLARE_EVENT_TABLE()
};

#endif // TESTGRIDEDITMAIN_H
