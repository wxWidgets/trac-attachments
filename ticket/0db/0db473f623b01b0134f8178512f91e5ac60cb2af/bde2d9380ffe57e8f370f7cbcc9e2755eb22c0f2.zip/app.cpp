#include <wx/wx.h>

class Frame : public wxFrame{
public:
	Frame::Frame(const wxString &, const wxPoint &, const wxSize &);
	void Quit(wxCloseEvent &event);

	DECLARE_EVENT_TABLE();
};

BEGIN_EVENT_TABLE(Frame,wxFrame)
	EVT_CLOSE(Frame::Quit)
END_EVENT_TABLE()

Frame::Frame(const wxString & a, const wxPoint & b, const wxSize &c) 
:wxFrame((wxWindow *)NULL,-1,a,b,c){	}

void Frame::Quit(wxCloseEvent &WXUNUSED(event)){ 
	
	int ret = wxMessageBox(_("Message"),_("Caption"),wxYES_NO|wxCANCEL);
	if(ret == wxYES)
	{ 
		wxMessageBox("YES");
	}
	else if( ret == wxCANCEL ) return;

	Close(true);

}

class App : public wxApp{

public: 
	virtual bool App::OnInit()
	{

		wxInitAllImageHandlers();
		Frame *pFrame = new Frame(wxT("My TestFrame"),wxDefaultPosition,wxSize(800,600));
		pFrame->Show(TRUE);
		SetTopWindow(pFrame);
		return TRUE;
	}
};

DECLARE_APP(App)
IMPLEMENT_APP(App)