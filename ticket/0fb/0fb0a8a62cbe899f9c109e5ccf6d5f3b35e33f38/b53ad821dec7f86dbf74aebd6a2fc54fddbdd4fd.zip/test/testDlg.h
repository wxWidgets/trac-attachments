#ifndef testDialog_H
#define testDialog_H

// Define a new Dialog type: this is going to be our main Dialog
class testDialog : public wxDialog
{
public:
    // ctor(s)
    testDialog(const wxString& title, const wxPoint& pos, const wxSize& size);
	virtual ~testDialog();

    // event handlers (these functions should _not_ be virtual)

private:
    DECLARE_CLASS(testDialog)
    // any class wishing to process wxWindows events must use this macro
    DECLARE_EVENT_TABLE()
};

#endif // testDialog_H
