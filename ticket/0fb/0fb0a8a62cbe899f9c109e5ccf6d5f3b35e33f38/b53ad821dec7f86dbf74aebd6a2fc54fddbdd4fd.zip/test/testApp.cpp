// ----------------------------------------------------------------------------
// headers
// ----------------------------------------------------------------------------
#include "wx/wxprec.h"

#ifndef WX_PRECOMP
	#include "wx/wx.h"
#endif
#include <wx/xrc/xmlres.h>

#include "testApp.h"
#include "testDlg.h"
#include "resource.h"

#include "wx/image.h"



// Create a new application object: this macro will allow wxWindows to create
// the application object during program execution (it's better than using a
// static object for many reasons) and also declares the accessor function
// wxGetApp() which will return the reference of the right type (i.e. testApp and
// not wxApp)
IMPLEMENT_APP(testApp)

// ============================================================================
// implementation
// ============================================================================

// ----------------------------------------------------------------------------
// the application class
// ----------------------------------------------------------------------------

testApp::testApp()
{
}

testApp::~testApp()
{
}

// 'Main program' equivalent: the program execution "starts" here
bool testApp::OnInit()
{
	::wxInitAllImageHandlers();
    wxXmlResource::Get()->InitAllHandlers(); 
    wxXmlResource::Get()->Load("resource/main_dialog.xrc");        

    // create the main application window
    testDialog *dialog = new testDialog(_("Application Title"),
                                 wxPoint(50, 50), wxSize(400, 300));

    // and show it (the frames, unlike simple controls, are not shown when
    // created initially)
    dialog->Show(TRUE);
	SetTopWindow(dialog);

    // success: wxApp::OnRun() will be called which will enter the main message
    // loop and the application will run. If we returned FALSE here, the
    // application would exit immediately.
    return TRUE;
}

