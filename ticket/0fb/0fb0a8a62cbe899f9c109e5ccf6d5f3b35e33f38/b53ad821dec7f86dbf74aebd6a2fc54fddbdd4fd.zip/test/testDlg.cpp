// ----------------------------------------------------------------------------
// headers
// ----------------------------------------------------------------------------
#include "wx/wxprec.h"

#ifndef WX_PRECOMP
	#include "wx/wx.h"
#endif
#include <wx/xrc/xmlres.h>

#include "testApp.h"
#include "testDlg.h"

// ----------------------------------------------------------------------------
// resources
// ----------------------------------------------------------------------------
// the application icon
#if defined(__WXGTK__) || defined(__WXMOTIF__)
    #include "test.xpm"
#endif

// ----------------------------------------------------------------------------
// constants
// ----------------------------------------------------------------------------


// ----------------------------------------------------------------------------
// event tables and other macros for wxWindows
// ----------------------------------------------------------------------------

// the event tables connect the wxWindows events with the functions (event
// handlers) which process them. It can be also done at run-time, but for the
// simple menu events like this the static method is much simpler.
IMPLEMENT_CLASS(testDialog, wxDialog)
BEGIN_EVENT_TABLE(testDialog, wxDialog)

END_EVENT_TABLE()

// ----------------------------------------------------------------------------
// main Dialog
// ----------------------------------------------------------------------------

// Dialog constructor
testDialog::testDialog(const wxString& title, const wxPoint& pos, const wxSize& size)
{
    wxXmlResource::Get()->LoadDialog(this, NULL, "main_dialog");
    SetTitle(title);

    // set the Dialog icon
    SetIcon(wxICON(test));
}

// Dialog destructor
testDialog::~testDialog()
{
}

// event handlers
