/***************************************************************
 * Name:      reorder_tab_traversalApp.h
 * Purpose:   Defines Application Class
 * Author:     ()
 * Created:   2014-02-27
 * Copyright:  ()
 * License:
 **************************************************************/

#ifndef REORDER_TAB_TRAVERSALAPP_H
#define REORDER_TAB_TRAVERSALAPP_H

#include <wx/app.h>

class reorder_tab_traversalApp : public wxApp
{
    public:
        virtual bool OnInit();
};

#endif // REORDER_TAB_TRAVERSALAPP_H
