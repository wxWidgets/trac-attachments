/***************************************************************
 * Name:      reorder_tab_traversalApp.cpp
 * Purpose:   Code for Application Class
 * Author:     ()
 * Created:   2014-02-27
 * Copyright:  ()
 * License:
 **************************************************************/

#include "reorder_tab_traversalApp.h"

//(*AppHeaders
#include "reorder_tab_traversalMain.h"
#include <wx/image.h>
//*)

IMPLEMENT_APP(reorder_tab_traversalApp);

bool reorder_tab_traversalApp::OnInit()
{
    //(*AppInitialize
    bool wxsOK = true;
    wxInitAllImageHandlers();
    if ( wxsOK )
    {
    	reorder_tab_traversalFrame* Frame = new reorder_tab_traversalFrame(0);
    	Frame->Show();
    	SetTopWindow(Frame);
    }
    //*)
    return wxsOK;

}
