/***************************************************************
 * Name:      reorder_tab_traversalMain.cpp
 * Purpose:   Code for Application Frame
 * Author:     ()
 * Created:   2014-02-27
 * Copyright:  ()
 * License:
 **************************************************************/

#include "reorder_tab_traversalMain.h"
#include <wx/msgdlg.h>

//(*InternalHeaders(reorder_tab_traversalFrame)
#include <wx/string.h>
#include <wx/intl.h>
//*)

//(*IdInit(reorder_tab_traversalFrame)
const long reorder_tab_traversalFrame::ID_TEXTCTRL1 = wxNewId();
const long reorder_tab_traversalFrame::ID_TEXTCTRL2 = wxNewId();
const long reorder_tab_traversalFrame::ID_TEXTCTRL3 = wxNewId();
const long reorder_tab_traversalFrame::ID_PANEL1 = wxNewId();
const long reorder_tab_traversalFrame::ID_BUTTON1 = wxNewId();
//*)

BEGIN_EVENT_TABLE(reorder_tab_traversalFrame,wxFrame)
    //(*EventTable(reorder_tab_traversalFrame)
    //*)
END_EVENT_TABLE()

reorder_tab_traversalFrame::reorder_tab_traversalFrame(wxWindow* parent,wxWindowID id)
{
    //(*Initialize(reorder_tab_traversalFrame)
    wxBoxSizer* BoxSizer2;
    wxBoxSizer* BoxSizer1;

    Create(parent, id, wxEmptyString, wxDefaultPosition, wxDefaultSize, wxDEFAULT_FRAME_STYLE, _T("id"));
    BoxSizer1 = new wxBoxSizer(wxVERTICAL);
    Panel1 = new wxPanel(this, ID_PANEL1, wxDefaultPosition, wxDefaultSize, wxTAB_TRAVERSAL, _T("ID_PANEL1"));
    BoxSizer2 = new wxBoxSizer(wxHORIZONTAL);
    text1 = new wxTextCtrl(Panel1, ID_TEXTCTRL1, _("text1"), wxDefaultPosition, wxDefaultSize, 0, wxDefaultValidator, _T("ID_TEXTCTRL1"));
    BoxSizer2->Add(text1, 1, wxALL|wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL, 5);
    text2 = new wxTextCtrl(Panel1, ID_TEXTCTRL2, _("text2"), wxDefaultPosition, wxDefaultSize, 0, wxDefaultValidator, _T("ID_TEXTCTRL2"));
    BoxSizer2->Add(text2, 1, wxALL|wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL, 5);
    text3 = new wxTextCtrl(Panel1, ID_TEXTCTRL3, _("text3"), wxDefaultPosition, wxDefaultSize, 0, wxDefaultValidator, _T("ID_TEXTCTRL3"));
    BoxSizer2->Add(text3, 1, wxALL|wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL, 5);
    Panel1->SetSizer(BoxSizer2);
    BoxSizer2->Fit(Panel1);
    BoxSizer2->SetSizeHints(Panel1);
    BoxSizer1->Add(Panel1, 1, wxALL|wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL, 5);
    buttonReorder = new wxButton(this, ID_BUTTON1, _("Reorder"), wxDefaultPosition, wxDefaultSize, 0, wxDefaultValidator, _T("ID_BUTTON1"));
    buttonReorder->SetDefault();
    BoxSizer1->Add(buttonReorder, 0, wxALL|wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL, 5);
    SetSizer(BoxSizer1);
    BoxSizer1->Fit(this);
    BoxSizer1->SetSizeHints(this);

    Connect(ID_BUTTON1,wxEVT_COMMAND_BUTTON_CLICKED,(wxObjectEventFunction)&reorder_tab_traversalFrame::OnbuttonReorderClick);
    //*)
}

reorder_tab_traversalFrame::~reorder_tab_traversalFrame()
{
    //(*Destroy(reorder_tab_traversalFrame)
    //*)
}

void reorder_tab_traversalFrame::OnbuttonReorderClick(wxCommandEvent& event)
{
  // note: relevant part
  text2->MoveAfterInTabOrder(text3);
}
