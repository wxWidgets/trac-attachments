/***************************************************************
 * Name:      reorder_tab_traversalMain.h
 * Purpose:   Defines Application Frame
 * Author:     ()
 * Created:   2014-02-27
 * Copyright:  ()
 * License:
 **************************************************************/

#ifndef REORDER_TAB_TRAVERSALMAIN_H
#define REORDER_TAB_TRAVERSALMAIN_H

//(*Headers(reorder_tab_traversalFrame)
#include <wx/sizer.h>
#include <wx/button.h>
#include <wx/panel.h>
#include <wx/frame.h>
#include <wx/textctrl.h>
//*)

class reorder_tab_traversalFrame: public wxFrame
{
    public:

        reorder_tab_traversalFrame(wxWindow* parent,wxWindowID id = -1);
        virtual ~reorder_tab_traversalFrame();

    private:

        //(*Handlers(reorder_tab_traversalFrame)
        void OnQuit(wxCommandEvent& event);
        void OnAbout(wxCommandEvent& event);
        void OnbuttonReorderClick(wxCommandEvent& event);
        //*)

        //(*Identifiers(reorder_tab_traversalFrame)
        static const long ID_TEXTCTRL1;
        static const long ID_TEXTCTRL2;
        static const long ID_TEXTCTRL3;
        static const long ID_PANEL1;
        static const long ID_BUTTON1;
        //*)

        //(*Declarations(reorder_tab_traversalFrame)
        wxPanel* Panel1;
        wxButton* buttonReorder;
        wxTextCtrl* text1;
        wxTextCtrl* text3;
        wxTextCtrl* text2;
        //*)

        DECLARE_EVENT_TABLE()
};

#endif // REORDER_TAB_TRAVERSALMAIN_H
