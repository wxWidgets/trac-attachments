#Boa:Frame:Frame1

import wx

def create(parent):
    return Frame1(parent)

[wxID_FRAME1, wxID_FRAME1LISTCTRL1, 
] = [wx.NewId() for _init_ctrls in range(2)]

class Frame1(wx.Frame):
    def _init_coll_listCtrl1_Columns(self, parent):
        # generated method, don't edit

        parent.InsertColumn(col=0, format=wx.LIST_FORMAT_LEFT,
              heading='Columns0', width=-1)
        parent.InsertColumn(col=1, format=wx.LIST_FORMAT_LEFT,
              heading='Columns1', width=-1)
        parent.InsertColumn(col=2, format=wx.LIST_FORMAT_LEFT,
              heading='Columns2', width=-1)

    def _init_ctrls(self, prnt):
        # generated method, don't edit
        wx.Frame.__init__(self, id=wxID_FRAME1, name='', parent=prnt,
              pos=wx.Point(278, 121), size=wx.Size(400, 489),
              style=wx.DEFAULT_FRAME_STYLE, title='Frame1')
        self.SetClientSize(wx.Size(392, 455))

        self.listCtrl1 = wx.ListCtrl(id=wxID_FRAME1LISTCTRL1, name='listCtrl1',
              parent=self, pos=wx.Point(0, 0), size=wx.Size(392, 455),
              style=wx.LC_REPORT)
        self._init_coll_listCtrl1_Columns(self.listCtrl1)

    def __init__(self, parent):
        self._init_ctrls(parent)
        self.listCtrl1.InsertStringItem(0,'first')
        self.listCtrl1.SetStringItem(0,1,'column')
        self.listCtrl1.SetStringItem(0,2,'last')
        self.listCtrl1.InsertStringItem(1,'second')
        self.listCtrl1.SetStringItem(1,1,'name is longer')
        self.listCtrl1.SetStringItem(1,2,'again')
        self.listCtrl1.SetColumnWidth(0,wx.LIST_AUTOSIZE)
        self.listCtrl1.SetColumnWidth(1,wx.LIST_AUTOSIZE)
        self.listCtrl1.SetColumnWidth(2,wx.LIST_AUTOSIZE)
        
