#include "WndMain.h"
#include "wxGridCellExpandRenderer.h"

BEGIN_EVENT_TABLE(WndMain,wxFrame)
  EVT_GRID_CELL_LEFT_CLICK(WndMain::OnGridCellLeftClick)
END_EVENT_TABLE()

WndMain::WndMain(wxWindow *parent)
{
  Create(parent,wxID_ANY,L"wxTreeGrid",wxDefaultPosition,wxSize(800,500));
  CreateControls();
}

WndMain::~WndMain(void)
{
}

void WndMain::CreateControls()
{
	this->SetSizeHints( wxDefaultSize, wxDefaultSize );
	
	wxBoxSizer* mMS = new wxBoxSizer( wxVERTICAL );
	
	mGrid = new wxGrid( this, wxID_ANY, wxDefaultPosition, wxDefaultSize, 0 );
  mGrid->CreateGrid(0, 5 ,wxGrid::wxGridSelectRows );
	mGrid->EnableEditing( false );
	mGrid->EnableGridLines( true );
	mGrid->EnableDragGridSize( true );
	mGrid->SetMargins( 0, 0 );
	mGrid->EnableDragColMove( false );
	mGrid->EnableDragColSize( true );
	mGrid->SetColLabelSize( 30 );
	mGrid->SetColLabelAlignment( wxALIGN_CENTRE, wxALIGN_CENTRE );
  //mGrid->AutoSizeRows();
	mGrid->EnableDragRowSize( false );
	mGrid->SetRowLabelSize( 80 );
	mGrid->SetRowLabelAlignment( wxALIGN_CENTRE, wxALIGN_CENTRE );
	mGrid->SetDefaultCellAlignment( wxALIGN_LEFT, wxALIGN_TOP );
	mMS->Add( mGrid, 1, wxALL|wxEXPAND, 5 );

  mGrid->AppendRows(50);

  // Renderers
  for(int i=0; i<mGrid->GetRows(); ++i)
  {
    if(i%4 == 0)
    {
      mGrid->SetCellRenderer(i,0,new wxGridCellExpandRenderer());
      mGrid->SetCellValue(i,0,L"1");
      wxGridCellAttr *attr=new wxGridCellAttr();
      attr->SetBackgroundColour(wxColor(0xc0c0c0));
      mGrid->SetRowAttr(i,attr);
    }
    else
    {
      mGrid->HideRow(i);
    }
  }

  mGrid->SetColumnWidth(0,15);

	this->SetSizer( mMS );
	this->Layout();
	
	this->Centre( wxBOTH );
}

void WndMain::OnGridCellLeftClick(wxGridEvent &e)
{
  if(e.GetCol()!=0) e.Skip();
  else
  {
    wxString top=mGrid->GetCellValue(e.GetRow(),e.GetCol());
    if(top!=L"1")
      return;
  
    for(int i=e.GetRow()+1; i<mGrid->GetRows(); ++i)
    {
      if(top==mGrid->GetCellValue(i,e.GetCol()))
        break;

      bool visible=mGrid->IsRowShown(i);
      if(visible)
        mGrid->HideRow(i);
      else
      {
        mGrid->ShowRow(i);
        mGrid->AutoSizeRow(i);
      }
    }
  }
}
