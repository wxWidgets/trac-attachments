#include "wxGridCellExpandRenderer.h"
#include <wx/renderer.h>

void wxGridCellExpandRenderer::Draw(
  wxGrid &grid,
  wxGridCellAttr &attr,
  wxDC &dc,
  const wxRect &rect,
  int row,int col,
  bool isSelected)
{
  wxGridCellRenderer::Draw(grid,attr,dc,rect,row,col,isSelected);

  int flag=0;
  if(row+1<grid.GetRows() && grid.IsRowShown(row+1))
    flag=wxCONTROL_EXPANDED;

  wxRendererNative &renderer=wxRendererNative::Get();

  renderer.DrawTreeItemButton(&grid,dc,rect,flag);
}

wxSize wxGridCellExpandRenderer::GetBestSize(
  wxGrid &grid,
  wxGridCellAttr &attr,
  wxDC &dc,
  int row,int col)
{
  return wxSize(9,9);
}
