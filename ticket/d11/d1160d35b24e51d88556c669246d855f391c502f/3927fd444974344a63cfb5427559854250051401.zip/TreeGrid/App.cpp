#include "App.h"
#include "WndMain.h"

IMPLEMENT_APP(App);

WndMain *wndMain;

bool App::OnInit()
{
  if(!wxApp::OnInit())
    return false;

  wndMain=new WndMain(NULL);
  wndMain->Show();

  return true;
}

int App::OnExit()
{
  return wxApp::OnExit();
}