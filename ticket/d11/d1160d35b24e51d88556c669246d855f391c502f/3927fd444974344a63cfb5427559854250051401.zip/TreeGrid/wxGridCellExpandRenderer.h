#pragma once

#include <wx/wx.h>
#include <wx/grid.h>

class wxGridCellExpandRenderer : public wxGridCellRenderer
{
public:
  wxGridCellExpandRenderer() {}
  ~wxGridCellExpandRenderer() {}

  virtual void Draw(
    wxGrid &grid,
    wxGridCellAttr &attr,
    wxDC &dc,
    const wxRect &rect,
    int row,int col,
    bool isSelected);

  virtual wxSize GetBestSize(
    wxGrid &grid,
    wxGridCellAttr &attr,
    wxDC &dc,
    int row,int col);

  virtual wxGridCellRenderer *Clone() const
  {
    return new wxGridCellExpandRenderer();
  }
};

