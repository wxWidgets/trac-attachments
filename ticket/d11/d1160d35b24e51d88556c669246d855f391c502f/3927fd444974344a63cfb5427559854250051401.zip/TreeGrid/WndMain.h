#pragma once

#include <wx/wx.h>
#include <wx/grid.h>

class WndMain : public wxFrame
{
private:
  wxGrid *mGrid;

public:
  WndMain(wxWindow *parent);
  ~WndMain();

private:
  void CreateControls();

  DECLARE_EVENT_TABLE();
  void OnGridCellLeftClick(wxGridEvent &e);
};

