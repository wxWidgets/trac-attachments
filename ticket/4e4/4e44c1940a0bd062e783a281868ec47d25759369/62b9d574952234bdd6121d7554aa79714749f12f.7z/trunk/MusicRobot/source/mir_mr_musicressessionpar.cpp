

#include <string>

#include "mir_mr_musicressessionpar.h"

namespace SyNaT
{
  namespace MIR 
  {
    namespace MR 
    {

      using namespace std;
      MusicResSessionPar::MusicResSessionPar() 
      {
      }

      MusicResSessionPar::MusicResSessionPar(const string &musicResource, const string &sessionParam) 
        : m_musicResource(musicResource), m_sessionParam(sessionParam)
      {
      }

      string &MusicResSessionPar::getMusicResource()
      {
        return this->m_musicResource;
      }

      string &MusicResSessionPar::getSessionParam()
      {
        return this->m_sessionParam;
      }

      void     MusicResSessionPar::setMusicResource(const string &musicResource)
      {
        this->m_musicResource = musicResource;
      }

      void     MusicResSessionPar::setSessionParam(const string &sessionParam)
      {
        this->m_sessionParam = sessionParam;
      }

      string  &MusicResSessionPar::getTableName()
      {
        return this->m_tableName;
      }

      string  &MusicResSessionPar::getTablePrefix()
      {
        return this->m_tablePrefix;
      }

      void     MusicResSessionPar::setTableName(const string &tableName)
      {
        this->m_tableName = tableName;
      }

      void     MusicResSessionPar::setTablePrefix(const string &tablePrefix)
      {
        this->m_tablePrefix = tablePrefix;
      }
    }
  }
}
