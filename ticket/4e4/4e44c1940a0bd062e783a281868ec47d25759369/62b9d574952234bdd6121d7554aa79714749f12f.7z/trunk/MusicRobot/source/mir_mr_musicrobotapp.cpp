#include <Wt/WApplication>
#include <Wt/WText>
#include <Wt/WProgressBar>
#include <Wt/WPushButton>
#include <Wt/WTimer>
#include <Wt/WTextArea>
#include <Wt/WAnchor>
#include <Wt/WMessageBox>
#include <Wt/WLabel>
#include <Wt/WContainerWidget>
#include <Wt/WLogger>
#include <Wt/WWidget>
#include <Wt/WEnvironment>

// For compilers that support precompilation, includes "wx/wx.h".
#include <wx/wxprec.h>

#ifdef __BORLANDC__
    #pragma hdrstop
#endif

// for all others, include the necessary headers (this file is usually all you
// need because it includes almost all "standard" wxWidgets headers
#ifndef WX_PRECOMP
    #include "wx/wx.h"
#endif

#include <wx/filename.h>
#include <wx/utils.h>
#include <wx/platinfo.h>
#include <wx/strconv.h>

#include <boost/foreach.hpp>
#include <boost/regex.hpp>
#include <boost/ptr_container/ptr_vector.hpp>
#include <boost/ptr_container/ptr_map.hpp>
#include <boost/thread/mutex.hpp>

#include "mir_defines.h"
#include "mir_stringutils.h"
#include "mir_exceptions.h"
#include "mir_databasetypes.h"
#include "mir_databasemodule.h"
#include "mir_utils.h"
#include "mir_mr_musicrobotapp.h"
#include "mir_mr_downloadedmusicfilespage.h"
#include "mir_mr_loginpage.h"
#include "mir_mr_mainpage.h"
#include "mir_mr_musicfilepage.h"
#include "mir_mr_settingspage.h"
#include "mir_mr_statuspage.h"

#include <ibpp.h>

namespace SyNaT
{
  namespace MIR 
  {
    namespace MR 
    {

      using namespace std;
      using namespace Wt;

      /**
       * Przyjmuje że parametr path jest escape'owany z kodowania UTF-8. Path składa się ze ścieżki, parametrów i ich wartości np.
       * sciezka_escapeowana_ze_stringa_w_utf8/parametr_1_escapowany_ze_string_utf8/wartosci_parametru_1_escapowana_ze_stringa_w_utf8
       * /parametr_2_escapowany_ze_string_utf8/wartosci_parametru_2_escapowana_ze_stringa_w_utf8
       */
      void MusicRobotApp::m_slt_internalPathChanged(const string &path)
      {
        Utils::ptr_map_string_wxString ptr_map_params;
        wxCSConv wxCharSetUTF8Conv(wxFONTENCODING_UTF8);
        wxString wxpath = Utils::buildParameterMapFromPath(path, ptr_map_params, wxCharSetUTF8Conv);


        if (wxpath.CmpNoCase(wxString("start", wxCharSetUTF8Conv)) == 0) 
        {
          
          this->m_mp.mainPage();
        
        } 
        else if (wxpath.CmpNoCase(wxString("dwnlStatus", wxCharSetUTF8Conv)) == 0)
        {
          
          this->m_ssp.statusPage();

        } 
        else if (wxpath.CmpNoCase(wxString("dwnlSettings", wxCharSetUTF8Conv)) == 0)
        {
          
          this->m_sp.settingsPage();

        }
        else if (wxpath.CmpNoCase(wxString("dwnlMusicFiles", wxCharSetUTF8Conv)) == 0) 
        {

          this->m_dmf.dwnlMusicFiles(ptr_map_params);
        
        }
        else if (wxpath.CmpNoCase(wxString("musicFile", wxCharSetUTF8Conv)) == 0) 
        {

          this->m_mfp.musicFile(ptr_map_params);
        
        }
        else if (wxpath.CmpNoCase(wxString("login", wxCharSetUTF8Conv)) == 0) 
        {
          
          this->m_lp.loginPage();

        } 
        else if (wxpath.CmpNoCase(wxString("logout", wxCharSetUTF8Conv)) == 0) 
        {
          this->changeStateOfMusicRobot(false);
          this->isMusicRobotWorking = false;
          this->m_login.clear();
          this->m_name.clear();
          this->m_surname.clear();
          this->m_hashpassword.clear();
          this->setInternalPath("/login", true);
        }
      }


      void MusicRobotApp::m_slt_wtimerTimeout()
      {
        int  buttonsStartStopEnabled = false;
        bool downThreadsRecreate = false;
        bool allStopped = true;
        if (this->m_wxdt.size() > 0)
        {
          for(size_t i=0; i < this->m_wxdt.size(); i++)
          {
            boost::lock_guard<boost::mutex> lock(this->m_wxdt.at(i).m_downloadthread_m_stopDownloading_mutex);

            if (!this->m_wxdt.at(i).m_stopDownloading)
            {
              allStopped = false;
              break;
            }
          }
          
          if (allStopped)
          {
            this->m_stopDownloading = true;
            downThreadsRecreate = true;
          }
          
          for(size_t i=0; i < this->m_ssp.m_wpbr.size(); i++)
          {
            if (this->m_stopDownloading) 
            {
              if (this->m_ssp.m_wpbr.at(i).value()!=0)
                this->m_ssp.m_wpbr.at(i).setValue(0);
              if (this->m_ssp.m_wpbStart && this->m_ssp.m_wpbStart->isDisabled())
                this->m_ssp.m_wpbStart->enable();
              if (this->m_ssp.m_wpbStop && this->m_ssp.m_wpbStop->isDisabled())
                this->m_ssp.m_wpbStop->enable();
              buttonsStartStopEnabled = true;

              if (!downThreadsRecreate)
                downThreadsRecreate = true;
            }      
          } 

          for(size_t i=0; i < this->m_wxdt.size(); i++)
          {
            if (!this->m_stopDownloading)
            {

              if (i < this->m_ssp.m_wpbr.size())
              {
                boost::lock_guard<boost::mutex> lock(this->m_wxdt.at(i).m_downloadthread_m_progressPercent_mutex);
                this->m_ssp.m_wpbr.at(i).setValue(this->m_wxdt.at(i).m_progressPercent);
              }
              {
                boost::lock_guard<boost::mutex> lock(this->m_wxdt.at(i).m_downloadthread_m_wxuri_mutex);

                if (this->m_wxdt.at(i).m_wxuri)
                {
                  if (i < this->m_ssp.m_wpbrTxt.size())
                    this->m_ssp.m_wpbrTxt.at(i).setText(wx2wts(/*wxURI::Unescape(*/this->m_wxdt.at(i).m_wxuri->BuildUnescapedURI()/*)*/));
                } else 
                {
                  if (i < this->m_wxServer.size())
                    this->m_ssp.m_wpbrTxt.at(i).setText(WString(this->m_wxServer.at(i).getMusicResource(), UTF8));
                }
              }
            } 
            else
            {
              if (i < this->m_ssp.m_wpbr.size())
                this->m_ssp.m_wpbr.at(i).setValue(0);
              if ((i < this->m_ssp.m_wpbrTxt.size()) && (i < this->m_wxServer.size()))
                this->m_ssp.m_wpbrTxt.at(i).setText(WString(this->m_wxServer.at(i).getMusicResource(), UTF8));
            }
          }
        }

        if(downThreadsRecreate || this->m_stopDownloading)
        {
          //wxCriticalSectionLocker wxcsl(MusicRobotApp::ms_downloadthread_m_wxuri_crit_sect);

          //DownloadThreadsRecreate();
        }

        if(this->m_stopDownloading && buttonsStartStopEnabled)
        {
          this->m_wtimer->stop();
        }
      }

      bool MusicRobotApp::stateOfMusicRobot()
      {
        bool trawersuje = true;

        try {
          this->m_tr->Start();
          string sql("SELECT SMR_TRAWERSUJE FROM MIR_STAN_MUZYCZNEGO_ROBOTA");
          Statement stmt = this->m_dm.createStatement(&this->m_tr, &sql);
          stmt->Execute();
          if (stmt->Fetch())
          {
            stmt->Get(1, trawersuje);
          }
          this->m_tr->Commit();
        }
        catch(IBPP::Exception &)
        {
        }
        
        return trawersuje;      
      }

      void MusicRobotApp::changeStateOfMusicRobot(bool working)
      {
        Transaction tr;
        try 
        {
          tr = this->m_dm.createTransaction(amWrite, ilReadCommitted, lrWait);
          boost::ptr_vector<DBField> fields;
          fields.push_back(new BoolDBField(working, "SMR_TRAWERSUJE"));
          tr->Start();
          this->m_dm.updateTable(1, "SMR", "MIR_STAN_MUZYCZNEGO_ROBOTA", fields, &tr);
          tr->Commit();
        } catch(IBPP::Exception &e)
        {
          wApp->log("error") << e.Origin() << " " << e.what();
        }
      }

      MusicRobotApp::ptr_map_string_string MusicRobotApp::fillMimeTypes()
      {
        MusicRobotApp::ptr_map_string_string mime;

        mime["AUDIO/BASIC"]= *new string("snd,au");
        mime["AUDIO/MID"] =*new string("mid,rmi");
        mime["AUDIO/MPEG"]= *new string("mp3,mp2,mp1");
        mime["AUDIO/MP4"]= *new string("mp4a");
        mime["AUDIO/OGG"]= *new string("oga,ogg,spx");
        mime["AUDIO/VORBIS"]= *new string("oga,ogg,spx");
        mime["AUDIO/X-MS-WMA"]= *new string("wma");
        mime["AUDIO/X-MS-WAX"]= *new string("wax");
        mime["AUDIO/X-MS-WMV"]= *new string("wmv");
        mime["AUDIO/X-MATROSKA"]= *new string("mka");
        mime["AUDIO/VND.RN-REALAUDIO"]= *new string("ra,ram");
        mime["AUDIO/X-PN-REALAUDIO"]= *new string("ra,ram");
        mime["AUDIO/VND.WAVE"]= *new string("wav");
        mime["AUDIO/WAV"]= *new string("wav");
        mime["AUDIO/WAVE"]= *new string("wav");
        mime["AUDIO/X-WAV"]= *new string("wav");

        mime["AUDIO/X-MPEGURL"] = *new string("m3u");
        mime["APPLICATION/VND.APPLE.MPEGURL"] = *new string("m3u8");

        mime["IMAGE/BMP"] = *new string("bmp");
        mime["IMAGE/CGM"] = *new string("cgm");
        mime["IMAGE/G3FAX"] = *new string("g3");
        mime["IMAGE/GIF"] = *new string("gif");
        mime["IMAGE/IEF"] = *new string("ief");
        mime["IMAGE/JP2"] = *new string("jp2");
        mime["IMAGE/JPEG"] = *new string("jpeg");
        mime["IMAGE/PNG"] = *new string("png");
        mime["IMAGE/PRS.BTIF"] = *new string("btif");
        mime["IMAGE/SVG+XML"] = *new string("svg,svgz");
        mime["IMAGE/TIFF"] = *new string("tiff,tif");
        mime["IMAGE/VND.ADOBE.PHOTOSHOP"] = *new string("psd");
        mime["IMAGE/VND.DJVU"] = *new string("djvu,djv");
        mime["IMAGE/VND.DWG"] = *new string("dwg");
        mime["IMAGE/VND.DXF"] = *new string("dxf");
        mime["IMAGE/VND.FASTBIDSHEET"] = *new string("fbs");
        mime["IMAGE/VND.FPX"] = *new string("fpx");
        mime["IMAGE/VND.FST"] = *new string("fst");
        mime["IMAGE/VND.FUJIXEROX.EDMICS-MMR"] = *new string("mmr");
        mime["IMAGE/VND.FUJIXEROX.EDMICS-RLC"] = *new string("rlc");
        mime["IMAGE/VND.MS-MODI"] = *new string("mdi");
        mime["IMAGE/VND.NET-FPX"] = *new string("npx");
        mime["IMAGE/VND.WAP.WBMP"] = *new string("wbmp");
        mime["IMAGE/VND.XIFF"] = *new string("xif");
        mime["IMAGE/X-CMU-RASTER"] = *new string("ras");
        mime["IMAGE/X-CMX"] = *new string("cmx");
        mime["IMAGE/X-FREEHAND"] = *new string("fh,fhc,fh4,fh5,fh7");
        mime["IMAGE/X-ICON"] = *new string("ico");
        mime["IMAGE/X-PCX"] = *new string("pcx");
        mime["IMAGE/X-PICT"] = *new string("pic,pct");
        mime["IMAGE/X-PORTABLE-ANYMAP"] = *new string("pnm");
        mime["IMAGE/X-PORTABLE-BITMAP"] = *new string("pbm");
        mime["IMAGE/X-PORTABLE-GRAYMAP"] = *new string("pgm");
        mime["IMAGE/X-PORTABLE-PIXMAP"] = *new string("ppm");
        mime["IMAGE/X-RGB"] = *new string("rgb");
        mime["IMAGE/X-XBITMAP"] = *new string("xbm");
        mime["IMAGE/X-XPIXMAP"] = *new string("xpm");
        mime["IMAGE/X-XWINDOWDUMP"] = *new string("xwd");

        mime["TEXT/CSS"] = *new string("css");

        mime["TEXT/JAVASCRIPT"] = *new string("js");
        mime["APPLICATION/X-JAVASCRIPT"] = *new string("js");
        mime["APPLICATION/JAVASCRIPT"] = *new string("js");
        mime["TEXT/ECMASCRIPT"] = *new string("js");
        mime["APPLICATION/ECMASCRIPT"] = *new string("js");
        mime["TEXT/JSCRIPT"] = *new string("js");
        mime["TEXT/VBSCRIPT"] = *new string("js");

        mime["TEXT/HTML"]= *new string("html,htm,*");
        mime["TEXT/XML"]= *new string("xml,xhtm,xhtml,*");
        mime["APPLICATION/XHTML+XML"]= *new string("xml,xhtm,xhtml");
        mime["APPLICATION/XML"]= *new string("xml,xhtm,xhtml");
        mime["TEXT/PLAIN"]= *new string("txt,*");

        return mime;
      }

      MusicRobotApp::MusicRobotApp(const WEnvironment& env)
        : WApplication(env), m_dmf(this), m_mfp(this), m_lp(this)
         , m_mp(this), m_sp(this), m_ssp(this)
      {
        wxCSConv wxCSUTF8(wxFONTENCODING_UTF8);

        this->setFieldsToNull(false);

        this->m_stopDownloading = true;

        this->setTitle("SyNaT - Muzyczny Robot");

        wxFileName fncwd;
        {
          boost::lock_guard<boost::mutex> lock(DownloadThread::ms_downloadthread_wxWidgetsFuncs_mutex);

          fncwd.Assign(wxFileName::GetCwd());
        }

        wxString volPostfix;
        if (this->mcs_wxosid & wxOS_WINDOWS)
          volPostfix = wxT(":");

        wxFileName fname(fncwd.GetVolume() + volPostfix + fncwd.GetVolumeSeparator(wxPATH_UNIX) + wxT(MIR_PATH_TO_DB_DIR) + wxT("MDB.FDB"), wxPATH_UNIX);
        fname.Normalize(wxPATH_NORM_LONG|wxPATH_NORM_DOTS|wxPATH_NORM_TILDE|wxPATH_NORM_ABSOLUTE);

        this->m_dm.connect("localhost", wx2std(fname.GetFullPath(), &wxCSUTF8),
           "SYSDBA", "masterkey", "",
           "UTF8", "", "admin", "admin", false);
        
        this->m_tr = this->m_dm.createTransaction(amRead, ilReadCommitted, lrWait);

        this->isMusicRobotWorking = false;
        if (this->stateOfMusicRobot())
        {
		      new WText("Muzyczny robot aktualnie pracuje", this->root());
		      return;
        }

        this->setFieldsToNull(false);
        
        this->m_wtimer = new WTimer((WObject *) this->root());
        this->m_wtimer->setInterval(5000); // co 5 sekundy
        this->m_wtimer->timeout().connect(this, &MusicRobotApp::m_slt_wtimerTimeout);

        this->internalPathChanged().connect(this, &MusicRobotApp::m_slt_internalPathChanged);

        this->setInternalPath("");
        this->setInternalPath("/login", true);
      }

      MusicRobotApp::~MusicRobotApp()
      {
        this->destroyAllWidgets(); //ptr_vector will delete it in his destructor

        if (this->m_wtimer)
          this->m_wtimer->stop();
        this->m_stopDownloading = true;
        for(size_t i = 0; i < this->m_wxdt.size(); i++)
        {
          {
            boost::lock_guard<boost::mutex> lock(this->m_wxdt.at(i).m_downloadthread_m_stopDownloading_mutex);
            this->m_wxdt.at(i).m_stopDownloading = true;
          }
          this->m_thread_group.join_all();
        }

        if (this->isMusicRobotWorking)
          this->changeStateOfMusicRobot(false);
      }

      void MusicRobotApp::setFieldsToNull(bool nest)
      {
        if (nest)
        {
          this->m_wxdt.resize(0);
          this->m_ssp.m_wpbr.resize(0);
          this->m_ssp.m_wpbrTxt.resize(0);
          this->m_wxServer.resize(0);
        }
        this->m_lp.m_wleLogin = NULL;
        this->m_lp.m_wlePassword = NULL;
        this->m_ssp.m_wpbStart = NULL;
        this->m_ssp.m_wpbStop = NULL;
        this->m_wtimer = NULL;
      }

      void MusicRobotApp::removeAllWidgets()
      {
        WContainerWidget *wcw = this->root();

        for(int i = 0, count = wcw->count(); i < count ; i++)
        {
          wcw->removeWidget(wcw->widget(0));
        }
      }
      
      void MusicRobotApp::destroyAllWidgets()
      {
        this->m_sp.destroyAllWidgets();

        this->m_ssp.destroyAllWidgets();

        this->root()->clear();
        this->m_ssp.m_wpbStart = NULL;
        this->m_ssp.m_wpbStop = NULL;
      }

      void MusicRobotApp::hideAllFields()
      {
        WContainerWidget *wcw = this->root();
        for(int i = 0; i < wcw->count(); i++)
        {
          wcw->widget(i)->hide();
        }
      }

      void MusicRobotApp::copyLoginInfo(DownloadThread &dt)
      {
        dt.m_charSet = this->m_charSet;
        dt.m_databaseName = this->m_databaseName;
        dt.m_hashpassword = this->m_hashpassword;
        dt.m_login = this->m_login;
        dt.m_name = this->m_name;
        dt.m_roleName = this->m_roleName;
        dt.m_serverName = this->m_serverName;
        dt.m_surname = this->m_surname;
        dt.m_userName = this->m_userName;
        dt.m_userPassword = this->m_userPassword;
      }

      void MusicRobotApp::waitForThreads()
      {
        {
          for(size_t i = 0; i < this->m_wxdt.size(); i++)
          {
          	boost::lock_guard<boost::mutex> lock(this->m_wxdt.at(i).m_downloadthread_m_stopDownloading_mutex);
          	boost::lock_guard<boost::mutex> lock2(this->m_wxdt.at(i).m_downloadthread_m_progressPercent_mutex);

            this->m_wxdt.at(i).m_stopDownloading = true;
            this->m_wxdt.at(i).m_progressPercent = 0;
          }
        }
        this->m_thread_group.join_all();
        for(size_t i = this->m_threads.size() == 0 ? 0 : this->m_threads.size() - 1; i >= 0 ; i--)
        {
          if (i == 0) break;
          if (this->m_thread_group.size() > i)
          {
            this->m_thread_group.remove_thread(&(this->m_threads.at(i)));
          }
        }
        this->m_threads.resize(0);
        this->m_wxdt.resize(0);
      }

      void MusicRobotApp::DownloadThreadsRecreate()
      {
        wxCSConv wxCSUTF8(wxFONTENCODING_UTF8);
        this->waitForThreads();
        this->m_wxdt.reserve(this->m_wxServer.size());

        for(size_t i = 0; i < this->m_wxServer.size(); i++)
        {
          MusicResSessionPar mrsp = this->m_wxServer.at(i);

          DownloadThread *dwnThr = new DownloadThread(mrsp.getSessionParam());
          {
            boost::lock_guard<boost::mutex> lock(dwnThr->m_downloadthread_m_wxuri_mutex);

            dwnThr->m_wxuri = new wxURI(std2wx(mrsp.getMusicResource(), &wxCSUTF8));
            dwnThr->m_musicResourceURI.Create(dwnThr->m_wxuri->BuildURI());
          }
          dwnThr->m_tableName = mrsp.getTableName();
          dwnThr->m_tablePrefix = mrsp.getTablePrefix();
          
          this->copyLoginInfo(*dwnThr);

          this->m_wxdt.push_back(dwnThr);

        }
      }

      MusicRobotApp::ptr_map_string_string MusicRobotApp::mcs_mime = MusicRobotApp::fillMimeTypes();

      const wxOperatingSystemId MusicRobotApp::mcs_wxosid = wxGetOsVersion();

    } // namespace MR
  } // namespace MIR
} // namespace SyNaT
