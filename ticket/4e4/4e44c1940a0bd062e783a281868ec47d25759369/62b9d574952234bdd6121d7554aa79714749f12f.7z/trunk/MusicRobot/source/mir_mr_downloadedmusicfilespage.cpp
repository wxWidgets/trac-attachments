﻿
// For compilers that support precompilation, includes "wx/wx.h".
#include <wx/wxprec.h>

#ifdef __BORLANDC__
    #pragma hdrstop
#endif

// for all others, include the necessary headers (this file is usually all you
// need because it includes almost all "standard" wxWidgets headers
#ifndef WX_PRECOMP
    #include "wx/wx.h"
#endif

#include "mir_utils.h"
#include "mir_mr_musicrobotapp.h"
#include "mir_mr_downloadedmusicfilespage.h"

#include <ibpp.h>


namespace SyNaT
{
  namespace MIR
  {
    namespace MR
    {
      using namespace IBPP;

      DownloadedMusicFilesPage::DownloadedMusicFilesPage(MusicRobotApp *mra) : m_mra(mra)
      {
      }

      void DownloadedMusicFilesPage::dwnlMusicFiles(Utils::ptr_map_string_wxString &ptr_map_params)
      {
        if (!this->m_mra->m_login.compare(""))
        {
          this->m_mra->setInternalPath("/login", true);
          return;
        }

        this->m_mra->destroyAllWidgets();

        WContainerWidget *wcw = this->m_mra->root();

        Statement stmt = this->m_mra->m_dm.createStatement(&this->m_mra->m_tr);



      }
    }
  }
}
