#include <Wt/WApplication>
#include <Wt/WText>
#include <Wt/WProgressBar>
#include <Wt/WPushButton>
#include <Wt/WTimer>
#include <Wt/WTextArea>
#include <Wt/WAnchor>
#include <Wt/WMessageBox>
#include <Wt/WLabel>
#include <Wt/WLogger>

// For compilers that support precompilation, includes "wx/wx.h".
#include <wx/wxprec.h>

#ifdef __BORLANDC__
    #pragma hdrstop
#endif

// for all others, include the necessary headers (this file is usually all you
// need because it includes almost all "standard" wxWidgets headers
#ifndef WX_PRECOMP
    #include "wx/wx.h"
#endif

#include <boost/foreach.hpp>
#include <boost/thread/mutex.hpp>
#include <boost/thread.hpp>

#include "mir_stringutils.h"
#include "mir_exceptions.h"
#include "mir_databasetypes.h"
#include "mir_databasemodule.h"
#include "mir_mr_downloadthread.h"
#include "mir_mr_musicrobotapp.h"
#include "mir_mr_statuspage.h"

namespace SyNaT
{
  namespace MIR
  {
    namespace MR
    {
      StatusPage::StatusPage(MusicRobotApp *mra) : m_mra(mra)
      {
      }

      void StatusPage::destroyAllWidgets()
      {
        WContainerWidget *wcw = this->m_mra->root();

        BOOST_FOREACH(WWidget &widget, this->m_wpbrTxt)
        {
          wcw->removeWidget(&widget);
        }
        this->m_wpbrTxt.resize(0);

        BOOST_FOREACH(WWidget &widget, this->m_wpbr)
        {
          wcw->removeWidget(&widget);
        }
        this->m_wpbr.resize(0);
      }

      void StatusPage::m_slt_wpbStart()
      {

        this->m_wpbStart->disable();

        int i = 0;

        BOOST_FOREACH(DownloadThread &dt, this->m_mra->m_wxdt)
        {
        	bool stopDownloading = true;
        	{
        		boost::lock_guard<boost::mutex> lock(dt.m_downloadthread_m_stopDownloading_mutex);
        		stopDownloading = dt.m_stopDownloading;
        	}
          if (stopDownloading)
          {
            {
              boost::lock_guard<boost::mutex> lock(dt.m_downloadthread_m_progressPercent_mutex);
              dt.m_progressPercent = 0;
            }
            this->m_mra->m_threads.push_back(this->m_mra->m_thread_group.create_thread(boost::ref(dt)));
          }
        }

        this->m_mra->m_stopDownloading = false;
        this->m_mra->m_wtimer->start();

      }

      void StatusPage::m_slt_wpbStop()
      {

        if (!this->m_mra->m_stopDownloading)
        {
          this->m_wpbStop->disable();
        }
        this->m_mra->DownloadThreadsRecreate();
        this->m_mra->m_stopDownloading = true;
        
      }

      void StatusPage::statusPage()
      {
        if (!this->m_mra->m_login.compare(""))
        {
          wApp->setInternalPath("/login", true);
          return;
        }
 
        wxCSConv wxCSUTF8(wxFONTENCODING_UTF8);

        this->m_mra->destroyAllWidgets();

        bool anyThreadRunning = false;

        WContainerWidget *wcw = this->m_mra->root();
        
        if (this->m_mra->m_wxServer.size() > 0)
        {
          for(size_t i=0; i < this->m_mra->m_wxServer.size(); i++)
          {
            if ((this->m_mra->m_wxdt.size() > i))
            {
              {
                boost::lock_guard<boost::mutex> lock(this->m_mra->m_wxdt.at(i).m_downloadthread_m_stopDownloading_mutex);
                if (!this->m_mra->m_wxdt.at(i).m_stopDownloading)
                {
                  anyThreadRunning = true;
                  break;
                }
              }
            }
          }
          if (!anyThreadRunning)
          {
            this->m_mra->waitForThreads();
            this->m_mra->m_wxdt.reserve(this->m_mra->m_wxServer.size());
            for(size_t i=0; i < this->m_mra->m_wxServer.size(); i++)
            {
              MusicResSessionPar mrsp = this->m_mra->m_wxServer.at(i);

              DownloadThread *dwnThr = new DownloadThread(mrsp.getSessionParam());
              {
                boost::lock_guard<boost::mutex> lock(dwnThr->m_downloadthread_m_wxuri_mutex);
                dwnThr->m_wxuri = new wxURI(std2wx(mrsp.getMusicResource(), &wxCSUTF8));
                dwnThr->m_musicResourceURI.Create(dwnThr->m_wxuri->BuildURI());
              }
              dwnThr->m_tableName = mrsp.getTableName();
              dwnThr->m_tablePrefix = mrsp.getTablePrefix();
              this->m_mra->copyLoginInfo(*dwnThr);

              this->m_mra->m_wxdt.push_back(dwnThr);

            }

          }

          this->m_wpbStart = new WPushButton(WString("Start downloading...", UTF8), wcw);
          this->m_wpbStart->setToolTip(WString("Rozpocznij pobieranie", UTF8));
          this->m_wpbStart->clicked().connect(this->m_wpbStart, &WPushButton::disable);
          this->m_wpbStart->clicked().connect(this, &StatusPage::m_slt_wpbStart);

          this->m_wpbStop = new WPushButton(WString("End downloading...", UTF8), wcw);
          this->m_wpbStop->setToolTip(WString("Zakończ pobieranie", UTF8));
          this->m_wpbStop->clicked().connect(this, &StatusPage::m_slt_wpbStop);

          new WText(WString("<br />", UTF8), XHTMLText, wcw);

          if (this->m_mra->m_wxServer.size() > 0)
          {
            this->m_wpbr.reserve(this->m_mra->m_wxServer.size());

            this->m_wpbrTxt.reserve(this->m_mra->m_wxServer.size());
          }

          for(size_t i = 0; i < this->m_mra->m_wxdt.size(); i++)
          {
            new WText(WString("<br /><br />", UTF8), XHTMLText, wcw);
            if (this->m_mra->m_stopDownloading)
            {
              this->m_wpbrTxt.push_back(new WText(WString(this->m_mra->m_wxServer.at(i).getMusicResource(), UTF8), wcw));
            } else
            {
              boost::lock_guard<boost::mutex> lock(this->m_mra->m_wxdt.at(i).m_downloadthread_m_wxuri_mutex);
              this->m_wpbrTxt.push_back(new WText(wx2wts(/*wxURI::Unescape(*/this->m_mra->m_wxdt.at(i).m_wxuri->BuildUnescapedURI()/*)*/), wcw));
            }
            new WText(WString("<br />", UTF8), XHTMLText, wcw);
            this->m_wpbr.push_back(new WProgressBar(wcw));
            this->m_wpbr.back().setMinimum(0);
            this->m_wpbr.back().setMaximum(100);
            new WText(WString("<br /><br />", UTF8), XHTMLText, wcw);
          }

          for(size_t i=0; i < this->m_mra->m_wxdt.size(); i++)
          {
            if(this->m_mra->m_stopDownloading)
            {
              this->m_wpbr.at(i).setValue(0);
            } 
            else
            {
              boost::lock_guard<boost::mutex> lock(this->m_mra->m_wxdt.at(i).m_downloadthread_m_progressPercent_mutex);

              this->m_wpbr.at(i).setValue(this->m_mra->m_wxdt.at(i).m_progressPercent);
              if (this->m_wpbStart->isEnabled())
                this->m_wpbStart->disable();
            }
          }
        }
        else 
        {
          WText *wt = new WText(WString("Nie ma serwerów na liście...", UTF8), wcw);
          wt->setToolTip(WString("Brak serwerów na liście", UTF8));
        }
      }

    } // namespace MR
  } // namespace MIR
} // namespace SyNaT
