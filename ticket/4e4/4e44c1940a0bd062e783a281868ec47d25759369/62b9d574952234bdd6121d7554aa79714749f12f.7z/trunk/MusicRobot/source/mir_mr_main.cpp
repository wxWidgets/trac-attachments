﻿/*
 * ZakĹ‚adam nie peĹ‚ne obliczanie wyraĹĽeĹ„ warunkowych...
 */

#include <Wt/WApplication>
#include <Wt/WEnvironment>

// For compilers that support precompilation, includes "wx/wx.h".
#include <wx/wxprec.h>

#ifdef __BORLANDC__
    #pragma hdrstop
#endif

// for all others, include the necessary headers (this file is usually all you
// need because it includes almost all "standard" wxWidgets headers
#ifndef WX_PRECOMP
    #include "wx/wx.h"
#endif

#include <wx/uri.h>

#include <curl/curl.h>

#include <ZenLib/Ztring.h> //Note : I need it for universal atoi, but you have not to use it for be able to use MediaInfoLib
#include <MediaInfo/MediaInfo.h>

#include <xtract/libxtract.h>

#include <boost/ptr_container/ptr_vector.hpp>

#include "mir_stringutils.h"
#include "mir_exceptions.h"
#include "mir_databasetypes.h"
#include "mir_databasemodule.h"
#include "mir_mr_musicrobotapp.h"

#include <ibpp.h>

using namespace Wt;


namespace SyNaT
{
  namespace MIR {
    namespace MR {

      WApplication *createApplication(const WEnvironment& env)
      {
        return new SyNaT::MIR::MR::MusicRobotApp(env);
      }



    } // namespace MR
  } // namespace MIR
} // namespace SyNaT

int main(int argc, char **argv)
{
	//ZenLib::Ztring s;
	//MediaInfoLib::MediaInfo MI;

 // float mean = 0, vector[] = {.1f, .2f, .3f, .4f, -.5f, -.4f, -.3f, -.2f, -.1f},
 //       spectrum[10];
 // int N = 9;
 // float argf[4];

 // argf[0] = 8000.f;
 // argf[1] = XTRACT_MAGNITUDE_SPECTRUM;
 // argf[2] = 0.f;
 // argf[3] = 0.f;
 // 
 // xtract[XTRACT_MEAN](vector, N, NULL, &mean);
 // xtract_init_fft(N, XTRACT_SPECTRUM);
 // xtract[XTRACT_SPECTRUM](vector, N, &argf[0], &spectrum[0]);

  //using namespace IBPP;
  //using namespace std;
  //  
  //using namespace SyNaT::MIR;

  //wxFileName fncwd(wxFileName::GetCwd());
  //wxFileName fname(fncwd.GetVolume() + fncwd.GetVolumeSeparator() + wxT("/opt/databases/MDB.FDB"), wxPATH_UNIX);
  //fname.Normalize(wxPATH_NORM_LONG|wxPATH_NORM_DOTS|wxPATH_NORM_TILDE|wxPATH_NORM_ABSOLUTE);

  //DatabaseModule dm("localhost", wx2std(fname.GetFullPath(), &wxConvUTF8), 
  //                                              "SYSDBA", "masterkey", "", 
  //                                              "UTF8", "", "lukasz", "admin", false);

  //Transaction tr = dm.createTransaction();
  //tr->Start();

  //boost::ptr_vector<DBField> dbfv;

  //dbfv.push_back(new StringDBField(string("kasia"), "UZY_IDENTYFIKATOR" ));
  //
  //dm.insertIntoTable("UZY", "MIR_UZYTKOWNIK", dbfv, &tr);

  //tr->Commit();
  //tr->Start();

  //((StringDBField *) &dbfv.at(0))->setValue("marek");

  //dm.updateTable(2, "UZY", "MIR_UZYTKOWNIK", dbfv, &tr);
  //
  //tr->Commit();
 
  //Statement stmt = dm.createStatement(&tr, &string("CREATE PROCEDURE SEQ_ID_SRW_ID RETURNS(P_OUT BIGINT) AS begin P_OUT = NEXT VALUE FOR SEQ_PAR_ID; suspend; end"));
  wxInitializer initializer;
  if ( !initializer )
  {
    std::cout << "Failed to initialize the wxWidgets library, aborting.";
    return -1;
  }

  curl_global_init(CURL_GLOBAL_DEFAULT);

  int result = WRun(argc, argv, &SyNaT::MIR::MR::createApplication);

  curl_global_cleanup();

  return result;
}
