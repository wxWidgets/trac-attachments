﻿// For compilers that support precompilation, includes "wx/wx.h".
#include <wx/wxprec.h>

#ifdef __BORLANDC__
    #pragma hdrstop
#endif

// for all others, include the necessary headers (this file is usually all you
// need because it includes almost all "standard" wxWidgets headers
#ifndef WX_PRECOMP
    #include "wx/wx.h"
#endif

#include <wx/filename.h>
#include <wx/uri.h>
#include <wx/strconv.h>
#include <wx/platinfo.h>
#include <wx/wfstream.h>
#include <wx/arrstr.h>
#include <wx/tokenzr.h>
#include <wx/filefn.h>

#include <curl/curl.h>

#include <boost/tokenizer.hpp>
#include <boost/regex.hpp>
#include <boost/ptr_container/ptr_vector.hpp>
#include <boost/ptr_container/ptr_map.hpp>
#include <boost/thread/mutex.hpp>

#include <string>

#include "mir_defines.h"
#include "mir_utils.h"
#include "mir_stringutils.h"
#include "mir_exceptions.h"
#include "mir_databasetypes.h"
#include "mir_databasemodule.h"
#include "mir_contenttyperetriever.h"
#include "mir_mr_musicrobotapp.h"
#include "mir_mr_downloadthread.h"

#include <ibpp.h>


namespace SyNaT
{
  namespace MIR
  {
    namespace MR
    {
      using namespace std;
      using namespace IBPP;

      void DownloadThread::operator()(void)
      {
        this->m_dm.connect(this->m_serverName, this->m_databaseName, this->m_userName,
          this->m_userPassword, this->m_roleName, this->m_charSet,
          "", this->m_login, this->m_hashpassword);

        if (this->m_dm.logged())
        {
          {
            boost::lock_guard<boost::mutex> lock(this->m_downloadthread_m_stopDownloading_mutex);
            this->m_stopDownloading = false;
          }
          {
            boost::lock_guard<boost::mutex> lock(DownloadThread::ms_downloadthread_wxWidgetsFuncs_mutex);
            this->m_fncwd.SetPath(wxFileName::GetCwd());
          }

          wxString volPostfix;
          if (MusicRobotApp::mcs_wxosid & wxOS_WINDOWS)
            volPostfix = wxT(":");
          this->m_fnrootwww.Assign(this->m_fncwd.GetVolume() + volPostfix + this->m_fncwd.GetVolumeSeparator(wxPATH_UNIX) + wxT(MIR_PATH_TO_WWW_DIR), wxPATH_UNIX);
          this->m_fnrootwww.Normalize(wxPATH_NORM_LONG|wxPATH_NORM_DOTS|wxPATH_NORM_TILDE|wxPATH_NORM_ABSOLUTE);

          this->m_curl = curl_easy_init();

          curl_easy_setopt(this->m_curl, CURLOPT_WRITEDATA, this);
          curl_easy_setopt(this->m_curl, CURLOPT_WRITEFUNCTION, DownloadThread::write_data);
          curl_easy_setopt(this->m_curl, CURLOPT_PROGRESSFUNCTION, DownloadThread::progress_callback);
          curl_easy_setopt(this->m_curl, CURLOPT_PROGRESSDATA, this);
          curl_easy_setopt(this->m_curl, CURLOPT_HEADERFUNCTION, DownloadThread::write_header);
          curl_easy_setopt(this->m_curl, CURLOPT_HEADERDATA, this);

          wxString wxpage, wxEscapedURI, /*wxm_MusicResource,*/
                   wx_part_of_page, wx_dest_href, wx_dest_page;

          KindOfContentTypeValue content_type;

          string charset, content_type_ext;

          string scz_odw_urla, odw_url;

          wxString wxdirplusfilename, wxpathdir_musicResource;

          wxpathdir_musicResource = this->m_musicResourceURI.GetPath(); // m_musicResource ma zawsze część Path
          if (!wxpathdir_musicResource.EndsWith(wxT("/")))
          {
            wxpathdir_musicResource.Truncate(wxpathdir_musicResource.Find('/', true) + 1);
          }
          // wxpathdir_musicResource zawiera część path /path/

          this->m_tr = this->m_dm.createTransaction(amWrite, ilReadCommitted, lrWait);

          //wxm_MusicResource = Utils::createMusicResourceForSimilarTo(this->m_musicResourceURI);

          if (!this->get_next_uri(odw_url, scz_odw_urla/*, wxm_MusicResource*/)) 
          {
            this->OnExit();
            return;
          }

          bool end = false;

          while(!end)
          {
            wxURI wx_base_uri, wx_a_href;
            {            
              boost::lock_guard<boost::mutex> lock(this->m_downloadthread_m_wxuri_mutex);
              curl_easy_setopt(this->m_curl, CURLOPT_URL, wx2std(this->m_wxuri->BuildURI(), &this->m_wxCSUTF8).c_str());
              curl_easy_setopt(this->m_curl, CURLOPT_HTTPGET, 1L);
              curl_easy_setopt(this->m_curl, CURLOPT_SSL_VERIFYPEER, 0L);
              curl_easy_setopt(this->m_curl, CURLOPT_SSL_VERIFYHOST, 0L);
              curl_easy_setopt(this->m_curl, CURLOPT_FOLLOWLOCATION, 1);
              curl_easy_setopt(this->m_curl, CURLOPT_NOPROGRESS, 0);
              curl_easy_setopt(this->m_curl, CURLOPT_AUTOREFERER, 1);
              curl_easy_setopt(this->m_curl, CURLOPT_COOKIESESSION, 1);
            }

            this->m_httpResponse.clear();
            this->m_httpResponseHeader.clear();

            bool stopDownloading = false;
            {
              boost::lock_guard<boost::mutex> lock(this->m_downloadthread_m_stopDownloading_mutex);
            	stopDownloading = this->m_stopDownloading;
            }

            if ((curl_easy_perform(this->m_curl) == CURLE_OK) && (!stopDownloading))
            {
              long responseCode;
              if (curl_easy_getinfo(this->m_curl, CURLINFO_RESPONSE_CODE , &responseCode ) == CURLE_OK)
              {
                if (responseCode < 400)
                {
                  {
                    boost::lock_guard<boost::mutex> lock(this->m_downloadthread_m_wxuri_mutex);
                    char *eurl = NULL;
                    curl_easy_getinfo(this->m_curl, CURLINFO_EFFECTIVE_URL, &eurl);
                    wxURI wxEURI(std2wx(string(eurl == NULL ? "" : eurl), &this->m_wxCSUTF8));

                    // obsługa redirecta z np. http://localhost/folder.c na http://localhost/folder.c/
                    this->handleRedirect(&wxEURI, this->m_wxuri);

                    wx_base_uri = this->buildBaseURI();
                  }

                  content_type = Utils::match_content_type(this->m_httpResponseHeader);
                  content_type_ext = Utils::match_content_type_ext(this->m_httpResponseHeader);

                  if (content_type < koctvJavaScript)
                  {

                    charset = Utils::match_charset(this->m_httpResponse, this->m_httpResponseHeader);

                    // we fall back if charset was not found to default charset
                    if (charset.empty())
                      charset.assign("ISO-8859-1");

                    wxCSConv wxCsConv(std2wx(charset, &this->m_wxCSUTF8).Upper());

                    this->m_httpResponse = boost::regex_replace(this->m_httpResponse, DownloadThread::mcs_regex_zeroReplacer, "%00");

                    wxpage = std2wx(this->m_httpResponse, &wxCsConv);

                    bool hasBaseTag = false;
                    bool hasBaseHref = false;
                    bool hasAHref = false;
                    bool hasATag = false;
                    bool hasLinkTag = false;
                    bool hasLinkHref = false;
                    bool hasImgTag = false;
                    bool hasImgSrc = false;

                    KindOfAttrValue koav, koavLink, koavImg;

                    size_t startA = 0, lenA = 0, startOfTagA = 0, lenOfTagA = 0,
                           startLink = 0, lenLink = 0, startOfTagLink = 0, lenOfTagLink = 0,
                           startImg = 0, lenImg = 0, startOfTagImg = 0, lenOfTagImg = 0,
                           startBase = 0, lenBase = 0, startOfTagBase = 0, lenOfTagBase = 0,
                           offset = 0, start = 0, len = 0, startOfTag = 0, lenOfTag = 0;

                    wx_part_of_page = wxpage;

                    wxEscapedURI = wxT("");
                    wx_dest_page = wxT("");

                    wxURI wx_base_href_uri = this->m_utl.match_base_tag(wx_part_of_page, hasBaseHref, hasBaseTag, startBase, lenBase, startOfTagBase, lenOfTagBase, this->m_wxuri, this->m_downloadthread_m_wxuri_mutex);

                    wx_a_href = this->m_utl.match_a_tag(wx_part_of_page, wx_base_uri, hasAHref, hasATag, startA, lenA, startOfTagA, lenOfTagA, koav, this->m_sessionID, this->m_sessionIDValue);

                    wxURI wx_link_href = this->m_utl.match_link_tag(wx_part_of_page, wx_base_uri, hasLinkHref, hasLinkTag, startLink, lenLink, startOfTagLink, lenOfTagLink, koavLink, this->m_sessionID, this->m_sessionIDValue);

                    wxURI wx_img_src = this->m_utl.match_img_tag(wx_part_of_page, wx_base_uri, hasImgSrc, hasImgTag, startImg, lenImg, startOfTagImg, lenOfTagImg, koavImg, this->m_sessionID, this->m_sessionIDValue);

                    if (((startOfTagBase < startOfTagA)    &&  hasATag  && hasBaseTag && !hasLinkTag && !hasImgTag)
                      ||((startOfTagBase < startOfTagLink) && !hasATag  && hasBaseTag &&  hasLinkTag && !hasImgTag)
                      ||((startOfTagBase < startOfTagImg)  && !hasATag  && hasBaseTag && !hasLinkTag &&  hasImgTag)

                      ||((startOfTagBase < startOfTagLink) && (startOfTagBase < startOfTagA)    &&  hasLinkTag && hasBaseTag &&  hasATag && !hasImgTag)
                      ||((startOfTagBase < startOfTagImg) && (startOfTagBase < startOfTagA)     && !hasLinkTag && hasBaseTag &&  hasATag &&  hasImgTag)
                      ||((startOfTagBase < startOfTagImg) && (startOfTagBase < startOfTagLink)  &&  hasLinkTag && hasBaseTag && !hasATag &&  hasImgTag)

                      ||((startOfTagBase < startOfTagImg) && (startOfTagBase < startOfTagLink)  &&  (startOfTagBase < startOfTagA)  &&  hasLinkTag && hasBaseTag && hasATag &&  hasImgTag)
                      || (!hasATag && !hasLinkTag && !hasImgTag && hasBaseTag))
                    {
                      start = startBase;
                      len = lenBase;
                      startOfTag = startOfTagBase;
                      lenOfTag = lenOfTagBase;

                      // tutaj zastępuje zawartość taga base jeżeli jest
                      if (hasBaseHref)
                      {
                        wx_dest_page += wxpage.Mid(offset, start);

                        offset = start + len;
                        wx_dest_page += wxT(" href=\"\"") + wxpage.Mid(offset, startOfTag + lenOfTag - len - start);

                        //offset = startOfTagBase + lenOfTagBase;
                      }
                      else if (hasBaseTag)
                      {
                        wx_dest_page += wxpage.Mid(offset, startOfTag + lenOfTag);
                        //offset = startOfTagBase + lenOfTagBase;
                      }

                      if (hasBaseTag)
                      {
                        offset = startOfTag + lenOfTag;
                        if (hasBaseHref)
                          wx_base_uri = wx_base_href_uri;
                      }
                    }

                    if (hasATag || hasBaseTag || hasLinkTag || hasImgTag)
                    {
                      while (hasATag || hasBaseTag || hasLinkTag || hasImgTag)
                      {
                        stopDownloading = false;
                        {
                          boost::lock_guard<boost::mutex> lock(this->m_downloadthread_m_stopDownloading_mutex);
                          stopDownloading = this->m_stopDownloading;
                        }
                        if (stopDownloading)
                        {
                          this->m_tr->Start();
                          this->m_dbFields.resize(0);
                          this->m_dbFields.push_back(new BoolDBField(false, this->m_tablePrefix + "_POBIERANY"));
                          this->m_dm.updateTable(this->m_tablePrefix_id, this->m_tablePrefix, this->m_tableName, this->m_dbFields, &(this->m_tr));
                          this->m_tr->Commit();
                          end = true;
                          break;
                        }

                        wx_part_of_page = wxpage.Mid(offset);

                        wx_base_href_uri = this->m_utl.match_base_tag(wx_part_of_page, hasBaseHref, hasBaseTag, startBase, lenBase, startOfTagBase, lenOfTagBase, this->m_wxuri, this->m_downloadthread_m_wxuri_mutex);

                        wx_a_href = this->m_utl.match_a_tag(wx_part_of_page, wx_base_uri, hasAHref, hasATag, startA, lenA, startOfTagA, lenOfTagA, koav, this->m_sessionID, this->m_sessionIDValue);

                        wx_link_href = this->m_utl.match_link_tag(wx_part_of_page, wx_base_uri, hasLinkHref, hasLinkTag, startLink, lenLink, startOfTagLink, lenOfTagLink, koavLink, this->m_sessionID, this->m_sessionIDValue);

                        wx_img_src = this->m_utl.match_img_tag(wx_part_of_page, wx_base_uri, hasImgSrc, hasImgTag, startImg, lenImg, startOfTagImg, lenOfTagImg, koavImg, this->m_sessionID, this->m_sessionIDValue);

                        if (((startOfTagBase < startOfTagA)    &&  hasATag  && hasBaseTag && !hasLinkTag && !hasImgTag)
                          ||((startOfTagBase < startOfTagLink) && !hasATag  && hasBaseTag &&  hasLinkTag && !hasImgTag)
                          ||((startOfTagBase < startOfTagImg)  && !hasATag  && hasBaseTag && !hasLinkTag &&  hasImgTag)

                          ||((startOfTagBase < startOfTagLink) && (startOfTagBase < startOfTagA)    &&  hasLinkTag && hasBaseTag &&  hasATag && !hasImgTag)
                          ||((startOfTagBase < startOfTagImg) && (startOfTagBase < startOfTagA)     && !hasLinkTag && hasBaseTag &&  hasATag &&  hasImgTag)
                          ||((startOfTagBase < startOfTagImg) && (startOfTagBase < startOfTagLink)  &&  hasLinkTag && hasBaseTag && !hasATag &&  hasImgTag)

                          ||((startOfTagBase < startOfTagImg) && (startOfTagBase < startOfTagLink)  &&  (startOfTagBase < startOfTagA)  &&  hasLinkTag && hasBaseTag && hasATag &&  hasImgTag)
                          || (!hasATag && !hasLinkTag && !hasImgTag && hasBaseTag))
                        {
                          start = startBase;
                          len = lenBase;
                          startOfTag = startOfTagBase;
                          lenOfTag = lenOfTagBase;

                          // tutaj zastępuje zawartość taga base jeżeli jest
                          if (hasBaseHref)
                          {
                            wx_dest_page += wxpage.Mid(offset, start);

                            wx_dest_page += wxT(" href=\"\"") + wxpage.Mid(offset + start + len, startOfTag + lenOfTag - len - start);

                            //offset = startOfTagBase + lenOfTagBase;
                          }
                          else if (hasBaseTag)
                          {
                            wx_dest_page += wxpage.Mid(offset, startOfTag + lenOfTag);
                            //offset = startOfTagBase + lenOfTagBase;
                          }

                          if (hasBaseTag)
                          {
                            if (hasBaseHref)
                              wx_base_uri = wx_base_href_uri;

                            hasAHref = false;
                            hasATag = false;
                          }

                        }
                        else if (((startOfTagA < startOfTagLink) && hasATag  && hasLinkTag && !hasImgTag)
                               ||((startOfTagA < startOfTagImg)  && hasATag  && !hasLinkTag &&  hasImgTag)

                               ||((startOfTagA < startOfTagLink) && (startOfTagA < startOfTagImg)    &&  hasLinkTag && hasATag && hasImgTag)

                               || (hasATag && !hasLinkTag && !hasImgTag))
                        {
                          //wxURI wx_a_href = Utils::match_a_tag(wx_part_of_page, wx_base_uri, hasAHref, hasATag, startA, lenA, startOfTagA, lenOfTagA, koav, this->m_sessionID);

                          wx_a_href = Utils::buildURIWithPathAfterServer(&wx_a_href);

                          start = startA;
                          len = lenA;
                          startOfTag = startOfTagA;
                          lenOfTag = lenOfTagA;
                        }
                        else if (((startOfTagLink < startOfTagImg)  && hasLinkTag &&  hasImgTag)

                               || (hasLinkTag && !hasImgTag))
                        {
                          start = startLink;
                          len = lenLink;
                          startOfTag = startOfTagLink;
                          lenOfTag = lenOfTagLink;
                          wx_a_href = wx_link_href;
                          koav = koavLink;
                          hasAHref = hasLinkHref;
                        }
                        else
                        {
                          start = startImg;
                          len = lenImg;
                          startOfTag = startOfTagImg;
                          lenOfTag = lenOfTagImg;
                          wx_a_href = wx_img_src;
                          koav = koavImg;
                          hasAHref = hasImgSrc;
                        }


                        if (hasAHref)
                        {
                          wxEscapedURI = wx_a_href.BuildURI();

                          // this->m_wxregex_newlineRemoval.ReplaceAll(&wxUnescapedURI, wxT("")); looping forever
                          //this->replaceNewlines(wxUnescapedURI);
                          wxEscapedURI.Replace(wxT("\n"), wxT(""));
                          wxEscapedURI.Replace(wxT("\r"), wxT(""));

                          wx_a_href.Create(wxEscapedURI);

                          wx_dest_page += wxpage.Mid(offset, startOfTag);

                          // TODO: dodać głębokość przeszukiwania wewnętrznego...
                          /*
                          if ((!this->m_musicResource.GetServer().Cmp(wx_a_href.GetServer()))
                            && Utils::isURIAtInnerDepth(int depth, wx_a_href, this->m_musicResource))
                             )
                          */
                          if ((!this->m_musicResourceURI.GetServer().Cmp(wx_a_href.GetServer()))
                            /*&& wx_a_href.GetPath().StartsWith(wxpathdir_musicResource)*/
                            /*&& ((wx_a_href.HasPath() && wx_a_href.GetPath().StartsWith(wxpathdir_musicResource))
                               || !wxpathdir_musicResource.Cmp(wxT("/")))*/
                             )
                          {
                            /// tutaj odkrywam z jakim content_type mam do czynienia

                            string a_href = wx2std(wx_a_href.BuildURI(), &this->m_wxCSUTF8);
                            ContentTypeRetriever ctr(a_href);

                            /// tutaj nastepuje zamiana hrefa w linku na wlasciwy

                            wx_dest_href = Utils::buildDestHref(wxdirplusfilename, wx_a_href, ctr, this->m_fnrootwww);

                            // zapis do bazy wxEscapedURI

                            this->insertEscapedURIIntoTable(wxEscapedURI, wx_dest_href, wx_a_href.GetServer(), wxdirplusfilename, content_type, ctr);

                            wx_dest_page += wxpage.Mid(offset + startOfTag, start - startOfTag);

                            switch(koav)
                            {
                              case koavWOQ:
                                wx_part_of_page = wxT(" href=/") + wx_dest_href + wxpage.Mid(offset + start + len, startOfTag + lenOfTag - len - start);
                                break;
                              case koavWDQ:
                                wx_part_of_page = wxT(" href=\"/") + wx_dest_href + wxT("\"") + wxpage.Mid(offset + start + len, startOfTag + lenOfTag - len - start);
                                break;
                              case koavWSQ:
                                wx_part_of_page = wxT(" href='/") + wx_dest_href + wxT("'") + wxpage.Mid(offset + start + len, startOfTag + lenOfTag - len - start);
                                break;
                              case koavWOQimg:
                                wx_part_of_page = wxT(" src=/") + wx_dest_href + wxpage.Mid(offset + start + len, startOfTag + lenOfTag - len - start);
                                break;
                              case koavWDQimg:
                                wx_part_of_page = wxT(" src=\"/") + wx_dest_href + wxT("\"") + wxpage.Mid(offset + start + len, startOfTag + lenOfTag - len - start);
                                break;
                              case koavWSQimg:
                                wx_part_of_page = wxT(" src='/") + wx_dest_href + wxT("'") + wxpage.Mid(offset + start + len, startOfTag + lenOfTag - len - start);
                            }

                            wx_dest_page += wx_part_of_page;
                          }
                          else
                          {
                            wx_dest_page += wxpage.Mid(offset + startOfTag, lenOfTag);
                            //wx_part_of_page = wxpage.Mid(offset + startOfTag, lenOfTag);
                          }

                          offset += startOfTag + lenOfTag;

                        }
                        else if (hasATag || hasBaseTag || hasLinkTag || hasImgTag)
                        {
                          if (hasATag)
                            wx_dest_page += wxpage.Mid(offset, startOfTag + lenOfTag);
                          offset += startOfTag + lenOfTag;
                        }
                        else
                        {
                          // rest of the page
                          if (wxpage.Len() > offset)
                          {
                            wx_dest_page += wxpage.Mid(offset);
                          }
                          break;
                        }

                      }
                    }
                    else
                    {
                      wx_dest_page += wxpage.Mid(offset);
                    }
                  }
                  else if (content_type == koctvAudioM3U)
                  {
                    // tutaj będę zamieniał
                    if (std2wx(scz_odw_urla, &this->m_wxCSUTF8).Upper().EndsWith(wxT("M3U8")))
                      charset = "UTF-8";
                    else
                      charset = "ISO-8859-1";

                    wxString wxCharset = std2wx(charset, &this->m_wxCSUTF8).Upper();
                    wxCSConv wxCsConv(wxCharset);

                    wx_dest_page = wxT("<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\">");
                    wx_dest_page += wxT("<html><head><meta http-equiv=\"content-type\" content=\"text/html; charset=");
                    wx_dest_page += wxCharset + wxT("\"><title></title></head><body>");
                    wxString m3uContents = std2wx(this->m_httpResponse, &wxCsConv);

                    wxArrayString wxas = wxStringTokenize(m3uContents, wxT("\r\n"), wxTOKEN_STRTOK);
                    for(size_t i = 0; i < wxas.Count(); i++)
                    {
                      wxas[i].Trim().Trim(false);
                      if (!wxas[i].StartsWith(wxT("#")))
                      {
                        wx_a_href.Create(wxas[i]);

                        wxEscapedURI = wx_a_href.BuildURI();

                        string a_href = wx2std(wx_a_href.BuildURI(), &this->m_wxCSUTF8);
                        ContentTypeRetriever ctr(a_href);

                        /// tutaj nastepuje zamiana hrefa w linku na wlasciwy
                        wx_dest_href = Utils::buildDestHref(wxdirplusfilename, wx_a_href, ctr, this->m_fnrootwww);

                        this->insertEscapedURIIntoTable(wxEscapedURI, wx_dest_href, wx_a_href.GetServer(), wxdirplusfilename, content_type, ctr);

                        wx_dest_page += wxT("<a href=\"/") + wx_dest_href + wxT("\" target=\"_blank\">/") + wx_dest_href + wxT("</a><br>");
                      }
                    }
                    wx_dest_page += wxT("</body></html>");

                  }

                  if (end)
                    continue;

                  if (content_type < koctvOther)
                  {
                    wxFileName fnscz_odw_urla(this->m_fncwd.GetVolume() + volPostfix + this->m_fncwd.GetVolumeSeparator(wxPATH_UNIX)+ std2wx(scz_odw_urla, &this->m_wxCSUTF8), wxPATH_UNIX);
                    fnscz_odw_urla.Normalize(wxPATH_NORM_LONG|wxPATH_NORM_DOTS|wxPATH_NORM_TILDE|wxPATH_NORM_ABSOLUTE);
                    if (!fnscz_odw_urla.DirExists())
                    {
                      boost::lock_guard<boost::mutex> lock(DownloadThread::ms_downloadthread_wxWidgetsFuncs_mutex);
                      wxFileName::Mkdir(fnscz_odw_urla.GetPath(wxPATH_GET_VOLUME|wxPATH_GET_SEPARATOR), 0755, wxPATH_MKDIR_FULL);
                    }
                    {
                      if (fnscz_odw_urla.FileExists())
                        wxRemoveFile(fnscz_odw_urla.GetFullPath());
                      wxFileOutputStream wxfos(fnscz_odw_urla.GetFullPath());
                      if ((content_type < koctvJavaScript) || (content_type == koctvAudioM3U))
                      {
                        wxCSConv wxCsConv(std2wx(charset, &this->m_wxCSUTF8).Upper());
                        wxfos.Write(wx_dest_page.char_str(wxCsConv), strlen(wx_dest_page.char_str(wxCsConv)));
                        wxfos.Close();
                      }
                      else
                      {
                        wxfos.Write(this->m_httpResponse.c_str(), this->m_httpResponse.size());
                        wxfos.Close();
                      }
                    }
                  }

                  this->m_dbFields.resize(0);
                  this->m_dbFields.push_back(new BoolDBField(false, this->m_tablePrefix + "_POBIERANY"));
                  this->m_dbFields.push_back(new BoolDBField(true, this->m_tablePrefix + "_ODWIEDZONY"));
                  switch(content_type)
                  {
                    case koctvHTML:
                    case koctvXHTML:
                      this->m_dbFields.push_back(new BoolDBField(true, this->m_tablePrefix + "_STRONA_LUB_AUDIO"));
                    break;
                    case koctvAudioContent:
                    case koctvAudioM3U:
                      this->m_dbFields.push_back(new BoolDBField(false, this->m_tablePrefix + "_STRONA_LUB_AUDIO"));
                  }

                  this->m_tr->Start();
                  try
                  {
                    this->m_dm.updateTable(this->m_tablePrefix_id, this->m_tablePrefix, this->m_tableName, this->m_dbFields, &(this->m_tr));
                  }
                  catch(IBPP::Exception &)
                  {
                  }
                  this->m_tr->Commit();
                }

              }


            }
            else
            {
            	stopDownloading = false;
              {
                boost::lock_guard<boost::mutex> lock(this->m_downloadthread_m_stopDownloading_mutex);
              	stopDownloading = this->m_stopDownloading;
              }

              if (stopDownloading)
              {
                this->m_tr->Start();
                this->m_dbFields.resize(0);
                this->m_dbFields.push_back(new BoolDBField(false, this->m_tablePrefix + "_POBIERANY"));
                this->m_dm.updateTable(this->m_tablePrefix_id, this->m_tablePrefix, this->m_tableName, this->m_dbFields, &(this->m_tr));
                this->m_tr->Commit();
                end = true;
                continue;
              }

            }

            // odnawianie m_wxuri
            if (!this->get_next_uri(odw_url, scz_odw_urla/*, wxm_MusicResource*/))
              end = true;

          }

          this->OnExit();
        }
        return;
      }

      DownloadThread::DownloadThread(const string &sessionID) : m_utl(sessionID), m_wxCSUTF8(wxFONTENCODING_UTF8) /*, m_tok(string("")*/
      {
        this->setFieldsToNull();
      }

      void DownloadThread::OnExit()
      {
        if (this->m_curl)
          curl_easy_cleanup(this->m_curl);
        this->m_curl = NULL;
        {
          boost::lock_guard<boost::mutex> lock(this->m_downloadthread_m_stopDownloading_mutex);
          this->m_stopDownloading = true;
        }

        {
          boost::lock_guard<boost::mutex> lock(this->m_downloadthread_m_wxuri_mutex);
          if (this->m_wxuri)
          {
            delete this->m_wxuri;
            this->m_wxuri = NULL;
          }
        }

        {
          boost::lock_guard<boost::mutex> lock(this->m_downloadthread_m_stopDownloading_mutex);
          this->m_stopDownloading = true;
        }
      }
      
      void DownloadThread::insertEscapedURIIntoTable(wxString &wxEscapedURI, wxString &wx_dest_href, const wxString &wx_a_hrefServer, wxString &wxdirplusfilename, KindOfContentTypeValue koctv, ContentTypeRetriever &ctr)
      {
        this->m_dbFields.resize(0);

        switch(ctr.getContentType())
        {
          case koctvHTML:
          case koctvXHTML:
            this->m_dbFields.push_back(new BoolDBField(true, this->m_tablePrefix + "_STRONA_LUB_AUDIO"));
          break;
          case koctvAudioContent:
          case koctvAudioM3U:
            this->m_dbFields.push_back(new BoolDBField(false, this->m_tablePrefix + "_STRONA_LUB_AUDIO"));
        }

        this->m_dbFields.push_back(new StringDBField(wx2std(wxEscapedURI, &this->m_wxCSUTF8), this->m_tablePrefix + "_ODW_URL"));
        this->m_dbFields.push_back(new StringDBField(wx2std(wxdirplusfilename, &this->m_wxCSUTF8), this->m_tablePrefix + "_SCZ_ODW_URLA"));
        this->m_dbFields.push_back(new BoolDBField(false, this->m_tablePrefix + "_ODWIEDZONY"));
        this->m_dbFields.push_back(new BoolDBField(false, this->m_tablePrefix + "_POBIERANY"));

        this->m_tr->Start();
        
        int64_t mir_serwxxxxx_id;
        try
        {
          mir_serwxxxxx_id = this->m_dm.insertIntoTable(this->m_tablePrefix, this->m_tableName, this->m_dbFields, &(this->m_tr));
          
          try 
          {
            if ((ctr.getContentType() == koctvAudioContent || ctr.getContentType() == koctvAudioM3U)
              && koctv != koctvAudioM3U)
            {
              this->m_dbFields.resize(0);
              this->m_dbFields.push_back(new INT64TDBField(this->m_tablePrefix_id, this->m_tablePrefix + "_SZA_S_" + this->m_tablePrefix + "_ID"));
              this->m_dbFields.push_back(new INT64TDBField(mir_serwxxxxx_id, this->m_tablePrefix + "_SZA_A_" + this->m_tablePrefix + "_ID"));
              this->m_dm.insertIntoTable(this->m_tablePrefix + "_SZA", this->m_tableName + "_STR_Z_AUD", this->m_dbFields, &(this->m_tr));
            }
          }
          catch(IBPP::Exception &)
          {
          
          }
        }
        catch(IBPP::Exception &)
        { // wyjątek gdy _ODW_URL miałby się powtórzyć a jest UNIQUE
          wxString wx_fullname;
          string fullname;
          ostringstream oss;

          oss.str("");
          oss << "SELECT " << this->m_tablePrefix << "_SCZ_ODW_URLA, " << this->m_tablePrefix << "_ID"
              << " FROM " << this->m_tableName << " WHERE "
              << this->m_tablePrefix << "_ODW_URL = " + DatabaseModule::toSql(wx2std(wxEscapedURI, &this->m_wxCSUTF8));
          Statement stmt = this->m_dm.createStatement(&(this->m_tr));
          stmt->Execute(oss.str());
          if (stmt->Fetch())
          {
            stmt->Get(1, fullname);
            wxString wx_fullname = std2wx(fullname, &this->m_wxCSUTF8);
            wx_dest_href = Utils::subAllNotAllowedCharsInFilenames(wx_a_hrefServer);
            wx_dest_href = wx_fullname.Mid(wx_fullname.Find(wx_dest_href));

            stmt->Get(2, mir_serwxxxxx_id);
            
            try 
            {
              if ((ctr.getContentType() == koctvAudioContent || ctr.getContentType() == koctvAudioM3U)
                && koctv != koctvAudioM3U)
              {
                this->m_dbFields.resize(0);
                this->m_dbFields.push_back(new INT64TDBField(this->m_tablePrefix_id, this->m_tablePrefix + "_SZA_S_" + this->m_tablePrefix + "_ID"));
                this->m_dbFields.push_back(new INT64TDBField(mir_serwxxxxx_id, this->m_tablePrefix + "_SZA_A_" + this->m_tablePrefix + "_ID"));
                this->m_dm.insertIntoTable(this->m_tablePrefix + "_SZA", this->m_tableName + "_STR_Z_AUD", this->m_dbFields, &(this->m_tr));
              }
            } 
            catch(IBPP::Exception &)
            {
            
            }
          }
        }

        this->m_tr->Commit();
      }
      
      wxURI DownloadThread::buildBaseURI()
      {
        wxString wx_base;
        wx_base = this->m_wxuri->GetScheme() + wxT("://");
        if (this->m_wxuri->HasUserInfo())
        {
          wx_base += this->m_wxuri->GetUser();
          if (!this->m_wxuri->GetPassword().IsEmpty())
            wx_base += wxT(":") + this->m_wxuri->GetPassword();
          wx_base += wxT("@");
        }
        wx_base += this->m_wxuri->GetServer();
        if (this->m_wxuri->HasPort())
          wx_base += wxT(":") + this->m_wxuri->GetPort();
        if (this->m_wxuri->HasPath())
          wx_base += this->m_wxuri->GetPath();
        else
          wx_base += wxT("/");

        return wxURI(wx_base);
      }

      /**
       * Wywoływana tylko podczas konstrukcji DownloadThread.
       */
      void DownloadThread::setFieldsToNull()
      {
        this->m_httpResponse.clear();
        {
          this->m_progressPercent = 0;
        }
        this->m_wxuri = NULL;
        {
					boost::lock_guard<boost::mutex> lock(this->m_downloadthread_m_stopDownloading_mutex);

          this->m_stopDownloading = true;
        }
        this->m_curl = NULL;
      }


      void DownloadThread::handleRedirect(wxURI *wxEURI, wxURI *wxuri)
      {
      	wxString wxURLStr;
        if (wxEURI->HasPath())
        {
          // moze powinienem porownywac port takze
          if ((!wxuri->GetScheme().Cmp(wxEURI->GetScheme()))
            && (!wxuri->GetServer().Cmp(wxEURI->GetServer()))
            && (!wxuri->GetQuery().Cmp(wxEURI->GetQuery()))
            && (!wxuri->GetFragment().Cmp(wxEURI->GetFragment())))
          {
            if (wxuri->HasPath()
              && (wxuri->GetPath().Len() == (wxEURI->GetPath().Len() - 1))
              && (!wxuri->GetPath().Cmp(wxEURI->GetPath().Left(wxEURI->GetPath().Len() - 1)))
              && (wxEURI->GetPath().EndsWith(wxT("/"))))
            {
            	wxURLStr = wxuri->GetScheme() + wxT("://");
              if (wxuri->HasUserInfo())
              {
              	wxURLStr += wxuri->GetUser();
                if (!wxuri->GetPassword().IsEmpty())
                	wxURLStr += wxT(":") + wxuri->GetPassword();
                wxURLStr += wxT("@");
              }
              wxURLStr += wxuri->GetServer();
              wxURLStr += wxuri->GetPath() + wxT("/"); // here i prepend /

              if (wxuri->HasQuery())
              	wxURLStr += wxT("?") + wxuri->GetQuery();
              if (wxuri->HasFragment())
              	wxURLStr += wxT("#") + wxuri->GetFragment();

              wxuri->Create(wxURLStr);
                      
            }
          }
        }
      }

      bool DownloadThread::get_next_uri(string &odw_url, string &scz_odw_urla/*, wxString &wxm_MusicResource*/)
      {
        ostringstream oss;
        
        oss << "SELECT " << this->m_tablePrefix << "_ID, " 
            << this->m_tablePrefix << "_ODW_URL, " << this->m_tablePrefix << "_SCZ_ODW_URLA"
            << " FROM " << this->m_tableName << " WHERE "
            << this->m_tablePrefix << "_ODWIEDZONY = 'F' AND "
            << this->m_tablePrefix << "_POBIERANY = 'F' "
            //<< "AND " << this->m_tablePrefix << "_ODW_URL SIMILAR TO "
            //<< "'" << DatabaseModule::toSimilarToSql(wx2std(wxm_MusicResource, &wxConvUTF8), false)
            //<< "_*'" << " ESCAPE '\\'";
            ;
        this->m_tr->Start();
        string sql = oss.str();
        Statement stmt = this->m_dm.createStatement(&(this->m_tr), &sql);
        stmt->Execute();
        bool fetched = stmt->Fetch();
        while (true)
        {
          if (fetched)
          {
            stmt->Get(1, this->m_tablePrefix_id);
            Transaction tr = this->m_dm.createTransaction();
            tr->Start();
            try 
            {
              this->m_dbFields.resize(0);
              this->m_dbFields.push_back(new BoolDBField(true, this->m_tablePrefix + "_POBIERANY"));
              this->m_dm.updateTable(this->m_tablePrefix_id, this->m_tablePrefix, this->m_tableName, this->m_dbFields, &tr);
            }
            catch(IBPP::Exception &)
            { // wystąpi gdy inny wątek spróbuje zapisać ten sam rekord
              tr->Commit();
              fetched = stmt->Fetch();
              continue;
            }
            tr->Commit();

            stmt->Get(2, odw_url);
            stmt->Get(3, scz_odw_urla);
            {
              boost::lock_guard<boost::mutex> lock(this->m_downloadthread_m_wxuri_mutex);
              wxString wx_odw_url;
              delete this->m_wxuri;
              if (!this->m_sessionID.empty())
              {
                this->m_wxuri = new wxURI(std2wx(odw_url, &this->m_wxCSUTF8));
                (*this->m_wxuri) = Utils::buildURIWithQueryParam(this->m_wxuri,
                                                               std2wx(this->m_sessionID, &this->m_wxCSUTF8),
                                                               std2wx(this->m_sessionIDValue, &this->m_wxCSUTF8));
              }
              else
                this->m_wxuri = new wxURI(std2wx(odw_url, &this->m_wxCSUTF8));
            }
            break;
          }
          else
          {
            break;
          }

        }

        this->m_tr->Commit();

        return fetched;
      }

      extern "C" 
      {
        int DownloadThread::progress_callback(void *progressData,double t,double d,double ultotal,double ulnow)
        {
          DownloadThread *wxdt = (DownloadThread *) progressData;
          {
            boost::lock_guard<boost::mutex> lock(wxdt->m_downloadthread_m_progressPercent_mutex);
            wxdt->m_progressPercent = (t != 0 ? (d/t * 100.0) : 0);
            
            if (wxdt->m_progressPercent > 100) // wydaje się, że takie sytuacje też mają miejsce...
              wxdt->m_progressPercent = 100;
          }
        	bool stopDownloading = false;
          {
            boost::lock_guard<boost::mutex> lock(wxdt->m_downloadthread_m_stopDownloading_mutex);
          	stopDownloading = wxdt->m_stopDownloading;
          }

	        return stopDownloading;
        }

        size_t DownloadThread::write_data(void *ptr, size_t size, size_t nmemb, void *writeData)
        {
          char *cptr = (char *) ptr;
          DownloadThread *wxdt = (DownloadThread *) writeData;
          wxdt->m_httpResponse.append(cptr, size*nmemb);
	        return size*nmemb;
        }

        size_t DownloadThread::write_header(void *ptr, size_t size, size_t nmemb, void *userdata)
        {
          char *cptr = (char *) ptr;
          DownloadThread *wxdt = (DownloadThread *) userdata;
          wxdt->m_httpResponseHeader.append(cptr, size*nmemb);
	        return size*nmemb;
        }
      }

      const boost::regex       DownloadThread::mcs_regex_zeroReplacer("\\0");
      boost::mutex             DownloadThread::ms_downloadthread_wxWidgetsFuncs_mutex;

    } // namespace MR
  } // namespace MIR
} // namespace SyNaT
