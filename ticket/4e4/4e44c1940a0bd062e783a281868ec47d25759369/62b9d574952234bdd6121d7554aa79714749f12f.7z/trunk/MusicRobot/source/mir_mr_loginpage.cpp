#include <Wt/WLineEdit>
#include <Wt/WPushButton>

// For compilers that support precompilation, includes "wx/wx.h".
#include <wx/wxprec.h>

#ifdef __BORLANDC__
    #pragma hdrstop
#endif

// for all others, include the necessary headers (this file is usually all you
// need because it includes almost all "standard" wxWidgets headers
#ifndef WX_PRECOMP
    #include "wx/wx.h"
#endif

#include <wx/platinfo.h>


#include <boost/thread/mutex.hpp>

#include "mir_defines.h"
#include "mir_databasemodule.h"
#include "mir_stringutils.h"
#include "mir_mr_musicrobotapp.h"
#include "mir_mr_loginpage.h"

#include <ibpp.h>

namespace SyNaT
{
  namespace MIR 
  {
    namespace MR 
    {
      using namespace std;
      using namespace Wt;
      using namespace IBPP;

      LoginPage::LoginPage(MusicRobotApp *mra) : m_mra(mra)
      {
      }

      void LoginPage::m_slt_wpbLogin()
      {
        wxCSConv wxCSUTF8(wxFONTENCODING_UTF8);

        wxFileName fncwd;
        {
          boost::lock_guard<boost::mutex> lock(DownloadThread::ms_downloadthread_wxWidgetsFuncs_mutex);

          fncwd.Assign(wxFileName::GetCwd());
        }
        wxString volPostfix;
        if (this->m_mra->mcs_wxosid & wxOS_WINDOWS)
          volPostfix = wxT(":");

        wxFileName fname(fncwd.GetVolume() + volPostfix + fncwd.GetVolumeSeparator(wxPATH_UNIX) + wxT(MIR_PATH_TO_DB_DIR) + wxT("MDB.FDB"), wxPATH_UNIX);
        fname.Normalize(wxPATH_NORM_LONG|wxPATH_NORM_DOTS|wxPATH_NORM_TILDE|wxPATH_NORM_ABSOLUTE);

        this->m_mra->m_dm.connect("localhost", wx2std(fname.GetFullPath(), &wxCSUTF8),
                          "SYSDBA", "masterkey", "", 
                          "UTF8", "", this->m_wleLogin->text().toUTF8(), this->m_wlePassword->text().toUTF8(), false);

        if (this->m_mra->m_dm.logged())
        {
          this->m_mra->m_login = this->m_wleLogin->text().toUTF8();
          this->m_mra->m_name = this->m_mra->m_dm.getName();
          this->m_mra->m_surname = this->m_mra->m_dm.getSurname();
          this->m_mra->m_hashpassword = this->m_mra->m_dm.getHashPassword();
          this->m_mra->m_serverName = "localhost";
          this->m_mra->m_databaseName = wx2std(fname.GetFullPath(), &wxCSUTF8);
          this->m_mra->m_userName = "SYSDBA";
          this->m_mra->m_userPassword = "masterkey";
          this->m_mra->m_roleName = "";
          this->m_mra->m_charSet = "UTF8";
          
          this->m_mra->changeStateOfMusicRobot(true);
          this->m_mra->isMusicRobotWorking = true;


          string sql = "SELECT URZ_URL, URZ_PARAM_SESJI, URZ_NAZWA_TABELI, URZ_PREFIKS_TABELI FROM MIR_URL_ZASOBU";
          this->m_mra->m_tr = this->m_mra->m_dm.createTransaction(amRead, ilReadCommitted, lrWait);
          this->m_mra->m_tr->Start();
          Statement st = this->m_mra->m_dm.createStatement(&this->m_mra->m_tr, &sql);
          st->Execute();
          string fieldVal, fieldVal2;
          MusicResSessionPar *mrsp;
          this->m_mra->m_wxServer.resize(0);
          while (st->Fetch())
          {
            st->Get(1, fieldVal);
            st->Get(2, fieldVal2);
            mrsp = new MusicResSessionPar(fieldVal, fieldVal2);
            st->Get(3, fieldVal);
            st->Get(4, fieldVal2);
            mrsp->setTableName(fieldVal);
            mrsp->setTablePrefix(fieldVal2);
            this->m_mra->m_wxServer.push_back(mrsp);
          }
          this->m_mra->m_tr->Commit();
          
          this->m_mra->m_wxdt.reserve(this->m_mra->m_wxServer.size());

          //try
          //{
          //  string str("<html><head><title>electric \"Nie ma\" @ legalez.nuta.pl </title><meta http-equiv=\"Content-Type\" content=\"text/html; charset=iso-8859-2\"><meta name=\"description\" content=\"Portal muzyczny Nuta.pl - Dobra Strona Muzyki\">");
          //  regex re("<meta.+http-equiv=\"Content-Type\".+content=(['\"])?.*charset=([-a-b0-9_]*)");
          //  boost::cmatch matches;
          //  if (boost::regex_match(str.c_str(), matches, re))
          //  {
          //   // matches[0] contains the original string.  matches[n]
          //   // contains a sub_match object for each matching
          //   // subexpression
          //    for (size_t i = 1; i < matches.size(); i++)
          //    {
          //      // sub_match::first and sub_match::second are iterators that
          //      // refer to the first and one past the last chars of the
          //      // matching subexpression
          //      string match(matches[i].first, matches[i].second);
          //      cout << "\tmatches[" << i << "] = " << match << endl;
          //    }
          //  }
          //}
          //catch(boost::regex_error& e)
          //{
          //  cout << e.what();
          //}

//          for(size_t i = 0; i < this->m_wxServer.size(); i++)
//          {
//            MusicResSessionPar mrsp = this->m_wxServer.at(i);
//
//            DownloadThread *dwnThr = new DownloadThread(wxTHREAD_JOINABLE, mrsp.getSessionParam());
//            {
//              wxMutexLocker wxml(dwnThr->m_downloadthread_m_wxuri_mutex);
//              dwnThr->m_wxuri = new wxURI(std2wx(mrsp.getMusicResource(), &wxConvUTF8));
//              dwnThr->m_musicResourceURI.Create(dwnThr->m_wxuri->BuildUnescapedURI());
//            }
//            dwnThr->m_tableName = mrsp.getTableName();
//            dwnThr->m_tablePrefix = mrsp.getTablePrefix();
//
//            this->copyLoginInfo(*dwnThr);
//
//            this->m_wxdt.push_back(dwnThr);
//
//            //this->m_wpbr.at(i) = NULL;
//            //this->m_wpbrTxt.at(i) = NULL;
//            //this->m_wpbrBr.at(3*i) = NULL;
//            //this->m_wpbrBr.at(3*i + 1) = NULL;
//            //this->m_wpbrBr.at(3*i + 2) = NULL;
//          }
          this->m_mra->setInternalPath("/start", true);
        } else {
          this->m_mra->setInternalPath("/login", true);
        }
      }

      void LoginPage::loginPage()
      {
        if (this->m_mra->m_login.compare(""))
        {
          this->m_mra->setInternalPath("/start", true);
          return;
        }

        this->m_mra->destroyAllWidgets();

        WContainerWidget *wcw = this->m_mra->root();

        this->m_wleLogin = new WLineEdit(wcw); // login
        this->m_wleLogin->setToolTip(WString("Type your login", UTF8));
        this->m_wleLogin->enterPressed().connect(this, &LoginPage::m_slt_wpbLogin);
        
        this->m_wlePassword = new WLineEdit(wcw); // password
        this->m_wlePassword->setEchoMode(WLineEdit::Password);
        this->m_wlePassword->setToolTip(WString("Type your password", UTF8));
        this->m_wlePassword->enterPressed().connect(this, &LoginPage::m_slt_wpbLogin);
        
        WPushButton *wpb = new WPushButton(WString("Login", UTF8), wcw);
        wpb->setToolTip(WString("Wykonaj logowanie", UTF8));
        wpb->clicked().connect(this, &LoginPage::m_slt_wpbLogin);

        //WFileResource *wfc = new WFileResource("text/html", "h:/opt/www/www.google.pl/index.html", (WObject *) wcw);
        //new WAnchor(wfc, "index.html", wcw);
      }
    }
  }
}
