#include <Wt/WApplication>
#include <Wt/WText>
#include <Wt/WProgressBar>
#include <Wt/WPushButton>
#include <Wt/WTimer>
#include <Wt/WTextArea>
#include <Wt/WAnchor>
#include <Wt/WMessageBox>
#include <Wt/WLabel>
#include <Wt/WContainerWidget>

#include "mir_stringutils.h"
#include "mir_mr_musicrobotapp.h"
#include "mir_mr_mainpage.h"

#include <ibpp.h>

namespace SyNaT
{
  namespace MIR 
  {
    namespace MR 
    {
      using namespace std;
      using namespace Wt;

      MainPage::MainPage(MusicRobotApp *mra) : m_mra(mra)
      {
      }

      void MainPage::m_slt_wpbDwnlStatus()
      {
        wApp->setInternalPath("/dwnlStatus", true);
      }

      void MainPage::m_slt_wpbDwnlSettings()
      {
        wApp->setInternalPath("/dwnlSettings", true);
      }

      void MainPage::m_slt_wpbDwnlPages()
      {
        wApp->setInternalPath("/dwnlPages", true);
      }

      void MainPage::m_slt_wpbLogout()
      {
        wApp->setInternalPath("/logout", true);
      }

      void MainPage::mainPage()
      {
        if (!this->m_mra->m_login.compare(""))
        {
          wApp->setInternalPath("/login", true);
          return;
        }

        this->m_mra->destroyAllWidgets();

        WContainerWidget *wcw = this->m_mra->root();
        
        WPushButton *wpb = new WPushButton(WString("Status of downloading", UTF8), wcw);
        wpb->setToolTip(WString("Przejdź do strony z postępem ściągania", UTF8));
        wpb->clicked().connect(this, &MainPage::m_slt_wpbDwnlStatus);
        new WText(WString("<br />", UTF8), XHTMLText, wcw);
        
        wpb = new WPushButton(WString("Settings", UTF8), wcw);
        wpb->setToolTip(WString("Przejdź do strony z ustawieniami ściągania", UTF8));
        wpb->clicked().connect(this, &MainPage::m_slt_wpbDwnlSettings);
        new WText(WString("<br />", UTF8), XHTMLText, wcw);
        
        wpb = new WPushButton(WString("Not used", UTF8), wcw);
        wpb->setToolTip(WString("Przejdź do strony z pobranymi plikami muzycznymi", UTF8));
        wpb->clicked().connect(this, &MainPage::m_slt_wpbDwnlPages);
        new WText(WString("<br />", UTF8), XHTMLText, wcw);

        wpb = new WPushButton(WString("Logout", UTF8), wcw);
        wpb->clicked().connect(this, &MainPage::m_slt_wpbLogout);

          //
          //if (!this->stopDownloading)
          //{
          //  this->wanchdwnlStatus->disable();
          //  this->wanchdwnlSettings->disable();
          //}

      }


    } // namespace MR
  } // namespace MIR
} // namespace SyNaT
