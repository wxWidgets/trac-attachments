//////////////////////////////////////////////////////////////////////////
//
// mir_charsvparser.cpp - char separated values parser
//
//////////////////////////////////////////////////////////////////////////
#include <Wt/WApplication>
#include <Wt/WLogger>

#include "wx/wxprec.h"

#include <iostream>

#include "mir_charsvparser.h"

using namespace std;

namespace SyNaT
{
  namespace MIR
  {
  bool CHARSVParser::HasMoreTokens() const
  {
      if ( this->m_string.length() > 0)
      {
          if ( this->m_pos >= this->m_string.length())
              return false;

          if ( this->m_string.find_first_not_of(this->m_separator, this->m_pos) != wxString::npos )
              // there are non delimiter characters left, so we do have more tokens
              return true;

          if (this->m_string[this->m_pos] == wxT('\n'))
              return false;
      }
      return this->m_pos == 0 && !this->m_string.empty();
  }

  wxString CHARSVParser::GetNextToken()
  {
      wxString token;

      if ( !HasMoreTokens() )
          return token;

      // skip leading blanks if not quoted.
      while (this->m_pos < this->m_string.length() && this->m_string[this->m_pos] == wxT(' '))
          this->m_pos ++;

      // Are we a quoted field?  Must handle this special.
      bool quoted_string = (this->m_string[this->m_pos] == this->m_quote);
      bool inquote = false;

      size_t pos = this->m_pos;

      // find the end of this token.
      for (; pos < this->m_string.length(); pos++)
      {
          if (quoted_string && this->m_string[pos] == this->m_quote)
              inquote = !inquote;

          if (!inquote)
          {
              // Check to see if we have found the end of this token.
              // Tokens normally end with a m_separator delimiter.
              if (this->m_string[pos] == this->m_separator)
                  break;

              // Last token is delimited by '\n' or by end of string.
              if (this->m_string[pos] == wxT('\n') && pos == this->m_string.length()-1)
                  break;
          }
      }

      if (quoted_string && !inquote)
      {
          token.assign(this->m_string, this->m_pos + 1, pos - this->m_pos - 2);  // Remove leading and trailing quotes

          // Remove double quote chars, replace with single quote chars
          token.Replace(wxString(this->m_quote) + wxString(this->m_quote), this->m_quote, true);
      }
      else
          token.assign(this->m_string, this->m_pos, pos - this->m_pos);

      if (quoted_string && inquote)
        wApp->log("error") << (wxString::Format(wxT("unterminated quoted string: %s\n"), token.c_str())).c_str();

      this->m_pos = pos + 1;    // Skip token and delimiter

      if (this->m_pos > this->m_string.length())  // Perhaps no delimiter if at end of string if orig string didn't have '\n'.
          this->m_pos = this->m_string.length();

      return token;
    }
  }
}