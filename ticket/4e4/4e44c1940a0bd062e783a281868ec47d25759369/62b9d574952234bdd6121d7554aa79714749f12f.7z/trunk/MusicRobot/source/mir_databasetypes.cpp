﻿#include <Wt/WApplication>
#include <Wt/WLogger>


// For compilers that support precompilation, includes "wx/wx.h".
#include <wx/wxprec.h>

#ifdef __BORLANDC__
    #pragma hdrstop
#endif

// for all others, include the necessary headers (this file is usually all you
// need because it includes almost all "standard" wxWidgets headers
#ifndef WX_PRECOMP
    #include "wx/wx.h"
#endif

#include <boost/foreach.hpp>
#include <boost/regex.hpp>
#include <boost/ptr_container/ptr_vector.hpp>

#include <string>

#include "mir_stringutils.h"
#include "mir_sha1.h"
#include "mir_exceptions.h"
#include "mir_databasetypes.h"
#include "mir_databasemodule.h"

#include <ibpp.h>

namespace SyNaT
{
  namespace MIR
  {

    using namespace std;
    using namespace IBPP;

    DBField::DBField() : m_dbfType(NONET), m_null(true), m_dbFieldName((char *) 0) // isNull() - not applicable
    {
    }

    DBField::DBField(DBFieldType fieldType, const char *name)
      : m_dbfType(fieldType), m_null(true), m_dbFieldName((char *) 0)
    {
      if (name)
      {
        this->m_dbFieldName = (char *) realloc(this->m_dbFieldName, strlen(name) + 1);
        strcpy(this->m_dbFieldName, name);
      }
    }

    DBField::~DBField()
    {
      if (this->m_dbFieldName)
      {
        free(this->m_dbFieldName);
      }
    }

    void DBField::setNull(bool isNull)
    {
      this->m_null = isNull;
    }

    bool DBField::isNull()
    {
      return this->m_null;
    }

    DBFieldType DBField::getDBFieldType()
    {
      return this->m_dbfType;
    }

    string DBField::getAsDBString()
    {
      if (this->isNull())
        return "NULL";
      return "";
    }

    string DBField::getFieldName()
    {
      return this->m_dbFieldName;
    }
    
    void DBField::setFieldName(const char *name)
    {
      if (name)
      {
        this->m_dbFieldName =  (char *) realloc(this->m_dbFieldName, strlen(name));
        strcpy(this->m_dbFieldName, name);
      }
    }

    BoolDBField::BoolDBField()
      : DBField(BOOLT), m_value(false)
    {
      this->setNull(true);
    }

    BoolDBField::BoolDBField(const char *name)
      : DBField(BOOLT, name), m_value(false)
    {
    }

    BoolDBField::BoolDBField(const string &name)
      : DBField(BOOLT, name.c_str()), m_value(false)
    {
    }

    BoolDBField::BoolDBField(bool val, const char *name)
      : DBField(BOOLT, name), m_value(val)
    {
      this->setNull(false);
    }

    BoolDBField::BoolDBField(bool val, const string &name)
      : DBField(BOOLT, name.c_str()), m_value(val)
    {
      this->setNull(false);
    }

    void BoolDBField::getValue(bool& val)
    {
      val = this->m_value;
    }

    void BoolDBField::setValue(bool val)
    {
      this->m_value = val;
      this->setNull(false);
    }

    string BoolDBField::getAsDBString()
    {
      if (this->isNull())
        return "NULL";
      if (this->m_value)
        return "'T'";
      else 
        return "'F'";
    }

    VOIDPDBField::VOIDPDBField() 
      : DBField(VOIDP), m_value((void *) 0), m_size(0)
    {
    }

    VOIDPDBField::VOIDPDBField(const char *name)
      : DBField(VOIDP, name), m_value((void *) 0), m_size(0)
    {
    }

    VOIDPDBField::VOIDPDBField(const string &name)
      : DBField(VOIDP, name.c_str()), m_value((void *) 0), m_size(0)
    {
    }

    VOIDPDBField::VOIDPDBField(const void *val, int size, const char *name)
      : DBField(VOIDP, name), m_value((void *) 0), m_size(0)
    {
      this->setValue(val, size);
    }

    VOIDPDBField::VOIDPDBField(const void *val, int size, const string &name)
      : DBField(VOIDP, name.c_str()), m_value((void *) 0), m_size(0)
    {
      this->setValue(val, size);
    }

    VOIDPDBField::~VOIDPDBField()
    {
      if (this->m_value)
        free(this->m_value);
    }

    /**
     * Caller must free() the (re)allocated memory
     * @param val - must be 0 (c null pointer) or valid memory pointer allocated by malloc/realloc
     */
    void VOIDPDBField::getValue(void *&val, int &size)
    {
      if(this->isNull())
      {
        size = 0;
        return;
      }
      val = realloc(val, this->m_size);
      val = memcpy(val, this->m_value, this->m_size);
      size = this->m_size;
      this->setNull(false);
    }

    /*
     * @param size is a buffer lenght (not including ending c-string 0 if it is present)
     */
    void VOIDPDBField::setValue(const void *val, int size)
    {
      if (!val)
      {
        if (this->m_value)
        {
          free(this->m_value);
          this->m_value = (void *) 0;
        }
        this->m_size = 0;
        this->setNull(true);
        return;
      }
      if (this->m_size != size)
        this->m_value = realloc(this->m_value, size);
      this->m_value = memcpy(this->m_value, val, size);
      this->m_size = size;
      this->setNull(false);
    }

    string VOIDPDBField::getAsDBString()
    {
      if (this->isNull())
        return "NULL";
      return "";
    }


    CHARPDBField::CHARPDBField() 
      : DBField(CHARP), m_value((unsigned char *) 0), m_size(0)
    {
    }

    CHARPDBField::CHARPDBField(const char *name)
      : DBField(CHARP, name), m_value((unsigned char *) 0), m_size(0)
    {
    }

    CHARPDBField::CHARPDBField(const string &name)
      : DBField(CHARP, name.c_str()), m_value((unsigned char *) 0), m_size(0)
    {
    }

    CHARPDBField::CHARPDBField(const unsigned char *val, const char *name)
      : DBField(CHARP, name), m_value((unsigned char *) 0), m_size(0)
    {
      this->setValue(val);
    }

    CHARPDBField::CHARPDBField(const unsigned char *val, const string &name)
      : DBField(CHARP, name.c_str()), m_value((unsigned char *) 0), m_size(0)
    {
      this->setValue(val);
    }


    CHARPDBField::~CHARPDBField()
    {
      if (this->m_value)
        free(this->m_value);
    }


    /**
     * Caller must free() the (re)allocated memory
     * @param val - must be 0 (c null pointer) or valid memory pointer
     */
    void CHARPDBField::getValue(unsigned char *&val)
    {
      if(this->isNull())
        return;
      val = (unsigned char *) realloc((void *) val, this->m_size);
      val = (unsigned char *) memcpy((void *) val, (void *) this->m_value, this->m_size);
    }

    void CHARPDBField::setValue(const unsigned char *val)
    {
      if (!val)
      {
        if (this->m_value)
        {
          free(this->m_value);
          this->m_value = (unsigned char *) 0;
        }
        this->m_size = 0;
        this->setNull(true);
        return;
      }
      size_t vallen = strlen((const char *) val) + 1;
      if (this->m_size != vallen)
        this->m_value = (unsigned char *) realloc((void *) this->m_value, vallen);
      this->m_value = (unsigned char *) memcpy((void *) this->m_value, val, vallen);
      this->m_size = vallen;
      this->setNull(false);
    }

    string CHARPDBField::getAsDBString()
    {
      if (this->isNull())
        return "NULL";
      return "";
    }

    StringDBField::StringDBField()
      : DBField(STRINGT), m_value("")
    {
    }

    /*
     */
    StringDBField::StringDBField(const char *name)
      : DBField(STRINGT, name), m_value("")
    {
    }

    /*
     */
    StringDBField::StringDBField(const string &name)
      : DBField(STRINGT, name.c_str()), m_value("")
    {
    }

    /*
     * @param val - string z kodowaniem UTF8
     */
    StringDBField::StringDBField(const string &val, const char *name)
      : DBField(STRINGT, name), m_value(val)
    {
      this->setNull(false);
    }

    /*
     * @param val - string z kodowaniem UTF8
     */
    StringDBField::StringDBField(const string &val, const string &name)
      : DBField(STRINGT, name.c_str()), m_value(val)
    {
      this->setNull(false);
    }

    /*
     * @param val string w kodowaniu UTF8
     */
    void StringDBField::getValue(string& val)
    {
      val = this->m_value;
    }

    
    /*
     * @param val string w kodowaniu UTF8
     */
    void StringDBField::setValue(const string& val)
    {
      this->m_value = val;
      this->setNull(false);
    }

    
    /*
     * @return string w kodowaniu UTF8
     */
    string StringDBField::getAsDBString()
    {
      if (this->isNull())
        return "NULL";
       return "'" + boost::regex_replace(this->m_value, DatabaseModule::mcs_regex, "''") + "'";
    }


    INT16TDBField::INT16TDBField() 
      : DBField(INT16_T), m_value(0)
    {
    }

    INT16TDBField::INT16TDBField(const char *name)
      : DBField(INT16_T, name), m_value(0)
    {
    }

    INT16TDBField::INT16TDBField(const string &name)
      : DBField(INT16_T, name.c_str()), m_value(0)
    {
    }

    INT16TDBField::INT16TDBField(int16_t val, const char *name)
      : DBField(INT16_T, name), m_value(val)
    {
      this->setNull(false);
    }

    INT16TDBField::INT16TDBField(int16_t val, const string &name)
      : DBField(INT16_T, name.c_str()), m_value(val)
    {
      this->setNull(false);
    }

    void INT16TDBField::getValue(int16_t &val)
    {
      val = this->m_value;
    }

    void INT16TDBField::setValue(int16_t val)
    {
      this->m_value = val;
      this->setNull(false);
    }

    string INT16TDBField::getAsDBString()
    {
      if (this->isNull())
        return "NULL";
      ostringstream oss;
      oss << this->m_value;
      return oss.str();
    }

    INT32TDBField::INT32TDBField() 
      : DBField(INT32_T), m_value(0)
    {
    }

    INT32TDBField::INT32TDBField(const char *name)
      : DBField(INT32_T, name), m_value(0)
    {
    }

    INT32TDBField::INT32TDBField(const string &name)
      : DBField(INT32_T, name.c_str()), m_value(0)
    {
    }

    INT32TDBField::INT32TDBField(int32_t val, const char *name)
      : DBField(INT32_T, name), m_value(val)
    {
      this->setNull(false);
    }

    INT32TDBField::INT32TDBField(int32_t val, const string &name)
      : DBField(INT32_T, name.c_str()), m_value(val)
    {
      this->setNull(false);
    }

    void INT32TDBField::getValue(int32_t &val)
    {
      val = this->m_value;
    }

    void INT32TDBField::setValue(int32_t val)
    {
      this->m_value = val;
      this->setNull(false);
    }

    string INT32TDBField::getAsDBString()
    {
      if (this->isNull())
        return "NULL";
      ostringstream oss; 
      oss << this->m_value; 
      return oss.str(); 
    }



    INT64TDBField::INT64TDBField() 
      : DBField(INT64_T), m_value(0)
    {
    }

    INT64TDBField::INT64TDBField(const char *name)
      : DBField(INT64_T, name), m_value(0)
    {
    }

    INT64TDBField::INT64TDBField(const string &name)
      : DBField(INT64_T, name.c_str()), m_value(0)
    {
    }

    INT64TDBField::INT64TDBField(int64_t val, const char *name)
      : DBField(INT64_T, name), m_value(val)
    {
      this->setNull(false);
    }

    INT64TDBField::INT64TDBField(int64_t val, const string &name)
      : DBField(INT64_T, name.c_str()), m_value(val)
    {
      this->setNull(false);
    }

    void INT64TDBField::getValue(int64_t &val)
    {
      val = this->m_value;
    }

    void INT64TDBField::setValue(int64_t val)
    {
      this->m_value = val;
      this->setNull(false);
    }

    string INT64TDBField::getAsDBString()
    {
      if (this->isNull())
        return "NULL";
      ostringstream oss; 
      oss << this->m_value; 
      return oss.str(); 
    }


    FloatDBField::FloatDBField()
      : DBField(FLOATT), m_value(0)
    {
    }

    FloatDBField::FloatDBField(const char *name)
      : DBField(FLOATT, name), m_value(0)
    {
    }

    FloatDBField::FloatDBField(const string &name)
      : DBField(FLOATT, name.c_str()), m_value(0)
    {
    }

    FloatDBField::FloatDBField(float val, const char *name)
      : DBField(FLOATT, name), m_value(val)
    {
      this->setNull(false);
    }

    FloatDBField::FloatDBField(float val, const string &name)
      : DBField(FLOATT, name.c_str()), m_value(val)
    {
      this->setNull(false);
    }

    void FloatDBField::getValue(float &val)
    {
      val = this->m_value;
    }

    void FloatDBField::setValue(float val)
    {
      this->m_value = val;
      this->setNull(false);
    }

    string FloatDBField::getAsDBString()
    {
      if (this->isNull())
        return "NULL";
      ostringstream oss;
      oss << this->m_value;
      return oss.str();
    }


    DoubleDBField::DoubleDBField() 
      : DBField(DOUBLET), m_value(0)
    {
    }

    DoubleDBField::DoubleDBField(const char *name)
      : DBField(DOUBLET, name), m_value(0)
    {
    }

    DoubleDBField::DoubleDBField(const string &name)
      : DBField(DOUBLET, name.c_str()), m_value(0)
    {
    }

    DoubleDBField::DoubleDBField(double val, const char *name)
      : DBField(DOUBLET, name), m_value(val)
    {
      this->setNull(false);
    }

    DoubleDBField::DoubleDBField(double val, const string &name)
      : DBField(DOUBLET, name.c_str()), m_value(val)
    {
      this->setNull(false);
    }

    void DoubleDBField::getValue(double &val)
    {
      val = this->m_value;
    }

    void DoubleDBField::setValue(double val)
    {
      this->m_value = val;
      this->setNull(false);
    }

    string DoubleDBField::getAsDBString()
    {
      if (this->isNull())
        return "NULL";
      ostringstream oss;
      oss << this->m_value;
      return oss.str();
    }



    TimestampDBField::TimestampDBField() 
      : DBField(TIMESTAMPT)
    {
    }

    TimestampDBField::TimestampDBField(const char *name)
      : DBField(TIMESTAMPT, name)
    {
    }

    TimestampDBField::TimestampDBField(const string &name)
      : DBField(TIMESTAMPT, name.c_str())
    {
    }

    TimestampDBField::TimestampDBField(const Timestamp &val, const char *name)
      : DBField(TIMESTAMPT, name), m_value(val)
    {
      this->setNull(false);
    }

    TimestampDBField::TimestampDBField(const Timestamp &val, const string &name)
      : DBField(TIMESTAMPT, name.c_str()), m_value(val)
    {
      this->setNull(false);
    }

    TimestampDBField::TimestampDBField(int y, int m, int d, int h, int min, int s, int ms, const char *name) 
      : DBField(TIMESTAMPT, name)
    {
      Timestamp ts(y, m, d, h, min, s, ms);
      this->m_value.SetDate(ts.GetDate());
      this->m_value.SetTime(ts.GetTime());
      this->setNull(false);
    }

    TimestampDBField::TimestampDBField(int y, int m, int d, int h, int min, int s, int ms, const string &name) 
      : DBField(TIMESTAMPT, name.c_str())
    {
      Timestamp ts(y, m, d, h, min, s, ms);
      this->m_value.SetDate(ts.GetDate());
      this->m_value.SetTime(ts.GetTime());
      this->setNull(false);
    }

    void TimestampDBField::getValue(Timestamp &val)
    {
      val = this->m_value;
    }

    void TimestampDBField::setValue(const Timestamp &val)
    {
      this->m_value = val;
      this->setNull(false);
    }

    string TimestampDBField::getAsDBString()
    {
      if (this->isNull())
        return "NULL";
      ostringstream oss;
      oss << "'" << this->m_value.Year() << "-" << this->m_value.Month() << "-" 
        << this->m_value.Day() << " " << this->m_value.Hours() << ":" << this->m_value.Minutes()
        << ":" << this->m_value.Seconds() << ":" << this->m_value.SubSeconds() << "'";
      return oss.str();      
    }



    DateDBField::DateDBField() 
      : DBField(DATET)
    {
    }

    DateDBField::DateDBField(const char *name)
      : DBField(DATET, name)
    {
    }

    DateDBField::DateDBField(const string &name)
      : DBField(DATET, name.c_str())
    {
    }

    DateDBField::DateDBField(const Date &val, const char *name)
      : DBField(DATET, name), m_value(val)
    {
      this->setNull(false);
    }

    DateDBField::DateDBField(const Date &val, const string &name)
      : DBField(DATET, name.c_str()), m_value(val)
    {
      this->setNull(false);
    }

    DateDBField::DateDBField(int y, int m, int d, const char *name)
      : DBField(DATET, name)
    {
      Date dt(y, m, d);
      this->m_value.SetDate(dt.GetDate());
      this->setNull(false);
    }

    DateDBField::DateDBField(int y, int m, int d, const string &name)
      : DBField(DATET, name.c_str())
    {
      Date dt(y, m, d);
      this->m_value.SetDate(dt.GetDate());
      this->setNull(false);
    }


    void DateDBField::getValue(Date &val)
    {
      val = this->m_value;
    }

    void DateDBField::setValue(const Date &val)
    {
      this->m_value = val;
      this->setNull(false);
    }

    string DateDBField::getAsDBString()
    {
      if (this->isNull())
        return "NULL";
      ostringstream oss;
      oss << "'" << this->m_value.Year() << "-" << this->m_value.Month() << "-" 
        << this->m_value.Day() << "'";
      return oss.str();
    }


    TimeDBField::TimeDBField() 
      : DBField(TIMET)
    {
    }

    TimeDBField::TimeDBField(const char *name)
      : DBField(TIMET, name)
    {
    }

    TimeDBField::TimeDBField(const string &name)
      : DBField(TIMET, name.c_str())
    {
    }

    TimeDBField::TimeDBField(const Time &val, const char *name)
      : DBField(TIMET, name), m_value(val)
    {
      this->setNull(false);
    }

    TimeDBField::TimeDBField(const Time &val, const string &name)
      : DBField(TIMET, name.c_str()), m_value(val)
    {
      this->setNull(false);
    }

    TimeDBField::TimeDBField(int h, int min, int s, int ms, const char *name)
      : DBField(TIMESTAMPT, name)
    {
      Time ti(h, min, s, ms);
      this->m_value.SetTime(ti.GetTime());
      this->setNull(false);
    }

    TimeDBField::TimeDBField(int h, int min, int s, int ms, const string &name)
      : DBField(TIMESTAMPT, name.c_str())
    {
      Time ti(h, min, s, ms);
      this->m_value.SetTime(ti.GetTime());
      this->setNull(false);
    }


    void TimeDBField::getValue(Time &val)
    {
      val = this->m_value;
    }

    void TimeDBField::setValue(const Time &val)
    {
      this->m_value = val;
      this->setNull(false);
    }

    string TimeDBField::getAsDBString()
    {
      if (this->isNull())
        return "NULL";
      ostringstream oss;
      oss << "'" << this->m_value.Hours() << ":" << this->m_value.Minutes()
        << ":" << this->m_value.Seconds() << ":" << this->m_value.SubSeconds() << "'";
      return oss.str();
    }


    BlobDBField::BlobDBField() 
      : DBField(BLOBT)
    {
    }

    BlobDBField::BlobDBField(const char *name)
      : DBField(BLOBT, name)
    {
    }

    BlobDBField::BlobDBField(const string &name)
      : DBField(BLOBT, name.c_str())
    {
    }

    BlobDBField::BlobDBField(const Blob &val, const char *name)
      : DBField(BLOBT, name), m_value(val)
    {
      this->setNull(false);
    }

    BlobDBField::BlobDBField(const Blob &val, const string &name)
      : DBField(BLOBT, name.c_str()), m_value(val)
    {
      this->setNull(false);
    }

    void BlobDBField::getValue(Blob &val)
    {
      val = this->m_value;
    }

    void BlobDBField::setValue(const Blob &val)
    {
      this->m_value = val;
      this->setNull(false);
    }
  } // namespace MIR
} // namespace SyNaT