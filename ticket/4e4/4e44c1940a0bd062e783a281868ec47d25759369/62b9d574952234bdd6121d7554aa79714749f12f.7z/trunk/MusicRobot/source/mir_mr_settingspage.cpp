#include <Wt/WApplication>
#include <Wt/WText>
#include <Wt/WProgressBar>
#include <Wt/WPushButton>
#include <Wt/WTimer>
#include <Wt/WTextArea>
#include <Wt/WAnchor>
#include <Wt/WMessageBox>
#include <Wt/WLabel>
#include <Wt/WLogger>

// For compilers that support precompilation, includes "wx/wx.h".
#include <wx/wxprec.h>

#ifdef __BORLANDC__
    #pragma hdrstop
#endif

// for all others, include the necessary headers (this file is usually all you
// need because it includes almost all "standard" wxWidgets headers
#ifndef WX_PRECOMP
    #include "wx/wx.h"
#endif

//#include <wx/tokenzr.h>
#include <wx/filename.h>
#include <wx/platinfo.h>
#include <wx/uri.h>

#include <boost/foreach.hpp>
#include <boost/ptr_container/ptr_vector.hpp>
#include <boost/ptr_container/ptr_set.hpp>
#include <boost/thread/mutex.hpp>
#include <boost/thread.hpp>

#include <string>
#include <iomanip>

#include "mir_defines.h"
#include "mir_utils.h"
#include "mir_stringutils.h"
#include "mir_contenttyperetriever.h"
#include "mir_exceptions.h"
#include "mir_boostfilesystemremoveall.h"
#include "mir_databasetypes.h"
#include "mir_databasemodule.h"
#include "mir_mr_musicrobotapp.h"
#include "mir_mr_settingspage.h"

#include <ibpp.h>


namespace SyNaT
{
  namespace MIR
  {
    namespace MR
    {
      using namespace std;
      using namespace IBPP;

      SettingsPage::SettingsPage(MusicRobotApp *mra) : m_mra(mra)
      {
      }

      void SettingsPage::destroyAllWidgets()
      {
        WContainerWidget *wcw = this->m_mra->root();
        BOOST_FOREACH(WWidget &widget, this->m_wleServers)
        {
          wcw->removeWidget(&widget);
        }
        this->m_wleServers.resize(0);

        BOOST_FOREACH(WWidget &widget, this->m_wsettingsBr)
        {
          wcw->removeWidget(&widget);
        }
        this->m_wsettingsBr.resize(0);
      }

      /* wpbServers slot */
      void SettingsPage::m_slt_wpbSave()
      {
        if (!this->m_mra->m_stopDownloading)
        {
          return;
        }

        wxCSConv wxCSUTF8(wxFONTENCODING_UTF8);

        this->getMusicServers(); // fills this->m_wxServer
  
        this->m_mra->DownloadThreadsRecreate(); // gdy to wyw. było na końcu funkcji przed setInternalPath
                                         // to transakcje w DownloadThread byly stworzone
                                         // (ale commitowane) i nie pozwalaly zrzucic (DROP) tabeli
                                         // MIR_SERWXXXXX

        Transaction tr = this->m_mra->m_dm.createTransaction(amWrite, ilReadCommitted, lrWait);

        wxFileName fncwd;
        {
          boost::lock_guard<boost::mutex> lock(DownloadThread::ms_downloadthread_wxWidgetsFuncs_mutex);
          fncwd.Assign(wxFileName::GetCwd());
        }
        wxString volPostfix;
        if (this->m_mra->mcs_wxosid & wxOS_WINDOWS)
          volPostfix = wxT(":");

        wxFileName fname(fncwd.GetVolume() + volPostfix + fncwd.GetVolumeSeparator(wxPATH_UNIX) + wxT(MIR_PATH_TO_WWW_DIR), wxPATH_UNIX);
        fname.Normalize(wxPATH_NORM_LONG|wxPATH_NORM_DOTS|wxPATH_NORM_TILDE|wxPATH_NORM_ABSOLUTE);

        tr->Start();

        Statement stmt = this->m_mra->m_dm.createStatement(&tr);

        int i = 0;
        boost::ptr_vector<DBField> fields;
        boost::ptr_set<int64_t> IDs; // klucze glowne tabeli MIR_URL_ZASOBU, ktore maja pozostac w bazie

        //boost::ptr_vector<int> serwSeq;
        int serwSeqNum;
        int64_t id;

        ostringstream oss;

        ostringstream osssql;

        string tableName, tablePrefix, musicResource, sessionParam;
        wxURI wxMusicResourceUri;
        wxString wxProtSerw, wxMusicResource, wxEscapedURI;

        BOOST_FOREACH(MusicResSessionPar &mrsp, this->m_mra->m_wxServer)
        {
          fields.resize(0);
          fields.reserve(4);
          musicResource = mrsp.getMusicResource();
          sessionParam = mrsp.getSessionParam();

          wxMusicResourceUri.Create(std2wx(musicResource, &wxCSUTF8));

          wxEscapedURI = wxMusicResourceUri.GetScheme() + wxT("://");
          if (wxMusicResourceUri.HasUserInfo())
          {
            wxEscapedURI += wxMusicResourceUri.GetUser();
            if (!wxMusicResourceUri.GetPassword().IsEmpty())
              wxEscapedURI += wxT(":") + wxMusicResourceUri.GetPassword();
            wxEscapedURI += wxT("@");
          }
          wxEscapedURI += wxMusicResourceUri.GetServer();
          if (!wxMusicResourceUri.HasPath())
            wxEscapedURI += wxT("/"); // here i prepend /
          else
            wxEscapedURI += wxMusicResourceUri.GetPath();

          if (wxMusicResourceUri.HasQuery())
            wxEscapedURI += wxT("?") + wxMusicResourceUri.GetQuery();
          if (wxMusicResourceUri.HasFragment())
            wxEscapedURI += wxT("#") + wxMusicResourceUri.GetFragment();

          wxMusicResourceUri.Create(wxEscapedURI);
          wxEscapedURI = wxMusicResourceUri.BuildURI();

          mrsp.setMusicResource(wx2std(wxEscapedURI, &wxCSUTF8));
          musicResource = mrsp.getMusicResource();

          wxProtSerw = wxMusicResourceUri.GetScheme() + wxT("://");
          if (wxMusicResourceUri.HasUserInfo())
          {
            wxProtSerw += wxMusicResourceUri.GetUser();
            if (!wxMusicResourceUri.GetPassword().IsEmpty())
              wxProtSerw += wxT(":") + wxMusicResourceUri.GetPassword();

            wxProtSerw +=  wxT("@");
          }
          wxProtSerw += wxMusicResourceUri.GetServer();

          oss.str("");
          oss << "SELECT URZ_ID, URZ_NAZWA_TABELI, URZ_PREFIKS_TABELI FROM MIR_URL_ZASOBU WHERE URZ_URL SIMILAR TO " 
              << "'" << DatabaseModule::toSimilarToSql(wx2std(wxProtSerw, &wxCSUTF8), false)
              << "_*'" << " ESCAPE '\\'";

          fields.push_back(new StringDBField(musicResource, "URZ_URL"));
          fields.push_back(new StringDBField(sessionParam, "URZ_PARAM_SESJI"));

          stmt->Execute(oss.str());
          id = 0;
          if (stmt->Fetch())
          {
            stmt->Get(1, id);
            stmt->Get(2, tableName);
            stmt->Get(3, tablePrefix);
            mrsp.setTableName(tableName);
            mrsp.setTablePrefix(tablePrefix);
            fields.push_back(new StringDBField(tableName, "URZ_NAZWA_TABELI"));
            fields.push_back(new StringDBField(tablePrefix, "URZ_PREFIKS_TABELI"));
          } 
          else 
          {

            oss.str("");
            oss << "SELECT DISTINCT URZ_PREFIKS_TABELI FROM MIR_URL_ZASOBU ORDER BY URZ_NAZWA_TABELI ASC";
            stmt->Execute(oss.str());
            while (stmt->Fetch())
            {
              stmt->Get(1, tableName);
              istringstream iss(tableName.substr(3));
              iss >> serwSeqNum;
              if (serwSeqNum != i)
                break;
              else
                i++;
            }                

            oss.str("");
            oss << "MIR_SERW" << setw(5) << setfill('0') << i;

            fields.push_back(new StringDBField(oss.str(), "URZ_NAZWA_TABELI"));
            mrsp.setTableName(oss.str());
            oss.str("");
            oss << "SRW" << setw(5) << setfill('0') << i;
            mrsp.setTablePrefix(oss.str());
            fields.push_back(new StringDBField(oss.str(), "URZ_PREFIKS_TABELI"));
          }

          try 
          {
            id = this->m_mra->m_dm.insertIntoTable("URZ", "MIR_URL_ZASOBU", fields, &tr);
            IDs.insert(new int64_t(id));
          }
          catch(IBPP::Exception &) // wyj±tek zwykle gdy proba zapisania tego samego URZ_URL 
          {
            if (id == 0)
            {
              osssql.str("");
              osssql << "SELECT URZ_ID, URZ_NAZWA_TABELI, URZ_PREFIKS_TABELI FROM MIR_URL_ZASOBU WHERE URZ_URL SIMILAR TO " 
                     << "'" << DatabaseModule::toSimilarToSql(wx2std(wxProtSerw, &wxCSUTF8), false)
                     << "_*'" << " ESCAPE '\\'";
              stmt->Execute(osssql.str());
              if (stmt->Fetch())
              {
                stmt->Get(1, id);
                stmt->Get(2, tableName);
                stmt->Get(3, tablePrefix);
                mrsp.setTableName(tableName);
                mrsp.setTablePrefix(tablePrefix);
              }
            }
            IDs.insert(new int64_t(id));
            fields.resize(0);
            fields.push_back(new StringDBField(mrsp.getSessionParam(), "URZ_PARAM_SESJI"));
            this->m_mra->m_dm.updateTable(id, "URZ", "MIR_URL_ZASOBU", fields, &tr);
          }
        }
        tr->Commit();

        osssql.str("");
        osssql << "URZ_ID NOT IN (0,";
        BOOST_FOREACH(id, IDs) 
        {
          osssql << id << ",";
        }
        string osssqlstr = osssql.str();
        osssqlstr = osssqlstr.substr(0, osssqlstr.size()-1) +")";

        boost::ptr_vector<string> tableNames;    // nazwy table, ktore nie maja pozostac w bazie
        boost::ptr_vector<string> tablePrefixes; // prefiksy table, ktore nie maja pozostac w bazie

        tr = this->m_mra->m_dm.createTransaction(amWrite, ilReadCommitted, lrWait);
        tr->Start();
        oss.str("");
        oss << "SELECT URZ_URL, URZ_NAZWA_TABELI, URZ_PREFIKS_TABELI FROM MIR_URL_ZASOBU WHERE " << osssqlstr;
        string sql = oss.str();
        stmt = this->m_mra->m_dm.createStatement(&tr, &sql);
        wxURI uri;
        string url;
        wxString dirName, uriPath;
        stmt->Execute();
        while(stmt->Fetch())
        {
          stmt->Get(2, tableName);
          stmt->Get(1, url);
          uri.Create(std2wx(url, &wxCSUTF8));
          dirName = fname.GetFullPath() + Utils::subAllNotAllowedCharsInFilenames(uri.GetServer());
          uriPath = uri.GetPath();
          uriPath.Replace(wxT("%"), wxT(""));
          dirName += Utils::subAllNotAllowedCharsInFilenames(uriPath.Mid(0, uriPath.Find('/', true) + 1), false);
          wxFileName fnametmp(dirName);
          fnametmp.Normalize(wxPATH_NORM_LONG|wxPATH_NORM_DOTS|wxPATH_NORM_TILDE|wxPATH_NORM_ABSOLUTE);

          // sprawdzam czy dirName nie jest równe MIR_PATH_TO_WWW_DIR + "/var/www/"
          if (dirName.Cmp(fname.GetFullPath()))
          {
            string dirNameStd = wx2std(fnametmp.GetFullPath(), &wxCSUTF8);

            try
            {
              BoostFilesystemRemoveAll bfr;
              boost::thread t(bfr, dirNameStd);
              t.detach();
            }
            catch(...)
            {
              wApp->log("error") << "Cannot delete the directory " << dirNameStd;
            }
          }

          tableNames.push_back(new string(tableName));
          stmt->Get(3, tablePrefix);
          tablePrefixes.push_back(new string(tablePrefix));
          oss.str("");
          oss << "(1 = 1)";
          BOOST_FOREACH(MusicResSessionPar &mrsp, this->m_mra->m_wxServer)
          {
            musicResource = mrsp.getMusicResource();

            wxMusicResourceUri.Create(std2wx(musicResource, &wxCSUTF8));

            wxProtSerw = wxMusicResourceUri.GetScheme() + wxT("://");
            if (wxMusicResourceUri.HasUserInfo())
            {
              wxProtSerw += wxMusicResourceUri.GetUser();
              if (!wxMusicResourceUri.GetPassword().IsEmpty())
                wxProtSerw += wxT(":") + wxMusicResourceUri.GetPassword();

              wxProtSerw +=  wxT("@");
            }
            wxProtSerw += wxMusicResourceUri.GetServer();
            if (wxMusicResourceUri.HasPath())
            {
              wxString wxMusicResourceUriPath = wxMusicResourceUri.GetPath();
              if (wxMusicResourceUriPath.EndsWith(wxT("/")))
                wxProtSerw += wxMusicResourceUriPath;
              else
                wxProtSerw += wxMusicResourceUriPath.Mid(0, wxMusicResourceUriPath.Find('/', true) + 1);
            }
            oss << " AND " << tablePrefix << "_ODW_URL"
                << " NOT SIMILAR TO " 
                << "'" << DatabaseModule::toSimilarToSql(wx2std(wxProtSerw, &wxCSUTF8), false)
                << "_*'" << " ESCAPE '\\'";
          }
          ostringstream osql2;
          osql2 << "SELECT " << tablePrefix << "_ID FROM " << tableName << " WHERE " << oss.str();
          string sql2 = osql2.str();
          osql2.str("");
          osql2 << tablePrefix << "_SZA_S_" << tablePrefix << "_ID IN ("
                << "SELECT " << tablePrefix << "_ID FROM " << tableName << " WHERE " << oss.str()
                << ")";
          this->m_mra->m_dm.deleteFromTable(osql2.str(), tablePrefix + "_SZA", tableName + "_STR_Z_AUD", &tr);
          this->m_mra->m_dm.deleteFromTable(oss.str(), tablePrefix, tableName, &tr);
        }
        tr->Commit();
        tr = this->m_mra->m_dm.createTransaction(amWrite, ilReadCommitted, lrWait);
        tr->Start();
        stmt = this->m_mra->m_dm.createStatement(&tr);
        bool dropTable, dropProcAndSeq;
        BOOST_FOREACH(tableName, tableNames) 
        {
          dropTable = true;
          BOOST_FOREACH(MusicResSessionPar &mrsp, this->m_mra->m_wxServer)
          {
            if (!mrsp.getTableName().compare(tableName))
            {
              dropTable = false;
              break;
            }
          }
          if (dropTable)
          {
            oss.str("");
            oss << "DROP TABLE " << tableName << "_STR_Z_AUD";
            try 
            {
              stmt->Execute(oss.str());
            }
            catch(IBPP::Exception &)
            {
            
            }

            oss.str("");
            oss << "DROP TABLE " << tableName;
            try 
            {
              stmt->Execute(oss.str());
            }
            catch(IBPP::Exception &)
            {
            
            }
          }
        }
        BOOST_FOREACH(tablePrefix, tablePrefixes) 
        {
          dropProcAndSeq = true;
          BOOST_FOREACH(MusicResSessionPar &mrsp, this->m_mra->m_wxServer)
          {
            if (!mrsp.getTablePrefix().compare(tablePrefix))
            {
              dropProcAndSeq = false;
              break;
            }
          }
          if (dropProcAndSeq)
          {
            try 
            {
              oss.str("");
              oss << "DROP PROCEDURE SEQ_ID_" << tablePrefix << "_ID";
              stmt->Execute(oss.str());
              oss.str("");
              oss << "DROP SEQUENCE SEQ_" << tablePrefix << "_ID";
              stmt->Execute(oss.str());
              oss.str("");
              oss << "DROP PROCEDURE SEQ_ID_" << tablePrefix << "_SZA_ID";
              stmt->Execute(oss.str());
              oss.str("");
              oss << "DROP SEQUENCE SEQ_" << tablePrefix << "_SZA_ID";
              stmt->Execute(oss.str());
            } 
            catch(IBPP::Exception &)
            {
            }
          }
        }
        tr->Commit();

        tr = this->m_mra->m_dm.createTransaction(amWrite, ilReadCommitted, lrWait);
        tr->Start();
        this->m_mra->m_dm.deleteFromTable(osssqlstr, "URZ", "MIR_URL_ZASOBU", &tr);
        tr->Commit();

        // here i will create 
        // tables MIR_SERWXXXXX with SRWXXXXX prefix
        
        wxFileName fn;
        wxString wxfilename, wxfilenameExt;
        //fnrootwww.Normalize(wxPATH_NORM_LONG|wxPATH_NORM_DOTS|wxPATH_NORM_TILDE|wxPATH_NORM_ABSOLUTE);

        wxString sczOdwUrla;/*, fnSczOdwUrla, feSczOdwUrla*/

        boost::ptr_vector<DBField> dbFields;

        BOOST_FOREACH(MusicResSessionPar &mrsp, this->m_mra->m_wxServer)
        {
          tr = this->m_mra->m_dm.createTransaction(amWrite, ilReadCommitted, lrWait);
          
          musicResource = mrsp.getMusicResource();

          ContentTypeRetriever ctr(musicResource);
          uri.Create(std2wx(musicResource, &wxCSUTF8));

          sczOdwUrla = Utils::subAllNotAllowedCharsInFilenames(uri.GetServer());

          if ((!uri.GetPath().EndsWith(wxT("/")))
              || uri.HasQuery()
              || uri.HasFragment())
          {
            int lastDotPos;
            wxString wxuriPath = uri.GetPath(); // uri ma zawsze czę¶ć Path

            wxuriPath.Replace(wxT("%"), wxT(""));
            wxuriPath = Utils::subAllNotAllowedCharsInFilenames(wxuriPath, false, true);
            lastDotPos = wxuriPath.Find('.', true);
            if (lastDotPos == wxNOT_FOUND)
              wxfilenameExt = wxT("");
            else
            {
              wxfilenameExt = wxuriPath.Mid(lastDotPos + 1);
              wxuriPath = wxuriPath.Mid(0, lastDotPos);
            }
            
            sczOdwUrla += wxuriPath;

            if (uri.HasQuery())
              sczOdwUrla += Utils::subAllNotAllowedCharsInFilenames(wxT("?") + uri.GetQuery());
            if (uri.HasFragment())
              sczOdwUrla += Utils::subAllNotAllowedCharsInFilenames(wxT("#") + uri.GetFragment());

            sczOdwUrla = fname.GetPath(0, wxPATH_UNIX) + wxT("/") + sczOdwUrla + (wxfilenameExt.IsEmpty() ? (ctr.getContentTypeExtension().empty() ? wxT("") : std2wx("." + ctr.getContentTypeExtension(), &wxCSUTF8) ) : wxT(".") + wxfilenameExt);
          } 
          else 
          {
            {
              boost::lock_guard<boost::mutex> lock(DownloadThread::ms_downloadthread_wxWidgetsFuncs_mutex);

              wxfilename = Utils::CreateTempFileName(2);
              wxRemoveFile(wxfilename);
            }
            wxFileName tmpfn(wxfilename);
            sczOdwUrla =  fname.GetPath(0, wxPATH_UNIX) + wxT("/") + sczOdwUrla + wxT("/") + tmpfn.GetName() + (ctr.getContentTypeExtension().empty() ? wxT("") : std2wx("." + ctr.getContentTypeExtension(), &wxCSUTF8) );
          }

          dbFields.resize(0);

          switch(ctr.getContentType())
          {
            case koctvHTML:
            case koctvXHTML:
              dbFields.push_back(new BoolDBField(true, mrsp.getTablePrefix() + "_STRONA_LUB_AUDIO"));
            break;
            case koctvAudioContent:
              dbFields.push_back(new BoolDBField(false, mrsp.getTablePrefix() + "_STRONA_LUB_AUDIO"));
          }
          dbFields.push_back(new StringDBField(mrsp.getMusicResource(), mrsp.getTablePrefix() + "_ODW_URL"));
          dbFields.push_back(new StringDBField(wx2std(sczOdwUrla, &wxCSUTF8), mrsp.getTablePrefix() + "_SCZ_ODW_URLA"));
          dbFields.push_back(new BoolDBField(false, mrsp.getTablePrefix() + "_ODWIEDZONY"));
          dbFields.push_back(new BoolDBField(false, mrsp.getTablePrefix() + "_POBIERANY"));
          dbFields.push_back(new BoolDBField(true, mrsp.getTablePrefix() + "_PUNKT_STARTOWY"));
          tr->Start();
          try
          {
          	this->m_mra->m_dm.insertIntoTable(mrsp.getTablePrefix(), mrsp.getTableName(), dbFields, &tr);
          } 
          catch(IBPP::Exception &)
          {
            // nie ma jeszcze tabeli (wiec stworze i zrobie insert...) lub jest o identyczynym wpisie 
          }

          tr->Commit();


          tr = this->m_mra->m_dm.createTransaction(amWrite, ilReadCommitted, lrWait);
          tr->Start();

          stmt = this->m_mra->m_dm.createStatement(&tr);

          oss.str("");
          tablePrefix = mrsp.getTablePrefix();
          tableName = mrsp.getTableName();
          try
          {
            oss << "CREATE SEQUENCE SEQ_" << tablePrefix << "_ID";
            stmt->Execute(oss.str());
          }
          catch(IBPP::Exception &)
          {
            tr->Commit();
            continue;
          }
          oss.str("");
          oss << "CREATE PROCEDURE SEQ_ID_" << tablePrefix << "_ID"
              << " RETURNS(P_OUT BIGINT) AS begin P_OUT = NEXT VALUE FOR SEQ_"
              << tablePrefix <<  "_ID" << "; suspend; end";
          stmt->Execute(oss.str());

          oss.str("");
          oss << "CREATE TABLE " << tableName << " ("
              << tablePrefix << "_ID                 DOM_ID_PK,"
              << tablePrefix << "_ODW_URL            DOM_STRING3212 NOT NULL,"
              << tablePrefix << "_SCZ_ODW_URLA       DOM_STRING3212 NOT NULL,"
              << tablePrefix << "_ODWIEDZONY         DOM_BOOLEAN NOT NULL,"
              << tablePrefix << "_POBIERANY          DOM_BOOLEAN NOT NULL,"
              << tablePrefix << "_PUNKT_STARTOWY     DOM_BOOLEAN,"
              << tablePrefix << "_STRONA_LUB_AUDIO   DOM_BOOLEAN,"
              << tablePrefix << "_AUDYT_UT_UZY_ID    DOM_AUDYT_UT_UZY_ID NOT NULL,"
              << tablePrefix << "_AUDYT_DT           DOM_AUDYT_DT NOT NULL,"
              << tablePrefix << "_AUDYT_UM_UZY_ID    DOM_AUDYT_UM_UZY_ID,"
              << tablePrefix << "_AUDYT_DM           DOM_AUDYT_DM )";
          stmt->Execute(oss.str());

          oss.str("");
          oss << "ALTER TABLE " << tableName << " ADD CONSTRAINT PK_" << tableName
              << " PRIMARY KEY (" << tablePrefix << "_ID)";
          stmt->Execute(oss.str());
          
          oss.str("");
          oss << "ALTER TABLE " << tableName << " ADD CONSTRAINT UQ_" << tablePrefix << "_ODW_URL"
              << " UNIQUE (" << tablePrefix << "_ODW_URL)";
          stmt->Execute(oss.str());

          oss.str("");
          oss << "ALTER TABLE " << tableName << " ADD CONSTRAINT C_" << tablePrefix << "_AUDYT_UT_UZY_ID"
              << " FOREIGN KEY (" << tablePrefix << "_AUDYT_UT_UZY_ID)" << " REFERENCES MIR_UZYTKOWNIK(UZY_ID)";
          stmt->Execute(oss.str());
          
          oss.str("");
          oss << "ALTER TABLE " << tableName << " ADD CONSTRAINT C_" << tablePrefix << "_AUDYT_UM_UZY_ID"
              << " FOREIGN KEY (" << tablePrefix << "_AUDYT_UM_UZY_ID)" << " REFERENCES MIR_UZYTKOWNIK(UZY_ID)";
          stmt->Execute(oss.str());
          

          oss.str("");
          oss << "CREATE SEQUENCE SEQ_" << tablePrefix << "_SZA_ID";
          stmt->Execute(oss.str());

          oss.str("");
          oss << "CREATE PROCEDURE SEQ_ID_" << tablePrefix << "_SZA_ID"
              << " RETURNS(P_OUT BIGINT) AS begin P_OUT = NEXT VALUE FOR SEQ_"
              << tablePrefix <<  "_SZA_ID" << "; suspend; end";
          stmt->Execute(oss.str());


          oss.str("");
          oss << "CREATE TABLE " << tableName << "_STR_Z_AUD ("
              << tablePrefix << "_SZA_ID                         DOM_ID_PK,"
              << tablePrefix << "_SZA_S_" << tablePrefix << "_ID DOM_ID_FK,"
              << tablePrefix << "_SZA_A_" << tablePrefix << "_ID DOM_ID_FK,"
              << tablePrefix << "_SZA_AUDYT_UT_UZY_ID            DOM_AUDYT_UT_UZY_ID NOT NULL,"
              << tablePrefix << "_SZA_AUDYT_DT                   DOM_AUDYT_DT NOT NULL,"
              << tablePrefix << "_SZA_AUDYT_UM_UZY_ID            DOM_AUDYT_UM_UZY_ID,"
              << tablePrefix << "_SZA_AUDYT_DM                   DOM_AUDYT_DM )";

          stmt->Execute(oss.str());

          oss.str("");
          oss << "ALTER TABLE " << tableName << "_STR_Z_AUD ADD CONSTRAINT PK_" << tableName
              << "_STR_Z_AUD PRIMARY KEY (" << tablePrefix << "_SZA_ID)";
          stmt->Execute(oss.str());

          oss.str("");
          oss << "ALTER TABLE " << tableName << "_STR_Z_AUD ADD CONSTRAINT C_" << tablePrefix << "_SZA_S_ID"
              << " FOREIGN KEY (" << tablePrefix << "_SZA_S_" << tablePrefix << "_ID)" << " REFERENCES " << tableName << "(" << tablePrefix << "_ID)";
          stmt->Execute(oss.str());

          oss.str("");
          oss << "ALTER TABLE " << tableName << "_STR_Z_AUD ADD CONSTRAINT C_" << tablePrefix << "_SZA_A_ID"
              << " FOREIGN KEY (" << tablePrefix << "_SZA_A_" << tablePrefix << "_ID)" << " REFERENCES " << tableName << "(" << tablePrefix << "_ID)";
          stmt->Execute(oss.str());
          
          oss.str("");
          oss << "ALTER TABLE " << tableName << "_STR_Z_AUD ADD CONSTRAINT UQ_" << tablePrefix << "_SZA_S_ID_SZA_A_ID"
              << " UNIQUE (" << tablePrefix << "_SZA_S_" << tablePrefix << "_ID, " << tablePrefix << "_SZA_A_" << tablePrefix << "_ID)";
          stmt->Execute(oss.str());

          oss.str("");
          oss << "ALTER TABLE " << tableName << "_STR_Z_AUD ADD CONSTRAINT C_" << tablePrefix << "_SZA_AUDYT_UT_UZY_ID"
              << " FOREIGN KEY (" << tablePrefix << "_SZA_AUDYT_UT_UZY_ID)" << " REFERENCES MIR_UZYTKOWNIK(UZY_ID)";
          stmt->Execute(oss.str());
          
          oss.str("");
          oss << "ALTER TABLE " << tableName << "_STR_Z_AUD ADD CONSTRAINT C_" << tablePrefix << "_SZA_AUDYT_UM_UZY_ID"
              << " FOREIGN KEY (" << tablePrefix << "_SZA_AUDYT_UM_UZY_ID)" << " REFERENCES MIR_UZYTKOWNIK(UZY_ID)";
          stmt->Execute(oss.str());
          
          
          tr->Commit();



          tr = this->m_mra->m_dm.createTransaction(amWrite, ilReadCommitted, lrWait);
          tr->Start();
          try
          {
          	this->m_mra->m_dm.insertIntoTable(mrsp.getTablePrefix(), mrsp.getTableName(), dbFields, &tr);
          } 
          catch(IBPP::Exception &)
          {
            // z jakiś przyczyn insert się nie udał
          }
          tr->Commit();

        }

        wApp->setInternalPath("/start", true);
      }

      void SettingsPage::m_slt_wpbServersAdd()
      {
        WContainerWidget *wcw = this->m_mra->root();
        int i = wcw->indexOf(&this->m_wsettingsBr.back());

        this->m_wleServers.reserve(this->m_wleServers.size() + 2);
        this->m_wsettingsBr.reserve(this->m_wsettingsBr.size() + 1);
        this->m_wsettingsBr.push_back(new WText(WString("<br />", UTF8)));
        wcw->insertWidget(i+1, &this->m_wsettingsBr.back());
        WLineEdit *w[2];
        w[0] = new WLineEdit();
        w[0]->setTextSize(128);
        w[1] = new WLineEdit();
        w[1]->setTextSize(32);
        wcw->insertWidget(i+1, w[1]);
        wcw->insertWidget(i+1, w[0]);
        this->m_wleServers.push_back(w[0]);
        this->m_wleServers.push_back(w[1]);
      }

      // you must 
      void SettingsPage::getMusicServers()
      {
        this->m_mra->m_wxServer.resize(0);
        size_t wxServersCount = (size_t) (this->m_wleServers.size());
        if (wxServersCount > 0)
        {
          bool hasDuplicate = false;
          boost::ptr_set<size_t> duplicates;
          this->m_mra->m_wxServer.reserve(wxServersCount);
          for(size_t i=0; i < wxServersCount; i = i + 2)
          {
            for(size_t t = i + 2; t< wxServersCount; t = t + 2)
            {
              if (this->m_wleServers.at(i).text() == this->m_wleServers.at(t).text())
              {
                duplicates.insert(new size_t(t)); // push_back(new size_t(t));    
                break;
              }
            }
            hasDuplicate = true;
            if (duplicates.find(i) == duplicates.end())
            {
              hasDuplicate = false;
            }

            if ((!this->m_wleServers.at(i).text().empty()) && (!hasDuplicate))
              this->m_mra->m_wxServer.push_back(new MusicResSessionPar(this->m_wleServers.at(i).text().toUTF8(), this->m_wleServers.at(i+1).text().toUTF8()));
          }
        }

//        if (this->m_wxServer.size() > 0)
//        {
//          this->m_wxdt.reserve(this->m_wxServer.size());
//
//          for(size_t i = 0; i < this->m_wxServer.size(); i++)
//          {
//            MusicResSessionPar mrsp = this->m_wxServer.at(i);
//
//            DownloadThread *dwnThr = new DownloadThread(wxTHREAD_JOINABLE, mrsp.getSessionParam());
//
//            {
//              wxMutexLocker wxml(dwnThr->m_downloadthread_m_wxuri_mutex);
//              dwnThr->m_wxuri = new wxURI(std2wx(mrsp.getMusicResource(), &wxConvUTF8));
//              dwnThr->m_musicResourceURI.Create(dwnThr->m_wxuri->BuildUnescapedURI());
//            }
//            dwnThr->m_tableName = mrsp.getTableName();
//            dwnThr->m_tablePrefix = mrsp.getTablePrefix();
//
//            this->copyLoginInfo(*dwnThr);
//            this->m_wxdt.push_back(dwnThr);
//
//          }
//        }
      }


      void SettingsPage::settingsPage()
      {
        if (!this->m_mra->m_login.compare(""))
        {
          wApp->setInternalPath("/login", true);
          return;
        }

        if (!this->m_mra->m_stopDownloading)
        {
          wApp->setInternalPath("/start", true);
          return;
        }
        for(size_t i=0; i< this->m_mra->m_wxdt.size(); i++)
        {
        	bool stopDownloading = true;
        	{
        		boost::lock_guard<boost::mutex> lock(this->m_mra->m_wxdt.at(i).m_downloadthread_m_stopDownloading_mutex);
        		stopDownloading = this->m_mra->m_wxdt.at(i).m_stopDownloading;
        	}
          if(!stopDownloading)
          {
            wApp->setInternalPath("/start", true);
            return;
          }
        }

        this->m_mra->destroyAllWidgets();

        this->m_wleServers.resize(0);
        this->m_wsettingsBr.resize(0);
        size_t wxServersSize = this->m_mra->m_wxServer.size();

        if (wxServersSize == 0) wxServersSize = 1;
        this->m_wleServers.reserve(wxServersSize * 2);
        this->m_wsettingsBr.reserve(wxServersSize);

        WContainerWidget *wcw = this->m_mra->root();

        WLabel *wl = new WLabel(WString("Addresses of web pages:", UTF8), wcw);
        wl->setToolTip(WString("Type your address here", UTF8));
        new WText(WString("<br />", UTF8), XHTMLText, wcw);
        WString server;
        WString sessionID;

        if (wxServersSize >= 1)
        {
          for(size_t i=0; i< wxServersSize; i++)
          {
            if (this->m_mra->m_wxServer.size() > 0)
              server = WString(this->m_mra->m_wxServer.at(i).getMusicResource(), UTF8);
            else
              server = WString::fromUTF8("");

            if (this->m_mra->m_wxServer.size() > 0)
              sessionID = WString(this->m_mra->m_wxServer.at(i).getSessionParam(), UTF8);
            else
              sessionID = WString::fromUTF8("");

            this->m_wleServers.push_back(new WLineEdit(server, wcw));
            this->m_wleServers.back().setTextSize(128);
            this->m_wleServers.push_back(new WLineEdit(sessionID, wcw));
            this->m_wleServers.back().setTextSize(32);

            this->m_wsettingsBr.push_back(new WText(WString("<br />", UTF8), XHTMLText, wcw));
          }
        } 

        WPushButton *wpb = new WPushButton(WString("Add", UTF8), wcw);
        wpb->clicked().connect(this, &SettingsPage::m_slt_wpbServersAdd);

        wpb = new WPushButton(WString("Save", UTF8), wcw);
        wpb->setToolTip(WString("Zapisz zasoby muzyczne WWW", UTF8));
        wpb->clicked().connect(this, &SettingsPage::m_slt_wpbSave);
      }


    } // namespace MR
  } // namespace MIR
} // namespace SyNaT
