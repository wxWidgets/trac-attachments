﻿/*
 * mir_sha1.h must be first.
 * Another solution is to do following:
 **/
 //  //#if (ULONG_MAX == 0xFFFFFFFF)
 //  //#define UINT_32 unsigned long
 //  //#else
 //  #define UINT_32 unsigned int
 //  //#endif
#include "mir_sha1.h"


#include <Wt/WApplication>
#include <Wt/WLogger>

// For compilers that support precompilation, includes "wx/wx.h".
#include <wx/wxprec.h>

#ifdef __BORLANDC__
    #pragma hdrstop
#endif

// for all others, include the necessary headers (this file is usually all you
// need because it includes almost all "standard" wxWidgets headers
#ifndef WX_PRECOMP
    #include "wx/wx.h"
#endif

#include <wx/strconv.h>

#include <boost/foreach.hpp>
#include <boost/regex.hpp>
#include <boost/ptr_container/ptr_vector.hpp>

#include <string>

#include "mir_stringutils.h"
#include "mir_exceptions.h"
#include "mir_databasetypes.h"
#include "mir_databasemodule.h"

#include <ibpp.h>


namespace SyNaT
{
  namespace MIR
  {


    using namespace std;
    using namespace IBPP;

    string DatabaseModule::toSql(const string &input, const bool addSingleQuotations)
    {
      ostringstream oss;
      if (addSingleQuotations)
        oss << "'";
      oss << boost::regex_replace(input, DatabaseModule::mcs_regex, "''");
      if (addSingleQuotations)
        oss << "'";
      return oss.str();
    }
    
    string DatabaseModule::toSimilarToSql(const string &input, const bool addEscapeWord)
    {
      ostringstream oss;
      string sql = DatabaseModule::toSql(input, false);
      if (addEscapeWord)
        oss << "'";
      oss << boost::regex_replace(sql, DatabaseModule::mcs_similar_to_regex, "\\_");
      if (addEscapeWord)
        oss << "' ESCAPE '\\'";
      return oss.str();
    }

    DatabaseModule::DatabaseModule() : m_adminID(DATABASEMODULE_ADMIN_ID)
    {
      this->m_dbAssigned = false;
      this->m_loggedUserId = 0; // 0 means no one logged
    }

    DatabaseModule::DatabaseModule(const wxString &serverName, const wxString &databaseName, 
                                const wxString &userName, const wxString &userPassword,
                                const wxString &roleName, const wxString &charSet,
                                const wxString &createParams, const wxString &login, 
                                const wxString &loginPassword, bool isSha1) /* throw(...) */ : m_adminID(DATABASEMODULE_ADMIN_ID)
    {
      this->m_dbAssigned = false;
      this->m_loggedUserId = 0; // 0 means no logged
      this->connect(serverName, databaseName, userName, userPassword, roleName, charSet, createParams, login, loginPassword, isSha1);
    }

    DatabaseModule::DatabaseModule(const string &serverName, const string &databaseName, 
                                const string &userName, const string &userPassword,
                                const string &roleName, const string &charSet,
                                const string &createParams, const string &login, 
                                const string &loginPassword, bool isSha1) /* throw(...) */ : m_adminID(DATABASEMODULE_ADMIN_ID)
    {
      this->m_dbAssigned = false;
      this->m_loggedUserId = 0; // 0 means no logged
      this->connect(serverName, databaseName, userName, userPassword, roleName, charSet, createParams, login, loginPassword, isSha1);
    }

    void DatabaseModule::connect(const wxString &serverName, const wxString &databaseName, 
                                 const wxString &userName, const wxString &userPassword,
                                 const wxString &roleName, const wxString &charSet,
                                 const wxString &createParams, const wxString &login, 
                                 const wxString &loginPassword, bool isSha1) /* throw(...) */

    {
      wxCSConv wxCSUTF8(wxFONTENCODING_UTF8);

      this->m_db = DatabaseFactory(wx2std(serverName, &wxCSUTF8), wx2std(databaseName, &wxCSUTF8),
                                 wx2std(userName, &wxCSUTF8), wx2std(userPassword, &wxCSUTF8),
                                 wx2std(roleName, &wxCSUTF8), wx2std(charSet, &wxCSUTF8),
                                 wx2std(createParams, &wxCSUTF8));
      this->m_dbAssigned = true;

      this->m_db->Connect();
      Transaction tr = TransactionFactory(this->m_db, amRead);
      tr->Start();
      this->login(wx2std(login, &wxCSUTF8), wx2std(loginPassword, &wxCSUTF8), &tr, isSha1);
      tr->Commit();
    }

    void DatabaseModule::connect(const string &serverName, const string &databaseName, 
                                   const string &userName, const string &userPassword,
                                   const string &roleName, const string &charSet,
                                   const string &createParams, const string &login, 
                                   const string &loginPassword, bool isSha1) /* throw(...) */
    {
      this->m_db = DatabaseFactory(serverName, databaseName,
                                   userName, userPassword,
                                   roleName, charSet, createParams);
      this->m_dbAssigned = true;

      this->m_db->Connect();
      Transaction tr = TransactionFactory(this->m_db, amRead);
      tr->Start();
      this->login(login, loginPassword, &tr, isSha1);
      tr->Commit();
    }

    Transaction DatabaseModule::createTransaction(TAM am, TIL il, 
                                                  TLR lr, TFF flags)
                                                  /* throw(...) */
    {
      if(this->m_loggedUserId == 0)
        throw UserNotLoggedMirException(string("DatabaseModule::createTransaction(TAM am, TIL il, TLR lr, TFF flags)"));

      if(!this->m_dbAssigned)
        throw DatabaseNotAssignedMirException(string("DatabaseModule::createTransaction(TAM am, TIL il, TLR lr, TFF flags)"));

      return TransactionFactory(this->m_db, am, il, lr, flags);
    }

    Statement DatabaseModule::createStatement(Transaction *tr, string *sql) /* throw(...) */
    {
      if(this->m_loggedUserId == 0)
        throw UserNotLoggedMirException(string("DatabaseModule::createTransaction(TAM am, TIL il, TLR lr, TFF flags)"));

      if(!this->m_dbAssigned)
        throw DatabaseNotAssignedMirException(string("DatabaseModule::createTransaction(TAM am, TIL il, TLR lr, TFF flags)"));

      if(!tr)
        throw TransactionNotAssignedMirException(string("DatabaseModule::createStatement(Transaction *tr)"));
      
      if (sql)
        return StatementFactory(this->m_db, *tr, *sql);
      else
        return StatementFactory(this->m_db, *tr);
    }


    /**
     * @return 0 if next id cannot be computed, otherwise value greater then 0
     */
    int64_t DatabaseModule::getNextID(const wxString &tablePrefix, Transaction *tr)
    {
      wxCSConv wxCSUTF8(wxFONTENCODING_UTF8);
      int64_t result = 0;
      try {
        Statement st = StatementFactory(this->m_db, *tr);
        wxString sql = wxString::Format(wxT("SELECT p.P_OUT FROM SEQ_ID_%s_ID p"), tablePrefix.wc_str(wxCSUTF8));
        st->Execute(wx2std(sql, &wxCSUTF8));
        if (!st->Fetch())
          return result;
        st->Get(1, result);
      } catch(LogicException &e)
      {
        wApp->log("error") << e.Origin() << " " << e.what(); 
      }
      return result;
    }

    /*
     * @return 0 if next id cannot be computed, otherwise value greater then 0
     */
    int64_t DatabaseModule::getNextID(const string &tablePrefix, Transaction *tr)
    {
      int64_t result = 0;
      try {
        Statement st = StatementFactory(this->m_db, *tr);
        ostringstream sql;
        sql << "SELECT p.P_OUT FROM SEQ_ID_" << tablePrefix << "_ID p";
        st->Execute(sql.str());
        if (!st->Fetch())
          return result;
        st->Get(1, result);
      } catch(LogicException &e)
      {
        wApp->log("error") << e.Origin() << " " << e.what(); 
      }
      return result;
    }

    void DatabaseModule::checkTableLock(const int64_t tableId, const string &tablePrefix, 
                                        const string &tableName, 
                                        Transaction *tr)
                                        /* throw(...) */
    {
      if(!this->m_dbAssigned)
        throw DatabaseNotAssignedMirException(string("DatabaseModule::checkTableLock(const int64_t tableId, const string &tablePrefix, const string &tableName, Transaction *tr)"));
      
      if(!tr)
        throw TransactionNotAssignedMirException(string("DatabaseModule::checkTableLock(const int64_t tableId, const string &tablePrefix, const string &tableName, Transaction *tr)"));

      if(this->m_loggedUserId == 0)
        throw UserNotLoggedMirException(string("DatabaseModule::checkTableLock(const int64_t tableId, const string &tablePrefix, const string &tableName, Transaction *tr)"));


      ostringstream ostrstmt;
      ostrstmt << "UPDATE " << tableName << " SET " << tablePrefix << "_ID = " 
               << tablePrefix << "_ID WHERE " << tablePrefix << "_ID = " << tableId;

      Statement stmt = StatementFactory(this->m_db, *tr, ostrstmt.str());
      
      stmt->Execute();    
    }

    int64_t DatabaseModule::insertIntoTable(const string &tablePrefix, const string &tableName, 
                                            boost::ptr_vector<DBField> &dbfv, Transaction *tr)
                                            /* throw(...) */
    {
      if(!this->m_dbAssigned)
        throw DatabaseNotAssignedMirException(string("DatabaseModule::insertIntoTable(const wxString &prefix, const wxString &tableName, const DBFieldHashMap &dbfhm, Transaction &tr) "));
      
      if(!tr)
        throw TransactionNotAssignedMirException(string("DatabaseModule::insertIntoTable(const wxString &prefix, const wxString &tableName, const DBFieldHashMap &dbfhm, Transaction &tr) "));

      if(this->m_loggedUserId == 0)
        throw UserNotLoggedMirException(string("DatabaseModule::insertIntoTable(const wxString &prefix, const wxString &tableName, const DBFieldHashMap &dbfhm, Transaction &tr) "));

      ostringstream ostrstmt;
      ostrstmt << "INSERT INTO " << tableName;
      
      ostringstream dbFields;
      dbFields << " (" << tablePrefix << "_ID" 
               << "," << tablePrefix << "_AUDYT_UT_UZY_ID" 
               << "," << tablePrefix << "_AUDYT_DT";

      int64_t tableID = this->getNextID(tablePrefix, tr);
      ostringstream dbValues;
      dbValues << " VALUES(" << tableID 
               << "," << this->m_loggedUserId
               << ",CURRENT_TIMESTAMP";
      
      DBFieldType dbfk;
      bool isVOIDPorCHARP = false;

      BOOST_FOREACH(DBField &dbf, dbfv) 
      {
        dbFields << "," << dbf.getFieldName();
        dbfk = dbf.getDBFieldType();
        if (dbfk < BOOLT)
        {
          dbValues << ",?";
          isVOIDPorCHARP = true;
        } else
          dbValues << "," << dbf.getAsDBString();
      }
      dbFields << ")";
      dbValues << ")";

      ostrstmt << dbFields.str() << dbValues.str();

      Statement stmt = StatementFactory(this->m_db, *tr, ostrstmt.str());

      if (isVOIDPorCHARP)
      {
        VOIDPDBField *vpdbf;
        CHARPDBField *cpdbf;
        BlobDBField  *bdbf;
        Blob          b;
        int           i = 1;
        void         *value = (void *) 0;
        int           size;

        BOOST_FOREACH(DBField &dbf, dbfv) 
        {
          dbfk = dbf.getDBFieldType();
          if (dbfk < BOOLT)
          {
            switch(dbfk)
            {
              case VOIDP:
                vpdbf = (VOIDPDBField *) &dbf;
                vpdbf->getValue(value, size);
                stmt->Set(i++, value, size);
                free(value);
                value = (void *) 0;
              case CHARP:
                cpdbf = (CHARPDBField *) &dbf;
                cpdbf->getValue((unsigned char *&) value);
                stmt->Set(i++, (char *) value);
                free(value);
                value = (void *) 0;
              case BLOBT:
                bdbf = (BlobDBField *) &dbf;
                bdbf->getValue(b);
                stmt->Set(i++, b);
            }
          }
        }
      }
      
      stmt->Execute();
      return tableID;
    }

    void DatabaseModule::updateTable(const int64_t tableId, const string &tablePrefix, 
                                     const string &tableName, boost::ptr_vector<DBField> &dbfv, 
                                     Transaction *tr)
                                     /* throw (...) */
    {
      if(this->m_loggedUserId == 0)
        throw UserNotLoggedMirException(string("DatabaseModule::insertIntoTable(const wxString &prefix, const wxString &tableName, const DBFieldHashMap &dbfhm, Transaction &tr) "));

      if(!this->m_dbAssigned)
        throw DatabaseNotAssignedMirException(string("DatabaseModule::insertIntoTable(const wxString &prefix, const wxString &tableName, const DBFieldHashMap &dbfhm, Transaction &tr) "));
      
      if(!tr)
        throw TransactionNotAssignedMirException(string("DatabaseModule::insertIntoTable(const wxString &prefix, const wxString &tableName, const DBFieldHashMap &dbfhm, Transaction &tr) "));

      ostringstream ostrstmt;
      ostrstmt << "UPDATE " << tableName;

      ostrstmt << " SET " << tablePrefix << "_AUDYT_UM_UZY_ID = "  << this->m_loggedUserId
                         << "," << tablePrefix << "_AUDYT_DM = CURRENT_TIMESTAMP"  ;
      
      DBFieldType dbfk;
      bool isVOIDPorCHARP = false;

      BOOST_FOREACH(DBField &dbf, dbfv) 
      {
        ostrstmt << "," << dbf.getFieldName();
        dbfk = dbf.getDBFieldType();
        if (dbfk < BOOLT)
        {
          ostrstmt << " = ?";
          isVOIDPorCHARP = true;
        } else
          ostrstmt << " = " << dbf.getAsDBString();
      }
      ostrstmt << " WHERE " << tablePrefix << "_ID = " << tableId;

      Statement stmt = StatementFactory(this->m_db, *tr, ostrstmt.str());

      if (isVOIDPorCHARP)
      {
        VOIDPDBField *vpdbf;
        CHARPDBField *cpdbf;
        BlobDBField  *bdbf;
        Blob          b;
        int           i = 1;
        void         *value = (void *) 0;
        int           size;

        BOOST_FOREACH(DBField &dbf, dbfv) 
        {
          dbfk = dbf.getDBFieldType();
          if (dbfk < BOOLT)
          {
            switch(dbfk)
            {
              case VOIDP:
                vpdbf = (VOIDPDBField *) &dbf;
                vpdbf->getValue(value, size);
                stmt->Set(i++, value, size);
                free(value);
                value = (void *) 0;
              case CHARP:
                cpdbf = (CHARPDBField *) &dbf;
                cpdbf->getValue((unsigned char *&) value);
                stmt->Set(i++, (char *) value);
                free(value);
                value = (void *) 0;
              case BLOBT:
                bdbf = (BlobDBField *) &dbf;
                bdbf->getValue(b);
                stmt->Set(i++, b);
            }
          }
        }
      }

      stmt->Execute();
    }


    void DatabaseModule::updateTable(const string  &whereSql, const string &tablePrefix, 
                                    const string &tableName, boost::ptr_vector<DBField> &dbfv, 
                                    Transaction *tr)
                                    /* throw (...) */
    {
      if(this->m_loggedUserId == 0)
        throw UserNotLoggedMirException(string("DatabaseModule::insertIntoTable(const wxString &prefix, const wxString &tableName, const DBFieldHashMap &dbfhm, Transaction &tr) "));

      if(!this->m_dbAssigned)
        throw DatabaseNotAssignedMirException(string("DatabaseModule::insertIntoTable(const wxString &prefix, const wxString &tableName, const DBFieldHashMap &dbfhm, Transaction &tr) "));
      
      if(!tr)
        throw TransactionNotAssignedMirException(string("DatabaseModule::insertIntoTable(const wxString &prefix, const wxString &tableName, const DBFieldHashMap &dbfhm, Transaction &tr) "));

      ostringstream ostrstmt;
      ostrstmt << "UPDATE " << tableName;

      ostrstmt << " SET " << tablePrefix << "_AUDYT_UM_UZY_ID = "  << this->m_loggedUserId
                         << "," << tablePrefix << "_AUDYT_DM = CURRENT_TIMESTAMP"  ;
      
      DBFieldType dbfk;
      bool isVOIDPorCHARP = false;

      BOOST_FOREACH(DBField &dbf, dbfv) 
      {
        ostrstmt << "," << dbf.getFieldName();
        dbfk = dbf.getDBFieldType();
        if (dbfk < BOOLT)
        {
          ostrstmt << " = ?";
          isVOIDPorCHARP = true;
        } else
          ostrstmt << " = " << dbf.getAsDBString();
      }
      ostrstmt << " WHERE " << whereSql;

      Statement stmt = StatementFactory(this->m_db, *tr, ostrstmt.str());

      if (isVOIDPorCHARP)
      {
        VOIDPDBField *vpdbf;
        CHARPDBField *cpdbf;
        BlobDBField  *bdbf;
        Blob          b;
        int           i = 1;
        void         *value = (void *) 0;
        int           size;

        BOOST_FOREACH(DBField &dbf, dbfv) 
        {
          dbfk = dbf.getDBFieldType();
          if (dbfk < BOOLT)
          {
            switch(dbfk)
            {
              case VOIDP:
                vpdbf = (VOIDPDBField *) &dbf;
                vpdbf->getValue(value, size);
                stmt->Set(i++, value, size);
                free(value);
                value = (void *) 0;
              case CHARP:
                cpdbf = (CHARPDBField *) &dbf;
                cpdbf->getValue((unsigned char *&) value);
                stmt->Set(i++, (char *) value);
                free(value);
                value = (void *) 0;
              case BLOBT:
                bdbf = (BlobDBField *) &dbf;
                bdbf->getValue(b);
                stmt->Set(i++, b);
            }
          }
        }
      }

      stmt->Execute();
    }


    void  DatabaseModule::deleteFromTable(const int64_t tableId, const string &tablePrefix, 
                                          const string &tableName, Transaction *tr)
                                          /* throw (...) */
    {
      if(this->m_loggedUserId == 0)
        throw UserNotLoggedMirException(string("DatabaseModule::deleteFromTable(const int64_t tableId, const wxString &prefix, const wxString &tableName, Transaction &tr)"));

      if(!this->m_dbAssigned)
        throw DatabaseNotAssignedMirException(string("DatabaseModule::deleteFromTable(const int64_t tableId, const wxString &prefix, const wxString &tableName, Transaction &tr)"));
      
      if(!tr)
        throw TransactionNotAssignedMirException(string("DatabaseModule::deleteFromTable(const int64_t tableId, const wxString &prefix, const wxString &tableName, Transaction &tr)"));

      ostringstream ostrstmt;
      ostrstmt << "DELETE FROM " << tableName;
      if (tableId > 0)
        ostrstmt << " WHERE " << tablePrefix << "_ID = "  << tableId;

      Statement stmt = StatementFactory(this->m_db, *tr, ostrstmt.str());
      stmt->Execute();
    }


    void DatabaseModule::deleteFromTable(const string &whereSql, const string &tablePrefix, 
                                    const string &tableName, Transaction *tr)
                                    /* throw (...) */
    {
      if(this->m_loggedUserId == 0)
        throw UserNotLoggedMirException(string("DatabaseModule::deleteFromTable(const int64_t tableId, const wxString &prefix, const wxString &tableName, Transaction &tr)"));

      if(!this->m_dbAssigned)
        throw DatabaseNotAssignedMirException(string("DatabaseModule::deleteFromTable(const int64_t tableId, const wxString &prefix, const wxString &tableName, Transaction &tr)"));
      
      if(!tr)
        throw TransactionNotAssignedMirException(string("DatabaseModule::deleteFromTable(const int64_t tableId, const wxString &prefix, const wxString &tableName, Transaction &tr)"));

      ostringstream ostrstmt;
      ostrstmt << "DELETE FROM " << tableName;
      ostrstmt << " WHERE " << whereSql;

      Statement stmt = StatementFactory(this->m_db, *tr, ostrstmt.str());
      stmt->Execute();
    }

    void DatabaseModule::login(const string login, const string password, Transaction *tr, bool isSha1) /* throw (...) */
    {
      if(!this->m_dbAssigned)
        throw DatabaseNotAssignedMirException(string("DatabaseModule::login(const string login, const string password, Transaction *tr, bool isSha1)"));
      
      if(!tr)
        throw TransactionNotAssignedMirException(string("DatabaseModule::login(const string login, const string password, Transaction *tr, bool isSha1)"));

      ostringstream ostrstmt;
      
      ostrstmt << "SELECT UZY_HASLO, UZY_ID, UZY_IMIE, UZY_NAZWISKO FROM MIR_UZYTKOWNIK WHERE UZY_IDENTYFIKATOR = " << toSql(login);

      Statement stmt = StatementFactory(this->m_db, *tr, ostrstmt.str());
      stmt->Execute();
      if (stmt->Fetch())
      {
        char    hashdb[20], hashpass[20];
        int     size = 20;
        stmt->Get(1, (void *) hashdb, size);
        if (!isSha1) {
          CSHA1 cs;
          cs.Update((const UINT_8*) password.c_str(), (UINT_32) password.size());
          cs.Final();
          cs.GetHash((unsigned char *) hashpass);
        }
        else
        {
          memcpy(hashpass, password.c_str(), 20);
        }

        for(register int len = 0; len < 20; len++)
        {
          if (hashdb[len] !=  hashpass[len])
            throw IncorrectPasswordMirException(string("DatabaseModule::login(const string login, const string password, Transaction *tr, bool isSha1)"));
        }
        stmt->Get(2, this->m_loggedUserId);
        stmt->Get(3, this->m_name);
        stmt->Get(4, this->m_surname);
        this->m_hashpass = string(hashpass, 20);
      }
      else
      {
        throw UserDontExistsMirException(string("DatabaseModule::login(const string login, const string password, Transaction *tr, bool isSha1)"));
      }
    }

    bool DatabaseModule::logged()
    {
      return this->m_loggedUserId != 0;
    }

    string DatabaseModule::getName()
    {
      return this->m_name;
    }

    string DatabaseModule::getSurname()
    {
      return this->m_surname;
    }

    string DatabaseModule::getHashPassword()
    {
      return this->m_hashpass;
    }

    bool DatabaseModule::logout() /* throw(...) */
    {
      this->m_loggedUserId = 0;
      return true;
    }


    const boost::regex DatabaseModule::mcs_regex("'");

    const boost::regex DatabaseModule::mcs_similar_to_regex("_");

  } // namespace MIR
} // namespace SyNaT
