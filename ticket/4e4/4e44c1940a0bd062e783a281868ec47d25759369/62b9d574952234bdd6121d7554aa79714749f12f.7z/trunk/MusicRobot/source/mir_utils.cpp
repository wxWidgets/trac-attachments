// For compilers that support precompilation, includes "wx/wx.h".
#include <wx/wxprec.h>

#ifdef __BORLANDC__
    #pragma hdrstop
#endif

// for all others, include the necessary headers (this file is usually all you
// need because it includes almost all "standard" wxWidgets headers
#ifndef WX_PRECOMP
    #include "wx/wx.h"
#endif

#include <wx/uri.h>
#include <wx/regex.h>
#include <wx/filename.h>
#include <wx/tokenzr.h>

#include <boost/regex.hpp>
#include <boost/ptr_container/ptr_map.hpp>
#include <boost/thread/mutex.hpp>

#include <string>

#include "mir_stringutils.h"
#include "mir_charsvparser.h"
#include "mir_mr_downloadthread.h"
#include "mir_mr_musicrobotapp.h"
#include "mir_utils.h"

namespace SyNaT
{
  namespace MIR
  {
    using namespace std;

          //this->m_wxregex_ahref.Compile(wxT("<a\\s(?!<a\\s)href\\s*=\\s*(\"[^\">]*(\"|>)?|'[^'>]*('|>)?|[^>'\" ]*)"), wxRE_ADVANCED | wxRE_ICASE); // more like Firefox works, 
                                                                                                                             //need to update match_base_href and match_a_href
          //this->m_wxregex_a_tag.Compile(wxT("<a\\s.*?href.*?>.*?</a>"), wxRE_ADVANCED | wxRE_ICASE);
          //this->m_wxregex_hrefReplacer.Compile(wxT("href\\s*=\\s*(\"[^\"]*\"?|'[^']*'?|[^>\\s]*)"), wxRE_ADVANCED | wxRE_ICASE);
          //this->m_wxregex_hrefReplacerWOEQ.Compile(wxT("(href\\s|href>)"), wxRE_ADVANCED | wxRE_ICASE);

          // 2 version
          //this->m_wxregex_atag.Compile(wxT("<a(\\s+[^>=\\s]+\\s*=\\s*\"[^\"]*\"|\\s+[^>=\\s]+\\s*=\\s*'[^']*'|\\s+[^>=\\s]+=?[^>\\s]*|[^>=\\s]+=?[^>\\s]*)+[^>]*?(>|</a>)"), wxRE_ADVANCED | wxRE_ICASE);
          //this->m_wxregex_basetag.Compile(wxT("<base(\\s+[^>=\\s]+\\s*=\\s*\"[^\"]*\"|\\s+[^>=\\s]+\\s*=\\s*'[^']*'|\\s+[^>=\\s]+=?[^>\\s]*|[^>=\\s]+=?[^>\\s]*)+[^<]*<"), wxRE_ADVANCED | wxRE_ICASE);

          // 1 version
          //this->m_wxregex_ahref.Compile(wxT("<a(\\s+.+?\\s*=\\s*\"[^\"]*\"?|\\s+.+?\\s*=\\s*'[^']*'?|\\s+[^=>\\s]+?\\s*=?\\s*[^>\\s]*)+?.*?</a>"), wxRE_ADVANCED | wxRE_ICASE);
          //this->m_wxregex_basehref.Compile(wxT("<base(\\s+.+?\\s*=\\s*\"[^\"]*\"?|\\s+.+?\\s*=\\s*'[^']*'?|\\s+[^=>\\s]+\\s*=?\\s*[^>\\s]*)+?[^<]*<"), wxRE_ADVANCED | wxRE_ICASE);

          // 0 version
          //this->m_wxregex_ahref.Compile(wxT("<a(\\s+[a-z]+\\s*=?\\s*\"[^\"]*\"?|\\s[a-z]+\\s*=?\\s*'[^']*'?|\\s[a-z]+\\s*=?\\s*[^>\\s]*)+[^>]*>"), wxRE_ADVANCED | wxRE_ICASE);
          //this->m_wxregex_basehref.Compile(wxT("<base(\\s+[a-z]+\\s*=?\\s*\"[^\"]*\"?|\\s[a-z]+\\s*=?\\s*'[^']*'?|\\s[a-z]+\\s*=?\\s*[^>\\s]*)+[^<]*<"), wxRE_ADVANCED | wxRE_ICASE);

          //this->m_wxregex_sessionIDremoval.Compile(wxT("(&|\\?)?")+std2wx(this->m_sessionID, &wxConvUTF8)+wxT("=[^&]*?"), wxRE_ADVANCED | wxRE_ICASE);
          //this->m_wxregex_attributeWOQ.Compile(wxT("\\s[-.:\\xB7_0-9a-z\\xC0-\\xD6\\xD8-\\xF6\\xF8-\\x2FF\\x0300-\\x036F\\x370-\\x37D\\x37F-\\x1FFF\\x200C-\\x200D\\x203F-\\x2040\\x2070-\\x218F\\x2C00-\\x2FEF\\x2C00-\\x2FEF\\x3001-\\xD7FF\\xF900-\\xFDCF\\xFDF0-\\xFFFD\\x10000-\\xEFFFF]+\\s*=?\\s*[^>\\s]+"), wxRE_ADVANCED | wxRE_ICASE);
          //this->m_wxregex_attributeWSQ.Compile(wxT("\\s[-.:\\xB7_0-9a-z\\xC0-\\xD6\\xD8-\\xF6\\xF8-\\x2FF\\x0300-\\x036F\\x370-\\x37D\\x37F-\\x1FFF\\x200C-\\x200D\\x203F-\\x2040\\x2070-\\x218F\\x2C00-\\x2FEF\\x2C00-\\x2FEF\\x3001-\\xD7FF\\xF900-\\xFDCF\\xFDF0-\\xFFFD\\x10000-\\xEFFFF]+\\s*=\\s*'[^']*'?"), wxRE_ADVANCED | wxRE_ICASE);
          //this->m_wxregex_attributeWDQ.Compile(wxT("\\s[-.:\\xB7_0-9a-z\\xC0-\\xD6\\xD8-\\xF6\\xF8-\\x2FF\\x0300-\\x036F\\x370-\\x37D\\x37F-\\x1FFF\\x200C-\\x200D\\x203F-\\x2040\\x2070-\\x218F\\x2C00-\\x2FEF\\x2C00-\\x2FEF\\x3001-\\xD7FF\\xF900-\\xFDCF\\xFDF0-\\xFFFD\\x10000-\\xEFFFF]+\\s*=\\s*\"[^\"]*\"?"), wxRE_ADVANCED | wxRE_ICASE);
          //this->m_wxregex_attributeWOQ.Compile(wxT("\\s[a-z]+(\\s*=\\s*[^>\\s]*|[^>\\s]+>?|\\s*)"), wxRE_ADVANCED | wxRE_ICASE);   // interesuj� mnie tylko atrybuty z zakresu a-zA-Z
          //this->m_wxregex_attributeWSQ.Compile(wxT("\\s[a-z]+\\s*=\\s*'[^']*'?"), wxRE_ADVANCED | wxRE_ICASE);    // interesuj� mnie tylko atrybuty z zakresu a-zA-Z
          //this->m_wxregex_attributeWDQ.Compile(wxT("\\s[a-z]+\\s*=\\s*\"[^\"]*\"?"), wxRE_ADVANCED | wxRE_ICASE); // interesuj� mnie tylko atrybuty z zakresu a-zA-Z
          //this->m_wxregex_spaces.Compile(wxT("\\s+"), wxRE_ADVANCED | wxRE_ICASE);
    Utils::Utils(const string &sessionID) :
      m_wxregex_linktag(wxT("<link(\\s+[^>=\\s]+\\s*=\\s*\"[^\"]*\"|\\s+[^>=\\s]+\\s*=\\s*'[^']*'|\\s+[^>=\\s]+=?[^>\\s]*|[^>=\\s]+=?[^>\\s]*)+[^>]*>"), wxRE_ADVANCED | wxRE_ICASE),
      m_wxregex_basetag(wxT("<base(\\s+[^>=\\s]+\\s*=\\s*\"[^\"]*\"|\\s+[^>=\\s]+\\s*=\\s*'[^']*'|\\s+[^>=\\s]+=?[^>\\s]*|[^>=\\s]+=?[^>\\s]*)+[^<]*<"), wxRE_ADVANCED | wxRE_ICASE),
      m_wxregex_imgtag(wxT("<img(\\s+[^>=\\s]+\\s*=\\s*\"[^\"]*\"|\\s+[^>=\\s]+\\s*=\\s*'[^']*'|\\s+[^>=\\s]+=?[^>\\s]*|[^>=\\s]+=?[^>\\s]*)+[^>]*>"), wxRE_ADVANCED | wxRE_ICASE),
      m_wxregex_attributeWOQ(wxT("\\s[a-z]+(\\s*=\\s*[^>\\s]*|[^>\\s]+>?|\\s*)"), wxRE_ADVANCED | wxRE_ICASE),
      m_wxregex_attributeWSQ(wxT("\\s[a-z]+\\s*=\\s*'[^']*'?"), wxRE_ADVANCED | wxRE_ICASE),
      m_wxregex_attributeWDQ(wxT("\\s[a-z]+\\s*=\\s*\"[^\"]*\"?"), wxRE_ADVANCED | wxRE_ICASE),
      m_wxregex_spaces(wxT("\\s+"), wxRE_ADVANCED | wxRE_ICASE),
      m_wxregex_hrefReplacer(wxT("href\\s*=\\s*(\"[^\"]*\"?|'[^']*'?|[^>\\s]*)"), wxRE_ADVANCED | wxRE_ICASE),
      m_wxregex_hrefReplacerWOEQ(wxT("(href\\s|href>)"), wxRE_ADVANCED | wxRE_ICASE),
      m_wxregex_srcReplacer(wxT("src\\s*=\\s*(\"[^\"]*\"?|'[^']*'?|[^>\\s]*)"), wxRE_ADVANCED | wxRE_ICASE),
      m_wxregex_srcReplacerWOEQ(wxT("(src\\s|src>)"), wxRE_ADVANCED | wxRE_ICASE),
      m_wxregex_atag(wxT("<a(\\s+[^>=\\s]+\\s*=\\s*\"[^\"]*\"|\\s+[^>=\\s]+\\s*=\\s*'[^']*'|\\s+[^>=\\s]+=?[^>\\s]*|[^>=\\s]+=?[^>\\s]*)+[^>]*>"), wxRE_ADVANCED | wxRE_ICASE),
      m_wxCSUTF8(wxFONTENCODING_UTF8),
      m_wxregex_sessionIDremoval(wxT("(&|\\?)?")+std2wx(sessionID, &m_wxCSUTF8)+wxT("=([^&]*)"), wxRE_ADVANCED | wxRE_ICASE)
    {
    }

    wxURI Utils::match_img_tag(const wxString &wx_part_of_page, const wxURI &baseURI, bool &hasImgSrc, bool &hasImgTag, size_t &start, size_t &len, size_t &startOfTag, size_t &lenOfTag, KindOfAttrValue &koav, const string &sessionID, string &sessionIDVal)
    {
      wxString atag, match, wxstruri, attribWDQ, attribWSQ, attribWOQ, attribWOQ1;
      bool singleQuote, doubleQuote;

      hasImgSrc = false;
      hasImgTag = false;
      size_t attribStart, attribLen, offset, startWDQ, lenWDQ, startWSQ, lenWSQ, startWOQ, lenWOQ;

      bool hasWSQ = true,
           hasWDQ = true,
           hasWOQ = true;

      start = 0;
      len = 0;
      startOfTag = 0;
      lenOfTag = 0;

      while(this->m_wxregex_imgtag.Matches(wx_part_of_page) 
        && (hasWDQ || hasWSQ || hasWOQ) 
        && (!hasImgSrc))
      {
        if(this->m_wxregex_imgtag.GetMatch(&start, &len, 0))
        {
          startOfTag = start;
          lenOfTag = len;
          start = start + 2;
          len = len - 2;
          offset = start;
          hasImgTag = true;

          while ((hasWDQ || hasWSQ || hasWOQ) && (!hasImgSrc))
          {
            startWDQ = 0;
            lenWDQ = 0;
            startWSQ = 0;
            lenWSQ = 0;
            startWOQ = 0;
            lenWOQ = 0;

            hasWDQ = false;
            hasWSQ = false;
            hasWOQ = false;

            atag = wx_part_of_page.Mid(offset, len);
            if (this->m_wxregex_attributeWDQ.Matches(atag))
            {
              if(this->m_wxregex_attributeWDQ.GetMatch(&attribStart, &attribLen, 0))
              {
                hasWDQ = true;
                attribWDQ = atag.Mid(attribStart + 1, attribLen - 1);
                startWDQ = offset + attribStart;
                lenWDQ = attribLen;
              }
            }

            if (this->m_wxregex_attributeWSQ.Matches(atag))
            {
              if(this->m_wxregex_attributeWSQ.GetMatch(&attribStart, &attribLen, 0))
              {
                hasWSQ = true;
                attribWSQ = atag.Mid(attribStart + 1, attribLen - 1);
                startWSQ = offset + attribStart;
                lenWSQ = attribLen;
              }
            }

            if (this->m_wxregex_attributeWOQ.Matches(atag))
            {
              if(this->m_wxregex_attributeWOQ.GetMatch(&attribStart, &attribLen, 0))
              {
                hasWOQ = true;
                attribWOQ = atag.Mid(attribStart + 1, attribLen - 1);
                startWOQ = offset + attribStart;
                lenWOQ = attribLen;
              }
              if (this->m_wxregex_attributeWOQ.GetMatch(&attribStart, &attribLen, 1))
              {
                attribWOQ1 = atag.Mid(attribStart, attribLen);
              }
            }
            


            if (   ((hasWDQ && (!hasWSQ) && (!hasWOQ)))
                || ((hasWDQ && hasWSQ && (!hasWOQ)) && (startWDQ <= startWSQ))
                || ((hasWDQ && (!hasWSQ) && hasWOQ) && (startWDQ <= startWOQ))
                || ((hasWDQ && hasWSQ && hasWOQ && (startWDQ <= startWOQ) && (startWDQ <= startWSQ))))
            {
              if (attribWDQ.Upper().StartsWith(wxT("SRC")))
              {
                if (this->m_wxregex_srcReplacer.Matches(attribWDQ))
                {
                  if(this->m_wxregex_srcReplacer.GetMatch(&attribStart, &attribLen, 1))
                  {
                    match = attribWDQ.Mid(attribStart, attribLen);
                    
                    // usuwam pocz�tkowy znak "
                    doubleQuote = (match.Find(wxT("\"")) == 0);
                    if (doubleQuote)
                      match = match.Mid(1);
                                  
                    if (doubleQuote)
                    {
                      if (match.EndsWith(wxT("\"")))
                        match.Truncate(match.Len() - 1);
                    }
                    hasImgSrc = true;
                    start = startWDQ;
                    len   = lenWDQ;
                    koav  = koavWDQimg;
                    break;
                  }
                }
              }
              offset = startWDQ + lenWDQ;
              len = lenOfTag + startOfTag - offset;
            }
            else if (   ((hasWSQ && (!hasWDQ) && (!hasWOQ)))
                     || ((hasWSQ && hasWDQ && (!hasWOQ)) && (startWSQ <= startWDQ))
                     || ((hasWSQ && (!hasWDQ) && hasWOQ) && (startWSQ <= startWOQ))
                     || ((hasWSQ && hasWDQ && hasWOQ && (startWSQ <= startWOQ) && (startWSQ <= startWDQ))))
            {
              if (attribWSQ.Upper().StartsWith(wxT("SRC")))
              {
                if (this->m_wxregex_srcReplacer.Matches(attribWSQ))
                {
                  if(this->m_wxregex_srcReplacer.GetMatch(&attribStart, &attribLen, 1))
                  {
                    match = attribWSQ.Mid(attribStart, attribLen);

                    // usuwam pocz�tkowy znak ' lub "
                    singleQuote = (match.Find(wxT("'")) == 0);
                    if (singleQuote)
                      match = match.Mid(1);
                                  
                    // usuwam ko�cowy znak ' lub "
                    if (singleQuote)
                    {
                      if (match.EndsWith(wxT("'")))
                        match.Truncate(match.Len() - 1);
                    }
                    hasImgSrc = true;
                    start = startWSQ;
                    len   = lenWSQ;
                    koav  = koavWSQimg;

                    break;
                  }
                }
              }
              offset = startWSQ + lenWSQ;
              len = lenOfTag + startOfTag - offset;
            }
            else if (   ((hasWOQ && (!hasWDQ) && (!hasWSQ)))
                     || ((hasWOQ && hasWDQ && (!hasWSQ)) && (startWOQ <= startWDQ))
                     || ((hasWOQ && (!hasWDQ) && hasWSQ) && (startWOQ <= startWSQ))
                     || ((hasWOQ && hasWDQ && hasWSQ && (startWOQ <= startWSQ) && (startWOQ <= startWDQ))))
            {
              if (attribWOQ.Upper().StartsWith(wxT("SRC")))
              {
                if (this->m_wxregex_srcReplacer.Matches(attribWOQ))
                {
                  if(this->m_wxregex_srcReplacer.GetMatch(&attribStart, &attribLen, 1))
                  {
                    match = attribWOQ.Mid(attribStart, attribLen);

                    hasImgSrc = true;
                    start = startWOQ;
                    len   = lenWOQ;
                    koav  = koavWOQimg;

                    if (attribWOQ1.EndsWith(wxT(">")))
                      len   = lenWOQ - 1;

                    break;
                  }
                }
                else if (this->m_wxregex_srcReplacerWOEQ.Matches(attribWOQ))
                {

                  match = baseURI.BuildURI();
                  hasImgSrc = true;
                  start = startWOQ;
                  koav  = koavWOQimg;

                  if (attribWOQ1.EndsWith(wxT(">")))
                    len   = lenWOQ - 1;
                  else if (this->m_wxregex_spaces.Matches(attribWOQ1)) // test dla przypadku gdy attribWOQ1 zawiera same znaki \\s
                  {
                    if (this->m_wxregex_spaces.GetMatch(&attribStart, &attribLen, 0))
                    {
                      if ((attribStart == 0) && (attribLen == attribWOQ1.Len()))
                      {
                        len = lenWOQ - attribLen;                        
                      }
                    }
                  }
                  else
                    len = lenWOQ;

                  break;
                }

              }
              offset = startWOQ + lenWOQ;
              len = lenOfTag + startOfTag - offset;
            }

          }
        }
      }

      wxURI uri(match);
      uri.Resolve(baseURI, wxURI_STRICT);
      if (!sessionID.empty())
      {
        wxstruri = uri.GetScheme() + wxT("://");
        if (uri.HasUserInfo())
        {
          wxstruri += uri.GetUser();
          if (!uri.GetPassword().IsEmpty())
            wxstruri += wxT(":") + uri.GetPassword();
          wxstruri += wxT("@");
        }
        wxstruri += uri.GetServer();
        if (uri.HasPort())
        {
          wxstruri += wxT(":") + uri.GetPort();
        }

        wxstruri += uri.GetPath();

        match = uri.GetQuery();
        if(this->m_wxregex_sessionIDremoval.Matches(match))
        {
          size_t start, len;
          if (this->m_wxregex_sessionIDremoval.GetMatch(&start, &len, 2))
            sessionIDVal = wx2std(match.Mid(start, len), &this->m_wxCSUTF8);
          else
            sessionIDVal = "";

          this->m_wxregex_sessionIDremoval.ReplaceAll(&match, wxT(""));
        }
        if (!match.IsEmpty())
        {
          if (match.Find(wxT("&")) == 0)
            match = match.Mid(1);
          match = wxT("?") + match;
        }

        if (uri.HasFragment())
          wxstruri += match + wxT("#") + uri.GetFragment();
        else
          wxstruri += match;

        uri.Create(wxstruri);
      }
      return uri;      
    }

    wxURI Utils::match_link_tag(const wxString &wx_part_of_page, const wxURI &baseURI, bool &hasLinkHref, bool &hasLinkTag, size_t &start, size_t &len, size_t &startOfTag, size_t &lenOfTag, KindOfAttrValue &koav, const string &sessionID, string &sessionIDVal)
    {
      wxString atag, match, wxstruri, attribWDQ, attribWSQ, attribWOQ, attribWOQ1;
      bool singleQuote, doubleQuote;

      hasLinkHref = false;
      hasLinkTag = false;
      size_t attribStart, attribLen, offset, startWDQ, lenWDQ, startWSQ, lenWSQ, startWOQ, lenWOQ;

      bool hasWSQ = true,
           hasWDQ = true,
           hasWOQ = true;

      start = 0;
      len = 0;
      startOfTag = 0;
      lenOfTag = 0;

      while(this->m_wxregex_linktag.Matches(wx_part_of_page) 
        && (hasWDQ || hasWSQ || hasWOQ) 
        && (!hasLinkHref))
      {
        if(this->m_wxregex_linktag.GetMatch(&start, &len, 0))
        {
          startOfTag = start;
          lenOfTag = len;
          start = start + 2;
          len = len - 2;
          offset = start;
          hasLinkTag = true;

          while ((hasWDQ || hasWSQ || hasWOQ) && (!hasLinkHref))
          {
            startWDQ = 0;
            lenWDQ = 0;
            startWSQ = 0;
            lenWSQ = 0;
            startWOQ = 0;
            lenWOQ = 0;

            hasWDQ = false;
            hasWSQ = false;
            hasWOQ = false;

            atag = wx_part_of_page.Mid(offset, len);
            if (this->m_wxregex_attributeWDQ.Matches(atag))
            {
              if(this->m_wxregex_attributeWDQ.GetMatch(&attribStart, &attribLen, 0))
              {
                hasWDQ = true;
                attribWDQ = atag.Mid(attribStart + 1, attribLen - 1);
                startWDQ = offset + attribStart;
                lenWDQ = attribLen;
              }
            }

            if (this->m_wxregex_attributeWSQ.Matches(atag))
            {
              if(this->m_wxregex_attributeWSQ.GetMatch(&attribStart, &attribLen, 0))
              {
                hasWSQ = true;
                attribWSQ = atag.Mid(attribStart + 1, attribLen - 1);
                startWSQ = offset + attribStart;
                lenWSQ = attribLen;
              }
            }

            if (this->m_wxregex_attributeWOQ.Matches(atag))
            {
              if(this->m_wxregex_attributeWOQ.GetMatch(&attribStart, &attribLen, 0))
              {
                hasWOQ = true;
                attribWOQ = atag.Mid(attribStart + 1, attribLen - 1);
                startWOQ = offset + attribStart;
                lenWOQ = attribLen;
              }
              if (this->m_wxregex_attributeWOQ.GetMatch(&attribStart, &attribLen, 1))
              {
                attribWOQ1 = atag.Mid(attribStart, attribLen);
              }
            }
            


            if (   ((hasWDQ && (!hasWSQ) && (!hasWOQ)))
                || ((hasWDQ && hasWSQ && (!hasWOQ)) && (startWDQ <= startWSQ))
                || ((hasWDQ && (!hasWSQ) && hasWOQ) && (startWDQ <= startWOQ))
                || ((hasWDQ && hasWSQ && hasWOQ && (startWDQ <= startWOQ) && (startWDQ <= startWSQ))))
            {
              if (attribWDQ.Upper().StartsWith(wxT("HREF")))
              {
                if (this->m_wxregex_hrefReplacer.Matches(attribWDQ))
                {
                  if(this->m_wxregex_hrefReplacer.GetMatch(&attribStart, &attribLen, 1))
                  {
                    match = attribWDQ.Mid(attribStart, attribLen);
                    
                    // usuwam pocz�tkowy znak "
                    doubleQuote = (match.Find(wxT("\"")) == 0);
                    if (doubleQuote)
                      match = match.Mid(1);
                                  
                    if (doubleQuote)
                    {
                      if (match.EndsWith(wxT("\"")))
                        match.Truncate(match.Len() - 1);
                    }
                    hasLinkHref = true;
                    start = startWDQ;
                    len   = lenWDQ;
                    koav  = koavWDQ;
                    break;
                  }
                }
              }
              offset = startWDQ + lenWDQ;
              len = lenOfTag + startOfTag - offset;
            }
            else if (   ((hasWSQ && (!hasWDQ) && (!hasWOQ)))
                     || ((hasWSQ && hasWDQ && (!hasWOQ)) && (startWSQ <= startWDQ))
                     || ((hasWSQ && (!hasWDQ) && hasWOQ) && (startWSQ <= startWOQ))
                     || ((hasWSQ && hasWDQ && hasWOQ && (startWSQ <= startWOQ) && (startWSQ <= startWDQ))))
            {
              if (attribWSQ.Upper().StartsWith(wxT("HREF")))
              {
                if (this->m_wxregex_hrefReplacer.Matches(attribWSQ))
                {
                  if(this->m_wxregex_hrefReplacer.GetMatch(&attribStart, &attribLen, 1))
                  {
                    match = attribWSQ.Mid(attribStart, attribLen);

                    // usuwam pocz�tkowy znak ' lub "
                    singleQuote = (match.Find(wxT("'")) == 0);
                    if (singleQuote)
                      match = match.Mid(1);
                                  
                    // usuwam ko�cowy znak ' lub "
                    if (singleQuote)
                    {
                      if (match.EndsWith(wxT("'")))
                        match.Truncate(match.Len() - 1);
                    }
                    hasLinkHref = true;
                    start = startWSQ;
                    len   = lenWSQ;
                    koav  = koavWSQ;

                    break;
                  }
                }
              }
              offset = startWSQ + lenWSQ;
              len = lenOfTag + startOfTag - offset;
            }
            else if (   ((hasWOQ && (!hasWDQ) && (!hasWSQ)))
                     || ((hasWOQ && hasWDQ && (!hasWSQ)) && (startWOQ <= startWDQ))
                     || ((hasWOQ && (!hasWDQ) && hasWSQ) && (startWOQ <= startWSQ))
                     || ((hasWOQ && hasWDQ && hasWSQ && (startWOQ <= startWSQ) && (startWOQ <= startWDQ))))
            {
              if (attribWOQ.Upper().StartsWith(wxT("HREF")))
              {
                if (this->m_wxregex_hrefReplacer.Matches(attribWOQ))
                {
                  if(this->m_wxregex_hrefReplacer.GetMatch(&attribStart, &attribLen, 1))
                  {
                    match = attribWOQ.Mid(attribStart, attribLen);

                    hasLinkHref = true;
                    start = startWOQ;
                    len   = lenWOQ;
                    koav  = koavWOQ;

                    if (attribWOQ1.EndsWith(wxT(">")))
                      len   = lenWOQ - 1;

                    break;
                  }
                }
                else if (this->m_wxregex_hrefReplacerWOEQ.Matches(attribWOQ))
                {

                  match = baseURI.BuildURI();
                  hasLinkHref = true;
                  start = startWOQ;
                  koav  = koavWOQ;

                  if (attribWOQ1.EndsWith(wxT(">")))
                    len   = lenWOQ - 1;
                  else if (this->m_wxregex_spaces.Matches(attribWOQ1)) // test dla przypadku gdy attribWOQ1 zawiera same znaki \\s
                  {
                    if (this->m_wxregex_spaces.GetMatch(&attribStart, &attribLen, 0))
                    {
                      if ((attribStart == 0) && (attribLen == attribWOQ1.Len()))
                      {
                        len = lenWOQ - attribLen;                        
                      }
                    }
                  }
                  else
                    len = lenWOQ;

                  break;
                }

              }
              offset = startWOQ + lenWOQ;
              len = lenOfTag + startOfTag - offset;
            }

          }
        }
      }

      wxURI uri(match);
      uri.Resolve(baseURI, wxURI_STRICT);
      if (!sessionID.empty())
      {
        wxstruri = uri.GetScheme() + wxT("://");
        if (uri.HasUserInfo())
        {
          wxstruri += uri.GetUser();
          if (!uri.GetPassword().IsEmpty())
            wxstruri += wxT(":") + uri.GetPassword();
          wxstruri += wxT("@");
        }
        wxstruri += uri.GetServer();
        if (uri.HasPort())
        {
          wxstruri += wxT(":") + uri.GetPort();
        }

        wxstruri += uri.GetPath();

        match = uri.GetQuery();
        if(this->m_wxregex_sessionIDremoval.Matches(match))
        {
          size_t start, len;
          this->m_wxregex_sessionIDremoval.GetMatch(&start, &len, 2);
          sessionIDVal = wx2std(match.Mid(start, len), &this->m_wxCSUTF8);

          this->m_wxregex_sessionIDremoval.ReplaceAll(&match, wxT(""));
        }
        if (!match.IsEmpty())
        {
          if (match.Find(wxT("&")) == 0)
            match = match.Mid(1);
          match = wxT("?") + match;
        }

        if (uri.HasFragment())
          wxstruri += match + wxT("#") + uri.GetFragment();
        else
          wxstruri += match;

        uri.Create(wxstruri);
      }
      return uri;
    }

    wxURI Utils::match_base_tag(const wxString &wx_part_of_page, bool &hasBaseHref, bool &hasBaseTag, size_t &start, size_t &len, size_t &startOfTag, size_t &lenOfTag, wxURI *wxuri, boost::mutex &downloadthread_m_wxuri_mutex)
    {

      wxString atag, match, wxstruri, attribWDQ, attribWSQ, attribWOQ, attribWOQ1;
      bool singleQuote, doubleQuote;

      hasBaseHref = false;
      hasBaseTag = false;
      size_t attribStart, attribLen, offset, startWDQ, lenWDQ, startWSQ, lenWSQ, startWOQ, lenWOQ;

      bool hasWSQ = true,
           hasWDQ = true,
           hasWOQ = true;

      start = 0;
      len = 0;
      startOfTag = 0;
      lenOfTag = 0;

      while(this->m_wxregex_basetag.Matches(wx_part_of_page) 
        && (hasWDQ || hasWSQ || hasWOQ)  
        && (!hasBaseHref))
      {
        if(this->m_wxregex_basetag.GetMatch(&start, &len, 0))
        {
          lenOfTag = len - 1;
          startOfTag = start;
          hasBaseTag = true;

          start = start + 5;
          len = len - 5;
          offset = start;

          while ((hasWDQ || hasWSQ || hasWOQ) && (!hasBaseHref))
          {
            startWDQ = 0;
            lenWDQ = 0;
            startWSQ = 0;
            lenWSQ = 0;
            startWOQ = 0;
            lenWOQ = 0;

            hasWDQ = false;
            hasWSQ = false;
            hasWOQ = false;

            atag = wx_part_of_page.Mid(offset, len);
            if (this->m_wxregex_attributeWDQ.Matches(atag))
            {
              if(this->m_wxregex_attributeWDQ.GetMatch(&attribStart, &attribLen, 0))
              {
                hasWDQ = true;
                attribWDQ = atag.Mid(attribStart + 1, attribLen - 1);
                startWDQ = offset + attribStart;
                lenWDQ = attribLen;
              }
            }

            if (this->m_wxregex_attributeWSQ.Matches(atag))
            {
              if(this->m_wxregex_attributeWSQ.GetMatch(&attribStart, &attribLen, 0))
              {
                hasWSQ = true;
                attribWSQ = atag.Mid(attribStart + 1, attribLen - 1);
                startWSQ = offset + attribStart;
                lenWSQ = attribLen;
              }
            }

            if (this->m_wxregex_attributeWOQ.Matches(atag))
            {
              if(this->m_wxregex_attributeWOQ.GetMatch(&attribStart, &attribLen, 0))
              {
                hasWOQ = true;
                attribWOQ = atag.Mid(attribStart + 1, attribLen - 1);
                startWOQ = offset + attribStart;
                lenWOQ = attribLen;
              }
              if (this->m_wxregex_attributeWOQ.GetMatch(&attribStart, &attribLen, 1))
              {
                attribWOQ1 = atag.Mid(attribStart, attribLen);
              }
            }
            
            if (   ((hasWDQ && (!hasWSQ) && (!hasWOQ)))
                || ((hasWDQ && hasWSQ && (!hasWOQ)) && (startWDQ <= startWSQ))
                || ((hasWDQ && (!hasWSQ) && hasWOQ) && (startWDQ <= startWOQ))
                || ((hasWDQ && hasWSQ && hasWOQ && (startWDQ <= startWOQ) && (startWDQ <= startWSQ))))
            {
              if (attribWDQ.Upper().StartsWith(wxT("HREF")))
              {
                if (this->m_wxregex_hrefReplacer.Matches(attribWDQ))
                {
                  if(this->m_wxregex_hrefReplacer.GetMatch(&attribStart, &attribLen, 1))
                  {
                    match = attribWDQ.Mid(attribStart, attribLen);
                    
                    // usuwam pocz�tkowy znak "
                    doubleQuote = (match.Find(wxT("\"")) == 0);
                    if (doubleQuote)
                      match = match.Mid(1);
                                  
                    // "
                    if (doubleQuote)
                    {
                      if (match.EndsWith(wxT("\"")))
                        match.Truncate(match.Len() - 1);
                    }
                    hasBaseHref = true;
                    start = startWDQ;
                    len   = lenWDQ;

                    break;
                  }
                }
              }
              offset = startWDQ + lenWDQ;
              len = lenOfTag + startOfTag - offset;
            }
            else if (   ((hasWSQ && (!hasWDQ) && (!hasWOQ)))
                     || ((hasWSQ && hasWDQ && (!hasWOQ)) && (startWSQ <= startWDQ))
                     || ((hasWSQ && (!hasWDQ) && hasWOQ) && (startWSQ <= startWOQ))
                     || ((hasWSQ && hasWDQ && hasWOQ && (startWSQ <= startWOQ) && (startWSQ <= startWDQ))))
            {
              if (attribWSQ.Upper().StartsWith(wxT("HREF")))
              {
                if (this->m_wxregex_hrefReplacer.Matches(attribWSQ))
                {
                  if(this->m_wxregex_hrefReplacer.GetMatch(&attribStart, &attribLen, 1))
                  {
                    match = attribWSQ.Mid(attribStart, attribLen);

                    // usuwam pocz�tkowy znak '
                    singleQuote = (match.Find(wxT("'")) == 0);
                    if (singleQuote)
                      match = match.Mid(1);
                                  
                    // usuwam ko�cowy znak ' lub "
                    if (singleQuote)
                    {
                      if (match.EndsWith(wxT("'")))
                        match.Truncate(match.Len() - 1);
                    }
                    hasBaseHref = true;
                    start = startWSQ;
                    len   = lenWSQ;

                    break;
                  }
                }
              }
              offset = startWSQ + lenWSQ;
              len = lenOfTag + startOfTag - offset;
            }
            else if (   ((hasWOQ && (!hasWDQ) && (!hasWSQ)))
                     || ((hasWOQ && hasWDQ && (!hasWSQ)) && (startWOQ <= startWDQ))
                     || ((hasWOQ && (!hasWDQ) && hasWSQ) && (startWOQ <= startWSQ))
                     || ((hasWOQ && hasWDQ && hasWSQ && (startWOQ <= startWSQ) && (startWOQ <= startWDQ))))
            {
              if (attribWOQ.Upper().StartsWith(wxT("HREF")))
              {
                if (this->m_wxregex_hrefReplacer.Matches(attribWOQ))
                {
                  if(this->m_wxregex_hrefReplacer.GetMatch(&attribStart, &attribLen, 1))
                  {
                    match = attribWOQ.Mid(attribStart, attribLen);
                    hasBaseHref = true;
                    start = startWOQ;
                    len   = lenWOQ;
                    if (attribWOQ1.EndsWith(wxT(">")))
                      len   = lenWOQ - 1;

                    break;
                  }
                }
                else if (this->m_wxregex_hrefReplacerWOEQ.Matches(attribWOQ))
                {
                  match = wxT("");
                  hasBaseHref = true;
                  start = startWOQ;
                  len   = lenWOQ;

                  if (attribWOQ1.EndsWith(wxT(">")))
                    len   = lenWOQ - 1;
                  else if (this->m_wxregex_spaces.Matches(attribWOQ1)) // test dla przypadku gdy attribWOQ1 zawiera same znaki \\s
                  {
                    if (this->m_wxregex_spaces.GetMatch(&attribStart, &attribLen, 0))
                    {
                      if ((attribStart == 0) && (attribLen == attribWOQ1.Len()))
                      {
                        len = lenWOQ - attribLen;                        
                      }
                    }
                  }
                  else
                    len = lenWOQ;

                  break;
                }
              }
              offset = startWOQ + lenWOQ;
              len = lenOfTag + startOfTag - offset;
            }

          }
        }
      }

      wxURI uri(match);

      if (!(uri.HasScheme() && uri.HasServer()))
      {
        boost::lock_guard<boost::mutex> lock(downloadthread_m_wxuri_mutex);

        match = wxuri->GetScheme() + wxT("://");
        if (wxuri->HasUserInfo())
        {
          match += wxuri->GetUser();
          if (!wxuri->GetPassword().IsEmpty())
            match += wxT(":") + uri.GetPassword();
          match += wxT("@");
        }
        match += wxuri->GetServer();
        if (wxuri->HasPort())
        {
          match += wxT(":") + wxuri->GetPort();
        }

        if (!wxuri->HasPath())
          match += wxT("/");
        else
        {
          match += wxuri->GetPath();
          if (!match.EndsWith(wxT("/")))
            match.Truncate(match.Find('/', true) + 1);
        }
      }
      else
      {
        if ((!uri.GetScheme().compare(wxT("http"))) ||
            (!uri.GetScheme().compare(wxT("https")))||
            (!uri.GetScheme().compare(wxT("ftp"))))
        {
          match = uri.GetScheme() + wxT("://");
          if (uri.HasUserInfo())
          {
            match += uri.GetUser();
            if (!uri.GetPassword().IsEmpty())
              match += wxT(":") + uri.GetPassword();
            match += wxT("@");
          }
          match += uri.GetServer();
          if (uri.HasPort())
          {
            match += wxT(":") + uri.GetPort();
          }
          if (!uri.HasPath())
            match += wxT("/");
          else
          {
            match += uri.GetPath();
            if (!match.EndsWith(wxT("/")))
              match.Truncate(match.Find('/', true) + 1);
          }
        }
        else
        {
          boost::lock_guard<boost::mutex> lock(downloadthread_m_wxuri_mutex);

          match = wxuri->GetScheme() + wxT("://");
          if (wxuri->HasUserInfo())
          {
            match += wxuri->GetUser();
            if (!wxuri->GetPassword().IsEmpty())
              match += wxT(":") + uri.GetPassword();
            match += wxT("@");
          }
          match += wxuri->GetServer();

          if (wxuri->HasPort())
          {
            match += wxT(":") + wxuri->GetPort();
          }

          if (!wxuri->HasPath())
            match += wxT("/");
          else
          {
            match += wxuri->GetPath();
            if (!match.EndsWith(wxT("/")))
              match.Truncate(match.Find('/', true) + 1);
          }

        }

      }

      uri.Create(match);

      return uri;
    }

    wxURI Utils::match_a_tag(const wxString &wx_part_of_page, const wxURI &baseURI, bool &hasAHref, bool &hasATag, size_t &start, size_t &len, size_t &startOfTag, size_t &lenOfTag, KindOfAttrValue &koav, const string &sessionID, string &sessionIDVal)
    {
      wxString atag, match, wxstruri, attribWDQ, attribWSQ, attribWOQ, attribWOQ1;
      bool singleQuote, doubleQuote;

      hasAHref = false;
      hasATag = false;
      size_t attribStart, attribLen, offset, startWDQ, lenWDQ, startWSQ, lenWSQ, startWOQ, lenWOQ;

      bool hasWSQ = true,
           hasWDQ = true,
           hasWOQ = true;

      start = 0;
      len = 0;
      startOfTag = 0;
      lenOfTag = 0;

      while(this->m_wxregex_atag.Matches(wx_part_of_page) 
        && (hasWDQ || hasWSQ || hasWOQ) 
        && (!hasAHref))
      {
        if(this->m_wxregex_atag.GetMatch(&start, &len, 0))
        {
          startOfTag = start;
          lenOfTag = len;
          start = start + 2;
          len = len - 2;
          offset = start;
          hasATag = true;

          while ((hasWDQ || hasWSQ || hasWOQ) && (!hasAHref))
          {
            startWDQ = 0;
            lenWDQ = 0;
            startWSQ = 0;
            lenWSQ = 0;
            startWOQ = 0;
            lenWOQ = 0;

            hasWDQ = false;
            hasWSQ = false;
            hasWOQ = false;

            atag = wx_part_of_page.Mid(offset, len);
            if (this->m_wxregex_attributeWDQ.Matches(atag))
            {
              if(this->m_wxregex_attributeWDQ.GetMatch(&attribStart, &attribLen, 0))
              {
                hasWDQ = true;
                attribWDQ = atag.Mid(attribStart + 1, attribLen - 1);
                startWDQ = offset + attribStart;
                lenWDQ = attribLen;
              }
            }

            if (this->m_wxregex_attributeWSQ.Matches(atag))
            {
              if(this->m_wxregex_attributeWSQ.GetMatch(&attribStart, &attribLen, 0))
              {
                hasWSQ = true;
                attribWSQ = atag.Mid(attribStart + 1, attribLen - 1);
                startWSQ = offset + attribStart;
                lenWSQ = attribLen;
              }
            }

            if (this->m_wxregex_attributeWOQ.Matches(atag))
            {
              if(this->m_wxregex_attributeWOQ.GetMatch(&attribStart, &attribLen, 0))
              {
                hasWOQ = true;
                attribWOQ = atag.Mid(attribStart + 1, attribLen - 1);
                startWOQ = offset + attribStart;
                lenWOQ = attribLen;
              }
              if (this->m_wxregex_attributeWOQ.GetMatch(&attribStart, &attribLen, 1))
              {
                attribWOQ1 = atag.Mid(attribStart, attribLen);
              }
            }
            


            if (   ((hasWDQ && (!hasWSQ) && (!hasWOQ)))
                || ((hasWDQ && hasWSQ && (!hasWOQ)) && (startWDQ <= startWSQ))
                || ((hasWDQ && (!hasWSQ) && hasWOQ) && (startWDQ <= startWOQ))
                || ((hasWDQ && hasWSQ && hasWOQ && (startWDQ <= startWOQ) && (startWDQ <= startWSQ))))
            {
              if (attribWDQ.Upper().StartsWith(wxT("HREF")))
              {
                if (this->m_wxregex_hrefReplacer.Matches(attribWDQ))
                {
                  if(this->m_wxregex_hrefReplacer.GetMatch(&attribStart, &attribLen, 1))
                  {
                    match = attribWDQ.Mid(attribStart, attribLen);
                    
                    // usuwam pocz�tkowy znak "
                    doubleQuote = (match.Find(wxT("\"")) == 0);
                    if (doubleQuote)
                      match = match.Mid(1);
                                  
                    if (doubleQuote)
                    {
                      if (match.EndsWith(wxT("\"")))
                        match.Truncate(match.Len() - 1);
                    }
                    hasAHref = true;
                    start = startWDQ;
                    len   = lenWDQ;
                    koav  = koavWDQ;
                    break;
                  }
                }
              }
              offset = startWDQ + lenWDQ;
              len = lenOfTag + startOfTag - offset;
            }
            else if (   ((hasWSQ && (!hasWDQ) && (!hasWOQ)))
                     || ((hasWSQ && hasWDQ && (!hasWOQ)) && (startWSQ <= startWDQ))
                     || ((hasWSQ && (!hasWDQ) && hasWOQ) && (startWSQ <= startWOQ))
                     || ((hasWSQ && hasWDQ && hasWOQ && (startWSQ <= startWOQ) && (startWSQ <= startWDQ))))
            {
              if (attribWSQ.Upper().StartsWith(wxT("HREF")))
              {
                if (this->m_wxregex_hrefReplacer.Matches(attribWSQ))
                {
                  if(this->m_wxregex_hrefReplacer.GetMatch(&attribStart, &attribLen, 1))
                  {
                    match = attribWSQ.Mid(attribStart, attribLen);

                    // usuwam pocz�tkowy znak ' lub "
                    singleQuote = (match.Find(wxT("'")) == 0);
                    if (singleQuote)
                      match = match.Mid(1);
                                  
                    // usuwam ko�cowy znak ' lub "
                    if (singleQuote)
                    {
                      if (match.EndsWith(wxT("'")))
                        match.Truncate(match.Len() - 1);
                    }
                    hasAHref = true;
                    start = startWSQ;
                    len   = lenWSQ;
                    koav  = koavWSQ;

                    break;
                  }
                }
              }
              offset = startWSQ + lenWSQ;
              len = lenOfTag + startOfTag - offset;
            }
            else if (   ((hasWOQ && (!hasWDQ) && (!hasWSQ)))
                     || ((hasWOQ && hasWDQ && (!hasWSQ)) && (startWOQ <= startWDQ))
                     || ((hasWOQ && (!hasWDQ) && hasWSQ) && (startWOQ <= startWSQ))
                     || ((hasWOQ && hasWDQ && hasWSQ && (startWOQ <= startWSQ) && (startWOQ <= startWDQ))))
            {
              if (attribWOQ.Upper().StartsWith(wxT("HREF")))
              {
                if (this->m_wxregex_hrefReplacer.Matches(attribWOQ))
                {
                  if(this->m_wxregex_hrefReplacer.GetMatch(&attribStart, &attribLen, 1))
                  {
                    match = attribWOQ.Mid(attribStart, attribLen);

                    hasAHref = true;
                    start = startWOQ;
                    len   = lenWOQ;
                    koav  = koavWOQ;

                    if (attribWOQ1.EndsWith(wxT(">")))
                      len   = lenWOQ - 1;

                    break;
                  }
                }
                else if (this->m_wxregex_hrefReplacerWOEQ.Matches(attribWOQ))
                {

                  match = baseURI.BuildURI();
                  hasAHref = true;
                  start = startWOQ;
                  koav  = koavWOQ;

                  if (attribWOQ1.EndsWith(wxT(">")))
                    len   = lenWOQ - 1;
                  else if (this->m_wxregex_spaces.Matches(attribWOQ1)) // test dla przypadku gdy attribWOQ1 zawiera same znaki \\s
                  {
                    if (this->m_wxregex_spaces.GetMatch(&attribStart, &attribLen, 0))
                    {
                      if ((attribStart == 0) && (attribLen == attribWOQ1.Len()))
                      {
                        len = lenWOQ - attribLen;                        
                      }
                    }
                  }
                  else
                    len = lenWOQ;

                  break;
                }

              }
              offset = startWOQ + lenWOQ;
              len = lenOfTag + startOfTag - offset;
            }

          }
        }
      }

      wxURI uri(match);
      uri.Resolve(baseURI, wxURI_STRICT);
      if (!sessionID.empty())
      {
        wxstruri = uri.GetScheme() + wxT("://");
        if (uri.HasUserInfo())
        {
          wxstruri += uri.GetUser();
          if (!uri.GetPassword().IsEmpty())
            wxstruri += wxT(":") + uri.GetPassword();
          wxstruri += wxT("@");
        }
        wxstruri += uri.GetServer();
        if (uri.HasPort())
        {
          wxstruri += wxT(":") + uri.GetPort();
        }

        wxstruri += uri.GetPath();

        match = uri.GetQuery();
        if(this->m_wxregex_sessionIDremoval.Matches(match))
        {
          size_t start, len;
          this->m_wxregex_sessionIDremoval.GetMatch(&start, &len, 2);
          sessionIDVal = wx2std(match.Mid(start, len), &this->m_wxCSUTF8);
            
          this->m_wxregex_sessionIDremoval.ReplaceAll(&match, wxT(""));
        }
        if (!match.IsEmpty())
        {
          if (match.Find(wxT("&")) == 0)
            match = match.Mid(1);
          match = wxT("?") + match;
        }

        if (uri.HasFragment())
          wxstruri += match + wxT("#") + uri.GetFragment();
        else
          wxstruri += match;

        uri.Create(wxstruri);
      }
      return uri;
    }
        
    wxURI Utils::buildURIWithPathAfterServer(const wxURI *wxuri)
    {
      wxString uri;
      if (wxuri)
      {
        if (wxuri->HasScheme())
        {
          uri = wxuri->GetScheme();
          uri += wxT("://");
        }
        if (wxuri->HasUserInfo())
        {
          uri += wxuri->GetUser();
          if (!wxuri->GetPassword().IsEmpty())
            uri += wxT(":") + wxuri->GetPassword();
          uri += wxT("@");
        }
        if (wxuri->HasServer())
          uri += wxuri->GetServer();
        if (wxuri->HasPath())
        {
          uri += wxuri->GetPath();
        }
        else
        {
          if (wxuri->HasServer())
            uri += wxT("/");
        }
        if (wxuri->HasQuery())
          uri += wxT("?") + wxuri->GetQuery();
        if (wxuri->HasFragment())
          uri += wxT("#") + wxuri->GetFragment();
      }
      return wxURI(uri);
    }
        
    wxURI Utils::buildURIWithQueryParam(const wxURI *wxuri, const wxString &qparam, const wxString &qvalue)
    {
      wxString uri;
      if (wxuri)
      {
        if (wxuri->HasScheme())
        {
          uri = wxuri->GetScheme();
          uri += wxT("://");
        }
        if (wxuri->HasUserInfo())
        {
          uri += wxuri->GetUser();
          if (!wxuri->GetPassword().IsEmpty())
            uri += wxT(":") + wxuri->GetPassword();
          uri += wxT("@");
        }
        if (wxuri->HasServer())
          uri += wxuri->GetServer();
        if (wxuri->HasPath())
        {
          uri += wxuri->GetPath();
        }
        else
        {
          if (wxuri->HasServer())
            uri += wxT("/");
        }
        uri += (wxuri->HasQuery() ? (wxT("?") + wxuri->GetQuery() + wxT("&") + qparam + wxT("=") + qvalue)
                                 :  (wxT("?") + qparam + wxT("=") + qvalue));

        if (wxuri->HasFragment())
          uri += wxT("#") + wxuri->GetFragment();
      }
      return wxURI(uri);
    }


    KindOfContentTypeValue Utils::match_content_type(const string &httpResponseHeader)
    {
      string content_type;
      // checking the content type in http response
      wxCSConv wxCSUTF8(wxFONTENCODING_UTF8);


      boost::match_results<string::const_iterator> matchesi;
      //boost::match_results<string::const_iterator> matches;

      string::const_iterator begini;

      begini = httpResponseHeader.begin();

      while (boost::regex_search(begini, httpResponseHeader.end(), matchesi, Utils::mcs_regex_contentType, boost::match_default))
      {
        if (matchesi.size() > 0)
          content_type.assign(matchesi[1].first, matchesi[1].second);
        begini = matchesi[1].second;
      }

      //if (boost::regex_search(this->m_httpResponseHeader, matches, DownloadThread::mcs_regex_contentType, boost::match_default))
      //{
      //  if (matches.size() > 0)
      //    content_type.assign(matches[1].first, matches[1].second);
      //}

      SyNaT::MIR::MR::MusicRobotApp::ptr_map_string_string::iterator i = SyNaT::MIR::MR::MusicRobotApp::mcs_mime.find(wx2std(std2wx(content_type, &wxCSUTF8).Upper(), &wxCSUTF8));

      KindOfContentTypeValue koctv_content_type;

      if ((!content_type.empty()) && (i != SyNaT::MIR::MR::MusicRobotApp::mcs_mime.end()))
      {
        if ((i->second->find("xml") != string::npos))
          koctv_content_type = koctvXHTML;
        else if (i->second->find("htm") != string::npos)
          koctv_content_type = koctvHTML;
        else if (i->second->find("txt") != string::npos)
          koctv_content_type = koctvPlainText;
        else if (i->second->find("css") != string::npos)
          koctv_content_type = koctvCSS;
        else if (i->second->find("js") != string::npos)
          koctv_content_type = koctvJavaScript;

        else if (i->second->find("snd") != string::npos)
          koctv_content_type = koctvAudioContent;
        else if (i->second->find("mid") != string::npos)
          koctv_content_type = koctvAudioContent;
        else if (i->second->find("mp3") != string::npos)
          koctv_content_type = koctvAudioContent;
        else if (i->second->find("mp4") != string::npos)
          koctv_content_type = koctvAudioContent;
        else if (i->second->find("oga") != string::npos)
          koctv_content_type = koctvAudioContent;
        else if (i->second->find("wma") != string::npos)
          koctv_content_type = koctvAudioContent;
        else if (i->second->find("wax") != string::npos)
          koctv_content_type = koctvAudioContent;
        else if (i->second->find("wmv") != string::npos)
          koctv_content_type = koctvAudioContent;
        else if (i->second->find("mka") != string::npos)
          koctv_content_type = koctvAudioContent;
        else if (i->second->find("ra") != string::npos)
          koctv_content_type = koctvAudioContent;
        else if (i->second->find("wav") != string::npos)
          koctv_content_type = koctvAudioContent;
        else if (i->second->find("mka") != string::npos)
          koctv_content_type = koctvAudioContent;

        else if (i->second->find("m3u") != string::npos)
          koctv_content_type = koctvAudioM3U;

        else if (i->second->find("bmp") != string::npos)
          koctv_content_type = koctvImage;
        else if (i->second->find("cgm") != string::npos)
          koctv_content_type = koctvImage;
        else if (i->second->find("g3") != string::npos)
          koctv_content_type = koctvImage;
        else if (i->second->find("gif") != string::npos)
          koctv_content_type = koctvImage;
        else if (i->second->find("ief") != string::npos)
          koctv_content_type = koctvImage;
        else if (i->second->find("jp2") != string::npos)
          koctv_content_type = koctvImage;
        else if (i->second->find("jpeg") != string::npos)
          koctv_content_type = koctvImage;
        else if (i->second->find("png") != string::npos)
          koctv_content_type = koctvImage;
        else if (i->second->find("btif") != string::npos)
          koctv_content_type = koctvImage;
        else if (i->second->find("svg") != string::npos)
          koctv_content_type = koctvImage;
        else if (i->second->find("tiff") != string::npos)
          koctv_content_type = koctvImage;
        else if (i->second->find("psd") != string::npos)
          koctv_content_type = koctvImage;
        else if (i->second->find("djvu") != string::npos)
          koctv_content_type = koctvImage;
        else if (i->second->find("dwg") != string::npos)
          koctv_content_type = koctvImage;
        else if (i->second->find("dxf") != string::npos)
          koctv_content_type = koctvImage;
        else if (i->second->find("fbs") != string::npos)
          koctv_content_type = koctvImage;
        else if (i->second->find("fpx") != string::npos)
          koctv_content_type = koctvImage;
        else if (i->second->find("fst") != string::npos)
          koctv_content_type = koctvImage;
        else if (i->second->find("mmr") != string::npos)
          koctv_content_type = koctvImage;
        else if (i->second->find("rlc") != string::npos)
          koctv_content_type = koctvImage;
        else if (i->second->find("mdi") != string::npos)
          koctv_content_type = koctvImage;
        else if (i->second->find("npx") != string::npos)
          koctv_content_type = koctvImage;
        else if (i->second->find("wbmp") != string::npos)
          koctv_content_type = koctvImage;
        else if (i->second->find("xif") != string::npos)
          koctv_content_type = koctvImage;
        else if (i->second->find("ras") != string::npos)
          koctv_content_type = koctvImage;
        else if (i->second->find("cmx") != string::npos)
          koctv_content_type = koctvImage;
        else if (i->second->find("fh") != string::npos)
          koctv_content_type = koctvImage;
        else if (i->second->find("ico") != string::npos)
          koctv_content_type = koctvImage;
        else if (i->second->find("pcx") != string::npos)
          koctv_content_type = koctvImage;
        else if (i->second->find("pic") != string::npos)
          koctv_content_type = koctvImage;
        else if (i->second->find("pnm") != string::npos)
          koctv_content_type = koctvImage;
        else if (i->second->find("pbm") != string::npos)
          koctv_content_type = koctvImage;
        else if (i->second->find("pgm") != string::npos)
          koctv_content_type = koctvImage;
        else if (i->second->find("ppm") != string::npos)
          koctv_content_type = koctvImage;
        else if (i->second->find("rgb") != string::npos)
          koctv_content_type = koctvImage;
        else if (i->second->find("xbm") != string::npos)
          koctv_content_type = koctvImage;
        else if (i->second->find("xpm") != string::npos)
          koctv_content_type = koctvImage;
        else if (i->second->find("xwd") != string::npos)
          koctv_content_type = koctvImage;

      }
      else
      {
        koctv_content_type = koctvOther;
      }
      return koctv_content_type;
    }


    string Utils::match_content_type_ext(const string &httpResponseHeader)
    {
      string content_type;
      // checking the content type in http response
      wxCSConv wxCSUTF8(wxFONTENCODING_UTF8);

      boost::match_results<string::const_iterator> matchesi;
      //boost::match_results<string::const_iterator> matches;

      string::const_iterator begini;

      begini = httpResponseHeader.begin();

      while (boost::regex_search(begini, httpResponseHeader.end(), matchesi, Utils::mcs_regex_contentType, boost::match_default))
      {
        if (matchesi.size() > 0)
          content_type.assign(matchesi[1].first, matchesi[1].second);
        begini = matchesi[1].second;
      }

      //if (boost::regex_search(this->m_httpResponseHeader, matches, DownloadThread::mcs_regex_contentType, boost::match_default))
      //{
      //  if (matches.size() > 0)
      //    content_type.assign(matches[1].first, matches[1].second);
      //}

      SyNaT::MIR::MR::MusicRobotApp::ptr_map_string_string::iterator i = SyNaT::MIR::MR::MusicRobotApp::mcs_mime.find(wx2std(std2wx(content_type, &wxCSUTF8).Upper(), &wxCSUTF8));

      string content_type_ext;

      if ((!content_type.empty()) && (i != SyNaT::MIR::MR::MusicRobotApp::mcs_mime.end()))
      {
        if ((i->second->find("xml") != string::npos))
          content_type_ext = "xml";
        else if (i->second->find("htm") != string::npos)
          content_type_ext = "htm";

        else if (i->second->find("txt") != string::npos)
          content_type_ext = "txt";

        else if (i->second->find("snd") != string::npos)
          content_type_ext = "snd";
        else if (i->second->find("mid") != string::npos)
          content_type_ext = "mid";
        else if (i->second->find("mp3") != string::npos)
          content_type_ext = "mp3";
        else if (i->second->find("mp4") != string::npos)
          content_type_ext = "mp4";
        else if (i->second->find("oga") != string::npos)
          content_type_ext = "oga";
        else if (i->second->find("wma") != string::npos)
          content_type_ext = "wma";
        else if (i->second->find("wax") != string::npos)
          content_type_ext = "wax";
        else if (i->second->find("wmv") != string::npos)
          content_type_ext = "wmv";
        else if (i->second->find("mka") != string::npos)
          content_type_ext = "mka";
        else if (i->second->find("ra") != string::npos)
          content_type_ext = "ra";
        else if (i->second->find("wav") != string::npos)
          content_type_ext = "wav";
        else if (i->second->find("mka") != string::npos)
          content_type_ext = "mka";

        else if (i->second->find("m3u") != string::npos)
          content_type_ext = "m3u";
        else if (i->second->find("m3u8") != string::npos)
          content_type_ext = "m3u8";


        else if (i->second->find("css") != string::npos)
          content_type_ext = "css";

        else if (i->second->find("js") != string::npos)
          content_type_ext = "js";

        else if (i->second->find("bmp") != string::npos)
          content_type_ext = "bmp";
        else if (i->second->find("cgm") != string::npos)
          content_type_ext = "cgm";
        else if (i->second->find("g3") != string::npos)
          content_type_ext = "g3";
        else if (i->second->find("gif") != string::npos)
          content_type_ext = "gif";
        else if (i->second->find("ief") != string::npos)
          content_type_ext = "ief";
        else if (i->second->find("jp2") != string::npos)
          content_type_ext = "jp2";
        else if (i->second->find("jpeg") != string::npos)
          content_type_ext = "jpeg";
        else if (i->second->find("png") != string::npos)
          content_type_ext = "png";
        else if (i->second->find("btif") != string::npos)
          content_type_ext = "btif";
        else if (i->second->find("svg") != string::npos)
          content_type_ext = "svg";
        else if (i->second->find("tiff") != string::npos)
          content_type_ext = "tiff";
        else if (i->second->find("psd") != string::npos)
          content_type_ext = "psd";
        else if (i->second->find("djvu") != string::npos)
          content_type_ext = "djvu";
        else if (i->second->find("dwg") != string::npos)
          content_type_ext = "dwg";
        else if (i->second->find("dxf") != string::npos)
          content_type_ext = "dxf";
        else if (i->second->find("fbs") != string::npos)
          content_type_ext = "fbs";
        else if (i->second->find("fpx") != string::npos)
          content_type_ext = "fpx";
        else if (i->second->find("fst") != string::npos)
          content_type_ext = "fst";
        else if (i->second->find("mmr") != string::npos)
          content_type_ext = "mmr";
        else if (i->second->find("rlc") != string::npos)
          content_type_ext = "rlc";
        else if (i->second->find("mdi") != string::npos)
          content_type_ext = "mdi";
        else if (i->second->find("npx") != string::npos)
          content_type_ext = "npx";
        else if (i->second->find("wbmp") != string::npos)
          content_type_ext = "wbmp";
        else if (i->second->find("xif") != string::npos)
          content_type_ext = "xif";
        else if (i->second->find("ras") != string::npos)
          content_type_ext = "ras";
        else if (i->second->find("cmx") != string::npos)
          content_type_ext = "cmx";
        else if (i->second->find("fh") != string::npos)
          content_type_ext = "fh";
        else if (i->second->find("ico") != string::npos)
          content_type_ext = "ico";
        else if (i->second->find("pcx") != string::npos)
          content_type_ext = "pcx";
        else if (i->second->find("pic") != string::npos)
          content_type_ext = "pic";
        else if (i->second->find("pnm") != string::npos)
          content_type_ext = "pnm";
        else if (i->second->find("pbm") != string::npos)
          content_type_ext = "pbm";
        else if (i->second->find("pgm") != string::npos)
          content_type_ext = "pgm";
        else if (i->second->find("ppm") != string::npos)
          content_type_ext = "ppm";
        else if (i->second->find("rgb") != string::npos)
          content_type_ext = "rgb";
        else if (i->second->find("xbm") != string::npos)
          content_type_ext = "xbm";
        else if (i->second->find("xpm") != string::npos)
          content_type_ext = "xpm";
        else if (i->second->find("xwd") != string::npos)
          content_type_ext = "xwd";

      }
      else
      {
        content_type_ext = "";
      }
      return content_type_ext;
    }

    string Utils::match_charset(const string &httpResponse, const string &httpResponseHeader)
    {
      boost::match_results<string::const_iterator> matches;
      string charset;

      // we search in html document first - becouse it is more important
      if (boost::regex_search(httpResponse, matches, Utils::mcs_regex_metacharset, boost::match_default))
      {
        if (matches.size() > 0)
          charset.assign(matches[1].first, matches[1].second);
      }

      // we search for charset inside response header
      if (charset.empty())
      {
        if (boost::regex_search(httpResponseHeader, matches, Utils::mcs_regex_contentTypeCharset, boost::match_default))
        {
          if (matches.size() > 0)
            charset.assign(matches[1].first, matches[1].second);
        }
      }
      return charset;
    }

    wxString Utils::CreateTempFileName(int wxHowManyCallsToCreateTempFileName, const wxString& prefix , wxFile *fileTemp)
    {
      wxString wxfilename = wxFileName::CreateTempFileName(wxT(""));
      wxRemoveFile(wxfilename);
      while((wxHowManyCallsToCreateTempFileName--) > 0)
      {
        wxFileName fn(wxfilename);
        wxfilename = wxFileName::CreateTempFileName(fn.GetName());
        wxRemoveFile(wxfilename);
      }
      return wxfilename;
    }

    wxString Utils::buildDestHref(wxString &wxdirplusfilename, wxURI &wx_a_href, ContentTypeRetriever &ctr, wxFileName &fnrootwww)
    {
      wxString wx_dest_href = Utils::subAllNotAllowedCharsInFilenames(wx_a_href.GetServer());
      wxString wx_a_hrefPathExt = wxT("");
      wxCSConv wxCSUTF8(wxFONTENCODING_UTF8);
      if (wx_a_href.HasPath())
      {
        wxString wx_a_hrefPath = wx_a_href.GetPath();
        wx_a_hrefPath.Replace(wxT("%"), wxT(""));
        wx_a_hrefPath = Utils::subAllNotAllowedCharsInFilenames(wx_a_hrefPath, false, true);
        if (!wx_a_hrefPath.EndsWith(wxT("/")))
        {
          int lastDotPos = wx_a_hrefPath.Find('.', true);
          if (lastDotPos == wxNOT_FOUND)
            wx_a_hrefPathExt = wxT("");
          else
          {
            wx_a_hrefPathExt = wx_a_hrefPath.Mid(lastDotPos + 1);
            wx_a_hrefPath = wx_a_hrefPath.Mid(0, lastDotPos);
          }                                                          
        }
      
        wx_dest_href += wx_a_hrefPath;
      }
      else
      {
        wx_dest_href += wxT("/");
      }

      if (wx_a_href.HasQuery())
        wx_dest_href += Utils::subAllNotAllowedCharsInFilenames(wxT("?") + wx_a_href.GetQuery());
      if (wx_a_href.HasFragment())
        wx_dest_href += Utils::subAllNotAllowedCharsInFilenames(wxT("#") + wx_a_href.GetFragment());


      size_t filename_pos = wx_dest_href.Find('/', true);
      wxString filename = wx_dest_href.Mid(filename_pos + 1);
      wx_dest_href = wx_dest_href.Mid(0, filename_pos);

      // dodaje ograniczenie na długość 255 znaków w nazwie pliku (przyjmuje długość rozszerzenia 5 (4 + 1 na znak kropki)
      if (filename.Len() > 250)
      	filename = filename.Mid(0, 250);

      wx_dest_href += wxT("/") + filename;



      if ((wx_a_href.HasPath() && (!wx_a_href.GetPath().EndsWith(wxT("/"))))
          || wx_a_href.HasQuery()
          || wx_a_href.HasFragment())
      {
        if (!wx_a_hrefPathExt.Cmp(wxT("m3u")) || !wx_a_hrefPathExt.Cmp(wxT("m3u8"))
          || !ctr.getContentTypeExtension().compare("m3u") || !ctr.getContentTypeExtension().compare("m3u8"))
          wx_dest_href += wxT(".htm");
        else
          wx_dest_href += wx_a_hrefPathExt.StartsWith(wxT("mp3")) ? wxT(".mp3") : wx_a_hrefPathExt.IsEmpty() ? ctr.getContentTypeExtension().empty() ? wxT("") : std2wx("." + ctr.getContentTypeExtension(), &wxCSUTF8) : wxT(".") + wx_a_hrefPathExt;
        wxFileName fn;
        fn.Assign(fnrootwww.GetFullPath(wxPATH_UNIX)
                   + fn.GetPathSeparator(wxPATH_UNIX) + wx_dest_href, wxPATH_UNIX);
        fn.Normalize(wxPATH_NORM_LONG|wxPATH_NORM_DOTS|wxPATH_NORM_TILDE|wxPATH_NORM_ABSOLUTE);                
        wxdirplusfilename = fn.GetPath(0, wxPATH_UNIX) + fn.GetPathSeparator(wxPATH_UNIX) + fn.GetFullName();
      }
      else 
      {
        wxString wxfilename;
        {
          boost::lock_guard<boost::mutex> lock(SyNaT::MIR::MR::DownloadThread::ms_downloadthread_wxWidgetsFuncs_mutex);
          wxfilename = Utils::CreateTempFileName(2);
        }
        wxFileName fn(wxfilename);
        fn.Assign(fnrootwww.GetFullPath(wxPATH_UNIX) 
          + fn.GetPathSeparator(wxPATH_UNIX) 
          + wx_dest_href 
          + fn.GetName());
        fn.Normalize(wxPATH_NORM_LONG|wxPATH_NORM_DOTS|wxPATH_NORM_TILDE|wxPATH_NORM_ABSOLUTE);
        if (!wx_a_hrefPathExt.Cmp(wxT("m3u")) || !wx_a_hrefPathExt.Cmp(wxT("m3u8"))
          || !ctr.getContentTypeExtension().compare("m3u") || !ctr.getContentTypeExtension().compare("m3u8"))
          wxfilename = fn.GetFullName() + wxT(".htm");
        else
          wxfilename = fn.GetFullName() + (wx_a_hrefPathExt.IsEmpty() ? (ctr.getContentTypeExtension().empty() ? wxT("") : std2wx("." + ctr.getContentTypeExtension(), &wxCSUTF8) ): wxT(".") + wx_a_hrefPathExt);
        wx_dest_href += wxfilename;
        wxdirplusfilename = fn.GetPath(0, wxPATH_UNIX) + fn.GetPathSeparator(wxPATH_UNIX) + wxfilename;
      }
      return wx_dest_href;
    }
    
    /**
     * path musi zaczynać się od /
     */
    wxString Utils::buildParameterMapFromPath(string path, ptr_map_string_wxString &params, wxCSConv &wxCharSetConv)
    {
      wxString wxpath(path.c_str(), wxCharSetConv);
      wxURI uri(wxpath);
      wxpath = /*wxURI::Unescape(*/uri.BuildUnescapedURI()/*)*/;
      CHARSVParser parser(wxpath, wxT('/'));
      parser.GetNextToken();
      wxString wxReturnPath = parser.HasMoreTokens() ? parser.GetNextToken() : wxT("");
      for(; parser.HasMoreTokens() ; )
      {
        wxString parName = parser.GetNextToken();
        if (parser.HasMoreTokens())
        {
          wxString parValue = parser.GetNextToken();
          params[wx2std(parName, &wxCharSetConv)] = *new wxString(parValue);
        }
        else
        {
          params[wx2std(parName, &wxCharSetConv)] = *new wxString();
        }
      }
      return wxReturnPath;
    }

    wxString Utils::subAllNotAllowedCharsInFilenames(wxString input, bool replaceSlashes, bool doNotReplaceLastDot)
    {
      if (replaceSlashes)
        input.Replace(wxT("/"),  wxT("2f"));
      input.Replace(wxT("\\"), wxT("5c"));
      input.Replace(wxT("?"),  wxT("3f"));
      input.Replace(wxT("%"),  wxT("25"));
      input.Replace(wxT("*"),  wxT("2a"));
      input.Replace(wxT(":"),  wxT("3a"));
      input.Replace(wxT("|"),  wxT("7c"));
      input.Replace(wxT("\""), wxT("22"));
      input.Replace(wxT("<"),  wxT("3c"));
      input.Replace(wxT(">"),  wxT("3e"));
      if (!doNotReplaceLastDot)
        input.Replace(wxT("."),  wxT("2e"));
      else
      {
        int indexOfLastDot = input.Find('.', true);
        wxString withoutLastDot = input.Mid(0, indexOfLastDot == wxNOT_FOUND ? wxString::npos : indexOfLastDot);
        withoutLastDot.Replace(wxT("."), wxT("2e"));
        input = withoutLastDot + (indexOfLastDot == wxNOT_FOUND ? wxT("") : input.Mid(indexOfLastDot));
      }
      return input;
    }



    void Utils::replaceNewlines(wxString &input)
    {
      size_t j = 0;
      for(size_t i = 0; i < input.Len(); i++, j++)
      {
        while ((j < input.Len()) && ((input[j] == '\n') || (input[j] == '\r')))
          j++;
        
        if (i != j)
          input = input.Mid(0, i) + input.Mid(j);
        i = j;
      }
    }


    const boost::regex Utils::mcs_regex_metacharset("<meta[\\s\\x00]+.*?http-equiv[\\s\\x00]*=[\\s\\x00]*[\"']?Content-Type[\"']?.+?content[\\s\\x00]*=[\\s\\x00]*[\"']?.*?charset[\\s\\x00]*=[\\s\\x00]*([-a-z0-9_/]*)", boost::regex::icase);
    const boost::regex Utils::mcs_regex_contentType("Content-Type:[\\s\\x00]*([-a-z0-9_/]*)", boost::regex::icase);
    const boost::regex Utils::mcs_regex_contentTypeCharset("Content-Type:[\\s\\x00]*[^;]*;[\\s\\x00]*charset[\\s\\x00]*=[\\s\\x00]*([-a-z0-9_/]*)", boost::regex::icase);
    const boost::regex Utils::mcs_regex_contentdispositionFilename("content-disposition:[\\s\\x00]*attachment[\\s\\x00]*;[\\s\\x00]*filename[\\s\\x00]*=[\\s\\x00]*(\"[^\"]\"|'[^']'|.*)", boost::regex::icase);
  }
}
