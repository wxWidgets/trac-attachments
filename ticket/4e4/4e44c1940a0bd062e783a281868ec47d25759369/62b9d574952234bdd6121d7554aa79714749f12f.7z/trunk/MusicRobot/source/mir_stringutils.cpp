﻿/*
  $Id$
*/

// For compilers that support precompilation, includes "wx/wx.h".
#include <wx/wxprec.h>

#ifdef __BORLANDC__
    #pragma hdrstop
#endif

// for all others, include the necessary headers (this file is usually all you
// need because it includes almost all "standard" wxWidgets headers
#ifndef WX_PRECOMP
    #include "wx/wx.h"
#endif

#include <Wt/WString>

#include <string>

#include "mir_stringutils.h"

namespace SyNaT
{
  namespace MIR
  {
    using namespace std;

    //-----------------------------------------------------------------------------
    string wx2std(const wxString& input, wxMBConv* oconv)
    {
      if (input.IsEmpty())
          return "";
      if (!oconv)
          oconv = wxConvCurrent;
      const wxWX2MBbuf buf(input.mb_str(*oconv));
      // conversion may fail and return 0, which isn't a safe value to pass
      // to std:string constructor
      if (!buf)
          return "";
      return string(buf, input.size());
    }

    //-----------------------------------------------------------------------------
    wxString std2wx(const string& input, wxMBConv* iconv)
    {
      if (input.empty())
          return wxEmptyString;
      if (!iconv)
          iconv = wxConvCurrent;
      return wxString(input.c_str(), *iconv, input.size());
    }

    //-----------------------------------------------------------------------------
    wxString std2wxIdentifier(const string& input, wxMBConv* iconv)
    {
      if (input.empty())
          return wxEmptyString;
      if (!iconv)
          iconv = wxConvCurrent;
      // trim trailing whitespace
      size_t last = input.find_last_not_of(" ");
      return wxString(input.c_str(), *iconv,
          (last == string::npos) ? string::npos : last + 1);
    }

    //-----------------------------------------------------------------------------
    Wt::WString wx2wts(const wxString& input)
    {
      wxCSConv wxCSUTF8(wxFONTENCODING_UTF8);
      if (input.IsEmpty())
          return "";
      const wxWX2MBbuf buf(input.mb_str(wxCSUTF8));
      // conversion may fail and return 0, which isn't a safe value to pass
      // to std:string constructor
      if (!buf)
          return "";
      
      return Wt::WString(string(buf, input.size()), Wt::UTF8);
    }

    //-----------------------------------------------------------------------------
    wxString wts2wx(const Wt::WString& input)
    {
      wxCSConv wxCSUTF8(wxFONTENCODING_UTF8);
      string utf8str = input.toUTF8();
      return wxString(utf8str.c_str(), wxCSUTF8, utf8str.size());
    }

    //-----------------------------------------------------------------------------
    Wt::WString std2wts(const string& input, wxMBConv* iconv)
    {
      wxCSConv wxCSUTF8(wxFONTENCODING_UTF8);
      if (input.empty())
        return Wt::WString("");
      if (!iconv)
          iconv = wxConvCurrent;
      
      const wxWX2MBbuf buf(wxString(input.c_str(), *iconv, input.size()).mb_str(wxCSUTF8));
      // conversion may fail and return 0, which isn't a safe value to pass
      // to std:string constructor
      if (!buf)
          return "";
      return Wt::WString(string(buf, input.size()), Wt::UTF8);
    }

    //-----------------------------------------------------------------------------
    string wts2std(const Wt::WString& input, wxMBConv* oconv)
    {
      if (!oconv)
          oconv = wxConvCurrent;
      wxCSConv wxCSUTF8(wxFONTENCODING_UTF8);

      string sinput = input.toUTF8();
      wxString wxsinput = wxString(sinput.c_str(), wxCSUTF8, sinput.size());
      const wxWX2MBbuf buf(wxsinput.mb_str(*oconv));
      // conversion may fail and return 0, which isn't a safe value to pass
      // to std:string constructor
      if (!buf)
          return "";
      return string(buf, wxsinput.size());
    }

    //-----------------------------------------------------------------------------
    wxString getHtmlCharset()
    {
    #if !wxUSE_UNICODE
      struct CharsetMapping {
          wxFontEncoding encoding;
          const wxChar* htmlCS;
      };
      static const CharsetMapping mappings[] = {
          { wxFONTENCODING_ISO8859_1, wxT("ISO-8859-1") },
          { wxFONTENCODING_ISO8859_2, wxT("ISO-8859-2") },
          { wxFONTENCODING_ISO8859_3, wxT("ISO-8859-3") },
          { wxFONTENCODING_ISO8859_4, wxT("ISO-8859-4") },
          { wxFONTENCODING_ISO8859_5, wxT("ISO-8859-5") },
          { wxFONTENCODING_ISO8859_6, wxT("ISO-8859-6") },
          { wxFONTENCODING_ISO8859_7, wxT("ISO-8859-7") },
          { wxFONTENCODING_ISO8859_8, wxT("ISO-8859-8") },
          { wxFONTENCODING_ISO8859_9, wxT("ISO-8859-9") },
          { wxFONTENCODING_ISO8859_10, wxT("ISO-8859-10") },
          { wxFONTENCODING_ISO8859_11, wxT("ISO-8859-11") },
          { wxFONTENCODING_ISO8859_12, wxT("ISO-8859-12") },
          { wxFONTENCODING_ISO8859_13, wxT("ISO-8859-13") },
          { wxFONTENCODING_ISO8859_14, wxT("ISO-8859-14") },
          { wxFONTENCODING_ISO8859_15, wxT("ISO-8859-15") },

          { wxFONTENCODING_CP1250, wxT("windows-1250") },
          { wxFONTENCODING_CP1251, wxT("windows-1251") },
          { wxFONTENCODING_CP1252, wxT("windows-1252") },
          { wxFONTENCODING_CP1253, wxT("windows-1253") },
          { wxFONTENCODING_CP1254, wxT("windows-1254") },
          { wxFONTENCODING_CP1255, wxT("windows-1255") },
          { wxFONTENCODING_CP1256, wxT("windows-1256") },
          { wxFONTENCODING_CP1257, wxT("windows-1257") }
      };
      int mappingCount = sizeof(mappings) / sizeof(CharsetMapping);

      wxFontEncoding enc = wxLocale::GetSystemEncoding();
      for (int i = 0; i < mappingCount; i++)
      {
          if (mappings[i].encoding == enc)
              return mappings[i].htmlCS;
      }
    #endif
      return wxT("UTF-8");
    }
    //-----------------------------------------------------------------------------
    wxString escapeHtmlChars(const wxString& input, bool processNewlines)
    {
      if (input.IsEmpty())
          return input;
      wxString result;
      wxString::const_iterator start = input.begin();
      while (start != input.end())
      {
          wxString::const_iterator stop = start;
          while (stop != input.end())
          {
              const wxChar c = *stop;
              if (c == '&' || c == '<' || c == '>' || c == '"'
                  || (processNewlines && (c == '\r' || c == '\n')))
              {
                  if (stop > start)
                      result += wxString(start, stop);
                  if (c == '&')
                      result += wxT("&amp;");
                  else if (c == '<')
                      result += wxT("&lt;");
                  else if (c == '>')
                      result += wxT("&gt;");
                  else if (c == '"')
                      result += wxT("&quot;");
                  else if (c == '\n')
                      result += wxT("<BR>");
                  else if (c == '\r')
                      /* swallow silently */;
                  else
                      wxASSERT_MSG(false, wxT("escape not handled"));
                  // start processing *after* the replaced character
                  ++stop;
                  start = stop;
                  break;
              }
              ++stop;
          }
          if (stop > start)
              result += wxString(start, stop);
          start = stop;
      }
      return result;
    }
    //-----------------------------------------------------------------------------
    wxString escapeXmlChars(const wxString& input)
    {
      if (input.IsEmpty())
          return input;
      wxString result;
      wxString::const_iterator start = input.begin();
      while (start != input.end())
      {
          wxString::const_iterator stop = start;
          while (stop != input.end())
          {
              const wxChar c = *stop;
              if (c == '&' || c == '<' || c == '>' || c == '"')
              {
                  if (stop > start)
                      result += wxString(start, stop);
                  if (c == '&')
                      result += wxT("&amp;");
                  else if (c == '<')
                      result += wxT("&lt;");
                  else if (c == '>')
                      result += wxT("&gt;");
                  else if (c == '"')
                      result += wxT("&quot;");
                  else
                      wxASSERT_MSG(false, wxT("escape not handled"));
                  // start processing *after* the replaced character
                  ++stop;
                  start = stop;
                  break;
              }
              ++stop;
          }
          if (stop > start)
              result += wxString(start, stop);
          start = stop;
      }
      return result;
    }
    //-----------------------------------------------------------------------------
    wxString getBooleanAsString(bool value)
    {
      return (value) ? wxT("true") : wxT("false");
    }
    //-----------------------------------------------------------------------------
    wxString wxArrayToString(const wxArrayString& arrayStr, const wxString& delimiter)
    {
      wxString result;
      for (wxArrayString::const_iterator it = arrayStr.begin();
          it != arrayStr.end(); ++it)
      {
          if (result.IsEmpty())
              result << *(it);
          else
              result << delimiter << *(it);
      }
      return result;
    }
    //-----------------------------------------------------------------------------



  } // namespace MIR
} // namespace SyNaT
