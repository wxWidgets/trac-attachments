﻿// For compilers that support precompilation, includes "wx/wx.h".
#include <wx/wxprec.h>

#ifdef __BORLANDC__
    #pragma hdrstop
#endif

// for all others, include the necessary headers (this file is usually all you
// need because it includes almost all "standard" wxWidgets headers
#ifndef WX_PRECOMP
    #include "wx/wx.h"
#endif

#include <curl/curl.h>


#include <boost/regex.hpp>

#include <string>

#include "mir_utils.h"
#include "mir_contenttyperetriever.h"

namespace SyNaT
{
  namespace MIR
  {
    using namespace std;

    void ContentTypeRetriever::setURI(string &uri)
    {
      curl_easy_setopt(this->m_curl, CURLOPT_SSL_VERIFYPEER, 0L);
      curl_easy_setopt(this->m_curl, CURLOPT_SSL_VERIFYHOST, 0L);
      curl_easy_setopt(this->m_curl, CURLOPT_FOLLOWLOCATION, 1);
      curl_easy_setopt(this->m_curl, CURLOPT_AUTOREFERER, 1);
      curl_easy_setopt(this->m_curl, CURLOPT_COOKIESESSION, 1);
      curl_easy_setopt(this->m_curl, CURLOPT_HTTPGET, 1L);
      curl_easy_setopt(this->m_curl, CURLOPT_URL, uri.c_str());
    }

    void ContentTypeRetriever::Retrieve()
    {
      this->m_httpResponseHeader.clear();
      if(curl_easy_perform(this->m_curl) == CURLE_OK)
      {
        long responseCode;
        if(curl_easy_getinfo(this->m_curl, CURLINFO_RESPONSE_CODE, &responseCode) == CURLE_OK)
        {
          if (responseCode < 400)
            this->m_httpOK = true;
          else
            this->m_httpOK = false;
        }
      }
    }

    KindOfContentTypeValue ContentTypeRetriever::getContentType()
    {
      return Utils::match_content_type(this->m_httpResponseHeader);
    }

    string ContentTypeRetriever::getContentTypeExtension()
    {
      return Utils::match_content_type_ext(this->m_httpResponseHeader);
    }

    extern "C" 
    {
      size_t ContentTypeRetriever::write_data(void *ptr, size_t size, size_t nmemb, void *writeData)
      {
        return 0;
      }

      size_t ContentTypeRetriever::write_header(void *ptr, size_t size, size_t nmemb, void *userdata)
      {
        char *cptr = (char *) ptr;
        ContentTypeRetriever *ctr = (ContentTypeRetriever *) userdata;
        ctr->m_httpResponseHeader.append(cptr, size*nmemb);
        return size*nmemb;
      }
    }
  }
}
