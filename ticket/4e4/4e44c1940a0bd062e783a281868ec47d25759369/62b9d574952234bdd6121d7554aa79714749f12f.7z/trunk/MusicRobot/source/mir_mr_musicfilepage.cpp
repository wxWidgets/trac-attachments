
#include "mir_utils.h"
#include "mir_mr_musicrobotapp.h"
#include "mir_mr_musicfilepage.h"

namespace SyNaT
{
  namespace MIR
  {
    namespace MR
    {
      MusicFilePage::MusicFilePage(MusicRobotApp *mra)
      {
        this->m_mra = mra;
      }

      void MusicFilePage::musicFile(Utils::ptr_map_string_wxString &ptr_map_params)
      {
        if (!this->m_mra->m_login.compare(""))
        {
          this->m_mra->setInternalPath("/login", true);
          return;
        }

        
      }
    }
  }
}
