﻿// For compilers that support precompilation, includes "wx/wx.h".
#include <wx/wxprec.h>

#ifdef __BORLANDC__
    #pragma hdrstop
#endif

// for all others, include the necessary headers (this file is usually all you
// need because it includes almost all "standard" wxWidgets headers
#ifndef WX_PRECOMP
    #include "wx/wx.h"
#endif

#include "mir_stringutils.h"
#include "mir_exceptions.h"

namespace SyNaT
{
  namespace MIR
  {
    
    CommonMirException::CommonMirException()
    {
    }

    CommonMirException::CommonMirException(const CommonMirException &e) : m_origin(e.m_origin), m_what(e.m_what)
    {
    }

    CommonMirException::CommonMirException(const wxString &origin)
    {
      wxCSConv wxCSUTF8(wxFONTENCODING_UTF8);
      this->m_origin = wx2std(origin, &wxCSUTF8);
    }

    CommonMirException::CommonMirException(const wxString &origin, const wxString &what)
    {
      wxCSConv wxCSUTF8(wxFONTENCODING_UTF8);
      this->m_what = wx2std(what, &wxCSUTF8);
      this->m_origin = wx2std(origin, &wxCSUTF8);
    }

    CommonMirException::CommonMirException(const string &origin) : m_origin(origin)
    {
    }

    CommonMirException::CommonMirException(const string &origin, const string &what) : m_what(what), m_origin(origin)
    {
    }

    CommonMirException::~CommonMirException() throw()
    {
    }

    const char     *CommonMirException::Origin() const throw()
    {
      return this->m_origin.c_str();
    }

    const char     *CommonMirException::what() const throw()
    {
      return this->m_what.c_str();
    }

    const char     *CommonMirException::ErrorMessage() const throw()
    {
      return this->m_what.c_str();
    }

    const wxString CommonMirException::wxorigin() const throw()
    {
      wxCSConv wxCSUTF8(wxFONTENCODING_UTF8);
      return std2wx(this->m_origin, &wxCSUTF8);
    }

    const wxString CommonMirException::wxwhat() const throw()
    {
      wxCSConv wxCSUTF8(wxFONTENCODING_UTF8);
      return std2wx(this->m_what, &wxCSUTF8);
    }

    void           CommonMirException::setOrigin(string &origin) throw()
    {
      this->m_origin = origin;
    }

    void           CommonMirException::setWhat(string &what) throw()
    {
      this->m_what = what;
    }

    string         CommonMirException::getOrigin() throw()
    {
      return string(this->m_origin);
    }

    string         CommonMirException::getWhat() throw()
    {
      return string(this->m_what);
    }



    DatabaseNotAssignedMirException::DatabaseNotAssignedMirException() : CommonMirException()
    {
    }

    DatabaseNotAssignedMirException::DatabaseNotAssignedMirException(const DatabaseNotAssignedMirException &e) : CommonMirException(e)
    {
    }

    DatabaseNotAssignedMirException::DatabaseNotAssignedMirException(const wxString &origin) : CommonMirException(origin)
    {
    }

    DatabaseNotAssignedMirException::DatabaseNotAssignedMirException(const wxString &origin, const wxString &what) : CommonMirException(origin, what)
    {
    }

    DatabaseNotAssignedMirException::DatabaseNotAssignedMirException(const string &origin) : CommonMirException(origin)
    {
    }

    DatabaseNotAssignedMirException::DatabaseNotAssignedMirException(const string &origin, const string &what) : CommonMirException(origin, what)
    {
    }



    TransactionNotAssignedMirException::TransactionNotAssignedMirException() : CommonMirException()
    {
    }

    TransactionNotAssignedMirException::TransactionNotAssignedMirException(const TransactionNotAssignedMirException &e) : CommonMirException(e)
    {
    }

    TransactionNotAssignedMirException::TransactionNotAssignedMirException(const wxString &origin) : CommonMirException(origin)
    {
    }

    TransactionNotAssignedMirException::TransactionNotAssignedMirException(const wxString &origin, const wxString &what) : CommonMirException(origin, what)
    {
    }

    TransactionNotAssignedMirException::TransactionNotAssignedMirException(const string &origin) : CommonMirException(origin)
    {
    }

    TransactionNotAssignedMirException::TransactionNotAssignedMirException(const string &origin, const string &what) : CommonMirException(origin, what)
    {
    }



    UserNotLoggedMirException::UserNotLoggedMirException() : CommonMirException()
    {
    }

    UserNotLoggedMirException::UserNotLoggedMirException(const UserNotLoggedMirException &e) : CommonMirException(e)
    {
    }

    UserNotLoggedMirException::UserNotLoggedMirException(const wxString &origin) : CommonMirException(origin)
    {
    }

    UserNotLoggedMirException::UserNotLoggedMirException(const wxString &origin, const wxString &what) : CommonMirException(origin, what)
    {
    }

    UserNotLoggedMirException::UserNotLoggedMirException(const string &origin) : CommonMirException(origin)
    {
    }

    UserNotLoggedMirException::UserNotLoggedMirException(const string &origin, const string &what) : CommonMirException(origin, what)
    {
    }



    UserDontExistsMirException::UserDontExistsMirException() : CommonMirException()
    {
    }

    UserDontExistsMirException::UserDontExistsMirException(const UserDontExistsMirException &e) : CommonMirException(e)
    {
    }

    UserDontExistsMirException::UserDontExistsMirException(const wxString &origin) : CommonMirException(origin)
    {
    }

    UserDontExistsMirException::UserDontExistsMirException(const wxString &origin, const wxString &what) : CommonMirException(origin, what)
    {
    }

    UserDontExistsMirException::UserDontExistsMirException(const string &origin) : CommonMirException(origin)
    {
    }

    UserDontExistsMirException::UserDontExistsMirException(const string &origin, const string &what) : CommonMirException(origin, what)
    {
    }



    IncorrectPasswordMirException::IncorrectPasswordMirException() : CommonMirException()
    {
    }

    IncorrectPasswordMirException::IncorrectPasswordMirException(const IncorrectPasswordMirException &e) : CommonMirException(e)
    {
    }

    IncorrectPasswordMirException::IncorrectPasswordMirException(const wxString &origin) : CommonMirException(origin)
    {
    }

    IncorrectPasswordMirException::IncorrectPasswordMirException(const wxString &origin, const wxString &what) : CommonMirException(origin, what)
    {
    }

    IncorrectPasswordMirException::IncorrectPasswordMirException(const string &origin) : CommonMirException(origin)
    {
    }

    IncorrectPasswordMirException::IncorrectPasswordMirException(const string &origin, const string &what) : CommonMirException(origin, what)
    {
    }

  }
}
