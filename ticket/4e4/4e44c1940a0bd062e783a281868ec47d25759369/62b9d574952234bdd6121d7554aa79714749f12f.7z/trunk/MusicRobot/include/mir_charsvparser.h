//////////////////////////////////////////////////////////////////////////
//
// mir_charsvparser.h - char separated values parser
//
//////////////////////////////////////////////////////////////////////////

#ifndef _MIR_CHARSVPARSER_H_
#define _MIR_CHARSVPARSER_H_

// PostgreSQL and GPDB now support CSV format logs.
// So, we need a way to parse the CSV files into lines, and lines into tokens (fields).

// For compilers that support precompilation, includes "wx/wx.h".
#include <wx/wxprec.h>

#ifdef __BORLANDC__
    #pragma hdrstop
#endif

// for all others, include the necessary headers (this file is usually all you
// need because it includes almost all "standard" wxWidgets headers
#ifndef WX_PRECOMP
    #include "wx/wx.h"
#endif

namespace SyNaT
{
  namespace MIR
  {
    class CHARSVParser : public wxObject
    {
      public:
        CHARSVParser() : m_string(wxT("")), m_pos(0), m_separator(wxT(',')), m_quote(wxT('"')) { }
        CHARSVParser(const wxString& str): m_string(str), m_pos(0), m_separator(wxT(',')), m_quote(wxT('"')) { }
        CHARSVParser(const wxString& str, wxUniChar separator): m_string(str), m_pos(0), m_separator(separator), m_quote(wxT('"')) { }
        CHARSVParser(const wxString& str, wxUniChar separator, wxUniChar quote): m_string(str), m_pos(0), m_separator(separator), m_quote(quote) { }

        bool HasMoreTokens() const;

        // Get the next token (CSV field). Will return empty string if !HasMoreTokens()
        wxString GetNextToken();

        void setLine(const wxString& str)
        {
          this->m_string = str;
          this->m_pos = 0;
        }

        void setLine(const wxString& str, wxUniChar separator)
        {
          this->m_string = str;
          this->m_pos = 0;
          this->m_separator = separator;
        }

        void setLine(const wxString& str, wxUniChar separator, wxUniChar quote)
        {
          this->m_string = str;
          this->m_pos = 0;
          this->m_separator = separator;
          this->m_quote = quote;
        }


      protected:
        wxString  m_string;        // the string we tokenize into fields
        size_t    m_pos;           // the current position in m_string
        wxUniChar m_separator;     // the field separator
        wxUniChar m_quote;         // the quote sign around field value
    };
  }
}

#endif //_MIR_CHARSVPARSER_H_
