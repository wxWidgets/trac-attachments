/**
 * Prosty wrapper na funkcje boost::filesystem::remove_all
 */

#ifndef _MIR_BOOSTFILESYSTEMREMOVEALL_H_
#define _MIR_BOOSTFILESYSTEMREMOVEALL_H_

#include "boost/filesystem.hpp"

namespace SyNaT
{
  namespace MIR
  {
    class BoostFilesystemRemoveAll
    {
      public:
        void operator()(std::string &dirNameStd)
        {
          boost::filesystem::remove_all(dirNameStd);
        }
    };
  }
}

#endif //_MIR_BOOSTFILESYSTEMREMOVEALL_H_
