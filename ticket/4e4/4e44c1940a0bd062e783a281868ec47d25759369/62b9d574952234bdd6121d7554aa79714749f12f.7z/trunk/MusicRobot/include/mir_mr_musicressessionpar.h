﻿#ifndef _MIR_MR_MUSICRESSESSIONPAR_H_
#define _MIR_MR_MUSICRESSESSIONPAR_H_

#include <string>

namespace SyNaT
{
  namespace MIR
  {
    namespace MR
    {
      using namespace std;

      class MusicResSessionPar
      {
        private:
          string m_musicResource;
          string m_sessionParam;
          string m_tableName;
          string m_tablePrefix;
        public:
          MusicResSessionPar();
          MusicResSessionPar(const string &musicResource, const string &sessionParam);

          string   &getMusicResource();
          string   &getSessionParam();

          string   &getTableName();
          string   &getTablePrefix();

          void     setMusicResource(const string &musicResource);

          void     setSessionParam(const string &sessionParam);

          void     setTableName(const string &tableName);
          void     setTablePrefix(const string &tablePrefix);

      };
    }
  }
}

#endif //_MIR_MR_MUSICRESSESSIONPAR_H_
