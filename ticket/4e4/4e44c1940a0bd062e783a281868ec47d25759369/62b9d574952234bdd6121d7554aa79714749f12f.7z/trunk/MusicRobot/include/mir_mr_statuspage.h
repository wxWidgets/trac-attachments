#ifndef _MIR_MR_STATUSPAGE_H_
#define _MIR_MR_STATUSPAGE_H_

#include <Wt/WObject>

#include "mir_mr_musicrobotapp.h"

namespace SyNaT
{
  namespace MIR
  {
    using namespace Wt;

    class MusicRobotApp;

    namespace MR
    {
      class StatusPage : public WObject
      {
        protected:
          MusicRobotApp                           *m_mra;

        public:
          boost::ptr_vector<WText>                 m_wpbrTxt;
          boost::ptr_vector<WProgressBar>          m_wpbr;
          WPushButton                             *m_wpbStart;
          WPushButton                             *m_wpbStop;

                                                   StatusPage(MusicRobotApp *mra);
          void                                     destroyAllWidgets(void);
          void                                     m_slt_wpbStart(void);
          void                                     m_slt_wpbStop(void);
          void                                     statusPage(void);


      };
    }
  }
}

#endif //_MIR_MR_STATUSPAGE_H_
