#ifndef _MIR_MR_MUSICFILEPAGE_H_
#define _MIR_MR_MUSICFILEPAGE_H_


// For compilers that support precompilation, includes "wx/wx.h".
#include <wx/wxprec.h>

#ifdef __BORLANDC__
    #pragma hdrstop
#endif

// for all others, include the necessary headers (this file is usually all you
// need because it includes almost all "standard" wxWidgets headers
#ifndef WX_PRECOMP
    #include "wx/wx.h"
#endif

#include "mir_utils.h"
#include "mir_mr_musicrobotapp.h"

namespace SyNaT
{
  namespace MIR
  {
    namespace MR
    {
      class MusicRobotApp;

      class MusicFilePage
      {
        protected:
          MusicRobotApp                           *m_mra;
        public:
                                                   MusicFilePage(MusicRobotApp *mra);
          void                                     musicFile(Utils::ptr_map_string_wxString &ptr_map_params);

      }; //class MusicFilePage
    }
  }
}

#endif //_MIR_MR_MUSICFILEPAGE_H_
