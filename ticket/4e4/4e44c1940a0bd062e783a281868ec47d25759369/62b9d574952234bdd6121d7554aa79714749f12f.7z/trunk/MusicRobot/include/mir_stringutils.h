﻿/*
  Zaporzyczone z projektu Flamerobin.
  $Id$
*/

#ifndef _MIR_STRINGUTILS_H_
#define _MIR_STRINGUTILS_H_
//-----------------------------------------------------------------------------
#include <Wt/WString>

// For compilers that support precompilation, includes "wx/wx.h".
#include <wx/wxprec.h>

#ifdef __BORLANDC__
    #pragma hdrstop
#endif

// for all others, include the necessary headers (this file is usually all you
// need because it includes almost all "standard" wxWidgets headers
#ifndef WX_PRECOMP
    #include "wx/wx.h"
#endif
#include <wx/strconv.h>

#include <string>


namespace SyNaT
{
  namespace MIR 
  {
    using namespace std;

    //-----------------------------------------------------------------------------
    string wx2std(const wxString& input, wxMBConv* oconv);
    //-----------------------------------------------------------------------------
    wxString std2wx(const string& input, wxMBConv* iconv);
    //-----------------------------------------------------------------------------
    wxString std2wxIdentifier(const string& input, wxMBConv* iconv);
    //-----------------------------------------------------------------------------
    Wt::WString wx2wts(const wxString& input);
    //-----------------------------------------------------------------------------
    wxString wts2wx(const Wt::WString& input);
    //-----------------------------------------------------------------------------
    Wt::WString std2wts(const string& input, wxMBConv* iconv);
    //-----------------------------------------------------------------------------
    string wts2std(const Wt::WString& input, wxMBConv* oconv);

    //-----------------------------------------------------------------------------
    // Converts chars that have special meaning in HTML or XML, so they get
    // displayed.
    wxString escapeHtmlChars(const wxString& input, bool processNewlines = true);
    wxString escapeXmlChars(const wxString& input);
    //-----------------------------------------------------------------------------
    // Returns string suitable for HTML META charset tag (used only if no
    // conversion to UTF-8 is available, i.e. in non-Unicode build.
    wxString getHtmlCharset();
    //-----------------------------------------------------------------------------
    // Standard way to confert a boolean to a string ("true"/"false").
    wxString getBooleanAsString(bool value);
    //-----------------------------------------------------------------------------
    // Converts a wxArrayString to a delimited string of values.
    wxString wxArrayToString(const wxArrayString& arrayStr, const wxString& delimiter);
    //-----------------------------------------------------------------------------



  } // namespace MIR
} // namespace SyNaT
   
#endif // _MIR_STRINGUTILS_H_
