#ifndef _MIR_MR_MAINPAGE_H_
#define _MIR_MR_MAINPAGE_H_

#include <Wt/WObject>

#include "mir_mr_musicrobotapp.h"

namespace SyNaT
{
  namespace MIR
  {
    namespace MR
    {
      using namespace Wt;

      class MusicRobotApp;

      class MainPage : public WObject
      {
        protected:
          MusicRobotApp                           *m_mra;

        public:
                                                   MainPage(MusicRobotApp *mra);

          void                                     m_slt_wpbDwnlStatus(void);

          void                                     m_slt_wpbDwnlSettings(void);

          void                                     m_slt_wpbDwnlPages(void);

          void                                     m_slt_wpbLogout(void);

          void                                     mainPage(void);

      };
    }
  }
}

#endif //_MIR_MR_MAINPAGE_H_
