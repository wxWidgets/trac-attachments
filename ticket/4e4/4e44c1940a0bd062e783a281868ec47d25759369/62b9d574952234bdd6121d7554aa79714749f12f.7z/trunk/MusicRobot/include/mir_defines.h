﻿#ifndef _MIR_DEFINES_H_
#define _MIR_DEFINES_H_

#ifndef DATABASEMODULE_ADMIN_ID
#define DATABASEMODULE_ADMIN_ID 9000000000000000000LL
#endif

#ifndef MIR_PATH_TO_DB_DIR
/// Wszystko w formacie UNIXOWYM
#define MIR_PATH_TO_DB_DIR "/opt/databases/"
#endif
#ifndef MIR_PATH_TO_WWW_DIR
/// Wszystko w formacie UNIXOWYM
#define MIR_PATH_TO_WWW_DIR "/var/www/"
#endif

#endif //_MIR_DEFINES_H_