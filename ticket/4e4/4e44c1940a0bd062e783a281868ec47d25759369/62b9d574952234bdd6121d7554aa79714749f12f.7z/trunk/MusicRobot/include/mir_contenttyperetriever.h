﻿#ifndef _MIR_CONTENTTYPERETRIEVER_H_
#define _MIR_CONTENTTYPERETRIEVER_H_

#include <curl/curl.h>

#include <string>

#include "mir_enums.h"
#include "mir_utils.h"

namespace SyNaT
{
  namespace MIR
  {
    using namespace std;

    class ContentTypeRetriever
    {
      protected:
        CURL          *m_curl;

        bool           m_httpOK;
        string         m_httpResponseHeader;
        void                   initCurl()
                               {
                                 this->m_httpOK = false;
                                 this->m_curl = NULL;
                                 this->m_curl = curl_easy_init();
                                 if (this->m_curl)
                                 {
                                   curl_easy_setopt(this->m_curl, CURLOPT_WRITEDATA, this);
                                   curl_easy_setopt(this->m_curl, CURLOPT_WRITEFUNCTION, ContentTypeRetriever::write_data);
                                   curl_easy_setopt(this->m_curl, CURLOPT_HEADERFUNCTION, ContentTypeRetriever::write_header);
                                   curl_easy_setopt(this->m_curl, CURLOPT_HEADERDATA, this);
                                 }
                               }
      public:
                               ContentTypeRetriever()
                               {
                                 this->m_httpOK = false;
                                 this->initCurl();
                               }
           
                               ContentTypeRetriever(string &uri)
                               {
                                 this->m_httpOK = false;
                                 this->initCurl();
                                 this->setURI(uri);
                                 this->Retrieve();
                               }
                                
        virtual                ~ContentTypeRetriever()
                               {
                                 if (this->m_curl)
                                   curl_easy_cleanup(this->m_curl);
                               }

        void                   setURI(string &uri);

        virtual void           Retrieve();

        bool                   IsOK()
        {
          return this->m_httpOK;
        }

        KindOfContentTypeValue getContentType();

        string                 getContentTypeExtension();

        static size_t          write_data(void *ptr, size_t size, size_t nmemb, void *writeData);
        static size_t          write_header(void *ptr, size_t size, size_t nmemb, void *userdata);
    };
  }
}

#endif //_MIR_CONTENTTYPERETRIEVER_H_
