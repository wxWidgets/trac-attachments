﻿#ifndef _MIR_MR_MUSICROBOTAPP_H_
#define _MIR_MR_MUSICROBOTAPP_H_

#include <Wt/WApplication>
#include <Wt/WAnchor>
#include <Wt/WText>
#include <Wt/WProgressBar>
#include <Wt/WPushButton>
#include <Wt/WTimer>
#include <Wt/WTextArea>
#include <Wt/WAnchor>
#include <Wt/WMessageBox>
#include <Wt/WLabel>
#include <Wt/WLineEdit>

// For compilers that support precompilation, includes "wx/wx.h".
#include <wx/wxprec.h>

#ifdef __BORLANDC__
    #pragma hdrstop
#endif

// for all others, include the necessary headers (this file is usually all you
// need because it includes almost all "standard" wxWidgets headers
#ifndef WX_PRECOMP
    #include "wx/wx.h"
#endif

#include <wx/platinfo.h>

#include <boost/ptr_container/ptr_vector.hpp>
#include <boost/ptr_container/ptr_map.hpp>
#include <boost/thread/mutex.hpp>
#include <boost/thread.hpp>

#include <string>

#include "mir_mr_musicressessionpar.h"
#include "mir_mr_downloadthread.h"
#include "mir_mr_downloadedmusicfilespage.h"
#include "mir_mr_loginpage.h"
#include "mir_mr_mainpage.h"
#include "mir_mr_musicfilepage.h"
#include "mir_mr_settingspage.h"
#include "mir_mr_statuspage.h"

#include <ibpp.h>


namespace SyNaT
{
  namespace MIR
  {
    namespace MR
    {
      using namespace std;
      using namespace Wt;

      class DownloadedMusicFilesPage;

      class MusicRobotApp : public WApplication
      {
          friend void DownloadedMusicFilesPage::dwnlMusicFiles(Utils::ptr_map_string_wxString &ptr_map_params);
          friend void MusicFilePage::musicFile(Utils::ptr_map_string_wxString &ptr_map_params);
          friend void LoginPage::loginPage(void);
          friend void LoginPage::m_slt_wpbLogin(void);
          friend void MainPage::mainPage(void);
          friend void SettingsPage::m_slt_wpbSave(void);
          friend void SettingsPage::getMusicServers(void);
          friend void SettingsPage::settingsPage(void);
          friend void StatusPage::m_slt_wpbStart(void);
          friend void StatusPage::statusPage(void);
          friend void StatusPage::m_slt_wpbStop(void);
	      protected:
					DatabaseModule                                m_dm;
					IBPP::Transaction                             m_tr;


          string                                        m_login;
          string                                        m_name;
          string                                        m_surname;
          string                                        m_hashpassword;
          string                                        m_serverName;
          string                                        m_databaseName;
          string                                        m_userName;
          string                                        m_userPassword;
          string                                        m_roleName;
          string                                        m_charSet;

          WTimer                                       *m_wtimer;
          boost::ptr_vector<DownloadThread>             m_wxdt;
          boost::thread_group                           m_thread_group;
          boost::ptr_vector<boost::thread>              m_threads;
          boost::ptr_vector<MusicResSessionPar>         m_wxServer;

          bool                                          m_stopDownloading;


          void                                          DownloadThreadsRecreate();
          void                                          destroyAllWidgets();
          void                                          removeAllWidgets();
          void                                          waitForThreads();
          void                                          getMusicServers();
          void                                          hideAllFields();
          void                                          createWidgets();

          bool                                          stateOfMusicRobot();
          void                                          changeStateOfMusicRobot(bool working);
                                          /** aktualnie tylko jeden user może używać Muzycznego Robota
                                           */
          bool                                          isMusicRobotWorking;

          // wywoływany w razie zmiany URL'a na /login
          LoginPage                                     m_lp;

          // wywoływana w razie zmiany URL'a na stronę główną /start
          MainPage                                      m_mp;

          // wywoływana w razie zmiany URL'a na /dwnlSettings "Ustawienia ściągania"
          SettingsPage                                  m_sp;

          // wywoływana w razie zmiany URL'a na /dwnlStatus "Status postępu ściągania"
          StatusPage                                    m_ssp;

          // wywoływany w razie zmiany URL'a na /dwnlMusicFiles
          DownloadedMusicFilesPage                      m_dmf;

          // wywoływany w razie zmiany URL'a na /musicFile/param1/val1/param2/val2...
          MusicFilePage                                 m_mfp;

          // wywoływana w razie zmienay URL'a na /dwnlResults "Wyniki pobierania"

          void                                          setFieldsToNull(bool nest);
          void                                          copyLoginInfo(DownloadThread &dt);

        public:


          const static wxOperatingSystemId              mcs_wxosid;
          
          typedef boost::ptr_map<string,string>         ptr_map_string_string;

          static ptr_map_string_string                  mcs_mime;  // file extension and mime type

          static ptr_map_string_string                  fillMimeTypes();


          void                                          m_slt_internalPathChanged(const string &path); /* wApp slot */

          void                                          m_slt_wtimerTimeout();
          
                                                        MusicRobotApp(const WEnvironment& env);
          
          virtual                                       ~MusicRobotApp();


      }; // class MusicRobotApp

    } // namespace MR
  } // namespace MIR
} // namespace SyNaT

#endif //_MIR_MR_MUSICROBOTAPP_H_
