﻿#ifndef _MIR_DATABASETYPES_H_
#define _MIR_DATABASETYPES_H_

#include <string>

#include "mir_defines.h"
#include "mir_exceptions.h"

#include <ibpp.h>

namespace SyNaT
{
  namespace MIR
  {
    using namespace std;
    using namespace IBPP;

    enum DBFieldType { NONET, 
                       VOIDP,       // VARCHAR(1-32767) charset probably octets (aka binary)
                       CHARP,       // VARCHAR(1-32767) c-string
                       BLOBT,       // BLOB
                       BOOLT,       // VARCHAR(1)
                       STRINGT,     // VARCHAR(1-32767)
                       INT16_T,     // SMALLINT
                       INT32_T,     // INTEGER
                       INT64_T,     // BIGINT
                       FLOATT,      // FLOAT
                       DOUBLET,     // DOUBLE
                       TIMESTAMPT,  // TIMESTAMP
                       DATET,       // DATE
                       TIMET        // TIME
                     };

    class DBField
    {
      public:
        DBFieldType         getDBFieldType();
                            DBField();
                            DBField(DBFieldType fieldType, const char *name = "");

        virtual             ~DBField();

        virtual string      getAsDBString();
        string              getFieldName();
        void                setFieldName(const char *name);
        void                setNull(bool isNull);
        bool                isNull();
      protected:
        bool                m_null;
        DBFieldType         m_dbfType;
        char               *m_dbFieldName;
    };

    /**
     * Represents Firebird VARCHAR(1) CHECK VALUE IN ('T' OR 'F')
     */
    class BoolDBField : public DBField
    {
      protected:
        bool                m_value;
      public:
                            BoolDBField();
                            BoolDBField(const char *name);
                            BoolDBField(const string &name);
                            BoolDBField(bool val, const char *name);
                            BoolDBField(bool val, const string &name);
        virtual string      getAsDBString();
        void                getValue(bool &val);
        void                setValue(bool val);
    };

    /**
     * Represents Firebird VARCHAR(1-32767)
     */
    class StringDBField : public DBField
    {
      protected:
        string              m_value;

      public:
                            StringDBField();
                            StringDBField(const char *name);
                            StringDBField(const string &name);
                            StringDBField(const string &val, const char *name);
                            StringDBField(const string &val, const string &name);
        virtual string      getAsDBString();
        void                getValue(string& val);
        void                setValue(const string &val);
    };

    /**
     * Represents Firebird VARCHAR(1-32767) charset probably octets (aka binary)
     */
    class VOIDPDBField : public DBField
    {
      protected:
        void               *m_value;
        int                 m_size;
      public:
                            VOIDPDBField();
                            VOIDPDBField(const char *name);
                            VOIDPDBField(const string &name);
                            VOIDPDBField(const void* val, int size, const char *name);
                            VOIDPDBField(const void* val, int size, const string &name);
        virtual             ~VOIDPDBField();
        virtual string      getAsDBString();
        void                getValue(void *&val, int &size);
        void                setValue(const void *val, int size);
    };

    /**
     * Represents Firebird VARCHAR(1-32767) c-string
     */
    class CHARPDBField : public DBField
    {
      protected:
        unsigned char      *m_value;
        size_t              m_size;
      public:
                            CHARPDBField();
                            CHARPDBField(const char *name);
                            CHARPDBField(const string &name);
                            CHARPDBField(const unsigned char* val, const char *name);
                            CHARPDBField(const unsigned char* val, const string &name);
        virtual             ~CHARPDBField();
        virtual string      getAsDBString();
        void                getValue(unsigned char *&val);
        void                setValue(const unsigned char *val);
    };

    /**
     * Represents Firebird SMALLINT
     */
    class INT16TDBField : public DBField
    {
      protected:
        int16_t             m_value;
      public:
                            INT16TDBField();
                            INT16TDBField(const char *name);
                            INT16TDBField(const string &name);
                            INT16TDBField(int16_t val, const char *name);
                            INT16TDBField(int16_t val, const string &name);
        virtual string      getAsDBString();
        void                getValue(int16_t& val);
        void                setValue(int16_t val);
    };

    /**
     * Represents Firebird INTEGER
     */
    class INT32TDBField : public DBField
    {
      protected:
        int32_t             m_value;
      public:
                            INT32TDBField();
                            INT32TDBField(const char *name);
                            INT32TDBField(const string &name);
                            INT32TDBField(int32_t val, const char *name);
                            INT32TDBField(int32_t val, const string &name);
        virtual string      getAsDBString();
        void                getValue(int32_t& val);
        void                setValue(int32_t val);
    };

    /**
     * Represents Firebird BIGINT
     */
    class INT64TDBField : public DBField
    {
      protected:
        int64_t             m_value;
      public:
                            INT64TDBField();
                            INT64TDBField(const char *name);
                            INT64TDBField(const string &name);
                            INT64TDBField(int64_t val, const char *name);
                            INT64TDBField(int64_t val, const string &name);
        virtual string      getAsDBString();
        void                getValue(int64_t& val);
        void                setValue(int64_t val);
    };

    /**
     * Represents Firebird FLOAT
     */
    class FloatDBField : public DBField
    {
      protected:
        float               m_value;
      public:
                            FloatDBField();
                            FloatDBField(const char *name);
                            FloatDBField(const string &name);
                            FloatDBField(float val, const char *name);
                            FloatDBField(float val, const string &name);
        virtual string      getAsDBString();
        void                getValue(float& val);
        void                setValue(float val);
    };

    /**
     * Represents Firebird DOUBLE
     */
    class DoubleDBField : public DBField
    {
      protected:
        double              m_value;
      public:
                            DoubleDBField();
                            DoubleDBField(const char *name);
                            DoubleDBField(const string &name);
                            DoubleDBField(double val, const char *name);
                            DoubleDBField(double val, const string &name);
        virtual string      getAsDBString();
        void                getValue(double &val);
        void                setValue(double val);
    };

    /**
     * Represents Firebird TIMESTAMP (64bit value - (DATE << 32 | TIME))
     */
    class TimestampDBField : public DBField
    {
      protected:
        Timestamp           m_value;
      public:
                            TimestampDBField();
                            TimestampDBField(const char *name);
                            TimestampDBField(const string &name);
                            TimestampDBField(const Timestamp &val, const char *name);
                            TimestampDBField(const Timestamp &val, const string &name);
                            TimestampDBField(int y, int m, int d, int h = 0, int min = 0, int s = 0, int ms = 0, const char *name = (const char *) 0);
                            TimestampDBField(int y, int m, int d, int h = 0, int min = 0, int s = 0, int ms = 0, const string &name = "");
        virtual string      getAsDBString();
        void                getValue(Timestamp& val);
        void                setValue(const Timestamp &val);
    };

    /**
     * Represents Firebird DATE (32bit value)
     */
    class DateDBField : public DBField
    {
      protected:
        Date                m_value;
      public:
                            DateDBField();
                            DateDBField(const char *name);
                            DateDBField(const string &name);
                            DateDBField(const Date &val, const char *name);
                            DateDBField(const Date &val, const string &name);
                            DateDBField(int y, int m, int d, const char *name);
                            DateDBField(int y, int m, int d, const string &name);
        virtual string      getAsDBString();
        void                getValue(Date& val);
        void                setValue(const Date &val);
    };

    /**
     * Represents Firebird TIME (32bit value)
     */
    class TimeDBField : public DBField
    {
      protected:
        Time                m_value;
      public:
                            TimeDBField();
                            TimeDBField(const char *name);
                            TimeDBField(const string &name);
                            TimeDBField(const Time &val, const char *name);
                            TimeDBField(const Time &val, const string &name);
                            TimeDBField(int h, int min, int s, int ms, const char *name);
                            TimeDBField(int h, int min, int s, int ms, const string &name);
        virtual string      getAsDBString();
        void                getValue(Time& val);
        void                setValue(const Time &val);
    };

    /**
     * Represents Firebird BLOB
     */
    class BlobDBField : public DBField
    {
      protected:
        Blob                m_value;
      public:
                            BlobDBField();
                            BlobDBField(const char *name);
                            BlobDBField(const string &name);

                            /**
                             * First of all you call BlobFactory(...) to get Blob object;
                             * - for writing every Blob must be created by Create(),
                             *   then you call Write(...) (even multiple times),
                             *   then you issue Close()
                             *   then you issue Statement.Set(int, Blob)
                             * - for reading you issue Statement.Get(int, Blob)
                             *   then you call Open(...)
                             *   then you can call Info(...);
                             *   then you call Read(...) (even multiple times),
                             *   then you call Close();
                             */
                            BlobDBField(const Blob &val, const char *name);
                            BlobDBField(const Blob &val, const string &name);
        void                getValue(Blob& val);
        void                setValue(const Blob &val);
    };

  } // namespace MIR
} // namespace SyNaT
#endif //_MIR_DATABASETYPES_H_
