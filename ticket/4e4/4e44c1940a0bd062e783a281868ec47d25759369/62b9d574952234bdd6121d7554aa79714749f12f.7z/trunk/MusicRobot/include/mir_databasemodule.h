﻿#ifndef _MIR_DATABASEMODULE_H_
#define _MIR_DATABASEMODULE_H_


// For compilers that support precompilation, includes "wx/wx.h".
#include <wx/wxprec.h>

#ifdef __BORLANDC__
    #pragma hdrstop
#endif

// for all others, include the necessary headers (this file is usually all you
// need because it includes almost all "standard" wxWidgets headers
#ifndef WX_PRECOMP
    #include "wx/wx.h"
#endif

#include <boost/regex.hpp>
#include <boost/ptr_container/ptr_vector.hpp>

#include <string>

#include "mir_exceptions.h"
#include "mir_databasetypes.h"

#include <ibpp.h>


namespace SyNaT
{
  namespace MIR
  {
    using namespace std;
    using namespace IBPP;

    class DatabaseModule
    {
      protected:
        Database                   m_db;

        int64_t                    m_adminID;
        int64_t                    m_loggedUserId;
        string                     m_name;
        string                     m_surname;
        string                     m_hashpass;

        bool                       m_dbAssigned;
        int64_t                    getNextID(const wxString &tablePrefix, Transaction *tr);
        int64_t                    getNextID(const string &tablePrefix, Transaction *tr);

      public:
        const static boost::regex  mcs_regex;

        const static boost::regex  mcs_similar_to_regex;

        DatabaseModule();
        DatabaseModule(const wxString &serverName, const wxString &databaseName, 
                                    const wxString &userName, const wxString &userPassword,
                                    const wxString &roleName, const wxString &charSet,
                                    const wxString &createParams, const wxString &login, const wxString &loginPassword, bool isSha1 = true); // throw(...);

        DatabaseModule(const string &serverName, const string &databaseName, 
                                    const string &userName, const string &userPassword,
                                    const string &roleName, const string &charSet,
                                    const string &createParams, const string &login, const string &loginPassword, bool isSha1 = true); // throw(...);

        void                   connect(const wxString &serverName, const wxString &databaseName, 
                                    const wxString &userName, const wxString &userPassword,
                                    const wxString &roleName, const wxString &charSet,
                                    const wxString &createParams, const wxString &login, const wxString &loginPassword, bool isSha1 = true); // throw(...);

        void                   connect(const string &serverName, const string &databaseName, 
                                    const string &userName, const string &userPassword,
                                    const string &roleName, const string &charSet,
                                    const string &createParams, const string &login, const string &loginPassword, bool isSha1 = true); // throw(...);



        /**
         * TAM - Transaction Access Mode
         * TIL - Transaction Isolation Level
         *       ilConcurrency -  called Snapshot Repeatable Read (it allows a transaction to get a snapshot 
         *                        of the complete database at the time it's started,
         *                        ideal for reporting, not recommended 
         *                        for interactive users, this transaction cannot see any change made by 
         *                        other concurrent transactions, that transaction only can see changes 
         *                        made by itself)
         *       ilConsistency - called Snapshot table stability aka Forced Repeatable Read
         *                       specific to Firebird/InterBase
         *                       (as soon as it reads from a table, this table is write-locked for all 
         *                       other transactions,
         *                       transaction with this level takes control of that table and all other 
         *                       transactions only can read from it)
         * TLR - Transaction Lock Resolution
         * TFF - TransactionFactory Flags
         */
        Transaction            createTransaction(TAM am = amWrite, TIL il = ilReadCommitted, 
                                                 TLR lr = lrNoWait, TFF flags = TFF(0));// throw(...);

        Statement              createStatement(Transaction *tr, string *sql = (string *) 0);// throw(...);

        void                   checkTableLock(const int64_t tableId, const string &tablePrefix, 
                                              const string &tableName, 
                                              Transaction *tr);
                                              //throw(...);

        int64_t                insertIntoTable(const string &tablePrefix, const string &tableName, 
                                               boost::ptr_vector<DBField> &dbfv, Transaction *tr = (Transaction *) 0);
                                               //throw(...);

        void                   updateTable(const int64_t tableId, const string &tablePrefix, 
                                        const string &tableName, boost::ptr_vector<DBField> &dbfv, 
                                        Transaction *tr);
                                        //throw (...);

        void                   updateTable(const string  &whereSql, const string &tablePrefix, 
                                        const string &tableName, boost::ptr_vector<DBField> &dbfv, 
                                        Transaction *tr);
                                        //throw (...);


        void                   deleteFromTable(const int64_t tableId, const string &tablePrefix, 
                                        const string &tableName, Transaction *tr);
                                        //throw (...);

        void                   deleteFromTable(const string &whereSql, const string &tablePrefix, 
                                        const string &tableName, Transaction *tr);
                                        //throw (...);

        void                   login(const string login, const string password, Transaction *tr, bool isSha1 = true);//throw(...);

        bool                   logged();
        string                 getName();
        string                 getSurname();
        string                 getHashPassword();

        /*
         * W przyszłości updatetować tabele np. MIR_ZALOGOWANI
         **/
        bool                   logout();// throw(...);


        static string          toSql(const string &input, const bool addSingleQuotations = true);

        static string          toSimilarToSql(const string &input, const bool addEscapeWord = true);

    }; // class DatabaseModule

  } // namespace MIR
} // namespace SyNaT
#endif //_MIR_DATABASEMODULE_H_
