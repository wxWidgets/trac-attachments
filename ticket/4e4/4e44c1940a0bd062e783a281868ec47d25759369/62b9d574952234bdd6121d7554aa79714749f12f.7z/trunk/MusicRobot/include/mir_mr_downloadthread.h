﻿#ifndef _MIR_DOWNLOADTHREAD_H_
#define _MIR_DOWNLOADTHREAD_H_

// For compilers that support precompilation, includes "wx/wx.h".
#include <wx/wxprec.h>

#ifdef __BORLANDC__
    #pragma hdrstop
#endif

// for all others, include the necessary headers (this file is usually all you
// need because it includes almost all "standard" wxWidgets headers
#ifndef WX_PRECOMP
    #include "wx/wx.h"
#endif

#include <wx/uri.h>
#include <wx/filename.h>

#include <curl/curl.h>

#include <boost/regex.hpp>
//#include <boost/tokenizer.hpp>
#include <boost/ptr_container/ptr_vector.hpp>
#include <boost/thread/mutex.hpp>

#include <string>

#include "mir_databasetypes.h"
#include "mir_databasemodule.h"
#include "mir_utils.h"

#include <ibpp.h>


namespace SyNaT
{
  namespace MIR
  {
    namespace MR
    {
      using namespace std;
      using namespace IBPP;

      class DownloadThread
      {
        public:

          bool                                            m_stopDownloading;

          int                                             m_progressPercent;

          wxURI                                          *m_wxuri;
          string                                          m_tableName;
          string                                          m_tablePrefix;

          wxURI                                           m_musicResourceURI;

          string                                          m_login;
          string                                          m_name;
          string                                          m_surname;
          string                                          m_hashpassword;
          string                                          m_serverName;
          string                                          m_databaseName;
          string                                          m_userName;
          string                                          m_userPassword;
          string                                          m_roleName;
          string                                          m_charSet;

          mutable boost::mutex                            m_downloadthread_m_progressPercent_mutex;

          static  boost::mutex                            ms_downloadthread_wxWidgetsFuncs_mutex;

          mutable boost::mutex                            m_downloadthread_m_wxuri_mutex;

          mutable boost::mutex                            m_downloadthread_m_stopDownloading_mutex;



          DownloadThread(const string &sessionID = string(""));

          void                                            setFieldsToNull();

		      static int                                      progress_callback(void *progressData,double t,double d,double ultotal,double ulnow);
		      static size_t                                   write_data(void *ptr, size_t size, size_t nmemb, void *writeData);
          static size_t                                   write_header(void *ptr, size_t size, size_t nmemb, void *userdata);

          virtual void                                    operator()(void);

        protected:
          DatabaseModule                                  m_dm;
          Transaction                                     m_tr;

          Utils                                           m_utl;

          boost::ptr_vector<DBField>                      m_dbFields;


          string                                          m_httpResponse;
          string                                          m_httpResponseHeader;

          int64_t                                         m_tablePrefix_id;

          CURL                                           *m_curl;

          wxCSConv                                        m_wxCSUTF8;

          wxFileName                                      m_fncwd;
          wxFileName                                      m_fnrootwww;

          string                                          m_sessionID;
          string                                          m_sessionIDValue;

          void                                            handleRedirect(wxURI *wxEURI, wxURI *wxuri);

          bool                                            get_next_uri(string &odw_url, string &scz_odw_urla/*, wxString &wxm_MusicResource*/);

          void                                            OnExit();

          void 																						insertEscapedURIIntoTable(wxString &wxEscapedURI, wxString &wx_dest_href, const wxString &wx_a_hrefServer, wxString &wxdirplusfilename, KindOfContentTypeValue koctv, ContentTypeRetriever &ctr);

          wxURI                                           buildBaseURI();
          //typedef tokenizer<escaped_list_separator<char>> csvtokenizer;
          /**
            * String passed to contructor must be a variable not expressions like string("some,next")
            * 
            */
          //csvtokenizer                                    m_tok;

          const static boost::regex                       mcs_regex_zeroReplacer;
      };

    } // namespace MR
  } // namespace MIR
} // namespace SyNaT


#endif // _MIR_DOWNLOADTHREAD_H_
