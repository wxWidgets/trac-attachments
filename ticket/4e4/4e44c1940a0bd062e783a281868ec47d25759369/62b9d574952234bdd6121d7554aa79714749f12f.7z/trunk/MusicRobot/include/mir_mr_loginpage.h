#ifndef _MIR_MR_LOGINPAGE_H_
#define _MIR_MR_LOGINPAGE_H_

#include <Wt/WObject>
#include <Wt/WLineEdit>

#include "mir_mr_musicrobotapp.h"
#include "mir_mr_loginpage.h"

namespace SyNaT
{
  namespace MIR
  {
    namespace MR
    {
      using namespace Wt;

      class MusicRobotApp;

      class LoginPage : public WObject
      {
        protected:
          MusicRobotApp                           *m_mra;

        public:
          WLineEdit                               *m_wleLogin;
          WLineEdit                               *m_wlePassword;

                                                   LoginPage(MusicRobotApp *mra);
          void                                     m_slt_wpbLogin(void);
          void                                     loginPage(void);

      };
    }
  }
}


#endif //_MIR_MR_LOGINPAGE_H_
