#ifndef _MIR_MR_DOWNLOADEDMUSICFILESPAGE_H_
#define _MIR_MR_DOWNLOADEDMUSICFILESPAGE_H_

#include <Wt/WObject>

// For compilers that support precompilation, includes "wx/wx.h".
#include <wx/wxprec.h>

#ifdef __BORLANDC__
    #pragma hdrstop
#endif

// for all others, include the necessary headers (this file is usually all you
// need because it includes almost all "standard" wxWidgets headers
#ifndef WX_PRECOMP
    #include "wx/wx.h"
#endif

#include "mir_utils.h"
#include "mir_mr_musicrobotapp.h"

namespace SyNaT
{
  namespace MIR
  {
    namespace MR
    {
      using namespace Wt;

      class MusicRobotApp;

      class DownloadedMusicFilesPage : public WObject
      {
        protected:
          MusicRobotApp                           *m_mra;
        public:
                                                   DownloadedMusicFilesPage(MusicRobotApp *mra);
          void                                     dwnlMusicFiles(Utils::ptr_map_string_wxString &ptr_map_params);
      }; //class DownloadedMusicFilesPage
    }
  }
}

#endif //_MIR_MR_DOWNLOADEDMUSICFILESPAGE_H_
