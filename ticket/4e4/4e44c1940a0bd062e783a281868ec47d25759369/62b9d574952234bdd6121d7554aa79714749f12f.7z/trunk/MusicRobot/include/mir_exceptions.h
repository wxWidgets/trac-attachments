﻿#ifndef _MIR_EXCEPTIONS_H_
#define _MIR_EXCEPTIONS_H_
/*
 * valid for IBPP 2.5.3.1

                         std::exception
                                |
                         IBPP::Exception
                       /                 \
                      /                   \
  IBPP::LogicException    ExceptionBase    IBPP::SQLException
        |        \         /   |     \     /
        |   LogicExceptionImpl |   SQLExceptionImpl
        |                      |
    IBPP::WrongType            |
               \               |
              IBPP::WrongTypeImpl
*/




// For compilers that support precompilation, includes "wx/wx.h".
#include <wx/wxprec.h>

#ifdef __BORLANDC__
    #pragma hdrstop
#endif

// for all others, include the necessary headers (this file is usually all you
// need because it includes almost all "standard" wxWidgets headers
#ifndef WX_PRECOMP
    #include "wx/wx.h"
#endif

#include <string>

#include <ibpp.h>

namespace SyNaT
{
  namespace MIR
  {

    using namespace std;

    class CommonMirException : public IBPP::Exception
    {
      protected:
        string m_what;
        string m_origin;

      public:
        CommonMirException();
        CommonMirException(const CommonMirException &e);
        CommonMirException(const wxString &origin);
        CommonMirException(const wxString &origin, const wxString &what);
        CommonMirException(const string &origin);
        CommonMirException(const string &origin, const string &what);
    		virtual ~CommonMirException() throw();

		    virtual const char*     Origin() const throw();
        virtual const char*     ErrorMessage() const throw();
        virtual const char*     what() const throw();
        virtual const wxString  wxorigin() const throw();
        virtual const wxString  wxwhat() const throw();
        virtual void            setOrigin(string &origin) throw();
        virtual void            setWhat(string &what) throw();
        virtual string          getOrigin() throw();
        virtual string          getWhat() throw();
    };


    class DatabaseNotAssignedMirException : public CommonMirException
    {
      public:
        DatabaseNotAssignedMirException();
        DatabaseNotAssignedMirException(const DatabaseNotAssignedMirException &e);
        DatabaseNotAssignedMirException(const wxString &origin);
        DatabaseNotAssignedMirException(const wxString &origin, const wxString &what);
        DatabaseNotAssignedMirException(const string &origin);
        DatabaseNotAssignedMirException(const string &origin, const string &what);
    };


    class TransactionNotAssignedMirException : public CommonMirException
    {
      public:
        TransactionNotAssignedMirException();
        TransactionNotAssignedMirException(const TransactionNotAssignedMirException &e);
        TransactionNotAssignedMirException(const wxString &origin);
        TransactionNotAssignedMirException(const wxString &origin, const wxString &what);
        TransactionNotAssignedMirException(const string &origin);
        TransactionNotAssignedMirException(const string &origin, const string &what);
    };


    class UserNotLoggedMirException : public CommonMirException
    {
      public:
        UserNotLoggedMirException();
        UserNotLoggedMirException(const UserNotLoggedMirException &e);
        UserNotLoggedMirException(const wxString &origin);
        UserNotLoggedMirException(const wxString &origin, const wxString &what);
        UserNotLoggedMirException(const string &origin);
        UserNotLoggedMirException(const string &origin, const string &what);
    };


    class UserDontExistsMirException : public CommonMirException
    {
      public:
        UserDontExistsMirException();
        UserDontExistsMirException(const UserDontExistsMirException &e);
        UserDontExistsMirException(const wxString &origin);
        UserDontExistsMirException(const wxString &origin, const wxString &what);
        UserDontExistsMirException(const string &origin);
        UserDontExistsMirException(const string &origin, const string &what);
    };



    class IncorrectPasswordMirException : public CommonMirException
    {
      public:
        IncorrectPasswordMirException();
        IncorrectPasswordMirException(const IncorrectPasswordMirException &e);
        IncorrectPasswordMirException(const wxString &origin);
        IncorrectPasswordMirException(const wxString &origin, const wxString &what);
        IncorrectPasswordMirException(const string &origin);
        IncorrectPasswordMirException(const string &origin, const string &what);
    };

  }
}

#endif //_MIR_EXCEPTIONS_H_
