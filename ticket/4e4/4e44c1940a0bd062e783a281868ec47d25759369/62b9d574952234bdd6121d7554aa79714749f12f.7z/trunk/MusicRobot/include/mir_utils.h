﻿#ifndef _MIR_UTILS_H_
#define _MIR_UTILS_H_

// For compilers that support precompilation, includes "wx/wx.h".
#include <wx/wxprec.h>

#ifdef __BORLANDC__
    #pragma hdrstop
#endif

// for all others, include the necessary headers (this file is usually all you
// need because it includes almost all "standard" wxWidgets headers
#ifndef WX_PRECOMP
    #include "wx/wx.h"
#endif

#include <wx/uri.h>
#include <wx/thread.h>
#include <wx/regex.h>
#include <wx/file.h>
#include <wx/filename.h>

#include <boost/regex.hpp>
#include <boost/ptr_container/ptr_map.hpp>
#include <boost/thread/mutex.hpp>

#include <string>

#include "mir_enums.h"
#include "mir_contenttyperetriever.h"

namespace SyNaT
{
  namespace MIR
  {
    using namespace std;

    class Utils
    {
      public:
        const static boost::regex                              mcs_regex_metacharset;
        const static boost::regex                              mcs_regex_contentType;
        const static boost::regex                              mcs_regex_contentTypeCharset;
        const static boost::regex                              mcs_regex_contentdispositionFilename;


        Utils(const string &sessionID);

        static KindOfContentTypeValue                          match_content_type(const string &httpResponseHeader);

        static string                                          match_content_type_ext(const string &httpResponseHeader);

        static string                                          match_charset(const string &httpResponse, const string &httpResponseHeader);

        static wxString                                        CreateTempFileName(int wxHowManyCallsToCreateTempFileName, const wxString& prefix = wxT(""), wxFile *fileTemp = NULL);

        static wxString                                        buildDestHref(wxString &wxdirplusfilename, wxURI &wx_a_href, ContentTypeRetriever &ctr, wxFileName &fnrootwww);

        wxURI                                                  match_img_tag(const wxString &wx_part_of_page, const wxURI &baseURI, bool &hasImgSrc, bool &hasImgTag, size_t &start, size_t &len, size_t &startOfTag, size_t &lenOfTag, KindOfAttrValue &koav, const string &sessionID, string &sessionIDVal);

        wxURI                                                  match_link_tag(const wxString &wx_part_of_page, const wxURI &baseURI, bool &hasLinkHref, bool &hasLinkTag, size_t &start, size_t &len, size_t &startOfTag, size_t &lenOfTag, KindOfAttrValue &koav, const string &sessionID, string &sessionIDVal);

        wxURI                                                  match_base_tag(const wxString &wxpage, bool &hasBaseHref, bool &hasBaseTag, size_t &start, size_t &len, size_t &startOfTag, size_t &lenOfTag, wxURI *wxuri, boost::mutex &downloadthread_m_wxuri_mutex);

        wxURI                                                  match_a_tag(const wxString &wx_part_of_page, const wxURI &baseURI, bool &hasAHref, bool &hasATag, size_t &start, size_t &len, size_t &startOfTag, size_t &lenOfTag, KindOfAttrValue &koav, const string &sessionID, string &sessionIDVal);
        
        static wxURI                                           buildURIWithPathAfterServer(const wxURI *wxuri);
        
        static wxURI                                           buildURIWithQueryParam(const wxURI *wxuri, const wxString &qparam, const wxString &qvalue);

        static void                                            replaceNewlines(wxString &input);

        static wxString                                        subAllNotAllowedCharsInFilenames(wxString input, bool replaceSlashes = true, bool doNotReplaceLastDot = false);
         
        typedef boost::ptr_map<string,wxString>                ptr_map_string_wxString;

        /**
         * Przyjmuje, że path jest w formacie ISO-8859-1 z ewentualnie escapeowanymi znakami ze stringa w formacie UTF-8
         */
        static wxString                                        buildParameterMapFromPath(string path, ptr_map_string_wxString &params, wxCSConv &wxCharSetConv);

      protected:
        wxCSConv                                               m_wxCSUTF8;

        wxRegEx                                                m_wxregex_basetag;
        wxRegEx                                                m_wxregex_linktag;
        wxRegEx                                                m_wxregex_imgtag;
        wxRegEx                                                m_wxregex_attributeWOQ;
        wxRegEx                                                m_wxregex_attributeWSQ;
        wxRegEx                                                m_wxregex_attributeWDQ;
        wxRegEx                                                m_wxregex_spaces;
        wxRegEx                                                m_wxregex_hrefReplacer;
        wxRegEx                                                m_wxregex_hrefReplacerWOEQ;
        wxRegEx                                                m_wxregex_srcReplacer;
        wxRegEx                                                m_wxregex_srcReplacerWOEQ;
        wxRegEx                                                m_wxregex_atag;
        wxRegEx                                                m_wxregex_sessionIDremoval;
    };
  }
}

#endif //_MIR_UTILS_H_
