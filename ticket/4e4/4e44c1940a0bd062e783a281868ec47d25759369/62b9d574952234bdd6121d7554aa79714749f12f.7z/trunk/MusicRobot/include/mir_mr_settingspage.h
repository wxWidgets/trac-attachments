#ifndef _MIR_MR_SETTINGSPAGE_H_
#define _MIR_MR_SETTINGSPAGE_H_

#include <Wt/WObject>

#include "mir_mr_musicrobotapp.h"

namespace SyNaT
{
  namespace MIR
  {
    using namespace Wt;

    class MusicRobotApp;

    namespace MR
    {
      class SettingsPage : public WObject
      {
        protected:
          MusicRobotApp                           *m_mra;
          boost::ptr_vector<WText>                 m_wsettingsBr;
          boost::ptr_vector<WLineEdit>             m_wleServers;

        public:
                                                   SettingsPage(MusicRobotApp *mra);
          void                                     destroyAllWidgets(void);
          void                                     m_slt_wpbSave(void);
          void                                     m_slt_wpbServersAdd(void);
          void                                     getMusicServers(void);
          void                                     settingsPage(void);
      };
    }
  }
}


#endif //_MIR_MR_SETTINGSPAGE_H_
