﻿#ifndef _MIR_ENUMS_H_
#define _MIR_ENUMS_H_

namespace SyNaT
{
  namespace MIR
  {
    enum KindOfContentTypeValue
    {
      koctvHTML,
      koctvXHTML,
      koctvJavaScript,
      koctvCSS,
      koctvPlainText,
      koctvImage,
      koctvAudioContent,
      koctvAudioM3U,
      koctvOther
    };

    enum KindOfAttrValue
    {
      koavWOQ,
      koavWSQ,
      koavWDQ,
      koavWOQimg,
      koavWSQimg,
      koavWDQimg,
    };
  }
}

#endif //_MIR_ENUMS_H_