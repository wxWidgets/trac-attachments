#!/usr/bin/env python
import wx
import sys
import string
import wx.grid
from threading import Thread
import  win32file, win32pipe, win32api
import  wx.lib.colourselect as  csel
import operator
import wx.lib.intctrl
import os
import wx.lib.scrolledpanel as scrolled 

class FindText(wx.Panel):
	def __init__(self, parent, App, win, findData, log):
		self.log = log
		self.App = App
		self.window = win
		self.findData = findData
		self.searchDir = "down"
		self.isMatchCase = False
		self.currRow = self.window.grid.GetGridCursorRow()
		self.currCol = self.window.grid.GetGridCursorCol()	
		self.ifFound = False
		self.msgDlg = -1
		self.selectColor = self.window.grid.GetSelectionBackground()
		self.isFoundAtFirstPos = False
		
		wx.EVT_FIND_CLOSE(self.App.findFrame, -1, self.onCancel)
		wx.EVT_FIND(self.App.findFrame, -1, self.OnFind)
		wx.EVT_FIND_NEXT(self.App.findFrame, -1, self.OnFind)
				
	def OnFind(self, event):
		findFlag = event.GetFlags()
	
		if (findFlag & wx.FR_DOWN) != wx.FR_DOWN:
			self.searchDir = "up"
		else:
			self.searchDir = "down"
			
		if (findFlag & wx.FR_MATCHCASE) == wx.FR_MATCHCASE:
			self.isMatchCase = True
		else:
			self.isMatchCase = False
			
		if (findFlag & wx.FR_WHOLEWORD) == wx.FR_WHOLEWORD:
			self.isWholeWord = True
		else:
			self.isWholeWord = False			

		if self.searchDir =="down":
			self.searchDown(event)
		else:
			self.searchUp(event)
		return True
	
	
	def searchDown(self, event):
		currRow = self.window.grid.GetGridCursorRow()
		currCol = self.window.grid.GetGridCursorCol()
		substr = event.GetFindString()
		text = substr
		bottom = self.window.grid.GetNumberRows()
		right = self.window.grid.GetNumberCols()
		isFound = False
		isFinDiagShown = False
			
		for i in range(0, bottom):
			for j in range(0, right):
				row = (i + currRow)%bottom
				col = j				
				if row == currRow :
					if col < currCol:
						continue	
				if row == self.currRow:
					if col == self.currCol:	
						if isFound == True:
							if isFinDiagShown == False:
								self.msgDlg = wx.MessageDialog(self.App.findFrame, 'Finished searching the Logs', "Finished", wx.OK|wx.ICON_INFORMATION)
								self.msgDlg.ShowModal()	
								self.App.findFrame.SetFocus()
								isFinDiagShown = True

				cell_text = self.window.grid.GetCellValue(row, col)
				if self.isMatchCase != True:
					cell_text = cell_text.lower()
					text = text.lower()
				
				count = cell_text.count(text)
				if count != 0:
					if self.isWholeWord == True:
						if self.checkIfWholeWord(count, cell_text, text) != True:
							continue
					if row == currRow: #Text is found at the current cursor position
						if col == currCol:
							#print "Making the isFound true"
							isFound = True
							if self.isFoundAtFirstPos == True:
								continue
					self.window.grid.SetGridCursor(row, col)
					self.window.grid.MakeCellVisible(row, col)
					self.window.grid.SelectBlock(row, col,row, col)
					self.isFoundAtFirstPos = True
					return True
					
		#for searching the columns which are left in the row with current cursor position before the 
		#current column
		for col in range(0, currCol):
			#For finishing the searching
			if currRow == self.currRow:
				if col == self.currCol:	
					if isFound == True:
						if isFinDiagShown ==False:
							self.msgDlg = wx.MessageDialog(self.App.findFrame, 'Finished searching the Logs', "Finished", wx.OK|wx.ICON_INFORMATION)
							self.msgDlg.ShowModal()
							self.App.findFrame.SetFocus()
							isFinDiagShown = True
		
			cell_text = self.window.grid.GetCellValue(currRow, col)
			if self.isMatchCase != True:
				cell_text = cell_text.lower()
				text = text.lower()			
			count = cell_text.count(text)
			if count != 0:
				if self.isWholeWord == True:
					if self.checkIfWholeWord(count, cell_text, text) != True:
						continue
				self.window.grid.SetGridCursor(currRow, col)
				self.window.grid.MakeCellVisible(currRow, col)
				self.window.grid.SelectBlock(currRow, col,currRow, col)
				return True
				
		if isFound == False:
			self.window.grid.ClearSelection()
			self.msgDlg = wx.MessageDialog(self.App.findFrame, 'Cannnot find string "' + substr + '"', "Not Found", wx.OK|wx.ICON_INFORMATION)
			self.msgDlg.ShowModal()
			self.App.findFrame.SetFocus()
		else:
			if isFinDiagShown == False:
				#this part will be executed when only one occurrence is found
				self.msgDlg = wx.MessageDialog(self.App.findFrame, 'Finished searching the Logs', "Finished", wx.OK|wx.ICON_INFORMATION)
				self.msgDlg.ShowModal()
			self.App.findFrame.SetFocus()
		return True
	
	def searchUp(self, event):
		currRow = self.window.grid.GetGridCursorRow()
		currCol = self.window.grid.GetGridCursorCol()
		bottom = self.window.grid.GetNumberRows()
		right = self.window.grid.GetNumberCols()
		substr = event.GetFindString()
		text = substr
		isFound = False		
		isFinDiagShown = False

		for i in range(0, bottom):
			for j in range(0, right):
				row = currRow - i
				col = right - j - 1
				if row < 0: #to wrap the search
					row = bottom + row
				if row == currRow :
					if col > currCol:
						continue			
				if row == self.currRow:
					if col == self.currCol:
						if isFound == True:
							if isFinDiagShown == False:
								self.msgDlg = wx.MessageDialog(self.App.findFrame, 'Finished searching the Logs', "Finished", wx.OK|wx.ICON_INFORMATION)
								self.msgDlg.ShowModal()	
								self.App.findFrame.SetFocus()
								isFinDiagShown = True
		
				cell_text = self.window.grid.GetCellValue(row, col)
				if self.isMatchCase != True:
					cell_text = cell_text.lower()
					text = text.lower()				
				count = cell_text.count(text)
				if count != 0:
					if self.isWholeWord == True:
						if self.checkIfWholeWord(count, cell_text, text) != True:
							continue
					if row == currRow: #Text is found at the current cursor position
						if col == currCol:
							isFound = True
							if self.isFoundAtFirstPos == True:
								continue					

					self.window.grid.SetGridCursor(row, col)
					self.window.grid.MakeCellVisible(row, col)
					self.window.grid.SelectBlock(row, col, row, col)
					self.isFoundAtFirstPos = True
					return True
		
		#for searching the columns which are left in the row with current cursor position after the 
		#current column
		for j in range(0, right - currCol):
			col = right - j - 1
			#For finishing the searching
			if currRow == self.currRow:
				if col == self.currCol:	
					if isFound == True:
						if isFinDiagShown ==False:
							self.msgDlg = wx.MessageDialog(self.App.findFrame, 'Finished searching the Logs', "Finished", wx.OK|wx.ICON_INFORMATION)
							self.msgDlg.ShowModal()
							self.App.findFrame.SetFocus()
							isFinDiagShown = True
		
			cell_text = self.window.grid.GetCellValue(currRow, col)
			if self.isMatchCase != True:
				cell_text = cell_text.lower()
				text = text.lower()			
			count = cell_text.count(text)
			if count != 0:
				if self.isWholeWord == True:
					if self.checkIfWholeWord(count, cell_text, text) != True:
						continue
				self.window.grid.SetGridCursor(currRow, col)
				self.window.grid.MakeCellVisible(currRow, col)
				self.window.grid.SelectBlock(currRow, col,currRow, col)
				return True
				
		if isFound == False:
			self.window.grid.ClearSelection()
			self.msgDlg = wx.MessageDialog(self.App.findFrame, 'Cannnot find string "' + substr + '"', "Not Found", wx.OK|wx.ICON_INFORMATION)
			self.msgDlg.ShowModal()
			self.App.findFrame.SetFocus()
		else:
			#this part will be executed when only one occurrence is found
			if isFinDiagShown == False:
				self.msgDlg = wx.MessageDialog(self.App.findFrame, 'Finished searching the Logs', "Finished", wx.OK|wx.ICON_INFORMATION)
				self.msgDlg.ShowModal()	
			self.App.findFrame.SetFocus()
		return True

	def setSelection(self, row, col):
		currColor = self.window.grid.GetCellBackgroundColour(row, col)
		currSelectColor = ((self.selectColor[0] + currColor[0])%255, (self.selectColor[1] + currColor[1])%255, (self.selectColor[2] + currColor[2])%255, 255)
		self.window.grid.SetSelectionBackground(wx.Colour(currSelectColor[0], currSelectColor[1], currSelectColor[2]))
		self.window.grid.SelectBlock(row, col, row, col)
		
	def checkIfWholeWord(self, count, str, substr):
		strLen = len(str)
		substrLen = len(substr)
		if strLen == substrLen: #cell text is same as the text to be searched
			return True 
		pos = -1 #For the repeated occurance of the word
		for i in range(0, count):
			pos = str.find(substr, (pos +1))
			if pos == 0: #starting of the string
				if str [pos + substrLen] in (" ", ",", "."):
					return True
			elif (pos + substrLen) == strLen: #we have reached to the end of the string
				if str [pos - 1] in (" ", ",", "."):
					return True
			else : #midway
				if str [pos - 1] in (" ", ",", "."):
					if str [pos + substrLen] in (" ", ",", "."):
						return True
		return False

	def onCancel(self, event):
		self.App.toolbar.EnableTool(201, True)
		self.App.toolbar.EnableTool(202, True)
		self.App.toolbar.EnableTool(203, True)
		self.App.toolbar.EnableTool(204, True)
		self.App.toolbar.EnableTool(205, True)
		self.App.toolbar.EnableTool(206, True)
		self.App.toolbar.EnableTool(207, True)
		if (self.App.start != True):
			self.App.toolbar.EnableTool(208, True)
		
		self.App.item_save.Enable(True)
		self.App.item_saveas.Enable(True)
		self.App.item_exit.Enable(True)
		self.App.item_search.Enable(True)
		self.App.item_logStart.Enable(True)
		self.App.item_logStop.Enable(True)
		self.App.item_logPause.Enable(True)
		self.App.item_channel.Enable(True)
		self.App.item_filter.Enable(True)
		self.App.item_history.Enable(True)
		self.App.item_refresh.Enable(True)
			
		self.App.pause = self.App.oldPause
		self.App.winFind = -1
		self.App.findFrame.Destroy()
		self.window.grid.ClearSelection()
		return True

		
class HistoryDepth(wx.Dialog):
	def __init__(self, title, pos, size, App, log):
		self.log = log
		self.App = App
		wx.Dialog.__init__(self, None, -1, title, pos, size)
		self.panel = wx.Panel(self, -1)
		self.panel.SetAutoLayout(True)
		mainSizer = wx.BoxSizer(wx.VERTICAL)
		self.panel.SetSizer(mainSizer)
		
		buttonSizer = wx.FlexGridSizer(1, 2, 15, 5)	
		
		buttonSizer.AddMany([
			(wx.StaticText(self, -1, "Range is [0-2000]."), 0, wx.ALIGN_LEFT | wx.ALIGN_CENTER_VERTICAL),
			(wx.StaticText(self, -1, "To unset depth set it to 0"), 0, wx.ALIGN_LEFT | wx.ALIGN_CENTER_VERTICAL),
			])

		self.textBoxHistory = wx.lib.intctrl.IntCtrl(self, -1, pos=(20,20), size=(100,20))
		self.textBoxHistory.SetMax(2000)
		self.textBoxHistory.SetMin(0)
		self.textBoxHistory.SetLimited(True)
		self.textBoxHistory.SetValue(self.App.HISTORY)
		buttonSizer.AddMany([
			(wx.StaticText(self, -1, "History Depth"), 0, wx.ALIGN_LEFT | wx.ALIGN_CENTER_VERTICAL),
			(self.textBoxHistory,1,wx.EXPAND,20),
			])
		mainSizer.Add(buttonSizer, 0, wx.ALL, 3)
		self.panel.Layout()
		
		self.okButton = wx.Button(self, -1, 'Ok', (20, 70))
		self.cancelButton = wx.Button(self, -1, 'Cancel', (150, 70))
		self.okButton.Bind(wx.EVT_BUTTON, self.onHistoryOk)
		self.okButton.SetDefault()
		self.cancelButton.Bind(wx.EVT_BUTTON, self.onHistoryCancel)
		self.Bind(wx.EVT_CLOSE, self.onHistoryCancel)
		self.textBoxHistory.SetFocus()
		self.textBoxHistory.SetSelection(-1, -1)
		self.Center()
	
	def onHistoryCancel(self, event):
		self.App.winHistory = -1
		self.Destroy()
		return True
		
	def onHistoryOk(self, event):
		self.App.HISTORY = self.textBoxHistory.GetValue()
		self.App.winHistory = -1
		self.Destroy()
		
class ConfigSelect(wx.Dialog):
	def __init__(self, title, pos, size, App, log):
		self.log = log
		self.App = App
		wx.Dialog.__init__(self, None, -1, title, pos, size)
		self.panel = wx.Panel(self, -1)
		self.panel.SetAutoLayout(True)
		mainSizer = wx.BoxSizer(wx.VERTICAL)
		self.panel.SetSizer(mainSizer)
		
		buttonSizer = wx.FlexGridSizer(1, 2, 15, 10)	

		self.textBoxMAC = wx.TextCtrl ( self, -1, pos=(20,20), size=(150,20))
		self.textBoxMAC.SetValue(self.App.MAC_ADD)
		buttonSizer.AddMany([
			(wx.StaticText(self, -1, "MAC Address"), 0, wx.ALIGN_LEFT | wx.ALIGN_CENTER_VERTICAL),
			(self.textBoxMAC,1, wx.ALIGN_LEFT | wx.ALIGN_CENTER_VERTICAL,20),
			])
			
		self.textBoxChannel = wx.lib.intctrl.IntCtrl(self, -1, pos=(20,20), size=(150,20))
		self.textBoxChannel.SetMax(1023)
		self.textBoxChannel.SetMin(0)
		self.textBoxChannel.SetLimited(True)
		self.textBoxChannel.SetValue(self.App.CHANNEL_ID)
		buttonSizer.AddMany([
			(wx.StaticText(self, -1, "Channel Id"), 0, wx.ALIGN_LEFT | wx.ALIGN_CENTER_VERTICAL),
			(self.textBoxChannel,1,wx.EXPAND,20),
			])
		mainSizer.Add(buttonSizer, 0, wx.ALL, 3)
		self.panel.Layout()
		
		self.okButton = wx.Button(self, -1, 'Ok', (20, 80))
		self.cancelButton = wx.Button(self, -1, 'Cancel', (140, 80))
		self.okButton.Bind(wx.EVT_BUTTON, self.onConfigOk)
		self.okButton.SetDefault()
		self.cancelButton.Bind(wx.EVT_BUTTON, self.onConfigCancel)
		self.Bind(wx.EVT_CLOSE, self.onConfigCancel)
		self.textBoxMAC.SetFocus()
		self.textBoxMAC.SetSelection(-1, -1)
		self.Center()
		
	def onConfigOk(self, event):
		MAC_ADD = self.textBoxMAC.GetValue().upper()
		CHANNEL_ID = self.textBoxChannel.GetValue()
		i = 0
		if len(MAC_ADD) != 17:
			self.log.WriteText(self, 'Invalid MAC Address Length\n')
			self.textBoxMAC.SetFocus()
			self.textBoxMAC.SetSelection(-1, -1)
			return True
		for i in range(17):
			if i%3 != 2:
				if ((str(MAC_ADD[i]) < "0") | (str(MAC_ADD[i]) > "9")) & ((str(MAC_ADD[i]) < "A") | (str(MAC_ADD[i]) > "F")):
					self.log.WriteText(self, 'Invalid MAC Address Value %c\n' % MAC_ADD[i])
					self.textBoxMAC.SetFocus()
					self.textBoxMAC.SetSelection(-1, -1)
					return True
			else:
				if str(MAC_ADD[i]) != ":":
					self.log.WriteText(self, 'Invalid MAC Address Value %c\n' % MAC_ADD[i])
					self.textBoxMAC.SetFocus()
					self.textBoxMAC.SetSelection(-1, -1)
					return True
					
		if self.App.MAC_ADD != self.textBoxMAC.GetValue().upper():
			self.App.MAC_ADD = self.textBoxMAC.GetValue().upper()
		else:
			if self.App.CHANNEL_ID == self.textBoxChannel.GetValue():
				self.Destroy()
				return True
		self.App.CHANNEL_ID = self.textBoxChannel.GetValue()
		titleString = 'GoLAN Log Viewer: MAC Address = [%s], Channel Id = [' % self.App.MAC_ADD + str(self.App.CHANNEL_ID) + ']'
		wx.Frame.SetTitle(self.App.frame, titleString)
		self.App.StopThread()
		self.App.winConfig = -1
		self.Destroy()
		
	def onConfigCancel(self, event):
		self.App.winConfig = -1
		self.Destroy()
		
class TestColourSelect(wx.Dialog):
	def __init__(self, title, pos, size, App, log):
		self.log = log
		self.App = App
		self.filterColour = (255, 255, 255)
		wx.Dialog.__init__(self, None, -1, title, pos, size)
		self.panel = wx.Panel(self, -1)
		self.panel.SetAutoLayout(True)
		mainSizer = wx.BoxSizer(wx.VERTICAL)
		self.panel.SetSizer(mainSizer)
		
		buttonSizer = wx.FlexGridSizer(1, 2) # sizer to contain all the example buttons
		
		sampleList = ['zero', 'one', 'two', 'three', 'four', 'five', 'six', 'seven', 'eight']
		self.ch = wx.Choice(self, -1)
		self.ch.Bind(wx.EVT_SET_FOCUS, lambda evt, ch=self.ch:self.OnChoiceGetFocus(evt,self.ch)) 
		self.Bind(wx.EVT_CHOICE, self.EvtChoice, self.ch)
		
		buttonSizer.AddMany([
			(wx.StaticText(self, -1, "Filter Name"), 0, wx.ALIGN_LEFT | wx.ALIGN_CENTER_VERTICAL),
			(self.ch,1,wx.EXPAND,30),
			])
			
		buttonSizer.AddMany([
			(wx.StaticText(self, -1, ""), 0, wx.ALIGN_LEFT | wx.ALIGN_CENTER_VERTICAL),
			(wx.StaticText(self, -1, ""), 0, wx.EXPAND, 30),
			])
			
		self.textBox = wx.TextCtrl ( self, -1, pos=(20,20), size=(350,20))
		buttonSizer.AddMany([
			(wx.StaticText(self, -1, "Filter String"), 0, wx.ALIGN_LEFT | wx.ALIGN_CENTER_VERTICAL),
			(self.textBox,1,wx.EXPAND,30),
			])
		#for name, color, size, label in buttonData:
		self.b = csel.ColourSelect(self, -1, "Click Here...", (255, 255, 255), (120, -1))

		self.b.Bind(csel.EVT_COLOURSELECT, self.OnSelectColour)

		buttonSizer.AddMany([
			(wx.StaticText(self, -1, "Choose Colour"), 0, wx.ALIGN_RIGHT | wx.ALIGN_CENTER_VERTICAL),
			(self.b, 0, wx.ALL, 3),
			])
		
		mainSizer.Add(buttonSizer, 0, wx.ALL, 3)
		self.panel.Layout()
		
		#Build Buttons for Ok, Cancle, Clear
		self.okButton = wx.Button(self, -1, 'Ok', (10, 100))
		self.removeButton = wx.Button(self, -1, 'Remove', (120, 100))
		self.removeAllButton = wx.Button(self, -1, 'Remove All', (230, 100))
		self.cancelButton = wx.Button(self, -1, 'Cancel', (340, 100))
		self.okButton.Disable()
		self.removeButton.Disable()
		self.okButton.Bind(wx.EVT_BUTTON, self.onOk)
		self.removeButton.Bind(wx.EVT_BUTTON, self.onRemove)
		self.removeAllButton.Bind(wx.EVT_BUTTON, self.onRemoveAll)
		self.cancelButton.Bind(wx.EVT_BUTTON, self.onCancel)
		self.cancelButton.SetDefault()
		self.Bind(wx.EVT_CLOSE, self.onCancel)
		self.ch.SetFocus()

		self.Center()
		
	def OnChoiceGetFocus(self, event, ch): 
		ch.Clear() 
		sampleList = ['zero', 'one', 'two', 'three', 'four', 'five', 'six', 'seven', 'eight']
		for no in sampleList: 
			ch.Append(no) 
		event.Skip()
	
	def EvtChoice(self, event):
		tempFilter = event.GetString()
		for name, filterString, colour in self.App.filterList:
			if name == tempFilter:
				self.textBox.SetValue(filterString)
				self.b.SetValue(colour)
				self.okButton.Enable()
				self.okButton.SetDefault()
				self.removeButton.Enable()
				self.filterName = tempFilter
				break
		
	def OnSelectColour(self, event):
		self.filterColour = event.GetValue()
	
	def onOk(self, event):
		self.filterColour = self.b.GetValue()
		if self.textBox.GetValue() == "*":
				if self.filterColour != (255, 255, 255):
					self.log.WriteText(self, 'Invalid Filter String: %s\n' % self.textBox.GetValue())
				else:
					self.App.windowColour = -1
					self.Destroy()
		else:
			if self.filterColour == (255, 255, 255):
				self.log.WriteText(self, 'Invalid Filter Colour\n')
			else:
				i = 0
				for name, filterString, colour in self.App.filterList:
					if name != self.filterName:
						if filterString == self.textBox.GetValue():
							self.log.WriteText(self, 'Filter for this string already exists\n')
							return True
				for name, filterString, colour in self.App.filterList:
					if name == self.filterName:
						self.App.filterList[i] = (name, self.textBox.GetValue(), self.filterColour)
						for curName, filterString, colour in self.App.currentList:
							if (curName == name) | (filterString == self.textBox.GetValue()):
								self.App.currentList.remove((curName, filterString, colour))
								
						self.App.currentList.append((name, self.textBox.GetValue(), self.filterColour))
						self.App.windowColour = -1
						self.Destroy()
						break
					i = i + 1
		self.App.windowColour = -1
		self.Destroy()

	def onRemove(self, event):
		i = 0
		for name, filterString, colour in self.App.filterList:
			if name == self.filterName:
				self.App.filterList[i] = (name, "*", (255,255,255))
				self.textBox.SetValue("*")
				self.b.SetValue((255, 255, 255))
				self.App.currentList.remove((name, filterString, colour))
				break
			i += 1
		return True
	
	def onRemoveAll(self, event):
		i = 0
		for name, filterString, colour in self.App.filterList:
			self.App.filterList[i] = (name, "*", (255,255,255))
			self.textBox.SetValue("*")
			self.b.SetValue((255, 255, 255))
			i += 1
		i = 0
		for name, filterString, colour in self.App.currentList:
			i += 1
		j = 0
		for j in range(i):
			self.App.currentList.pop()
		return True
		
	def onCancel(self, event):
		self.App.windowColour = -1
		self.Destroy()
		return True
	
	
class AccessPipe (Thread):
	def __init__(self, App):
		Thread.__init__(self)
		self.App = App
		self.start()
		
	def run(self):
		self.i = 0
		self.j = 0
		self.curSize = 0
		try:
			self.PipeHandle = win32file.CreateFile(self.App.PipeName,
						win32file.GENERIC_READ | win32file.GENERIC_WRITE,
						0, None, win32file.OPEN_EXISTING,
						win32file.FILE_ATTRIBUTE_NORMAL, 0)
			if self.PipeHandle != win32file.INVALID_HANDLE_VALUE:
				win32file.CloseHandle(self.PipeHandle)
				self.App.log.WriteText(self.App.frame, 'Can not start Logging. A Log Viewer for configured MAC Address and Channel Id is already running.\n')
				self.App.pause = False
				self.App.oldPause = False
				self.App.stop = True
				self.App.start = False
				self.App.pipeThread = -1
				self.App.toolbar.SetToolNormalBitmap(201, wx.Bitmap('icons\play.png'))
				self.App.toolbar.SetToolNormalBitmap(202, wx.Bitmap('icons\stop1.png'))
				self.App.toolbar.SetToolNormalBitmap(203, wx.Bitmap('icons\pause1.png'))
				self.App.toolbar.EnableTool(202, False)
				self.App.toolbar.EnableTool(203, False)
				return True
		except win32api.error, (code, function, message):
			if code != 2:
				self.App.log.WriteText(self.App.frame, 'Can not start Logging. A Log Viewer for configured MAC Address and Channel Id is already running.\n')
				self.App.pause = False
				self.App.oldPause = False
				self.App.stop = True
				self.App.start = False
				self.App.pipeThread = -1
				self.App.toolbar.SetToolNormalBitmap(201, wx.Bitmap('icons\play.png'))
				self.App.toolbar.SetToolNormalBitmap(202, wx.Bitmap('icons\stop1.png'))
				self.App.toolbar.SetToolNormalBitmap(203, wx.Bitmap('icons\pause1.png'))
				self.App.toolbar.EnableTool(202, False)
				self.App.toolbar.EnableTool(203, False)
				#self.App.toolbar.EnableTool(204, True)
				#self.App.item_channel.Enable(True)
				return True

		self.pipeHandle = win32pipe.CreateNamedPipe(
							self.App.PipeName, 
							win32pipe.PIPE_ACCESS_DUPLEX,
							win32pipe.PIPE_TYPE_BYTE |
							win32pipe.PIPE_READMODE_BYTE |
							win32pipe.PIPE_WAIT,
							50,
							4096,
							4096,
							1000,
							None)
		if self.pipeHandle == win32file.INVALID_HANDLE_VALUE:
			sys.exit(1)
		
		self.needKill = False
		k = 0
		while not self.needKill:
			try:
				win32pipe.ConnectNamedPipe( self.pipeHandle )
				if self.needKill == True:
					win32pipe.DisconnectNamedPipe( self.pipeHandle )
					break
				hr, v = win32file.ReadFile( self.pipeHandle, 1024, None )
				win32pipe.DisconnectNamedPipe( self.pipeHandle )

				if ((self.App.pause != True) & (self.App.stop != True)):
					#self.App.window.grid.BeginBatch()
					#self.App.window.grid.AppendRows(1)
					self.App.window.grid.InsertRows(self.App.GridRow, 1, False)
					self.App.GridRow += 1
					if self.App.HISTORY != 0:
						#while self.App.window.grid.GetNumberRows() > self.App.HISTORY:
						while self.App.GridRow > self.App.HISTORY:
							self.App.window.grid.DeleteRows()
							self.App.GridRow -= 1
						tempCol = 0
						if self.App.GridRow == self.App.HISTORY:
							for tempCol in range (self.App.HISTORY):
								self.App.window.grid.SetCellValue(tempCol, 0, str(tempCol + 1))
					#self.i = self.App.window.grid.GetNumberRows() - 1
					self.i = self.App.GridRow - 1
					#self.i = 0
					self.App.window.grid.MakeCellVisible(self.i, 0)
					#self.App.window.MakeCellVisiblenew(self.i, 0)
					# self.App.window.grid.SetRowSize(self.i, 20)
					if self.curSize != self.App.MaxColSize:
						self.App.window.grid.SetColMinimalWidth(5, self.App.MaxColSize)
						self.curSize = self.App.MaxColSize
					#self.App.window.grid.AutoSizeColumn(5, False)
					
					#set Index Value
					#self.App.window.grid.SetCellValue(self.i, 0, str(self.App.GridRow))
			
					#get Time
					time, sub, temp = v.partition(" [")
					#self.App.window.grid.SetCellValue(self.i, 1, time)
				
					#get Processor
					processor, sub, temp = temp.partition("]")
					#self.App.window.grid.SetCellValue(self.i, 2, processor)
				
					#get Module
					module, sub, temp = temp.partition("[")
					module, sub, temp = temp.partition("]")
					#self.App.window.grid.SetCellValue(self.i, 3, module)
					
					#get Severity
					severity, sub, temp = temp.partition("[")
					severity, sub, temp = temp.partition("]:")
					#self.App.window.grid.SetCellValue(self.i, 4, severity)

					#get log
					log = temp.lstrip()
					#wx.MilliSleep(30)
					self.App.window.grid.BeginBatch()
					self.App.window.grid.SetCellValue(self.i, 5, log)
					self.App.window.grid.SetCellValue(self.i, 4, severity)
					self.App.window.grid.SetCellValue(self.i, 3, module)
					self.App.window.grid.SetCellValue(self.i, 2, processor)
					self.App.window.grid.SetCellValue(self.i, 1, time)
					self.App.window.grid.SetCellValue(self.i, 0, str(self.App.GridRow))

					for name, filterString, colour in self.App.currentList:
						if v.find(filterString) != -1:
							attr = wx.grid.GridCellAttr()
							attr.SetBackgroundColour(colour)
							self.App.window.grid.SetRowAttr(self.i, attr)
							attr.IncRef()
							break
					#self.App.window.grid.MakeCellVisible(self.i, 0)
					self.App.window.grid.EndBatch()
					#self.App.window.grid.ForceRefresh()
					
			except win32api.error, (code, function, message):
				win32pipe.DisconnectNamedPipe( self.pipeHandle )
	
	def kill(self):
		self.needKill = True

class TestListCtrlPanel(wx.Panel):
#class TestListCtrlPanel(scrolled.ScrolledPanel):
	colLabels = ["#", "Time Stamp", "Processor", "Module", "Severity", "Log Message"]
	
	def __init__(self, parent, App, log):
		wx.Panel.__init__(self, parent, -1, style=wx.WANTS_CHARS)
		#scrolled.ScrolledPanel.__init__(self, parent, -1, style=wx.TAB_TRAVERSAL)
		self.log = log
		tID = wx.NewId()
		self.App = App
				
		sizer = wx.BoxSizer(wx.VERTICAL)
		self.grid = wx.grid.Grid(self)
		self.grid.CreateGrid(0,6)
		sizer.Add(self.grid, 1, wx.EXPAND)
		self.SetSizerAndFit(sizer)
		self.SetAutoLayout(True)
		self.grid.SetDefaultCellOverflow(False)
		for col in range(6):
			self.grid.SetColLabelValue(col, self.colLabels[col])
		self.grid.SetColSize(5, 850)
		self.grid.SetRowLabelSize(0)
		attr = wx.grid.GridCellAttr()
		attr.SetAlignment(wx.ALIGN_CENTER, -1)
		for col in range(5):
			self.grid.SetColAttr(col, attr)
		self.grid.EnableDragRowSize(False)
		self.grid.EnableEditing(False)
		self.grid.SetColMinimalWidth(5, self.App.MaxColSize)
		self.grid.AutoSizeColumn(5, False)

		self.yposOld = self.grid.GetColLabelSize()
		#self.ScrollChildIntoView(self.grid)
		self.grid.FitInside()
		#self.grid.SetScrollLineY(1)
		self.grid.Bind(wx.EVT_SCROLLWIN, self.OnScroll)
		
	def OnScroll(self, event):
		print "Scrolling"
		event.Skip()
		
	def MakeCellVisiblenew(self, row, col):
		#print 'Making cell visible'
		i = 0
		xpos = -1
		ypos = -1
		ColSize = self.grid.GetColLabelSize()

		#get the cell rectangle in logical coords
		r = self.grid.CellToRect(0,0) #( row, col )

		#convert to device coords
		left = 0
		top = 0
		right = 0
		bottom = 0
		left, top = self.grid.CalcScrolledPosition( r.GetLeft(), r.GetTop())
		rightm, bottom = self.grid.CalcScrolledPosition( r.GetRight(), r.GetBottom())

		cw = 0
		ch = 0
		#cw, ch = self.grid.GetClientSize()
		#print "Client Size is %s %s" % (str(cw), str(ch))
		#my
		bottom += 34
		#my
		if top < 0:
			ypos = r.GetTop()
		else:
			if bottom > ch:
				#my
				h = 17
				#h = r.GetHeight()
				#my
				ypos = r.GetTop()
				#print 'h = %s' % str(h), ' ypos = %s ' % str(ypos), ' ch = %s' % str(ch)
				i = row - 1
				ch -= ColSize
				while i >= 0:
					#rowHeight = self.grid.GetRowSize(i)
					rowHeight = 17
					if ( h + rowHeight) > ch:
						#print 'Breaking Loop at %s' % str (i)
						break
					h += rowHeight
					ypos -= rowHeight
					i -= 1
				ypos += 17
			#else:
				#print 'row = %s' % str(row)
			if ypos != -1:
				ypos /= 15
				#print 'Yops at print %s' % str(ypos)
				self.grid.Scroll( -1, (ypos + ColSize))

	def newyScroll(self, y_pos):
		m_yScrollPosition = self.grid.GetScrollPos(wx.VERTICAL)
		m_yScrollLines = y_pos + 34
		if ((y_pos == -1) | (y_pos < m_yScrollPosition)):
			return
		w = 0
		h = 0
		w, h = self.grid.GetClientSize()

		#compute new position:
		new_y = m_yScrollPosition;
		new_y = y_pos;

		#Calculate page size i.e. number of scroll units you get on the
		#current client window
		noPagePositions = h/15
		if noPagePositions < 1:
			noPagePositions = 1

        #Correct position if greater than extent of canvas minus
        #the visible portion of it or if below zero
		#new_y = wx.Min( m_yScrollLines-noPagePositions, new_y )
		if (m_yScrollLines-noPagePositions) < new_y:
			new_y = m_yScrollLines-noPagePositions
		#new_y = wx.Max( 0, new_y )
		if new_y < 0:
			new_y = 0
		if new_y < m_yScrollPosition:
			return

		#flush all pending repaints before we change m_{x,y}ScrollPosition, as
		#otherwise invalidated area could be updated incorrectly later when
		#ScrollWindow() makes sure they're repainted before scrolling them
    #m_targetWindow->Update();

		#update the position and scroll the window now:
		if m_yScrollPosition != new_y:
			old_y = m_yScrollPosition
			m_yScrollPosition = new_y
			self.grid.SetScrollPos( wx.VERTICAL, new_y )
			self.grid.ScrollWindow( 0, (new_y-old_y)*15, self.grid.GetRect())
			print "scrollng... %s" % str((new_y-old_y)*15)

class Log:
    def WriteText(self, parent, text):
        if text[-1:] == '\n':
			text = text[:-1]
			#wx.SafeShowMessage("Log Viewer Info", text)
			self.msgDlg = wx.MessageDialog(parent, text, "Log Viewer Info", wx.OK)
			self.msgDlg.ShowModal()	
    write = WriteText

class Frame(wx.Frame):
	def __init__(self, parent, id, title):
		wx.Frame.__init__(self, parent, id, title)
		
class Dialog(wx.Dialog):
	def __init__(self, parent, id, title, pos, size):
		wx.Dialog.__init__(self, parent, id, title, pos, size)

class App(wx.App):
	filterList = [  ('zero', "*", (255, 255, 255)),
					('one', "*", (255, 255, 255)), 
					('two', "*", (255, 255, 255)), 
					('three', "*", (255, 255, 255)), 
					('four', "*", (255, 255, 255)), 
					('five', "*", (255, 255, 255)), 
					('six', "*", (255, 255, 255)), 
					('seven', "*", (255, 255, 255)), 
					('eight', "*", (255, 255, 255))]
	
	currentList = []
	pause = False
	oldPause = False
	stop = True
	start = False
	MaxColSize = 580
	GridRow = 0
	def __init__(self, redirect=False, filename=None):
		wx.App.__init__(self, redirect, filename)

	def OnInit(self):
		self.frame = Frame(parent=None, id=-1, title='GoLAN Log Viewer: MAC Address = [00:00:00:00:00:00], Channel Id = [00]')
		self.frame.Show()
		self.SetTopWindow(self.frame)
		self.colourFrame = -1
		self.pipeThread = -1
		self.configFrame = -1
		self.MAC_ADD = '00:00:00:00:00:0E'
		self.CHANNEL_ID = 10
		self.winHistory = -1
		self.HISTORY = 0
		self.windowFind = -1
		self.windowColour = -1
		self.gridSize = 0
		win = TestListCtrlPanel(self.frame, self, Log())
		if win:
            # so set the frame to a good size for showing stuff
			self.frame.SetSize((640, 480))
			win.SetFocus()
			self.window = win
			#self.window.SetupScrolling()
			frect = self.frame.GetRect()
			self.frame.Fit()
			self.log = Log()
		else:
            # It was probably a dialog or something that is already
            # gone, so we're done.
			self.frame.Destroy()
			return True
		self.last_name_saved = ''
		self.window.grid.Bind(wx.grid.EVT_GRID_LABEL_LEFT_CLICK, self.sortColumn)
		
		self.SetTopWindow(self.frame)
		menuBar = wx.MenuBar()
		
		menu = wx.Menu()
		self.item_save = menu.Append(-1, "&Save\tCtrl-S", "Save the file")
		self.Bind(wx.EVT_MENU, self.OnSaveFile, self.item_save)
		self.item_saveas = menu.Append(-1, "Save &As...\tShift+Ctrl+S", "Save the file with a different name")
		self.Bind(wx.EVT_MENU, self.OnSaveAsFile, self.item_saveas)
		self.item_exit = menu.Append(-1, "E&xit\tCtrl-Q", "Exit demo")
		self.Bind(wx.EVT_MENU, self.OnExitApp, self.item_exit)
		menuBar.Append(menu, "&File")
		
		menu_view = wx.Menu()
		self.item_history = menu_view.Append(-1, "&History Depth\tCtrl-H", "Configure History Depth")
		self.Bind(wx.EVT_MENU, self.setHistoryDepth, self.item_history)	
		self.item_refresh = menu_view.Append(-1, "&Refresh\tF5", "Refresh Window")
		self.Bind(wx.EVT_MENU, self.refreshGrid, self.item_refresh)	
		menuBar.Append(menu_view, "&View")
		
		menu_search = wx.Menu()
		self.item_search = menu_search.Append(-1, "&Find\tCtrl-F", "Find")
		self.Bind(wx.EVT_MENU, self.OnFind, self.item_search)		
		menuBar.Append(menu_search, "&Search")
		
		menu_log = wx.Menu()
		self.item_logStart = menu_log.Append(-1, "&Start\tCtrl-R", "Start Logging")
		self.Bind(wx.EVT_MENU, self.startLogging, self.item_logStart)
		self.item_logStop = menu_log.Append(-1, "S&top\tCtrl-X", "Stop Logging")
		self.Bind(wx.EVT_MENU, self.stopLogging, self.item_logStop)
		self.item_logPause = menu_log.Append(-1, "&Pause\tCtrl-P", "Pause Logging")
		self.Bind(wx.EVT_MENU, self.pauseLogging, self.item_logPause)
		self.item_logPause.Enable(False)
		self.item_logStop.Enable(False)
		menuBar.Append(menu_log, "&Log Run")
		
		menu_config = wx.Menu()
		self.item_channel = menu_config.Append(-1, "&Viewer Configuration\tF6", "Set the channel Id")
		self.Bind(wx.EVT_MENU, self.getViewerConfiguration, self.item_channel)
		self.item_filter = menu_config.Append(-1, "&Filter\tF7", "Create Filter")
		self.Bind(wx.EVT_MENU, self.getColor, self.item_filter)
		menuBar.Append(menu_config, "&Configuration")
		
		
		self.frame.SetMenuBar(menuBar)
		
		#Addind ToolBar
		self.toolbar = self.frame.CreateToolBar()
		self.toolbar.SetToolBitmapSize(wx.Size(16,16))
		self.toolbar.AddLabelTool(201, '', wx.Bitmap('icons\play.png'))
		self.toolbar.SetToolShortHelp(201, "Start Logging")
		self.frame.Bind(wx.EVT_TOOL, self.startLogging, id=201)
		self.toolbar.AddLabelTool(202, '', wx.Bitmap('icons\stop1.png'))
		self.toolbar.SetToolShortHelp(202, "Stop Logging")
		self.frame.Bind(wx.EVT_TOOL, self.stopLogging, id=202)
		self.toolbar.AddLabelTool(203, '', wx.Bitmap('icons\pause1.png'))
		self.toolbar.EnableTool(202, False)
		self.toolbar.EnableTool(203, False)
		self.frame.Bind(wx.EVT_TOOL, self.pauseLogging, id=203)
		self.toolbar.SetToolShortHelp(203, "Pause Logging")
		self.toolbar.AddSeparator()
		self.toolbar.AddLabelTool(204, '', wx.Bitmap('icons\config.png'))
		self.toolbar.SetToolShortHelp(204, "MAC\\Channel Id Configuration")
		self.frame.Bind(wx.EVT_TOOL, self.getViewerConfiguration, id=204)
		self.toolbar.AddLabelTool(205, '', wx.Bitmap('icons\seek.png'))
		self.toolbar.SetToolShortHelp(205, "Filter")
		self.frame.Bind(wx.EVT_TOOL, self.getColor, id=205)
		self.toolbar.AddLabelTool(206, '', wx.Bitmap('icons\size.png'))
		self.toolbar.SetToolShortHelp(206, "History Depth")
		self.frame.Bind(wx.EVT_TOOL, self.setHistoryDepth, id=206)
		self.toolbar.AddSeparator()

		self.toolbar.AddLabelTool(207, '', wx.Bitmap('icons\seek2.png'))
		self.toolbar.SetToolShortHelp(207, "Find")
		self.frame.Bind(wx.EVT_TOOL, self.OnFind, id=207)
		
		self.toolbar.AddLabelTool(208, '', wx.Bitmap('icons\start1.png'))
		self.toolbar.SetToolShortHelp(208, "Refresh Window")
		self.frame.Bind(wx.EVT_TOOL, self.refreshGrid, id=208)

		self.toolbar.Realize()

		#set the resize event
		self.frame.Bind(wx.EVT_SIZE, self.OnSize)
		#set on cancle
		self.frame.Bind(wx.EVT_CLOSE, self.OnExitApp)
		#set Frame to Maximize
		self.frame.Maximize()
		return True

	def OnFind(self, evt):
		if self.start != True:
			self.findData = wx.FindReplaceData(wx.FR_DOWN)
			self.findFrame = wx.FindReplaceDialog(self.window, self.findData, "Find")
			self.findFrame.Show()
			self.SetTopWindow(self.findFrame)
			winFind = FindText(self.findFrame, self, self.window, self.findData, Log())
			if winFind:
				self.toolbar.EnableTool(201, False)
				self.toolbar.EnableTool(202, False)
				self.toolbar.EnableTool(203, False)
				self.toolbar.EnableTool(204, False)
				self.toolbar.EnableTool(205, False)
				self.toolbar.EnableTool(206, False)
				self.toolbar.EnableTool(207, False)
				self.toolbar.EnableTool(208, False)
				self.oldPause = self.pause
				self.pause = True

				self.item_save.Enable(False)
				self.item_saveas.Enable(False)
				self.item_exit.Enable(False)
				self.item_search.Enable(False)
				self.item_logStart.Enable(False)
				self.item_logStop.Enable(False)
				self.item_logPause.Enable(False)
				self.item_channel.Enable(False)
				self.item_filter.Enable(False)
				self.item_history.Enable(False)
				self.item_refresh.Enable(False)
				
				self.windowFind = winFind
				self.findFrame.Bind(wx.EVT_CLOSE, self.windowFind.onCancel)
			else:
				# It was probably a dialog or something that is already
				# gone, so we're done.
				self.findFrame.Destroy()
				self.findFrame = -1
				self.windowFind = -1
				return True
			self.SetTopWindow(self.findFrame)
		else:
			self.log.WriteText(self.frame, 'Can not Find while Log is Running. Fisrt Stop or Pause the Log Run.\n')
		return True
			
			
	def OnSaveFile(self, event):
		if self.start != True:
			if self.last_name_saved:
				try:
					self.saveLogs(self.last_name_saved)
				except IOError, (code, message):
					print "Error", code, "with message", message
					dlg = wx.MessageDialog(self.frame, 'Error saving file: ' + message, 'File Save Error',wx.OK)
					dlg.ShowModal()				
			else:
				self.OnSaveAsFile(event)
		else:
			self.log.WriteText(self.frame, "Can not Save while Log is running. First Stop or Pause the Log Run.\n")

	def OnSaveAsFile(self, event):
		if self.start != True:
			wcd = 'CSV Files (*.csv)|*.csv'
			dir = os.getcwd()
			save_dlg = wx.FileDialog(self.frame,"Save file as...", dir, "",wcd, wx.SAVE | wx.OVERWRITE_PROMPT)
			if save_dlg.ShowModal() == wx.ID_OK:
				path = save_dlg.GetPath()
				try:
					self.saveLogs(path)
					self.last_name_saved = path
				except IOError, (code, message):
					print "Error", code, "with message", message
					dlg = wx.MessageDialog(self.frame, 'Error saving file: ' + message, 'File Save Error',wx.OK)
					dlg.ShowModal()
			save_dlg.Destroy()
		else:
			self.log.WriteText(self.frame, "Can not save while Log is running. First Stop or Pause the Log Run.\n")
		
	def saveLogs(self, path):
		bottom = self.window.grid.GetNumberRows()
		right = self.window.grid.GetNumberCols()
		file = open(path, 'w')
		file.write("#,Time Stamp,Processor,Module,Severity,Log Message")		
		if bottom > 0:
			print bottom
			print right
			print path
			for row in range(0, bottom):
				file.write("\n")
				for col in range(0, right):
					file.write(self.window.grid.GetCellValue(row, col))
					file.write(",")
		file.close()	
			
	def OnExit(self):
		print "OnExit"
	
	def OnExitApp(self, evt):
		print "OnExitApp"
		if self.pipeThread != -1:
			self.pipeThread.kill()
			try:
				PipeHandle = win32file.CreateFile(self.PipeName,
							win32file.GENERIC_READ | win32file.GENERIC_WRITE,
							0, None, win32file.OPEN_EXISTING,
							win32file.FILE_ATTRIBUTE_NORMAL, 0)
				if PipeHandle == win32file.INVALID_HANDLE_VALUE:
					print 'Fail'
				else:
					print 'pass'
			except win32api.error, (code, function, message):
				print "Exit Code ", code, "with message", message
			finally:
				self.pipeThread = -1
		self.frame.Destroy()
		return True
	
	def OnSize(self, event):
		self.size = event.GetSize()
		#self.gridSize = 0
		if self.gridSize == 0:
			self.gridSize  = 20 + self.window.grid.GetColSize(0) + self.window.grid.GetColSize(1) + self.window.grid.GetColSize(2) + self.window.grid.GetColSize(3) + self.window.grid.GetColSize(4)
		i = self.size.width - self.gridSize
		if i > self.MaxColSize:
			self.MaxColSize = i
		#self.window.grid.SetColMinimalWidth(5, self.MaxColSize)
		#self.window.grid.AutoSizeColumn(5, False)
		event.Skip()
		
	def getChannelId(self, evt):
		dialog = wx.TextEntryDialog(None,
					"What kind of text would you like to enter?",
					"Text Entry", "Default Value", style=wx.OK|wx.CANCEL)
		if dialog.ShowModal() == wx.ID_OK:
			if dialog.GetValue().isdigit() != True:
				return True
		dialog.Destroy()
		self.pipeThread = AccessPipe(self)
		return True
		
	def StopThread(self):
		if self.pipeThread != -1:
			self.pipeThread.kill()
			fileOpened = False
			while fileOpened != True:
				try:
					self.PipeHandle = win32file.CreateFile(self.PipeName,
								win32file.GENERIC_READ | win32file.GENERIC_WRITE,
								0, None, win32file.OPEN_EXISTING,
								win32file.FILE_ATTRIBUTE_NORMAL, 0)
					if self.PipeHandle != win32file.INVALID_HANDLE_VALUE:
						win32file.CloseHandle(self.PipeHandle)
				except win32api.error, (code, function, message):
					fileOpened = True
				finally:
					fileOpened = True
		self.pipeThread = -1
	
	def getViewerConfiguration(self, event):
		if (self.stop == True):
			winConfig = ConfigSelect('Viewer Configuration', (100,100), (240,150), self, Log())
			if winConfig:
				winConfig.ShowModal()
				self.winConfig = winConfig
			else:
				# It was probably a dialog or something that is already
				# gone, so we're done.
				self.configFrame.Destroy()
				self.configFrame = -1
				return True
		else:
			self.log = Log()
			self.log.WriteText(self.frame, 'Viewer can not be configured, while Log is Running or Paused. First Stop the Logging\n')
			return True

	def configFrameDestroy(self):
		self.configFrame.Destroy()
		
	def getColor(self, event):
		winColour = TestColourSelect('Filter Configuration', (100,100), (440,170), self, Log())
		if winColour:
			winColour.ShowModal()
			self.windowColour = winColour
		else:
            # It was probably a dialog or something that is already
            # gone, so we're done.
			self.windowColour.Destroy()
			self.windowColour = -1
			return True
		return True
	
	def refreshGrid(self, event):
		if self.start != True:
			self.window.grid.BeginBatch()
			for i in range(self.window.grid.GetNumberRows()):
				attr = wx.grid.GridCellAttr()
				attr.SetBackgroundColour(wx.Colour(255,255,255))
				self.window.grid.SetRowAttr(i, attr)
				for name, filterString, colour in self.currentList:
					if self.window.grid.GetCellValue(i, 0).find(filterString) == -1:
						if self.window.grid.GetCellValue(i, 1).find(filterString) == -1:
							if self.window.grid.GetCellValue(i, 2).find(filterString) == -1:
								if self.window.grid.GetCellValue(i, 3).find(filterString) == -1:
									if self.window.grid.GetCellValue(i, 4).find(filterString) == -1:
										if self.window.grid.GetCellValue(i, 5).find(filterString) == -1:
											continue
					attr_new = wx.grid.GridCellAttr()
					attr_new.SetBackgroundColour(colour)
					self.window.grid.SetRowAttr(i, attr_new)
					continue
			self.window.grid.EndBatch()
			self.window.grid.ForceRefresh()
		else:
			self.log.WriteText(self.frame, 'Can not Refresh while Log is Running. Fisrt Stop or Pause the Log Run.\n')		
		
	def setHistoryDepth(self, event):
		winHistory = HistoryDepth('History Depth', (100,100), (250,130), self, Log())
		if winHistory:
			winHistory.ShowModal()
			self.winHistory = winHistory
		else:
            # It was probably a dialog or something that is already
            # gone, so we're done.
			self.winHistory.Destroy()
			self.winHistory = -1
			return True
		return True
		
	def sortColumn(self, event):
		if (self.pause == True) | (self.stop == True):
			logList = []
			sortedlist = []
			if event.GetCol() != -1:
				for i in range(self.window.grid.GetNumberRows()):
					logList.append((int(self.window.grid.GetCellValue(i, 0)), int(self.window.grid.GetCellValue(i, 1)), 
									self.window.grid.GetCellValue(i, 2), self.window.grid.GetCellValue(i, 3),
									self.window.grid.GetCellValue(i, 4), self.window.grid.GetCellValue(i, 5),
									self.window.grid.GetCellBackgroundColour(i, 0)))
				sortedList = sorted(logList, key=operator.itemgetter(event.GetCol()))
				i = 0
				for index, timeStamp, processor, module, severity, log, colour in sortedList:
					self.window.grid.SetCellValue(i, 0, str(index))
					self.window.grid.SetCellValue(i, 1, str(timeStamp))
					self.window.grid.SetCellValue(i, 2, processor)
					self.window.grid.SetCellValue(i, 3, module)
					self.window.grid.SetCellValue(i, 4, severity)
					self.window.grid.SetCellValue(i, 5, log)
					attr = wx.grid.GridCellAttr()
					attr.SetBackgroundColour(colour)
					self.window.grid.SetRowAttr(i, attr)
					i += 1
				i = 0
			event.Skip()
		else:
			self.log.WriteText(self.frame, "Column can not be sorted while Log is running. First Stop or Pause the Logging\n")

	def startLogging (self, event):
		if self.stop == True:
			if self.window.grid.GetNumberRows() > 0:
				self.window.grid.DeleteRows(0, self.window.grid.GetNumberRows())
				self.window.grid.SetColMinimalWidth(5, self.MaxColSize)
				self.window.grid.AutoSizeColumn(5, False)
				self.GridRow = 0
		self.stop = False
		self.pause = False
		self.start = True
		self.toolbar.SetToolNormalBitmap(201, wx.Bitmap('icons\startHot.png'))
		self.toolbar.SetToolNormalBitmap(202, wx.Bitmap('icons\stop1.png'))
		self.toolbar.SetToolNormalBitmap(203, wx.Bitmap('icons\pause1.png'))
		#stop Configuration Option if Logging has started
		if self.pipeThread == -1:
			MAC_String = self.MAC_ADD.replace(":", "_")
			self.PipeName = '\\\\.\\pipe\\mynamedpipe_' + str(self.CHANNEL_ID) + "_" + MAC_String
			self.pipeThread = AccessPipe(self)
		self.toolbar.EnableTool(202, True)
		self.toolbar.EnableTool(203, True)
		self.item_logPause.Enable(True)
		self.item_logStop.Enable(True)
		return True
	
	def stopLogging (self, event):
		self.stop = True
		self.start = False
		self.pause = False
		self.toolbar.SetToolNormalBitmap(201, wx.Bitmap('icons\play.png'))
		self.toolbar.SetToolNormalBitmap(202, wx.Bitmap('icons\stopHot.png'))
		self.toolbar.SetToolNormalBitmap(203, wx.Bitmap('icons\pause1.png'))
		self.window.grid.SetColMinimalWidth(5, self.MaxColSize)
		self.window.grid.AutoSizeColumn(5, False)
		self.toolbar.EnableTool(203, False)
		self.item_logPause.Enable(False)
	
	def pauseLogging (self, event):
		if self.stop != True:
			self.pause = True
			self.start = False
			self.toolbar.SetToolNormalBitmap(201, wx.Bitmap('icons\play.png'))
			self.toolbar.SetToolNormalBitmap(202, wx.Bitmap('icons\stop1.png'))
			self.toolbar.SetToolNormalBitmap(203, wx.Bitmap('icons\pauseHot.png'))
			self.window.grid.SetColMinimalWidth(5, self.MaxColSize)
			self.window.grid.AutoSizeColumn(5, False)

if __name__ == '__main__':
	try:
		app = App(redirect=False)
		app.MainLoop()
	finally:
		print 'Program crashed'