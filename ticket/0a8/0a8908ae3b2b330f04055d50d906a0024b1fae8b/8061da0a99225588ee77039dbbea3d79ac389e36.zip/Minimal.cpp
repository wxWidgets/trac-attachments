#include "wx/wxprec.h"

#ifdef __BORLANDC__
    #pragma hdrstop
#endif

#ifndef WX_PRECOMP
    #include "wx/wx.h"
#endif


#include <wx/msw/dib.h>
#include <wx/rawbmp.h>
#include <wx/msw/private.h>
#include <vector>
using namespace std;

#define dprintf(...)\
{\
    WCHAR* szMessage = new WCHAR[1024];\
    wsprintf( szMessage, __VA_ARGS__);\
    OutputDebugString( szMessage );\
    delete szMessage;\
}

static inline bool GetDIBSection(HBITMAP hbmp, DIBSECTION *ds)
{
    return ::GetObject(hbmp, sizeof(DIBSECTION), ds) == sizeof(DIBSECTION) &&
                       ds->dsBm.bmBits;
}

void PrintInformation(HBITMAP hbmp)
{
    DIBSECTION ds;
    if ( GetDIBSection(hbmp, &ds) )
    {
        dprintf(L"  A DIB section, BitsPixel:%d",ds.dsBm.bmBitsPixel);
    }
    else
    {
        BITMAP bm;
        if ( !::GetObject(hbmp, sizeof(bm), &bm) )
        {
            wxLogLastError(wxT("GetObject(bitmap)"));
        }

        dprintf(L"  A DDB, BitsPixel:%d",bm.bmBitsPixel);
    }
}

void PrintInformation(wxBitmap& bm)
{
    HBITMAP hbmp = (HBITMAP)bm.GetHBITMAP();
    PrintInformation(hbmp);
}

class MyApp : public wxApp
{
public:
    virtual bool OnInit();
};

class MyFrame : public wxFrame
{
public:
    MyFrame(const wxString& title);
    ~MyFrame();

private:
    void OnClose(wxCloseEvent& event);
    void OnQuit(wxCommandEvent& event);

    void OnPaint(wxPaintEvent &event);
    void OnBefore(wxCommandEvent& event);
    void OnAfter(wxCommandEvent& event);

    enum
    {
        idBtnBefore = 1000,
        idBtnAfter
    };
    wxButton* BtnBefore;
    wxButton* BtnAfter;
    wxBitmap bmp;

    HBITMAP hBm;
    HBITMAP hBmCp;

    vector<wxBitmap> bmArray;

    DECLARE_EVENT_TABLE()
};

BEGIN_EVENT_TABLE(MyFrame, wxFrame)
    EVT_PAINT(MyFrame::OnPaint)
    EVT_BUTTON(idBtnBefore, MyFrame::OnBefore)
    EVT_BUTTON(idBtnAfter, MyFrame::OnAfter)
END_EVENT_TABLE()

IMPLEMENT_APP(MyApp)


bool MyApp::OnInit()
{
    if ( !wxApp::OnInit() )
        return false;

    MyFrame *frame = new MyFrame("Minimal wxWidgets App");

    frame->Show(true);

    return true;
}

MyFrame::MyFrame(const wxString& title)
       : wxFrame(NULL, wxID_ANY, title)
{
    SetSize( 400, 400);
    Center();

    hBmCp = hBm = NULL;
    bmp = wxNullBitmap;

    wxPoint btnPos(320,0);
    BtnBefore = new wxButton(this, idBtnBefore, L"&Create", btnPos, wxDefaultSize, 0);
    btnPos.y = 20;
    BtnAfter = new wxButton(this, idBtnAfter, L"&Select", btnPos, wxDefaultSize, 0);

    /*--------------------------for Type 1------------------------*/
    // This bitmap doesn't work: a 256-color bitmap with pallete
    wxBitmap bm(L"type_1.bmp",wxBITMAP_TYPE_BMP);
    bmArray.push_back(bm);
    dprintf(L"A wxBitmap constructed from wxBitmap::LoadFile:");
    PrintInformation(bm);
    dprintf(L"---------------------------");

    {
        dprintf(L"Construct a wxNativePoxelData for a wxBitmap:");
        wxNativePixelData data(bm);
        bm.UngetRawData(data);
        dprintf(L"---------------------------");
    }

    dprintf(L"wxBitmap::GetSubBitmap:");
    wxRect rt( 0, 0, bm.GetWidth()/4, bm.GetHeight());
    wxBitmap sub = bm.GetSubBitmap(rt);
    bmArray.push_back(sub);
    dprintf(L"---------------------------");

    {
        wxBitmap bitmap(10,10,8);

        dprintf(L"Select a 8bpp wxBitmap into a memory DC:");
        wxMemoryDC memdc(bitmap);
        dprintf(L"---------------------------");
    }

    {
        wxDIB dib(bm);
        hBm = dib.CreateDDB();
        dprintf(L"A bitmap created by wxDIB(wxBitmap&), m_depth:%d\n", dib.GetDepth());
        PrintInformation(hBm);
        MemoryHDC dc;
        SelectInHDC selectDC(dc, hBm);
        if( !selectDC )
        {
            wxLogLastError(L"SelectObject(wxDIB)");
        }
        dprintf(L"---------------------------");
        hBm = NULL;
    }

    {
        wxDIB dib(10,10,24);
        hBm = dib.CreateDDB();
        dprintf(L"A bitmap created by wxDIB, m_depth:%d\n", dib.GetDepth());
        PrintInformation(hBm);
        MemoryHDC dc;
        SelectInHDC selectDC(dc, hBm);
        if( !selectDC )
        {
            wxLogLastError(L"SelectObject(24-bpp wxDIB)");
        }
        dprintf(L"---------------------------");
        hBm = NULL;
    }

    /*--------------------------for Type 2------------------------*/
    // This bitmap works: a 24bpp bitmap
    bm.LoadFile(L"type_2.bmp",wxBITMAP_TYPE_BMP);
    bmArray.push_back(bm);
    rt.width = bm.GetWidth()/4;
    rt.height = bm.GetHeight();
    bmArray.push_back(bm.GetSubBitmap(rt));
}

MyFrame::~MyFrame()
{
}

void MyFrame::OnPaint(wxPaintEvent &event)
{
    wxPaintDC dc( this);
    for(int i=0,count=bmArray.size();i<count;i++)
        dc.DrawBitmap( bmArray[i], i*50, i*50, false);
}

void MyFrame::OnClose(wxCloseEvent &event)
{
    Destroy();
}

void MyFrame::OnQuit(wxCommandEvent &event)
{
    Destroy();
}

void MyFrame::OnBefore(wxCommandEvent &event)
{
    if( hBm || hBmCp || bmp.IsOk() )
        return;

    dprintf(L"A bitmap created by CreateBitmap:");
    hBm = ::CreateBitmap(100, 100, 1, wxDisplayDepth(), NULL);
    if( !hBm )
    {
        wxLogLastError(L"CreateBitmap");
    }
    else
        PrintInformation(hBm);

    dprintf(L"A bitmap created by CreateCompatibleBitmap:");
    HDC hdc;
    hdc = ::GetDC(NULL);
    hBmCp = ::CreateCompatibleBitmap(hdc, 100, 100);
    ::ReleaseDC(NULL, hdc);
    if( !hBmCp )
    {
        wxLogLastError(L"CreateCompatibleBitmap");
    }
    else
        PrintInformation(hBmCp);

    bmp.LoadFile(L"bm.bmp", wxBITMAP_TYPE_BMP);
    if( bmp.IsOk() )
    {
        dprintf(L"A wxBitmap constructed from wxBitmap::LoadFile:");
    }
    else
        wxLogLastError(L"wxBitmap::LoadFile");
    PrintInformation(bmp);

    dprintf(L"----------------------");
}

void MyFrame::OnAfter(wxCommandEvent &event)
{
    if( !hBm || !hBmCp || !bmp.IsOk() )
        return;

    {
        dprintf(L"A bitmap created by CreateBitmap:");
        MemoryHDC dc;
        SelectInHDC selectDC(dc, hBm);
        if( !selectDC )
        {
            wxLogLastError(L"SelectObject(CreateBitmap)");
        }
        else
            PrintInformation(hBm);
        ::DeleteObject(hBm);
        hBm = NULL;
    }

    {
        dprintf(L"A bitmap created by CreateCompatibleBitmap:");
        MemoryHDC dc;
        SelectInHDC selectDC(dc, hBmCp);
        if( !selectDC )
        {
            wxLogLastError(L"SelectObject(CreateCompatibleBitmap)");
        }
        else
            PrintInformation(hBmCp);
        ::DeleteObject(hBmCp);
        hBmCp = NULL;
    }

    {
        dprintf(L"A wxBitmap constructed from wxBitmap::LoadFile:");
        MemoryHDC dc;
        SelectInHDC selectDC(dc, (HBITMAP)bmp.GetHBITMAP());
        if( !selectDC )
        {
            wxLogLastError(L"SelectObject(wxBitmap)");
        }
        else
            PrintInformation(bmp);
        bmp = wxNullBitmap;
    }

    dprintf(L"----------------------");
}
