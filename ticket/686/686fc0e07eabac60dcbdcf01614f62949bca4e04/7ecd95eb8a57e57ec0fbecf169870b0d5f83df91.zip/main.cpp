

#include <wx/wx.h>
#include <wx/dcbuffer.h>


//-----------------------------------------------------------------------------
class App: public wxApp
{
public:
	virtual bool OnInit();
};

//-----------------------------------------------------------------------------
class Clock : public wxPanel
{
public:
	Clock(wxWindow* parent);
	void OnPaint(wxPaintEvent& e);
};

//-----------------------------------------------------------------------------
class AppMainWin : public wxFrame
{
public:
	typedef wxFrame    super;
	typedef AppMainWin self;

	AppMainWin();
	virtual ~AppMainWin();

	void OnShowModalDialog(wxCommandEvent& e);
	void OnStartStopTimer(wxCommandEvent& e);
	void OnTimer(wxTimerEvent& e);
	void OnClose(wxCloseEvent& e);

private:
	wxTimer   timer_;
	wxPanel*  panel_;
	wxTextCtrl* text_;
	Clock*    clock_;
	wxButton* show_modal_dlg_;
	wxButton* start_stop_timer_;
};

//-----------------------------------------------------------------------------
IMPLEMENT_APP(App)

//-----------------------------------------------------------------------------
bool App::OnInit()
{
	if (!wxApp::OnInit()) {
		return false;
	}

	// create the main program window
	AppMainWin *w = new AppMainWin;
	w->Show(true);
	SetTopWindow(w);
	return true;
}

//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------

//-----------------------------------------------------------------------------
AppMainWin::AppMainWin()
: wxFrame(NULL, wxID_ANY, wxT("wx modal bug test app"))
{
	panel_ = new wxPanel(this);
	text_ = new wxTextCtrl(panel_, wxID_ANY, wxT(""), 
		wxDefaultPosition, wxDefaultSize, 
		wxTE_MULTILINE | wxTE_READONLY);
	clock_ = new Clock(panel_);
	show_modal_dlg_ = new wxButton(panel_, wxID_ANY, wxT("Show Modal"));
	start_stop_timer_ = new wxButton(panel_, wxID_ANY, wxT("&Stop Timer"));

	static int const border = 5;
	wxBoxSizer* sizer = new wxBoxSizer(wxVERTICAL);
	wxBoxSizer* panel_sizer = new wxBoxSizer(wxVERTICAL);
	wxBoxSizer* button_sizer = new wxBoxSizer(wxHORIZONTAL);
	wxBoxSizer* top_sizer = new wxBoxSizer(wxHORIZONTAL);
	top_sizer->Add(text_, 1, wxEXPAND);
	top_sizer->AddSpacer(border);
	top_sizer->Add(clock_, 0, wxEXPAND | wxSHAPED);
	button_sizer->AddStretchSpacer();
	button_sizer->Add(show_modal_dlg_);
	button_sizer->AddSpacer(border);
	button_sizer->AddSpacer(border);
	button_sizer->Add(start_stop_timer_);
	button_sizer->AddStretchSpacer();
	panel_sizer->Add(top_sizer, 1, wxEXPAND | wxALL, border);
	panel_sizer->Add(button_sizer, 0, wxEXPAND);
	panel_sizer->AddSpacer(border);
	panel_->SetSizer(panel_sizer);
	sizer->Add(panel_, 1, wxEXPAND);
	SetSizer(sizer);

	show_modal_dlg_->Connect(wxEVT_COMMAND_BUTTON_CLICKED, 
		wxCommandEventHandler(self::OnShowModalDialog), NULL, this);

	start_stop_timer_->Connect(wxEVT_COMMAND_BUTTON_CLICKED, 
		wxCommandEventHandler(self::OnStartStopTimer), NULL, this);

	timer_.SetOwner(this);
	Connect(wxEVT_TIMER, wxTimerEventHandler(self::OnTimer));
	Connect(wxEVT_CLOSE_WINDOW, wxCloseEventHandler(self::OnClose));

	timer_.Start(1, wxTIMER_CONTINUOUS);
}

//-----------------------------------------------------------------------------
AppMainWin::~AppMainWin()
{
}

//-----------------------------------------------------------------------------
void 
AppMainWin::OnClose(wxCloseEvent& e)
{
	timer_.Stop();
	e.Skip();
}

//-----------------------------------------------------------------------------
void 
AppMainWin::OnStartStopTimer(wxCommandEvent& e)
{
	if (timer_.IsRunning()) {
		timer_.Stop();
		start_stop_timer_->SetLabel(wxT("&Start Timer"));
	}
	else {
		timer_.Start(1, wxTIMER_CONTINUOUS);
		start_stop_timer_->SetLabel(wxT("&Stop Timer"));
	}
}

//-----------------------------------------------------------------------------
void
AppMainWin::OnShowModalDialog(wxCommandEvent& e)
{
	wxDialog* dlg = new wxDialog(this, wxID_ANY, wxT("Modal Dialog"), wxDefaultPosition);

	dlg->SetInitialSize(GetSize() / 2);

	dlg->CenterOnParent();
	text_->AppendText(wxT("Entering Modal Loop.\n"));
	dlg->ShowModal();
	text_->AppendText(wxT("Modal Loop Exited.\n"));
	dlg->Destroy();
}

//-----------------------------------------------------------------------------
void 
AppMainWin::OnTimer(wxTimerEvent& e)
{
	Refresh();
	// Sleep ensures that there is another timer event on the event queue
	// and causes modal loop of child dialog to never exit (until the timer
	// is stopped).
	wxMilliSleep(50);
}

//-----------------------------------------------------------------------------
Clock::Clock(wxWindow* parent)
: wxPanel(parent, wxID_ANY)
{
	SetBackgroundStyle(wxBG_STYLE_CUSTOM);
	Connect(wxEVT_PAINT, wxPaintEventHandler(Clock::OnPaint));
}

//-----------------------------------------------------------------------------
void 
Clock::OnPaint(wxPaintEvent& e)
{
	wxAutoBufferedPaintDC dc(this);

	wxSize center = GetClientSize() / 2;
	double radius = (center.x < center.y) ? center.x : center.y;
	radius -= 1;
	wxMilliClock_t t = wxGetLocalTimeMillis();
	int const total_ms = 1000 * 60;
	t = t % total_ms;
	double const angle = M_PI * 2 * t.ToDouble() / double(total_ms);
	double const arm_length = radius - 2;
	int x = (sin(angle) * arm_length) + center.x;
	int y = (-cos(angle) * arm_length) + center.y;

	dc.SetBackground(*wxWHITE);
	dc.Clear();
	dc.SetBrush(*wxTRANSPARENT_BRUSH);
	dc.SetPen(*wxBLACK);
	dc.DrawCircle(center.x, center.y, radius);
	dc.DrawLine(center.x, center.y, x, y);
}
