#include "main.h"
#include "pobieranie.h"

////////////////////////////////////////////////////////////////////////////////

void test(wxString _url)
{
	wxURL __polaczenie(_url);
	if (__polaczenie.IsOk())
	{
		__polaczenie.GetProtocol().SetTimeout(20);
		wxInputStream* __strumien = __polaczenie.GetInputStream();
		if (__strumien)
		{
			wxMessageBox(_("test: ok"));
		} else
		{
			wxMessageBox(_("test: faild"));
		}
	} else
	{
		switch (__polaczenie.GetError())
		{
			case wxURL_SNTXERR:
				break;

			case wxURL_NOPROTO:
				break;

			case wxURL_NOHOST:
				break;

			case wxURL_NOPATH:
				break;

			case wxURL_CONNERR:
				break;

			case wxURL_PROTOERR:
				break;

			case wxURL_NOERR:
				break;
		}

	}
}

void AuOknoPostepu::wykonaj()
{
	wxTextEntryDialog dlg(this, _("Enter url:"), _("Please enter text"), _("ftp://biolpc22.york.ac.uk/pub/binary/wxWidgets-DialogsDemo-Windows.zip"));
	if (dlg.ShowModal()==wxID_OK)
	{
		test(dlg.GetValue());

		do
		{
			_pobieranie = new AuPobieranie(dlg.GetValue(), _pobieranieFlaga);
		} while (!_pobieranieFlaga);
	}
}

AuOknoPostepu::AuOknoPostepu()
: _AuOknoPostepu(NULL)
{
	Show();

	wykonaj();
}

AuOknoPostepu::~AuOknoPostepu()
{
	if (_pobieranieFlaga) _pobieranie->Delete();

	while (_pobieranieFlaga)
		wxSleep(1);
}
