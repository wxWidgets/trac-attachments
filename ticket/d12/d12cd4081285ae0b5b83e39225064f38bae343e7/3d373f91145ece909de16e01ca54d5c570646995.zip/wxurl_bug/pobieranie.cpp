#include "pobieranie.h"

////////////////////////////////////////////////////////////////////////////////

void* AuPobieranie::Entry()
{
	wxURL __polaczenie(_url);
	if (__polaczenie.IsOk())
	{
		__polaczenie.GetProtocol().SetTimeout(20);
		wxInputStream* __strumien = __polaczenie.GetInputStream();
		if (__strumien)
		{
			wxMessageBox(_("thread: ok"));
			delete __strumien;
		} else
		{
			wxMessageBox(_("thread: faild"));
		}
	} else
	{
		switch (__polaczenie.GetError())
		{
			case wxURL_SNTXERR:
				break;

			case wxURL_NOPROTO:
				break;

			case wxURL_NOHOST:
				break;

			case wxURL_NOPATH:
				break;

			case wxURL_CONNERR:
				break;

			case wxURL_PROTOERR:
				break;

			case wxURL_NOERR:
				break;
		}
	}

	_flaga = false;
	return 0;
}

AuPobieranie::AuPobieranie(wxString __url, bool& __flaga)
: wxThread(), _flaga(__flaga), _url(__url)
{
	_flaga = false;
	if (Create()==wxTHREAD_NO_ERROR)
	{
		if (Run()==wxTHREAD_NO_ERROR)
		{
			_flaga = true;
		} else
		{
			Delete();
		}
	}
	else
	{
		Delete();
	}
}
