///////////////////////////////////////////////////////////////////////////
// C++ code generated with wxFormBuilder (version Oct 13 2006)
// http://www.wxformbuilder.org/
//
// PLEASE DO "NOT" EDIT THIS FILE!
///////////////////////////////////////////////////////////////////////////

#ifndef __okna__
#define __okna__

// Define WX_GCH in order to support precompiled headers with GCC compiler.
// You have to create the header "wx_pch.h" and include all files needed
// for compile your gui inside it.
// Then, compile it and place the file "wx_pch.h.gch" into the same
// directory that "wx_pch.h".
#ifdef WX_GCH
#include <wx_pch.h>
#else
#include <wx/wx.h>
#endif

#include <wx/gauge.h>
#include <wx/panel.h>

///////////////////////////////////////////////////////////////////////////

/**
 * Class _AuOknoPostepu
 */
class _AuOknoPostepu : public wxFrame 
{
	private:
	
	protected:
		enum
		{
			ID_DEFAULT = 1000,
		};
		
		wxPanel* m_panel1;
		wxStaticText* m_opisStaticText;
		wxGauge* m_postepGauge;
		wxStaticText* m_predkoscStaticText;
	
	public:
		_AuOknoPostepu( wxWindow* parent, int id = -1, wxString title = wxT("au"), wxPoint pos = wxDefaultPosition, wxSize size = wxSize( -1,-1 ), int style = wxCAPTION|wxSTAY_ON_TOP|wxTAB_TRAVERSAL );
	
};

#endif //__okna__
