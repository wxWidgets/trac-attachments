#ifndef _au_pobieranie_
#define _au_pobieranie_

#include <wx/wxprec.h>

#ifdef __BORLANDC__
	#pragma hdrstop
#endif

#ifndef WX_PRECOMP
	#include <wx/wx.h>
#endif

#include <wx/thread.h>
#include <wx/url.h>

////////////////////////////////////////////////////////////////////////////////

class AuPobieranie: public wxThread
{
	public:
		AuPobieranie(wxString, bool&);
		virtual void*	Entry();

	protected:

	private:
		bool&					_flaga;
		wxString				_url;

};


#endif // _au_pobieranie_

