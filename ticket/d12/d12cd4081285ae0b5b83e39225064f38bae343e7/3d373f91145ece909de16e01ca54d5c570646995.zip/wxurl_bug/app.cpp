#include "app.h"
IMPLEMENT_APP(AuApp);

#include "main.h"

////////////////////////////////////////////////////////////////////////////////

bool AuApp::OnInit()
{
	/* Podstawowa inicjacja. */
	wxSocketBase::Initialize();

	AuOknoPostepu* okno = new AuOknoPostepu;

	return true;
}
