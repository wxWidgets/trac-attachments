///////////////////////////////////////////////////////////////////////////
// C++ code generated with wxFormBuilder (version Oct 13 2006)
// http://www.wxformbuilder.org/
//
// PLEASE DO "NOT" EDIT THIS FILE!
///////////////////////////////////////////////////////////////////////////

#include "wx/wxprec.h"

#ifdef __BORLANDC__
#pragma hdrstop
#endif //__BORLANDC__

#ifndef WX_PRECOMP
#include <wx/wx.h>
#endif //WX_PRECOMP

#include "okna.h"

///////////////////////////////////////////////////////////////////////////

_AuOknoPostepu::_AuOknoPostepu( wxWindow* parent, int id, wxString title, wxPoint pos, wxSize size, int style ) : wxFrame( parent, id, title, pos, size, style )
{
	wxBoxSizer* bSizer2;
	bSizer2 = new wxBoxSizer( wxVERTICAL );
	
	m_panel1 = new wxPanel( this, ID_DEFAULT, wxDefaultPosition, wxDefaultSize, wxTAB_TRAVERSAL );
	wxBoxSizer* bSizer3;
	bSizer3 = new wxBoxSizer( wxVERTICAL );
	
	m_opisStaticText = new wxStaticText( m_panel1, ID_DEFAULT, _("MyLabel"), wxDefaultPosition, wxDefaultSize, 0 );
	bSizer3->Add( m_opisStaticText, 0, wxALL|wxEXPAND, 5 );
	
	m_postepGauge = new wxGauge( m_panel1, ID_DEFAULT, 100, wxDefaultPosition, wxSize( 200,-1 ), wxGA_HORIZONTAL|wxGA_SMOOTH );
	bSizer3->Add( m_postepGauge, 0, wxALL|wxEXPAND, 5 );
	
	m_predkoscStaticText = new wxStaticText( m_panel1, ID_DEFAULT, _("MyLabel"), wxDefaultPosition, wxDefaultSize, wxALIGN_CENTRE );
	bSizer3->Add( m_predkoscStaticText, 0, wxALL|wxALIGN_CENTER_HORIZONTAL|wxEXPAND, 5 );
	
	m_panel1->SetSizer( bSizer3 );
	m_panel1->Layout();
	bSizer3->Fit( m_panel1 );
	bSizer2->Add( m_panel1, 1, wxEXPAND, 5 );
	
	this->SetSizer( bSizer2 );
	this->Layout();
	bSizer2->Fit( this );
}
