#ifndef _au_main_
#define _au_main_

#include <wx/wxprec.h>

#ifdef __BORLANDC__
	#pragma hdrstop
#endif

#ifndef WX_PRECOMP
	#include <wx/wx.h>
#endif

#include "okna.h"
#include <wx/textdlg.h>

////////////////////////////////////////////////////////////////////////////////
/*prototypy */
class AuPobieranie;

////////////////////////////////////////////////////////////////////////////////

class AuOknoPostepu: public _AuOknoPostepu
{
	public:
		AuOknoPostepu();
		~AuOknoPostepu();

		void	wykonaj();

	protected:

	private:

		AuPobieranie*			_pobieranie;
		bool					_pobieranieFlaga;

};


#endif // _au_main_
