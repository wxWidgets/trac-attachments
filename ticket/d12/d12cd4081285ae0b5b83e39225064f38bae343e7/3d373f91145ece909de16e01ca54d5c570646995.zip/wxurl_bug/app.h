#ifndef _au_app_
#define _au_app_

#include <wx/wxprec.h>

#ifdef __BORLANDC__
	#pragma hdrstop
#endif

#ifndef WX_PRECOMP
	#include <wx/wx.h>
#endif

#include <wx/socket.h>

////////////////////////////////////////////////////////////////////////////////

class AuApp: public wxApp
{
	public:
		virtual bool	OnInit();

	protected:

	private:

};


#endif // _au_app_
