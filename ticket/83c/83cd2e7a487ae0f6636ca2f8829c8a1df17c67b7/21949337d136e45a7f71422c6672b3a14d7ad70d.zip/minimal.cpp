#define WXUSINGDLL

#include <wx/wx.h>
#include <wx/propgrid/propgrid.h>
#include <wx/propgrid/advprops.h>
#include <wx/aui/aui.h>

class MyTimer : public wxTimer
{
public:
	explicit MyTimer(wxEvtHandler* owner) :
		wxTimer(owner, wxID_ANY)
	{
	}

	virtual void Notify()
	{
		wxWakeUpIdle();
	}
};

class MyWin : public wxWindow
{
public:
	MyWin(wxWindow* parent) :
		wxWindow(parent, wxID_ANY),
		myTimer(this)
	{
		auiManager.SetManagedWindow(this);

		wxTextCtrl* t1 = new wxTextCtrl(this, wxID_ANY, "This is a test text.");
		auiManager.AddPane(t1, wxAuiPaneInfo().Name("pane1").Caption("Pane 1").MinSize(100, 100).CloseButton(false).Left());
		auiManager.Update();

		myTimer.Start(1000);
	}
private:
	MyTimer myTimer;
	wxAuiManager auiManager;
};



class MyFrame : public wxFrame
{
public:
    MyFrame(wxWindow* parent) :
		wxFrame(parent, wxID_ANY, wxT("PropertyGrid Test"), wxDefaultPosition, wxSize(800, 600))
	{
		wxAuiNotebook* myBook = new wxAuiNotebook(this, wxID_ANY, wxDefaultPosition, wxDefaultSize, wxAUI_NB_TOP|wxAUI_NB_SCROLL_BUTTONS);
		myBook->AddPage(new MyWin(this), "Test");
	}
};

class MyApp: public wxApp
{
public:
	virtual bool OnInit()
	{
		MyFrame *frame = new MyFrame(NULL);
		frame->Show(true);
		SetTopWindow(frame);
		return true;
	}
};
DECLARE_APP(MyApp);
IMPLEMENT_APP_CONSOLE(MyApp);
