#define WXUSINGDLL

#include <wx/wx.h>
#include <wx/propgrid/propgrid.h>
#include <wx/propgrid/advprops.h>
#include <wx/aui/aui.h>

class MyWin : public wxWindow
{
public:
	MyWin(wxWindow* parent) :
		wxWindow(parent, wxID_ANY)
	{
		auiManager.SetManagedWindow(this);
		wxPropertyGrid *pg = new wxPropertyGrid(this,wxID_ANY,wxDefaultPosition,wxSize(400,400));
		wxPGChoices actions;
		actions.Add("Choice 1", 1);
		actions.Add("Choice 2", 2);
		actions.Add("Choice 3", 3);
		pg->Append(new wxEnumProperty("Action0", wxPG_LABEL, actions));
		pg->Append(new wxEnumProperty("Action1", wxPG_LABEL, actions));
		pg->Append(new wxEnumProperty("Action2", wxPG_LABEL, actions));
		pg->Append(new wxEnumProperty("Action3", wxPG_LABEL, actions));
		pg->Append(new wxEnumProperty("Action4", wxPG_LABEL, actions));
		pg->Append(new wxEnumProperty("Action5", wxPG_LABEL, actions));
		pg->Append(new wxEnumProperty("Action6", wxPG_LABEL, actions));
		pg->Append(new wxEnumProperty("Action7", wxPG_LABEL, actions));
		pg->Append(new wxEnumProperty("Action8", wxPG_LABEL, actions));
		pg->Append(new wxEnumProperty("Action9", wxPG_LABEL, actions));
		pg->Append(new wxEnumProperty("Action10", wxPG_LABEL, actions));
		pg->Append(new wxEnumProperty("Action11", wxPG_LABEL, actions));
		pg->Append(new wxEnumProperty("Action12", wxPG_LABEL, actions));
		pg->Append(new wxEnumProperty("Action13", wxPG_LABEL, actions));
		pg->Append(new wxEnumProperty("Action14", wxPG_LABEL, actions));
		pg->Append(new wxEnumProperty("Action15", wxPG_LABEL, actions));

		//auiManager.AddPane(pg, wxAuiPaneInfo().Name("pane2").Caption("Pane 2").MinSize(100, 100).CloseButton(false).Left());
		auiManager.AddPane(pg, wxAuiPaneInfo().Name("pane2").Caption("Pane 2").MinSize(100, 100).CloseButton(false).Right());
		auiManager.Update();
	}
private:
	wxAuiManager auiManager;
};

class MyFrame : public wxFrame
{
public:
    MyFrame(wxWindow* parent) :
		wxFrame(parent, wxID_ANY, wxT("PropertyGrid Test"), wxDefaultPosition, wxSize(800, 600))
	{
		wxAuiNotebook* myBook = new wxAuiNotebook(this, wxID_ANY, wxDefaultPosition, wxDefaultSize, wxAUI_NB_TOP|wxAUI_NB_SCROLL_BUTTONS);
		myBook->AddPage(new MyWin(this), "Test");
	}
};

class MyApp: public wxApp
{
public:
	virtual bool OnInit()
	{
		MyFrame *frame = new MyFrame(NULL);
		frame->Show(true);
		SetTopWindow(frame);
		return true;
	}
};
DECLARE_APP(MyApp);
IMPLEMENT_APP_CONSOLE(MyApp);
