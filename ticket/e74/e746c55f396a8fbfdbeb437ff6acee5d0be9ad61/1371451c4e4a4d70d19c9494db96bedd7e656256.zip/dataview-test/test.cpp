
#include <wx/wx.h>
#include <wx/dataview.h>

#include <list>

/****************************************************************************/
/* Resource class                                                           */
/****************************************************************************/

class Resource
{
public:
    Resource ()
    {
        int_value = rand ();
        string_value = "Some string";
    }

    Resource (const wxString& s, int i) : string_value (s), int_value (i) {}
    wxString string_value;
    int      int_value;
};


/****************************************************************************/
/* TestModel class                                                          */
/****************************************************************************/

class TestModel : public wxDataViewModel
{
public:
    TestModel ()
    {
        ResetCounters ();
    }

    int Compare (const wxDataViewItem& i1,
                 const wxDataViewItem& i2,
                 unsigned int column,
                 bool ascending) const
    {
        Resource* r1 = (Resource*) i1.GetID ();
        Resource* r2 = (Resource*) i2.GetID ();
        int ret;

        compare_count++;

        switch (column) {
            case 0:
                ret = r1->string_value.CmpNoCase (r2->string_value);
                break;

            case 1:
                ret = r1->int_value - r2->int_value;
                break;

            default:
                wxFAIL;
        }

        if (ascending)
            return ret;
        else
            return -ret;
    }

    bool HasDefaultCompare () const { return true; }
    virtual wxString GetColumnType (unsigned int col) const { return "string"; }
    virtual unsigned int GetColumnCount () const { return 2; }
    virtual unsigned int GetRowCount () const { return list.size (); }
    wxDataViewItem GetRoot () { return wxDataViewItem (NULL); }
    virtual wxDataViewItem GetParent (const wxDataViewItem& item) const { return wxDataViewItem (NULL); }
    virtual bool SetValue (const wxVariant&, const wxDataViewItem&, unsigned int) { return false; }
    
    virtual bool IsContainer (const wxDataViewItem& item) const
    {
        // Only the "invalid" item (root) has children
        return !item.IsOk ();
    }

    virtual void GetValue (wxVariant& var, const wxDataViewItem& item, unsigned int col) const
    {
        if (!item.IsOk ()) {
            var = wxEmptyString;
            return;
        }

        Resource* r = (Resource*) item.GetID ();

        if (r == NULL) {
            var = wxEmptyString;
            return;
        }

        switch (col) {
            case 0:
                var = r->string_value;
                break;

            case 1:
                var = wxString::Format ("%d", r->int_value);
                break;

            default:
                printf ("GetValue() for invalid column: %u\n", col);
                var = wxEmptyString;
                break;
        }
    }

    virtual unsigned int GetChildren (const wxDataViewItem& item, wxDataViewItemArray& array) const
    {
        for (std::list<Resource*>::const_iterator it = list.begin (); it != list.end (); it++)
            array.Add (wxDataViewItem (*it));
        return array.GetCount ();
    }

    virtual void Resort ()
    {
        resort_count++;
        wxDataViewModel::Resort ();
    }

    void ResetCounters ()
    {
        resort_count = 0;
        compare_count = 0;
    }

    void Add1 ()
    {
        Resource* r = new Resource ();
        list.push_back (r);
        ItemAdded (wxDataViewItem (NULL), wxDataViewItem (r));
    }
    
    void AddMultiple (int n)
    {
        wxDataViewItemArray a;

        for (int i = 0; i < n; i++) {
            Resource* r = new Resource ();
            list.push_back (r);
            a.Add (wxDataViewItem (r));
        }

        ItemsAdded (wxDataViewItem (NULL), a);
    }

    void ChangeOneValue ()
    {
        if (list.size () > 0) {
            Resource* r = list.front ();
            r->int_value = rand ();
            ValueChanged (wxDataViewItem (r), 1);
        }
    }
    
    void ChangeOneItem ()
    {
        if (list.size () > 0) {
            Resource* r = list.front ();
            r->int_value = rand ();
            r->string_value = r->string_value + ".";
            ItemChanged (wxDataViewItem (r));
        }
    }
    
    void ChangeAllItemsV1 ()
    {
        for (std::list<Resource*>::iterator it = list.begin (); it != list.end (); it++) {
            Resource* r = *it;
            r->int_value = rand ();
            r->string_value = r->string_value + "x";
            ItemChanged (wxDataViewItem (r));
        }
    }
    
    void ChangeAllItemsV2 ()
    {
        wxDataViewItemArray a;

        for (std::list<Resource*>::iterator it = list.begin (); it != list.end (); it++) {
            Resource* r = *it;
            r->int_value = rand ();
            r->string_value = r->string_value + "x";
            a.Add (wxDataViewItem (r));
        }

        ItemsChanged (a);
    }

    static int compare_count;
    static int resort_count;

private:
    std::list<Resource*> list;
};

int TestModel::compare_count = 0;
int TestModel::resort_count = 0;

/****************************************************************************/
/* MainFrame class                                                          */
/****************************************************************************/

class MainFrame : public wxFrame
{
public:
    MainFrame (wxWindow* parent, const wxString& title);
private:
    wxDataViewCtrl* CreateView ();

    void OnClearButton (wxCommandEvent&) { printf ("FIXME!\n"); }
    void UpdateCounters ();
    
    void OnResetButton (wxCommandEvent&) { model->ResetCounters (); }
    void OnAddSingle (wxCommandEvent&) { model->Add1 (); }
    void OnAdd10 (wxCommandEvent&) { model->AddMultiple (10); }
    void OnAdd1000 (wxCommandEvent&) { model->AddMultiple (1000); }
    void OnChangeOneValue (wxCommandEvent&) { model->ChangeOneValue (); }
    void OnChangeOneItem (wxCommandEvent&) { model->ChangeOneItem (); }
    void OnChangeAllItemsV1 (wxCommandEvent&) { model->ChangeAllItemsV1 (); }
    void OnChangeAllItemsV2 (wxCommandEvent&) { model->ChangeAllItemsV2 (); }
    void OnIdle (wxIdleEvent& ev) { UpdateCounters (); }

    wxBoxSizer* szr;
    TestModel* model;
    wxDataViewCtrl* view;

    wxStaticText* resort_count_label;
    wxStaticText* compare_count_label;
};

MainFrame::MainFrame (wxWindow* parent, const wxString& title)
    : wxFrame (parent, -1, title)
{
    wxBoxSizer* hszr;
    wxButton* btn;

    resort_count_label = new wxStaticText (this, -1, "Resort count:");
    compare_count_label = new wxStaticText (this, -1, "Compare count:");

    szr = new wxBoxSizer (wxVERTICAL);

    hszr = new wxBoxSizer (wxHORIZONTAL);
    hszr->Add (resort_count_label, 0, wxRIGHT, 64);
    hszr->Add (compare_count_label, 0);
    szr->Add (hszr, 0, wxLEFT | wxRIGHT | wxTOP, 12);

    view = CreateView ();
    szr->Add (view, 1, wxEXPAND | wxALL, 12);
    
    hszr = new wxBoxSizer (wxHORIZONTAL);
    
    btn = new wxButton (this, -1, "Reset counters");
    btn->Bind (wxEVT_COMMAND_BUTTON_CLICKED, &MainFrame::OnResetButton, this);
    hszr->Add (btn, 0, wxRIGHT, 12);
    
    btn = new wxButton (this, -1, "Clear");
    btn->Bind (wxEVT_COMMAND_BUTTON_CLICKED, &MainFrame::OnClearButton, this);
    hszr->Add (btn, 0, wxRIGHT, 12);
    
    szr->Add (hszr, 0, wxLEFT | wxRIGHT | wxBOTTOM, 12);

    hszr = new wxBoxSizer (wxHORIZONTAL);

    btn = new wxButton (this, -1, "Add 1");
    btn->Bind (wxEVT_COMMAND_BUTTON_CLICKED, &MainFrame::OnAddSingle, this);
    hszr->Add (btn, 0, wxRIGHT, 12);
    
    btn = new wxButton (this, -1, "Add 10");
    btn->Bind (wxEVT_COMMAND_BUTTON_CLICKED, &MainFrame::OnAdd10, this);
    hszr->Add (btn, 0, wxRIGHT, 12);
    
    btn = new wxButton (this, -1, "Add 1000");
    btn->Bind (wxEVT_COMMAND_BUTTON_CLICKED, &MainFrame::OnAdd1000, this);
    hszr->Add (btn, 0, wxRIGHT, 12);

    szr->Add (hszr, 0, wxLEFT | wxRIGHT | wxBOTTOM, 12);
    
    hszr = new wxBoxSizer (wxHORIZONTAL);

    btn = new wxButton (this, -1, "Change one value");
    btn->Bind (wxEVT_COMMAND_BUTTON_CLICKED, &MainFrame::OnChangeOneValue, this);
    hszr->Add (btn, 0, wxRIGHT, 12);
    
    btn = new wxButton (this, -1, "Change one item");
    btn->Bind (wxEVT_COMMAND_BUTTON_CLICKED, &MainFrame::OnChangeOneItem, this);
    hszr->Add (btn, 0, wxRIGHT, 12);
    
    btn = new wxButton (this, -1, "Change all items (V1)");
    btn->Bind (wxEVT_COMMAND_BUTTON_CLICKED, &MainFrame::OnChangeAllItemsV1, this);
    hszr->Add (btn, 0, wxRIGHT, 12);
    
    btn = new wxButton (this, -1, "Change all items (V2)");
    btn->Bind (wxEVT_COMMAND_BUTTON_CLICKED, &MainFrame::OnChangeAllItemsV2, this);
    hszr->Add (btn, 0, wxRIGHT, 12);

    szr->Add (hszr, 0, wxLEFT | wxRIGHT | wxBOTTOM, 12);

    SetSizerAndFit (szr);

    Bind (wxEVT_IDLE, &MainFrame::OnIdle, this);
}

wxDataViewCtrl* MainFrame::CreateView ()
{
    wxDataViewRenderer *r;
    wxDataViewColumn *col;

    wxDataViewCtrl* ctrl = new wxDataViewCtrl (this, -1);

    ctrl->ClearColumns ();

    r = new wxDataViewTextRenderer ("string", wxDATAVIEW_CELL_INERT);
    col = new wxDataViewColumn ("String value", r, 0, wxDVC_DEFAULT_WIDTH, wxALIGN_LEFT,
                                wxDATAVIEW_COL_SORTABLE | wxDATAVIEW_COL_RESIZABLE);
    ctrl->AppendColumn (col);
    
    r = new wxDataViewTextRenderer ("string", wxDATAVIEW_CELL_INERT);
    col = new wxDataViewColumn ("Integer value", r, 1, wxDVC_DEFAULT_WIDTH, wxALIGN_LEFT,
                                wxDATAVIEW_COL_SORTABLE | wxDATAVIEW_COL_RESIZABLE);
    ctrl->AppendColumn (col);

    model = new TestModel ();
    ctrl->AssociateModel (model);
    ctrl->Expand (model->GetRoot ());
    ctrl->SetIndent (0);

    return ctrl;
}

void MainFrame::UpdateCounters ()
{
    resort_count_label->SetLabel (wxString::Format ("Resort count: %d", model->resort_count));
    compare_count_label->SetLabel (wxString::Format ("Compare count: %d", model->compare_count));
}


/****************************************************************************/
/* Application class                                                        */
/****************************************************************************/

class TestApp : public wxApp
{
public:
    bool OnInit ();
private:
    MainFrame* frm;
};

DECLARE_APP(TestApp);

bool TestApp::OnInit ()
{
    frm = new MainFrame (NULL, "wxDataView test");
    frm->Show ();
    return true;
}

IMPLEMENT_APP(TestApp)

