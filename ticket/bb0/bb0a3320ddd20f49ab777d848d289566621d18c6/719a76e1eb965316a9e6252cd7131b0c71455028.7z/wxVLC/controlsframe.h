#ifndef CONTROLSFRAME_H
#define CONTROLSFRAME_H

#ifndef WX_PRECOMP
//(*HeadersPCH(wxControlsFrame)
#include <wx/frame.h>
#include <wx/panel.h>
//*)
#endif
//(*Headers(wxControlsFrame)
//*)

#include <wx/popupwin.h>

class wxControlsPanel;

class wxControlsFrame: public wxFrame
{
public:
    wxControlsFrame(wxWindow* parent);
    virtual ~wxControlsFrame();

private:
    //(*Declarations(wxControlsFrame)
    wxControlsPanel* Controls_Pnl;
    //*)

protected:
    //(*Identifiers(wxControlsFrame)
    static const long ID_PNL_CONTROLS;
    //*)

private:
    //(*Handlers(wxControlsFrame)
    void OnSize(wxSizeEvent& event);
    //*)

private:
    friend class wxVLCFrame;

    DECLARE_EVENT_TABLE()
};

#endif
