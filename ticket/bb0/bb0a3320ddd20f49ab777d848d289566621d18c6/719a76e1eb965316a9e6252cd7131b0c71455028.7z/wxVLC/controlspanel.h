#ifndef CONTROLSPANEL_H
#define CONTROLSPANEL_H

#ifndef WX_PRECOMP
//(*HeadersPCH(wxControlsPanel)
#include <wx/button.h>
#include <wx/panel.h>
#include <wx/sizer.h>
#include <wx/slider.h>
#include <wx/stattext.h>
//*)
#endif
//(*Headers(wxControlsPanel)
//*)

class wxVLCFrame;

class wxControlsPanel: public wxPanel
{
public:

    wxControlsPanel(wxWindow* parent,wxWindowID id = wxID_ANY,
                    const wxPoint& pos = wxDefaultPosition,
                    const wxSize& size = wxDefaultSize,
                    long style = wxTAB_TRAVERSAL | wxNO_BORDER,
                    const wxString& name = _T("ControlsPanel"));
    virtual ~wxControlsPanel();

private:

    //(*Declarations(wxControlsPanel)
    wxBoxSizer* BoxSizer1;
    wxBoxSizer* BoxSizer2;
    wxButton* Backward_Btn;
    wxButton* Forward_Btn;
    wxButton* Play_Pause_Btn;
    wxButton* Stop_Btn;
    wxSlider* Timeline_Sldr;
    wxSlider* Volume_Sldr;
    wxStaticText* CurrTime_SttcTxt;
    wxStaticText* MovieLength_SttcTxt;
    wxStaticText* StaticText1;
    //*)

protected:

    //(*Identifiers(wxControlsPanel)
    static const long ID_STTCTXT_CURRTIME;
    static const long ID_SLDR_TIMELINE;
    static const long ID_STTCTXT_MOVIELENGTH;
    static const long ID_BTN_PLAYPAUSE;
    static const long ID_BTN_STOP;
    static const long ID_BTN_BACKWARD;
    static const long ID_BTN_FORWARD;
    static const long ID_STATICTEXT1;
    static const long ID_SLDR_VOLUME;
    //*)

private:

    //(*Handlers(wxControlsPanel)
    void OnTimelineChanged(wxScrollEvent& event);
    void OnPlay_Pause(wxCommandEvent& event);
    void OnStop(wxCommandEvent& event);
    void OnBackward(wxCommandEvent& event);
    void OnForward(wxCommandEvent& event);
    void OnVolumeChanged(wxScrollEvent& event);
    //*)

private:
    wxVLCFrame* m_mainFrame;

private:
    friend class wxVLCFrame;
    friend class wxControlsFrame;

    DECLARE_EVENT_TABLE()
};

#endif
