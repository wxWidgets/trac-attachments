/***************************************************************
 * Name:      wxVLCMain.h
 * Purpose:   Defines Application Frame
 * Author:    Tomay (tomay3000@gmail.com)
 * Created:   2018-05-23
 * Copyright: Tomay ()
 * License:
 **************************************************************/

#ifndef WXVLCMAIN_H
#define WXVLCMAIN_H

#include <vlc/vlc.h>
#include "imagepanel.h"

//(*Headers(wxVLCFrame)
//#include "wx/wxImagePanel.h"
#include <wx/filedlg.h>
#include <wx/frame.h>
#include <wx/menu.h>
#include <wx/panel.h>
#include <wx/sizer.h>
#include <wx/statline.h>
#include <wx/statusbr.h>
#include <wx/timer.h>
//*)

class wxControlsPanel;
class wxControlsFrame;

class wxVLCFrame: public wxFrame
{
public:

    wxVLCFrame(wxWindow* parent,wxWindowID id = -1);
    virtual ~wxVLCFrame();

private:

    //(*Handlers(wxVLCFrame)
    void OnQuit(wxCommandEvent& event);
    void OnAbout(wxCommandEvent& event);
    void OnOpen(wxCommandEvent& event);
    void OnToggleFullscreen(wxMouseEvent& event);
    void OnMouseMove(wxMouseEvent& event);
    void OnTimer1(wxTimerEvent& event);
    //*)

    //(*Identifiers(wxVLCFrame)
    static const long ID_PNL_PLAYER;
    static const long ID_STATICLINE1;
    static const long ID_PNL_CONTROLS;
    static const long ID_MENUITEM1;
    static const long idMenuQuit;
    static const long idMenuAbout;
    static const long ID_STATUSBAR1;
    static const long ID_TIMER1;
    //*)

    //(*Declarations(wxVLCFrame)
    wxBoxSizer* BoxSizer1;
    wxControlsPanel* Controls_Pnl;
    wxFileDialog* OpenFile_Dlg;
    wxImagePanel* Player_Pnl;
    wxMenuItem* MenuItem3;
    wxStaticLine* StaticLine1;
    wxStatusBar* StatusBar1;
    wxTimer Timer1;
    //*)

private:
    wxControlsFrame *Controls_Frm;

private:
    void InitVLC();

public:
    void Play();
    void Pause();
    void Stop();
    void OnPositionChanged();
    void OnAudioVolumeChanged();

private:
    libvlc_media_player_t *media_player;
    libvlc_instance_t *vlc_inst;
    libvlc_event_manager_t *vlc_evt_man;

private:
    friend class wxControlsPanel;

    DECLARE_EVENT_TABLE()
};

void OnPositionChanged_VLC(const libvlc_event_t *event, void *data);
void OnEndReached_VLC(const libvlc_event_t *event, void *data);
void OnAudioVolumeChanged_VLC(const libvlc_event_t *event, void *data);

#endif // WXVLCMAIN_H
