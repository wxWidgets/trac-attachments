#include "wx_pch.h"
#include "controlsframe.h"
#include "controlspanel.h"

#ifndef WX_PRECOMP
//(*InternalHeadersPCH(wxControlsFrame)
#include <wx/string.h>
#include <wx/intl.h>
//*)
#endif
//(*InternalHeaders(wxControlsFrame)
//*)

//(*IdInit(wxControlsFrame)
const long wxControlsFrame::ID_PNL_CONTROLS = wxNewId();
//*)

BEGIN_EVENT_TABLE(wxControlsFrame, wxFrame)
    //(*EventTable(wxControlsFrame)
    //*)
END_EVENT_TABLE()

wxControlsFrame::wxControlsFrame(wxWindow* parent)
{
    //(*Initialize(wxControlsFrame)
    Create(parent, wxID_ANY, wxEmptyString, wxDefaultPosition, wxDefaultSize, wxSTAY_ON_TOP|wxFRAME_NO_TASKBAR|wxFRAME_TOOL_WINDOW|wxFRAME_FLOAT_ON_PARENT|wxNO_BORDER, _T("wxID_ANY"));
    Controls_Pnl = new wxControlsPanel(this, ID_PNL_CONTROLS, wxDefaultPosition, wxDefaultSize, wxTAB_TRAVERSAL, _T("ID_PNL_CONTROLS"));

    Connect(wxEVT_SIZE,(wxObjectEventFunction)&wxControlsFrame::OnSize);
    //*)

    Fit();
}

wxControlsFrame::~wxControlsFrame()
{
    //(*Destroy(wxControlsFrame)
    //*)
}

void wxControlsFrame::OnSize(wxSizeEvent& event)
{
    FitInside();
    int w = 0, h = 0;
    GetVirtualSize(&w, &h);
    Controls_Pnl->SetSize(w, h);
}
