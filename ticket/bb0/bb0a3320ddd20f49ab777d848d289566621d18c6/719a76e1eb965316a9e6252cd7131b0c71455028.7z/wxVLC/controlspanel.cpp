#include "wx_pch.h"
#include "controlspanel.h"
#include "wxVLCApp.h"
#include "wxVLCMain.h"

#ifndef WX_PRECOMP
//(*InternalHeadersPCH(wxControlsPanel)
#include <wx/string.h>
#include <wx/intl.h>
//*)
#endif
//(*InternalHeaders(wxControlsPanel)
//*)

//(*IdInit(wxControlsPanel)
const long wxControlsPanel::ID_STTCTXT_CURRTIME = wxNewId();
const long wxControlsPanel::ID_SLDR_TIMELINE = wxNewId();
const long wxControlsPanel::ID_STTCTXT_MOVIELENGTH = wxNewId();
const long wxControlsPanel::ID_BTN_PLAYPAUSE = wxNewId();
const long wxControlsPanel::ID_BTN_STOP = wxNewId();
const long wxControlsPanel::ID_BTN_BACKWARD = wxNewId();
const long wxControlsPanel::ID_BTN_FORWARD = wxNewId();
const long wxControlsPanel::ID_STATICTEXT1 = wxNewId();
const long wxControlsPanel::ID_SLDR_VOLUME = wxNewId();
//*)

BEGIN_EVENT_TABLE(wxControlsPanel,wxPanel)
    //(*EventTable(wxControlsPanel)
    //*)
END_EVENT_TABLE()

wxControlsPanel::wxControlsPanel(wxWindow* parent,wxWindowID id,const wxPoint& pos,const wxSize& size, long style, const wxString& name)
{
    //(*Initialize(wxControlsPanel)
    wxBoxSizer* BoxSizer3;

    Create(parent, id, wxDefaultPosition, wxDefaultSize, wxTAB_TRAVERSAL, _T("id"));
    BoxSizer1 = new wxBoxSizer(wxVERTICAL);
    BoxSizer2 = new wxBoxSizer(wxHORIZONTAL);
    CurrTime_SttcTxt = new wxStaticText(this, ID_STTCTXT_CURRTIME, _("00:00:00"), wxDefaultPosition, wxDefaultSize, 0, _T("ID_STTCTXT_CURRTIME"));
    BoxSizer2->Add(CurrTime_SttcTxt, 0, wxALL|wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL, 5);
    Timeline_Sldr = new wxSlider(this, ID_SLDR_TIMELINE, 0, 0, 10000, wxDefaultPosition, wxDefaultSize, wxSL_BOTH|wxSL_SELRANGE, wxDefaultValidator, _T("ID_SLDR_TIMELINE"));
    Timeline_Sldr->Disable();
    BoxSizer2->Add(Timeline_Sldr, 1, wxALL|wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL, 5);
    MovieLength_SttcTxt = new wxStaticText(this, ID_STTCTXT_MOVIELENGTH, _("00:00:00"), wxDefaultPosition, wxDefaultSize, 0, _T("ID_STTCTXT_MOVIELENGTH"));
    BoxSizer2->Add(MovieLength_SttcTxt, 0, wxALL|wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL, 5);
    BoxSizer1->Add(BoxSizer2, 0, wxALL|wxEXPAND, 5);
    BoxSizer3 = new wxBoxSizer(wxHORIZONTAL);
    Play_Pause_Btn = new wxButton(this, ID_BTN_PLAYPAUSE, _("Play >"), wxDefaultPosition, wxDefaultSize, 0, wxDefaultValidator, _T("ID_BTN_PLAYPAUSE"));
    Play_Pause_Btn->Disable();
    BoxSizer3->Add(Play_Pause_Btn, 0, wxALL|wxEXPAND, 5);
    Stop_Btn = new wxButton(this, ID_BTN_STOP, _("Stop []"), wxDefaultPosition, wxDefaultSize, 0, wxDefaultValidator, _T("ID_BTN_STOP"));
    Stop_Btn->Disable();
    BoxSizer3->Add(Stop_Btn, 0, wxALL|wxEXPAND, 5);
    Backward_Btn = new wxButton(this, ID_BTN_BACKWARD, _("Backward <<"), wxDefaultPosition, wxDefaultSize, 0, wxDefaultValidator, _T("ID_BTN_BACKWARD"));
    Backward_Btn->Disable();
    BoxSizer3->Add(Backward_Btn, 0, wxALL|wxEXPAND, 5);
    Forward_Btn = new wxButton(this, ID_BTN_FORWARD, _("Forward >>"), wxDefaultPosition, wxDefaultSize, 0, wxDefaultValidator, _T("ID_BTN_FORWARD"));
    Forward_Btn->Disable();
    BoxSizer3->Add(Forward_Btn, 0, wxALL|wxEXPAND, 5);
    BoxSizer3->Add(-1,-1,1, wxALL|wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL, 5);
    StaticText1 = new wxStaticText(this, ID_STATICTEXT1, _("Volume"), wxDefaultPosition, wxDefaultSize, 0, _T("ID_STATICTEXT1"));
    BoxSizer3->Add(StaticText1, 0, wxALL|wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL, 5);
    Volume_Sldr = new wxSlider(this, ID_SLDR_VOLUME, 100, 0, 100, wxDefaultPosition, wxSize(100,-1), wxSL_LABELS|wxSL_BOTH, wxDefaultValidator, _T("ID_SLDR_VOLUME"));
    Volume_Sldr->Disable();
    BoxSizer3->Add(Volume_Sldr, 0, wxALL|wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL, 5);
    BoxSizer1->Add(BoxSizer3, 0, wxALL|wxEXPAND, 5);
    SetSizer(BoxSizer1);
    BoxSizer1->Fit(this);
    BoxSizer1->SetSizeHints(this);

    Connect(ID_SLDR_TIMELINE,wxEVT_SCROLL_THUMBTRACK,(wxObjectEventFunction)&wxControlsPanel::OnTimelineChanged);
    Connect(ID_SLDR_TIMELINE,wxEVT_COMMAND_SLIDER_UPDATED,(wxObjectEventFunction)&wxControlsPanel::OnTimelineChanged);
    Connect(ID_BTN_PLAYPAUSE,wxEVT_COMMAND_BUTTON_CLICKED,(wxObjectEventFunction)&wxControlsPanel::OnPlay_Pause);
    Connect(ID_BTN_STOP,wxEVT_COMMAND_BUTTON_CLICKED,(wxObjectEventFunction)&wxControlsPanel::OnStop);
    Connect(ID_BTN_BACKWARD,wxEVT_COMMAND_BUTTON_CLICKED,(wxObjectEventFunction)&wxControlsPanel::OnBackward);
    Connect(ID_BTN_FORWARD,wxEVT_COMMAND_BUTTON_CLICKED,(wxObjectEventFunction)&wxControlsPanel::OnForward);
    Connect(ID_SLDR_VOLUME,wxEVT_SCROLL_THUMBTRACK,(wxObjectEventFunction)&wxControlsPanel::OnVolumeChanged);
    Connect(ID_SLDR_VOLUME,wxEVT_COMMAND_SLIDER_UPDATED,(wxObjectEventFunction)&wxControlsPanel::OnVolumeChanged);
    //*)

    m_mainFrame = ((wxVLCFrame *)wxGetApp().GetTopWindow());
}

wxControlsPanel::~wxControlsPanel()
{
    //(*Destroy(wxControlsPanel)
    //*)
}


void wxControlsPanel::OnTimelineChanged(wxScrollEvent& event)
{
    //libvlc_media_player_set_position(m_mainFrame->media_player, (float)Timeline_Sldr->GetValue() / (float)Timeline_Sldr->GetMax());
    libvlc_media_player_set_time(m_mainFrame->media_player, Timeline_Sldr->GetValue() * 1000);
    libvlc_time_t currTime = libvlc_media_player_get_time(m_mainFrame->media_player);
    CurrTime_SttcTxt->SetLabel(wxTimeSpan::Milliseconds(currTime).Format());
    BoxSizer2->Layout();
    //event.Skip();
}

void wxControlsPanel::OnPlay_Pause(wxCommandEvent& event)
{
    if (libvlc_media_player_is_playing(m_mainFrame->media_player))
        m_mainFrame->Pause();
    else
        m_mainFrame->Play();
}

void wxControlsPanel::OnStop(wxCommandEvent& event)
{
    m_mainFrame->Stop();
}

void wxControlsPanel::OnBackward(wxCommandEvent& event)
{
    //float fpos = libvlc_media_player_get_position(m_mainFrame->media_player);
    libvlc_time_t currTime = libvlc_media_player_get_time(m_mainFrame->media_player);

    //fpos -= .05;
    currTime -= 60000;

    //if (fpos < 0) fpos = 0;
    if (currTime < 0)
        currTime = 0;

    //libvlc_media_player_set_position(m_mainFrame->media_player, fpos);
    libvlc_media_player_set_time(m_mainFrame->media_player, currTime);
    m_mainFrame->OnPositionChanged();
}

void wxControlsPanel::OnForward(wxCommandEvent& event)
{
    //float fpos = libvlc_media_player_get_position(m_mainFrame->media_player);
    libvlc_time_t currTime = libvlc_media_player_get_time(m_mainFrame->media_player);
    libvlc_time_t movieLength = libvlc_media_player_get_length(m_mainFrame->media_player);

    //fpos += .05;
    currTime += 60000;

    //if (fpos > 1) fpos = 1;
    if (currTime > movieLength)
        currTime = movieLength - 1;

    //libvlc_media_player_set_position(m_mainFrame->media_player, fpos);
    libvlc_media_player_set_time(m_mainFrame->media_player, currTime);
    m_mainFrame->OnPositionChanged();
}

void wxControlsPanel::OnVolumeChanged(wxScrollEvent& event)
{
    libvlc_audio_set_volume(m_mainFrame->media_player, Volume_Sldr->GetValue());
    //event.Skip();
}
