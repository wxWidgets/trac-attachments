/////////////////////////////////////////////////////////////////////////////
// Name:        testdialog.cpp
// Purpose:     
// Author:      
// Modified by: 
// Created:     5/3/2008 1:36:06 AM
// RCS-ID:      
// Copyright:   
// Licence:     
/////////////////////////////////////////////////////////////////////////////

// For compilers that support precompilation, includes "wx/wx.h".
#include "wx/wxprec.h"

#ifdef __BORLANDC__
#pragma hdrstop
#endif

#ifndef WX_PRECOMP
#include "wx/wx.h"
#endif

////@begin includes
////@end includes

#include "testdialog.h"

////@begin XPM images
////@end XPM images


/*!
 * TestDialog type definition
 */

IMPLEMENT_DYNAMIC_CLASS( TestDialog, wxDialog )


/*!
 * TestDialog event table definition
 */

BEGIN_EVENT_TABLE( TestDialog, wxDialog )

////@begin TestDialog event table entries
////@end TestDialog event table entries

END_EVENT_TABLE()


/*!
 * TestDialog constructors
 */

TestDialog::TestDialog()
{
    Init();
}

TestDialog::TestDialog( wxWindow* parent, wxWindowID id, const wxString& caption, const wxPoint& pos, const wxSize& size, long style )
{
    Init();
    Create(parent, id, caption, pos, size, style);
}


/*!
 * TestDialog creator
 */

bool TestDialog::Create( wxWindow* parent, wxWindowID id, const wxString& caption, const wxPoint& pos, const wxSize& size, long style )
{
////@begin TestDialog creation
    SetExtraStyle(wxWS_EX_BLOCK_EVENTS);
    wxDialog::Create( parent, id, caption, pos, size, style );

    CreateControls();
    if (GetSizer())
    {
        GetSizer()->SetSizeHints(this);
    }
    Centre();
////@end TestDialog creation
    return true;
}


/*!
 * TestDialog destructor
 */

TestDialog::~TestDialog()
{
////@begin TestDialog destruction
////@end TestDialog destruction
}


/*!
 * Member initialisation
 */

void TestDialog::Init()
{
////@begin TestDialog member initialisation
////@end TestDialog member initialisation
}


/*!
 * Control creation for TestDialog
 */

void TestDialog::CreateControls()
{    
////@begin TestDialog content construction
    TestDialog* itemDialog1 = this;

    wxBoxSizer* itemBoxSizer2 = new wxBoxSizer(wxVERTICAL);
    itemDialog1->SetSizer(itemBoxSizer2);

    wxNotebook* itemNotebook3 = new wxNotebook( itemDialog1, ID_NOTEBOOK1, wxDefaultPosition, wxDefaultSize, wxBK_DEFAULT );

    wxPanel* itemPanel4 = new wxPanel( itemNotebook3, ID_PANEL1, wxDefaultPosition, wxDefaultSize, wxSUNKEN_BORDER|wxTAB_TRAVERSAL );
    wxBoxSizer* itemBoxSizer5 = new wxBoxSizer(wxVERTICAL);
    itemPanel4->SetSizer(itemBoxSizer5);

    wxCollapsiblePane* itemCollapsiblePane6 = new wxCollapsiblePane( itemPanel4, ID_COLLAPSIBLEPANE1, _("Label"), wxDefaultPosition, wxDefaultSize, wxCP_DEFAULT_STYLE );
    itemBoxSizer5->Add(itemCollapsiblePane6, 0, wxALIGN_CENTER_HORIZONTAL|wxALL, 5);

    wxCollapsiblePane* itemCollapsiblePane7 = new wxCollapsiblePane( itemPanel4, ID_COLLAPSIBLEPANE2, _("Label"), wxDefaultPosition, wxDefaultSize, wxCP_DEFAULT_STYLE );
    itemBoxSizer5->Add(itemCollapsiblePane7, 0, wxALIGN_CENTER_HORIZONTAL|wxALL, 5);

    itemNotebook3->AddPage(itemPanel4, _("Tab"));

    wxPanel* itemPanel8 = new wxPanel( itemNotebook3, ID_PANEL2, wxDefaultPosition, wxDefaultSize, wxSUNKEN_BORDER|wxTAB_TRAVERSAL );
    wxBoxSizer* itemBoxSizer9 = new wxBoxSizer(wxVERTICAL);
    itemPanel8->SetSizer(itemBoxSizer9);

    wxCollapsiblePane* itemCollapsiblePane10 = new wxCollapsiblePane( itemPanel8, ID_COLLAPSIBLEPANE3, _("Label"), wxDefaultPosition, wxDefaultSize, wxCP_DEFAULT_STYLE );
    itemBoxSizer9->Add(itemCollapsiblePane10, 0, wxALIGN_CENTER_HORIZONTAL|wxALL, 5);

    wxCollapsiblePane* itemCollapsiblePane11 = new wxCollapsiblePane( itemPanel8, ID_COLLAPSIBLEPANE4, _("Label"), wxDefaultPosition, wxDefaultSize, wxCP_DEFAULT_STYLE );
    itemBoxSizer9->Add(itemCollapsiblePane11, 0, wxALIGN_CENTER_HORIZONTAL|wxALL, 5);

    itemNotebook3->AddPage(itemPanel8, _("Tab"));

    itemBoxSizer2->Add(itemNotebook3, 0, wxALIGN_CENTER_HORIZONTAL|wxALL, 5);

////@end TestDialog content construction
}


/*!
 * Should we show tooltips?
 */

bool TestDialog::ShowToolTips()
{
    return true;
}

/*!
 * Get bitmap resources
 */

wxBitmap TestDialog::GetBitmapResource( const wxString& name )
{
    // Bitmap retrieval
////@begin TestDialog bitmap retrieval
    wxUnusedVar(name);
    return wxNullBitmap;
////@end TestDialog bitmap retrieval
}

/*!
 * Get icon resources
 */

wxIcon TestDialog::GetIconResource( const wxString& name )
{
    // Icon retrieval
////@begin TestDialog icon retrieval
    wxUnusedVar(name);
    return wxNullIcon;
////@end TestDialog icon retrieval
}
