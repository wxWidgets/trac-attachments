/////////////////////////////////////////////////////////////////////////////
// Name:        testdialog.h
// Purpose:     
// Author:      
// Modified by: 
// Created:     5/3/2008 1:36:06 AM
// RCS-ID:      
// Copyright:   
// Licence:     
/////////////////////////////////////////////////////////////////////////////

#ifndef _TESTDIALOG_H_
#define _TESTDIALOG_H_


/*!
 * Includes
 */

////@begin includes
#include "wx/notebook.h"
#include "wx/collpane.h"
////@end includes

/*!
 * Forward declarations
 */

////@begin forward declarations
////@end forward declarations

/*!
 * Control identifiers
 */

////@begin control identifiers
#define ID_TESTDIALOG 10000
#define ID_NOTEBOOK1 10001
#define ID_PANEL1 10002
#define ID_COLLAPSIBLEPANE1 10004
#define ID_COLLAPSIBLEPANE2 10005
#define ID_PANEL2 10003
#define ID_COLLAPSIBLEPANE3 10006
#define ID_COLLAPSIBLEPANE4 10007
#define SYMBOL_TESTDIALOG_STYLE wxCAPTION|wxRESIZE_BORDER|wxSYSTEM_MENU|wxCLOSE_BOX|wxTAB_TRAVERSAL
#define SYMBOL_TESTDIALOG_TITLE _("TestDialog")
#define SYMBOL_TESTDIALOG_IDNAME ID_TESTDIALOG
#define SYMBOL_TESTDIALOG_SIZE wxSize(400, 300)
#define SYMBOL_TESTDIALOG_POSITION wxDefaultPosition
////@end control identifiers


/*!
 * TestDialog class declaration
 */

class TestDialog: public wxDialog
{    
    DECLARE_DYNAMIC_CLASS( TestDialog )
    DECLARE_EVENT_TABLE()

public:
    /// Constructors
    TestDialog();
    TestDialog( wxWindow* parent, wxWindowID id = SYMBOL_TESTDIALOG_IDNAME, const wxString& caption = SYMBOL_TESTDIALOG_TITLE, const wxPoint& pos = SYMBOL_TESTDIALOG_POSITION, const wxSize& size = SYMBOL_TESTDIALOG_SIZE, long style = SYMBOL_TESTDIALOG_STYLE );

    /// Creation
    bool Create( wxWindow* parent, wxWindowID id = SYMBOL_TESTDIALOG_IDNAME, const wxString& caption = SYMBOL_TESTDIALOG_TITLE, const wxPoint& pos = SYMBOL_TESTDIALOG_POSITION, const wxSize& size = SYMBOL_TESTDIALOG_SIZE, long style = SYMBOL_TESTDIALOG_STYLE );

    /// Destructor
    ~TestDialog();

    /// Initialises member variables
    void Init();

    /// Creates the controls and sizers
    void CreateControls();

////@begin TestDialog event handler declarations

////@end TestDialog event handler declarations

////@begin TestDialog member function declarations

    /// Retrieves bitmap resources
    wxBitmap GetBitmapResource( const wxString& name );

    /// Retrieves icon resources
    wxIcon GetIconResource( const wxString& name );
////@end TestDialog member function declarations

    /// Should we show tooltips?
    static bool ShowToolTips();

////@begin TestDialog member variables
////@end TestDialog member variables
};

#endif
    // _TESTDIALOG_H_
