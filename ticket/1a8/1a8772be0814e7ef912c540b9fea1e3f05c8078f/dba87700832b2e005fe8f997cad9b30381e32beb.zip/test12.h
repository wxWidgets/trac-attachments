/////////////////////////////////////////////////////////////////////////////
// Name:        test12.h
// Purpose:     
// Author:      
// Modified by: 
// Created:     4/13/2008 11:58:35 PM
// RCS-ID:      
// Copyright:   
// Licence:     
/////////////////////////////////////////////////////////////////////////////

#ifndef _TEST12_H_
#define _TEST12_H_


/*!
 * Includes
 */

////@begin includes
#include "wx/notebook.h"
#include "wx/collpane.h"
#include "wx/bmpcbox.h"
////@end includes

/*!
 * Forward declarations
 */

////@begin forward declarations
////@end forward declarations

/*!
 * Control identifiers
 */

////@begin control identifiers
#define ID_TEST12 10000
#define ID_NOTEBOOK1 10001
#define ID_PANEL1 10002
#define ID_COLLAPSIBLEPANE1 10003
#define ID_BITMAPCOMBOBOX1 10007
#define ID_BUTTON1 10008
#define ID_BUTTON2 10009
#define ID_BUTTON3 10010
#define ID_BUTTON4 10011
#define ID_BUTTON5 10012
#define ID_BUTTON6 10013
#define ID_BUTTON7 10014
#define ID_BUTTON8 10015
#define ID_BUTTON9 10016
#define ID_BUTTON10 10017
#define ID_BUTTON11 10018
#define ID_BUTTON12 10019
#define ID_COLLAPSIBLEPANE2 10004
#define ID_CHECKBOX1 10020
#define ID_CHECKBOX2 10021
#define ID_CHECKBOX3 10022
#define ID_CHECKBOX4 10023
#define ID_CHECKBOX5 10024
#define ID_CHECKBOX6 10025
#define ID_CHECKBOX7 10026
#define ID_CHECKBOX8 10027
#define ID_COLLAPSIBLEPANE3 10005
#define ID_BUTTON13 10028
#define ID_COLLAPSIBLEPANE4 10006
#define ID_BUTTON14 10029
#define ID_BUTTON15 10030
#define ID_PANEL2 10031
#define ID_COLLAPSIBLEPANE 10032
#define ID_BITMAPCOMBOBOX 10033
#define ID_BUTTON 10034
#define ID_BUTTON16 10035
#define ID_BUTTON17 10036
#define ID_BUTTON18 10037
#define ID_BUTTON19 10038
#define ID_BUTTON20 10039
#define ID_BUTTON21 10040
#define ID_BUTTON22 10041
#define ID_BUTTON23 10042
#define ID_BUTTON24 10043
#define ID_BUTTON25 10044
#define ID_BUTTON26 10045
#define ID_COLLAPSIBLEPANE5 10046
#define ID_CHECKBOX 10047
#define ID_CHECKBOX9 10048
#define ID_CHECKBOX10 10049
#define ID_CHECKBOX11 10050
#define ID_CHECKBOX12 10051
#define ID_CHECKBOX13 10052
#define ID_CHECKBOX14 10053
#define ID_CHECKBOX15 10054
#define ID_COLLAPSIBLEPANE6 10055
#define ID_BUTTON27 10056
#define ID_COLLAPSIBLEPANE7 10057
#define ID_BUTTON28 10058
#define ID_BUTTON29 10059
#define SYMBOL_TEST12_STYLE wxCAPTION|wxRESIZE_BORDER|wxSYSTEM_MENU|wxCLOSE_BOX|wxTAB_TRAVERSAL
#define SYMBOL_TEST12_TITLE _("test12")
#define SYMBOL_TEST12_IDNAME ID_TEST12
#define SYMBOL_TEST12_SIZE wxSize(400, 300)
#define SYMBOL_TEST12_POSITION wxDefaultPosition
////@end control identifiers


/*!
 * test12 class declaration
 */

class test12: public wxDialog
{    
    DECLARE_DYNAMIC_CLASS( test12 )
    DECLARE_EVENT_TABLE()

public:
    /// Constructors
    test12();
    test12( wxWindow* parent, wxWindowID id = SYMBOL_TEST12_IDNAME, const wxString& caption = SYMBOL_TEST12_TITLE, const wxPoint& pos = SYMBOL_TEST12_POSITION, const wxSize& size = SYMBOL_TEST12_SIZE, long style = SYMBOL_TEST12_STYLE );

    /// Creation
    bool Create( wxWindow* parent, wxWindowID id = SYMBOL_TEST12_IDNAME, const wxString& caption = SYMBOL_TEST12_TITLE, const wxPoint& pos = SYMBOL_TEST12_POSITION, const wxSize& size = SYMBOL_TEST12_SIZE, long style = SYMBOL_TEST12_STYLE );

    /// Destructor
    ~test12();

    /// Initialises member variables
    void Init();

    /// Creates the controls and sizers
    void CreateControls();

////@begin test12 event handler declarations

////@end test12 event handler declarations

////@begin test12 member function declarations

    /// Retrieves bitmap resources
    wxBitmap GetBitmapResource( const wxString& name );

    /// Retrieves icon resources
    wxIcon GetIconResource( const wxString& name );
////@end test12 member function declarations

    /// Should we show tooltips?
    static bool ShowToolTips();

////@begin test12 member variables
////@end test12 member variables
};

#endif
    // _TEST12_H_
