/////////////////////////////////////////////////////////////////////////////
// Name:        test12.cpp
// Purpose:     
// Author:      
// Modified by: 
// Created:     4/13/2008 11:58:35 PM
// RCS-ID:      
// Copyright:   
// Licence:     
/////////////////////////////////////////////////////////////////////////////

// For compilers that support precompilation, includes "wx/wx.h".
#include "wx/wxprec.h"

#ifdef __BORLANDC__
#pragma hdrstop
#endif

#ifndef WX_PRECOMP
#include "wx/wx.h"
#endif

////@begin includes
////@end includes

#include "test12.h"

////@begin XPM images
////@end XPM images


/*!
 * test12 type definition
 */

IMPLEMENT_DYNAMIC_CLASS( test12, wxDialog )


/*!
 * test12 event table definition
 */

BEGIN_EVENT_TABLE( test12, wxDialog )

////@begin test12 event table entries
////@end test12 event table entries

END_EVENT_TABLE()


/*!
 * test12 constructors
 */

test12::test12()
{
    Init();
}

test12::test12( wxWindow* parent, wxWindowID id, const wxString& caption, const wxPoint& pos, const wxSize& size, long style )
{
    Init();
    Create(parent, id, caption, pos, size, style);
}


/*!
 * test12 creator
 */

bool test12::Create( wxWindow* parent, wxWindowID id, const wxString& caption, const wxPoint& pos, const wxSize& size, long style )
{
////@begin test12 creation
    SetExtraStyle(wxWS_EX_BLOCK_EVENTS);
    wxDialog::Create( parent, id, caption, pos, size, style );

    CreateControls();
    if (GetSizer())
    {
        GetSizer()->SetSizeHints(this);
    }
    Centre();
////@end test12 creation
    return true;
}


/*!
 * test12 destructor
 */

test12::~test12()
{
////@begin test12 destruction
////@end test12 destruction
}


/*!
 * Member initialisation
 */

void test12::Init()
{
////@begin test12 member initialisation
////@end test12 member initialisation
}


/*!
 * Control creation for test12
 */

void test12::CreateControls()
{    
////@begin test12 content construction
    test12* itemDialog1 = this;

    wxBoxSizer* itemBoxSizer2 = new wxBoxSizer(wxVERTICAL);
    itemDialog1->SetSizer(itemBoxSizer2);

    wxNotebook* itemNotebook3 = new wxNotebook( itemDialog1, ID_NOTEBOOK1, wxDefaultPosition, wxDefaultSize, wxBK_DEFAULT );

    wxPanel* itemPanel4 = new wxPanel( itemNotebook3, ID_PANEL1, wxDefaultPosition, wxDefaultSize, wxSUNKEN_BORDER|wxTAB_TRAVERSAL );
    wxBoxSizer* itemBoxSizer5 = new wxBoxSizer(wxVERTICAL);
    itemPanel4->SetSizer(itemBoxSizer5);

    wxStaticBox* itemStaticBoxSizer6Static = new wxStaticBox(itemPanel4, wxID_ANY, _("check12"));
    wxStaticBoxSizer* itemStaticBoxSizer6 = new wxStaticBoxSizer(itemStaticBoxSizer6Static, wxVERTICAL);
    itemBoxSizer5->Add(itemStaticBoxSizer6, 0, wxGROW|wxALL, 5);
    wxCollapsiblePane* itemCollapsiblePane7 = new wxCollapsiblePane( itemPanel4, ID_COLLAPSIBLEPANE1, _("Label"), wxDefaultPosition, wxDefaultSize, wxCP_DEFAULT_STYLE );
    itemStaticBoxSizer6->Add(itemCollapsiblePane7, 0, wxGROW|wxALL, 5);
    wxBoxSizer* itemBoxSizer8 = new wxBoxSizer(wxVERTICAL);
    itemCollapsiblePane7->GetPane()->SetSizer(itemBoxSizer8);

    wxArrayString itemBitmapComboBox9Strings;
    wxBitmapComboBox* itemBitmapComboBox9 = new wxBitmapComboBox( itemCollapsiblePane7->GetPane(), ID_BITMAPCOMBOBOX1, _T(""), wxDefaultPosition, wxDefaultSize, itemBitmapComboBox9Strings, 0 );
    itemBoxSizer8->Add(itemBitmapComboBox9, 0, wxALIGN_CENTER_HORIZONTAL|wxALL, 5);

    wxGridSizer* itemGridSizer10 = new wxGridSizer(2, 2, 0, 0);
    itemBoxSizer8->Add(itemGridSizer10, 0, wxALIGN_CENTER_HORIZONTAL|wxALL, 5);
    wxButton* itemButton11 = new wxButton( itemCollapsiblePane7->GetPane(), ID_BUTTON1, _("Button"), wxDefaultPosition, wxDefaultSize, 0 );
    itemGridSizer10->Add(itemButton11, 0, wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL|wxALL, 5);

    wxButton* itemButton12 = new wxButton( itemCollapsiblePane7->GetPane(), ID_BUTTON2, _("Button"), wxDefaultPosition, wxDefaultSize, 0 );
    itemGridSizer10->Add(itemButton12, 0, wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL|wxALL, 5);

    wxButton* itemButton13 = new wxButton( itemCollapsiblePane7->GetPane(), ID_BUTTON3, _("Button"), wxDefaultPosition, wxDefaultSize, 0 );
    itemGridSizer10->Add(itemButton13, 0, wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL|wxALL, 5);

    wxButton* itemButton14 = new wxButton( itemCollapsiblePane7->GetPane(), ID_BUTTON4, _("Button"), wxDefaultPosition, wxDefaultSize, 0 );
    itemGridSizer10->Add(itemButton14, 0, wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL|wxALL, 5);

    wxButton* itemButton15 = new wxButton( itemCollapsiblePane7->GetPane(), ID_BUTTON5, _("Button"), wxDefaultPosition, wxDefaultSize, 0 );
    itemGridSizer10->Add(itemButton15, 0, wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL|wxALL, 5);

    wxButton* itemButton16 = new wxButton( itemCollapsiblePane7->GetPane(), ID_BUTTON6, _("Button"), wxDefaultPosition, wxDefaultSize, 0 );
    itemGridSizer10->Add(itemButton16, 0, wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL|wxALL, 5);

    wxButton* itemButton17 = new wxButton( itemCollapsiblePane7->GetPane(), ID_BUTTON7, _("Button"), wxDefaultPosition, wxDefaultSize, 0 );
    itemGridSizer10->Add(itemButton17, 0, wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL|wxALL, 5);

    wxButton* itemButton18 = new wxButton( itemCollapsiblePane7->GetPane(), ID_BUTTON8, _("Button"), wxDefaultPosition, wxDefaultSize, 0 );
    itemGridSizer10->Add(itemButton18, 0, wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL|wxALL, 5);

    wxButton* itemButton19 = new wxButton( itemCollapsiblePane7->GetPane(), ID_BUTTON9, _("Button"), wxDefaultPosition, wxDefaultSize, 0 );
    itemGridSizer10->Add(itemButton19, 0, wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL|wxALL, 5);

    wxButton* itemButton20 = new wxButton( itemCollapsiblePane7->GetPane(), ID_BUTTON10, _("Button"), wxDefaultPosition, wxDefaultSize, 0 );
    itemGridSizer10->Add(itemButton20, 0, wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL|wxALL, 5);

    wxButton* itemButton21 = new wxButton( itemCollapsiblePane7->GetPane(), ID_BUTTON11, _("Button"), wxDefaultPosition, wxDefaultSize, 0 );
    itemGridSizer10->Add(itemButton21, 0, wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL|wxALL, 5);

    wxButton* itemButton22 = new wxButton( itemCollapsiblePane7->GetPane(), ID_BUTTON12, _("Button"), wxDefaultPosition, wxDefaultSize, 0 );
    itemGridSizer10->Add(itemButton22, 0, wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL|wxALL, 5);

    wxCollapsiblePane* itemCollapsiblePane23 = new wxCollapsiblePane( itemPanel4, ID_COLLAPSIBLEPANE2, _("Label"), wxDefaultPosition, wxDefaultSize, wxCP_DEFAULT_STYLE );
    itemStaticBoxSizer6->Add(itemCollapsiblePane23, 0, wxGROW|wxALL, 5);
    wxGridSizer* itemGridSizer24 = new wxGridSizer(2, 2, 0, 0);
    itemCollapsiblePane23->GetPane()->SetSizer(itemGridSizer24);

    wxCheckBox* itemCheckBox25 = new wxCheckBox( itemCollapsiblePane23->GetPane(), ID_CHECKBOX1, _("Checkbox"), wxDefaultPosition, wxDefaultSize, 0 );
    itemCheckBox25->SetValue(false);
    itemGridSizer24->Add(itemCheckBox25, 0, wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL|wxALL, 5);

    wxCheckBox* itemCheckBox26 = new wxCheckBox( itemCollapsiblePane23->GetPane(), ID_CHECKBOX2, _("Checkbox"), wxDefaultPosition, wxDefaultSize, 0 );
    itemCheckBox26->SetValue(false);
    itemGridSizer24->Add(itemCheckBox26, 0, wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL|wxALL, 5);

    wxCheckBox* itemCheckBox27 = new wxCheckBox( itemCollapsiblePane23->GetPane(), ID_CHECKBOX3, _("Checkbox"), wxDefaultPosition, wxDefaultSize, 0 );
    itemCheckBox27->SetValue(false);
    itemGridSizer24->Add(itemCheckBox27, 0, wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL|wxALL, 5);

    wxCheckBox* itemCheckBox28 = new wxCheckBox( itemCollapsiblePane23->GetPane(), ID_CHECKBOX4, _("Checkbox"), wxDefaultPosition, wxDefaultSize, 0 );
    itemCheckBox28->SetValue(false);
    itemGridSizer24->Add(itemCheckBox28, 0, wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL|wxALL, 5);

    wxCheckBox* itemCheckBox29 = new wxCheckBox( itemCollapsiblePane23->GetPane(), ID_CHECKBOX5, _("Checkbox"), wxDefaultPosition, wxDefaultSize, 0 );
    itemCheckBox29->SetValue(false);
    itemGridSizer24->Add(itemCheckBox29, 0, wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL|wxALL, 5);

    wxCheckBox* itemCheckBox30 = new wxCheckBox( itemCollapsiblePane23->GetPane(), ID_CHECKBOX6, _("Checkbox"), wxDefaultPosition, wxDefaultSize, 0 );
    itemCheckBox30->SetValue(false);
    itemGridSizer24->Add(itemCheckBox30, 0, wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL|wxALL, 5);

    wxCheckBox* itemCheckBox31 = new wxCheckBox( itemCollapsiblePane23->GetPane(), ID_CHECKBOX7, _("Checkbox"), wxDefaultPosition, wxDefaultSize, 0 );
    itemCheckBox31->SetValue(false);
    itemGridSizer24->Add(itemCheckBox31, 0, wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL|wxALL, 5);

    wxCheckBox* itemCheckBox32 = new wxCheckBox( itemCollapsiblePane23->GetPane(), ID_CHECKBOX8, _("Checkbox"), wxDefaultPosition, wxDefaultSize, 0 );
    itemCheckBox32->SetValue(false);
    itemGridSizer24->Add(itemCheckBox32, 0, wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL|wxALL, 5);

    wxCollapsiblePane* itemCollapsiblePane33 = new wxCollapsiblePane( itemPanel4, ID_COLLAPSIBLEPANE3, _("Label"), wxDefaultPosition, wxDefaultSize, wxCP_DEFAULT_STYLE );
    itemStaticBoxSizer6->Add(itemCollapsiblePane33, 0, wxGROW|wxALL, 5);
    wxButton* itemButton34 = new wxButton( itemCollapsiblePane33->GetPane(), ID_BUTTON13, _("Button"), wxDefaultPosition, wxDefaultSize, 0 );

    wxCollapsiblePane* itemCollapsiblePane35 = new wxCollapsiblePane( itemPanel4, ID_COLLAPSIBLEPANE4, _("Label"), wxDefaultPosition, wxDefaultSize, wxCP_DEFAULT_STYLE );
    itemStaticBoxSizer6->Add(itemCollapsiblePane35, 0, wxGROW|wxALL, 5);
    wxBoxSizer* itemBoxSizer36 = new wxBoxSizer(wxHORIZONTAL);
    itemCollapsiblePane35->GetPane()->SetSizer(itemBoxSizer36);

    wxButton* itemButton37 = new wxButton( itemCollapsiblePane35->GetPane(), ID_BUTTON14, _("Button"), wxDefaultPosition, wxDefaultSize, 0 );
    itemBoxSizer36->Add(itemButton37, 0, wxALIGN_CENTER_VERTICAL|wxALL, 5);

    wxButton* itemButton38 = new wxButton( itemCollapsiblePane35->GetPane(), ID_BUTTON15, _("Button"), wxDefaultPosition, wxDefaultSize, 0 );
    itemBoxSizer36->Add(itemButton38, 0, wxALIGN_CENTER_VERTICAL|wxALL, 5);

    itemNotebook3->AddPage(itemPanel4, _("Tab1"));

    wxPanel* itemPanel39 = new wxPanel( itemNotebook3, ID_PANEL2, wxDefaultPosition, wxDefaultSize, wxSUNKEN_BORDER|wxTAB_TRAVERSAL );
    wxBoxSizer* itemBoxSizer40 = new wxBoxSizer(wxVERTICAL);
    itemPanel39->SetSizer(itemBoxSizer40);

    wxStaticBox* itemStaticBoxSizer41Static = new wxStaticBox(itemPanel39, wxID_ANY, _("check12"));
    wxStaticBoxSizer* itemStaticBoxSizer41 = new wxStaticBoxSizer(itemStaticBoxSizer41Static, wxVERTICAL);
    itemBoxSizer40->Add(itemStaticBoxSizer41, 0, wxGROW|wxALL, 5);
    wxCollapsiblePane* itemCollapsiblePane42 = new wxCollapsiblePane( itemPanel39, ID_COLLAPSIBLEPANE, _("Label"), wxDefaultPosition, wxDefaultSize, wxCP_DEFAULT_STYLE );
    itemStaticBoxSizer41->Add(itemCollapsiblePane42, 0, wxGROW|wxALL, 5);
    wxBoxSizer* itemBoxSizer43 = new wxBoxSizer(wxVERTICAL);
    itemCollapsiblePane42->GetPane()->SetSizer(itemBoxSizer43);

    wxArrayString itemBitmapComboBox44Strings;
    wxBitmapComboBox* itemBitmapComboBox44 = new wxBitmapComboBox( itemCollapsiblePane42->GetPane(), ID_BITMAPCOMBOBOX, _T(""), wxDefaultPosition, wxDefaultSize, itemBitmapComboBox44Strings, 0 );
    itemBoxSizer43->Add(itemBitmapComboBox44, 0, wxALIGN_CENTER_HORIZONTAL|wxALL, 5);

    wxGridSizer* itemGridSizer45 = new wxGridSizer(2, 2, 0, 0);
    itemBoxSizer43->Add(itemGridSizer45, 0, wxALIGN_CENTER_HORIZONTAL|wxALL, 5);
    wxButton* itemButton46 = new wxButton( itemCollapsiblePane42->GetPane(), ID_BUTTON, _("Button"), wxDefaultPosition, wxDefaultSize, 0 );
    itemGridSizer45->Add(itemButton46, 0, wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL|wxALL, 5);

    wxButton* itemButton47 = new wxButton( itemCollapsiblePane42->GetPane(), ID_BUTTON16, _("Button"), wxDefaultPosition, wxDefaultSize, 0 );
    itemGridSizer45->Add(itemButton47, 0, wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL|wxALL, 5);

    wxButton* itemButton48 = new wxButton( itemCollapsiblePane42->GetPane(), ID_BUTTON17, _("Button"), wxDefaultPosition, wxDefaultSize, 0 );
    itemGridSizer45->Add(itemButton48, 0, wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL|wxALL, 5);

    wxButton* itemButton49 = new wxButton( itemCollapsiblePane42->GetPane(), ID_BUTTON18, _("Button"), wxDefaultPosition, wxDefaultSize, 0 );
    itemGridSizer45->Add(itemButton49, 0, wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL|wxALL, 5);

    wxButton* itemButton50 = new wxButton( itemCollapsiblePane42->GetPane(), ID_BUTTON19, _("Button"), wxDefaultPosition, wxDefaultSize, 0 );
    itemGridSizer45->Add(itemButton50, 0, wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL|wxALL, 5);

    wxButton* itemButton51 = new wxButton( itemCollapsiblePane42->GetPane(), ID_BUTTON20, _("Button"), wxDefaultPosition, wxDefaultSize, 0 );
    itemGridSizer45->Add(itemButton51, 0, wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL|wxALL, 5);

    wxButton* itemButton52 = new wxButton( itemCollapsiblePane42->GetPane(), ID_BUTTON21, _("Button"), wxDefaultPosition, wxDefaultSize, 0 );
    itemGridSizer45->Add(itemButton52, 0, wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL|wxALL, 5);

    wxButton* itemButton53 = new wxButton( itemCollapsiblePane42->GetPane(), ID_BUTTON22, _("Button"), wxDefaultPosition, wxDefaultSize, 0 );
    itemGridSizer45->Add(itemButton53, 0, wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL|wxALL, 5);

    wxButton* itemButton54 = new wxButton( itemCollapsiblePane42->GetPane(), ID_BUTTON23, _("Button"), wxDefaultPosition, wxDefaultSize, 0 );
    itemGridSizer45->Add(itemButton54, 0, wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL|wxALL, 5);

    wxButton* itemButton55 = new wxButton( itemCollapsiblePane42->GetPane(), ID_BUTTON24, _("Button"), wxDefaultPosition, wxDefaultSize, 0 );
    itemGridSizer45->Add(itemButton55, 0, wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL|wxALL, 5);

    wxButton* itemButton56 = new wxButton( itemCollapsiblePane42->GetPane(), ID_BUTTON25, _("Button"), wxDefaultPosition, wxDefaultSize, 0 );
    itemGridSizer45->Add(itemButton56, 0, wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL|wxALL, 5);

    wxButton* itemButton57 = new wxButton( itemCollapsiblePane42->GetPane(), ID_BUTTON26, _("Button"), wxDefaultPosition, wxDefaultSize, 0 );
    itemGridSizer45->Add(itemButton57, 0, wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL|wxALL, 5);

    wxCollapsiblePane* itemCollapsiblePane58 = new wxCollapsiblePane( itemPanel39, ID_COLLAPSIBLEPANE5, _("Label"), wxDefaultPosition, wxDefaultSize, wxCP_DEFAULT_STYLE );
    itemStaticBoxSizer41->Add(itemCollapsiblePane58, 0, wxGROW|wxALL, 5);
    wxGridSizer* itemGridSizer59 = new wxGridSizer(2, 2, 0, 0);
    itemCollapsiblePane58->GetPane()->SetSizer(itemGridSizer59);

    wxCheckBox* itemCheckBox60 = new wxCheckBox( itemCollapsiblePane58->GetPane(), ID_CHECKBOX, _("Checkbox"), wxDefaultPosition, wxDefaultSize, 0 );
    itemCheckBox60->SetValue(false);
    itemGridSizer59->Add(itemCheckBox60, 0, wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL|wxALL, 5);

    wxCheckBox* itemCheckBox61 = new wxCheckBox( itemCollapsiblePane58->GetPane(), ID_CHECKBOX9, _("Checkbox"), wxDefaultPosition, wxDefaultSize, 0 );
    itemCheckBox61->SetValue(false);
    itemGridSizer59->Add(itemCheckBox61, 0, wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL|wxALL, 5);

    wxCheckBox* itemCheckBox62 = new wxCheckBox( itemCollapsiblePane58->GetPane(), ID_CHECKBOX10, _("Checkbox"), wxDefaultPosition, wxDefaultSize, 0 );
    itemCheckBox62->SetValue(false);
    itemGridSizer59->Add(itemCheckBox62, 0, wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL|wxALL, 5);

    wxCheckBox* itemCheckBox63 = new wxCheckBox( itemCollapsiblePane58->GetPane(), ID_CHECKBOX11, _("Checkbox"), wxDefaultPosition, wxDefaultSize, 0 );
    itemCheckBox63->SetValue(false);
    itemGridSizer59->Add(itemCheckBox63, 0, wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL|wxALL, 5);

    wxCheckBox* itemCheckBox64 = new wxCheckBox( itemCollapsiblePane58->GetPane(), ID_CHECKBOX12, _("Checkbox"), wxDefaultPosition, wxDefaultSize, 0 );
    itemCheckBox64->SetValue(false);
    itemGridSizer59->Add(itemCheckBox64, 0, wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL|wxALL, 5);

    wxCheckBox* itemCheckBox65 = new wxCheckBox( itemCollapsiblePane58->GetPane(), ID_CHECKBOX13, _("Checkbox"), wxDefaultPosition, wxDefaultSize, 0 );
    itemCheckBox65->SetValue(false);
    itemGridSizer59->Add(itemCheckBox65, 0, wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL|wxALL, 5);

    wxCheckBox* itemCheckBox66 = new wxCheckBox( itemCollapsiblePane58->GetPane(), ID_CHECKBOX14, _("Checkbox"), wxDefaultPosition, wxDefaultSize, 0 );
    itemCheckBox66->SetValue(false);
    itemGridSizer59->Add(itemCheckBox66, 0, wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL|wxALL, 5);

    wxCheckBox* itemCheckBox67 = new wxCheckBox( itemCollapsiblePane58->GetPane(), ID_CHECKBOX15, _("Checkbox"), wxDefaultPosition, wxDefaultSize, 0 );
    itemCheckBox67->SetValue(false);
    itemGridSizer59->Add(itemCheckBox67, 0, wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL|wxALL, 5);

    wxCollapsiblePane* itemCollapsiblePane68 = new wxCollapsiblePane( itemPanel39, ID_COLLAPSIBLEPANE6, _("Label"), wxDefaultPosition, wxDefaultSize, wxCP_DEFAULT_STYLE );
    itemStaticBoxSizer41->Add(itemCollapsiblePane68, 0, wxGROW|wxALL, 5);
    wxButton* itemButton69 = new wxButton( itemCollapsiblePane68->GetPane(), ID_BUTTON27, _("Button"), wxDefaultPosition, wxDefaultSize, 0 );

    wxCollapsiblePane* itemCollapsiblePane70 = new wxCollapsiblePane( itemPanel39, ID_COLLAPSIBLEPANE7, _("Label"), wxDefaultPosition, wxDefaultSize, wxCP_DEFAULT_STYLE );
    itemStaticBoxSizer41->Add(itemCollapsiblePane70, 0, wxGROW|wxALL, 5);
    wxBoxSizer* itemBoxSizer71 = new wxBoxSizer(wxHORIZONTAL);
    itemCollapsiblePane70->GetPane()->SetSizer(itemBoxSizer71);

    wxButton* itemButton72 = new wxButton( itemCollapsiblePane70->GetPane(), ID_BUTTON28, _("Button"), wxDefaultPosition, wxDefaultSize, 0 );
    itemBoxSizer71->Add(itemButton72, 0, wxALIGN_CENTER_VERTICAL|wxALL, 5);

    wxButton* itemButton73 = new wxButton( itemCollapsiblePane70->GetPane(), ID_BUTTON29, _("Button"), wxDefaultPosition, wxDefaultSize, 0 );
    itemBoxSizer71->Add(itemButton73, 0, wxALIGN_CENTER_VERTICAL|wxALL, 5);

    itemNotebook3->AddPage(itemPanel39, _("Tab2"));

    itemBoxSizer2->Add(itemNotebook3, 0, wxALIGN_CENTER_HORIZONTAL|wxALL, 5);

////@end test12 content construction
}


/*!
 * Should we show tooltips?
 */

bool test12::ShowToolTips()
{
    return true;
}

/*!
 * Get bitmap resources
 */

wxBitmap test12::GetBitmapResource( const wxString& name )
{
    // Bitmap retrieval
////@begin test12 bitmap retrieval
    wxUnusedVar(name);
    return wxNullBitmap;
////@end test12 bitmap retrieval
}

/*!
 * Get icon resources
 */

wxIcon test12::GetIconResource( const wxString& name )
{
    // Icon retrieval
////@begin test12 icon retrieval
    wxUnusedVar(name);
    return wxNullIcon;
////@end test12 icon retrieval
}
