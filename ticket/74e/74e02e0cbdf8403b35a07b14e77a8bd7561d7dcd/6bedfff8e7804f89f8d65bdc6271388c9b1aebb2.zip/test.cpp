#include "wx/wxprec.h"
#ifdef __BORLANDC__
    #pragma hdrstop
#endif
#ifndef WX_PRECOMP
    #include "wx/wx.h"
#endif

class MyApp : public wxApp
{
public:
    virtual bool OnInit();
};

class MyFrame : public wxFrame
{
public:
    MyFrame(const wxString& title);
    void TestWorkFail1( wxCommandEvent& event );
    void TestWorkFail2( wxCommandEvent& event );
    void TestWorkWorkaround( wxCommandEvent& event );
    void OnQuit(wxCommandEvent& event);

private:
    void InitializeFourTestPanels();
    DECLARE_EVENT_TABLE()
    wxToolBar* toolbar;
    wxPanel* mainPanel;
    wxBoxSizer* mainPanelSizer;
};

BEGIN_EVENT_TABLE(MyFrame, wxFrame)
    EVT_BUTTON( 2, MyFrame::TestWorkFail1 )
    EVT_BUTTON( 3, MyFrame::TestWorkFail2 )
    EVT_BUTTON( 4, MyFrame::TestWorkWorkaround )
END_EVENT_TABLE()

IMPLEMENT_APP(MyApp)

bool MyApp::OnInit()
{
    if ( !wxApp::OnInit() )
        return false;
    MyFrame *frame = new MyFrame("Test Remove()");
    frame->Show(true);
    return true;
}

MyFrame::MyFrame(const wxString& title)
       : wxFrame(NULL, wxID_ANY, title)
{
    // Add sizer for toolbar and mainpanel
    wxBoxSizer* verticalsizer = new wxBoxSizer(wxVERTICAL);
    this->SetSizer(verticalsizer);

    // Add toolbar with three buttons for testing
    toolbar = new wxToolBar( this, 1);
    wxButton* buttonFail1 = new wxButton( toolbar, 2, _("Test fail 1"));
    wxButton* buttonFail2 = new wxButton( toolbar, 3, _("Test fail 2"));
    wxButton* buttonWorkaround = new wxButton( toolbar, 4, _("Workaround"));
    toolbar->AddControl(buttonFail1);
    toolbar->AddControl(buttonFail2);
    toolbar->AddControl(buttonWorkaround);
    toolbar->Realize();
    verticalsizer->Add(toolbar, 0, wxGROW|wxALL, 0);

    // Create mainpanel with sizer for testpanels
    mainPanel = new wxPanel( this, 5);
    verticalsizer->Add(mainPanel, 1, wxGROW|wxALL, 0);

    mainPanelSizer = new wxBoxSizer(wxHORIZONTAL);
    mainPanel->SetSizer(mainPanelSizer);

    Centre();
}

void MyFrame::TestWorkFail1( wxCommandEvent& WXUNUSED(event) )
{
    InitializeFourTestPanels();
    wxMessageBox("Initialize 4 panels, remove 1st panel 3 times.");

    mainPanelSizer->Remove(0);
    mainPanelSizer->Layout(); 
    mainPanelSizer->Remove(0);
    mainPanelSizer->Layout(); 
    mainPanelSizer->Remove(0);
    mainPanelSizer->Layout(); 
    Refresh();
    Update();

    wxMessageBox("If you now resize the window vertically, you can see the removed "
            "panels secretly floating behind the first.");

    toolbar->Disable();
}


/*
 * wxEVT_COMMAND_BUTTON_CLICKED event handler for ID_BUTTON1
 */

void MyFrame::TestWorkFail2( wxCommandEvent& WXUNUSED(event) )
{
    InitializeFourTestPanels();
    wxMessageBox("Initialize 4 panels, remove last 3 panels");

    mainPanelSizer->Remove(3);
    mainPanelSizer->Layout(); 
    mainPanelSizer->Remove(2);
    mainPanelSizer->Layout(); 
    mainPanelSizer->Remove(1);
    mainPanelSizer->Layout(); 

    Refresh();
    Update();

    wxMessageBox("It is now more obvious that the removed panels still exist--although "
            "detached--and you can resize vertically again.");

    toolbar->Disable();
}


void MyFrame::TestWorkWorkaround( wxCommandEvent& WXUNUSED(event) )
{
    InitializeFourTestPanels();
    wxMessageBox("Initialize 4 panels, remove last 3 panels + delete windows");

    mainPanelSizer->GetItem(3)->DeleteWindows();
    mainPanelSizer->Remove(3);
    mainPanelSizer->Layout(); 
    mainPanelSizer->GetItem(2)->DeleteWindows();
    mainPanelSizer->Remove(2);
    mainPanelSizer->Layout(); 
    mainPanelSizer->GetItem(1)->DeleteWindows();
    mainPanelSizer->Remove(1);
    mainPanelSizer->Layout(); 

    Refresh();
    Update();

    wxMessageBox("If we force the deletion of the window--by calling DeleteWindows() on "
            "the item--and then call Remove(), the behaviour is more as expected.");
}


void MyFrame::InitializeFourTestPanels()
{
    // Cleanup (if possible) remaining children
    size_t panels = mainPanelSizer->GetChildren().GetCount();
    for (size_t i=0; i<panels; i++) {
        mainPanelSizer->GetItem(static_cast<size_t>(0))->DeleteWindows();
        mainPanelSizer->Remove(0);
        mainPanelSizer->Layout();
    }

    // Add four test panels with different colors to mainpanel
    wxPanel* testPanel1 = new wxPanel( mainPanel, 6, wxDefaultPosition, wxSize(30,30));
    testPanel1->SetBackgroundColour(wxColour(255, 0, 0));
    mainPanelSizer->Add(testPanel1, 0, wxALIGN_CENTER_VERTICAL|wxALL, 5);

    wxPanel* testPanel2 = new wxPanel( mainPanel, 7, wxDefaultPosition, wxSize(30,30));
    testPanel2->SetBackgroundColour(wxColour(0, 255, 0));
    mainPanelSizer->Add(testPanel2, 0, wxALIGN_CENTER_VERTICAL|wxALL, 5);

    wxPanel* testPanel3 = new wxPanel( mainPanel, 8, wxDefaultPosition, wxSize(30,30));
    testPanel3->SetBackgroundColour(wxColour(255, 255, 0));
    mainPanelSizer->Add(testPanel3, 0, wxALIGN_CENTER_VERTICAL|wxALL, 5);

    wxPanel* testPanel4 = new wxPanel( mainPanel, 9, wxDefaultPosition, wxSize(30,30));
    testPanel4->SetBackgroundColour(wxColour(0, 0, 255));
    mainPanelSizer->Add(testPanel4, 0, wxALIGN_CENTER_VERTICAL|wxALL, 5);

    // Redraw sizer
    mainPanelSizer->Layout();
}

void MyFrame::OnQuit(wxCommandEvent& WXUNUSED(event))
{
    Close(true);
}
