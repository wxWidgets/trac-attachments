

#include <wx/xml/xml.h>
#include <wx/string.h>

#include "wxmemdbg.h"
#include <vld.h>

wxString xmlConfig = wxT("xmlc.xml");
wxString p1;
wxString p2;
wxString p3;
wxString p4;
wxString p5;
wxString p6;
wxString p7;

void readConfig();

int main(int argc,char **argv) {

readConfig();

}

void readConfig() {

wxXmlDocument doc;
if (doc.Load(xmlConfig)) {

wxXmlNode *root = doc.GetRoot();
// start processing the XML file
if (root->GetName() != wxT("Config")) {
    

root = doc.GetRoot();
wxXmlNode *child = root->GetChildren();
while (child) {
	wxString str=child->GetName();

    if (str == wxT("p1")) {
       p1 = child->GetNodeContent();
    }else if (str == wxT("p2")) {
       p2 = child->GetNodeContent(); 
    }else if(str==wxT("p3")) {
		p3 = child->GetNodeContent();
	}else if(str==wxT("p4")) {
		p4 = child->GetNodeContent();
	}else if(str==wxT("p5")) {
		p5 = child->GetNodeContent();
	}else if(str==wxT("p6")) {
		p6 = child->GetNodeContent();
	}else if(str==wxT("p7")) {
		p7 = child->GetNodeContent();
	}
	wxDELETE(child);
    child = child->GetNext();
}

wxDELETE(root);
//wxDELETE(child);

}

}

else {

wxPuts(wxT("Using Defaults"));

p1 =wxT("se");
p2 =wxT("D:,E:");
p3 = wxT("");
p4 = wxT("21");
p5 = wxT("");
p6 = wxT("");
p7 = wxT("");

}



}





