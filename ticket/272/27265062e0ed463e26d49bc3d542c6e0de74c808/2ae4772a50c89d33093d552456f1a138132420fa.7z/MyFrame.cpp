#include "MyFrame.h"

BEGIN_EVENT_TABLE(MyFrame, wxFrame)
    EVT_MENU(Minimal_Quit,  MyFrame::OnQuit)
    EVT_MENU(Minimal_About, MyFrame::OnAbout)
END_EVENT_TABLE()

// frame constructor
MyFrame::MyFrame(const wxString& title)
       : wxFrame(NULL, wxID_ANY, title)
{
    // set the frame icon
    SetIcon(wxICON(sample));

#if wxUSE_MENUS
    // create a menu bar
    wxMenu *fileMenu = new wxMenu;

    // the "About" item should be in the help menu
    wxMenu *helpMenu = new wxMenu;
    helpMenu->Append(Minimal_About, _T("&About...\tF1"), _T("Show about dialog"));
    fileMenu->Append(Minimal_Quit, _T("E&xit\tAlt-X"), _T("Quit this program"));

    // now append the freshly created menu to the menu bar...
    wxMenuBar *menuBar = new wxMenuBar();
    menuBar->Append(fileMenu, _T("&File"));
    menuBar->Append(helpMenu, _T("&Help"));

    // ... and attach this menu bar to the frame
    SetMenuBar(menuBar);

#endif // wxUSE_MENUS

#if wxUSE_STATUSBAR
    // create a status bar just for fun (by default with 1 pane only)
    CreateStatusBar(2);
    SetStatusText(_T("Welcome to wxWidgets!"));
#endif // wxUSE_STATUSBAR
}


// event handlers

void MyFrame::OnQuit(wxCommandEvent& WXUNUSED(event))
{
    // true is to force the frame to close
    Close(true);
}

void MyFrame::OnAbout(wxCommandEvent& WXUNUSED(event))
{
	wxFileDialog *openFileDialog = NULL;
	openFileDialog = new wxFileDialog(
		this,
		_("Choose a file to open"),
		wxEmptyString,
		wxEmptyString,
		_("All Files|*.*"),
		wxFD_OPEN,
		wxDefaultPosition);

	// Creates a "open file" dialog with 4 file types
	if (openFileDialog->ShowModal() == wxID_OK) // if the user click "Open" instead of "cancel"
	{
		wxString filepath = wxEmptyString;
		filepath = openFileDialog->GetPath(); // <- Corruption happens here.

		wxMessageDialog *message = new wxMessageDialog(NULL, filepath, _("File selected is"), wxOK);
        message->ShowModal();
	}
	openFileDialog->Destroy();
}
