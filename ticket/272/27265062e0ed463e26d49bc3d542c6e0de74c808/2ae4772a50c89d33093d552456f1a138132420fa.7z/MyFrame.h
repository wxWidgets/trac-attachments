#ifndef MYFRAME_H_INCLUDED
#define MYFRAME_H_INCLUDED

#include "wx/wxprec.h"

#include <wx/icon.h>
#include <wx/menu.h>
#include <wx/gdicmn.h>
#include <wx/toolbar.h>
#include <wx/sizer.h>
#include <wx/frame.h>

// GOOD PLACE to include "filedlg.h" and "msdlg.h"


// Place to includ boost asio
#include <boost/asio.hpp>

// BAD PLACE to include "filedlg.h" and "msdlg.h"
#include <wx/filedlg.h>
#include <wx/msgdlg.h>


// IDs for the controls and the menu commands
enum
{
    // menu items
    Minimal_Quit = wxID_EXIT,

    // it is important for the id corresponding to the "About" command to have
    // this standard value as otherwise it won't be handled properly under Mac
    // (where it is special and put into the "Apple" menu)
    Minimal_About = wxID_ABOUT
};

// Define a new frame type: this is going to be our main frame
class MyFrame : public wxFrame
{
public:
    // ctor(s)
    MyFrame(const wxString& title);

    // event handlers (these functions should _not_ be virtual)
    void OnQuit(wxCommandEvent& event);
    void OnAbout(wxCommandEvent& event);

private:
    // any class wishing to process wxWidgets events must use this macro
    DECLARE_EVENT_TABLE()
};


#endif // MYFRAME_HPP_INCLUDED
